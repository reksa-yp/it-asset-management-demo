<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$id = $_GET['id'] ?? null;
if ($id) {
    $db = getDB();

    $nameStmt = $db->prepare("SELECT name FROM asset_categories WHERE id = ?");
    $nameStmt->execute([$id]);
    $name = $nameStmt->fetchColumn();

    if ($name !== false) {
        // Cegah hapus kategori yang masih dipakai aset, supaya tidak ada
        // aset yang tiba-tiba kehilangan kategorinya di daftar.
        $countStmt = $db->prepare("SELECT COUNT(*) FROM assets WHERE category = ?");
        $countStmt->execute([$name]);
        $inUse = (int)$countStmt->fetchColumn();

        if ($inUse > 0) {
            $_SESSION['category_msg'] = ['ok' => false, 'text' => t('category_delete_in_use', $inUse)];
        } else {
            $stmt = $db->prepare("DELETE FROM asset_categories WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['category_msg'] = ['ok' => true, 'text' => t('category_deleted')];
        }
    }
}

header('Location: categories.php');
exit;
