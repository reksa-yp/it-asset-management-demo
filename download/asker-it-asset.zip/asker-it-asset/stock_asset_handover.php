<?php
/**
 * Serahkan 1 aset berstatus Stok ke user (dari menu Stok Barang > tab Aset IT Stok).
 *
 * TIDAK mengubah struktur database. Hanya mengisi tabel yang sudah ada:
 *   - asset_owners : user penerima dicatat sebagai pengguna aset
 *   - assets       : status -> 'Digunakan', lokasi (opsional) diperbarui,
 *                    departement/email/login PC disalin dari data user
 *                    (sama persis dengan saat aset disimpan dari menu Aset)
 *   - ticket tidak disentuh.
 *   - Jika aset berasal dari Barang Masuk ber-ID (stock_asset_links), penyerahan ini juga
 *     dicatat otomatis sebagai Barang Keluar (qty 1) di Riwayat Stok.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/mutation.php';
require_once __DIR__ . '/includes/stock.php';

$back = 'stock.php?tab=assets';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . $back); exit; }
csrfCheck();

$db       = getDB();
$assetId  = (int)($_POST['asset_id'] ?? 0);
$userId   = (int)($_POST['user_id'] ?? 0);
$location = trim((string)($_POST['location'] ?? ''));
$cat      = trim((string)($_POST['cat'] ?? ''));
if ($cat !== '') $back .= '&acat=' . urlencode($cat);

$a = $db->prepare("SELECT id, asset_number, status FROM assets WHERE id = ?");
$a->execute([$assetId]);
$asset = $a->fetch();

$u = $db->prepare("SELECT id, full_name, department FROM users WHERE id = ? AND is_active = 1");
$u->execute([$userId]);
$user = $u->fetch();

if (!$asset) {
    $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('asset_stock_err_asset')];
} elseif ($asset['status'] !== 'Stok') {
    $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('asset_stock_err_not_stock', $asset['asset_number'])];
} elseif (!$user) {
    $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('asset_stock_err_user')];
} elseif (!assetOwnersTableExists($db)) {
    $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('asset_stock_err_migration')];
} else {
    ensureMutationTable($db);              // tabel riwayat mutasi (dibuat sebelum transaksi)
    $srcTrx = stockTablesExist($db) ? assetStockSourceTrx($db, $assetId) : null;   // Barang Masuk asal aset (jika ada)
    $mutBefore = mutationSnapshot($db, $assetId);
    $db->beginTransaction();
    try {
        setAssetOwners($db, $assetId, [$userId]);
        if ($location !== '') {
            $db->prepare("UPDATE assets SET status = 'Digunakan', location = ? WHERE id = ?")->execute([mb_substr($location, 0, 100), $assetId]);
        } else {
            $db->prepare("UPDATE assets SET status = 'Digunakan' WHERE id = ?")->execute([$assetId]);
        }
        syncAssetUserData($db, $assetId); // departement, email, login PC ikut data user
        // Catat otomatis di menu Mutasi Aset: Stok IT -> user penerima.
        $mutNo = recordAssetMutation($db, $mutBefore, mutationSnapshot($db, $assetId), ['reason' => 'handover', 'source' => 'stock']);
        $extra = '';
        if ($srcTrx && stockItemAvailable($db, (int)$srcTrx['category_id'], trim((string)$srcTrx['item_name'])) >= 1) {
            // Catat juga sebagai Barang Keluar (1 unit) supaya jumlah stok & riwayat stok ikut sesuai.
            $db->prepare("INSERT INTO stock_transactions (category_id, type, trx_date, qty, item_name, user_id,
                          recipient_name, recipient_department, note, created_by) VALUES (?, 'out', ?, 1, ?, ?, ?, ?, ?, ?)")
               ->execute([(int)$srcTrx['category_id'], date('Y-m-d'), $srcTrx['item_name'], $userId, $user['full_name'],
                          $user['department'], mb_substr(t('stock_handover_note', $asset['asset_number'], $mutNo), 0, 255), (int)$_SESSION['user_id']]);
            stockLinkAssets($db, (int)$db->lastInsertId(), [$assetId]);
            $extra = ' ' . t('stock_handover_logged');
        }
        $db->commit();
        $_SESSION['stock_msg'] = ['ok' => true, 'text' => t('asset_stock_handover_done', $asset['asset_number'], $user['full_name']) . $extra];
    } catch (Throwable $e) {
        $db->rollBack();
        $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('asset_stock_err_save') . ' ' . $e->getMessage()];
    }
}

header('Location: ' . $back);
exit;
