<?php
/**
 * Menu Stok Barang (khusus admin): catat barang masuk / keluar, rekap per kategori & per user,
 * export Excel (stock_export_excel.php) dan print (stock_print.php).
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/stock.php';

$db = getDB();
ensureStockTables($db);   // hanya membuat tabel stok BARU jika belum ada

$f            = stockFilters();
$categories   = getStockCategories($db);
$transactions = getStockTransactions($db, $f);
$recap        = getStockRecap($db, $f);
$recapUser    = getStockRecapByUser($transactions);
$users        = $db->query("SELECT id, full_name, department FROM users WHERE is_active = 1 ORDER BY full_name")->fetchAll();

// Stok tersedia saat ini per kategori (untuk info di form)
$currentStock = [];
foreach ($db->query("SELECT category_id, SUM(CASE WHEN type='in' THEN qty ELSE -qty END) s FROM stock_transactions GROUP BY category_id") as $r) {
    $currentStock[(int)$r['category_id']] = (int)$r['s'];
}
// Barang yang pernah dicatat di Barang Masuk + stok tersedianya (untuk pilihan di form Barang Keluar)
$stockItems = getStockItems($db);
// Stok ber-ID aset: unit yang masih Stok (untuk Barang Keluar), jenis aset (untuk Barang Masuk), & ID per transaksi.
$stockUnits      = getStockItemUnits($db);
$assetCatOptions = getStockAssetCategoryOptions($db);
$trxAssets       = getStockTrxAssets($db, array_column($transactions, 'id'));
$usedCats = [];
foreach ($db->query("SELECT DISTINCT category_id FROM stock_transactions") as $r) { $usedCats[(int)$r['category_id']] = true; }

$totalIn  = array_sum(array_map(fn($t) => $t['type'] === 'in'  ? (int)$t['qty'] : 0, $transactions));
$totalOut = array_sum(array_map(fn($t) => $t['type'] === 'out' ? (int)$t['qty'] : 0, $transactions));
$receivers = count(array_unique(array_filter(array_map(fn($t) => $t['type'] === 'out' ? ($t['user_id'] ?: $t['recipient_name']) : null, $transactions))));
$lowList  = array_filter($recap, fn($r) => $r['status'] !== 'ok');
$totalStock = array_sum(array_map(fn($r) => max(0, $r['closing']), $recap));

$tab = in_array($_GET['tab'] ?? '', ['recap','assets','history','user'], true) ? $_GET['tab'] : 'recap';

// Jumlah transaksi SEMUA waktu & semua kategori (tanpa filter). Dipakai untuk memberi petunjuk
// saat tab Riwayat / Rekap per User kosong hanya karena filter periode (bawaan: bulan berjalan) atau kategori.
$allTrxCount = (int)$db->query("SELECT COUNT(*) FROM stock_transactions")->fetchColumn();
$allOutCount = (int)$db->query("SELECT COUNT(*) FROM stock_transactions WHERE type = 'out'")->fetchColumn();
$stockOutsideHint = function (int $count) use ($tab, $f): string {
    if ($count <= 0) return '';
    return '<div class="mt-3 text-slate-600">' . htmlspecialchars(sprintf(t('stock_outside_filter'), $count, stockPeriodLabel($f)))
         . ' <a href="stock.php?tab=' . htmlspecialchars($tab) . '&from=&to=" class="font-medium text-blue-600 hover:underline">'
         . htmlspecialchars(t('stock_show_all_time')) . '</a></div>';
};

// Stok Aset IT: otomatis dari aset berstatus "Stok" di menu Aset (hanya membaca tabel assets).
$assetStock      = getAssetStockSummary($db);
$assetStockTotal = array_sum(array_column($assetStock, 'stok'));
$assetStockCat   = trim((string)($_GET['acat'] ?? ''));
$assetStockItems = $tab === 'assets' ? getAssetStockItems($db, $assetStockCat) : [];
$qs  = stockFilterQuery($f);

$stockMsg = $_SESSION['stock_msg'] ?? null;
unset($_SESSION['stock_msg']);

$pageTitle = t('page_title_stock');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

$fmtDate = fn($d) => date('d M Y', strtotime($d));
$statusLabelsAsset = ['Digunakan' => t('status_used'), 'Stok' => t('status_stock'), 'Tidak Digunakan' => t('status_unused')];
$pill = [
    'ok'    => 'bg-green-100 text-green-700',
    'low'   => 'bg-amber-100 text-amber-700',
    'empty' => 'bg-red-100 text-red-700',
];
$bar = ['ok' => 'bg-green-500', 'low' => 'bg-amber-500', 'empty' => 'bg-red-500'];
?>

<div class="flex flex-wrap items-center justify-between gap-3 mb-4">
    <p class="text-sm text-slate-500 max-w-xl"><?= t('stock_intro') ?></p>
    <div class="flex flex-wrap gap-2">
        <button type="button" onclick="openStockModal('in')" class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('plus') ?> <?= t('stock_btn_in') ?>
        </button>
        <button type="button" onclick="openStockModal('out')" class="inline-flex items-center gap-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('minus') ?> <?= t('stock_btn_out') ?>
        </button>
        <a href="stock_export_excel.php?<?= htmlspecialchars($qs) ?>" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('sheet') ?> <?= t('btn_export_excel') ?>
        </a>
        <a href="stock_print.php?<?= htmlspecialchars($qs) ?>" target="_blank" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('printer') ?> <?= t('btn_print') ?>
        </a>
        <button type="button" onclick="openCategoryManager()" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('tag') ?> <?= t('stock_btn_categories') ?>
        </button>
    </div>
</div>

<?php if ($stockMsg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $stockMsg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>">
        <?= htmlspecialchars($stockMsg['text']) ?>
    </div>
<?php endif; ?>

<!-- Filter -->
<form method="get" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-end gap-3 text-sm">
    <input type="hidden" name="tab" value="<?= htmlspecialchars($tab) ?>">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('stock_filter_from') ?></span>
        <input type="date" name="from" value="<?= htmlspecialchars($f['from']) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('stock_filter_to') ?></span>
        <input type="date" name="to" value="<?= htmlspecialchars($f['to']) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('stock_category') ?></span>
        <select name="cat" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[150px]">
            <option value=""><?= t('stock_all_categories') ?></option>
            <?php foreach ($categories as $c): ?>
                <option value="<?= $c['id'] ?>" <?= $f['cat'] === (int)$c['id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['name']) ?></option>
            <?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('stock_type') ?></span>
        <select name="type" class="border border-slate-300 rounded-lg px-2 py-1.5">
            <option value=""><?= t('stock_all') ?></option>
            <option value="in" <?= $f['type'] === 'in' ? 'selected' : '' ?>><?= t('stock_type_in') ?></option>
            <option value="out" <?= $f['type'] === 'out' ? 'selected' : '' ?>><?= t('stock_type_out') ?></option>
        </select></label>
    <label class="flex flex-col gap-1 flex-1 min-w-[160px]"><span class="text-xs text-slate-500"><?= t('stock_search') ?></span>
        <input type="search" name="q" value="<?= htmlspecialchars($f['q']) ?>" placeholder="<?= htmlspecialchars(t('stock_search_ph')) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= t('stock_apply') ?></button>
    <a href="stock.php?tab=<?= htmlspecialchars($tab) ?>" class="text-slate-500 hover:text-slate-700 px-2 py-1.5"><?= t('stock_reset') ?></a>
    <a href="stock.php?tab=<?= htmlspecialchars($tab) ?>&from=&to=" class="text-slate-500 hover:text-slate-700 px-2 py-1.5"><?= t('stock_all_time') ?></a>
</form>

<!-- Kartu ringkasan -->
<div class="grid grid-cols-2 xl:grid-cols-5 gap-3 mb-4">
    <?php $assetStockSub = implode(' · ', array_map(fn($r) => $r['name'] . ': ' . $r['stok'], array_filter($assetStock, fn($r) => $r['stok'] > 0))) ?: t('asset_stock_none'); ?>
    <a href="stock.php?tab=assets" class="bg-white rounded-xl shadow-sm p-4 flex items-start gap-3 hover:bg-slate-50 transition col-span-2 xl:col-span-1">
        <span class="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 bg-indigo-50 text-indigo-700"><?= icon('laptop', 'w-5 h-5') ?></span>
        <div class="min-w-0">
            <p class="text-xs text-slate-500"><?= t('asset_stock_card') ?></p>
            <p class="text-2xl font-semibold text-slate-800 leading-tight tabular-nums"><?= number_format($assetStockTotal, 0, ',', '.') ?> <span class="text-sm font-normal text-slate-400"><?= t('asset_stock_unit') ?></span></p>
            <p class="text-xs text-slate-400 truncate" title="<?= htmlspecialchars($assetStockSub) ?>"><?= htmlspecialchars($assetStockSub) ?></p>
        </div>
    </a>
    <?php
    $cards = [
        [t('stock_card_total'), $totalStock, sprintf(t('stock_card_total_sub'), count($recap)), 'package', 'bg-brand-50 text-brand-700'],
        [t('stock_card_in'), $totalIn, stockPeriodLabel($f), 'arrow-down', 'bg-green-50 text-green-700'],
        [t('stock_card_out'), $totalOut, sprintf(t('stock_card_out_sub'), $receivers), 'arrow-up', 'bg-orange-50 text-orange-700'],
        [t('stock_card_low'), count($lowList), $lowList ? implode(', ', array_column($lowList, 'name')) : t('stock_card_low_none'), 'alert', $lowList ? 'bg-red-50 text-red-600' : 'bg-slate-100 text-slate-500'],
    ];
    foreach ($cards as [$label, $val, $sub, $ic, $tone]): ?>
        <div class="bg-white rounded-xl shadow-sm p-4 flex items-start gap-3">
            <span class="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 <?= $tone ?>"><?= icon($ic, 'w-5 h-5') ?></span>
            <div class="min-w-0">
                <p class="text-xs text-slate-500"><?= htmlspecialchars($label) ?></p>
                <p class="text-2xl font-semibold text-slate-800 leading-tight tabular-nums"><?= number_format($val, 0, ',', '.') ?></p>
                <p class="text-xs text-slate-400 truncate" title="<?= htmlspecialchars($sub) ?>"><?= htmlspecialchars($sub) ?></p>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Tab -->
<div class="bg-white rounded-xl shadow-sm">
    <div class="flex flex-wrap gap-1 border-b px-3 text-sm">
        <?php foreach (['recap' => t('stock_tab_recap'), 'assets' => t('asset_stock_tab'), 'history' => t('stock_tab_history'), 'user' => t('stock_tab_user')] as $k => $label): ?>
            <a href="stock.php?tab=<?= $k ?>&<?= htmlspecialchars($qs) ?>"
               class="px-3 py-3 border-b-2 font-medium whitespace-nowrap <?= $tab === $k ? 'border-brand-600 text-brand-700' : 'border-transparent text-slate-500 hover:text-slate-700' ?>"><?= $label ?><?php if ($k === 'assets'): ?> <span class="ml-1 text-xs rounded-full px-1.5 py-0.5 bg-indigo-50 text-indigo-700 tabular-nums"><?= $assetStockTotal ?></span><?php endif; ?></a>
        <?php endforeach; ?>
    </div>
    <div class="overflow-x-auto">

    <?php if ($tab === 'recap'): ?>
        <?php $max = max(1, ...array_map(fn($r) => $r['opening'] + $r['qty_in'], $recap ?: [['opening'=>1,'qty_in'=>0]])); ?>
        <table class="w-full text-sm">
            <thead class="bg-slate-50 text-slate-500 text-left"><tr>
                <th class="py-2 px-3 font-medium"><?= t('stock_category') ?></th>
                <th class="py-2 px-3 font-medium text-right"><?= t('stock_opening') ?></th>
                <th class="py-2 px-3 font-medium text-right"><?= t('stock_type_in') ?></th>
                <th class="py-2 px-3 font-medium text-right"><?= t('stock_type_out') ?></th>
                <th class="py-2 px-3 font-medium text-right"><?= t('stock_closing') ?></th>
                <th class="py-2 px-3 font-medium min-w-[140px]"><?= t('stock_availability') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('th_status') ?></th>
            </tr></thead>
            <tbody>
            <?php foreach ($recap as $r): ?>
                <tr class="border-t hover:bg-slate-50">
                    <td class="py-2 px-3 font-medium"><?= htmlspecialchars($r['name']) ?> <span class="text-xs text-slate-400 font-normal">· min. <?= $r['min_stock'] ?> <?= htmlspecialchars($r['unit']) ?></span></td>
                    <td class="py-2 px-3 text-right tabular-nums text-slate-500"><?= $r['opening'] ?></td>
                    <td class="py-2 px-3 text-right tabular-nums text-green-700"><?= $r['qty_in'] ? '+' . $r['qty_in'] : 0 ?></td>
                    <td class="py-2 px-3 text-right tabular-nums text-orange-700"><?= $r['qty_out'] ? '−' . $r['qty_out'] : 0 ?></td>
                    <td class="py-2 px-3 text-right tabular-nums font-semibold"><?= $r['closing'] ?> <span class="text-xs text-slate-400 font-normal"><?= htmlspecialchars($r['unit']) ?></span></td>
                    <td class="py-2 px-3"><div class="h-1.5 bg-slate-100 rounded-full overflow-hidden"><div class="h-full rounded-full <?= $bar[$r['status']] ?>" style="width:<?= max(0, min(100, $r['closing'] / $max * 100)) ?>%"></div></div></td>
                    <td class="py-2 px-3"><span class="px-2 py-0.5 rounded-full text-xs font-semibold <?= $pill[$r['status']] ?>"><?= stockStatusLabel($r['status']) ?></span></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$recap): ?>
                <tr><td colspan="7" class="p-8 text-center text-slate-400"><?= t('stock_no_categories') ?></td></tr>
            <?php endif; ?>
            </tbody>
            <?php if ($recap): ?>
            <tfoot class="bg-slate-50 font-semibold"><tr class="border-t">
                <td class="py-2 px-3"><?= t('stock_total') ?></td>
                <td class="py-2 px-3 text-right tabular-nums"><?= array_sum(array_column($recap, 'opening')) ?></td>
                <td class="py-2 px-3 text-right tabular-nums text-green-700">+<?= array_sum(array_column($recap, 'qty_in')) ?></td>
                <td class="py-2 px-3 text-right tabular-nums text-orange-700">−<?= array_sum(array_column($recap, 'qty_out')) ?></td>
                <td class="py-2 px-3 text-right tabular-nums"><?= array_sum(array_column($recap, 'closing')) ?></td>
                <td colspan="2"></td>
            </tr></tfoot>
            <?php endif; ?>
        </table>

        <!-- Stok Aset IT per jenis (otomatis dari menu Aset) -->
        <div class="border-t-4 border-slate-100">
            <div class="flex flex-wrap items-center justify-between gap-2 px-3 pt-4 pb-2">
                <p class="font-semibold text-slate-700"><?= t('asset_stock_recap_title') ?>
                    <span class="ml-1 text-[11px] font-semibold uppercase tracking-wide bg-indigo-50 text-indigo-700 rounded-full px-2 py-0.5"><?= t('asset_stock_auto_badge') ?></span></p>
                <a href="stock.php?tab=assets" class="text-xs font-medium text-blue-600 hover:underline"><?= t('asset_stock_view_units') ?> &rarr;</a>
            </div>
            <table class="w-full text-sm">
                <thead class="bg-slate-50 text-slate-500 text-left"><tr>
                    <th class="py-2 px-3 font-medium"><?= t('th_type') ?></th>
                    <th class="py-2 px-3 font-medium text-right"><?= t('asset_stock_col_stock') ?></th>
                    <th class="py-2 px-3 font-medium text-right"><?= t('status_used') ?></th>
                    <th class="py-2 px-3 font-medium text-right"><?= t('status_unused') ?></th>
                    <th class="py-2 px-3 font-medium text-right"><?= t('stock_total') ?></th>
                    <th class="py-2 px-3 font-medium"><?= t('th_status') ?></th>
                </tr></thead>
                <tbody>
                <?php foreach ($assetStock as $r): ?>
                    <tr class="border-t hover:bg-slate-50">
                        <td class="py-2 px-3 font-medium"><a href="stock.php?tab=assets&acat=<?= urlencode($r['name']) ?>" class="inline-flex items-center gap-2 hover:text-blue-600"><span class="text-slate-400"><?= categoryIcon($r['name'], 'w-4 h-4') ?></span><?= htmlspecialchars($r['name']) ?></a></td>
                        <td class="py-2 px-3 text-right tabular-nums font-semibold"><?= $r['stok'] ?> <span class="text-xs text-slate-400 font-normal"><?= t('asset_stock_unit') ?></span></td>
                        <td class="py-2 px-3 text-right tabular-nums text-slate-500"><?= $r['used'] ?></td>
                        <td class="py-2 px-3 text-right tabular-nums text-slate-500"><?= $r['unused'] ?></td>
                        <td class="py-2 px-3 text-right tabular-nums text-slate-500"><?= $r['total'] ?></td>
                        <td class="py-2 px-3"><span class="px-2 py-0.5 rounded-full text-xs font-semibold <?= $r['stok'] > 0 ? $pill['ok'] : $pill['empty'] ?>"><?= $r['stok'] > 0 ? t('asset_stock_available') : t('stock_status_empty') ?></span></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$assetStock): ?>
                    <tr><td colspan="6" class="p-6 text-center text-slate-400"><?= t('no_assets_yet') ?></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
            <p class="px-3 py-3 text-xs text-slate-400"><?= t('asset_stock_recap_hint') ?></p>
        </div>

    <?php elseif ($tab === 'assets'): ?>
        <div class="px-3 py-3 text-sm text-slate-600 bg-indigo-50/60 border-b border-indigo-100">
            <?= t('asset_stock_intro') ?>
            <div class="mt-2 flex flex-wrap gap-1.5">
                <a href="stock.php?tab=assets" class="px-2.5 py-1 rounded-full text-xs font-medium <?= $assetStockCat === '' ? 'bg-blue-600 text-white' : 'bg-white border text-slate-600' ?>"><?= t('stock_all') ?> <?= $assetStockTotal ?></a>
                <?php foreach ($assetStock as $r): if (!$r['stok']) continue; ?>
                    <a href="stock.php?tab=assets&acat=<?= urlencode($r['name']) ?>" class="px-2.5 py-1 rounded-full text-xs font-medium <?= $assetStockCat === $r['name'] ? 'bg-blue-600 text-white' : 'bg-white border text-slate-600' ?>"><?= htmlspecialchars($r['name']) ?> <?= $r['stok'] ?></a>
                <?php endforeach; ?>
            </div>
        </div>
        <table class="w-full text-sm">
            <thead class="bg-slate-50 text-slate-500 text-left"><tr>
                <th class="py-2 px-3 font-medium"><?= t('th_asset_no') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('th_type') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('th_specs') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('th_serial') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('th_location') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('lbl_purchase_date') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('th_action') ?></th>
            </tr></thead>
            <tbody>
            <?php foreach ($assetStockItems as $a):
                $spec = implode(' / ', array_filter([$a['processor'] ?? '', $a['ram'] ?? '', $a['storage'] ?? ''])); ?>
                <tr class="border-t hover:bg-slate-50 align-top">
                    <td class="py-2 px-3 whitespace-nowrap">
                        <a href="assets.php?q=<?= urlencode($a['asset_number']) ?>" class="font-medium text-blue-600 hover:underline"><?= htmlspecialchars($a['asset_number']) ?></a>
                        <div class="text-xs text-slate-400"><?= htmlspecialchars($a['device_name'] ?: '') ?></div>
                    </td>
                    <td class="py-2 px-3 whitespace-nowrap"><?= htmlspecialchars($a['category']) ?></td>
                    <td class="py-2 px-3 text-xs text-slate-600 min-w-[12rem]"><?= htmlspecialchars($spec ?: t('dash')) ?></td>
                    <td class="py-2 px-3 whitespace-nowrap"><?= htmlspecialchars($a['serial_number'] ?: t('dash')) ?></td>
                    <td class="py-2 px-3 whitespace-nowrap"><?= htmlspecialchars($a['location'] ?: t('dash')) ?></td>
                    <td class="py-2 px-3 whitespace-nowrap tabular-nums"><?= !empty($a['purchase_date']) ? $fmtDate($a['purchase_date']) : t('dash') ?></td>
                    <td class="py-2 px-3 whitespace-nowrap">
                        <button type="button" class="inline-flex items-center gap-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-3 py-1.5 text-xs font-medium"
                                onclick='openHandover(<?= json_encode(['id' => (int)$a['id'], 'no' => $a['asset_number'], 'name' => $a['device_name'] ?: $a['category'], 'spec' => $spec, 'location' => $a['location'] ?? ''], JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP) ?>)'>
                            <?= icon('users', 'w-3.5 h-3.5') ?> <?= t('asset_stock_btn_handover') ?>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$assetStockItems): ?>
                <tr><td colspan="7" class="p-8 text-center text-slate-400"><?= t('asset_stock_empty') ?></td></tr>
            <?php endif; ?>
            </tbody>
        </table>

    <?php elseif ($tab === 'history'): ?>
        <table class="w-full text-sm">
            <thead class="bg-slate-50 text-slate-500 text-left"><tr>
                <th class="py-2 px-3 font-medium"><?= t('th_date') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('stock_type') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('stock_category') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('stock_item_name') ?></th>
                <th class="py-2 px-3 font-medium text-right"><?= t('stock_qty') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('stock_asset_ids') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('stock_given_to') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('stock_note') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('th_action') ?></th>
            </tr></thead>
            <tbody>
            <?php foreach ($transactions as $tx): $in = $tx['type'] === 'in'; ?>
                <tr class="border-t hover:bg-slate-50 align-top">
                    <td class="py-2 px-3 whitespace-nowrap tabular-nums"><?= $fmtDate($tx['trx_date']) ?></td>
                    <td class="py-2 px-3">
                        <span class="inline-flex items-center gap-1 text-xs font-semibold rounded-full px-2 py-0.5 <?= $in ? 'bg-green-50 text-green-700' : 'bg-orange-50 text-orange-700' ?>">
                            <?= icon($in ? 'arrow-down' : 'arrow-up', 'w-3 h-3') ?> <?= $in ? t('stock_type_in') : t('stock_type_out') ?>
                        </span>
                    </td>
                    <td class="py-2 px-3 font-medium"><?= htmlspecialchars($tx['category_name']) ?></td>
                    <td class="py-2 px-3 text-slate-600"><?= htmlspecialchars($tx['item_name'] ?: t('dash')) ?></td>
                    <td class="py-2 px-3 text-right tabular-nums font-semibold whitespace-nowrap <?= $in ? 'text-green-700' : 'text-orange-700' ?>"><?= $in ? '+' : '−' ?><?= (int)$tx['qty'] ?> <span class="text-xs text-slate-400 font-normal"><?= htmlspecialchars($tx['unit']) ?></span></td>
                    <td class="py-2 px-3">
                        <?php $txA = $trxAssets[(int)$tx['id']] ?? []; ?>
                        <?php if ($txA): ?>
                            <div class="flex flex-col gap-0.5">
                            <?php foreach (array_slice($txA, 0, 6) as $la): ?>
                                <a href="assets.php?q=<?= urlencode($la['asset_number']) ?>" class="text-xs font-medium text-blue-600 hover:underline whitespace-nowrap" title="<?= htmlspecialchars($statusLabelsAsset[$la['status']] ?? $la['status']) ?>"><?= htmlspecialchars($la['asset_number']) ?></a>
                            <?php endforeach; ?>
                            <?php if (count($txA) > 6): ?>
                                <a href="stock.php?tab=history&q=<?= urlencode($tx['item_name'] ?? '') ?>" class="text-xs text-slate-400"><?= t('stock_asset_ids_more', count($txA) - 6) ?></a>
                            <?php endif; ?>
                            </div>
                        <?php else: ?><span class="text-slate-300"><?= t('dash') ?></span><?php endif; ?>
                    </td>
                    <td class="py-2 px-3">
                        <?php if (!$in): ?>
                            <div class="font-medium"><?= htmlspecialchars($tx['recipient_name'] ?: t('dash')) ?></div>
                            <div class="text-xs text-slate-400"><?= htmlspecialchars($tx['recipient_department'] ?: '') ?></div>
                        <?php else: ?><span class="text-slate-300"><?= t('dash') ?></span><?php endif; ?>
                    </td>
                    <td class="py-2 px-3 text-slate-500 max-w-[240px]"><?= htmlspecialchars($tx['note'] ?: t('dash')) ?></td>
                    <td class="py-2 px-3 whitespace-nowrap">
                        <button type="button" class="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-blue-600" title="<?= htmlspecialchars(t('btn_edit')) ?>"
                                onclick='openStockModal(null, <?= json_encode([
                                    'id' => (int)$tx['id'], 'type' => $tx['type'], 'category_id' => (int)$tx['category_id'],
                                    'trx_date' => $tx['trx_date'], 'qty' => (int)$tx['qty'], 'item_name' => $tx['item_name'],
                                    'user_id' => $tx['user_id'] ? (int)$tx['user_id'] : '', 'note' => $tx['note'],
                                    'linked' => count($trxAssets[(int)$tx['id']] ?? []),
                                ], JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP) ?>)'><?= icon('pencil') ?></button>
                        <form method="post" action="stock_delete.php" class="inline" onsubmit="return confirm('<?= htmlspecialchars(t('stock_confirm_delete'), ENT_QUOTES) ?>')">
                            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                            <input type="hidden" name="id" value="<?= (int)$tx['id'] ?>">
                            <input type="hidden" name="back" value="<?= htmlspecialchars('tab=history&' . $qs) ?>">
                            <button type="submit" class="p-1.5 rounded-lg text-slate-500 hover:bg-red-50 hover:text-red-600" title="<?= htmlspecialchars(t('link_delete')) ?>"><?= icon('trash') ?></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$transactions): ?>
                <tr><td colspan="9" class="p-8 text-center text-slate-400"><?= t('stock_no_transactions') ?><?= $stockOutsideHint($allTrxCount) ?></td></tr>
            <?php endif; ?>
            </tbody>
        </table>

    <?php else: ?>
        <table class="w-full text-sm">
            <thead class="bg-slate-50 text-slate-500 text-left"><tr>
                <th class="py-2 px-3 font-medium"><?= t('stock_user') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('th_department') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('stock_items_received') ?></th>
                <th class="py-2 px-3 font-medium text-right"><?= t('stock_total_items') ?></th>
                <th class="py-2 px-3 font-medium"><?= t('stock_last_received') ?></th>
            </tr></thead>
            <tbody>
            <?php foreach ($recapUser as $u): ?>
                <tr class="border-t hover:bg-slate-50">
                    <td class="py-2 px-3 font-medium"><?= htmlspecialchars($u['name']) ?></td>
                    <td class="py-2 px-3 text-slate-500"><?= htmlspecialchars($u['department']) ?></td>
                    <td class="py-2 px-3"><div class="flex flex-wrap gap-1">
                        <?php foreach ($u['items'] as $cn => $q): ?>
                            <span class="text-xs bg-slate-100 text-slate-700 rounded-full px-2 py-0.5"><?= htmlspecialchars($cn) ?> <b class="tabular-nums"><?= $q ?></b></span>
                        <?php endforeach; ?>
                    </div></td>
                    <td class="py-2 px-3 text-right tabular-nums font-semibold"><?= $u['total'] ?></td>
                    <td class="py-2 px-3 whitespace-nowrap text-slate-500"><?= $fmtDate($u['last']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$recapUser): ?>
                <tr><td colspan="5" class="p-8 text-center text-slate-400"><?= t('stock_no_out') ?><?= $stockOutsideHint($allOutCount) ?></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>
    </div>
</div>

<!-- ===== Modal transaksi stok ===== -->
<div id="stockModal" class="hidden fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
    <form method="post" action="stock_save.php" id="stockForm" class="bg-white rounded-xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="id" id="sfId" value="">
        <input type="hidden" name="type" id="sfType" value="in">
        <input type="hidden" name="back" value="<?= htmlspecialchars('tab=history&' . $qs) ?>">
        <div class="flex items-center justify-between px-5 py-4 border-b">
            <h3 class="font-semibold text-slate-800" id="sfTitle"><?= t('stock_modal_title') ?></h3>
            <button type="button" data-modal-close onclick="closeStockModal()" class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button>
        </div>
        <div class="px-5 py-4 space-y-4 text-sm">
            <div class="grid grid-cols-2 gap-1 bg-slate-100 rounded-lg p-1">
                <button type="button" id="sfBtnIn" onclick="setStockType('in')" class="rounded-md py-1.5 font-medium"><?= t('stock_btn_in') ?></button>
                <button type="button" id="sfBtnOut" onclick="setStockType('out')" class="rounded-md py-1.5 font-medium"><?= t('stock_btn_out') ?></button>
            </div>
            <div class="grid sm:grid-cols-2 gap-3">
                <label class="flex flex-col gap-1 sm:col-span-2"><span class="font-medium text-slate-700"><?= t('stock_category') ?> <span class="text-red-500">*</span></span>
                    <select name="category_id" id="sfCat" required class="border border-slate-300 rounded-lg px-3 py-2" onchange="updateStockInfo(); refreshStockItems(true)">
                        <?php foreach ($categories as $c): ?>
                            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <span id="sfStockInfo" class="text-xs text-slate-500"></span></label>
                <!-- Barang Masuk: nama barang diketik (dengan saran nama yang sudah pernah dipakai) -->
                <label class="flex flex-col gap-1 sm:col-span-2" id="sfItemWrap"><span class="font-medium text-slate-700"><?= t('stock_item_name') ?> <span class="text-slate-400 font-normal">(<?= t('stock_optional') ?>)</span></span>
                    <input name="item_name" id="sfItem" maxlength="100" list="sfItemList" autocomplete="off" class="border border-slate-300 rounded-lg px-3 py-2" placeholder="<?= htmlspecialchars(t('stock_item_ph')) ?>">
                    <datalist id="sfItemList"></datalist></label>
                <!-- Barang Keluar: barang dipilih dari yang sudah dicatat di Barang Masuk -->
                <label class="hidden flex-col gap-1 sm:col-span-2" id="sfPickWrap"><span class="font-medium text-slate-700"><?= t('stock_pick_item') ?> <span class="text-red-500">*</span></span>
                    <select id="sfPick" class="border border-slate-300 rounded-lg px-3 py-2" onchange="onStockPick()"></select>
                    <span id="sfPickInfo" class="text-xs text-slate-500"></span></label>
                <label class="flex flex-col gap-1"><span class="font-medium text-slate-700" id="sfDateLbl"></span>
                    <input type="date" name="trx_date" id="sfDate" required class="border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="flex flex-col gap-1"><span class="font-medium text-slate-700" id="sfQtyLbl"></span>
                    <input type="number" name="qty" id="sfQty" min="1" required oninput="refreshAssetPreview()" class="border border-slate-300 rounded-lg px-3 py-2 tabular-nums"></label>
                <!-- Barang Masuk: daftarkan tiap unit sebagai aset (ID otomatis, status Stok) -->
                <div id="sfAssetWrap" class="sm:col-span-2 rounded-lg border border-blue-200 bg-blue-50/60 p-3 space-y-2">
                    <label class="flex items-start gap-2 cursor-pointer">
                        <input type="checkbox" name="register_asset" value="1" id="sfAsAsset" class="mt-0.5 h-4 w-4 accent-blue-600" onchange="refreshAssetPreview()" <?= $assetCatOptions ? '' : 'disabled' ?>>
                        <span><span class="font-medium text-slate-800"><?= t('stock_register_asset') ?></span><br>
                        <span class="text-xs text-slate-500"><?= $assetCatOptions ? t('stock_register_asset_hint') : t('stock_register_asset_no_cat') ?></span></span>
                    </label>
                    <div id="sfAssetOpt" class="hidden space-y-2 pl-6">
                        <label class="flex flex-col gap-1"><span class="font-medium text-slate-700"><?= t('stock_asset_category') ?> <span class="text-red-500">*</span></span>
                            <select name="asset_category" id="sfAssetCat" class="border border-slate-300 rounded-lg px-3 py-2 bg-white" onchange="refreshAssetPreview()">
                                <?php foreach ($assetCatOptions as $ac): ?>
                                    <option value="<?= htmlspecialchars($ac['name']) ?>"><?= htmlspecialchars($ac['name']) ?> (<?= htmlspecialchars($ac['abbr']) ?>)</option>
                                <?php endforeach; ?>
                            </select></label>
                        <div class="text-xs text-slate-600"><span class="font-medium"><?= t('stock_asset_preview') ?></span>
                            <div id="sfAssetPreview" class="mt-1 flex flex-wrap gap-1"></div></div>
                    </div>
                </div>
                <!-- Barang Keluar: pilih ID aset yang diberikan (untuk barang ber-ID) -->
                <div id="sfUnitsWrap" class="hidden sm:col-span-2 rounded-lg border border-orange-200 bg-orange-50/60 p-3 space-y-2">
                    <div class="flex items-center justify-between gap-2">
                        <span class="font-medium text-slate-800"><?= t('stock_pick_units') ?></span>
                        <span class="flex gap-3 text-xs"><button type="button" onclick="setAllUnits(true)" class="text-blue-600 hover:underline"><?= t('user_export_select_all') ?></button><button type="button" onclick="setAllUnits(false)" class="text-blue-600 hover:underline"><?= t('user_export_select_none') ?></button></span>
                    </div>
                    <div id="sfUnits" class="grid sm:grid-cols-2 gap-1.5 max-h-48 overflow-y-auto"></div>
                    <p id="sfUnitsHint" class="text-xs text-slate-500"></p>
                </div>
                <p id="sfLockedInfo" class="hidden sm:col-span-2 text-xs bg-amber-50 text-amber-800 rounded-lg px-3 py-2"></p>
                <label class="flex flex-col gap-1 sm:col-span-2" id="sfUserWrap"><span class="font-medium text-slate-700"><?= t('stock_given_to_user') ?> <span class="text-red-500">*</span></span>
                    <input type="search" id="sfUserSearch" autocomplete="off" data-user-search="sfUser" class="border border-slate-300 rounded-lg px-3 py-2" placeholder="<?= htmlspecialchars(t('stock_search_user_ph')) ?>">
                    <span id="sfUserSearchInfo" class="hidden text-xs"></span>
                    <select name="user_id" id="sfUser" class="border border-slate-300 rounded-lg px-3 py-2">
                        <option value=""><?= t('stock_choose_user') ?></option>
                        <?php foreach ($users as $u): ?>
                            <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['full_name']) ?><?= $u['department'] ? ' · ' . htmlspecialchars($u['department']) : '' ?></option>
                        <?php endforeach; ?>
                    </select>
                    <span class="text-xs text-slate-500"><?= t('stock_user_hint') ?></span></label>
                <label class="flex flex-col gap-1 sm:col-span-2"><span class="font-medium text-slate-700"><?= t('stock_note') ?></span>
                    <textarea name="note" id="sfNote" rows="2" maxlength="255" class="border border-slate-300 rounded-lg px-3 py-2" placeholder="<?= htmlspecialchars(t('stock_note_ph')) ?>"></textarea></label>
            </div>
            <p id="sfErr" class="hidden text-sm bg-red-50 text-red-700 rounded-lg px-3 py-2"></p>
        </div>
        <div class="px-5 py-3 border-t flex justify-end gap-2">
            <button type="button" onclick="closeStockModal()" class="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm"><?= t('btn_cancel') ?></button>
            <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium"><?= t('btn_save') ?></button>
        </div>
    </form>
</div>

<!-- ===== Modal serahkan aset stok ke user ===== -->
<div id="handoverModal" class="hidden fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
    <form method="post" action="stock_asset_handover.php" class="bg-white rounded-xl shadow-xl w-full max-w-md">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="asset_id" id="hoId" value="">
        <input type="hidden" name="cat" value="<?= htmlspecialchars($assetStockCat) ?>">
        <div class="flex items-center justify-between px-5 py-4 border-b">
            <h3 class="font-semibold text-slate-800"><?= t('asset_stock_btn_handover') ?></h3>
            <button type="button" data-modal-close onclick="closeHandover()" class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button>
        </div>
        <div class="px-5 py-4 space-y-3 text-sm">
            <div class="rounded-lg bg-slate-50 p-3"><p class="font-medium text-slate-700" id="hoNo"></p><p class="text-slate-500" id="hoInfo"></p></div>
            <label class="flex flex-col gap-1"><span class="font-medium text-slate-700"><?= t('stock_given_to_user') ?> <span class="text-red-500">*</span></span>
                <input type="search" id="hoUserSearch" autocomplete="off" data-user-search="hoUser" class="border border-slate-300 rounded-lg px-3 py-2" placeholder="<?= htmlspecialchars(t('stock_search_user_ph')) ?>">
                <span id="hoUserSearchInfo" class="hidden text-xs"></span>
                <select name="user_id" id="hoUser" required class="border border-slate-300 rounded-lg px-3 py-2">
                    <option value=""><?= t('stock_choose_user') ?></option>
                    <?php foreach ($users as $u): ?>
                        <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['full_name']) ?><?= $u['department'] ? ' · ' . htmlspecialchars($u['department']) : '' ?></option>
                    <?php endforeach; ?>
                </select></label>
            <label class="flex flex-col gap-1"><span class="font-medium text-slate-700"><?= t('asset_stock_new_location') ?> <span class="text-slate-400 font-normal">(<?= t('stock_optional') ?>)</span></span>
                <input name="location" id="hoLoc" maxlength="100" class="border border-slate-300 rounded-lg px-3 py-2"></label>
            <p class="text-xs text-slate-500"><?= t('asset_stock_handover_hint') ?></p>
        </div>
        <div class="px-5 py-3 border-t flex justify-end gap-2">
            <button type="button" onclick="closeHandover()" class="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm"><?= t('btn_cancel') ?></button>
            <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium"><?= t('asset_stock_btn_confirm') ?></button>
        </div>
    </form>
</div>

<!-- ===== Modal kelola kategori stok ===== -->
<div id="catModal" class="hidden fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-xl max-h-[90vh] flex flex-col">
        <div class="flex items-center justify-between px-5 py-4 border-b">
            <h3 class="font-semibold text-slate-800"><?= t('stock_btn_categories') ?></h3>
            <button type="button" data-modal-close onclick="document.getElementById('catModal').classList.add('hidden')" class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button>
        </div>
        <div class="overflow-y-auto px-5 py-4 text-sm space-y-4">
            <form method="post" action="stock_category_save.php" id="catForm" class="grid grid-cols-6 gap-2 items-end bg-slate-50 rounded-lg p-3">
                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="id" id="cfId" value="">
                <label class="col-span-6 sm:col-span-3 flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('stock_cat_name') ?></span>
                    <input name="name" id="cfName" required maxlength="60" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
                <label class="col-span-3 sm:col-span-1 flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('stock_unit') ?></span>
                    <input name="unit" id="cfUnit" maxlength="20" value="pcs" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
                <label class="col-span-3 sm:col-span-1 flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('stock_min') ?></span>
                    <input type="number" min="0" name="min_stock" id="cfMin" value="0" class="border border-slate-300 rounded-lg px-2 py-1.5 tabular-nums"></label>
                <button type="submit" class="col-span-6 sm:col-span-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-3 py-1.5 font-medium" id="cfBtn"><?= t('btn_save') ?></button>
            </form>
            <p class="text-xs text-slate-500"><?= t('stock_cat_hint') ?></p>
            <table class="w-full">
                <thead class="text-slate-500 text-left"><tr>
                    <th class="py-1.5 font-medium"><?= t('stock_cat_name') ?></th><th class="py-1.5 font-medium"><?= t('stock_unit') ?></th>
                    <th class="py-1.5 font-medium text-right"><?= t('stock_min') ?></th><th class="py-1.5 font-medium text-right"><?= t('stock_now') ?></th><th></th>
                </tr></thead>
                <tbody>
                <?php foreach ($categories as $c): ?>
                    <tr class="border-t">
                        <td class="py-1.5 font-medium"><?= htmlspecialchars($c['name']) ?></td>
                        <td class="py-1.5"><?= htmlspecialchars($c['unit']) ?></td>
                        <td class="py-1.5 text-right tabular-nums"><?= (int)$c['min_stock'] ?></td>
                        <td class="py-1.5 text-right tabular-nums"><?= $currentStock[(int)$c['id']] ?? 0 ?></td>
                        <td class="py-1.5 text-right whitespace-nowrap">
                            <button type="button" class="text-blue-600 hover:underline text-xs"
                                    onclick='editStockCategory(<?= json_encode(['id'=>(int)$c['id'],'name'=>$c['name'],'unit'=>$c['unit'],'min_stock'=>(int)$c['min_stock']], JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP) ?>)'><?= t('btn_edit') ?></button>
                            <?php if (empty($usedCats[(int)$c['id']])): ?>
                                <form method="post" action="stock_category_save.php" class="inline" onsubmit="return confirm('<?= htmlspecialchars(t('stock_cat_confirm_delete'), ENT_QUOTES) ?>')">
                                    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                                    <button type="submit" class="text-red-600 hover:underline text-xs ml-2"><?= t('link_delete') ?></button>
                                </form>
                            <?php else: ?>
                                <span class="text-slate-300 text-xs ml-2 cursor-not-allowed" title="<?= htmlspecialchars(t('stock_cat_in_use')) ?>"><?= t('link_delete') ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
const STOCK_NOW  = <?= json_encode((object)$currentStock) ?>;
const STOCK_CATS = <?= json_encode(array_map(fn($c) => ['id'=>(int)$c['id'],'unit'=>$c['unit'],'min'=>(int)$c['min_stock']], $categories)) ?>;
const STOCK_T = <?= json_encode([
    'date_in' => t('stock_date_in'), 'date_out' => t('stock_date_out'), 'qty_in' => t('stock_qty_in'), 'qty_out' => t('stock_qty_out'),
    'available' => t('stock_available'), 'title_new' => t('stock_modal_title'), 'title_edit' => t('stock_modal_edit'),
    'err_user' => t('stock_err_user'), 'err_qty' => t('stock_err_qty'), 'err_over' => t('stock_err_over'), 'no_cat' => t('stock_no_categories'),
]) ?>;
const STOCK_ITEMS = <?= json_encode($stockItems, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const STOCK_T2 = <?= json_encode([
    'noname' => t('stock_item_noname'), 'none' => t('stock_pick_none'), 'avail' => t('stock_pick_available'),
    'err_pick' => t('stock_err_pick'), 'err_item_over' => t('stock_err_item_over'),
], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const STOCK_UNITS = <?= json_encode($stockUnits, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const ASSET_CATS  = <?= json_encode($assetCatOptions, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const STOCK_T3 = <?= json_encode([
    'preview_empty' => t('stock_asset_preview_empty'), 'preview_more' => tRaw('stock_asset_preview_more'),
    'units_all' => t('stock_units_hint_all'), 'units_mixed' => tRaw('stock_units_hint_mixed'),
    'locked' => t('stock_locked_linked'), 'err_units' => t('stock_err_pick_units'),
    'err_asset_item' => t('stock_err_asset_item'), 'err_asset_max' => tRaw('stock_err_asset_max'),
], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const ASSET_MAX_UNITS = <?= STOCK_ASSET_MAX_UNITS ?>;
let stockEditing = null;
const normItem = (v) => String(v || '').trim().toLowerCase();

/** Stok tersedia 1 barang (kategori + nama), memperhitungkan transaksi yang sedang diedit. */
function itemAvailableFor(catId, item) {
    const row = STOCK_ITEMS.find(r => r.cat == catId && normItem(r.item) === normItem(item));
    let s = row ? row.s : 0;
    if (stockEditing && stockEditing.category_id == catId && normItem(stockEditing.item_name) === normItem(item)) {
        s -= (stockEditing.type === 'in' ? stockEditing.qty : -stockEditing.qty);
    }
    return s;
}
/** Isi saran nama (Barang Masuk) & daftar pilihan barang (Barang Keluar) sesuai kategori terpilih. */
function refreshStockItems(resetPick) {
    const catId = document.getElementById('sfCat').value;
    const type  = document.getElementById('sfType').value;
    const items = STOCK_ITEMS.filter(r => r.cat == catId);
    document.getElementById('sfItemList').innerHTML = items.filter(r => r.item !== '')
        .map(r => '<option value="' + r.item.replace(/"/g, '&quot;') + '"></option>').join('');
    if (type !== 'out') return;

    const pick = document.getElementById('sfPick');
    const keep = resetPick ? '' : document.getElementById('sfItem').value;
    // Barang yang masih ada stoknya, ditambah barang milik transaksi yang sedang diedit.
    const list = items.map(r => ({ item: r.item, s: itemAvailableFor(catId, r.item) }))
        .filter(r => r.s > 0 || (stockEditing && stockEditing.type === 'out' && stockEditing.category_id == catId && normItem(stockEditing.item_name) === normItem(r.item)));
    if (stockEditing && stockEditing.type === 'out' && stockEditing.category_id == catId && !list.some(r => normItem(r.item) === normItem(stockEditing.item_name))) {
        list.push({ item: stockEditing.item_name || '', s: itemAvailableFor(catId, stockEditing.item_name) });
    }
    const unit = (STOCK_CATS.find(c => c.id == catId) || {}).unit || '';
    const esc = v => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
    pick.innerHTML = list.length
        ? list.map(r => '<option value="' + esc(r.item) + '">' + esc(r.item || STOCK_T2.noname) + ' \u2014 ' + STOCK_T2.avail + ' ' + r.s + ' ' + esc(unit) + '</option>').join('')
        : '<option value="">' + esc(STOCK_T2.none) + '</option>';
    pick.disabled = !list.length;
    const match = list.find(r => normItem(r.item) === normItem(keep));
    pick.value = match ? match.item : (list[0] ? list[0].item : '');
    onStockPick();
}
function onStockPick() {
    const catId = document.getElementById('sfCat').value, pick = document.getElementById('sfPick');
    document.getElementById('sfItem').value = pick.disabled ? '' : pick.value;
    const info = document.getElementById('sfPickInfo');
    info.textContent = pick.disabled ? STOCK_T2.none : '';
    refreshUnits();
}

/* ===== Stok ber-ID aset ===== */
const escH = v => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
function refreshAssetPreview() {
    const on = document.getElementById('sfAsAsset').checked;
    document.getElementById('sfAssetOpt').classList.toggle('hidden', !on);
    if (!on) return;
    const c = ASSET_CATS.find(x => x.name === document.getElementById('sfAssetCat').value);
    const n = Math.min(Math.max(parseInt(document.getElementById('sfQty').value, 10) || 0, 0), ASSET_MAX_UNITS);
    const box = document.getElementById('sfAssetPreview');
    if (!c || !n) { box.innerHTML = '<span class="text-slate-400">' + escH(STOCK_T3.preview_empty) + '</span>'; return; }
    const no = i => <?= json_encode(assetPrefix()) ?> + '/STOK/' + c.abbr + '/' + String(c.next + i).padStart(3, '0');
    const show = Math.min(n, 6);
    let html = '';
    for (let i = 0; i < show; i++) html += '<span class="font-mono bg-white border border-blue-200 text-blue-800 rounded px-1.5 py-0.5">' + escH(no(i)) + '</span>';
    if (n > show) html += '<span class="text-slate-500 self-center">' + escH(STOCK_T3.preview_more.replace('%d', n - show).replace('%s', no(n - 1))) + '</span>';
    box.innerHTML = html;
}
/** Unit ber-ID (status Stok) untuk barang terpilih di Barang Keluar. */
function unitsForPick() {
    const catId = +document.getElementById('sfCat').value, pick = document.getElementById('sfPick');
    if (pick.disabled) return [];
    return STOCK_UNITS.filter(u => u.cat === catId && u.key === normItem(pick.value));
}
function refreshUnits() {
    const type = document.getElementById('sfType').value, wrap = document.getElementById('sfUnitsWrap');
    const units = (type === 'out' && !stockEditing) ? unitsForPick() : [];
    wrap.classList.toggle('hidden', !units.length);
    document.getElementById('sfUnits').innerHTML = units.map(u =>
        '<label class="flex items-center gap-2 bg-white border border-slate-200 rounded-md px-2 py-1.5 cursor-pointer hover:border-orange-300">' +
        '<input type="checkbox" name="asset_ids[]" value="' + u.id + '" class="h-4 w-4 accent-orange-600" onchange="onUnitsChange()">' +
        '<span class="font-mono text-xs">' + escH(u.no) + '</span></label>').join('');
    const pick = document.getElementById('sfPick');
    const nonLinked = units.length ? itemAvailableFor(document.getElementById('sfCat').value, pick.value) - units.length : 0;
    wrap.dataset.nonLinked = nonLinked;
    document.getElementById('sfUnitsHint').textContent = nonLinked > 0 ? STOCK_T3.units_mixed.replace('%d', nonLinked) : STOCK_T3.units_all;
    onUnitsChange();
}
function setAllUnits(on) { document.querySelectorAll('#sfUnits input').forEach(i => i.checked = on); onUnitsChange(); }
function onUnitsChange() {
    const wrap = document.getElementById('sfUnitsWrap'), qty = document.getElementById('sfQty');
    const units = wrap.classList.contains('hidden') ? 0 : document.querySelectorAll('#sfUnits input').length;
    const checked = document.querySelectorAll('#sfUnits input:checked').length;
    // Jumlah keluar = banyaknya ID dicentang. Hanya bisa diketik bila ada sisa stok tanpa ID & tidak ada yang dicentang.
    const lock = units > 0 && (checked > 0 || (+wrap.dataset.nonLinked || 0) <= 0);
    qty.readOnly = lock;
    qty.classList.toggle('bg-slate-100', lock);
    if (units > 0 && lock) qty.value = checked || '';
}

function setStockType(type) {
    document.getElementById('sfType').value = type;
    const on = 'text-white', inBtn = document.getElementById('sfBtnIn'), outBtn = document.getElementById('sfBtnOut');
    inBtn.className  = 'rounded-md py-1.5 font-medium ' + (type === 'in'  ? 'bg-green-600 ' + on : 'text-slate-600');
    outBtn.className = 'rounded-md py-1.5 font-medium ' + (type === 'out' ? 'bg-orange-600 ' + on : 'text-slate-600');
    const req = ' <span class="text-red-500">*</span>';
    document.getElementById('sfDateLbl').innerHTML = (type === 'in' ? STOCK_T.date_in : STOCK_T.date_out) + req;
    document.getElementById('sfQtyLbl').innerHTML  = (type === 'in' ? STOCK_T.qty_in : STOCK_T.qty_out) + req;
    document.getElementById('sfUserWrap').classList.toggle('hidden', type === 'in');
    document.getElementById('sfUser').required = (type === 'out');
    // Barang Masuk: ketik nama barang. Barang Keluar: pilih dari barang yang sudah masuk.
    document.getElementById('sfItemWrap').classList.toggle('hidden', type === 'out');
    document.getElementById('sfItemWrap').classList.toggle('flex', type !== 'out');
    document.getElementById('sfPickWrap').classList.toggle('hidden', type !== 'out');
    document.getElementById('sfPickWrap').classList.toggle('flex', type === 'out');
    document.getElementById('sfAssetWrap').classList.toggle('hidden', type !== 'in' || !!stockEditing);
    if (type !== 'out') {
        document.getElementById('sfUnitsWrap').classList.add('hidden');
        document.getElementById('sfQty').readOnly = false;
        document.getElementById('sfQty').classList.remove('bg-slate-100');
    }
    updateStockInfo();
    refreshStockItems(false);
    refreshAssetPreview();
}
function availableFor(catId) {
    let s = STOCK_NOW[catId] || 0;
    if (stockEditing && stockEditing.category_id == catId) s -= (stockEditing.type === 'in' ? stockEditing.qty : -stockEditing.qty);
    return s;
}
function updateStockInfo() {
    const id = document.getElementById('sfCat').value, cat = STOCK_CATS.find(c => c.id == id);
    if (!cat) { document.getElementById('sfStockInfo').textContent = STOCK_T.no_cat; return; }
    const s = availableFor(id);
    document.getElementById('sfStockInfo').innerHTML = STOCK_T.available + ': <b class="tabular-nums ' + (s <= cat.min ? 'text-amber-600' : 'text-slate-700') + '">' + s + ' ' + cat.unit + '</b>';
}
function openStockModal(type, data) {
    stockEditing = data || null;
    document.getElementById('sfErr').classList.add('hidden');
    document.getElementById('sfTitle').textContent = data ? STOCK_T.title_edit : STOCK_T.title_new;
    document.getElementById('sfId').value   = data ? data.id : '';
    if (data) document.getElementById('sfCat').value = data.category_id;
    document.getElementById('sfItem').value = data ? (data.item_name || '') : '';
    document.getElementById('sfDate').value = data ? data.trx_date : '<?= date('Y-m-d') ?>';
    document.getElementById('sfQty').value  = data ? data.qty : '';
    resetUserSearch('sfUser');
    document.getElementById('sfUser').value = data ? (data.user_id || '') : '';
    document.getElementById('sfNote').value = data ? (data.note || '') : '';
    document.getElementById('sfAsAsset').checked = false;
    document.getElementById('sfQty').readOnly = false;
    document.getElementById('sfQty').classList.remove('bg-slate-100');
    setStockType(data ? data.type : type);
    // Transaksi yang terhubung dengan ID aset: hanya tanggal & keterangan yang bisa diubah.
    const locked = !!(data && data.linked);
    document.getElementById('sfLockedInfo').classList.toggle('hidden', !locked);
    document.getElementById('sfLockedInfo').textContent = locked ? STOCK_T3.locked : '';
    ['sfCat', 'sfItem', 'sfPick', 'sfQty', 'sfUser', 'sfUserSearch', 'sfBtnIn', 'sfBtnOut'].forEach(id => {
        const el = document.getElementById(id);
        if (el) { el.disabled = locked ? true : (id === 'sfPick' ? el.disabled : false); el.classList.toggle('opacity-60', locked); }
    });
    if (!locked && document.getElementById('sfType').value === 'out') refreshStockItems(false);
    document.getElementById('stockModal').classList.remove('hidden');
    setTimeout(() => document.getElementById('sfQty').focus(), 50);
}
function closeStockModal() { document.getElementById('stockModal').classList.add('hidden'); }
document.getElementById('stockForm').addEventListener('submit', e => {
    const type = document.getElementById('sfType').value, qty = parseInt(document.getElementById('sfQty').value, 10);
    const err = m => { e.preventDefault(); const el = document.getElementById('sfErr'); el.textContent = m; el.classList.remove('hidden'); };
    if (stockEditing && stockEditing.linked) {
        // Field terkunci (disabled) tidak ikut terkirim; server memakai data lama. Aktifkan sebentar agar form valid.
        ['sfCat', 'sfItem', 'sfPick', 'sfQty', 'sfUser'].forEach(id => document.getElementById(id).disabled = false);
        return;
    }
    if (!qty || qty < 1) return err(STOCK_T.err_qty);
    if (type === 'in' && document.getElementById('sfAsAsset').checked) {
        if (!document.getElementById('sfItem').value.trim()) return err(STOCK_T3.err_asset_item);
        if (qty > ASSET_MAX_UNITS) return err(STOCK_T3.err_asset_max.replace('%d', ASSET_MAX_UNITS));
    }
    if (type === 'out' && !document.getElementById('sfUnitsWrap').classList.contains('hidden')) {
        const checked = document.querySelectorAll('#sfUnits input:checked').length;
        const nonLinked = +document.getElementById('sfUnitsWrap').dataset.nonLinked || 0;
        if (!checked && nonLinked < qty) return err(STOCK_T3.err_units);
    }
    if (type === 'out') {
        const pick = document.getElementById('sfPick');
        if (pick.disabled) return err(STOCK_T2.err_pick);
        document.getElementById('sfItem').value = pick.value;
        const si = itemAvailableFor(document.getElementById('sfCat').value, pick.value);
        if (qty > si) return err(STOCK_T2.err_item_over.replace('%s', pick.value || STOCK_T2.noname).replace('%d', Math.max(0, si)));
        if (!document.getElementById('sfUser').value) return err(STOCK_T.err_user);
        const s = availableFor(document.getElementById('sfCat').value);
        if (qty > s) return err(STOCK_T.err_over.replace('%d', s));
    }
});
function openCategoryManager() {
    editStockCategory(null);
    document.getElementById('catModal').classList.remove('hidden');
}
function editStockCategory(c) {
    document.getElementById('cfId').value   = c ? c.id : '';
    document.getElementById('cfName').value = c ? c.name : '';
    document.getElementById('cfUnit').value = c ? c.unit : 'pcs';
    document.getElementById('cfMin').value  = c ? c.min_stock : 0;
    document.getElementById('cfName').focus();
}
function openHandover(a) {
    document.getElementById('hoId').value = a.id;
    document.getElementById('hoNo').textContent = a.no;
    document.getElementById('hoInfo').textContent = a.name + (a.spec ? ' · ' + a.spec : '');
    document.getElementById('hoLoc').value = a.location || '';
    resetUserSearch('hoUser');
    document.getElementById('hoUser').value = '';
    document.getElementById('handoverModal').classList.remove('hidden');
}
function closeHandover() { document.getElementById('handoverModal').classList.add('hidden'); }
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeStockModal(); closeHandover(); document.getElementById('catModal').classList.add('hidden'); } });
/* ===== Pencarian user (Barang Keluar & Serahkan Aset) =====
 * Kotak cari menyaring daftar pilihan user berdasarkan nama / departement.
 * Opsi dibangun ulang (bukan disembunyikan) agar jalan di semua browser. */
const USER_SEARCH_T = <?= json_encode(['found' => t('stock_search_user_found'), 'none' => t('stock_search_user_none')], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const USER_SEARCH = {};
function initUserSearch(selectId) {
    const sel = document.getElementById(selectId), input = document.getElementById(selectId + 'Search');
    if (!sel || !input) return;
    const opts = Array.from(sel.options);
    USER_SEARCH[selectId] = {
        placeholder: opts.find(o => o.value === ''),
        all: opts.filter(o => o.value !== '').map(o => ({ value: o.value, text: o.text, key: o.text.toLowerCase() })),
    };
    input.addEventListener('input', () => filterUserOptions(selectId));
    input.addEventListener('keydown', e => {
        if (e.key === 'Enter') {            // Enter = pilih hasil pertama, jangan submit form
            e.preventDefault();
            if (sel.options.length > 1 && !sel.value) sel.selectedIndex = 1;
            sel.focus();
        } else if (e.key === 'ArrowDown') { e.preventDefault(); sel.focus(); }
    });
}
function filterUserOptions(selectId) {
    const st = USER_SEARCH[selectId]; if (!st) return;
    const sel = document.getElementById(selectId), input = document.getElementById(selectId + 'Search');
    const info = document.getElementById(selectId + 'SearchInfo');
    const words = input.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
    const keep = sel.value;
    const list = words.length ? st.all.filter(u => words.every(w => u.key.includes(w))) : st.all;
    sel.innerHTML = '';
    if (st.placeholder) sel.appendChild(st.placeholder);
    list.forEach(u => sel.appendChild(new Option(u.text, u.value)));
    // Pertahankan user yang sudah dipilih bila masih cocok; jika hasil cuma 1, langsung terpilih.
    sel.value = list.some(u => u.value === keep) ? keep : (list.length === 1 ? list[0].value : '');
    if (!words.length) { info.classList.add('hidden'); return; }
    info.textContent = list.length ? USER_SEARCH_T.found.replace('%d', list.length) : USER_SEARCH_T.none;
    info.className = 'text-xs ' + (list.length ? 'text-slate-500' : 'text-red-600');
}
function resetUserSearch(selectId) {
    const input = document.getElementById(selectId + 'Search');
    if (input) { input.value = ''; filterUserOptions(selectId); }
}
initUserSearch('sfUser');
initUserSearch('hoUser');
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
