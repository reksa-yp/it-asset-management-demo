<?php
require_once __DIR__ . '/includes/auth.php';
requireAdminOrQme();   // admin, atau user QME (khusus aset Tablet)

// Hapus hanya lewat POST + token CSRF (link biasa / GET tidak bisa menghapus data).
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: assets.php'); exit; }
csrfCheck();

$id = $_POST['id'] ?? null;
if ($id) {
    qmeAssertTabletAssets(getDB(), [(int)$id]);   // user QME: hanya tablet
    $stmt = getDB()->prepare("DELETE FROM assets WHERE id = ?");
    $stmt->execute([$id]);
    deleteTabletDetails(getDB(), [(int)$id]); // hapus juga detail tablet (jika ada)
    deleteExtNumbers(getDB(), [(int)$id]);    // hapus juga Nomor Ext (jika ada)
    deleteCctvAssetData(getDB(), [(int)$id]);   // brand/type & pemetaan CCTV (jika ada)
    deleteNvrAssets(getDB(), [(int)$id]);       // aset NVR -> NVR di menu CCTV ikut dihapus
}
header('Location: assets.php');
exit;
