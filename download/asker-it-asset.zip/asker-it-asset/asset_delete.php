<?php
require_once __DIR__ . '/includes/auth.php';
requireAdminOrQme();   // admin, atau user QME (khusus aset Tablet)

$id = $_GET['id'] ?? null;
if ($id) {
    qmeAssertTabletAssets(getDB(), [(int)$id]);   // user QME: hanya tablet
    $stmt = getDB()->prepare("DELETE FROM assets WHERE id = ?");
    $stmt->execute([$id]);
    deleteTabletDetails(getDB(), [(int)$id]); // hapus juga detail tablet (jika ada)
    deleteExtNumbers(getDB(), [(int)$id]);    // hapus juga Nomor Ext (jika ada)
    deleteCctvAssetData(getDB(), [(int)$id]);   // brand/type & pemetaan CCTV (jika ada)
    deleteNvrAssets(getDB(), [(int)$id]);       // aset NVR -> NVR di menu CCTV ikut dihapus
}
header('Location: assets.php');
exit;
