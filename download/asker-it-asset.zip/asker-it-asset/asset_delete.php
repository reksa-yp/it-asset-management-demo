<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = getDB()->prepare("DELETE FROM assets WHERE id = ?");
    $stmt->execute([$id]);
    deleteTabletDetails(getDB(), [(int)$id]); // hapus juga detail tablet (jika ada)
}
header('Location: assets.php');
exit;
