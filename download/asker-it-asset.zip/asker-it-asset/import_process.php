<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/categories.php';
require_once __DIR__ . '/includes/asset_import.php';
require_once __DIR__ . '/includes/tablet_excel.php';
require_once __DIR__ . '/includes/asset_user_import.php';
require_once __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['excel_file']['tmp_name'])) {
    header('Location: assets.php');
    exit;
}
csrfCheck();


try {
    $spreadsheet = IOFactory::load($_FILES['excel_file']['tmp_name']);
    $sheet = $spreadsheet->getActiveSheet();

    // ===== File GABUNGAN Aset + User (template_aset_user.xlsx) =====
    // Dikenali dari kolom Username / Nama Lengkap. Diproses langsung dalam 1 transaksi.
    if (isAssetUserXlsHeader(readSheetHeader($sheet))) {
        $db = getDB();
        $db->beginTransaction();
        $res = importAssetUserSheet($db, $sheet);
        $db->commit();
        $text = t('import_au_done', $res['assets_new'], $res['assets_upd'], $res['users_new'], $res['users_upd'], $res['skipped']);
        if ($res['errors']) {
            $text .= ' ' . t('import_au_notes') . ' ' . implode(' | ', array_slice($res['errors'], 0, 8));
            if (count($res['errors']) > 8) $text .= ' ' . sprintf(t('import_au_more'), count($res['errors']) - 8);
        }
        $_SESSION['import_msg'] = ['ok' => true, 'text' => $text];
        header('Location: assets.php');
        exit;
    }

    // ===== File format TABLET (hasil Export Tablet / Template Tablet) =====
    // Kalau ada sheet berformat tablet, file disimpan sementara lalu ditampilkan dulu di
    // halaman Preview. Data baru benar-benar disimpan setelah admin menekan "Simpan".
    $hasTabletSheet = false;
    foreach ($spreadsheet->getWorksheetIterator() as $ws) {
        if (isTabletXlsHeader(readSheetHeader($ws))) { $hasTabletSheet = true; break; }
    }
    if ($hasTabletSheet) {
        ensureTabletTable(getDB());
        tabletImportDiscardPending();
        $tmp = tempnam(sys_get_temp_dir(), 'tabimp_');
        if (!$tmp || !move_uploaded_file($_FILES['excel_file']['tmp_name'], $tmp)) {
            throw new Exception('File upload tidak bisa disimpan sementara di server.');
        }
        $_SESSION['tablet_import'] = [
            'file' => $tmp,
            'name' => basename((string)$_FILES['excel_file']['name']),
            'time' => time(),
        ];
        header('Location: tablet_import_preview.php');
        exit;
    }

    $db = getDB();
    $db->beginTransaction();
    [$inserted, $updated, $skipped] = importGenericAssetSheet($db, $sheet);

    $db->commit();

    $_SESSION['import_msg'] = [
        'ok'   => true,
        'text' => "Import selesai: $inserted data baru ditambahkan, $updated data diperbarui, $skipped baris dilewati (ID Aset kosong)."
    ];
} catch (Throwable $e) {
    if (isset($db) && $db->inTransaction()) { $db->rollBack(); }
    $_SESSION['import_msg'] = ['ok' => false, 'text' => 'Import gagal: ' . $e->getMessage()];
}

header('Location: assets.php');
exit;
