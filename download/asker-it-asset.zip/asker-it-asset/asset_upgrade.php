<?php
/**
 * Form Proses Upgrade Aset (khusus admin).
 *   asset_upgrade.php?asset_id=12&ticket_id=45  -> dari Dashboard "Aset Perlu Di-Upgrade"
 *   asset_upgrade.php?asset_id=12               -> Catat Upgrade tanpa tiket (dari menu Aset)
 *
 * Saat disimpan:
 *   1. Kolom aset yang dipilih (RAM, Storage, OS, dll.) diperbarui dengan nilai baru.
 *   2. Riwayat dicatat di tabel baru asset_upgrade_logs + asset_upgrade_log_items.
 *   3. (Opsional, dicentang default) tiket ditandai selesai lewat asset_upgrade_ack
 *      sehingga hilang dari daftar "Aset Perlu Di-Upgrade" di Dashboard.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/upgrade_alert.php';
require_once __DIR__ . '/includes/asset_upgrade.php';

$db = getDB();
ensureUpgradeLogTables($db);   // hanya membuat tabel BARU jika belum ada

$assetId  = (int)($_POST['asset_id'] ?? $_GET['asset_id'] ?? 0);
$ticketId = (int)($_POST['ticket_id'] ?? $_GET['ticket_id'] ?? 0);
$asset = $assetId ? getAssetForCurrentUser($assetId) : null;
if (!$asset) {
    http_response_code(404);
    die(htmlspecialchars(t('access_denied_asset')));
}

// Tiket asal (opsional) + catatan "harus upgrade"-nya
$ticket = null;
$ticketNote = '';
if ($ticketId) {
    $st = $db->prepare("
        SELECT t.id, t.ticket_number, t.problem_detail, wd.work_detail, wd.asset_check
        FROM tickets t LEFT JOIN ticket_work_details wd ON wd.ticket_id = t.id
        WHERE t.id = ? AND t.asset_id = ?
    ");
    $st->execute([$ticketId, $assetId]);
    $ticket = $st->fetch() ?: null;
    if ($ticket) {
        foreach (['asset_check', 'work_detail', 'problem_detail'] as $col) {
            if (stripos((string)$ticket[$col], UPGRADE_ALERT_KEYWORD) !== false) { $ticketNote = (string)$ticket[$col]; break; }
        }
        if ($ticketNote === '') $ticketNote = (string)($ticket['asset_check'] ?: ($ticket['work_detail'] ?: $ticket['problem_detail']));
    } else {
        $ticketId = 0;
    }
}

$ackReady = (bool)$db->query("SELECT COUNT(*) FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_upgrade_ack'")->fetchColumn();

$defs = upgradeFieldDefs();
$cur = fn(string $k) => str_starts_with($k, '__') ? '' : (string)($asset[$k] ?? '');
$me = currentUser();

// ---------------- Simpan ----------------
$errors = [];
$form = ['rows' => [], 'date' => date('Y-m-d'), 'notes' => '', 'done' => 1];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $keys    = (array)($_POST['field'] ?? []);
    $afters  = (array)($_POST['after'] ?? []);
    $labels  = (array)($_POST['label'] ?? []);
    $befores = (array)($_POST['before_other'] ?? []);
    $swStat  = (array)($_POST['sw_status'] ?? []);
    $form = [
        'rows'  => [],
        'date'  => trim((string)($_POST['upgrade_date'] ?? '')),
        'notes' => trim((string)($_POST['notes'] ?? '')),
        'done'  => !empty($_POST['mark_done']) ? 1 : 0,
    ];

    $items = [];
    $seen = [];
    foreach ($keys as $i => $k) {
        $k      = (string)$k;
        $after  = trim((string)($afters[$i] ?? ''));
        $label  = trim((string)($labels[$i] ?? ''));
        $before = trim((string)($befores[$i] ?? ''));
        $sw     = (string)($swStat[$i] ?? 'Original');
        $form['rows'][] = ['key' => $k, 'after' => $after, 'label' => $label, 'before' => $before, 'sw_status' => $sw];

        if (!isset($defs[$k])) { $errors[] = t('upg_err_unknown'); continue; }
        if ($k === UPGRADE_FIELD_OTHER) {
            if ($label === '') { $errors[] = t('upg_err_other_label'); continue; }
        } elseif ($k === UPGRADE_FIELD_SOFTWARE) {
            $label = 'Software';
            $before = '';
        } else {
            $label = $defs[$k]['label'];
            $before = $cur($k);                                   // nilai lama selalu dari database
            if (isset($seen[$k])) { $errors[] = sprintf(t('upg_err_duplicate'), $label); continue; }
            $seen[$k] = true;
            if (isset($defs[$k]['options']) && !isset($defs[$k]['options'][$after])) { $errors[] = sprintf(t('upg_err_after'), $label); continue; }
        }
        if ($after === '') { $errors[] = sprintf(t('upg_err_after'), $label); continue; }
        if ($after === $before) { $errors[] = sprintf(t('upg_err_same'), $label); continue; }
        if (mb_strlen($after) > 150 || mb_strlen($label) > 100) { $errors[] = sprintf(t('upg_err_long'), $label); continue; }
        $items[] = ['key' => $k, 'label' => $label, 'before' => $before, 'after' => $after, 'sw_status' => $sw];
    }
    if (!$items && !$errors) $errors[] = t('upg_err_empty');
    $d = DateTime::createFromFormat('Y-m-d', $form['date']);
    if (!$d || $d->format('Y-m-d') !== $form['date']) $errors[] = t('upg_err_date');

    if (!$errors) {
        try {
            $logId = saveAssetUpgrade($db, $assetId, $ticketId ?: null, $form['date'], $form['notes'], $items,
                                      (string)($me['full_name'] ?: $me['username']));
            $acked = false;
            if ($ticketId && $form['done'] && $ackReady) {
                acknowledgeUpgrade($db, $assetId, $ticketId, $me['id'] !== null ? (int)$me['id'] : null);
                $acked = true;
            }
            $_SESSION['upgrade_msg'] = ['log' => $logId, 'acked' => $acked, 'ack_missing' => $ticketId && $form['done'] && !$ackReady];
            header('Location: asset_upgrade.php?asset_id=' . $assetId . '&saved=' . $logId);
            exit;
        } catch (Throwable $e) {
            $errors[] = t('upg_err_save') . ' ' . $e->getMessage();
        }
    }
}

// Baris awal: saran dari catatan tiket, atau 1 baris kosong
if (!$form['rows']) {
    $form['rows'] = $ticketNote !== '' ? suggestUpgradeRows($ticketNote) : [];
    if (!$form['rows']) $form['rows'] = [['key' => 'ram', 'after' => '']];
}

$msg = $_SESSION['upgrade_msg'] ?? null;
unset($_SESSION['upgrade_msg']);
$savedId = (int)($_GET['saved'] ?? 0);
$history = getAssetUpgradeHistory($db, $assetId);
$lastUp  = getLastUpgradedFields($db, $assetId);

$pageTitle = t('upg_page_title');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

$h = fn($v) => htmlspecialchars((string)$v);
$inputCls = 'w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500';
$fieldsForJs = [];
foreach ($defs as $k => $f) {
    $fieldsForJs[] = ['key' => $k, 'label' => $f['label'], 'options' => $f['options'] ?? null, 'before' => $cur($k),
                      'beforeLabel' => $k === 'os_status' && $cur($k) !== '' ? ($defs['os_status']['options'][$cur($k)] ?? $cur($k)) : $cur($k)];
}
?>

<div class="max-w-4xl mx-auto space-y-5">

    <div class="flex flex-wrap items-center justify-between gap-3">
        <a href="dashboard.php" class="inline-flex items-center gap-1 text-sm text-brand-600 hover:underline">&larr; <?= t('upg_back_dashboard') ?></a>
        <a href="assets.php?q=<?= urlencode($asset['asset_number']) ?>" class="text-sm text-slate-500 hover:text-slate-700 underline"><?= t('upg_open_asset') ?></a>
    </div>

    <?php if ($msg && $savedId): ?>
        <div class="rounded-xl bg-green-50 border border-green-200 px-5 py-4 text-sm text-green-800 flex flex-wrap items-center justify-between gap-3">
            <div>
                <p class="font-semibold"><?= t('upg_saved') ?></p>
                <?php if (!empty($msg['acked'])): ?><p class="text-green-700"><?= t('upg_saved_acked') ?></p><?php endif; ?>
                <?php if (!empty($msg['ack_missing'])): ?>
                    <p class="text-amber-700"><?= t('upgrade_marked_done_need_migration') ?></p>
                <?php endif; ?>
            </div>
            <div class="flex flex-wrap gap-2">
                <a href="dashboard.php" class="bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-3 py-1.5 text-xs font-medium"><?= t('upg_back_dashboard') ?></a>
                <a href="asset_detail_print.php?id=<?= $assetId ?>" target="_blank" class="inline-flex items-center gap-1 bg-white border border-green-200 hover:bg-green-100 text-green-800 rounded-lg px-3 py-1.5 text-xs font-medium"><?= icon('printer', 'w-3.5 h-3.5') ?> <?= t('btn_print') ?></a>
            </div>
        </div>
    <?php endif; ?>

    <!-- Info aset -->
    <section class="bg-white rounded-2xl shadow-sm overflow-hidden">
        <div class="bg-gradient-to-r from-brand-600 to-brand-700 px-5 py-5 text-white flex items-center gap-3">
            <div class="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center shrink-0"><?= categoryIcon((string)$asset['category'], 'w-6 h-6') ?></div>
            <div class="min-w-0">
                <h1 class="font-semibold text-lg truncate"><?= $h($asset['device_name'] ?: $asset['asset_number']) ?></h1>
                <p class="text-brand-100 text-sm truncate"><?= $h($asset['asset_number']) ?> &middot; <?= $h($asset['category']) ?> &middot; <?= $h($asset['owner_name'] ?: t('dash')) ?> &middot; <?= $h($asset['department'] ?: t('dash')) ?></p>
            </div>
        </div>
        <dl class="grid sm:grid-cols-2 gap-x-8 px-5 py-2">
            <?php foreach ($defs as $k => $f): if (str_starts_with($k, '__')) continue;
                $v = $cur($k);
                if ($k === 'os_status' && $v !== '') $v = $f['options'][$v] ?? $v; ?>
                <div class="asset-field-row border-b border-slate-100">
                    <dt><?= $h($f['label']) ?></dt>
                    <dd><?= $h($v !== '' ? $v : t('dash')) ?>
                        <?php if (!empty($lastUp[$k])): ?>
                            <span class="block text-[11px] text-brand-600 font-medium"><?= $h(sprintf(t('upg_upgraded_on'), date('d M Y', strtotime($lastUp[$k])))) ?></span>
                        <?php endif; ?>
                    </dd>
                </div>
            <?php endforeach; ?>
        </dl>
    </section>

    <!-- Form upgrade -->
    <section class="bg-white rounded-2xl shadow-sm">
        <div class="px-5 py-4 border-b"><h2 class="font-semibold text-slate-700"><?= $ticket ? t('upg_form_title_ticket') : t('upg_form_title') ?></h2></div>
        <form method="post" class="p-5 space-y-5">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="asset_id" value="<?= $assetId ?>">
            <input type="hidden" name="ticket_id" value="<?= $ticketId ?>">

            <?php if ($ticket): ?>
                <div class="rounded-xl border border-red-100 bg-red-50 px-3 py-2 text-xs text-red-700">
                    <b><?= $h($ticket['ticket_number']) ?></b> &middot; <?= $h($ticketNote) ?>
                </div>
            <?php endif; ?>
            <?php if ($errors): ?>
                <div class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"><?= implode('<br>', array_map($h, array_unique($errors))) ?></div>
            <?php endif; ?>

            <div>
                <div class="flex items-center justify-between gap-2 mb-2">
                    <p class="text-sm font-semibold text-slate-700"><?= t('upg_what') ?></p>
                    <button type="button" id="upgAddRow" class="inline-flex items-center gap-1 text-brand-600 hover:bg-brand-50 rounded-lg px-2.5 py-1.5 text-xs font-medium"><?= icon('plus', 'w-3.5 h-3.5') ?> <?= t('upg_add_row') ?></button>
                </div>
                <div class="hidden sm:grid grid-cols-12 gap-2 text-[11px] uppercase tracking-wider text-slate-400 font-semibold px-1 mb-1">
                    <span class="col-span-4"><?= t('upg_col_component') ?></span><span class="col-span-3"><?= t('upg_col_before') ?></span><span class="col-span-4"><?= t('upg_col_after') ?></span><span class="col-span-1"></span>
                </div>
                <div id="upgRows" class="space-y-2"></div>
                <p class="text-xs text-slate-400 mt-2"><?= t('upg_rows_hint') ?></p>
            </div>

            <div class="grid gap-4 sm:grid-cols-2">
                <label class="block"><span class="block text-sm font-medium text-slate-600 mb-1"><?= t('upg_date') ?></span>
                    <input type="date" name="upgrade_date" value="<?= $h($form['date']) ?>" required class="<?= $inputCls ?>"></label>
                <label class="block"><span class="block text-sm font-medium text-slate-600 mb-1"><?= t('upg_done_by') ?></span>
                    <input value="<?= $h($me['full_name'] ?: $me['username']) ?>" readonly class="<?= $inputCls ?> bg-slate-50 text-slate-500"></label>
            </div>
            <label class="block"><span class="block text-sm font-medium text-slate-600 mb-1"><?= t('upg_notes') ?></span>
                <textarea name="notes" rows="2" maxlength="1000" placeholder="<?= $h(t('upg_notes_ph')) ?>" class="<?= $inputCls ?>"><?= $h($form['notes']) ?></textarea></label>

            <?php if ($ticket): ?>
                <label class="flex items-start gap-2 text-sm text-slate-600">
                    <input type="checkbox" name="mark_done" value="1" <?= $form['done'] ? 'checked' : '' ?> class="mt-0.5">
                    <span><?= sprintf(t('upg_mark_done'), '<b>' . $h($ticket['ticket_number']) . '</b>') ?></span>
                </label>
            <?php endif; ?>

            <div class="form-actions-sticky flex justify-end gap-2 py-3 border-t">
                <a href="dashboard.php" class="bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium"><?= t('btn_cancel') ?></a>
                <button type="submit" class="inline-flex items-center gap-1 bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= icon('check', 'w-4 h-4') ?> <?= t('upg_btn_save') ?></button>
            </div>
        </form>
    </section>

    <!-- Riwayat upgrade -->
    <section class="bg-white rounded-2xl shadow-sm p-5">
        <h2 class="font-semibold text-slate-700 mb-3"><?= t('upg_history_title') ?></h2>
        <?= renderUpgradeHistoryCards($history, $savedId ?: null) ?>
    </section>
</div>

<script>
(function () {
    const FIELDS = <?= json_encode($fieldsForJs, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const START  = <?= json_encode(array_values($form['rows']), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const TXT = <?= json_encode([
        'otherName' => t('upg_ph_other_name'), 'otherBefore' => t('upg_ph_other_before'), 'newValue' => t('upg_ph_new_value'),
        'swName' => t('upg_ph_sw_name'), 'remove' => t('btn_delete'), 'original' => t('os_original'), 'notOriginal' => t('os_not_original'),
    ], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const cls = <?= json_encode($inputCls) ?>;
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const rows = document.getElementById('upgRows');

    function addRow(init) {
        init = init || {};
        const div = document.createElement('div');
        div.className = 'grid grid-cols-12 gap-2 items-start rounded-lg sm:rounded-none bg-slate-50 sm:bg-transparent p-2 sm:p-0';
        div.innerHTML = `
            <div class="col-span-12 sm:col-span-4 space-y-1">
                <select name="field[]" class="${cls}">${FIELDS.map((f) => `<option value="${f.key}">${esc(f.label)}</option>`).join('')}</select>
                <input name="label[]" maxlength="100" placeholder="${esc(TXT.otherName)}" class="${cls}">
            </div>
            <div class="col-span-12 sm:col-span-3 js-before"></div>
            <div class="col-span-10 sm:col-span-4 js-after"></div>
            <div class="col-span-2 sm:col-span-1 flex justify-end">
                <button type="button" class="js-del p-2 rounded-lg text-slate-400 hover:bg-red-50 hover:text-red-600" title="${esc(TXT.remove)}" aria-label="${esc(TXT.remove)}">&#x2715;</button>
            </div>`;
        rows.appendChild(div);
        const sel = div.querySelector('select[name="field[]"]');
        const label = div.querySelector('[name="label[]"]');
        const beforeBox = div.querySelector('.js-before');
        const afterBox = div.querySelector('.js-after');
        if (init.key && FIELDS.some((f) => f.key === init.key)) sel.value = init.key;

        const sync = (first) => {
            const f = FIELDS.find((x) => x.key === sel.value);
            const isOther = f.key === '__other', isSw = f.key === '__software';
            label.style.display = isOther ? '' : 'none';
            if (!isOther) label.value = ''; else if (first) label.value = init.label || '';
            // Kolom "Sebelum": nilai aset (baca saja), isian bebas untuk "Lainnya", status lisensi untuk software
            if (isSw) {
                const st = first ? (init.sw_status || 'Original') : 'Original';
                beforeBox.innerHTML = `<select name="sw_status[]" class="${cls}"><option value="Original" ${st === 'Original' ? 'selected' : ''}>${esc(TXT.original)}</option><option value="Belum Original" ${st !== 'Original' ? 'selected' : ''}>${esc(TXT.notOriginal)}</option></select><input type="hidden" name="before_other[]" value="">`;
            } else if (isOther) {
                beforeBox.innerHTML = `<input name="before_other[]" maxlength="150" placeholder="${esc(TXT.otherBefore)}" value="${esc(first ? init.before || '' : '')}" class="${cls}"><input type="hidden" name="sw_status[]" value="">`;
            } else {
                beforeBox.innerHTML = `<input value="${esc(f.beforeLabel || '-')}" readonly tabindex="-1" class="${cls} bg-slate-50 text-slate-500"><input type="hidden" name="before_other[]" value=""><input type="hidden" name="sw_status[]" value="">`;
            }
            const prev = first ? init.after || '' : '';
            afterBox.innerHTML = f.options
                ? `<select name="after[]" class="${cls}">${Object.entries(f.options).map(([v, l]) => `<option value="${esc(v)}" ${v === (prev || Object.keys(f.options)[0]) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`
                : `<input name="after[]" maxlength="150" value="${esc(prev)}" placeholder="${esc(isSw ? TXT.swName : TXT.newValue)}" class="${cls}">`;
        };
        sel.addEventListener('change', () => sync(false));
        sync(true);
        div.querySelector('.js-del').addEventListener('click', () => { if (rows.children.length > 1) div.remove(); });
    }
    START.forEach(addRow);
    document.getElementById('upgAddRow').addEventListener('click', () => addRow({ key: 'storage' }));
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
