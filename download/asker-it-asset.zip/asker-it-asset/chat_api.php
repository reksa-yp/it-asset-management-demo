<?php
/**
 * API Chat Grup (dipanggil dari chat.php dan pengecek notifikasi di footer). Selalu membalas JSON,
 * kecuali a=key (unduh cadangan kunci enkripsi, khusus admin).
 */
require_once __DIR__ . '/includes/auth.php';
if (empty($_SESSION['user_id'])) { http_response_code(401); header('Content-Type: application/json'); echo '{"ok":false,"error":"login"}'; exit; }
require_once __DIR__ . '/includes/chat.php';

$db  = getDB();
$uid = (int)$_SESSION['user_id'];
$a   = (string)($_GET['a'] ?? $_POST['a'] ?? '');

function chatOut(array $d): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($d, JSON_UNESCAPED_UNICODE);
    exit;
}
function chatFail(string $msg): void { chatOut(['ok' => false, 'error' => $msg]); }

try {
    ensureChatTables($db);
    chatCleanup($db);
    $users = chatUsers($db);
    if (!isset($users[$uid])) chatFail(chL('Akun Anda tidak aktif.', 'Your account is inactive.'));
    $myGroups = chatMyGroups($db, $uid);

    // Grup yang diminta harus grup yang diikuti user.
    $needGroup = function (int $gid) use ($myGroups): array {
        if (!isset($myGroups[$gid])) chatFail(chL('Anda bukan anggota grup ini.', 'You are not a member of this group.'));
        return $myGroups[$gid];
    };
    // Kutipan pesan yang dibalas (nama + potongan teks), supaya tetap tampil walau pesan aslinya belum dimuat.
    $withQuotes = function (array $rows) use ($db, $users, $uid): array {
        $out = [];
        $q = $db->prepare("SELECT * FROM chat_messages WHERE id = ?");
        foreach ($rows as $m) {
            $o = chatMessageOut($db, $m, $users);
            if ($o['reply']) {
                $q->execute([$o['reply']]);
                $r = $q->fetch();
                $o['rq'] = $r ? ['name' => (int)$r['user_id'] === $uid ? chL('Anda', 'You') : ((int)$r['user_id'] === 0 ? 'IT System' : ($users[(int)$r['user_id']]['name'] ?? '?')),
                                 'text' => preg_replace('/^[^:]+:\s/u', '', chatSnippet($db, $r, $uid, $users))] : null;
            }
            $out[] = $o;
        }
        return $out;
    };

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if ($a === 'unread') {
            // Untuk angka di menu & notifikasi (footer.php): total belum dibaca + pesan baru setelah $since.
            $sum = chatSummary($db, $uid);
            $since = (int)($_GET['since'] ?? 0);
            $new = []; $max = 0;
            foreach ($sum as $g) $max = max($max, $g['last_id']);
            if ($since > 0 && $max > $since && $myGroups) {
                $in = implode(',', array_map('intval', array_keys($myGroups)));
                $st = $db->prepare("SELECT * FROM chat_messages WHERE id > ? AND group_id IN ($in) AND user_id <> ? AND deleted_by IS NULL AND kind = 'msg' ORDER BY id DESC LIMIT 5");
                $st->execute([$since, $uid]);
                foreach (array_reverse($st->fetchAll()) as $m) {
                    $new[] = ['id' => (int)$m['id'], 'g' => (int)$m['group_id'], 'group' => (string)$myGroups[(int)$m['group_id']]['name'],
                              'text' => chatSnippet($db, $m, $uid, $users), 'mention' => strpos((string)$m['mentions'], ',' . $uid . ',') !== false];
                }
            }
            chatOut(['ok' => true, 'total' => array_sum(array_column($sum, 'unread')), 'max_id' => $max, 'new' => $new]);
        }

        if ($a === 'poll' || $a === 'older') {
            $gid = (int)($_GET['g'] ?? 0);
            $res = ['ok' => true];
            if ($a === 'poll') $res['groups'] = chatSummary($db, $uid);
            if ($gid && isset($myGroups[$gid])) {
                $g = $myGroups[$gid];
                if ($a === 'older') {
                    $st = $db->prepare("SELECT * FROM (SELECT * FROM chat_messages WHERE group_id = ? AND id < ? ORDER BY id DESC LIMIT 60) x ORDER BY id");
                    $st->execute([$gid, (int)($_GET['before'] ?? 0)]);
                    chatOut(['ok' => true, 'messages' => $withQuotes($st->fetchAll())]);
                }
                $after = (int)($_GET['after'] ?? 0);
                if ($after > 0) {
                    $st = $db->prepare("SELECT * FROM chat_messages WHERE group_id = ? AND id > ? ORDER BY id LIMIT 200");
                    $st->execute([$gid, $after]);
                } else {
                    $st = $db->prepare("SELECT * FROM (SELECT * FROM chat_messages WHERE group_id = ? ORDER BY id DESC LIMIT 60) x ORDER BY id");
                    $st->execute([$gid]);
                }
                $msgs = $withQuotes($st->fetchAll());
                $from = (int)($_GET['from'] ?? 0);
                $del = $db->prepare("SELECT id FROM chat_messages WHERE group_id = ? AND id >= ? AND deleted_by IS NOT NULL");
                $del->execute([$gid, $from]);
                $members = chatMemberIds($db, $g);
                $reads = [];
                $rs = $db->prepare("SELECT user_id, last_read_id FROM chat_reads WHERE group_id = ?");
                $rs->execute([$gid]);
                foreach ($rs->fetchAll() as $r) if (in_array((int)$r['user_id'], $members, true)) $reads[(int)$r['user_id']] = (int)$r['last_read_id'];
                $pin = null;
                if ($g['pinned_msg_id']) {
                    $ps = $db->prepare("SELECT * FROM chat_messages WHERE id = ? AND group_id = ? AND deleted_by IS NULL");
                    $ps->execute([(int)$g['pinned_msg_id'], $gid]);
                    if ($pr = $ps->fetch()) $pin = ['id' => (int)$pr['id'], 'text' => preg_replace('/^[^:]+:\s/u', '', chatSnippet($db, $pr, $uid, $users))];
                }
                // Tandai sudah dibaca (hanya saat halaman chat sedang dilihat).
                $maxId = $msgs ? end($msgs)['id'] : 0;
                if (($_GET['seen'] ?? '') === '1' && $maxId) { chatMarkRead($db, $gid, $uid, $maxId); $reads[$uid] = max($reads[$uid] ?? 0, $maxId); }
                $res['group'] = [
                    'id' => $gid, 'name' => (string)$g['name'], 'color' => CHAT_COLORS[(int)$g['color'] % count(CHAT_COLORS)],
                    'all' => (int)$g['is_all'] === 1, 'announce' => (int)$g['is_announce'] === 1, 'can_write' => chatCanWrite($g),
                    'members' => array_map(fn($id) => ['id' => $id, 'name' => $users[$id]['name'], 'dept' => $users[$id]['dept']], $members),
                    'pinned' => $pin,
                ];
                $res['messages'] = $msgs;
                $res['deleted'] = array_map('intval', $del->fetchAll(PDO::FETCH_COLUMN));
                $res['reads'] = (object)$reads;
            }
            chatOut($res);
        }

        if ($a === 'share_search') {
            // Bagikan tiket / aset: user hanya tiketnya sendiri; admin semua tiket & aset.
            $q = trim((string)($_GET['q'] ?? ''));
            $like = '%' . $q . '%';
            $out = [];
            $sql = "SELECT t.id, t.ticket_number, t.problem_detail, t.status, u.full_name FROM tickets t JOIN users u ON u.id = t.reported_by WHERE (t.ticket_number LIKE ? OR t.problem_detail LIKE ?)"
                 . (isAdmin() ? '' : ' AND t.reported_by = ' . $uid) . " ORDER BY t.id DESC LIMIT 8";
            $st = $db->prepare($sql); $st->execute([$like, $like]);
            foreach ($st->fetchAll() as $t) $out[] = ['type' => 'tiket', 'id' => (int)$t['id'], 'ref' => $t['ticket_number'], 'title' => mb_strimwidth((string)$t['problem_detail'], 0, 70, '…'), 'sub' => $t['full_name'] . ' · ' . $t['status']];
            if (isAdmin()) {
                $st = $db->prepare("SELECT id, asset_number, device_name, category, location FROM assets WHERE asset_number LIKE ? OR device_name LIKE ? OR location LIKE ? ORDER BY asset_number LIMIT 8");
                $st->execute([$like, $like, $like]);
                foreach ($st->fetchAll() as $s) $out[] = ['type' => 'aset', 'id' => (int)$s['id'], 'ref' => $s['asset_number'], 'title' => ($s['device_name'] ?: $s['category']), 'sub' => trim($s['category'] . ' · ' . $s['location'], ' ·')];
            }
            chatOut(['ok' => true, 'items' => $out]);
        }

        if ($a === 'admin') {
            if (!isAdmin()) chatFail('403');
            $groups = [];
            foreach (chatGroups($db) as $g) {
                $st = $db->prepare("SELECT user_id FROM chat_members WHERE group_id = ?"); $st->execute([(int)$g['id']]);
                $groups[] = ['id' => (int)$g['id'], 'name' => (string)$g['name'], 'all' => (int)$g['is_all'] === 1, 'announce' => (int)$g['is_announce'] === 1,
                             'members' => array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN))];
            }
            chatOut(['ok' => true, 'groups' => $groups, 'users' => array_values($users), 'settings' => chatSettings(), 'stats' => chatStats($db),
                     'key_ok' => is_file(CHAT_KEY_FILE)]);
        }

        if ($a === 'key') {
            if (!isAdmin()) { http_response_code(403); exit('403'); }
            chatKey($db);
            chatSaveSettings(['key_backup_at' => date('Y-m-d H:i:s')]);
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="chat_key.php"');
            header('Cache-Control: no-store');
            readfile(CHAT_KEY_FILE);
            exit;
        }
        chatFail('?');
    }

    // ---------------- POST ----------------
    csrfCheck();

    if ($a === 'send') {
        $gid = (int)($_POST['g'] ?? 0);
        $g = $needGroup($gid);
        if (!chatCanWrite($g)) chatFail(chL('Grup pengumuman: hanya admin yang dapat mengirim pesan.', 'Announcement group: only admins can post.'));
        $text = trim(str_replace("\r\n", "\n", (string)($_POST['text'] ?? '')));
        if (mb_strlen($text) > 4000) $text = mb_substr($text, 0, 4000);
        $reply = (int)($_POST['reply'] ?? 0);
        if ($reply) { $chk = $db->prepare("SELECT 1 FROM chat_messages WHERE id = ? AND group_id = ?"); $chk->execute([$reply, $gid]); if (!$chk->fetchColumn()) $reply = 0; }
        $card = null;
        $stype = (string)($_POST['share_type'] ?? ''); $sid = (int)($_POST['share_id'] ?? 0);
        if ($stype === 'tiket' && $sid) {
            $st = $db->prepare("SELECT t.ticket_number, t.problem_detail, t.status, t.reported_by, u.full_name FROM tickets t JOIN users u ON u.id = t.reported_by WHERE t.id = ?");
            $st->execute([$sid]);
            if (($t = $st->fetch()) && (isAdmin() || (int)$t['reported_by'] === $uid))
                $card = ['type' => 'tiket', 'ref' => $t['ticket_number'], 'title' => mb_strimwidth((string)$t['problem_detail'], 0, 90, '…'), 'sub' => $t['full_name'] . ' · ' . $t['status'], 'url' => 'tickets.php?q=' . rawurlencode($t['ticket_number'])];
        } elseif ($stype === 'aset' && $sid && isAdmin()) {
            $st = $db->prepare("SELECT asset_number, device_name, category, location FROM assets WHERE id = ?");
            $st->execute([$sid]);
            if ($s = $st->fetch())
                $card = ['type' => 'aset', 'ref' => $s['asset_number'], 'title' => (string)($s['device_name'] ?: $s['category']), 'sub' => trim($s['category'] . ' · ' . $s['location'], ' ·'), 'url' => 'assets.php?q=' . rawurlencode($s['asset_number'])];
        }
        $photo = null;
        if (!empty($_FILES['photo']) && ($_FILES['photo']['error'] ?? 4) === UPLOAD_ERR_OK && is_uploaded_file($_FILES['photo']['tmp_name'])) {
            if ($_FILES['photo']['size'] > CHAT_PHOTO_MAX) chatFail(chL('Foto terlalu besar (maks. 8 MB).', 'Photo too large (max 8 MB).'));
            $photo = chatStorePhotoBytes($db, (string)file_get_contents($_FILES['photo']['tmp_name']), (int)($_POST['orig'] ?? 0));
            if (!$photo) chatFail(chL('File bukan foto JPG/PNG/WebP yang valid.', 'Not a valid JPG/PNG/WebP photo.'));
        }
        if ($text === '' && !$card && !$photo) chatFail(chL('Pesan kosong.', 'Empty message.'));
        $id = chatPost($db, $gid, $uid, $text, $card, $photo, $reply);
        chatOut(['ok' => true, 'id' => $id]);
    }

    if ($a === 'read') {
        $gid = (int)($_POST['g'] ?? 0); $needGroup($gid);
        chatMarkRead($db, $gid, $uid, (int)($_POST['id'] ?? 0));
        chatOut(['ok' => true]);
    }

    if ($a === 'delete') {
        $st = $db->prepare("SELECT * FROM chat_messages WHERE id = ?");
        $st->execute([(int)($_POST['id'] ?? 0)]);
        $m = $st->fetch();
        if (!$m || $m['deleted_by']) chatFail(chL('Pesan tidak ditemukan.', 'Message not found.'));
        $needGroup((int)$m['group_id']);
        $own = (int)$m['user_id'] === $uid;
        if (!isAdmin() && !($own && time() - strtotime((string)$m['created_at']) <= CHAT_DELETE_WINDOW))
            chatFail(chL('Pesan hanya bisa dihapus pengirimnya dalam 1 jam, atau oleh admin.', 'Only the sender within 1 hour, or an admin, can delete this.'));
        if ($m['photo_path']) { $f = CHAT_PHOTO_DIR . '/' . $m['photo_path']; if (strpos((string)$m['photo_path'], '..') === false && is_file($f)) @unlink($f); }
        $db->prepare("UPDATE chat_messages SET deleted_by = ?, deleted_at = ?, body = NULL, photo_path = NULL, mentions = NULL WHERE id = ?")->execute([$uid, date('Y-m-d H:i:s'), (int)$m['id']]);
        $db->prepare("UPDATE chat_groups SET pinned_msg_id = NULL WHERE pinned_msg_id = ?")->execute([(int)$m['id']]);
        chatOut(['ok' => true]);
    }

    // ---------- khusus admin ----------
    if (!isAdmin()) chatFail('403');

    if ($a === 'pin') {
        $gid = (int)($_POST['g'] ?? 0); $needGroup($gid);
        $mid = (int)($_POST['id'] ?? 0);
        $db->prepare("UPDATE chat_groups SET pinned_msg_id = ? WHERE id = ?")->execute([$mid ?: null, $gid]);
        chatOut(['ok' => true]);
    }

    if ($a === 'save_group') {
        $id = (int)($_POST['id'] ?? 0);
        $name = mb_substr(trim((string)($_POST['name'] ?? '')), 0, 100);
        if ($name === '') chatFail(chL('Nama grup wajib diisi.', 'Group name is required.'));
        $all = !empty($_POST['is_all']) ? 1 : 0; $ann = !empty($_POST['is_announce']) ? 1 : 0;
        $mem = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['members'] ?? [])), fn($x) => isset($users[$x]))));
        if (!$all && !in_array($uid, $mem, true)) $mem[] = $uid;   // pembuat/pengubah grup tetap jadi anggota
        $db->beginTransaction();
        if ($id) {
            $db->prepare("UPDATE chat_groups SET name = ?, is_all = ?, is_announce = ? WHERE id = ?")->execute([$name, $all, $ann, $id]);
        } else {
            $n = (int)$db->query("SELECT COUNT(*) FROM chat_groups")->fetchColumn();
            $db->prepare("INSERT INTO chat_groups (name, color, is_all, is_announce, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)")->execute([$name, $n % count(CHAT_COLORS), $all, $ann, $uid, date('Y-m-d H:i:s')]);
            $id = (int)$db->lastInsertId();
        }
        $db->prepare("DELETE FROM chat_members WHERE group_id = ?")->execute([$id]);
        $ins = $db->prepare("INSERT INTO chat_members (group_id, user_id) VALUES (?, ?)");
        foreach ($mem as $m) $ins->execute([$id, $m]);
        $db->commit();
        chatOut(['ok' => true, 'id' => $id]);
    }

    if ($a === 'delete_group') {
        $id = (int)($_POST['id'] ?? 0);
        $st = $db->prepare("SELECT photo_path FROM chat_messages WHERE group_id = ? AND photo_path IS NOT NULL");
        $st->execute([$id]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $p) { $f = CHAT_PHOTO_DIR . '/' . $p; if (strpos($p, '..') === false && is_file($f)) @unlink($f); }
        foreach (['chat_messages', 'chat_members', 'chat_reads'] as $t) $db->prepare("DELETE FROM $t WHERE group_id = ?")->execute([$id]);
        $db->prepare("DELETE FROM chat_groups WHERE id = ?")->execute([$id]);
        if ((int)chatSettings()['cctv_group'] === $id) chatSaveSettings(['cctv_group' => 0]);
        chatOut(['ok' => true]);
    }

    if ($a === 'settings') {
        $ret = (int)($_POST['retention'] ?? 90);
        chatSaveSettings(['retention' => in_array($ret, [30, 60, 90, 180, 365], true) ? $ret : 90, 'cctv_group' => (int)($_POST['cctv_group'] ?? 0)]);
        chatOut(['ok' => true]);
    }

    chatFail('?');
} catch (Throwable $e) {
    if ($db->inTransaction()) $db->rollBack();
    chatFail($e->getMessage());
}
