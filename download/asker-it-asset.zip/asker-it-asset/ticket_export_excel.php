<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/vendor/autoload.php'; // composer require phpoffice/phpspreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

$db = getDB();

// Filter "Ditangani Oleh" (handled_by), sama seperti filter di menu Ticketing:
// '' = semua, 'none' = belum ditangani, angka = id admin/IT tertentu. Dipakai
// supaya bisa export khusus per admin yang menangani.
$filterHandledBy = trim($_GET['handled_by'] ?? '');
$filenameSuffix = '';

$conditions = [];
$params = [];
if ($filterHandledBy === 'none') {
    $conditions[] = 't.handled_by IS NULL';
    $filenameSuffix = '_belum_ditangani';
} elseif ($filterHandledBy !== '') {
    $conditions[] = 't.handled_by = ?';
    $params[] = (int)$filterHandledBy;
    $handlerName = $db->prepare("SELECT full_name FROM users WHERE id = ?");
    $handlerName->execute([(int)$filterHandledBy]);
    $hName = $handlerName->fetchColumn();
    if ($hName) {
        $filenameSuffix = '_' . preg_replace('/[^A-Za-z0-9]+/', '_', $hName);
    }
}

// Filter periode tanggal (berdasarkan tanggal dibuat tiket), sama seperti
// filter di menu Ticketing. Bebas diisi salah satu atau keduanya.
$filterDateFrom = trim($_GET['date_from'] ?? '');
$filterDateTo   = trim($_GET['date_to'] ?? '');
$filterDateFrom = preg_match('/^\d{4}-\d{2}-\d{2}$/', $filterDateFrom) ? $filterDateFrom : '';
$filterDateTo   = preg_match('/^\d{4}-\d{2}-\d{2}$/', $filterDateTo) ? $filterDateTo : '';
if ($filterDateFrom !== '') {
    $conditions[] = 'DATE(t.created_at) >= ?';
    $params[] = $filterDateFrom;
    $filenameSuffix .= '_dari' . str_replace('-', '', $filterDateFrom);
}
if ($filterDateTo !== '') {
    $conditions[] = 'DATE(t.created_at) <= ?';
    $params[] = $filterDateTo;
    $filenameSuffix .= '_sd' . str_replace('-', '', $filterDateTo);
}
$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';

// Ambil tiket (sesuai filter) + relasi pelapor, aset, yang menangani, dan
// detail pengerjaan/pengecekan aset (diisi admin lewat tombol "Isi Detail
// Pengerjaan" di menu Ticketing).
$stmt = $db->prepare("
    SELECT t.*, u.full_name AS pelapor, a.asset_number, h.full_name AS handler,
           wd.work_detail AS work_detail, wd.asset_check AS asset_check
    FROM tickets t
    JOIN users u ON u.id = t.reported_by
    LEFT JOIN assets a ON a.id = t.asset_id
    LEFT JOIN users h ON h.id = t.handled_by
    LEFT JOIN ticket_work_details wd ON wd.ticket_id = t.id
    $where
    ORDER BY FIELD(t.status,'Menunggu','Proses','Selesai'), t.created_at DESC
");
$stmt->execute($params);
$tickets = applyTicketCancellations($db, $stmt->fetchAll());

// Label status tiket mengikuti bahasa aktif user
$statusLabel = [
    'Menunggu' => t('ticket_status_waiting'),
    'Proses'   => t('ticket_status_process'),
    'Selesai'  => t('ticket_status_done'),
    'Dibatalkan' => t('ticket_status_cancelled'),
];

$headers = [
    t('xls_hdr_ticket_no'), t('xls_hdr_reporter'), t('xls_hdr_related_asset'), t('xls_hdr_problem_detail'),
    t('xls_hdr_work_detail'), t('xls_hdr_asset_check'), // diisi admin lewat tombol "Isi Detail Pengerjaan"
    t('xls_hdr_status'), t('xls_hdr_handled_by'), t('xls_hdr_created_at'), t('xls_hdr_updated_at'), t('xls_hdr_resolved_at'),
];

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Ticketing IT');

// Tulis header (baris 1)
$sheet->fromArray($headers, null, 'A1');

// Susun data jadi array 2 dimensi dulu, baru tulis sekaligus. Status mentah
// (bahasa Indonesia, untuk pewarnaan baris) disimpan terpisah karena kolom
// "Status" di $dataRows sudah memakai teks terjemahan.
$dataRows = [];
$rawStatuses = [];
foreach ($tickets as $t) {
    $rawStatuses[] = $t['status'];
    $dataRows[] = [
        $t['ticket_number'],
        $t['pelapor'],
        $t['asset_number'] ?? '-',
        $t['problem_detail'],
        $t['work_detail'] ?: '-',
        $t['asset_check'] ?: '-',
        $statusLabel[$t['status']] ?? $t['status'],
        $t['handler'] ?? '-',
        date('Y-m-d H:i', strtotime($t['created_at'])),
        date('Y-m-d H:i', strtotime($t['updated_at'])),
        $t['is_cancelled'] ? t('ticket_cancelled_at_xls', date('Y-m-d H:i', strtotime($t['cancelled_at']))) . ($t['cancel_reason'] ? ' — ' . $t['cancel_reason'] : '')
            : ($t['resolved_at'] ? date('Y-m-d H:i', strtotime($t['resolved_at'])) : '-'),
    ];
}

if ($dataRows) {
    $sheet->fromArray($dataRows, null, 'A2');
}

$lastCol = count($headers);
$lastRow = 1 + count($dataRows);

// ===== Styling: header bold + background biru, border seluruh tabel, auto-fit kolom =====
$headerRange = 'A1:' . Coordinate::stringFromColumnIndex($lastCol) . '1';
$sheet->getStyle($headerRange)->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
$sheet->getStyle($headerRange)->getFill()
      ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
$sheet->getStyle($headerRange)->getAlignment()->setHorizontal('center');

if ($lastRow >= 1) {
    $fullRange = 'A1:' . Coordinate::stringFromColumnIndex($lastCol) . $lastRow;
    $sheet->getStyle($fullRange)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
}

// Beri warna beda tiap status pada kolom "Status" (kolom G) supaya cepat dibaca
$statusColorMap = [
    'Menunggu' => 'F1F5F9', // abu-abu terang
    'Dibatalkan' => 'FEE2E2', // merah muda
    'Proses'   => 'FEF3C7', // kuning muda
    'Selesai'  => 'DCFCE7', // hijau muda
];
foreach ($dataRows as $i => $row) {
    $rowNum = $i + 2; // baris data dimulai dari row 2
    $statusVal = $rawStatuses[$i] ?? null;
    $color = $statusColorMap[$statusVal] ?? null;
    if ($color) {
        $sheet->getStyle('G' . $rowNum)->getFill()
              ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($color);
    }
}

// Bungkus teks panjang di kolom "Rincian Masalah", "Detail Pengerjaan", dan
// "Pengecekan Aset" (kolom D-F) agar tidak melebar
$sheet->getStyle('D2:F' . max($lastRow, 2))->getAlignment()->setWrapText(true);

// Auto-fit lebar kolom
for ($c = 1; $c <= $lastCol; $c++) {
    $colLetter = Coordinate::stringFromColumnIndex($c);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}
$sheet->freezePane('A2');

// Kolom No di paling kiri (dipanggil terakhir supaya gaya & huruf kolom di atas tidak perlu diubah).
require_once __DIR__ . '/includes/xls_number.php';
xlsAddNumberColumn($sheet, 1, $lastRow);
require_once __DIR__ . '/includes/letterhead.php';
xlsAddTitleBlock($sheet, 1, xlsL('Data Tiket IT ', 'IT Ticket Data ') . xlsCompanyName(),
    [documentCreatedAt(), xlsCountLine('Jumlah tiket', 'Total tickets', count($dataRows))]);

// ===== Output =====
$filename = 'ticketing_it_export' . $filenameSuffix . '_' . date('Ymd_His') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
