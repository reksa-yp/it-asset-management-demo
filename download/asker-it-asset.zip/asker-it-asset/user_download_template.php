<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/vendor/autoload.php'; // composer require phpoffice/phpspreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

// ===== Header HARUS PERSIS sama dengan yang dibaca user_import_process.php =====
$headers = ['Nama Lengkap', 'Username', 'Email', 'Departement', 'Jabatan', 'Password', 'Username PC', 'Password PC', 'Role', 'Status'];

// Contoh baris, sekadar panduan pengisian (boleh dihapus sebelum upload)
$example = [
    'Budi Santoso',
    'budi.santoso',
    'budi.santoso@example.com',
    'PPIC',
    'Staff',
    'password123',
    'budi.santoso.pc',
    'pcpassword123',
    'user',
    'Aktif',
];

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Template User');

$sheet->fromArray($headers, null, 'A1');
$sheet->fromArray([$example], null, 'A2');

$lastCol = count($headers);
$lastRow = 2;

// Styling header
$headerRange = 'A1:' . \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($lastCol) . '1';
$sheet->getStyle($headerRange)->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
$sheet->getStyle($headerRange)->getFill()
      ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
$sheet->getStyle($headerRange)->getAlignment()->setHorizontal('center');

$fullRange = 'A1:' . \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($lastCol) . $lastRow;
$sheet->getStyle($fullRange)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);

// Catatan panduan pengisian, ditaruh beberapa baris di bawah data
$sheet->setCellValue('A4', 'Keterangan:');
$sheet->setCellValue('A5', '- Username harus unik. Baris dengan Username yang sudah ada akan di-UPDATE, baris baru akan ditambahkan.');
$sheet->setCellValue('A6', '- Password wajib diisi untuk user baru. Untuk update user lama, kosongkan Password jika tidak ingin mengubahnya.');
$sheet->setCellValue('A7', '- Departement diisi sesuai departemen user (contoh: PPIC, IT, Finance, HR, dll.).');
$sheet->setCellValue('A8', '- Role diisi "admin" atau "user" (default "user" jika kosong/tidak valid).');
$sheet->setCellValue('A9', '- Status diisi "Aktif" atau "Nonaktif" (default "Aktif" jika kosong/tidak valid).');
$sheet->setCellValue('A10', '- Username PC & Password PC bersifat opsional, hanya data referensi login PC/laptop milik user (bukan login ke sistem ini).');
$sheet->setCellValue('A11', '- Jabatan boleh dikosongkan (contoh: Staff, Supervisor, Manager).');
$sheet->getStyle('A4')->getFont()->setBold(true);
foreach (range(4, 10) as $r) {
    $sheet->getStyle("A$r")->getFont()->setSize(9)->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color('FF64748B'));
}

// Auto-fit lebar kolom
for ($c = 1; $c <= $lastCol; $c++) {
    $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($c);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}
$sheet->freezePane('A2');

// ===== Output =====
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="template_user.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
