<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: request.php'); exit; }
csrfCheck();
$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
if (!$id || $id < 1) { $_SESSION['request_flash'] = ['type'=>'error','message'=>'Pengajuan tidak valid.']; header('Location: request.php'); exit; }
require_once __DIR__ . '/includes/request_feature.php';
$db = getDB(); ensureRequestTable($db);
if (isAdmin()) {
    $st = $db->prepare("UPDATE user_requests SET status='Dibatalkan' WHERE id=? AND status='Menunggu'");
    $st->execute([$id]);
} else {
    $st = $db->prepare("UPDATE user_requests SET status='Dibatalkan' WHERE id=? AND status='Menunggu' AND (user_id=? OR submitted_by_user_id=?)");
    $st->execute([$id, (int)$_SESSION['user_id'], (int)$_SESSION['user_id']]);
}
$_SESSION['request_flash'] = $st->rowCount() > 0
    ? ['type'=>'success','message'=>'Pengajuan berhasil dibatalkan.']
    : ['type'=>'error','message'=>'Pengajuan tidak dapat dibatalkan. Hanya pengajuan berstatus Menunggu yang dapat dibatalkan.'];
header('Location: request.php'); exit;
