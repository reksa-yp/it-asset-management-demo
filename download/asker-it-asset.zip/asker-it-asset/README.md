# ASKER IT Asset

Aplikasi web manajemen aset IT dan helpdesk untuk kantor: inventaris aset, ticketing, stok barang, mutasi aset, dan export audit dalam satu sistem. Dibuat dengan PHP dan MySQL, jalan di XAMPP atau server kantor sendiri.

*Open-source IT asset management and helpdesk web app (PHP + MySQL). The interface is available in Indonesian and English.*

![Dashboard](docs/screenshots/dashboard.png)

## Fitur

| Menu | Kegunaan |
|---|---|
| **Dashboard** | Jumlah aset, antrian tiket, perbaikan selesai hari ini, dan peringatan stok |
| **Aset** | Data aset lengkap (pengguna, departemen, lokasi, spesifikasi, software, aksesoris), nomor aset otomatis, cetak label, detail PDF |
| **Ticketing IT** | User membuat tiket keluhan; admin mendapat notifikasi, mengubah status, dan mengisi detail pengerjaan. Riwayat update tercatat |
| **Stok Barang** | Barang masuk dan keluar, rekap per kategori dan per user, peringatan restock |
| **Mutasi Aset** | Serah terima dan pemindahan aset dengan berita acara siap cetak |
| **Aset Rusak** | Pencatatan aset rusak, perbaikan, dan penghapusan |
| **Export Audit** | Pilih sendiri data dan kolom yang diminta auditor, lalu export ke Excel |
| **Ganti Password PC** | Membuat password baru yang berbeda untuk tiap PC/laptop, dengan daftar kerja Excel |
| **Signature Email** | User membuat gambar signature email; logo, telepon, dan alamat perusahaan diatur admin, warna mengikuti logo |
| **Management User** | Akun admin dan user, departemen, jabatan, import/export Excel |
| **Kop Surat** | Logo, ornamen, nama dan alamat perusahaan untuk kop di semua dokumen cetak, PDF, dan file Excel; diatur admin |
| **CCTV** 🆕 | Monitoring NVR Hikvision/Dahua realtime dengan **live preview & video dari RTSP sub-stream**, pop-up jika kamera mati ≥ 10 menit, email jika ≥ 30 menit, checklist digital Pagi & Sore (hari libur bisa diatur), laporan petugas, List View dengan snapshot kamera, import CCTV/NVR dari Excel, rekap bulanan Excel per NVR |
| **Ext Telepon** | Daftar nomor extension kantor untuk admin dan user, cetak/PDF/Excel |

Lainnya: tampilan menyesuaikan layar HP dan laptop, dua bahasa (Indonesia/English), import dan export Excel untuk aset dan user, nama sistem dan logo bisa diganti di Pengaturan Sistem.

Tambahan di versi ini:

- **Scan QR aset**: QR pada label berisi alamat detail aset, jadi bisa dipindai dengan kamera HP atau scanner USB. Tombol Scan QR ada di Dashboard dan menu Aset.
- **Filter Lokasi** pada daftar aset, dan export Excel mengikuti filter yang aktif.
- **Semua file Excel** (export dan template import) memakai susunan yang sama: logo, judul otomatis, tanggal dibuat, jumlah data, lalu tabel dengan kolom No. Judul kolom ada di baris 8 dan data mulai baris 9. Import mengenali susunan baru maupun file lama.
- **Dokumen cetak dan PDF** memakai kop surat di setiap halaman, dengan keterangan "Dibuat pada" (jam 24 jam, zona waktu bisa dipilih).
- **Tombol VNC** di samping IP aset untuk membuka TightVNC Viewer dari PC admin. Butuh pemasangan sekali di PC admin, lihat `tools/tombol-vnc/PANDUAN.txt`.
- **Label aset** untuk Ext Telepon, Printer, Monitor, dan Aksesoris hanya memuat ID, pengguna, dan lokasi.
- **Menu CCTV** (baru): status kamera dibaca langsung dari NVR (Hikvision ISAPI / Dahua) atau lewat IP kamera, log CCTV mati, pop-up web dan email (setelah kamera mati 30 menit, bisa diubah), checklist digital per shift pengganti form kertas, user khusus CCTV (mis. Security) untuk checklist & lapor kamera mati, snapshot kamera untuk laporan List View, dan Export Excel rekap bulanan per NVR (cover multi-view, rekap 1 lembar A4, log CCTV mati). Panduan lengkap: `PANDUAN_CCTV.md`.
- **Akses tambahan user**: Tablet (QME) dan Checklist CCTV, dicentang di Management User.
- **Live preview CCTV**: thumbnail tiap kamera dan video "Lihat live" diambil dari RTSP sub-stream NVR memakai ffmpeg di server (tanpa plugin browser / Internet Explorer). Pasang ffmpeg sekali, lalu klik **Tes RTSP** di CCTV → Pengaturan → 1.
- **Log CCTV mati** bisa difilter per NVR dan dihapus sebagian/semua; Nama CCTV tampil di semua halaman dan email.

| Aset | Ticketing IT |
|---|---|
| ![Aset](docs/screenshots/aset.png) | ![Ticketing](docs/screenshots/ticketing.png) |

| Stok Barang | Signature Email |
|---|---|
| ![Stok](docs/screenshots/stok.png) | ![Signature Email](docs/screenshots/signature-email.png) |

Data pada tangkapan layar adalah data contoh.

## Kebutuhan

- PHP 8.0 atau lebih baru, dengan ekstensi `pdo_mysql`, `mbstring`, `gd`, `zip`
- MySQL atau MariaDB
- Web server (Apache pada XAMPP sudah cukup)

Folder `vendor/` (PhpSpreadsheet dan Dompdf) sudah disertakan, jadi tidak perlu menjalankan `composer install`.

## Instalasi

1. Unduh repository ini (tombol **Code → Download ZIP**) dan ekstrak ke `htdocs`, misalnya `C:\xampp\htdocs\asker-it-asset`.
2. Jalankan Apache dan MySQL.
3. Buka `http://localhost/asker-it-asset/`. Anda otomatis diarahkan ke halaman instalasi.
4. Isi data database, nama sistem, awalan nomor aset, dan akun admin pertama, lalu klik **Instal sekarang**.
5. Login, lalu hapus file `install.php` dari server.
6. (Opsional, untuk menu CCTV) Tambahkan kategori aset **CCTV** dan **NVR**, lalu klik kanan `scripts\pasang_jadwal_cctv.bat` → **Run as administrator** agar status CCTV dicek otomatis tiap 1 menit (Windows Task Scheduler).

Panduan lengkap ada di [PANDUAN_INSTALASI.md](PANDUAN_INSTALASI.md).

## Panduan penggunaan

Fungsi setiap menu dan cara menggunakannya dijelaskan di [PANDUAN_PENGGUNAAN.pdf](PANDUAN_PENGGUNAAN.pdf) (25 halaman, bergambar).

## Catatan keamanan

- Aplikasi ini dirancang untuk **jaringan internal kantor**. Jangan dibuka langsung ke internet tanpa pengamanan tambahan (HTTPS, pembatasan akses).
- Password login aplikasi disimpan dalam bentuk hash. **Username dan password PC** pada data aset disimpan sebagai teks biasa karena dipakai sebagai data referensi IT; hanya admin yang bisa melihatnya. Pertimbangkan hal ini sebelum mengisinya.
- Setelah instalasi, `config/database.php` berisi kredensial database Anda. Jangan mengunggah file itu, isi folder `includes/data/`, atau `assets/uploads/` dari server yang sudah dipakai ke repository publik.

## Kontribusi

Laporan bug dan usulan fitur bisa dikirim lewat menu **Issues**. Pull request dipersilakan.

## Lisensi

[MIT](LICENSE) © 2026 ASKER. Pustaka di folder `vendor/` memakai lisensinya masing-masing.
