# ASKER IT Asset

Aplikasi web manajemen aset IT dan helpdesk untuk kantor: inventaris aset, ticketing, stok barang, mutasi aset, dan export audit dalam satu sistem. Dibuat dengan PHP dan MySQL, jalan di XAMPP atau server kantor sendiri.

*Open-source IT asset management and helpdesk web app (PHP + MySQL). The interface is available in Indonesian and English.*

![Dashboard](docs/screenshots/dashboard.png)

## Fitur

| Menu | Kegunaan |
|---|---|
| **Dashboard** | Jumlah aset, antrian tiket, perbaikan selesai hari ini, dan peringatan stok |
| **Aset** | Data aset lengkap (pengguna, departemen, lokasi, spesifikasi, software, aksesoris), nomor aset otomatis, cetak label, detail PDF |
| **Ticketing IT** | User membuat tiket keluhan; admin mendapat notifikasi, mengubah status, dan mengisi detail pengerjaan. Riwayat update tercatat |
| **Stok Barang** | Barang masuk dan keluar, rekap per kategori dan per user, peringatan restock |
| **Mutasi Aset** | Serah terima dan pemindahan aset dengan berita acara siap cetak |
| **Aset Rusak** | Pencatatan aset rusak, perbaikan, dan penghapusan |
| **Export Audit** | Pilih sendiri data dan kolom yang diminta auditor, lalu export ke Excel |
| **Ganti Password PC** | Membuat password baru yang berbeda untuk tiap PC/laptop, dengan daftar kerja Excel |
| **Signature Email** | User membuat gambar signature email; logo, telepon, dan alamat perusahaan diatur admin, warna mengikuti logo |
| **Management User** | Akun admin dan user, departemen, jabatan, import/export Excel |

Lainnya: tampilan menyesuaikan layar HP dan laptop, dua bahasa (Indonesia/English), import dan export Excel untuk aset dan user, nama sistem dan logo bisa diganti di Pengaturan Sistem.

| Aset | Ticketing IT |
|---|---|
| ![Aset](docs/screenshots/aset.png) | ![Ticketing](docs/screenshots/ticketing.png) |

| Stok Barang | Signature Email |
|---|---|
| ![Stok](docs/screenshots/stok.png) | ![Signature Email](docs/screenshots/signature-email.png) |

Data pada tangkapan layar adalah data contoh.

## Kebutuhan

- PHP 8.0 atau lebih baru, dengan ekstensi `pdo_mysql`, `mbstring`, `gd`, `zip`
- MySQL atau MariaDB
- Web server (Apache pada XAMPP sudah cukup)

Folder `vendor/` (PhpSpreadsheet dan Dompdf) sudah disertakan, jadi tidak perlu menjalankan `composer install`.

## Instalasi

1. Unduh repository ini (tombol **Code → Download ZIP**) dan ekstrak ke `htdocs`, misalnya `C:\xampp\htdocs\asker-it-asset`.
2. Jalankan Apache dan MySQL.
3. Buka `http://localhost/asker-it-asset/`. Anda otomatis diarahkan ke halaman instalasi.
4. Isi data database, nama sistem, awalan nomor aset, dan akun admin pertama, lalu klik **Instal sekarang**.
5. Login, lalu hapus file `install.php` dari server.

Panduan lengkap ada di [PANDUAN_INSTALASI.md](PANDUAN_INSTALASI.md).

## Catatan keamanan

- Aplikasi ini dirancang untuk **jaringan internal kantor**. Jangan dibuka langsung ke internet tanpa pengamanan tambahan (HTTPS, pembatasan akses).
- Password login aplikasi disimpan dalam bentuk hash. **Username dan password PC** pada data aset disimpan sebagai teks biasa karena dipakai sebagai data referensi IT; hanya admin yang bisa melihatnya. Pertimbangkan hal ini sebelum mengisinya.
- Setelah instalasi, `config/database.php` berisi kredensial database Anda. Jangan mengunggah file itu, isi folder `includes/data/`, atau `assets/uploads/` dari server yang sudah dipakai ke repository publik.

## Kontribusi

Laporan bug dan usulan fitur bisa dikirim lewat menu **Issues**. Pull request dipersilakan.

## Lisensi

[MIT](LICENSE) © 2026 ASKER. Pustaka di folder `vendor/` memakai lisensinya masing-masing.
