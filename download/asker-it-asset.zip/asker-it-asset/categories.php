<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/categories.php';

$db = getDB();

// Jumlah aset yang memakai tiap kategori, untuk info & supaya kategori yang
// masih dipakai tidak bisa dihapus sembarangan (dicegah juga di category_delete.php).
$usageRows = $db->query("SELECT category, COUNT(*) AS total FROM assets GROUP BY category")->fetchAll();
$usageMap = [];
foreach ($usageRows as $u) { $usageMap[$u['category']] = (int)$u['total']; }

$categoryList = getAssetCategories($db);

$catMsg = $_SESSION['category_msg'] ?? null;
unset($_SESSION['category_msg']);

$pageTitle = t('page_title_categories');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="flex flex-wrap justify-between items-center gap-2 mb-4">
    <p class="text-sm text-slate-500 max-w-xl"><?= t('categories_intro') ?></p>
    <button onclick="openCategoryModal()" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium shrink-0">
        <?= t('btn_add_category') ?>
    </button>
</div>

<?php if ($catMsg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $catMsg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>">
        <?= htmlspecialchars($catMsg['text']) ?>
    </div>
<?php endif; ?>

<div class="bg-white rounded-xl shadow-sm overflow-x-auto">
<table class="w-full text-sm">
    <thead class="bg-slate-50 text-slate-500 text-left">
        <tr>
            <th class="py-2 px-3"><?= t('th_category_name') ?></th>
            <th class="py-2 px-3"><?= t('th_category_abbr') ?></th>
            <th class="py-2 px-3"><?= t('th_category_asset_count') ?></th>
            <th class="py-2 px-3"><?= t('th_action') ?></th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($categoryList as $c): ?>
        <?php $usedCount = $usageMap[$c['name']] ?? 0; ?>
        <tr class="border-t hover:bg-slate-50">
            <td class="py-2 px-3 font-medium"><?= htmlspecialchars($c['name']) ?></td>
            <td class="py-2 px-3">
                <span class="px-2 py-0.5 rounded-full text-xs font-medium bg-brand-50 text-brand-700"><?= htmlspecialchars($c['abbr']) ?></span>
            </td>
            <td class="py-2 px-3"><?= $usedCount ?></td>
            <td class="py-2 px-3 space-x-2">
                <button type="button" class="text-blue-600 hover:underline text-xs"
                        onclick='openCategoryModal(<?= json_encode($c, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'><?= t('btn_edit') ?></button>
                <?php if ($usedCount > 0): ?>
                    <span class="text-slate-300 text-xs cursor-not-allowed" title="<?= htmlspecialchars(t('category_in_use_hint')) ?>"><?= t('link_delete') ?></span>
                <?php else: ?>
                    <a href="category_delete.php?id=<?= $c['id'] ?>"
                       onclick="return confirmDelete('<?= htmlspecialchars(t('confirm_delete_category', $c['name']), ENT_QUOTES) ?>')"
                       class="text-red-600 hover:underline text-xs"><?= t('link_delete') ?></a>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
    <?php if (!$categoryList): ?>
        <tr><td colspan="4" class="py-6 text-center text-slate-400"><?= t('no_categories_yet') ?></td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<div id="categoryModal" class="fixed inset-0 bg-black/40 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-sm">
        <form method="post" action="category_save.php" class="p-5 space-y-3 text-sm">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="id" id="c_id">
            <div class="flex items-start justify-between gap-3">
                <h2 class="font-semibold text-lg" id="categoryModalTitle"><?= t('modal_add_category_title') ?></h2>
                <button type="button" onclick="closeCategoryModal()" data-modal-close title="<?= htmlspecialchars(t('btn_close')) ?>" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="shrink-0 -mr-1 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><?= icon('x', 'w-5 h-5') ?></button>
            </div>

            <div>
                <label class="block mb-1 font-medium"><?= t('field_category_name') ?></label>
                <input name="name" id="c_name" required maxlength="50" class="w-full border rounded-lg px-3 py-2" placeholder="<?= htmlspecialchars(t('category_name_placeholder')) ?>">
            </div>
            <div>
                <label class="block mb-1 font-medium"><?= t('field_category_abbr') ?></label>
                <input name="abbr" id="c_abbr" required maxlength="10" class="w-full border rounded-lg px-3 py-2 uppercase" placeholder="<?= htmlspecialchars(t('category_abbr_placeholder')) ?>">
                <p class="text-xs text-slate-400 mt-1"><?= t('category_abbr_hint') ?></p>
            </div>
            <div>
                <label class="block mb-1 font-medium"><?= t('field_category_sort') ?></label>
                <input type="number" name="sort_order" id="c_sort_order" min="0" value="0" class="w-full border rounded-lg px-3 py-2">
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t mt-3">
                <button type="button" onclick="closeCategoryModal()" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200"><?= t('btn_cancel') ?></button>
                <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium"><?= t('btn_save') ?></button>
            </div>
        </form>
    </div>
</div>

<script>
var modalAddCategoryTitle = <?= json_encode(t('modal_add_category_title')) ?>;
var modalEditCategoryTitle = <?= json_encode(t('modal_edit_category_title')) ?>;

function openCategoryModal(data) {
    document.getElementById('categoryModal').classList.remove('hidden');
    document.getElementById('categoryModal').classList.add('flex');
    ['id','name','abbr','sort_order'].forEach(f => {
        const el = document.getElementById('c_' + f);
        if (el) el.value = data && data[f] !== null && data[f] !== undefined ? data[f] : (f === 'sort_order' ? 0 : '');
    });
    document.getElementById('categoryModalTitle').innerText = data ? modalEditCategoryTitle : modalAddCategoryTitle;
}
function closeCategoryModal() {
    document.getElementById('categoryModal').classList.add('hidden');
    document.getElementById('categoryModal').classList.remove('flex');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
