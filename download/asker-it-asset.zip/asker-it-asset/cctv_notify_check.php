<?php
/**
 * Popup notifikasi CCTV untuk admin (dipanggil berkala dari includes/footer.php).
 *   GET  -> pemberitahuan CCTV yang belum dilihat admin ini
 *   POST last_id=<id> -> tandai sudah dilihat
 * READ-ONLY terhadap data CCTV; status "sudah dilihat" disimpan di includes/data/cctv_seen.json.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cctv.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (empty($_SESSION['user_id']) || !isAdmin()) { echo json_encode(['ok' => false]); exit; }
$uid = (int)$_SESSION['user_id'];
$db  = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $last = (int)($_POST['last_id'] ?? 0);
    cctvSeen(function ($d) use ($uid, $last) { $d[$uid] = max((int)($d[$uid] ?? 0), $last); return $d; });
    echo json_encode(['ok' => true]);
    exit;
}

if (!cctvSettings()['notify_web']) { echo json_encode(['ok' => true, 'max_id' => 0, 'items' => []]); exit; }
try {
    $r = cctvUnseenNotices($db, $uid);
    echo json_encode(['ok' => true] + $r, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $e) {
    echo json_encode(['ok' => false]);
}
