<?php
/**
 * Cetak nametag di kertas F4 landscape.
 *   nametag_print.php?uid=ID          -> halaman cetak (dialog cetak terbuka otomatis)
 *   nametag_print.php?uid=ID&pdf=1    -> unduh PDF ukuran F4
 * User biasa hanya boleh mencetak nametag miliknya sendiri; admin boleh semua.
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();
require_once __DIR__ . '/includes/nametag.php';

$db  = getDB();
$me  = (int)$_SESSION['user_id'];
$uid = isAdmin() ? (int)($_GET['uid'] ?? $me) : $me;
$d   = ntGet($db, $uid);
if (!$d) { http_response_code(404); exit('User tidak ditemukan'); }

@set_time_limit(60);
$png = ntRenderPng($d, 300);
$src = 'data:image/png;base64,' . base64_encode($png);
$fileBase = 'Nametag_' . preg_replace('/[^A-Za-z0-9]+/', '_', $d['full_name']);

if (!empty($_GET['pdf'])) {
    require_once __DIR__ . '/vendor/autoload.php';
    $options = new Dompdf\Options();
    $options->set('isRemoteEnabled', false);
    $options->set('dpi', 300);
    $dompdf = new Dompdf\Dompdf($options);
    $dompdf->setPaper([0, 0, 935.43, 609.45]);   // F4 landscape: 330 x 215 mm (dalam poin)
    $dompdf->loadHtml('<html><head><meta charset="UTF-8"><style>@page{margin:0}body{margin:0}</style></head><body>' . ntSheetHtml($src, true) . '</body></html>');
    $dompdf->render();
    $dompdf->stream($fileBase . '_F4.pdf', ['Attachment' => true]);
    exit;
}
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES);
?><!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $h($fileBase) ?></title>
<style>
@page { size: 330mm 215mm; margin: 0; }
html, body { margin: 0; background: #e2e8f0; font-family: "Segoe UI", Arial, sans-serif; }
.bar { position: sticky; top: 0; background: #fff; border-bottom: 1px solid #cbd5e1; padding: 10px 16px; display: flex; flex-wrap: wrap; gap: 10px; align-items: center; z-index: 2; }
.bar button, .bar a { font: 600 14px inherit; padding: 8px 14px; border-radius: 8px; border: 1px solid #cbd5e1; background: #fff; color: #0f172a; text-decoration: none; cursor: pointer; }
.bar .pri { background: #2563eb; border-color: #2563eb; color: #fff; }
.warn { background: #fef3c7; color: #92400e; border: 1px solid #fcd34d; border-radius: 8px; padding: 8px 12px; font-size: 13px; flex: 1 1 320px; line-height: 1.4; }
.paper { margin: 16px auto; width: 330mm; background: #fff; box-shadow: 0 8px 24px rgba(15,23,42,.25); }
.scroll { overflow-x: auto; padding: 0 16px 24px; }
@media print {
  html, body { background: #fff; }
  .bar { display: none; }
  .scroll { padding: 0; overflow: visible; }
  .paper { margin: 0; box-shadow: none; }
}
</style></head>
<body>
<div class="bar">
  <button class="pri" onclick="doPrint()">🖨️ Cetak</button>
  <a href="nametag_print.php?<?= $h(http_build_query(['uid' => $uid, 'pdf' => 1])) ?>">📄 Simpan PDF (F4)</a>
  <a href="nametag.php<?= isAdmin() && $uid !== $me ? '?uid=' . $uid : '' ?>">← Kembali</a>
  <div class="warn"><b>Wajib kertas F4 (21,5 × 33 cm).</b> Di dialog cetak pilih ukuran kertas <b>F4 / Folio</b>, orientasi <b>Landscape</b>, skala <b>100% / Actual size</b>, margin <b>None</b>. Jangan pakai A4 (tepi hanya 3 mm, nametag bisa terpotong printer).</div>
</div>
<div class="scroll"><div class="paper"><?= ntSheetHtml($src, false) ?></div></div>
<script>
function doPrint() {
    // Aplikasi Android IT System: cetak lewat fitur cetak aplikasi.
    if (window.TMNNApp && TMNNApp.print) TMNNApp.print(<?= json_encode($fileBase) ?>); else window.print();
}
window.addEventListener('load', function () { setTimeout(doPrint, 400); });
</script>
</body></html>
