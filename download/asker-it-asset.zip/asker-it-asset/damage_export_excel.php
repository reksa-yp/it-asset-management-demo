<?php
/** Export Excel daftar Aset Rusak, mengikuti filter aktif di halaman Aset Rusak. */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/damage.php';
require_once __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;

$db = getDB();
ensureDamageTable($db);
$f    = damageFilters();
$rows = getDamages($db, $f);
$statusLabels = ['Digunakan' => t('status_used'), 'Stok' => t('status_stock'), 'Tidak Digunakan' => t('status_unused')];

$headers = [
    t('xls_hdr_asset_id'), t('xls_hdr_category'), t('xls_hdr_device_name'), t('th_serial'), t('dmg_col_date'), t('dmg_col_issue'),
    t('dmg_col_storage'), t('dmg_col_last_user'), t('th_department'), t('dmg_state_label'), t('dmg_col_closed'),
    t('dmg_col_days'), t('dmg_col_asset_status'), t('stock_note'), t('mut_col_by'),
];

$book  = new Spreadsheet();
$sheet = $book->getActiveSheet();
$sheet->setTitle(mb_substr(str_replace(['[', ']', ':', '*', '?', '/', '\\'], ' ', t('page_title_damages')), 0, 31));
$lastCol = Coordinate::stringFromColumnIndex(count($headers));
$stateText = $f['state'] === 'open' ? t('dmg_filter_open') : ($f['state'] === 'all' ? t('stock_all') : damageStateLabel($f['state']));
$sheet->setCellValue('A1', t('app_name') . ' — ' . t('dmg_report_title'));
$sheet->setCellValue('A2', t('th_status') . ': ' . $stateText . '   •   ' . t('stock_period') . ': ' . ($f['from'] ?: '…') . ' s/d ' . ($f['to'] ?: '…')
    . '   •   ' . t('printed_at') . ': ' . date('d M Y H:i'));
$sheet->mergeCells("A1:{$lastCol}1");
$sheet->mergeCells("A2:{$lastCol}2");
$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(13);
$sheet->getStyle('A2')->getFont()->setItalic(true)->getColor()->setRGB('64748B');
$sheet->fromArray($headers, null, 'A4');

$r = 5;
foreach ($rows as $d) {
    $vals = [
        $d['current_number'] ?: $d['asset_number'], $d['current_category'] ?: $d['asset_category'], $d['current_name'] ?: $d['asset_name'],
        $d['serial_number'] ?? '', date('Y-m-d', strtotime($d['damage_date'])), $d['issue'], $d['storage_location'],
        $d['last_user_names'], $d['last_department'], damageStateLabel($d['state']), $d['closed_date'] ?: '',
        damageDays($d), $d['current_number'] ? ($statusLabels[$d['asset_status']] ?? $d['asset_status']) : t('dmg_asset_deleted'),
        $d['note'], $d['created_by_name'],
    ];
    foreach ($vals as $c => $v) {
        $cell = Coordinate::stringFromColumnIndex($c + 1) . $r;
        if (is_int($v)) $sheet->setCellValue($cell, $v);
        else $sheet->setCellValueExplicit($cell, (string)$v, DataType::TYPE_STRING);
    }
    $r++;
}
$last = max(4, $r - 1);
$sheet->getStyle("A4:{$lastCol}4")->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
$sheet->getStyle("A4:{$lastCol}4")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
$sheet->getStyle("A4:{$lastCol}{$last}")->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
for ($c = 1; $c <= count($headers); $c++) $sheet->getColumnDimension(Coordinate::stringFromColumnIndex($c))->setAutoSize(true);
$sheet->freezePane('A5');

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="aset_rusak_' . date('Ymd_His') . '.xlsx"');
header('Cache-Control: max-age=0');
(new Xlsx($book))->save('php://output');
exit;
