# Panduan Chat Grup

Menu **Chat Grup** dipakai untuk mengobrol per grup antar user terdaftar, lengkap dengan foto, dari PC maupun HP (termasuk aplikasi Android). Isi pesan dan foto disimpan **terenkripsi (AES-256)** di server.

## 1. Untuk semua user

- Buka menu **Chat Grup** (di HP ada di menu bawah). Angka merah = jumlah pesan belum dibaca; tanda **@** = Anda disebut.
- **Kirim pesan**: ketik lalu Enter (di HP tekan tombol kirim). Shift+Enter = baris baru.
- **Kirim foto**: klik ikon kamera → **Buka kamera** (potret langsung dari HP) atau **Pilih dari galeri / file**. Screenshot juga bisa ditempel dengan **Ctrl+V** atau diseret ke ruang chat. Foto otomatis dikecilkan (maks. 1600 px) sebelum dikirim.
- **Bagikan tiket / aset**: ikon kamera → **Bagikan tiket / aset**. Hasilnya kartu yang bisa diklik. User biasa hanya bisa membagikan tiketnya sendiri; admin bisa semua tiket dan aset.
- **Balas**: arahkan kursor (di HP ketuk) ke pesan → **⋯** → **Balas**. Kutipan pesan aslinya ikut tampil.
- **Sebut nama**: ketik **@** lalu pilih nama anggota. Orang yang disebut mendapat notifikasi khusus.
- **Dibaca oleh**: klik **✓✓ 3/5** di pesan Anda untuk melihat siapa yang sudah dan belum membaca.
- **Hapus pesan**: **⋯** → **Hapus** (klik dua kali). Pesan sendiri bisa dihapus dalam **1 jam** setelah dikirim; lewat dari itu minta admin.
- **Notifikasi**: saat membuka halaman lain di IT System, pesan baru muncul sebagai kartu di pojok kanan atas (dicek tiap 15 detik). Di aplikasi Android ikut berbunyi seperti notifikasi tiket.

## 2. Untuk admin (Kelola grup)

- **Buat grup**: Kelola grup → pilih **+ Grup baru** → isi nama → centang anggota → **Simpan grup**. Hanya admin yang bisa membuat grup.
- **Semua user terdaftar**: anggota otomatis semua user aktif, termasuk user baru.
- **Grup pengumuman**: hanya admin yang boleh menulis; user hanya membaca. Grup awal **Semua Karyawan** dibuat otomatis sebagai grup pengumuman untuk semua user.
- **Sematkan pesan**: ⋯ → **Sematkan di atas**. Pesan tampil di bilah kuning atas grup.
- **Hapus pesan siapa pun** dan **hapus grup** (klik dua kali; semua pesan & foto grup ikut terhapus).
- **User nonaktif** (Management User) otomatis keluar dari semua grup dan tidak bisa membaca chat.
- **Temuan checklist CCTV**: pilih grup di **Kirim temuan checklist CCTV ke grup**. Setiap temuan ✗ baru dari checklist otomatis dikirim sebagai kartu (beserta fotonya) ke grup itu.
- **Lama simpan foto**: 30–365 hari (bawaan 90). Foto yang lebih lama dihapus otomatis sekali sehari; teks pesan tetap ada dengan keterangan "Foto sudah dihapus".

## 3. PENTING: cadangan kunci enkripsi

Semua pesan dan foto hanya bisa dibuka dengan kunci di `includes/data/chat_key.php` (dibuat otomatis saat Chat pertama kali dibuka).

1. Kelola grup → **Unduh cadangan kunci** → simpan file `chat_key.php` di flashdisk / NAS, **terpisah dari backup database**.
2. Kalau server di-install ulang: kembalikan database seperti biasa, lalu salin `chat_key.php` ke folder `includes/data/`.
3. Tanpa file ini, chat lama **tidak bisa dibuka lagi**, walaupun database sudah di-backup. Jangan menghapus atau mengubah file kunci.

## 4. Catatan teknis

- Tabel baru (dibuat otomatis, tabel lama tidak diubah): `chat_groups`, `chat_members`, `chat_messages`, `chat_reads`.
- File foto: `includes/data/chat_photos/TAHUN/BULAN/*.enc` (terenkripsi; hanya bisa dibuka lewat `chat_photo.php` oleh anggota grup).
- Pengaturan: `includes/data/chat_settings.json`. Folder `includes/data` sudah ditolak dari akses langsung lewat browser (`.htaccess`).
- Butuh ekstensi PHP **openssl** (bawaan XAMPP sudah aktif).
- Halaman chat mengecek pesan baru tiap 3 detik hanya selama halaman chat dibuka (15 detik bila tab tidak terlihat); beban server ringan.
- Server masih HTTP: isi chat aman di database/backup, tapi saat dikirim lewat jaringan belum terenkripsi. Pasang HTTPS bila ingin lebih aman.
