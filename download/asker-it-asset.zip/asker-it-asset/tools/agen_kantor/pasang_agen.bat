@echo off
:: =====================================================================
:: Pasang Agen Kantor agar berjalan otomatis setiap PC/server menyala
:: (Task Scheduler, akun SYSTEM, tanpa perlu login). Klik kanan > Run as administrator.
:: =====================================================================
net session >nul 2>&1
if errorlevel 1 (
    echo Jalankan file ini dengan klik kanan ^> Run as administrator.
    pause
    exit /b 1
)
schtasks /Create /TN "Agen Kantor IT Asset" /TR "\"%~dp0jalankan_agen.bat\"" /SC ONSTART /RU SYSTEM /RL HIGHEST /F
if errorlevel 1 (
    echo Gagal membuat jadwal.
    pause
    exit /b 1
)
schtasks /Run /TN "Agen Kantor IT Asset"
echo.
echo Selesai. Agen Kantor berjalan di latar belakang dan akan menyala otomatis setiap PC dihidupkan.
echo Cek statusnya di aplikasi: menu Agen Kantor. Log ada di agen_log.txt.
pause
