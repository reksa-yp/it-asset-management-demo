@echo off
:: =====================================================================
:: AGEN KANTOR - IT Asset Management
:: Menjalankan agen terus-menerus (otomatis dibuka lagi bila berhenti).
:: Uji coba: klik 2x file ini. Agar otomatis saat PC menyala: jalankan pasang_agen.bat.
:: =====================================================================
setlocal
cd /d "%~dp0"
set "PHP_EXE="
set "PHP_ARGS="
if exist "%~dp0php\php.exe" (
    set "PHP_EXE=%~dp0php\php.exe"
    set "PHP_ARGS=-n -d extension_dir="%~dp0php\ext" -d extension=curl -d extension=openssl -d extension=sockets"
)
if not defined PHP_EXE if exist "C:\xampp\php\php.exe" set "PHP_EXE=C:\xampp\php\php.exe"
if not defined PHP_EXE (
    echo.
    echo  PHP tidak ditemukan.
    echo  Pilih salah satu:
    echo   1. Pasang XAMPP di C:\xampp, atau
    echo   2. Unduh PHP for Windows ^(VS16/VS17 x64 Thread Safe, file .zip^) dari https://windows.php.net/download
    echo      lalu ekstrak ke folder "php" di dalam folder agen ini, sehingga ada php\php.exe
    echo.
    pause
    exit /b 1
)
echo Agen Kantor berjalan. Biarkan jendela ini terbuka ^(atau pasang dengan pasang_agen.bat^). Tutup untuk berhenti.
:loop
"%PHP_EXE%" %PHP_ARGS% "%~dp0asker_agent.php"
ping -n 11 127.0.0.1 >nul
goto loop
