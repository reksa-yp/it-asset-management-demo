<?php
/**
 * AGEN KANTOR - IT Asset Management
 * ---------------------------------------------------------------------------------------------
 * Dijalankan di 1 PC/server di kantor yang selalu menyala (Windows), BUKAN di hosting.
 * Agen membaca NVR/CCTV dan menjalankan ping di jaringan kantor, lalu mengirim hasilnya ke aplikasi
 * di hosting. Agen hanya membuat koneksi KELUAR (HTTPS) ke hosting: tidak perlu IP publik,
 * port forwarding, maupun VPN.
 *
 * Pengaturan: file agen_config.json di folder yang sama (dibuat otomatis saat diunduh dari menu Agen Kantor):
 *   { "url": "https://domainanda.com/asker-it-asset/", "key": "kunci-rahasia" }
 *
 * Cara menjalankan: klik 2x jalankan_agen.bat (uji coba), atau pasang_agen.bat (otomatis saat PC menyala).
 * Log: agen_log.txt (otomatis diganti baru jika > 1 MB).
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('403'); }
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', 'stderr');
date_default_timezone_set('Asia/Jakarta');
set_time_limit(0);

const AGENT_VER = '1.0';
$dir = __DIR__;
$logFile = $dir . '/agen_log.txt';

function agLog(string $msg): void
{
    global $logFile;
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n";
    echo $line;
    if (is_file($logFile) && filesize($logFile) > 1000000) @rename($logFile, $logFile . '.old');
    @file_put_contents($logFile, $line, FILE_APPEND);
}

$cfg = json_decode((string)@file_get_contents($dir . '/agen_config.json'), true);
if (!is_array($cfg) || empty($cfg['url']) || empty($cfg['key'])) {
    agLog('ERROR: agen_config.json tidak ditemukan / belum lengkap. Unduh ulang paket agen dari menu Agen Kantor.');
    exit(2);
}
if (!function_exists('curl_init')) {
    agLog('ERROR: ekstensi PHP curl tidak aktif. Pakai php.exe dari XAMPP, atau jalankan lewat jalankan_agen.bat.');
    exit(2);
}
$api = rtrim((string)$cfg['url'], '/') . '/agent_api.php';

// Hanya 1 agen yang berjalan di PC ini.
$lock = fopen($dir . '/agen.lock', 'c');
if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) { agLog('Agen sudah berjalan di PC ini, keluar.'); exit(0); }

/* ============================================================== HTTP */

/** curl ke hosting (HTTPS). Memakai daftar sertifikat Windows bila tersedia (PHP portable tidak punya cacert). */
function agPost(string $url, array $data, int $timeout = 60): array
{
    $ch = curl_init($url);
    $opt = [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data, JSON_UNESCAPED_SLASHES),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Expect:'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_USERAGENT => 'AskerAgent/' . AGENT_VER,
        CURLOPT_ENCODING => '',
    ];
    if (defined('CURLOPT_SSL_OPTIONS') && defined('CURLSSLOPT_NATIVE_CA')) $opt[CURLOPT_SSL_OPTIONS] = CURLSSLOPT_NATIVE_CA;
    $cacert = __DIR__ . '/cacert.pem';
    if (is_file($cacert)) $opt[CURLOPT_CAINFO] = $cacert;
    curl_setopt_array($ch, $opt);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    return [$code, $body === false ? '' : (string)$body, $err];
}

/** Banyak HTTP GET ke NVR sekaligus (paralel), Digest/Basic auth. $reqs = [id => [url, user, pass, timeout]]. */
function agHttpMany(array $reqs): array
{
    $out = [];
    if (!$reqs) return $out;
    $mh = curl_multi_init();
    $handles = [];
    foreach ($reqs as $id => $r) {
        $ch = curl_init($r[0]);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => max(2, (int)$r[3]),
            CURLOPT_TIMEOUT => max(3, (int)$r[3] + 3),
            CURLOPT_HTTPAUTH => CURLAUTH_DIGEST | CURLAUTH_BASIC,
            CURLOPT_USERPWD => $r[1] . ':' . $r[2],
            CURLOPT_SSL_VERIFYPEER => false,      // NVR di LAN memakai sertifikat buatan sendiri
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        curl_multi_add_handle($mh, $ch);
        $handles[$id] = $ch;
    }
    do {
        $st = curl_multi_exec($mh, $running);
        if ($running) curl_multi_select($mh, 0.5);
    } while ($running && $st === CURLM_OK);
    foreach ($handles as $id => $ch) {
        $body = curl_multi_getcontent($ch);
        $errno = curl_errno($ch);
        $code = $errno ? 0 : (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $out[$id] = ['code' => $code, 'body' => base64_encode($errno ? '' : (string)$body)];
        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);
    }
    curl_multi_close($mh);
    return $out;
}

/* ============================================================== Ping / TCP / ARP */

function agPingBin(): string
{
    foreach (['C:\\Windows\\System32\\PING.EXE', 'C:\\Windows\\Sysnative\\PING.EXE', '/bin/ping', '/usr/bin/ping'] as $p) if (@is_file($p)) return $p;
    return 'ping';
}

function agPingArgs(string $ip, int $count, int $waitMs): array
{
    if (DIRECTORY_SEPARATOR === '\\') return [agPingBin(), '-n', (string)$count, '-w', (string)$waitMs, $ip];
    return [agPingBin(), '-c', (string)$count, '-i', '0.2', '-W', (string)max(1, (int)ceil($waitMs / 1000)), $ip];
}

function agParsePing(string $out, int $count): array
{
    $replies = 0; $times = [];
    foreach (preg_split('/\r?\n/', $out) as $line) {
        if (stripos($line, 'ttl=') === false) continue;
        $replies++;
        if (preg_match('/[=<]\s*([\d.]+)\s*ms/i', $line, $m)) $times[] = max(1, (int)round((float)$m[1]));
    }
    return ['replies' => min($replies, $count), 'sent' => $count,
            'avg' => $times ? (int)round(array_sum($times) / count($times)) : null, 'max' => $times ? max($times) : null];
}

/** Ping banyak IP bersamaan (maks. $parallel proses). Return [ip => hasil]. */
function agPingMany(array $ips, int $count, int $waitMs, int $parallel = 32): array
{
    $ips = array_values(array_unique(array_filter($ips, function ($ip) { return filter_var($ip, FILTER_VALIDATE_IP); })));
    $res = []; $queue = $ips; $running = [];
    $deadline = microtime(true) + 25 + $count * 2;
    while ($queue || $running) {
        while ($queue && count($running) < $parallel) {
            $ip = array_shift($queue);
            $fo = tempnam(sys_get_temp_dir(), 'agp');
            $p = @proc_open(agPingArgs($ip, $count, $waitMs), [0 => ['pipe', 'r'], 1 => ['file', $fo, 'w'], 2 => ['file', $fo, 'a']], $pipes, null, null, ['bypass_shell' => true]);
            if (!is_resource($p)) { @unlink($fo); $res[$ip] = ['replies' => 0, 'sent' => $count, 'avg' => null, 'max' => null, 'error' => 'ping gagal dijalankan']; continue; }
            fclose($pipes[0]);
            $running[$ip] = [$p, $fo];
        }
        foreach ($running as $ip => $r) {
            list($p, $fo) = $r;
            $st = proc_get_status($p);
            if ($st['running'] && microtime(true) < $deadline) continue;
            if ($st['running']) proc_terminate($p);
            proc_close($p);
            $res[$ip] = agParsePing((string)@file_get_contents($fo), $count);
            @unlink($fo);
            unset($running[$ip]);
        }
        if ($running) usleep(40000);
    }
    return $res;
}

/** Coba sambung TCP ke banyak alamat & port sekaligus. $targets = [ip => [port,...]]. Return [ip => [port, ms]]. */
function agTcpMany(array $targets, float $timeout = 1.5): array
{
    $socks = []; $meta = []; $found = [];
    $t0 = microtime(true);
    foreach ($targets as $ip => $ports) {
        if (!filter_var($ip, FILTER_VALIDATE_IP) && !preg_match('/^[a-z0-9.-]+$/i', (string)$ip)) continue;
        foreach ((array)$ports as $port) {
            $s = @stream_socket_client('tcp://' . $ip . ':' . (int)$port, $en, $es, $timeout, STREAM_CLIENT_CONNECT | STREAM_CLIENT_ASYNC_CONNECT);
            if (!$s) continue;
            stream_set_blocking($s, false);
            $k = (int)$s; $socks[$k] = $s; $meta[$k] = [$ip, (int)$port];
        }
    }
    $end = $t0 + $timeout;
    while ($socks && ($left = $end - microtime(true)) > 0) {
        $w = array_values($socks); $e = array_values($socks); $r = null;
        $n = @stream_select($r, $w, $e, 0, (int)min(200000, $left * 1000000));
        if ($n === false) break;
        foreach (array_merge($w ?: [], $e ?: []) as $s) {
            $k = (int)$s; if (!isset($socks[$k])) continue;
            list($ip, $port) = $meta[$k];
            $ok = @stream_socket_get_name($s, true) !== false;
            if ($ok) { @fread($s, 1); $ok = !feof($s); }
            if ($ok && !isset($found[$ip])) $found[$ip] = [$port, max(1, (int)round((microtime(true) - $t0) * 1000))];
            @fclose($s); unset($socks[$k]);
        }
    }
    foreach ($socks as $s) @fclose($s);
    return $found;
}

function agArpTable(): array
{
    $out = [];
    $bin = 'arp';
    foreach (['C:\\Windows\\System32\\ARP.EXE', 'C:\\Windows\\Sysnative\\ARP.EXE', '/usr/sbin/arp', '/sbin/arp'] as $c) if (@is_file($c)) { $bin = $c; break; }
    $p = @proc_open([$bin, '-a'], [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes, null, null, ['bypass_shell' => true]);
    if (is_resource($p)) {
        fclose($pipes[0]);
        $txt = (string)stream_get_contents($pipes[1]); fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
        foreach (preg_split('/\r?\n/', $txt) as $line) {
            if (preg_match('/(\d{1,3}(?:\.\d{1,3}){3}).*?([0-9a-f]{2}([-:])[0-9a-f]{2}(?:\3[0-9a-f]{2}){4})/i', $line, $m)) {
                $mac = strtoupper(str_replace('-', ':', $m[2]));
                if ($mac !== 'FF:FF:FF:FF:FF:FF' && strpos($mac, '01:00:5E') !== 0) $out[$m[1]] = $mac;
            }
        }
    }
    return $out;
}

/* ============================================================== Menjalankan pekerjaan dari server */

function agRunProbes(array $probes): array
{
    $http = []; $tcp = []; $out = [];
    foreach ($probes as $p) {
        $id = (string)($p['id'] ?? '');
        if (!preg_match('/^[0-9a-f]{40}$/', $id)) continue;
        if (($p['kind'] ?? '') === 'http' && preg_match('#^https?://#i', (string)$p['target'])) {
            $http[$id] = [(string)$p['target'], (string)($p['user'] ?? ''), (string)($p['pass'] ?? ''), (int)($p['timeout'] ?? 8)];
        } elseif (($p['kind'] ?? '') === 'tcp' && preg_match('/^(.+):(\d+)$/', (string)$p['target'], $m)) {
            $tcp[$id] = [$m[1], (int)$m[2]];
        }
    }
    foreach (array_chunk($http, 12, true) as $part) $out += agHttpMany($part);   // maks. 12 permintaan bersamaan ke NVR
    if ($tcp) {
        $targets = [];
        foreach ($tcp as $id => $t) $targets[$t[0]][] = $t[1];
        $open = [];
        // Satu alamat bisa punya beberapa port: cek per port agar hasil tiap probe tepat.
        foreach ($tcp as $id => $t) $open[$id] = agTcpMany([$t[0] => [$t[1]]], 2.0) ? 1 : 0;
        foreach ($open as $id => $v) $out[$id] = ['code' => $v, 'body' => ''];
    }
    return $out;
}

function agRunJob(array $j): array
{
    $p = (array)($j['params'] ?? []);
    switch ($j['type'] ?? '') {
        case 'ping':
            return ['ping' => agPingMany((array)($p['ips'] ?? []), max(1, min(10, (int)($p['count'] ?? 4))), max(200, min(5000, (int)($p['wait_ms'] ?? 1000))))];
        case 'tcp':
            return ['tcp' => agTcpMany((array)($p['targets'] ?? []), max(0.5, min(5.0, (float)($p['timeout'] ?? 1.2))))];
        case 'arp':
            $hosts = [];
            $t0 = microtime(true);
            foreach ((array)($p['resolve'] ?? []) as $ip) {
                if (microtime(true) - $t0 > 8 || !filter_var($ip, FILTER_VALIDATE_IP)) break;
                $h = (string)@gethostbyaddr($ip);
                if ($h !== '' && $h !== $ip) $hosts[$ip] = $h;
            }
            return ['arp' => agArpTable(), 'hosts' => $hosts];
    }
    return ['error' => 'jenis pekerjaan tidak dikenal'];
}

/* ============================================================== Loop utama */

$info = ['host' => (string)gethostname(), 'php' => PHP_VERSION, 'version' => AGENT_VER, 'os' => PHP_OS_FAMILY];
agLog('Agen Kantor ' . AGENT_VER . ' mulai. Server: ' . $api);
$results = ['probes' => [], 'jobs' => []];
$fails = 0; $lastOk = 0;
$started = time();
while (true) {
    list($code, $body, $err) = agPost($api, ['key' => $cfg['key'], 'info' => $info, 'results' => $results]);
    $resp = json_decode($body, true);
    if ($code !== 200 || !is_array($resp) || empty($resp['ok'])) {
        $fails++;
        $msg = is_array($resp) && !empty($resp['error']) ? $resp['error'] : ($err !== '' ? $err : 'HTTP ' . $code);
        if ($fails === 1 || $fails % 20 === 0) agLog('Gagal menghubungi server (' . $fails . 'x): ' . $msg);
        if ($code === 403) sleep(60);
        sleep(min(60, 5 * $fails));
        continue;   // hasil sebelumnya dikirim ulang pada percobaan berikutnya
    }
    if ($fails) agLog('Terhubung kembali ke server.');
    $fails = 0;
    if (time() - $lastOk > 600) { agLog('OK · ' . ($resp['cctv'] !== '' ? 'CCTV: ' . $resp['cctv'] : 'terhubung')); $lastOk = time(); }
    $results = ['probes' => [], 'jobs' => []];

    $probes = (array)($resp['probes'] ?? []);
    $jobs = (array)($resp['jobs'] ?? []);
    if ($probes) $results['probes'] = agRunProbes($probes);
    foreach ($jobs as $j) {
        $id = (string)($j['id'] ?? '');
        if (!preg_match('/^[0-9a-f]{16}$/', $id)) continue;
        $results['jobs'][$id] = agRunJob($j);
    }
    if ($probes || $jobs) continue;                  // kirim hasil segera
    sleep(max(1, min(30, (int)($resp['next'] ?? 10))));
    // Mulai ulang tiap 12 jam (dibuka lagi oleh jalankan_agen.bat) agar memori tetap bersih.
    if (time() - $started > 43200) { agLog('Mulai ulang terjadwal.'); exit(0); }
}
