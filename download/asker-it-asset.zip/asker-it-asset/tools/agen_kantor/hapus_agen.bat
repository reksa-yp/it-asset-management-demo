@echo off
:: Hentikan & hapus jadwal Agen Kantor. Klik kanan > Run as administrator.
schtasks /End /TN "Agen Kantor IT Asset" >nul 2>&1
schtasks /Delete /TN "Agen Kantor IT Asset" /F
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like *asker_agent.php* -or $_.CommandLine -like *jalankan_agen.bat* } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" >nul 2>&1
echo Agen Kantor dihentikan dan jadwalnya dihapus.
pause
