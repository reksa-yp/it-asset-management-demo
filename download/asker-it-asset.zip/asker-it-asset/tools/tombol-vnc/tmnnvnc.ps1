# Penghubung tombol "VNC" di IT Asset Management ke TightVNC Viewer.
# Dipanggil Windows saat link tmnnvnc://<IP> diklik di browser.
# Hanya menerima alamat IPv4; isi lain diabaikan, sehingga link dari situs lain tidak bisa
# menyisipkan perintah atau parameter tambahan.
param([string]$Url = '')

if ($Url -notmatch '^tmnnvnc:/{0,2}((?:\d{1,3}\.){3}\d{1,3})/?$') { exit 1 }
$ip = $Matches[1]
foreach ($part in $ip.Split('.')) { if ([int]$part -gt 255) { exit 1 } }

$candidates = @(
    (Join-Path $env:ProgramFiles 'TightVNC\tvnviewer.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'TightVNC\tvnviewer.exe')
)
$viewer = $candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1

if (-not $viewer) {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show(
        "TightVNC Viewer tidak ditemukan di PC ini.`nPasang TightVNC (dengan komponen Viewer) lalu coba lagi.",
        'IT Asset Management - Remote VNC') | Out-Null
    exit 1
}
Start-Process -FilePath $viewer -ArgumentList "-host=$ip"
