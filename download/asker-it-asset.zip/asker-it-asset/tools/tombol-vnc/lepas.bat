@echo off
rem Menghapus pendaftaran tombol "VNC" IT Asset Management dari PC ini.
reg delete "HKCU\Software\Classes\tmnnvnc" /f >nul 2>&1
del "%LOCALAPPDATA%\ITAssetVNC\tmnnvnc.ps1" >nul 2>&1
echo Tombol VNC sudah dilepas dari PC ini.
pause
