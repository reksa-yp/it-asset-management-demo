@echo off
rem Mendaftarkan tombol "VNC" IT Asset Management untuk pengguna Windows yang sedang login.
rem Tidak butuh hak Administrator. Jalankan sekali di tiap PC admin.
setlocal
set "DEST=%LOCALAPPDATA%\ITAssetVNC"
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0tmnnvnc.ps1" "%DEST%\tmnnvnc.ps1" >nul
if errorlevel 1 (
  echo GAGAL menyalin tmnnvnc.ps1. Pastikan file ini diekstrak dulu dari ZIP, jangan dijalankan dari dalam ZIP.
  pause
  exit /b 1
)
reg add "HKCU\Software\Classes\tmnnvnc" /ve /d "URL:TightVNC (IT Asset Management)" /f >nul
reg add "HKCU\Software\Classes\tmnnvnc" /v "URL Protocol" /d "" /f >nul
reg add "HKCU\Software\Classes\tmnnvnc\shell\open\command" /ve /d "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%DEST%\tmnnvnc.ps1\" \"%%1\"" /f >nul
echo.
echo Selesai. Tombol VNC di IT Asset Management sekarang membuka TightVNC Viewer.
echo Tutup lalu buka lagi browser sebelum mencoba.
if not exist "%ProgramFiles%\TightVNC\tvnviewer.exe" if not exist "%ProgramFiles(x86)%\TightVNC\tvnviewer.exe" echo PERHATIAN: TightVNC Viewer belum ditemukan di PC ini.
pause
