<?php
/**
 * Preview Import Excel Tablet.
 * File yang di-upload lewat "Import dari Excel" dan berformat Tablet ditampilkan dulu di sini:
 * baris baru / diperbarui / error / peringatan. Data baru disimpan setelah admin klik "Simpan".
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/includes/tablet_excel.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$pending = $_SESSION['tablet_import'] ?? null;
// File sementara kedaluwarsa setelah 1 jam atau hilang dari server.
if ($pending && (time() - (int)$pending['time'] > 3600 || !is_file($pending['file']))) {
    tabletImportDiscardPending();
    $pending = null;
}
if (!$pending) {
    $_SESSION['import_msg'] = ['ok' => false, 'text' => t('tablet_imp_expired')];
    header('Location: assets.php');
    exit;
}

$db = getDB();
$tabletCats = array_values(array_filter(array_column(getAssetCategories($db), 'name'), 'isTabletCategory'));
$backUrl = 'assets.php?category=' . urlencode($tabletCats[0] ?? 'Tablet');

// ===== Aksi: Batal / Simpan =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    if (($_POST['action'] ?? '') === 'save') {
        try {
            $ss = IOFactory::load($pending['file']);
            $res = runAssetSpreadsheetImport($db, $ss, true);
            $ins = $upd = $err = 0;
            foreach ($res['tablet'] as $r) { $ins += $r['inserted']; $upd += $r['updated']; $err += $r['errors']; }
            $text = t('tablet_imp_done', $ins, $upd, $err);
            if ($res['generic']) {
                [$gi, $gu, $gs] = $res['generic']['counts'];
                $text .= ' ' . t('tablet_imp_done_generic', $res['generic']['sheet'], $gi, $gu, $gs);
            }
            $_SESSION['import_msg'] = ['ok' => true, 'text' => $text];
        } catch (Throwable $e) {
            $_SESSION['import_msg'] = ['ok' => false, 'text' => t('tablet_imp_failed') . ' ' . $e->getMessage()];
        }
    } else {
        $_SESSION['import_msg'] = ['ok' => false, 'text' => t('tablet_imp_cancelled')];
    }
    tabletImportDiscardPending();
    header('Location: ' . $backUrl);
    exit;
}

// ===== Preview (dijalankan lalu dibatalkan / rollback) =====
$previewError = null;
$res = ['tablet' => [], 'generic' => null];
try {
    $ss = IOFactory::load($pending['file']);
    $res = runAssetSpreadsheetImport($db, $ss, false);
} catch (Throwable $e) {
    $previewError = $e->getMessage();
}
$tot = ['insert' => 0, 'update' => 0, 'error' => 0, 'warn' => 0];
foreach ($res['tablet'] as $r) {
    $tot['insert'] += $r['inserted']; $tot['update'] += $r['updated'];
    $tot['error'] += $r['errors'];    $tot['warn'] += $r['warnings'];
}
$canSave = !$previewError && ($tot['insert'] + $tot['update'] > 0 || $res['generic']);

$h = fn($v) => htmlspecialchars((string)$v);
$fmtDate = function ($v) {
    $d = tabletParseDate($v);
    return $d ? date('d/m/Y', strtotime($d)) : (is_scalar($v) ? (string)$v : '');
};

$pageTitle = t('tablet_imp_title');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="flex flex-wrap items-center justify-between gap-3 mb-4">
    <div>
        <h1 class="text-xl font-semibold text-slate-800"><?= t('tablet_imp_title') ?></h1>
        <p class="text-sm text-slate-500"><?= t('tablet_imp_file') ?>: <span class="font-medium text-slate-700"><?= $h($pending['name']) ?></span></p>
    </div>
    <form method="post" class="flex gap-2">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <button name="action" value="cancel" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-medium"><?= t('btn_cancel') ?></button>
        <button name="action" value="save" <?= $canSave ? '' : 'disabled' ?>
                class="inline-flex items-center gap-1 px-4 py-2 rounded-lg text-sm font-medium text-white <?= $canSave ? 'bg-blue-600 hover:bg-blue-700' : 'bg-slate-300 cursor-not-allowed' ?>">
            <?= icon('check') ?> <?= t('tablet_imp_btn_save') ?>
        </button>
    </form>
</div>

<?php if ($previewError): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 bg-red-50 text-red-700"><?= t('tablet_imp_failed') ?> <?= $h($previewError) ?></div>
<?php else: ?>

<div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
    <div class="bg-white rounded-xl shadow-sm p-4"><p class="text-xs text-slate-500"><?= t('tablet_imp_new') ?></p><p class="text-2xl font-semibold text-green-600 tabular-nums"><?= $tot['insert'] ?></p></div>
    <div class="bg-white rounded-xl shadow-sm p-4"><p class="text-xs text-slate-500"><?= t('tablet_imp_updated') ?></p><p class="text-2xl font-semibold text-blue-600 tabular-nums"><?= $tot['update'] ?></p></div>
    <div class="bg-white rounded-xl shadow-sm p-4"><p class="text-xs text-slate-500"><?= t('tablet_imp_error') ?></p><p class="text-2xl font-semibold text-red-600 tabular-nums"><?= $tot['error'] ?></p></div>
    <div class="bg-white rounded-xl shadow-sm p-4"><p class="text-xs text-slate-500"><?= t('tablet_imp_warning') ?></p><p class="text-2xl font-semibold text-amber-600 tabular-nums"><?= $tot['warn'] ?></p></div>
</div>

<p class="text-xs text-slate-500 mb-3"><?= t('tablet_imp_note') ?></p>

<?php if ($res['generic']): [$gi, $gu, $gs] = $res['generic']['counts']; ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 bg-slate-50 border text-slate-600">
        <?= $h(t('tablet_imp_generic_note', $res['generic']['sheet'], $gi, $gu, $gs)) ?>
    </div>
<?php endif; ?>

<?php foreach ($res['tablet'] as $sheetName => $r): ?>
<div class="bg-white rounded-xl shadow-sm mb-5 overflow-hidden">
    <div class="px-4 py-3 border-b text-sm font-semibold text-slate-700">
        <?= t('tablet_imp_sheet') ?>: <?= $h($sheetName) ?>
        <span class="font-normal text-slate-400">(<?= count($r['rows']) ?> <?= t('tablet_imp_rows') ?>)</span>
    </div>
    <div class="overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-left text-xs text-slate-500">
        <tr>
            <th class="py-2 px-3"><?= t('tablet_imp_col_row') ?></th>
            <th class="py-2 px-3"><?= t('tablet_imp_col_action') ?></th>
            <th class="py-2 px-3"><?= t('xls_hdr_asset_id') ?></th>
            <th class="py-2 px-3"><?= t('xls_hdr_device_name') ?></th>
            <th class="py-2 px-3"><?= t('xls_hdr_users') ?></th>
            <th class="py-2 px-3"><?= t('xls_hdr_department') ?></th>
            <th class="py-2 px-3"><?= t('xls_hdr_location') ?></th>
            <th class="py-2 px-3"><?= t('xls_hdr_serial') ?></th>
            <th class="py-2 px-3"><?= t('xls_hdr_ip') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_received') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_id') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_brand') ?></th>
            <th class="py-2 px-3"><?= t('xls_hdr_accessories') ?></th>
            <th class="py-2 px-3"><?= t('xls_hdr_tablet_condition') ?></th>
            <th class="py-2 px-3 min-w-[16rem]"><?= t('tablet_imp_col_notes') ?></th>
        </tr>
        </thead>
        <tbody class="divide-y">
        <?php foreach ($r['rows'] as $row): $d = $row['data'];
            $badge = [
                'insert' => ['bg-green-100 text-green-700', t('tablet_imp_badge_new')],
                'update' => ['bg-blue-100 text-blue-700', t('tablet_imp_badge_update')],
                'error'  => ['bg-red-100 text-red-700', t('tablet_imp_badge_error')],
            ][$row['action']]; ?>
            <tr class="<?= $row['action'] === 'error' ? 'bg-red-50/40' : '' ?>">
                <td class="py-2 px-3 text-slate-400 tabular-nums"><?= (int)$row['row'] ?></td>
                <td class="py-2 px-3"><span class="px-2 py-0.5 rounded-full text-xs font-semibold <?= $badge[0] ?>"><?= $badge[1] ?></span></td>
                <td class="py-2 px-3 font-medium whitespace-nowrap"><?= $h($row['asset_number'] ?: t('dash')) ?></td>
                <td class="py-2 px-3"><?= $h($d['device_name'] ?? '') ?></td>
                <td class="py-2 px-3"><?= $h($d['users'] ?? '') ?></td>
                <td class="py-2 px-3"><?= $h($d['department'] ?? '') ?></td>
                <td class="py-2 px-3"><?= $h($d['location'] ?? '') ?></td>
                <td class="py-2 px-3 whitespace-nowrap"><?= $h($d['serial'] ?? '') ?></td>
                <td class="py-2 px-3 whitespace-nowrap"><?= $h($d['ip'] ?? '') ?></td>
                <td class="py-2 px-3 whitespace-nowrap"><?= $h($fmtDate($d['received'] ?? null)) ?></td>
                <td class="py-2 px-3 whitespace-nowrap"><?= $h($d['tablet_id'] ?? '') ?></td>
                <td class="py-2 px-3"><?= $h($d['brand'] ?? '') ?></td>
                <td class="py-2 px-3"><?= $h($d['accessories'] ?? '') ?></td>
                <td class="py-2 px-3"><?= $h($d['condition'] ?? '') ?></td>
                <td class="py-2 px-3 text-xs">
                    <?php foreach ($row['errors'] as $m): ?><div class="text-red-600"><?= $h($m) ?></div><?php endforeach; ?>
                    <?php foreach ($row['warnings'] as $m): ?><div class="text-amber-600"><?= $h($m) ?></div><?php endforeach; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$r['rows']): ?>
            <tr><td colspan="13" class="py-6 text-center text-slate-400"><?= t('tablet_imp_empty') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php endforeach; ?>

<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
