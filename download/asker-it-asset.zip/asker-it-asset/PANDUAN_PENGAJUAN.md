# Pengajuan Khusus

Menu untuk mengajukan **perangkat baru** atau **penggantian barang** kepada tim IT, lengkap dengan status dan riwayatnya.
Tersedia untuk user dan admin.

## User
1. Buka **Pengajuan Khusus → Buat Pengajuan**.
2. Pilih **Jenis Pengajuan**: *Pengajuan Baru* atau *Penggantian Barang*.
3. Pilih **Kategori** (atau *Lainnya*), lalu tulis **Detail** (nama barang, tipe, jumlah, kebutuhan khusus) dan **Alasan**.
4. Untuk *Penggantian Barang*, **foto barang yang ingin diganti wajib dilampirkan** (unggah, tempel screenshot, atau foto langsung). Maks. 8 MB.
5. Klik **Kirim Pengajuan**. Pengajuan berstatus **Menunggu**; selama masih Menunggu bisa dibatalkan.
6. Pantau di **Riwayat Pengajuan Saya**. Status: Menunggu, Disetujui, Ditolak, Selesai, Dibatalkan.

## Admin
- **Semua Pengajuan**: cari (nomor, nama, departemen, detail, alasan), filter status dan kategori.
- Ubah status satu per satu atau banyak sekaligus, dengan **catatan admin** (wajib saat menolak). Pengajuan Ditolak dianggap ditutup.
- Admin bisa membuat pengajuan **untuk dirinya sendiri, user lain, atau orang baru yang belum punya akun** (tercatat atas nama pengaju).
- **Cetak detail** per pengajuan dan **Cetak Riwayat** (kop surat ikut dicetak). Hapus satu atau banyak pengajuan secara permanen.
- Pengajuan baru memunculkan **pop-up** di admin dan masuk ke **pusat notifikasi** (ikon lonceng, jenis "Pengajuan").

## Terjemahan otomatis (mode English)
- Tombol **Translate to English** di form menerjemahkan detail dan alasan sebelum dikirim; teks asli tetap tersimpan.
- Saat bahasa aplikasi English, teks bebas berbahasa Indonesia di halaman (detail aset, keterangan, catatan, tiket) ikut diterjemahkan.
  Isi kolom input, tombol, dan menu tidak diubah. Hasil disimpan di cache browser; bila layanan gagal, teks asli tetap tampil.
- Pengaturan penyedia terjemahan ada di `includes/translation_config.php`. Teks dikirim ke penyedia eksternal, jadi hindari
  informasi rahasia bila kebijakan perusahaan tidak mengizinkan.

Tabel database dibuat otomatis saat menu pertama kali dibuka. File: `request.php`, `request_save.php`, `request_update.php`,
`request_bulk.php`, `request_cancel.php`, `request_print.php`, `request_notify_check.php`, `request_translate.php`, `includes/request_feature.php`.
