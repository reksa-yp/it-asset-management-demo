<?php
/**
 * Generate usulan Nomor Aset otomatis untuk SATU aset, format:
 *   <Awalan>/<Singkatan Departement>/<Singkatan Jenis Aset>/<Urutan 3 digit>
 *
 * Dipanggil lewat AJAX dari modal Tambah/Edit Aset di assets.php — hasilnya
 * tetap bisa diedit manual oleh admin sebelum disimpan, jadi endpoint ini
 * hanya memberi USULAN, tidak langsung menyimpan apa pun ke database.
 *
 * Untuk generate ulang banyak aset sekaligus dari tombol toolbar, lihat
 * asset_generate_number_bulk.php.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/asset_number.php';
requireAdmin();
header('Content-Type: application/json');

$category   = (string)($_GET['category'] ?? '');
$department = trim((string)($_GET['department'] ?? ''));
$excludeId  = !empty($_GET['exclude_id']) ? (int)$_GET['exclude_id'] : null;
// Pengguna yang dicentang di form (dipisah koma): departement diambil dari user pertama,
// sama persis dengan yang dipakai saat aset disimpan.
$ownerIds   = array_filter(array_map('intval', explode(',', (string)($_GET['owner_ids'] ?? ''))));

try {
    $db = getDB();
    $department = assetNumberDepartment($db, $ownerIds, $department);
    echo json_encode(suggestAssetNumber($db, $category, $department, (string)($_GET['location'] ?? ''), $excludeId));
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'message' => t('gen_number_failed')]);
}
