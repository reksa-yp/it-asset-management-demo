<?php
/**
 * Cetak / Simpan PDF topologi jaringan (khusus admin), dengan kop surat.
 *   ?loc=Gudang      filter lokasi (kosong = semua)
 *   &net=1           hanya perangkat jaringan (switch/router/AP); aset biasa diringkas jadi jumlah
 *   &orient=landscape|portrait
 *   &grp=1           kotak per lokasi
 *   &cable=1         warna kabel per switch / router
 *   &out=pdf         unduh PDF (Dompdf); tanpa ini = halaman cetak browser (langsung muncul dialog Print)
 * Gambar dipotong otomatis per halaman A4; sambungan ke halaman sebelumnya digambar dari tepi atas.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/net_topo.php';
require_once __DIR__ . '/includes/letterhead.php';
require_once __DIR__ . '/includes/xls_number.php';   // xlsCompanyName()

$db = getDB();
ensureNetTables($db);
$loc     = trim((string)($_GET['loc'] ?? ''));
$netOnly = !empty($_GET['net']);
$land    = ($_GET['orient'] ?? 'portrait') === 'landscape';
$pdf     = ($_GET['out'] ?? '') === 'pdf';
$h = fn($v) => htmlspecialchars((string)$v);

$all  = netAssets($db);
$grp  = !empty($_GET['grp']);   // kotak per lokasi
$cable = !empty($_GET['cable']);   // warna kabel per switch / router
$rows = netTopoRows($all, $loc, $netOnly, $grp, $cable);
$last = $db->query("SELECT checked_at FROM net_checks ORDER BY id DESC LIMIT 1")->fetchColumn();
$suspects = netSuspects($all);
// Koneksi tambahan yang kedua perangkatnya ikut tergambar.
$shown = array_flip(array_map(fn($r) => $r['a']['id'], $rows));
$extras = array_values(array_filter(netExtraLinks($db), fn($l) => isset($shown[$l['a']], $shown[$l['b']], $all[$l['a']], $all[$l['b']])));
$company = function_exists('xlsCompanyName') ? xlsCompanyName() : '';

// Ruang gambar per halaman (mm -> px 96 dpi). Halaman pertama dikurangi judul & keterangan.
$mm = 96 / 25.4;
$availW = ($land ? 269 : 182) * $mm;
$availH = ($land ? 132 : 219) * $mm;
// Halaman lanjutan dikurangi baris "Topologi (lanjutan)" + jarak aman, supaya gambar tidak terdorong ke halaman berikutnya.
// Susunan bebas (mode "Geser bebas") dipakai bila ada posisi tersimpan.
$savedPos = netTopoPosMap($db);
$free = $savedPos && $rows ? netTopoFreeLayout($rows, $savedPos) : null;
$layout = $free
    ? netTopoFreePages($free, $availW, $availH - 12 * $mm, $availH - 40 * $mm - count($suspects) * 6 * $mm)
    : netTopoPages($rows, $availW, $availH - 12 * $mm, $availH - 40 * $mm - count($suspects) * 6 * $mm, count($extras));
$scale = $layout['scale'];

$stateLabel = ['ok' => nL('Normal', 'Normal'), 'warn' => nL('Lambat', 'Slow'), 'err' => nL('Mati', 'Down'), 'na' => nL('Belum dicek', 'Not checked')];
$devices = array_values(array_filter($rows, fn($r) => empty($r['a']['virtual']) && $r['a']['is_net']));
$title = nL('Topologi Jaringan', 'Network Topology') . ($company !== '' ? ' ' . $company : '');

// ---------- Isi dokumen (dipakai versi cetak & PDF) ----------
ob_start(); ?>
<div class="topo-head">
    <h1><?= $h($title) ?></h1>
    <p><?= $h(nL('Lokasi', 'Location')) ?>: <b><?= $h($loc !== '' ? $loc : nL('Semua lokasi', 'All locations')) ?></b>
        &nbsp;&middot;&nbsp; <?= $h(nL('Isi', 'Content')) ?>: <b><?= $h($netOnly ? nL('Perangkat jaringan saja', 'Network devices only') : nL('Semua aset ber-IP & perangkat jaringan', 'All IP assets & network devices')) ?></b>
        &nbsp;&middot;&nbsp; <?= $h(nL('Cek jaringan terakhir', 'Last network check')) ?>: <b><?= $h($last ? date('d-m-Y H:i', strtotime($last)) : nL('belum pernah', 'never')) ?></b></p>
    <p class="muted"><?= $h(documentCreatedAt()) ?></p>
    <p class="legend">
        <span class="sw" style="background:#ecfdf3;border-color:#15803d"></span><?= $h(nL('Normal', 'Normal')) ?>
        <span class="sw" style="background:#fffbeb;border-color:#b45309"></span><?= $h(nL('Lambat', 'Slow')) ?>
        <span class="sw" style="background:#fef2f2;border-color:#b91c1c"></span><?= $h(nL('Mati / diduga mati', 'Down / suspected')) ?>
        <span class="sw" style="background:#ffffff;border-color:#94a3b8"></span><?= $h(nL('Tanpa IP / belum dicek', 'No IP / not checked')) ?>
        <span class="sw" style="background:#ffffff;border:1px dashed #2563eb"></span><?= $h(nL('Koneksi tambahan', 'Extra link')) ?>
        <?php if ($grp): ?><span class="sw" style="background:#ffffff;border:1px dashed #64748b"></span><?= $h(nL('Belum dihubungkan (di kotak lokasinya)', 'Not linked (in its location box)')) ?><?php endif; ?>
        <span class="muted">&nbsp; <?= $h(nL('Teks kecil di garis = port (perangkat atas ⇄ perangkat ini).', 'Small text on lines = ports (upstream ⇄ this device).')) ?></span>
    </p>
    <?php foreach ($suspects as $s): ?>
        <p class="alert"><?= $h(nL('Diduga mati: ' . $s['name'] . ' (' . $s['down'] . ' dari ' . $s['total'] . ' aset di bawahnya tidak merespons)', 'Suspected down: ' . $s['name'] . ' (' . $s['down'] . ' of ' . $s['total'] . ' assets below not responding)')) ?></p>
    <?php endforeach; ?>
</div>
<?php if (!$rows): ?>
    <p class="muted"><?= $h(nL('Belum ada data topologi untuk filter ini. Isi "Terhubung ke" di menu Jaringan > Data koneksi.', 'No topology data for this filter.')) ?></p>
<?php endif; ?>
<?php foreach ($layout['pages'] as $pi => [$from, $to]):
    $svg = $free ? netTopoFreeSvg($rows, $free, $from, $to, $netOnly, $extras) : netTopoSvg($rows, $from, $to, $netOnly, $extras);
    preg_match('/width="(\d+)" height="(\d+)"/', $svg, $m);
    $wMm = round($m[1] * $scale / $mm, 1); $hMm = round($m[2] * $scale / $mm, 1); ?>
    <div class="topo-page<?= $pi < count($layout['pages']) - 1 || $devices ? ' brk' : '' ?>">
        <?php if ($pi > 0): ?><p class="muted cont"><?= $h(nL('Topologi (lanjutan, halaman ', 'Topology (continued, page ') . ($pi + 1) . ')') ?></p><?php endif; ?>
        <?php if ($pdf): ?>
            <img src="data:image/svg+xml;base64,<?= base64_encode($svg) ?>" style="width:<?= $wMm ?>mm;height:<?= $hMm ?>mm;" alt="">
        <?php else: ?>
            <div style="width:<?= $wMm ?>mm;height:<?= $hMm ?>mm;"><?= str_replace('<svg ', '<svg style="width:100%;height:100%" ', $svg) ?></div>
        <?php endif; ?>
    </div>
<?php endforeach; ?>
<?php if ($devices): ?>
<div class="topo-list">
    <h2><?= $h(nL('Daftar perangkat jaringan', 'Network device list')) ?> (<?= count($devices) ?>)</h2>
    <table class="list">
        <thead><tr><th>No</th><th><?= $h(nL('Perangkat', 'Device')) ?></th><th><?= $h(nL('Jenis', 'Type')) ?></th><th><?= $h(nL('Lokasi', 'Location')) ?></th><th>IP</th><th><?= $h(nL('Terhubung ke', 'Connected to')) ?></th><th><?= $h(nL('Koneksi tambahan', 'Extra links')) ?></th><th><?= $h(nL('Aset di bawahnya', 'Assets below')) ?></th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($devices as $i => $r): $a = $r['a']; $p = $a['parent'] ? ($all[$a['parent']] ?? null) : null; ?>
            <tr><td><?= $i + 1 ?></td><td><b><?= $h($a['name']) ?></b><br><span class="muted"><?= $h($a['number']) ?></span><?php if (trim($a['brand']) !== ''): ?><br><span style="color:#4338ca"><?= $h($a['brand']) ?></span><?php endif; ?></td><td><?= $h($a['type']) ?></td><td><?= $h($a['loc'] ?: '-') ?></td>
                <td><?= $h($a['ip'] ?: nL('tanpa IP', 'no IP')) ?><?php if (count($a['ips']) > 1): ?><br><span class="muted"><?= $h(implode(', ', $a['ips'])) ?></span><?php endif; ?></td><td><?= $h($p ? $p['name'] . (netPortLabel($a['port'], $a['own_port']) !== '' ? ' (' . netPortLabel($a['port'], $a['own_port']) . ')' : '') : '-') ?></td><td><?= $h(netExtraText($all, netExtraLinks($db), $a['id']) ?: '-') ?></td>
                <td style="text-align:center"><?= (int)$r['below'] ?></td><td class="st-<?= $h($r['state']) ?>"><?= $h($a['ip'] === '' && $r['state'] === 'err' ? nL('Diduga mati', 'Suspected down') : $stateLabel[$r['state']] ?? '-') ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif;
$body = ob_get_clean();

$css = '
    body { font-family: Helvetica, Arial, sans-serif; font-size: 10pt; color: #1e293b; }
    .topo-head h1 { font-size: 15pt; margin: 0 0 4px; }
    .topo-head p { margin: 0 0 3px; font-size: 9pt; }
    .muted { color: #64748b; font-size: 8.5pt; }
    .legend { margin-top: 5px !important; }
    .legend .sw { display: inline-block; width: 11px; height: 9px; border: 1px solid; border-radius: 2px; margin: 0 4px 0 10px; vertical-align: middle; }
    .legend .sw:first-child { margin-left: 0; }
    .alert { color: #b91c1c; font-weight: bold; }
    .topo-page { margin-top: 8px; }
    .brk { page-break-after: always; }
    .cont { margin: 0 0 4px; }
    .topo-list h2 { font-size: 12pt; margin: 0 0 6px; }
    table.list { width: 100%; border-collapse: collapse; font-size: 8.5pt; }
    table.list th, table.list td { border: 1px solid #cbd5e1; padding: 3px 5px; text-align: left; vertical-align: top; }
    table.list th { background: #f1f5f9; }
    .st-ok { color: #15803d; } .st-warn { color: #b45309; } .st-err { color: #b91c1c; font-weight: bold; }
';
$fileBase = 'Topologi_Jaringan' . ($loc !== '' ? '_' . preg_replace('/[^A-Za-z0-9]+/', '_', $loc) : '') . '_' . date('Ymd_Hi');

if ($pdf) {
    require_once __DIR__ . '/vendor/autoload.php';
    // Font PDF bawaan tidak punya simbol ⇄, jadi diganti "<->" (gambar & tabel).
    // (Gambar SVG di-decode dulu: mengganti potongan base64 langsung bisa merusak gambar.)
    $body = str_replace('⇄', '&lt;-&gt;', $body);
    $body = preg_replace_callback('#data:image/svg\+xml;base64,([A-Za-z0-9+/=]+)#', fn($m) => 'data:image/svg+xml;base64,' . base64_encode(str_replace('⇄', '&lt;-&gt;', base64_decode($m[1]))), $body);
    $html = '<html><head><meta charset="UTF-8"><style>' . letterheadPdfCss() . $css . '</style></head><body>' . letterheadPdfHtml() . $body . '</body></html>';
    $opt = new \Dompdf\Options();
    $opt->set('isRemoteEnabled', true);
    $dompdf = new \Dompdf\Dompdf($opt);
    $dompdf->setPaper('A4', $land ? 'landscape' : 'portrait');
    $dompdf->loadHtml($html);
    $dompdf->render();
    $dompdf->stream($fileBase . '.pdf', ['Attachment' => true]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="<?= $h(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $h($fileBase) ?></title>
<style>
    @page { size: A4 <?= $land ? 'landscape' : 'portrait' ?>; }
    body { margin: 20px; }
    <?= $css ?>
    .no-print { margin: 16px 0; text-align: center; }
    .no-print button, .no-print a { background: #1F3DD1; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 13px; cursor: pointer; text-decoration: none; display: inline-block; margin: 0 4px; }
    .no-print a.sec { background: #475569; }
    @media print { body { margin: 0; } .no-print { display: none; } }
<?= letterheadCss() ?></style>
</head>
<body onload="window.print()">
    <?= letterheadOpen() ?>
    <?= $body ?>
    <?= letterheadClose() ?>
    <div class="no-print">
        <button onclick="window.print()"><?= $h(nL('Cetak lagi', 'Print again')) ?></button>
        <a class="sec" href="?<?= $h(http_build_query(array_merge($_GET, ['out' => 'pdf']))) ?>"><?= $h(nL('Unduh PDF', 'Download PDF')) ?></a>
    </div>
</body>
</html>
