<?php
/**
 * Simpan / update Rincian Pengerjaan & Pengecekan Aset untuk satu tiket.
 * Disimpan di tabel BARU ticket_work_details (1 baris per tiket, upsert),
 * tidak mengubah struktur tabel tickets/assets yang sudah ada.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tickets.php');
    exit;
}
csrfCheck();

$ticketId   = (int) ($_POST['ticket_id'] ?? 0);
$workDetail = trim($_POST['work_detail'] ?? '');
$assetCheck = trim($_POST['asset_check'] ?? '');

if ($ticketId <= 0) {
    header('Location: tickets.php');
    exit;
}

$db = getDB();

// Pastikan tiket memang ada
$check = $db->prepare("SELECT id FROM tickets WHERE id = ?");
$check->execute([$ticketId]);
if (!$check->fetch()) {
    header('Location: tickets.php');
    exit;
}

$stmt = $db->prepare("
    INSERT INTO ticket_work_details (ticket_id, work_detail, asset_check, filled_by)
    VALUES (?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
        work_detail = VALUES(work_detail),
        asset_check = VALUES(asset_check),
        filled_by   = VALUES(filled_by)
");
$stmt->execute([
    $ticketId,
    $workDetail !== '' ? $workDetail : null,
    $assetCheck !== '' ? $assetCheck : null,
    $_SESSION['user_id'],
]);

$_SESSION['ticket_bulk_msg'] = ['ok' => true, 'text' => t('msg_work_detail_saved')];

header('Location: tickets.php');
exit;
