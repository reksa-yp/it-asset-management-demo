<?php
/**
 * Simpan / update Rincian Pengerjaan & Pengecekan Aset untuk satu tiket.
 * Disimpan di tabel BARU ticket_work_details (1 baris per tiket, upsert),
 * tidak mengubah struktur tabel tickets/assets yang sudah ada.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tickets.php');
    exit;
}
csrfCheck();

$ticketId   = (int) ($_POST['ticket_id'] ?? 0);
$workDetail = trim($_POST['work_detail'] ?? '');
$assetCheck = trim($_POST['asset_check'] ?? '');

if ($ticketId <= 0) {
    header('Location: tickets.php');
    exit;
}

$db = getDB();

// Pastikan tiket memang ada
$check = $db->prepare("SELECT id FROM tickets WHERE id = ?");
$check->execute([$ticketId]);
if (!$check->fetch()) {
    header('Location: tickets.php');
    exit;
}

$stmt = $db->prepare("
    INSERT INTO ticket_work_details (ticket_id, work_detail, asset_check, filled_by)
    VALUES (?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
        work_detail = VALUES(work_detail),
        asset_check = VALUES(asset_check),
        filled_by   = VALUES(filled_by)
");
$stmt->execute([
    $ticketId,
    $workDetail !== '' ? $workDetail : null,
    $assetCheck !== '' ? $assetCheck : null,
    $_SESSION['user_id'],
]);

// Pusat Notifikasi: catatan pengerjaan untuk pelapor; kata kunci "harus upgrade" untuk admin lain.
try {
    require_once __DIR__ . '/includes/notifications.php';
    $nt = $db->prepare("SELECT t.ticket_number, t.reported_by, a.asset_number, a.device_name FROM tickets t LEFT JOIN assets a ON a.id = t.asset_id WHERE t.id = ?");
    $nt->execute([$ticketId]);
    if (($tk = $nt->fetch()) && $workDetail !== '') {
        notifAdd($db, [(int)$tk['reported_by']], 'ticket', 'ticket_note', notifL('Catatan pengerjaan tiket ', 'Work note on ticket ') . $tk['ticket_number'],
            mb_strimwidth($workDetail, 0, 160, '...'), 'tickets.php?q=' . urlencode((string)$tk['ticket_number']), $ticketId, '', (int)$_SESSION['user_id']);
    }
    $kw = defined('UPGRADE_ALERT_KEYWORD') ? UPGRADE_ALERT_KEYWORD : 'harus upgrade';
    if ($tk && !empty($tk['asset_number']) && (mb_stripos($workDetail, $kw) !== false || mb_stripos($assetCheck, $kw) !== false)) {
        $dup = $db->prepare("SELECT 1 FROM app_notifications WHERE type = 'upgrade' AND ref_id = ? LIMIT 1");
        $dup->execute([$ticketId]);
        if (!$dup->fetchColumn()) {
            notifToAdmins($db, 'system', 'upgrade', notifL('Aset perlu di-upgrade: ', 'Asset needs upgrade: ') . $tk['asset_number'],
                trim((string)($tk['device_name'] ?? '') . ' · ' . notifL('dari tiket ', 'from ticket ') . $tk['ticket_number'], ' ·'), 'dashboard.php', $ticketId, '', (int)$_SESSION['user_id']);
        }
    }
} catch (Throwable $e) {}
$_SESSION['ticket_bulk_msg'] = ['ok' => true, 'text' => t('msg_work_detail_saved')];

header('Location: tickets.php');
exit;
