<?php
/**
 * Hapus 1 transaksi stok. Ditolak jika penghapusan membuat stok menjadi minus.
 *
 * Transaksi yang terhubung dengan ID aset (stock_asset_links):
 *  - Barang Keluar ber-ID tidak bisa dihapus (aset sudah diserahkan; pakai menu Mutasi Aset untuk mengembalikan).
 *  - Barang Masuk ber-ID hanya bisa dihapus bila SEMUA unit asetnya masih berstatus Stok dan belum pernah
 *    diserahkan; aset-aset tersebut ikut dihapus dari Data Aset.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/stock.php';

$back = 'stock.php?' . preg_replace('/[^A-Za-z0-9_=&%.\-]/', '', (string)($_POST['back'] ?? 'tab=history'));
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . $back); exit; }
csrfCheck();

$db = getDB();
ensureStockTables($db);
$id = (int)($_POST['id'] ?? 0);
$s = $db->prepare("SELECT * FROM stock_transactions WHERE id = ?");
$s->execute([$id]);
$tx = $s->fetch();
$linked = $tx ? (getStockTrxAssets($db, [$id])[$id] ?? []) : [];

if (!$tx) {
    $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('stock_err_not_found')];
} elseif ($linked && $tx['type'] === 'out') {
    $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('stock_err_delete_linked_out')];
} elseif (stockAvailable($db, (int)$tx['category_id'], $id) < 0) {
    $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('stock_err_delete_negative')];
} elseif ($tx['type'] === 'in'
          && stockItemAvailable($db, (int)$tx['category_id'], trim((string)$tx['item_name']), $id) < 0
          && stockItemAvailable($db, (int)$tx['category_id'], trim((string)$tx['item_name']), 0) >= 0) {
    // Barang Masuk ini sudah (sebagian) diserahkan lewat Barang Keluar -> hapus Barang Keluar-nya dulu.
    $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('stock_err_delete_negative')];
} else {
    $assetIds = array_column($linked, 'id');
    $blocked = [];
    if ($assetIds) {
        // Unit yang sudah tidak berstatus Stok, atau pernah dipakai transaksi lain (mis. diserahkan), tidak boleh ikut terhapus.
        $ph = implode(',', array_fill(0, count($assetIds), '?'));
        $other = $db->prepare("SELECT DISTINCT asset_id FROM stock_asset_links WHERE asset_id IN ($ph) AND stock_trx_id <> ?");
        $other->execute([...$assetIds, $id]);
        $usedElsewhere = array_map('intval', $other->fetchAll(PDO::FETCH_COLUMN));
        foreach ($linked as $a) {
            if ($a['status'] !== 'Stok' || in_array($a['id'], $usedElsewhere, true)) $blocked[] = $a['asset_number'];
        }
    }
    if ($blocked) {
        $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('stock_err_delete_linked_in', implode(', ', $blocked))];
    } else {
        $db->beginTransaction();
        try {
            if ($assetIds) {
                $ph = implode(',', array_fill(0, count($assetIds), '?'));
                if (assetOwnersTableExists($db)) $db->prepare("DELETE FROM asset_owners WHERE asset_id IN ($ph)")->execute($assetIds);
                $db->prepare("DELETE FROM assets WHERE id IN ($ph)")->execute($assetIds);
                $db->prepare("DELETE FROM stock_asset_links WHERE stock_trx_id = ?")->execute([$id]);
            }
            $db->prepare("DELETE FROM stock_transactions WHERE id = ?")->execute([$id]);
            $db->commit();
            if ($assetIds) deleteTabletDetails($db, $assetIds);
            $_SESSION['stock_msg'] = ['ok' => true, 'text' => $assetIds
                ? t('stock_deleted_with_assets', implode(', ', array_column($linked, 'asset_number')))
                : t('stock_deleted')];
        } catch (Throwable $e) {
            $db->rollBack();
            $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('stock_err_save_generic', $e->getMessage())];
        }
    }
}
header('Location: ' . $back);
