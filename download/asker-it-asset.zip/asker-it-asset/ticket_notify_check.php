<?php
/**
 * Endpoint AJAX (dipanggil dari dashboard/footer.php via fetch, di-poll berkala).
 * Mengembalikan daftar tiket yang dibuat SETELAH last_seen_ticket_id milik
 * admin yang sedang login, supaya bisa ditampilkan sebagai popup notifikasi.
 * Khusus admin — user biasa tidak butuh notifikasi ini.
 *
 * VERSI TANPA UBAH DATABASE:
 * Status "tiket terakhir yang sudah dilihat" per admin disimpan di file JSON
 * lokal (includes/data/last_seen_tickets.json), BUKAN di kolom tabel users.
 * Jadi tidak perlu ALTER TABLE apapun.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

header('Content-Type: application/json; charset=utf-8');

$storageFile = __DIR__ . '/includes/data/last_seen_tickets.json';

function readLastSeenAll(string $file): array
{
    if (!file_exists($file)) return [];
    $content = file_get_contents($file);
    $data = json_decode($content, true);
    return is_array($data) ? $data : [];
}

$userId      = (string)$_SESSION['user_id'];
$lastSeenAll = readLastSeenAll($storageFile);
$lastSeen    = (int)($lastSeenAll[$userId] ?? 0);

$db = getDB();
$stmt = $db->prepare("
    SELECT t.id, t.ticket_number, t.problem_detail, t.created_at, t.reported_by,
           u.full_name AS pelapor, u.department AS user_department,
           a.department AS asset_department, a.location AS asset_location
    FROM tickets t
    JOIN users u ON u.id = t.reported_by
    LEFT JOIN assets a ON a.id = t.asset_id
    WHERE t.id > ?
    ORDER BY t.id ASC
    LIMIT 20
");
$stmt->execute([$lastSeen]);
$rows = $stmt->fetchAll();

// Departemen & lokasi pelapor: lihat ticketReporterDeptLocation() di includes/asset_owners.php
// (hanya membaca tabel yang sudah ada, tanpa ubah database).
$tickets = array_map(function ($r) use ($db) {
    $info = ticketReporterDeptLocation($db, $r);

    return [
        'id'             => (int)$r['id'],
        'ticket_number'  => $r['ticket_number'],
        'pelapor'        => $r['pelapor'],
        'department'     => $info['department'],
        'location'       => $info['location'],
        'problem_detail' => mb_strimwidth($r['problem_detail'], 0, 120, '...'),
        'created_at'     => date('d M Y H:i', strtotime($r['created_at'])),
    ];
}, $rows);

echo json_encode([
    'ok'      => true,
    'tickets' => $tickets,
    'max_id'  => $tickets ? end($tickets)['id'] : $lastSeen,
]);
