// ===== Sidebar toggle (mobile drawer + desktop collapse) =====
const sidebar   = document.getElementById('sidebar');
const overlay   = document.getElementById('sidebarOverlay');
const btnBurger = document.getElementById('btnHamburger');
const btnClose  = document.getElementById('btnCloseSidebar');

function isDesktop() {
    return window.innerWidth >= 1024; // tailwind 'lg' breakpoint
}

function openMobileSidebar() {
    sidebar.classList.remove('-translate-x-full');
    overlay.classList.remove('hidden');
}
function closeMobileSidebar() {
    sidebar.classList.add('-translate-x-full');
    overlay.classList.add('hidden');
}
function toggleDesktopCollapse() {
    const collapsed = sidebar.classList.toggle('sidebar-collapsed');
    localStorage.setItem('sidebarCollapsed', collapsed ? '1' : '0');
}

btnBurger?.addEventListener('click', () => {
    if (isDesktop()) {
        toggleDesktopCollapse();
    } else {
        sidebar.classList.contains('-translate-x-full') ? openMobileSidebar() : closeMobileSidebar();
    }
});
btnClose?.addEventListener('click', closeMobileSidebar);
overlay?.addEventListener('click', closeMobileSidebar);

// Restore collapsed state on desktop
window.addEventListener('DOMContentLoaded', () => {
    if (isDesktop() && localStorage.getItem('sidebarCollapsed') === '1') {
        sidebar.classList.add('sidebar-collapsed');
    }
});

// ===== Generic confirm-delete helper for tables =====
function confirmDelete(message = 'Yakin ingin menghapus data ini?') {
    return confirm(message);
}

// ===== Tab switcher untuk kartu detail aset (dipakai di my_asset.php) =====
function assetTabSwitch(tabId, btnEl) {
    document.querySelectorAll('.asset-tab-panel').forEach(p => p.classList.add('hidden'));
    document.querySelectorAll('.asset-tab-btn').forEach(b => b.classList.remove('asset-tab-active'));
    document.getElementById(tabId).classList.remove('hidden');
    btnEl.classList.add('asset-tab-active');
}


// =====================================================================
// Tabel responsif — berlaku untuk semua tabel di area halaman (<main>)
//
// Supaya tabel SELALU muat di lebar layar (tanpa scroll ke samping / zoom out):
// kolom yang tidak muat disembunyikan mulai dari yang paling kurang penting, lalu
// tiap baris mendapat tombol panah untuk membuka isi kolom yang disembunyikan.
// - Kolom berisi isian / tombol / centang tidak pernah disembunyikan.
// - Urutan penting kolom bisa diatur lewat atribut data-priority di <th>
//   (angka kecil = lebih penting). Tanpa atribut itu, kolom kiri dianggap lebih penting.
// - Tabel dengan atribut data-rt="off" tidak diubah.
// Kalau skrip ini gagal jalan, tabel tetap tampil seperti biasa (bisa di-scroll ke samping).
// =====================================================================
(function () {
    'use strict';
    var seq = 0, tables = [];
    var hintText = (document.documentElement.lang || 'id').toLowerCase().indexOf('en') === 0
        ? 'Some columns are hidden to fit the screen. Click the arrow on a row to see them.'
        : 'Sebagian kolom disembunyikan agar muat di layar. Klik tombol panah di baris untuk melihatnya.';

    function scrollerOf(table) {
        for (var p = table.parentElement; p && p.tagName !== 'MAIN' && p !== document.body; p = p.parentElement) {
            var ox = getComputedStyle(p).overflowX;
            if (ox === 'auto' || ox === 'scroll' || ox === 'hidden') return p;
        }
        return table.parentElement;
    }
    function headerCells(table) {
        var row = table.tHead && table.tHead.rows.length ? table.tHead.rows[table.tHead.rows.length - 1] : null;
        return row ? Array.prototype.slice.call(row.cells) : [];
    }
    function bodyRows(table) {
        var rows = [];
        Array.prototype.forEach.call(table.tBodies, function (tb) {
            Array.prototype.forEach.call(tb.rows, function (r) { if (!r.classList.contains('rt-detail')) rows.push(r); });
        });
        return rows;
    }

    function setup(table) {
        if (table.dataset.rt === 'off' || table.dataset.rtId) return null;
        var heads = headerCells(table);
        if (heads.length < 3) return null;
        // Tabel dengan sel gabungan di header tidak disentuh (urutannya tidak bisa ditebak dengan aman).
        if (table.tHead.rows.length > 1 || heads.some(function (th) { return th.colSpan > 1; })) return null;
        var id = 'rt' + (++seq);
        table.dataset.rtId = id;
        var style = document.createElement('style');
        document.head.appendChild(style);
        var rows = bodyRows(table).filter(function (r) { return r.cells.length === heads.length; });
        // Isian yang menyimpan nilai (kotak teks, centang, pilihan) tidak boleh dipindah ke baris detail.
        var STATEFUL = 'input:not([type="hidden"]):not([type="submit"]):not([type="button"]),select,textarea';
        var cols = heads.map(function (th, i) {
            var sample = rows.slice(0, 40);
            var stateful = !!th.querySelector(STATEFUL) || sample.some(function (r) {
                // isian di dalam <form> kecil (mis. tombol hapus + token) aman disalin; yang berdiri sendiri tidak
                return Array.prototype.some.call(r.cells[i].querySelectorAll(STATEFUL), function (el) { return !el.closest('td form, th form'); });
            });
            var actions = sample.some(function (r) { return !!r.cells[i].querySelector('button,a,form'); });
            var label = (th.textContent || '').replace(/\s+/g, ' ').trim();
            var pr = th.hasAttribute('data-priority') ? parseFloat(th.getAttribute('data-priority')) : (actions ? 50 + i : 100 + i);
            return { index: i, label: label, keep: stateful || label === '' || i === 0, narrow: label === '' || stateful && !sample.some(function (r) { return !!r.cells[i].querySelector('input[type="text"],select,textarea'); }), priority: pr };
        });
        // Kolom teks pertama selalu tampil (tempat tombol panah).
        var first = cols.filter(function (c) { return !c.keep; })[0];
        var anchor = 0;
        for (var k = 0; k < cols.length; k++) { if (cols[k].label !== '' && !heads[k].querySelector('input')) { anchor = k; break; } }
        cols[anchor].keep = true;
        var info = { table: table, id: id, style: style, cols: cols, heads: heads, anchor: anchor, hidden: [], hint: null };
        tables.push(info);
        return info;
    }

    function cellSel(info, i) {
        return 'table[data-rt-id="' + info.id + '"] > * > tr:not(.rt-detail) > :nth-child(' + (i + 1) + '):not([colspan])';
    }
    // wrap = true: teks boleh turun baris (lebar kolom minimal 6.5rem) supaya lebih banyak kolom yang muat.
    function applyHidden(info, hidden, wrap) {
        info.hidden = hidden;
        var css = '';
        if (wrap) {
            css += 'table[data-rt-id="' + info.id + '"]{white-space:normal!important}';
            var text = info.cols.filter(function (c) { return !c.narrow && hidden.indexOf(c.index) === -1; }).map(function (c) { return cellSel(info, c.index); });
            if (text.length) css += text.join(',') + '{white-space:normal!important;min-width:6.5rem;overflow-wrap:break-word}';
        }
        if (hidden.length) css += hidden.map(function (i) { return cellSel(info, i); }).join(',') + '{display:none}';
        info.style.textContent = css;
    }

    function fit(info) {
        var table = info.table;
        if (!document.body.contains(table)) return;
        var box = scrollerOf(table);
        if (!box || box.clientWidth === 0 || table.offsetParent === null) return;   // sedang tidak tampil
        unclip(info, false);
        closeAll(info);
        applyHidden(info, [], false);
        // +1: toleransi pembulatan sub-pixel
        var overflows = function () { return table.scrollWidth > box.clientWidth + 1 || box.scrollWidth > box.clientWidth + 1; };
        if (overflows()) {
            // Langkah 1: biarkan teks turun baris. Langkah 2: sembunyikan kolom yang paling kurang penting.
            applyHidden(info, [], true);
            var order = info.cols.filter(function (c) { return !c.keep; }).sort(function (a, b) { return b.priority - a.priority; });
            var hidden = [];
            while (overflows()) {
                var next = order.shift();
                if (!next) break;
                hidden.push(next.index);
                applyHidden(info, hidden, true);
            }
        }
        decorate(info);
        unclip(info, true);
    }

    // Judul kolom tabel "freeze" saat halaman di-scroll (position: sticky, lihat style.css).
    // Sticky hanya bekerja kalau kotak pembungkus tabel tidak membuat area scroll sendiri, jadi
    // pembungkus yang tidak sedang di-scroll diberi kelas rt-unclip (overflow: clip). Pembungkus
    // yang memang punya scroll sendiri (mis. kotak tabel Aset di layar besar) dibiarkan: di sana
    // judul kolom menempel di bagian atas kotak itu.
    function unclip(info, on) {
        var table = info.table, list = [];
        for (var p = table.parentElement; p && p.tagName !== 'MAIN' && p !== document.body; p = p.parentElement) list.push(p);
        list.forEach(function (p) { p.classList.remove('rt-unclip'); });
        if (!on) return;
        list.forEach(function (p) {
            var cs = getComputedStyle(p);
            var clips = cs.overflowX !== 'visible' || cs.overflowY !== 'visible';
            if (!clips) return;
            var scrollsY = (cs.overflowY === 'auto' || cs.overflowY === 'scroll') && p.scrollHeight > p.clientHeight + 1;
            var scrollsX = p.scrollWidth > p.clientWidth + 1;
            if (!scrollsY && !scrollsX) p.classList.add('rt-unclip');
        });
    }

    function closeAll(info) {
        Array.prototype.forEach.call(info.table.querySelectorAll('tr.rt-detail'), function (r) { r.remove(); });
        Array.prototype.forEach.call(info.table.querySelectorAll('tr.rt-open'), function (r) { r.classList.remove('rt-open'); });
    }

    function decorate(info) {
        var table = info.table, has = info.hidden.length > 0;
        bodyRows(table).forEach(function (row) {
            if (row.cells.length !== info.heads.length) return;
            var cell = row.cells[info.anchor];
            var btn = cell.querySelector(':scope > .rt-toggle');
            if (has && !btn) {
                btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'rt-toggle';
                btn.textContent = '▸';
                btn.setAttribute('aria-expanded', 'false');
                btn.setAttribute('aria-label', hintText);
                btn.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); toggle(info, row, btn); });
                cell.insertBefore(btn, cell.firstChild);
            } else if (!has && btn) {
                btn.remove();
            }
        });
        if (has && !info.hint) {
            info.hint = document.createElement('div');
            info.hint.className = 'rt-hint';
            info.hint.textContent = hintText;
            var box = scrollerOf(table);
            (table.parentElement === box ? box : table.parentElement).insertBefore(info.hint, table);
        } else if (!has && info.hint) {
            info.hint.remove(); info.hint = null;
        }
    }

    function toggle(info, row, btn) {
        var open = row.classList.contains('rt-open');
        if (open) {
            if (row.nextElementSibling && row.nextElementSibling.classList.contains('rt-detail')) row.nextElementSibling.remove();
            row.classList.remove('rt-open'); btn.textContent = '▸'; btn.setAttribute('aria-expanded', 'false');
            return;
        }
        var tr = document.createElement('tr'); tr.className = 'rt-detail';
        var td = document.createElement('td'); td.colSpan = info.heads.length - info.hidden.length;
        var grid = document.createElement('div'); grid.className = 'rt-detail-grid';
        info.hidden.slice().sort(function (a, b) { return a - b; }).forEach(function (i) {
            var item = document.createElement('div'); item.className = 'rt-detail-item';
            var l = document.createElement('div'); l.className = 'rt-detail-label'; l.textContent = info.cols[i].label;
            var v = document.createElement('div'); v.className = 'rt-detail-value'; v.innerHTML = row.cells[i].innerHTML;
            item.appendChild(l); item.appendChild(v); grid.appendChild(item);
        });
        td.appendChild(grid); tr.appendChild(td);
        row.parentNode.insertBefore(tr, row.nextSibling);
        row.classList.add('rt-open'); btn.textContent = '▾'; btn.setAttribute('aria-expanded', 'true');
    }

    function run() {
        try {
            Array.prototype.forEach.call(document.querySelectorAll('main table'), function (t) {
                if (t.closest('.fixed')) return;            // tabel di dalam pop up tidak diubah
                if (!t.dataset.rtId) setup(t);
            });
            tables.forEach(fit);
        } catch (err) { /* biarkan tabel tampil apa adanya */ }
    }

    var timer = null, lastWidth = window.innerWidth;
    function schedule() { clearTimeout(timer); timer = setTimeout(run, 120); }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run); else run();
    window.addEventListener('load', run);
    // Gaya halaman (Tailwind) bisa selesai dimuat sedikit setelah halaman tampil -> hitung ulang.
    [300, 1200, 2500].forEach(function (ms) { setTimeout(run, ms); });
    // Lebar tempat tabel berubah (sidebar dibuka/ditutup, pindah tab, gaya baru dimuat) -> hitung ulang.
    if (window.ResizeObserver) {
        var ro = new ResizeObserver(function () {
            var need = tables.some(function (info) {
                var box = scrollerOf(info.table);
                if (!box || box.clientWidth === 0 || info.table.offsetParent === null) return false;
                var changed = info.boxWidth !== box.clientWidth;
                info.boxWidth = box.clientWidth;
                return changed || info.table.scrollWidth > box.clientWidth + 1;
            });
            if (need) schedule();
        });
        var observe = function () {
            tables.forEach(function (info) {
                if (info.observed) return;
                info.observed = true;
                ro.observe(info.table);
                var box = scrollerOf(info.table); if (box) ro.observe(box);
            });
        };
        setTimeout(observe, 50); setTimeout(observe, 1500);
    }
    window.addEventListener('resize', function () { if (window.innerWidth !== lastWidth) { lastWidth = window.innerWidth; schedule(); } });
    // Sidebar dibuka/ditutup atau pindah tab di halaman -> lebar tempat tabel berubah.
    document.addEventListener('click', function (e) {
        if (e.target.closest && e.target.closest('.rt-toggle')) return;
        setTimeout(function () {
            var changed = tables.some(function (info) {
                var box = scrollerOf(info.table);
                var w = box ? box.clientWidth : 0;
                var c = info.lastBox !== undefined && info.lastBox !== w; info.lastBox = w; return c || (w > 0 && info.table.offsetParent !== null && info.fitted !== true && (info.fitted = true));
            });
            if (changed || document.querySelector('main table:not([data-rt-id]):not([data-rt="off"])')) run();
        }, 260);
    });
    window.rtRefresh = run;
})();


// =====================================================================
// Tombol form selalu terlihat (Batal / Simpan)
//
// Di semua pop up form, baris tombol di bagian bawah diberi kelas "modal-actions"
// (position: sticky di style.css) sehingga tetap menempel di bawah jendela pop up
// walau isi form panjang dan harus di-scroll.
// =====================================================================
(function () {
    'use strict';
    function mark() {
        try {
            Array.prototype.forEach.call(document.querySelectorAll('div.fixed.inset-0'), function (overlay) {
                if (overlay.id === 'sidebarOverlay') return;
                var panel = overlay.firstElementChild;
                if (!panel) return;
                // Baris tombol = induk dari tombol kirim (submit) TERAKHIR di pop up itu.
                var submits = panel.querySelectorAll('form button[type="submit"], form button:not([type]), form input[type="submit"]');
                if (!submits.length) return;
                var row = submits[submits.length - 1].parentElement;
                if (!row || row === panel || row.tagName === 'FORM' || row.classList.contains('modal-actions')) return;
                // Hanya baris yang isinya memang tombol (bukan baris isian yang kebetulan punya tombol).
                if (row.children.length > 5 || row.querySelector('input:not([type="hidden"]):not([type="submit"]), select, textarea')) return;
                row.classList.add('modal-actions');
            });
        } catch (err) { /* form tetap bisa dipakai seperti biasa */ }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mark); else mark();
    window.addEventListener('load', mark);
})();
