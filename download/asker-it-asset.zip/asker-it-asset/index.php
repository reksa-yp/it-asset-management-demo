<?php
// Belum diinstal -> arahkan ke installer.
if (!is_file(__DIR__ . '/includes/data/installed.lock')) {
    header('Location: install.php');
    exit;
}
require_once __DIR__ . '/includes/auth.php';
if (!empty($_SESSION['user_id'])) {
    header('Location: ' . (($_SESSION['role'] ?? '') === 'admin' ? 'dashboard.php' : 'my_asset.php'));
} else {
    header('Location: login.php');
}
exit;
