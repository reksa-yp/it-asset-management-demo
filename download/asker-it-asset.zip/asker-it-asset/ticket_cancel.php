<?php
/**
 * User membatalkan tiketnya sendiri. Hanya boleh saat status masih "Menunggu"
 * (belum diproses IT). Dicatat di tabel baru ticket_cancellations.
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: tickets.php'); exit; }
csrfCheck();

$db = getDB();
ensureTicketCancelTable($db);

$id     = (int)($_POST['id'] ?? 0);
$reason = mb_substr(trim($_POST['reason'] ?? ''), 0, 255);

$stmt = $db->prepare("SELECT * FROM tickets WHERE id = ?");
$stmt->execute([$id]);
$ticket = $stmt->fetch();

$fail = function (string $key) {
    $_SESSION['ticket_bulk_msg'] = ['ok' => false, 'text' => t($key)];
    header('Location: tickets.php');
    exit;
};
if (!$ticket || (int)$ticket['reported_by'] !== (int)$_SESSION['user_id']) $fail('ticket_cancel_not_allowed');
if (getTicketCancelMap($db, [$id]))                                          $fail('ticket_cancel_already');
if ($ticket['status'] !== 'Menunggu')                                        $fail('ticket_cancel_only_waiting');

$db->prepare("INSERT INTO ticket_cancellations (ticket_id, cancelled_by, reason) VALUES (?,?,?)")
   ->execute([$id, (int)$_SESSION['user_id'], $reason !== '' ? $reason : null]);
// Keluarkan dari antrian tanpa mengubah struktur tabel: status Selesai, resolved_at kosong.
$db->prepare("UPDATE tickets SET status = 'Selesai', resolved_at = NULL WHERE id = ?")->execute([$id]);
$db->prepare("INSERT INTO ticket_logs (ticket_id, status, note, changed_by) VALUES (?, 'Selesai', ?, ?)")
   ->execute([$id, mb_substr('Dibatalkan oleh user' . ($reason !== '' ? ': ' . $reason : ''), 0, 255), (int)$_SESSION['user_id']]);

$_SESSION['ticket_bulk_msg'] = ['ok' => true, 'text' => t('ticket_cancel_done', $ticket['ticket_number'])];
header('Location: tickets.php');
