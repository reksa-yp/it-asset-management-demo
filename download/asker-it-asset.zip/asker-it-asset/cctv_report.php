<?php
/**
 * Menu CCTV > Cetak & laporan.
 *   cctv_report.php?mode=shift&date=YYYY-MM-DD&shift=Pagi   -> checklist 1 shift (A4 portrait)
 *   cctv_report.php?mode=month&ym=YYYY-MM                    -> laporan bulanan (A4 landscape, khusus admin)
 *   &out=print (cetak langsung) | pdf | xlsx | html (pratinjau di dalam halaman)
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cctv.php';
requireAdminOrCctv();
require_once __DIR__ . '/includes/letterhead.php';
require_once __DIR__ . '/includes/user_position.php';

$db = getDB();
ensureCctvTables($db);
$h = fn($v) => htmlspecialchars((string)$v);

$mode = (string)($_GET['mode'] ?? 'month');
if (!isAdmin()) $mode = 'shift';                 // user Checklist CCTV hanya mencetak checklist per shift
if (!in_array($mode, ['shift', 'month'], true)) $mode = 'month';
$shifts = cctvShiftOptions();
$date  = (string)($_GET['date'] ?? date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');
$shift = (string)($_GET['shift'] ?? $shifts[0]);
if (!in_array($shift, $shifts, true)) $shift = $shifts[0];
$ym    = (string)($_GET['ym'] ?? date('Y-m'));
if (!preg_match('/^\d{4}-\d{2}$/', $ym)) $ym = date('Y-m');
$out   = (string)($_GET['out'] ?? '');
$nvrSel = (string)($_GET['nvr'] ?? 'all');   // id NVR, 0 = kamera tanpa NVR, 'all' = semua (dipisah per NVR)
$allCamsList = cctvCameras($db);
$groups = cctvNvrGroups($allCamsList);
if ($nvrSel !== 'all' && (!ctype_digit($nvrSel) || !isset($groups[(int)$nvrSel]))) $nvrSel = 'all';
$nvrSuffix = $nvrSel === 'all' ? '' : '_' . preg_replace('/[^A-Za-z0-9]+/', '_', $groups[(int)$nvrSel]['name']);

$items  = cctvCheckItems($db, false);
$signers = cctvSigners($db);
$longDate = function (string $d): string {
    $days = cL('id', 'en') === 'en' ? ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] : ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    $ts = strtotime($d);
    return $days[(int)date('w', $ts)] . ', ' . date('j', $ts) . ' ' . cctvMonthNames()[(int)date('n', $ts) - 1] . ' ' . date('Y', $ts);
};
$baseName = $mode === 'month'
    ? 'Laporan_CCTV_' . str_replace(' ', '_', cctvMonthTitle($ym))
    : 'Checklist_CCTV_' . $date . '_' . preg_replace('/[^A-Za-z0-9]+/', '_', $shift);
$baseName .= $nvrSuffix;

/* ---------------------------------------------------------------- Data */
if ($mode === 'shift') {
    $cl = cctvGetChecklist($db, $date, $shift);
    // Satu bagian (halaman) per NVR. "Semua" = semua NVR yang sudah dicek di shift ini.
    $printGroups = $nvrSel === 'all' ? $groups : [(int)$nvrSel => $groups[(int)$nvrSel]];
    if ($nvrSel === 'all' && $cl) {
        $withData = array_filter($printGroups, fn($g) => (bool)array_filter($g['cams'], fn($c) => isset($cl['results'][$c['id']])));
        if ($withData) $printGroups = $withData;
    }
    // Penandatangan pertama tiap bagian = petugas yang mengecek NVR itu.
    $groupSigners = [];
    foreach ($printGroups as $gk => $g) {
        $off = cctvChecklistOfficer($cl, $gk);
        $sg = $signers;
        if ($off['name'] !== '') $sg[0] = ['label' => cL('Diperiksa oleh', 'Checked by'), 'name' => $off['name'], 'title' => getUserPosition($db, $off['user_id'])];
        $groupSigners[$gk] = ['signers' => $sg, 'officer' => $off];
    }
} else {
    $rep = cctvMonthReport($db, $ym, $nvrSel === 'all' ? null : (int)$nvrSel);
}

/* ---------------------------------------------------------------- Isi dokumen (HTML untuk cetak & PDF) */
function cctvDocCss(bool $pdf, string $mode): string
{
    $font = $pdf ? '"DejaVu Sans", sans-serif' : 'Arial, sans-serif';
    $base = $mode === 'month' ? ($pdf ? '7.2px' : '9px') : ($pdf ? '8.5px' : '11px');
    return "
    body { font-family: $font; color: #111827; font-size: $base; }
    .doc-title { text-align: center; font-weight: bold; font-size: 1.45em; letter-spacing: .03em; margin: 0 0 2px; }
    .doc-meta { text-align: center; color: #374151; margin: 0 0 8px; }
    table.g { width: 100%; border-collapse: collapse; }
    table.g th, table.g td { border: 1px solid #94a3b8; padding: 2px 4px; vertical-align: middle; }
    table.g th { background: #e5ecf6; text-align: center; font-weight: bold; }
    table.g td.c { text-align: center; }
    table.g td.r { text-align: right; }
    table.g td.ok { color: #15803d; text-align: center; }
    table.g td.bad { background: #fee2e2; color: #b91c1c; font-weight: bold; text-align: center; }
    table.g td.na { color: #9ca3af; text-align: center; }
    /* Hari libur: kolom merah muda, tanggal & huruf L merah */
    table.g th.we { background: #fecdd3; color: #dc2626; }
    table.g td.we { background: #ffe4e6; }
    table.g td.na.we { color: #dc2626; font-weight: bold; }
    table.g td.we.bad { background: #fecaca; }
    .x { color: #b91c1c; font-weight: bold; }
    .legend { color: #374151; margin: 3px 0 8px; }
    .sec { font-weight: bold; margin: 10px 0 3px; font-size: 1.1em; }
    table.sum { border-collapse: collapse; margin: 0 0 8px; }
    table.sum td { padding: 1px 14px 1px 0; vertical-align: top; }
    table.sum b { font-size: 1.35em; }
    table.sign { width: 100%; margin-top: 16px; border-collapse: collapse; page-break-inside: avoid; }
    table.sign td { width: 33%; text-align: center; vertical-align: top; padding: 0 10px; }
    .sign-line { margin-top: 48px; border-top: 1px solid #111827; padding-top: 2px; font-weight: bold; }
    .sign-title { color: #374151; font-size: .95em; }
    .doc-nvr { text-align: center; font-weight: bold; font-size: 1.15em; color: #173A68; margin: 0 0 2px; }
    .pb { page-break-before: always; break-before: page; height: 0; }
    tr.grp td { background: #eef2f7; font-weight: bold; text-align: left; }
    .empty { padding: 30px; text-align: center; color: #64748b; border: 1px dashed #94a3b8; }
    ";
}

function cctvSignHtml(array $signers): string
{
    $hh = fn($v) => htmlspecialchars((string)$v);
    $out = '<table class="sign"><tr>';
    foreach ($signers as $s) {
        $out .= '<td>' . $hh($s['label']) . ',<div class="sign-line">' . ($s['name'] !== '' ? $hh($s['name']) : '&nbsp;') . '</div>'
              . '<div class="sign-title">' . $hh($s['title']) . '</div></td>';
    }
    return $out . '</tr></table>';
}

$mark = fn($v) => (int)$v === 1 ? '✓' : ((int)$v === 2 ? '✗' : '');
$docHtml = '';
if ($mode === 'shift') {
    $gi = 0;
    foreach ($printGroups as $gk => $g) {
        $off = $groupSigners[$gk]['officer'];
        if ($gi++ > 0) $docHtml .= '<div class="pb"></div>';
        $docHtml .= '<p class="doc-title">' . $h(cL('CHECKLIST PEMERIKSAAN CCTV', 'CCTV INSPECTION CHECKLIST')) . '</p>'
                  . '<p class="doc-nvr">' . $h($g['name']) . '</p>'
                  . '<p class="doc-meta">' . $h($longDate($date)) . ' &bull; Shift: ' . $h($shift)
                  . ($cl && $off['name'] !== '' ? ' &bull; ' . $h(cL('Petugas', 'Officer')) . ': ' . $h($off['name']) . ' &bull; ' . $h(cL('Disimpan', 'Saved')) . ' ' . $h(date('d/m/Y H:i', strtotime((string)$off['at']))) : '') . '</p>';
        $rowsHtml = ''; $no = 0;
        foreach ($g['cams'] as $c) {
            $r = $cl['results'][$c['id']] ?? null;
            if (!$r) continue;
            $st = (string)$r['status_snapshot'];
            $rowsHtml .= '<tr><td class="c">' . (++$no) . '</td><td>' . $h($c['number']) . '</td><td>' . $h($c['name'] ?: $c['location']) . '</td>'
                       . '<td class="c">' . ($c['channel'] ? 'ch ' . (int)$c['channel'] : ($c['ip'] !== '' ? $h($c['ip']) : '-')) . '</td>'
                       . '<td class="c' . (in_array($st, ['off', 'vl'], true) ? ' x' : '') . '">' . $h(cctvStateLabel($st)) . '</td>';
            foreach ($items as $it) {
                $v = (int)($r['marks'][$it['code']] ?? 0);
                $rowsHtml .= '<td class="' . ($v === 2 ? 'bad' : 'ok') . '">' . $mark($v) . '</td>';
            }
            $rowsHtml .= '<td>' . $h($r['note'] ?? '') . '</td></tr>';
        }
        if ($rowsHtml === '') {
            $docHtml .= '<div class="empty">' . $h(cL('Checklist NVR ini untuk tanggal & shift tersebut belum diisi.', 'No checklist saved for this NVR, date & shift.')) . '</div>';
        } else {
            $docHtml .= '<table class="g"><thead><tr><th>No</th><th>' . $h(cL('No Aset', 'Asset No')) . '</th><th>' . $h(cL('Nama CCTV', 'Camera name')) . '</th><th>' . $h($g['key'] ? 'Channel' : 'IP') . '</th><th>Status</th>';
            foreach ($items as $it) $docHtml .= '<th>' . $h($it['code']) . '</th>';
            $docHtml .= '<th>' . $h(cL('Keterangan', 'Note')) . '</th></tr></thead><tbody>' . $rowsHtml . '</tbody></table>'
                      . '<p class="legend">' . implode(' &bull; ', array_map(fn($it) => '<b>' . $h($it['code']) . '</b> ' . $h($it['label']), $items)) . ' &bull; ✓ OK &bull; ✗ ' . $h(cL('bermasalah', 'problem')) . '</p>';
        }
        $docHtml .= cctvSignHtml($groupSigners[$gk]['signers']);
    }
} else {
    $cams = $rep['cams'];
    $totalDown = array_sum(array_column($rep['down'], 'sec'));
    $docHtml .= '<p class="doc-title">' . $h(cL('LAPORAN BULANAN PEMERIKSAAN CCTV', 'MONTHLY CCTV INSPECTION REPORT')) . '</p>'
              . '<p class="doc-meta">' . $h(cL('Periode', 'Period')) . ': ' . $h(cctvMonthTitle($ym))
              . ($rep['last_day'] && $rep['last_day'] < $rep['days'] ? ' (' . $h(cL('s.d. tanggal ', 'up to day ')) . $rep['last_day'] . ')' : '')
              . ($nvrSel !== 'all' ? ' &bull; ' . $h($groups[(int)$nvrSel]['name']) : '') . '</p>'
              . '<table class="sum"><tr>'
              . '<td>' . $h(cL('Kamera', 'Cameras')) . '<br><b>' . count($cams) . '</b></td>'
              . '<td>' . $h(cL('Shift diperiksa', 'Shifts checked')) . '<br><b>' . $rep['done'] . ' / ' . $rep['due'] . '</b> (' . ($rep['due'] ? round($rep['done'] / $rep['due'] * 100) : 0) . '%)</td>'
              . '<td>' . $h(cL('Temuan masalah', 'Findings')) . '<br><b>' . $rep['issues'] . '</b></td>'
              . '<td>' . $h(cL('Kejadian CCTV mati', 'Downtime events')) . '<br><b>' . count($rep['events']) . '</b></td>'
              . '<td>' . $h(cL('Total waktu mati', 'Total downtime')) . '<br><b>' . $h(cctvDuration($totalDown)) . '</b></td>'
              . '</tr></table>';
    // Matriks kamera x tanggal
    $docHtml .= '<table class="g"><thead><tr><th>No</th><th>' . $h(cL('No Aset', 'Asset No')) . '</th><th>' . $h(cL('Nama CCTV', 'Camera name')) . '</th>';
    $sun = [];
    for ($d = 1; $d <= $rep['days']; $d++) {
        $sun[$d] = isset($rep['off'][$ym . '-' . str_pad((string)$d, 2, '0', STR_PAD_LEFT)]);   // hari libur (Sabtu/Minggu/libur manual)
        $docHtml .= '<th' . ($sun[$d] ? ' class="we"' : '') . '>' . $d . '</th>';
    }
    $docHtml .= '<th>' . $h(cL('Cek', 'Chk')) . '</th><th>' . $h(cL('Temuan', 'Find.')) . '</th><th>' . $h(cL('Mati', 'Down')) . '</th><th>Uptime</th></tr></thead><tbody>';
    $multiGroup = count($rep['groups']) > 1; $i = -1;
    foreach ($rep['groups'] as $grp) foreach ($grp['cams'] as $c) {
        $i++;
        if ($multiGroup && $c === $grp['cams'][0]) $docHtml .= '<tr class="grp"><td colspan="' . ($rep['days'] + 7) . '">' . $h($grp['name']) . '</td></tr>';
        $docHtml .= '<tr><td class="c">' . ($i + 1) . '</td><td>' . $h($c['number']) . '</td><td>' . $h($c['name'] ?: $c['location']) . '</td>';
        $n = 0; $b = 0;
        for ($d = 1; $d <= $rep['days']; $d++) {
            $we = $sun[$d] ? ' we' : '';
            $g = $rep['grid'][$c['id']][$d] ?? null;
            if ($d > $rep['last_day']) { $docHtml .= '<td class="na' . $we . '"></td>'; continue; }
            if (!$g) { $docHtml .= '<td class="na' . $we . '">' . ($sun[$d] ? 'L' : '–') . '</td>'; continue; }
            $n += $g['n']; $b += $g['bad'];
            $docHtml .= $g['bad'] ? '<td class="bad' . $we . '">✗</td>' : '<td class="ok' . $we . '">✓</td>';
        }
        $dn = $rep['down'][$c['id']] ?? null;
        $docHtml .= '<td class="c">' . $n . '</td><td class="' . ($b ? 'bad' : 'c') . '">' . $b . '</td><td class="c">' . ($dn ? $dn['n'] . 'x' : '-') . '</td>'
                  . '<td class="r">' . number_format(100 - ($dn['sec'] ?? 0) / $rep['period_sec'] * 100, 1) . '%</td></tr>';
    }
    $docHtml .= '</tbody></table><p class="legend">✓ ' . $h(cL('semua shift hari itu OK', 'all shifts OK that day')) . ' &bull; ✗ ' . $h(cL('ada temuan', 'finding')) . ' &bull; – ' . $h(cL('belum diperiksa', 'not checked'))
              . ' &bull; ' . $h(cL('L / kolom merah muda = hari libur (checklist tidak wajib)', 'L / pink = day off (checklist not required)')) . ' &bull; ' . $h(cL('Cek = jumlah shift diperiksa · Mati & Uptime dari monitoring otomatis', 'Chk = shifts checked · Down & Uptime from automatic monitoring')) . '</p>';
    $holList = cctvHolidayMap($db, $rep['start'], $rep['end']);
    if ($holList) {
        $docHtml .= '<p class="legend"><b>' . $h(cL('Hari libur', 'Holidays')) . ':</b> ' . $h(implode(', ', array_map(fn($d, $n) => date('d/m', strtotime($d)) . ' ' . $n, array_keys($holList), $holList))) . '</p>';
    }
    if ($rep['missed']) {
        $docHtml .= '<p class="legend"><b>' . $h(cL('Shift belum diisi', 'Missed shifts')) . ' (' . count($rep['missed']) . '):</b> ' . $h(implode(', ', array_slice($rep['missed'], 0, 40))) . (count($rep['missed']) > 40 ? ', ...' : '') . '</p>';
    }
    // Catatan temuan
    $docHtml .= '<p class="sec">' . $h(cL('Catatan temuan', 'Findings')) . '</p>';
    if ($rep['notes']) {
        $docHtml .= '<table class="g"><thead><tr><th>' . $h(cL('Tanggal', 'Date')) . '</th><th>Shift</th><th>' . $h(cL('Kamera', 'Camera')) . '</th><th>Item</th><th>' . $h(cL('Keterangan', 'Note')) . '</th></tr></thead><tbody>';
        foreach ($rep['notes'] as $nt) {
            $c = $rep['cam_by_id'][$nt['asset_id']] ?? null;
            $docHtml .= '<tr><td class="c">' . $h(date('d/m/Y', strtotime($nt['date']))) . '</td><td class="c">' . $h($nt['shift']) . '</td><td>' . $h($c ? $c['number'] . ' · ' . ($c['name'] ?: $c['location']) : '#' . $nt['asset_id']) . '</td>'
                      . '<td class="c">' . $h($nt['items']) . '</td><td>' . $h($nt['note']) . '</td></tr>';
        }
        $docHtml .= '</tbody></table>';
    } else {
        $docHtml .= '<p class="legend">' . $h(cL('Tidak ada temuan.', 'No findings.')) . '</p>';
    }
    // Log CCTV mati
    $docHtml .= '<p class="sec">' . $h(cL('Log CCTV mati', 'Downtime log')) . '</p>';
    if ($rep['events']) {
        $docHtml .= '<table class="g"><thead><tr><th>' . $h(cL('Mati sejak', 'Down since')) . '</th><th>' . $h(cL('Hidup lagi', 'Back up')) . '</th><th>' . $h(cL('Durasi', 'Duration')) . '</th><th>' . $h(cL('Kamera', 'Camera')) . '</th><th>' . $h(cL('Jenis', 'Type')) . '</th><th>' . $h(cL('Keterangan', 'Note')) . '</th></tr></thead><tbody>';
        foreach ($rep['events'] as $e) {
            $c = $rep['cam_by_id'][(int)$e['asset_id']] ?? null;
            $dur = $e['ended_at'] ? (int)$e['duration_sec'] : time() - strtotime((string)$e['started_at']);
            $docHtml .= '<tr><td class="c">' . $h(date('d/m/Y H:i', strtotime((string)$e['started_at']))) . '</td><td class="c">' . ($e['ended_at'] ? $h(date('d/m/Y H:i', strtotime((string)$e['ended_at']))) : '<span class="x">' . $h(cL('Masih mati', 'Still down')) . '</span>') . '</td>'
                      . '<td class="c">' . $h(cctvDuration($dur)) . '</td><td>' . $h($c ? $c['number'] . ' · ' . ($c['name'] ?: $c['location']) : '#' . $e['asset_id']) . '</td>'
                      . '<td class="c">' . $h(cctvStateLabel((string)$e['kind'])) . '</td><td>' . $h(trim(($e['note'] ?? '') . (($e['note'] ?? '') !== '' && ($e['detail'] ?? '') !== '' ? ' · ' : '') . ($e['detail'] ?? ''))) . '</td></tr>';
        }
        $docHtml .= '</tbody></table>';
    } else {
        $docHtml .= '<p class="legend">' . $h(cL('Tidak ada kamera mati di periode ini.', 'No downtime in this period.')) . '</p>';
    }
    // Laporan petugas
    $docHtml .= '<p class="sec">' . $h(cL('Laporan petugas', 'Officer reports')) . '</p>';
    if ($rep['reports']) {
        $docHtml .= '<table class="g"><thead><tr><th>' . $h(cL('Waktu lapor', 'Reported')) . '</th><th>' . $h(cL('Kamera', 'Camera')) . '</th><th>' . $h(cL('Masalah', 'Problem')) . '</th><th>' . $h(cL('Keterangan', 'Details')) . '</th><th>' . $h(cL('Pelapor', 'Reporter')) . '</th><th>Status</th><th>' . $h(cL('Tindak lanjut', 'Follow-up')) . '</th></tr></thead><tbody>';
        foreach ($rep['reports'] as $r) {
            $c = $rep['cam_by_id'][(int)$r['asset_id']] ?? null;
            $docHtml .= '<tr><td class="c">' . $h(date('d/m/Y H:i', strtotime((string)$r['reported_at']))) . '</td><td>' . $h($c ? $c['number'] . ' · ' . ($c['name'] ?: $c['location']) : '#' . $r['asset_id']) . '</td>'
                      . '<td>' . $h(cctvIssueLabel((string)$r['issue'])) . '</td><td>' . $h($r['note'] ?? '') . '</td><td>' . $h($r['reporter_name'] ?? '') . '</td>'
                      . '<td class="c' . ($r['status'] === 'done' ? '' : ' x') . '">' . $h($r['status'] === 'done' ? cL('Selesai', 'Done') : cL('Belum', 'Open')) . '</td>'
                      . '<td>' . $h(trim(($r['admin_note'] ?? '') . ($r['handled_at'] ? ' (' . date('d/m H:i', strtotime((string)$r['handled_at'])) . ')' : ''))) . '</td></tr>';
        }
        $docHtml .= '</tbody></table>';
    } else {
        $docHtml .= '<p class="legend">' . $h(cL('Tidak ada laporan petugas di periode ini.', 'No officer reports in this period.')) . '</p>';
    }
    $docHtml .= cctvSignHtml($signers);
}
$docHtml .= '<p class="legend" style="text-align:right;margin-top:6px">' . $h(documentCreatedAt()) . '</p>';

/* ---------------------------------------------------------------- Output: cetak / pratinjau */
if ($out === 'print' || $out === 'html') {
    $landscape = $mode === 'month';
    ?><!DOCTYPE html>
<html lang="<?= $h(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $h(str_replace('_', ' ', $baseName)) ?></title>
<style>
    @page { size: A4 <?= $landscape ? 'landscape' : 'portrait' ?>; }
    body { margin: 20px; }
    <?= cctvDocCss(false, $mode) ?>
    .no-print { margin-top: 18px; text-align: center; }
    .no-print button { background: #1F3DD1; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 13px; cursor: pointer; }
    @media print { body { margin: 0; } .no-print { display: none; } tr { page-break-inside: avoid; } }
<?= letterheadCss() ?></style>
</head>
<body>
    <?= letterheadOpen() ?>
    <?= $docHtml ?>
    <?= letterheadClose() ?>
    <?php if ($out === 'print'): ?>
    <div class="no-print"><button onclick="window.print()"><?= $h(cL('Cetak', 'Print')) ?></button></div>
    <script>window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 300); });</script>
    <?php endif; ?>
</body>
</html>
<?php
    exit;
}

/* ---------------------------------------------------------------- Output: PDF */
if ($out === 'pdf') {
    require_once __DIR__ . '/vendor/autoload.php';
    $opt = new \Dompdf\Options();
    $opt->set('isRemoteEnabled', true);
    $opt->set('defaultFont', 'DejaVu Sans');
    $pdf = new \Dompdf\Dompdf($opt);
    $pdf->setPaper('A4', $mode === 'month' ? 'landscape' : 'portrait');
    $pdf->loadHtml('<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' . cctvDocCss(true, $mode) . letterheadPdfCss() . '</style></head><body>'
        . letterheadPdfHtml() . $docHtml . '</body></html>', 'UTF-8');
    $pdf->render();
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    $pdf->stream($baseName . '.pdf', ['Attachment' => true]);
    exit;
}

/* ---------------------------------------------------------------- Output: Excel */
if ($out === 'xlsx') {
    require_once __DIR__ . '/vendor/autoload.php';
    require_once __DIR__ . '/includes/ext_phone.php';
    $ss = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $ss->getDefaultStyle()->getFont()->setName('Arial')->setSize(9);
    $C = fn(int $i) => \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i);
    $thin = ['borders' => ['allBorders' => ['borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN, 'color' => ['rgb' => '94A3B8']]]];
    $fill = fn(string $rgb) => ['fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['rgb' => $rgb]]];
    [$logoFile, $ornFile] = extLetterheadFiles();
    $addr = function_exists('letterheadAddress') ? letterheadAddress() : [];

    /** Kop + judul di baris atas sheet. Return baris berikutnya. */
    $kop = function ($sh, int $lastCol, string $title, string $sub) use ($C, $logoFile, $ornFile, $addr): int {
        $sh->getRowDimension(1)->setRowHeight(22); $sh->getRowDimension(2)->setRowHeight(22);
        if ($logoFile && is_file($logoFile)) {
            $d = new \PhpOffice\PhpSpreadsheet\Worksheet\Drawing();
            $d->setName('Logo'); $d->setPath($logoFile); $d->setHeight(50); $d->setCoordinates('A1'); $d->setOffsetX(2); $d->setOffsetY(2); $d->setWorksheet($sh);
        }
        if ($ornFile && is_file($ornFile)) {
            $d = new \PhpOffice\PhpSpreadsheet\Worksheet\Drawing();
            $d->setName('Ornamen'); $d->setPath($ornFile); $d->setHeight(50); $d->setCoordinates($C(max(1, $lastCol - 3)) . '1'); $d->setOffsetY(2); $d->setWorksheet($sh);
        }
        $sh->setCellValue('A4', $title);
        $sh->mergeCells('A4:' . $C($lastCol) . '4');
        $sh->getStyle('A4')->getFont()->setBold(true)->setSize(13);
        $sh->getStyle('A4')->getAlignment()->setHorizontal('center');
        $sh->setCellValue('A5', $sub . ($addr ? '  ·  ' . $addr[0] : ''));
        $sh->mergeCells('A5:' . $C($lastCol) . '5');
        $sh->getStyle('A5')->getAlignment()->setHorizontal('center');
        $sh->getStyle('A5')->getFont()->getColor()->setRGB('374151');
        return 7;
    };
    $signRows = function ($sh, int $row, int $lastCol, ?array $who = null) use ($C, $signers): void {
        $span = max(1, intdiv($lastCol, 3));
        foreach (($who ?? $signers) as $i => $s) {
            $c1 = 1 + $i * $span; $c2 = $i === 2 ? $lastCol : $c1 + $span - 1;
            foreach ([[$row, $s['label'] . ','], [$row + 4, $s['name']], [$row + 5, $s['title']]] as [$r, $v]) {
                $sh->setCellValue($C($c1) . $r, $v);
                $sh->mergeCells($C($c1) . $r . ':' . $C($c2) . $r);
                $sh->getStyle($C($c1) . $r)->getAlignment()->setHorizontal('center');
            }
            $sh->getStyle($C($c1) . ($row + 4))->getFont()->setBold(true);
            $sh->getStyle($C($c1) . ($row + 4) . ':' . $C($c2) . ($row + 4))->getBorders()->getTop()->setBorderStyle('thin');
        }
    };
    $header = function ($sh, int $row, array $cols) use ($C, $thin, $fill): void {
        foreach ($cols as $i => $v) $sh->setCellValue($C($i + 1) . $row, $v);
        $rng = 'A' . $row . ':' . $C(count($cols)) . $row;
        $sh->getStyle($rng)->applyFromArray($thin + $fill('E5ECF6'));
        $sh->getStyle($rng)->getFont()->setBold(true);
        $sh->getStyle($rng)->getAlignment()->setHorizontal('center')->setVertical('center')->setWrapText(true);
    };
    $setup = function ($sh, bool $landscape, int $lastCol, int $lastRow) use ($C): void {
        $ps = $sh->getPageSetup();
        $ps->setOrientation($landscape ? 'landscape' : 'portrait')->setPaperSize(\PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4);
        $ps->setFitToWidth(1)->setFitToHeight(0);
        $ps->setPrintArea('A1:' . $C($lastCol) . $lastRow);
        $sh->getPageMargins()->setLeft(0.4)->setRight(0.4)->setTop(0.4)->setBottom(0.4);
    };

    if ($mode === 'shift') {
        $gi = 0;
        foreach ($printGroups as $gk => $g) {
            $sh = $gi++ === 0 ? $ss->getActiveSheet() : $ss->createSheet();
            $sh->setTitle(mb_substr(preg_replace('#[\\/?*\[\]:]#', ' ', $g['name']), 0, 31) ?: 'Checklist');
            $off = $groupSigners[$gk]['officer'];
            $cols = array_merge(['No', cL('No Aset', 'Asset No'), cL('Nama CCTV', 'Camera name'), $g['key'] ? 'Channel' : 'IP', 'Status'], array_column($items, 'code'), [cL('Keterangan', 'Note')]);
            $last = count($cols);
            $row = $kop($sh, $last, cL('CHECKLIST PEMERIKSAAN CCTV', 'CCTV INSPECTION CHECKLIST') . ' - ' . $g['name'],
                $longDate($date) . '  ·  Shift ' . $shift . ($cl && $off['name'] !== '' ? '  ·  ' . cL('Petugas', 'Officer') . ': ' . $off['name'] : ''));
            $header($sh, $row, $cols);
            $start = $row + 1; $r = $start; $no = 0;
            foreach ($g['cams'] as $c) {
                $res = $cl['results'][$c['id']] ?? null;
                if (!$res) continue;
                $vals = [++$no, $c['number'], $c['name'] ?: $c['location'], $c['channel'] ? 'ch ' . $c['channel'] : ($c['ip'] ?: '-'), cctvStateLabel((string)$res['status_snapshot'])];
                foreach ($items as $it) $vals[] = $mark($res['marks'][$it['code']] ?? 0);
                $vals[] = (string)$res['note'];
                foreach ($vals as $i => $v) $sh->setCellValueExplicit($C($i + 1) . $r, (string)$v, \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
                foreach ($items as $k => $it) if ((int)($res['marks'][$it['code']] ?? 0) === 2) $sh->getStyle($C(6 + $k) . $r)->applyFromArray($fill('FEE2E2'))->getFont()->getColor()->setRGB('B91C1C');
                if (in_array($res['status_snapshot'], ['off', 'vl'], true)) $sh->getStyle('E' . $r)->getFont()->setBold(true)->getColor()->setRGB('B91C1C');
                $r++;
            }
            if ($r === $start) { $sh->setCellValue('A' . $r, cL('Checklist NVR ini belum diisi.', 'No checklist saved for this NVR.')); $r++; }
            $sh->getStyle('A' . $start . ':' . $C($last) . ($r - 1))->applyFromArray($thin);
            $sh->getStyle('A' . $start . ':A' . ($r - 1))->getAlignment()->setHorizontal('center');
            $sh->getStyle($C(4) . $start . ':' . $C($last - 1) . ($r - 1))->getAlignment()->setHorizontal('center');
            $sh->getColumnDimension('A')->setWidth(5); $sh->getColumnDimension('B')->setWidth(18); $sh->getColumnDimension('C')->setWidth(24);
            $sh->getColumnDimension('D')->setWidth(14); $sh->getColumnDimension('E')->setWidth(13);
            foreach ($items as $k => $it) $sh->getColumnDimension($C(6 + $k))->setWidth(5);
            $sh->getColumnDimension($C($last))->setWidth(40);
            $sh->getStyle($C($last) . $start . ':' . $C($last) . ($r - 1))->getAlignment()->setWrapText(true);
            $sh->setCellValue('A' . ($r + 1), implode('  ·  ', array_map(fn($it) => $it['code'] . ' = ' . $it['label'], $items)));
            $signRows($sh, $r + 3, $last, $groupSigners[$gk]['signers']);
            $setup($sh, false, $last, $r + 9);
        }
        $ss->setActiveSheetIndex(0);
    } else {
        // Sheet 1: Rekap (kamera x tanggal)
        // Rekap dipisah per NVR: 1 sheet "Rekap <NVR>" per NVR (juga saat memilih Semua NVR).
        $rekapUsed = [];
        $firstRekap = true;
        foreach ($rep['groups'] as $gk => $grp) {
        $gRep = count($rep['groups']) > 1 ? cctvMonthReport($db, $ym, (int)$gk) : $rep;
        $sh = $firstRekap ? $ss->getActiveSheet() : $ss->createSheet();
        $firstRekap = false;
        $rt = 'Rekap ' . mb_substr(trim(preg_replace('#[\\/?*\[\]:]+#', ' ', $grp['name'])), 0, 24);
        $rtx = $rt; $k = 2;
        while (isset($rekapUsed[mb_strtolower($rtx)])) $rtx = mb_substr($rt, 0, 28) . ' ' . $k++;
        $rekapUsed[mb_strtolower($rtx)] = true;
        $sh->setTitle($rtx);
        $cols = ['No', cL('No Aset', 'Asset No'), cL('Nama CCTV', 'Camera name')];
        for ($d = 1; $d <= $rep['days']; $d++) $cols[] = (string)$d;
        $cols = array_merge($cols, [cL('Cek', 'Chk'), cL('Temuan', 'Findings'), cL('Kali mati', 'Times down'), cL('Total mati', 'Downtime'), 'Uptime']);
        $last = count($cols);
        $row = $kop($sh, $last, cL('LAPORAN BULANAN PEMERIKSAAN CCTV', 'MONTHLY CCTV INSPECTION REPORT'),
            $grp['name'] . '  ·  ' . cL('Periode', 'Period') . ' ' . cctvMonthTitle($ym) . '  ·  ' . cL('Shift diperiksa', 'Shifts checked') . ' ' . $gRep['done'] . '/' . $gRep['due']
            . '  ·  ' . cL('Temuan', 'Findings') . ' ' . $gRep['issues'] . '  ·  ' . cL('Kejadian mati', 'Downtime events') . ' ' . count($gRep['events']));
        $header($sh, $row, $cols);
        $start = $row + 1; $r = $start;
        $i = -1;
        foreach ($grp['cams'] as $ci => $c) {
            $i++;
            $sh->setCellValue('A' . $r, $i + 1);
            $sh->setCellValueExplicit('B' . $r, $c['number'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            $sh->setCellValue('C' . $r, $c['name'] ?: $c['location']);
            $n = 0; $b = 0;
            for ($d = 1; $d <= $rep['days']; $d++) {
                $cell = $C(3 + $d) . $r;
                $g = $rep['grid'][$c['id']][$d] ?? null;
                if ($d > $rep['last_day']) continue;
                $isOff = isset($rep['off'][$ym . '-' . str_pad((string)$d, 2, '0', STR_PAD_LEFT)]);   // hari libur: merah muda, L merah
                if (!$g) {
                    $sh->setCellValue($cell, $isOff ? 'L' : '–');
                    if ($isOff) $sh->getStyle($cell)->applyFromArray($fill('FFE4E6'))->getFont()->setBold(true)->getColor()->setRGB('DC2626');
                    else $sh->getStyle($cell)->getFont()->getColor()->setRGB('9CA3AF');
                    continue;
                }
                $n += $g['n']; $b += $g['bad'];
                $sh->setCellValue($cell, $g['bad'] ? '✗' : '✓');
                if ($g['bad']) $sh->getStyle($cell)->applyFromArray($fill('FEE2E2'))->getFont()->setBold(true)->getColor()->setRGB('B91C1C');
                else { $sh->getStyle($cell)->getFont()->getColor()->setRGB('15803D'); if ($isOff) $sh->getStyle($cell)->applyFromArray($fill('FFE4E6')); }
            }
            $dn = $rep['down'][$c['id']] ?? null;
            $sh->setCellValue($C($rep['days'] + 4) . $r, $n);
            $sh->setCellValue($C($rep['days'] + 5) . $r, $b);
            $sh->setCellValue($C($rep['days'] + 6) . $r, $dn ? $dn['n'] : 0);
            $sh->setCellValue($C($rep['days'] + 7) . $r, cctvDuration((int)($dn['sec'] ?? 0)));
            $sh->setCellValue($C($rep['days'] + 8) . $r, round(100 - ($dn['sec'] ?? 0) / $rep['period_sec'] * 100, 1) / 100);
            if ($b) $sh->getStyle($C($rep['days'] + 5) . $r)->applyFromArray($fill('FEE2E2'));
            $r++;
        }
        $sh->getStyle('A' . $start . ':' . $C($last) . max($start, $r - 1))->applyFromArray($thin);
        $sh->getStyle('D' . $start . ':' . $C($last - 1) . max($start, $r - 1))->getAlignment()->setHorizontal('center');
        $sh->getStyle($C($last) . $start . ':' . $C($last) . max($start, $r - 1))->getNumberFormat()->setFormatCode('0.0%');
        for ($d = 1; $d <= $rep['days']; $d++) {
            $sh->getColumnDimension($C(3 + $d))->setWidth(3.6);
            if (isset($rep['off'][$ym . '-' . str_pad((string)$d, 2, '0', STR_PAD_LEFT)])) {
                $sh->getStyle($C(3 + $d) . $row)->applyFromArray($fill('FECDD3'))->getFont()->getColor()->setRGB('DC2626');
                // sel libur yang belum berjalan (sisa bulan) juga diberi warna
                for ($rr = $start; $rr < $r; $rr++) if ($d > $rep['last_day']) $sh->getStyle($C(3 + $d) . $rr)->applyFromArray($fill('FFE4E6'));
            }
        }
        $sh->getColumnDimension('A')->setWidth(4.5); $sh->getColumnDimension('B')->setWidth(17); $sh->getColumnDimension('C')->setWidth(22);
        foreach ([[4, 6], [5, 8], [6, 9], [7, 11], [8, 8]] as [$off, $w]) $sh->getColumnDimension($C($rep['days'] + $off))->setWidth($w);
        $sh->setCellValue('A' . ($r + 1), cL('✓ semua shift hari itu OK · ✗ ada temuan · – belum diperiksa · L = hari libur (tidak wajib) · Mati & Uptime dari monitoring otomatis', '✓ all shifts OK · ✗ finding · – not checked · L = day off · Downtime & Uptime from automatic monitoring'));
        if ($gRep['missed']) $sh->setCellValue('A' . ($r + 2), cL('Shift belum diisi: ', 'Missed shifts: ') . implode(', ', $gRep['missed']));
        $signRows($sh, $r + 4, $last);
        // Halaman 2 sheet ini: Log CCTV mati khusus kamera NVR ini (tidak dibuat sheet terpisah).
        $lr = $r + 11;
        $sh->setBreak('A' . ($lr - 1), \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::BREAK_ROW);
        $sh->setCellValue('A' . $lr, cL('LOG CCTV MATI', 'CCTV DOWNTIME LOG') . ' — ' . mb_strtoupper($grp['name']) . ' — ' . cctvMonthTitle($ym));
        $sh->mergeCells('A' . $lr . ':' . $C($last) . $lr);
        $sh->getStyle('A' . $lr)->getFont()->setBold(true)->setSize(12);
        $sh->getStyle('A' . $lr)->getAlignment()->setHorizontal('center');
        $lr += 2;
        // Kolom log digabung melintasi kolom tanggal yang sempit.
        $spans = [[1, 1], [2, 2], [3, 3], [4, 6], [7, 11], [12, 17], [18, 20], [21, 28], [29, $last]];
        $logCols = ['No', cL('Mati sejak', 'Down since'), cL('Hidup lagi', 'Back up'), cL('Durasi', 'Duration'), cL('No Aset', 'Asset No'), cL('Nama CCTV', 'Camera name'),
                    cL('Jenis', 'Type'), cL('Penyebab terdeteksi', 'Detected cause'), cL('Keterangan admin', 'Admin note')];
        $logRow = function (int $row, array $vals, bool $head = false) use ($sh, $spans, $C, $thin, $fill) {
            foreach ($vals as $k => $v) {
                [$a1, $a2] = $spans[$k];
                $sh->setCellValueExplicit($C($a1) . $row, (string)$v, \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
                if ($a2 > $a1) $sh->mergeCells($C($a1) . $row . ':' . $C($a2) . $row);
            }
            $rng = 'A' . $row . ':' . $C($spans[count($spans) - 1][1]) . $row;
            $sh->getStyle($rng)->applyFromArray($thin);
            $sh->getStyle($rng)->getAlignment()->setVertical('center')->setWrapText(true);
            if ($head) {
                $sh->getStyle($rng)->applyFromArray($fill('E5ECF6'));
                $sh->getStyle($rng)->getFont()->setBold(true);
                $sh->getStyle($rng)->getAlignment()->setHorizontal('center');
            }
        };
        $logRow($lr, $logCols, true);
        $lr++;
        $evs = $gRep['events'];
        if (!$evs) {
            $sh->setCellValue('A' . $lr, cL('Tidak ada kejadian CCTV mati pada bulan ini.', 'No downtime this month.'));
            $sh->mergeCells('A' . $lr . ':' . $C($last) . $lr);
            $sh->getStyle('A' . $lr)->getFont()->setItalic(true)->getColor()->setRGB('64748B');
            $lr++;
        }
        foreach ($evs as $ei => $e) {
            $c = $rep['cam_by_id'][(int)$e['asset_id']] ?? ['number' => '#' . $e['asset_id'], 'location' => '', 'name' => ''];
            $dur = $e['ended_at'] ? (int)$e['duration_sec'] : time() - strtotime((string)$e['started_at']);
            $logRow($lr, [$ei + 1, date('d/m/Y H:i', strtotime((string)$e['started_at'])),
                $e['ended_at'] ? date('d/m/Y H:i', strtotime((string)$e['ended_at'])) : cL('Masih mati', 'Still down'),
                cctvDuration($dur), $c['number'], $c['name'] ?: $c['location'], cctvStateLabel((string)$e['kind']),
                (string)($e['detail'] ?? ''), (string)($e['note'] ?? '')]);
            $sh->getStyle('A' . $lr)->getAlignment()->setHorizontal('center');
            if (!$e['ended_at']) $sh->getStyle('C' . $lr)->getFont()->setBold(true)->getColor()->setRGB('B91C1C');
            $lr++;
        }
        $setup($sh, true, $last, $lr);
        // Cetak: halaman 1 (rekap, s.d. tanda tangan) harus muat 1 lembar A4 landscape walau 64 kamera.
        // Baris kamera dibuat ringkas, lalu skala cetak dihitung dari tinggi & lebar halaman 1
        // (fit-to-page tidak dipakai karena Excel mengabaikan page break manual saat fit-to-page).
        $sh->getStyle('A' . $start . ':' . $C($last) . max($start, $r - 1))->getFont()->setSize(8);
        for ($x = $start; $x < $r; $x++) $sh->getRowDimension($x)->setRowHeight(12);
        $sh->getRowDimension($start - 1)->setRowHeight(24);
        $p1Last = $r + 10;
        $hTot = 0;
        for ($x = 1; $x <= $p1Last; $x++) { $rh = $sh->getRowDimension($x)->getRowHeight(); $hTot += $rh > 0 ? $rh : 12.75; }
        $wTot = 0;
        for ($x = 1; $x <= $last; $x++) { $cw = $sh->getColumnDimension($C($x))->getWidth(); $wTot += (($cw > 0 ? $cw : 9.14) * 7 + 5) * 0.75; }
        // Isi penuh lebar kertas: jika tinggi yang membatasi skala, kolom diperlebar sebanding sampai
        // rasio lebar : tinggi sama dengan kertas A4 landscape (sisi kanan tidak kosong).
        $wantW = $hTot * 770 / 520;
        if ($wTot < $wantW) {
            $f = $wantW / $wTot;
            for ($x = 1; $x <= $last; $x++) {
                $cd = $sh->getColumnDimension($C($x));
                $cw = $cd->getWidth() > 0 ? $cd->getWidth() : 9.14;
                $cd->setWidth(round((((($cw * 7 + 5) * $f) - 5) / 7), 2));
            }
            $wTot = 0;
            for ($x = 1; $x <= $last; $x++) $wTot += ($sh->getColumnDimension($C($x))->getWidth() * 7 + 5) * 0.75;
        }
        $scale = (int)floor(min(770 / max(1, $wTot), 520 / max(1, $hTot)) * 100);
        $sh->getPageSetup()->setScale(max(10, min(100, $scale)));
        $sh->getPageSetup()->setHorizontalCentered(true);
        $sh->freezePane('D' . $start);
        }   // akhir loop Rekap per NVR

        // Sheet 2: Temuan
        $sh2 = $ss->createSheet(); $sh2->setTitle(cL('Temuan', 'Findings'));
        $cols2 = [cL('Tanggal', 'Date'), 'Shift', cL('No Aset', 'Asset No'), cL('Nama CCTV', 'Camera name'), 'Item', 'Status', cL('Keterangan', 'Note')];
        $header($sh2, 1, $cols2);
        $r2 = 2;
        foreach ($rep['notes'] as $nt) {
            $c = $rep['cam_by_id'][$nt['asset_id']] ?? ['number' => '#' . $nt['asset_id'], 'location' => '', 'name' => ''];
            foreach ([date('d/m/Y', strtotime($nt['date'])), $nt['shift'], $c['number'], $c['name'] ?: $c['location'], $nt['items'], cctvStateLabel($nt['status']), $nt['note']] as $i => $v)
                $sh2->setCellValueExplicit($C($i + 1) . $r2, (string)$v, \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            $r2++;
        }
        if ($r2 > 2) $sh2->getStyle('A2:G' . ($r2 - 1))->applyFromArray($thin);
        foreach ([12, 10, 17, 24, 10, 13, 50] as $i => $w) $sh2->getColumnDimension($C($i + 1))->setWidth($w);
        $setup($sh2, true, 7, max(2, $r2));

        // Sheet 3: Detail checklist (semua centangan per shift)
        $sh3 = $ss->createSheet(); $sh3->setTitle('Detail Checklist');
        $cols3 = array_merge([cL('Tanggal', 'Date'), 'Shift', cL('Petugas', 'Officer'), cL('No Aset', 'Asset No'), cL('Nama CCTV', 'Camera name'), 'Status'], array_column($items, 'code'), [cL('Keterangan', 'Note'), cL('Foto', 'Photo')]);
        $header($sh3, 1, $cols3);
        $r3 = 2;
        foreach ($rep['detail'] as $dt) {
            $c = $rep['cam_by_id'][$dt['asset_id']] ?? ['number' => '#' . $dt['asset_id'], 'location' => '', 'name' => ''];
            $vals = [date('d/m/Y', strtotime($dt['date'])), $dt['shift'], $dt['user'], $c['number'], $c['name'] ?: $c['location'], cctvStateLabel($dt['status'])];
            foreach ($items as $it) $vals[] = $mark($dt['marks'][$it['code']] ?? 0);
            $vals[] = $dt['note']; $vals[] = $dt['photo'] !== '' ? 'Ada' : '';
            foreach ($vals as $i => $v) $sh3->setCellValueExplicit($C($i + 1) . $r3, (string)$v, \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            $r3++;
        }
        if ($r3 > 2) $sh3->getStyle('A2:' . $C(count($cols3)) . ($r3 - 1))->applyFromArray($thin);
        foreach ([12, 10, 20, 17, 24, 13] as $i => $w) $sh3->getColumnDimension($C($i + 1))->setWidth($w);
        foreach ($items as $k => $it) $sh3->getColumnDimension($C(7 + $k))->setWidth(5);
        $sh3->getColumnDimension($C(count($cols3) - 1))->setWidth(40);
        $sh3->freezePane('A2');
        $sh3->setAutoFilter('A1:' . $C(count($cols3)) . max(1, $r3 - 1));
        $setup($sh3, true, count($cols3), max(2, $r3));

        // Sheet 5: Laporan petugas
        $sh5 = $ss->createSheet(); $sh5->setTitle(cL('Laporan Petugas', 'Officer Reports'));
        $cols5 = [cL('Waktu lapor', 'Reported'), cL('No Aset', 'Asset No'), cL('Nama CCTV', 'Camera name'), cL('Masalah', 'Problem'), cL('Keterangan', 'Details'), cL('Pelapor', 'Reporter'), 'Status', cL('Ditangani', 'Handled'), cL('Tindak lanjut', 'Follow-up')];
        $header($sh5, 1, $cols5);
        $r5 = 2;
        foreach ($rep['reports'] as $rr) {
            $c = $rep['cam_by_id'][(int)$rr['asset_id']] ?? ['number' => '#' . $rr['asset_id'], 'location' => '', 'name' => ''];
            foreach ([date('d/m/Y H:i', strtotime((string)$rr['reported_at'])), $c['number'], $c['name'] ?: $c['location'], cctvIssueLabel((string)$rr['issue']), (string)($rr['note'] ?? ''),
                      (string)($rr['reporter_name'] ?? ''), $rr['status'] === 'done' ? cL('Selesai', 'Done') : cL('Belum ditangani', 'Open'),
                      $rr['handled_at'] ? ($rr['handled_name'] . ' ' . date('d/m/Y H:i', strtotime((string)$rr['handled_at']))) : '', (string)($rr['admin_note'] ?? '')] as $i => $v)
                $sh5->setCellValueExplicit($C($i + 1) . $r5, (string)$v, \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            $r5++;
        }
        if ($r5 > 2) $sh5->getStyle('A2:I' . ($r5 - 1))->applyFromArray($thin);
        foreach ([16, 17, 22, 26, 36, 20, 16, 26, 34] as $i => $w) $sh5->getColumnDimension($C($i + 1))->setWidth($w);
        $setup($sh5, true, 9, max(2, $r5));
        // Cover checklist: 1 sheet "VIEW_<NVR>" per NVR di depan (gambar multi-view + daftar kamera).
        require_once __DIR__ . '/includes/cctv_snapshot.php';
        $coverTmp = cctvAddCoverSheets($ss, $db, $ym, $rep['groups']);
        $ss->setActiveSheetIndex(0);
    }

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $baseName . '.xlsx"');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($ss))->save('php://output');
    foreach ($coverTmp ?? [] as $f) @unlink($f);
    exit;
}

/* ---------------------------------------------------------------- Halaman (pilih laporan + pratinjau) */
$months = [];
for ($i = 0; $i < 12; $i++) { $m = date('Y-m', strtotime(date('Y-m-01') . " -$i month")); $months[$m] = cctvMonthTitle($m); }
if (!isset($months[$ym])) $months[$ym] = cctvMonthTitle($ym);
$q = ($mode === 'month' ? ['mode' => 'month', 'ym' => $ym] : ['mode' => 'shift', 'date' => $date, 'shift' => $shift]) + ['nvr' => $nvrSel];
$url = fn(string $o) => 'cctv_report.php?' . http_build_query($q + ['out' => $o]);

$pageTitle = cL('Laporan CCTV', 'CCTV Reports');
$cctvTab = 'report';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="mb-3">
    <h1 class="text-xl font-semibold text-slate-800"><?= $h(cL('Cetak & laporan checklist', 'Print & checklist reports')) ?></h1>
    <p class="text-sm text-slate-500"><?= $h(isAdmin()
        ? cL('Per shift = pengganti form kertas (A4 portrait). Rekap bulanan = semua kamera × tanggal, temuan, dan log CCTV mati (A4 landscape).', 'Per shift = replaces the paper form. Monthly = all cameras × dates, findings and downtime log.')
        : cL('Cetak checklist per shift (pengganti form kertas).', 'Print the checklist per shift.')) ?></p>
</div>

<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<form method="get" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-end gap-3 text-sm">
    <?php if (isAdmin()): ?>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Jenis laporan', 'Report type')) ?></span>
        <select name="mode" class="border border-slate-300 rounded-lg px-2 py-1.5" onchange="this.form.submit()">
            <option value="month" <?= $mode === 'month' ? 'selected' : '' ?>><?= $h(cL('Rekap bulanan', 'Monthly summary')) ?></option>
            <option value="shift" <?= $mode === 'shift' ? 'selected' : '' ?>><?= $h(cL('Per shift', 'Per shift')) ?></option>
        </select></label>
    <?php else: ?><input type="hidden" name="mode" value="shift"><?php endif; ?>
    <?php if ($mode === 'month'): ?>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Bulan', 'Month')) ?></span>
            <select name="ym" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[160px]" onchange="this.form.submit()">
                <?php foreach ($months as $k => $label): ?><option value="<?= $h($k) ?>" <?= $k === $ym ? 'selected' : '' ?>><?= $h($label) ?></option><?php endforeach; ?>
            </select></label>
    <?php else: ?>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Tanggal', 'Date')) ?></span>
            <input type="date" name="date" value="<?= $h($date) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5" onchange="this.form.submit()"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">Shift</span>
            <select name="shift" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[130px]" onchange="this.form.submit()">
                <?php foreach ($shifts as $s): ?><option <?= $s === $shift ? 'selected' : '' ?>><?= $h($s) ?></option><?php endforeach; ?>
            </select></label>
    <?php endif; ?>
    <?php if (count($groups) > 1): ?>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">NVR</span>
        <select name="nvr" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[170px]" onchange="this.form.submit()">
            <option value="all" <?= $nvrSel === 'all' ? 'selected' : '' ?>><?= $h($mode === 'shift' ? cL('Semua NVR (1 halaman per NVR)', 'All NVRs (1 page per NVR)') : cL('Semua NVR', 'All NVRs')) ?></option>
            <?php foreach ($groups as $gk => $g): ?><option value="<?= $gk ?>" <?= $nvrSel === (string)$gk ? 'selected' : '' ?>><?= $h($g['name']) ?></option><?php endforeach; ?>
        </select></label>
    <?php endif; ?>
    <div class="flex flex-wrap gap-2 ml-auto">
        <?php if ($mode !== 'month'): // rekap bulanan: hanya Export Excel ?>
        <a href="<?= $h($url('print')) ?>" target="_blank" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium"><?= icon('printer') ?> <?= $h(cL('Cetak langsung', 'Print')) ?></a>
        <a href="<?= $h($url('pdf')) ?>" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 font-medium"><?= icon('download') ?> <?= $h(cL('Unduh PDF', 'Download PDF')) ?></a>
        <?php endif; ?>
        <a href="<?= $h($url('xlsx')) ?>" class="inline-flex items-center gap-2 <?= $mode === 'month' ? 'bg-green-600 hover:bg-green-700 text-white' : 'bg-white border border-slate-200 hover:bg-slate-50 text-slate-700' ?> rounded-lg px-4 py-2 font-medium"><?= icon('sheet') ?> Export Excel</a>
    </div>
</form>

<div class="bg-slate-200 rounded-xl p-3 overflow-x-auto">
    <iframe src="<?= $h($url('html')) ?>" title="<?= $h(cL('Pratinjau', 'Preview')) ?>" class="bg-white mx-auto block shadow" style="width: <?= $mode === 'month' ? '1180px' : '860px' ?>; max-width: none; height: 78vh; border: 0;"></iframe>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
