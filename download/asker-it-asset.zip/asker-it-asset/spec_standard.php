<?php
/**
 * Menu Standar Spesifikasi (khusus admin): atur spesifikasi minimal PC & laptop per departemen / jabatan,
 * lihat aset yang sudah / belum memenuhi, koreksi manual per aset, export Excel & laporan PDF (English).
 * Logika & tabel: includes/spec_standard.php.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/spec_standard.php';

$db = getDB();
$h  = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES);
specEnsure($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $act = (string)($_POST['act'] ?? '');
    $back = 'spec_standard.php';
    if ($act === 'tiers') {
        $r = specSaveTiers($db, $_POST);
        $_SESSION['spec_msg'] = $r;
    } elseif ($act === 'override') {
        $aid = (int)($_POST['asset_id'] ?? 0);
        if (!empty($_POST['reset'])) {
            $db->prepare("DELETE FROM spec_overrides WHERE asset_id = ?")->execute([$aid]);
            $_SESSION['spec_msg'] = ['ok' => true, 'msg' => spL('Koreksi manual dihapus, aset kembali ke data otomatis.', 'Manual corrections removed.')];
        } else {
            specSaveOverride($db, $aid, $_POST, (string)($_SESSION['full_name'] ?? ''));
            $_SESSION['spec_msg'] = ['ok' => true, 'msg' => spL('Perubahan aset disimpan.', 'Asset changes saved.')];
        }
        $back .= '?' . http_build_query(array_filter(['st' => $_POST['st'] ?? '', 'dept' => $_POST['dept'] ?? '', 'q' => $_POST['q'] ?? ''])) . '#devices';
    } elseif ($act === 'gpucopy') {
        $n = 0;
        foreach ((array)($_POST['pick'] ?? []) as $aid => $on) {
            $txt = trim((string)($_POST['gpu'][$aid] ?? ''));
            if ($on && $txt !== '') { specSetGpu($db, (int)$aid, $txt); $n++; }
        }
        $_SESSION['spec_msg'] = ['ok' => true, 'msg' => $n . spL(' isian VGA disalin dari aksesoris.', ' graphics card entries copied from accessories.')];
    }
    header('Location: ' . $back);
    exit;
}
$msg = $_SESSION['spec_msg'] ?? null;
unset($_SESSION['spec_msg']);

$view = ($_GET['view'] ?? '') === 'gpucopy' ? 'gpucopy' : '';
$rep  = specReport($db);
$tiers = $rep['tiers'];
$sum  = $rep['sum'];
$fSt   = in_array($_GET['st'] ?? '', ['ok', 'bad', 'warn'], true) ? $_GET['st'] : '';
$fDept = (string)($_GET['dept'] ?? '');
$fQ    = trim((string)($_GET['q'] ?? ''));
$rows = array_filter($rep['rows'], function ($x) use ($fSt, $fDept, $fQ) {
    if ($fSt !== '' && $x['r']['status'] !== $fSt) return false;
    if ($fDept !== '' && trim((string)$x['a']['department']) !== $fDept) return false;
    if ($fQ !== '') {
        $hay = mb_strtolower(implode(' ', [$x['a']['asset_number'], $x['a']['device_name'], $x['a']['owner_names'], $x['a']['department'], $x['a']['processor']]));
        if (mb_strpos($hay, mb_strtolower($fQ)) === false) return false;
    }
    return true;
});
$stUrl = fn(array $o) => 'spec_standard.php?' . http_build_query(array_filter(array_merge(['st' => $fSt, 'dept' => $fDept, 'q' => $fQ], $o), fn($v) => $v !== '')) . '#devices';
$badge = function (string $s) use ($h) {
    $c = ['ok' => 'bg-green-100 text-green-700', 'bad' => 'bg-red-100 text-red-700', 'warn' => 'bg-amber-100 text-amber-800'][$s];
    return '<span class="inline-block whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-semibold ' . $c . '">' . $h(specStatusLabel($s)) . '</span>';
};
$pct = $sum['n'] ? round($sum['ok'] / $sum['n'] * 100) : 0;

$pageTitle = spL('Standar Spesifikasi', 'Specification Standard');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="max-w-7xl mx-auto space-y-4">
<div class="flex flex-wrap items-end justify-between gap-3">
    <div>
        <h1 class="text-xl font-semibold text-slate-800"><?= $h(spL('Standar Spesifikasi PC & Laptop', 'PC & Laptop Specification Standard')) ?></h1>
        <p class="text-sm text-slate-500 max-w-3xl"><?= $h(spL('Atur spesifikasi minimal per kelompok. Semua Laptop & Desktop PC di data aset dicek otomatis terhadap standar pemakainya.', 'Set minimum specifications per group. Every laptop & desktop in the asset data is checked automatically against its user\'s standard.')) ?></p>
    </div>
    <div class="flex flex-wrap gap-2">
        <a href="spec_standard.php?view=gpucopy" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-3 py-2 text-sm font-medium"><?= icon('transfer', 'w-4 h-4') ?> <?= $h(spL('Salin VGA dari aksesoris', 'Copy GPU from accessories')) ?></a>
        <a href="spec_standard_export.php?fmt=xlsx" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-3 py-2 text-sm font-medium"><?= icon('sheet', 'w-4 h-4') ?> Export Excel</a>
        <a href="spec_standard_export.php?fmt=pdf" target="_blank" class="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-3 py-2 text-sm font-medium"><?= icon('download', 'w-4 h-4') ?> <?= $h(spL('Laporan PDF (English)', 'PDF report')) ?></a>
    </div>
</div>

<?php if ($msg): ?><div class="text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['msg']) ?></div><?php endif; ?>

<?php if ($view === 'gpucopy'): $cands = specGpuCopyCandidates($db); ?>
<div class="bg-white rounded-xl shadow-sm p-4">
    <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div>
            <h2 class="font-semibold text-slate-800"><?= $h(spL('Salin VGA dari aksesoris', 'Copy graphics card from accessories')) ?></h2>
            <p class="text-sm text-slate-500"><?= $h(spL('Kartu grafis yang terdeteksi di kolom Aksesoris, untuk aset yang isian VGA-nya masih kosong. Periksa, ubah teksnya bila perlu, lalu simpan. Isi aksesoris tidak diubah.', 'Graphics cards detected in the Accessories field for assets whose GPU field is still empty. Review, edit if needed, then save. Accessories are not changed.')) ?></p>
        </div>
        <a href="spec_standard.php" class="text-sm text-brand-700 hover:underline">&larr; <?= $h(spL('Kembali', 'Back')) ?></a>
    </div>
    <?php if (!$cands): ?>
        <p class="text-sm text-slate-500 italic py-6 text-center"><?= $h(spL('Tidak ada kartu grafis yang terdeteksi di aksesoris (atau semua sudah tersalin).', 'No graphics cards found in accessories (or all copied already).')) ?></p>
    <?php else: ?>
    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= $h(csrfToken()) ?>"><input type="hidden" name="act" value="gpucopy">
        <div class="overflow-x-auto border border-slate-200 rounded-lg">
        <table class="w-full text-sm">
            <thead class="bg-slate-50 text-left text-xs uppercase text-slate-500"><tr><th class="px-3 py-2 w-8"></th><th class="px-3 py-2"><?= $h(spL('Aset', 'Asset')) ?></th><th class="px-3 py-2"><?= $h(spL('Isi aksesoris', 'Accessories')) ?></th><th class="px-3 py-2"><?= $h(spL('Disimpan sebagai VGA', 'Save as GPU')) ?></th></tr></thead>
            <tbody>
            <?php foreach ($cands as $c): ?>
            <tr class="border-t border-slate-100 align-top">
                <td class="px-3 py-2"><input type="checkbox" name="pick[<?= (int)$c['id'] ?>]" value="1" class="w-4 h-4" <?= $c['unclear'] ? '' : 'checked' ?>></td>
                <td class="px-3 py-2"><b><?= $h($c['asset_number']) ?></b><div class="text-xs text-slate-500"><?= $h($c['device_name']) ?> · <?= $h($c['department']) ?></div></td>
                <td class="px-3 py-2 text-xs text-slate-600"><?= $h($c['accessories']) ?><?php if ($c['unclear']): ?><div class="mt-1 text-amber-700 font-medium"><?= $h(spL('Tanpa merek — pastikan ini kartu grafis, bukan kabel/port.', 'No brand — make sure this is a graphics card, not a cable/port.')) ?></div><?php endif; ?></td>
                <td class="px-3 py-2"><input name="gpu[<?= (int)$c['id'] ?>]" value="<?= $h($c['found']) ?>" class="w-full border rounded-lg px-2 py-1.5 text-sm"></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <div class="mt-3 flex justify-end"><button class="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= icon('check', 'w-4 h-4') ?> <?= $h(spL('Simpan yang dicentang', 'Save checked')) ?></button></div>
    </form>
    <?php endif; ?>
</div>
<?php else: ?>

<!-- 1. Standar -->
<form method="post" class="bg-white rounded-xl shadow-sm p-4" id="tierForm">
    <input type="hidden" name="csrf_token" value="<?= $h(csrfToken()) ?>"><input type="hidden" name="act" value="tiers">
    <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
        <h2 class="font-semibold text-slate-800">1 · <?= $h(spL('Spesifikasi minimal', 'Minimum specifications')) ?></h2>
        <span class="text-xs text-slate-500"><?= $h(spL('Semua bisa diubah: nama, kelompok, syarat. Tambah atau hapus standar sesuai kebutuhan.', 'Everything is editable. Add or remove standards as needed.')) ?></span>
    </div>
    <div class="grid gap-3 sm:grid-cols-2 xl:grid-cols-4" id="tierGrid">
        <?php foreach (array_merge($tiers, [null]) as $i => $t):
            $tpl = $t === null;
            $t = $t ?? ['id' => 0, 'name' => '', 'kind' => 'departemen', 'match_text' => '', 'cpu_min' => 'i3', 'gen_min' => 10, 'ram_min' => 8, 'os_min' => 11, 'need_pro' => 1, 'need_ssd' => 1, 'need_gpu' => 0];
            $k = $tpl ? '__I__' : $i; ?>
        <div class="tier-card border border-slate-200 rounded-xl p-3 bg-slate-50 space-y-2 text-sm<?= $tpl ? ' hidden' : '' ?>" <?= $tpl ? 'id="tierTpl"' : '' ?>>
            <input type="hidden" name="tid[<?= $k ?>]" value="<?= (int)$t['id'] ?>" <?= $tpl ? 'disabled' : '' ?>>
            <input type="hidden" name="tdel[<?= $k ?>]" value="" class="tier-del" <?= $tpl ? 'disabled' : '' ?>>
            <div class="flex gap-2 items-center">
                <input name="tname[<?= $k ?>]" value="<?= $h($t['name']) ?>" placeholder="<?= $h(spL('Nama standar', 'Standard name')) ?>" class="flex-1 min-w-0 border rounded-lg px-2 py-1.5 font-semibold" required <?= $tpl ? 'disabled' : '' ?>>
                <select name="tkind[<?= $k ?>]" class="tier-kind border rounded-lg px-1.5 py-1.5 text-xs" <?= $tpl ? 'disabled' : '' ?>>
                    <?php foreach (specKinds() as $kk => $kl): ?><option value="<?= $kk ?>" <?= $t['kind'] === $kk ? 'selected' : '' ?>><?= $h($kl) ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="grid grid-cols-2 gap-2">
                <label class="text-xs text-slate-500 font-medium"><?= $h(spL('Prosesor min.', 'Min. CPU')) ?>
                    <select name="tcpu[<?= $k ?>]" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800" <?= $tpl ? 'disabled' : '' ?>>
                        <?php foreach (array_keys(specCpuClasses()) as $ck): ?><option value="<?= $ck ?>" <?= $t['cpu_min'] === $ck ? 'selected' : '' ?>><?= $h(specCpuShort($ck)) ?></option><?php endforeach; ?>
                    </select></label>
                <label class="text-xs text-slate-500 font-medium"><?= $h(spL('Generasi min.', 'Min. generation')) ?>
                    <input type="number" min="1" max="30" name="tgen[<?= $k ?>]" value="<?= (int)$t['gen_min'] ?>" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800" <?= $tpl ? 'disabled' : '' ?>></label>
                <label class="text-xs text-slate-500 font-medium"><?= $h(spL('RAM min. (GB)', 'Min. RAM (GB)')) ?>
                    <input type="number" min="1" max="1024" name="tram[<?= $k ?>]" value="<?= (int)$t['ram_min'] ?>" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800" <?= $tpl ? 'disabled' : '' ?>></label>
                <label class="text-xs text-slate-500 font-medium"><?= $h(spL('OS min.', 'Min. OS')) ?>
                    <select name="tos[<?= $k ?>]" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800" <?= $tpl ? 'disabled' : '' ?>>
                        <?php foreach (specOsList() as $ov => $ol): ?><option value="<?= $ov ?>" <?= (int)$t['os_min'] === $ov ? 'selected' : '' ?>><?= $h(str_replace('Windows', 'Win', $ol)) ?></option><?php endforeach; ?>
                    </select></label>
            </div>
            <div class="flex flex-wrap gap-x-4 gap-y-1 text-sm">
                <label class="inline-flex items-center gap-1.5"><input type="checkbox" name="tpro[<?= $k ?>]" value="1" class="w-4 h-4" <?= $t['need_pro'] ? 'checked' : '' ?> <?= $tpl ? 'disabled' : '' ?>> <?= $h(spL('Edisi Pro', 'Pro edition')) ?></label>
                <label class="inline-flex items-center gap-1.5"><input type="checkbox" name="tssd[<?= $k ?>]" value="1" class="w-4 h-4" <?= $t['need_ssd'] ? 'checked' : '' ?> <?= $tpl ? 'disabled' : '' ?>> SSD</label>
                <label class="inline-flex items-center gap-1.5"><input type="checkbox" name="tgpu[<?= $k ?>]" value="1" class="w-4 h-4" <?= $t['need_gpu'] ? 'checked' : '' ?> <?= $tpl ? 'disabled' : '' ?>> VGA</label>
            </div>
            <label class="tier-match block text-xs text-slate-500 font-medium<?= $t['kind'] === 'umum' ? ' hidden' : '' ?>">
                <span class="lbl-dept<?= $t['kind'] === 'jabatan' ? ' hidden' : '' ?>"><?= $h(spL('Departemen (pisah koma)', 'Departments (comma separated)')) ?></span>
                <span class="lbl-pos<?= $t['kind'] !== 'jabatan' ? ' hidden' : '' ?>"><?= $h(spL('Kata kunci jabatan (pisah koma)', 'Position keywords (comma separated)')) ?></span>
                <input name="tmatch[<?= $k ?>]" value="<?= $h($t['match_text']) ?>" list="specDeptList" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800" <?= $tpl ? 'disabled' : '' ?>>
            </label>
            <p class="tier-umum text-xs text-slate-500<?= $t['kind'] === 'umum' ? '' : ' hidden' ?>"><?= $h(spL('Berlaku untuk semua yang tidak cocok dengan standar lain.', 'Applies to everyone not matched by another standard.')) ?></p>
            <div class="text-right"><button type="button" class="tier-remove text-xs font-semibold text-red-600 hover:underline"><?= $h(spL('Hapus standar', 'Remove')) ?></button></div>
        </div>
        <?php endforeach; ?>
        <button type="button" id="tierAdd" class="border-2 border-dashed border-slate-300 hover:border-brand-500 hover:text-brand-700 text-slate-500 rounded-xl min-h-[120px] text-sm font-semibold">+ <?= $h(spL('Tambah standar', 'Add standard')) ?></button>
    </div>
    <?php
    $deptOpts = [];
    try { $deptOpts = $db->query("SELECT DISTINCT department FROM assets WHERE department IS NOT NULL AND department <> '' ORDER BY department")->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $e) { }
    ?>
    <datalist id="specDeptList"><?php foreach ($deptOpts as $d): ?><option value="<?= $h($d) ?>"><?php endforeach; ?></datalist>
    <div class="flex flex-wrap items-center justify-between gap-2 mt-3">
        <p class="text-xs text-slate-500 max-w-3xl"><?= $h(spL('Urutan penentuan: standar yang dipilih manual untuk aset → departemen / jabatan yang cocok (bila cocok dengan dua, dipakai yang lebih tinggi) → standar Umum. AMD Ryzen disetarakan otomatis (Ryzen 3 = i3, dst.). Departemen ditulis persis seperti di data aset, contoh: ', 'Order: standard set manually on the asset → matching department / position (the higher one wins) → General. Departments must match the asset data, e.g. ')) . $h(implode(', ', array_slice($deptOpts, 0, 6))) ?></p>
        <button class="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= icon('check', 'w-4 h-4') ?> <?= $h(spL('Simpan standar', 'Save standards')) ?></button>
    </div>
</form>

<!-- 2. Ringkasan -->
<div class="bg-white rounded-xl shadow-sm p-4">
    <h2 class="font-semibold text-slate-800 mb-3">2 · <?= $h(spL('Hasil pengecekan', 'Check results')) ?></h2>
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <a href="<?= $h($stUrl(['st' => ''])) ?>" class="rounded-xl border border-slate-200 p-3 hover:bg-slate-50"><div class="text-2xl font-bold text-slate-800"><?= $sum['n'] ?></div><div class="text-xs text-slate-500"><?= $h(spL('Laptop & PC dicek', 'Laptops & PCs checked')) ?></div></a>
        <a href="<?= $h($stUrl(['st' => 'ok'])) ?>" class="rounded-xl border border-slate-200 p-3 hover:bg-slate-50"><div class="text-2xl font-bold text-green-700"><?= $sum['ok'] ?></div><div class="text-xs text-slate-500"><?= $h(specStatusLabel('ok')) ?></div></a>
        <a href="<?= $h($stUrl(['st' => 'bad'])) ?>" class="rounded-xl border border-slate-200 p-3 hover:bg-slate-50"><div class="text-2xl font-bold text-red-700"><?= $sum['bad'] ?></div><div class="text-xs text-slate-500"><?= $h(specStatusLabel('bad')) ?> · <?= $sum['replace'] ?> <?= $h(spL('perlu ganti unit', 'need replacement')) ?></div></a>
        <a href="<?= $h($stUrl(['st' => 'warn'])) ?>" class="rounded-xl border border-slate-200 p-3 hover:bg-slate-50"><div class="text-2xl font-bold text-amber-700"><?= $sum['warn'] ?></div><div class="text-xs text-slate-500"><?= $h(specStatusLabel('warn')) ?></div></a>
    </div>
    <?php if ($sum['n']): ?>
    <div class="mt-3 h-2 rounded-full bg-slate-100 overflow-hidden flex" aria-hidden="true">
        <span class="bg-green-600" style="width:<?= $sum['ok'] / $sum['n'] * 100 ?>%"></span><span class="bg-red-600" style="width:<?= $sum['bad'] / $sum['n'] * 100 ?>%"></span><span class="bg-amber-500" style="width:<?= $sum['warn'] / $sum['n'] * 100 ?>%"></span>
    </div>
    <div class="text-xs text-slate-500 mt-1"><?= $pct ?>% <?= $h(spL('perangkat sudah sesuai standar', 'of devices meet the standard')) ?></div>
    <?php endif; ?>
</div>

<!-- 3. Per departemen -->
<div class="bg-white rounded-xl shadow-sm p-4">
    <h2 class="font-semibold text-slate-800 mb-3">3 · <?= $h(spL('Per departemen', 'By department')) ?></h2>
    <div class="overflow-x-auto border border-slate-200 rounded-lg">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-left text-xs uppercase text-slate-500"><tr>
            <th class="px-3 py-2"><?= $h(spL('Departemen', 'Department')) ?></th><th class="px-3 py-2"><?= $h(spL('Standar dipakai', 'Standard')) ?></th>
            <th class="px-3 py-2 text-right"><?= $h(spL('Unit', 'Units')) ?></th><th class="px-3 py-2 text-right"><?= $h(spL('Sesuai', 'OK')) ?></th><th class="px-3 py-2 text-right"><?= $h(spL('Di bawah', 'Below')) ?></th><th class="px-3 py-2 text-right"><?= $h(spL('Belum lengkap', 'Incomplete')) ?></th><th class="px-3 py-2 text-right"><?= $h(spL('Ganti unit', 'Replace')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($rep['dept'] as $d => $o): ?>
        <tr class="border-t border-slate-100">
            <td class="px-3 py-2 font-medium"><a href="<?= $h($stUrl(['dept' => $d === '—' ? '' : $d, 'st' => ''])) ?>" class="hover:underline"><?= $h($d) ?></a></td>
            <td class="px-3 py-2 text-xs text-slate-500"><?= $h(implode(', ', array_keys($o['tiers']))) ?></td>
            <td class="px-3 py-2 text-right tabular-nums"><?= $o['n'] ?></td><td class="px-3 py-2 text-right tabular-nums text-green-700"><?= $o['ok'] ?></td><td class="px-3 py-2 text-right tabular-nums text-red-700"><?= $o['bad'] ?></td><td class="px-3 py-2 text-right tabular-nums text-amber-700"><?= $o['warn'] ?></td><td class="px-3 py-2 text-right tabular-nums"><?= $o['replace'] ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$rep['dept']): ?><tr><td colspan="7" class="px-3 py-6 text-center text-slate-400 italic"><?= $h(spL('Belum ada aset Laptop / Desktop PC.', 'No laptop / desktop assets yet.')) ?></td></tr><?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- 4. Daftar perangkat -->
<div class="bg-white rounded-xl shadow-sm p-4" id="devices">
    <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
        <h2 class="font-semibold text-slate-800">4 · <?= $h(spL('Daftar perangkat', 'Devices')) ?> <span class="text-sm font-normal text-slate-500">(<?= count($rows) ?>)</span></h2>
        <form method="get" class="flex flex-wrap gap-2 text-sm" action="spec_standard.php#devices">
            <select name="st" class="border rounded-lg px-2 py-1.5" onchange="this.form.submit()">
                <option value=""><?= $h(spL('Semua status', 'All statuses')) ?></option>
                <?php foreach (['bad', 'warn', 'ok'] as $s): ?><option value="<?= $s ?>" <?= $fSt === $s ? 'selected' : '' ?>><?= $h(specStatusLabel($s)) ?></option><?php endforeach; ?>
            </select>
            <select name="dept" class="border rounded-lg px-2 py-1.5" onchange="this.form.submit()">
                <option value=""><?= $h(spL('Semua departemen', 'All departments')) ?></option>
                <?php foreach (array_keys($rep['dept']) as $d): if ($d === '—') continue; ?><option value="<?= $h($d) ?>" <?= $fDept === $d ? 'selected' : '' ?>><?= $h($d) ?></option><?php endforeach; ?>
            </select>
            <input name="q" value="<?= $h($fQ) ?>" placeholder="<?= $h(spL('Cari aset / pemakai…', 'Search…')) ?>" class="border rounded-lg px-2 py-1.5 w-44">
            <button class="border rounded-lg px-3 py-1.5 bg-slate-50 hover:bg-slate-100"><?= icon('search', 'w-4 h-4') ?></button>
        </form>
    </div>
    <div class="overflow-x-auto border border-slate-200 rounded-lg">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-left text-xs uppercase text-slate-500"><tr>
            <th class="px-3 py-2"><?= $h(spL('Status', 'Status')) ?></th><th class="px-3 py-2"><?= $h(spL('Aset / pemakai', 'Asset / user')) ?></th><th class="px-3 py-2"><?= $h(spL('Standar', 'Standard')) ?></th>
            <th class="px-3 py-2"><?= $h(spL('Spesifikasi', 'Specification')) ?></th><th class="px-3 py-2"><?= $h(spL('Kekurangan & saran', 'Gaps & action')) ?></th><th class="px-3 py-2"></th>
        </tr></thead>
        <tbody>
        <?php foreach ($rows as $x): $a = $x['a']; $r = $x['r']; $e = $r['eff'];
            $o = $a['ov'];
            $edit = [
                'id' => (int)$a['id'], 'no' => $a['asset_number'], 'info' => trim($a['device_name'] . ' · ' . $a['owner_names'] . ' · ' . $a['department'], ' ·'),
                'tier' => (int)($o['tier_id'] ?? 0), 'auto_tier' => specTierFor(array_merge($a, ['ov' => []]), $tiers)[0]['name'],
                'cls' => $e['cpu']['cls'] ?? '', 'gen' => $e['cpu']['gen'] ?? '', 'ram' => $e['ram'] ?? '', 'ssd' => $e['ssd'] === null ? '' : ($e['ssd'] ? '1' : '0'),
                'osv' => $e['os']['v'] ?? '', 'pro' => !empty($e['os']['pro']) ? '1' : '0', 'gpu' => (string)($a['gpu'] ?? ''), 'gpu_acc' => $a['gpu'] === null && $e['gpu']['src'] === 'aksesoris' ? $e['gpu']['text'] : '',
                'status' => (string)($o['status'] ?? ''), 'action' => (string)($o['action_text'] ?? ''), 'note' => (string)($o['note'] ?? ''),
                'raw_cpu' => (string)$a['processor'], 'raw_ram' => (string)$a['ram'], 'raw_sto' => (string)$a['storage'], 'raw_os' => (string)$a['os_name'],
                'auto_action' => $r['action'], 'manual' => $r['manual'],
            ]; ?>
        <tr class="border-t border-slate-100 align-top">
            <td class="px-3 py-2"><?= $badge($r['status']) ?></td>
            <td class="px-3 py-2"><b><?= $h($a['asset_number']) ?></b><?php if ($r['manual']): ?> <span class="ml-1 rounded bg-brand-100 text-brand-700 px-1.5 py-0.5 text-[10px] font-bold">MANUAL</span><?php endif; ?>
                <div class="text-xs text-slate-500"><?= $h($a['device_name']) ?><?= $a['owner_names'] !== '' ? ' · ' . $h($a['owner_names']) : '' ?><br><?= $h($a['department']) ?><?= $a['positions'] ? ' · ' . $h(implode(', ', $a['positions'])) : '' ?></div></td>
            <td class="px-3 py-2"><?= $h($r['tier']['name']) ?><div class="text-xs text-slate-500"><?= $h($r['why']) ?></div></td>
            <td class="px-3 py-2"><?= $h(specSpecLine($e)) ?><div class="text-xs text-slate-400 max-w-xs truncate" title="<?= $h($a['processor']) ?>"><?= $h(trim(preg_replace('/\s+/', ' ', preg_replace('/\((R|TM)\)|CPU|@.*$/i', '', (string)$a['processor'])))) ?></div></td>
            <td class="px-3 py-2 text-xs">
                <?php foreach ($r['fails'] as $f): ?><div class="text-red-700"><?= $h($f) ?></div><?php endforeach; ?>
                <?php foreach ($r['miss'] as $f): ?><div class="text-amber-700"><?= $h($f) ?></div><?php endforeach; ?>
                <?php if ($r['status'] !== $r['auto_status']): ?><div class="text-slate-500"><?= $h(spL('Status diubah manual (otomatis: ', 'Status set manually (automatic: ') . specStatusLabel($r['auto_status']) . ')') ?></div><?php endif; ?>
                <?php if ($r['action'] !== ''): ?><div class="font-semibold text-slate-700 mt-0.5"><?= $h($r['action']) ?></div><?php endif; ?>
                <?php if ($r['note'] !== ''): ?><div class="mt-1 rounded bg-slate-50 border-l-2 border-brand-500 px-2 py-1 text-slate-700"><?= $h($r['note']) ?></div><?php endif; ?>
                <?php if (!$r['fails'] && !$r['miss'] && $r['action'] === '' && $r['note'] === ''): ?><span class="text-slate-400">—</span><?php endif; ?>
            </td>
            <td class="px-3 py-2"><button type="button" class="spec-edit inline-flex items-center gap-1 border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-semibold text-brand-700 hover:bg-slate-50" data-edit="<?= $h(json_encode($edit, JSON_UNESCAPED_UNICODE)) ?>"><?= icon('pencil', 'w-3.5 h-3.5') ?> Edit</button></td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="6" class="px-3 py-6 text-center text-slate-400 italic"><?= $h(spL('Tidak ada perangkat untuk filter ini.', 'No devices for this filter.')) ?></td></tr><?php endif; ?>
        </tbody>
    </table>
    </div>
    <p class="text-xs text-slate-500 mt-2"><?= $h(spL('Prosesor, RAM, penyimpanan, dan OS dibaca dari data aset; VGA dari isian VGA aset (atau kolom aksesoris bila kosong). Bila hasil baca kurang tepat, klik Edit. Koreksi disimpan terpisah, data aset asli tidak berubah — kecuali isian VGA yang memang milik aset.', 'CPU, RAM, storage and OS are read from the asset data; GPU from the asset GPU field (or accessories). Use Edit to correct; corrections are stored separately and the asset record is unchanged, except the GPU field.')) ?></p>
</div>

<!-- Modal edit aset -->
<div id="specModal" class="hidden fixed inset-0 z-50 items-center justify-center p-4 bg-slate-900/50">
    <form method="post" class="bg-white rounded-xl shadow-xl w-full max-w-xl max-h-[92vh] overflow-y-auto p-5 space-y-3 text-sm" id="specForm">
        <input type="hidden" name="csrf_token" value="<?= $h(csrfToken()) ?>"><input type="hidden" name="act" value="override"><input type="hidden" name="asset_id">
        <input type="hidden" name="st" value="<?= $h($fSt) ?>"><input type="hidden" name="dept" value="<?= $h($fDept) ?>"><input type="hidden" name="q" value="<?= $h($fQ) ?>">
        <div class="flex items-start justify-between gap-3">
            <div><h3 class="font-semibold text-slate-800 text-base">Edit <span data-f="no"></span></h3><div class="text-xs text-slate-500" data-f="info"></div></div>
            <button type="button" data-close class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button>
        </div>
        <div class="border-t pt-3"><div class="text-xs font-semibold uppercase text-slate-500 mb-1"><?= $h(spL('Standar yang dipakai', 'Standard to use')) ?></div>
            <select name="tier_id" class="w-full border rounded-lg px-2 py-1.5"><option value="0" data-auto></option><?php foreach ($tiers as $t): ?><option value="<?= (int)$t['id'] ?>"><?= $h($t['name']) ?></option><?php endforeach; ?></select></div>
        <div class="border-t pt-3 space-y-2"><div class="text-xs font-semibold uppercase text-slate-500"><?= $h(spL('Spesifikasi', 'Specification')) ?></div>
            <div class="grid grid-cols-2 gap-2">
                <label class="text-xs text-slate-500 font-medium"><?= $h(spL('Prosesor', 'CPU')) ?><select name="cpu_cls" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"><option value="">—</option><?php foreach (specCpuClasses() as $ck => $cl): ?><option value="<?= $ck ?>"><?= $h($cl) ?></option><?php endforeach; ?></select></label>
                <label class="text-xs text-slate-500 font-medium"><?= $h(spL('Generasi', 'Generation')) ?><input type="number" min="1" max="30" name="cpu_gen" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
            </div>
            <div class="text-[11px] text-slate-400"><?= $h(spL('Data aset: ', 'Asset data: ')) ?><span data-f="raw_cpu"></span></div>
            <div class="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <label class="text-xs text-slate-500 font-medium">RAM (GB)<input type="number" min="1" max="1024" name="ram_gb" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
                <label class="text-xs text-slate-500 font-medium"><?= $h(spL('Penyimpanan', 'Storage')) ?><select name="ssd" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"><option value="">—</option><option value="1">SSD</option><option value="0">HDD</option></select></label>
                <label class="text-xs text-slate-500 font-medium col-span-2 sm:col-span-1">VGA<input name="gpu" maxlength="150" placeholder="<?= $h(spL('mis. GTX 1650 / onboard', 'e.g. GTX 1650 / onboard')) ?>" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
            </div>
            <div class="text-[11px] text-slate-400"><?= $h(spL('Data aset: RAM ', 'Asset data: RAM ')) ?><span data-f="raw_ram"></span> · <span data-f="raw_sto"></span><span data-f="gpu_acc_wrap" class="hidden"> · <?= $h(spL('VGA dari aksesoris: ', 'GPU from accessories: ')) ?><span data-f="gpu_acc"></span></span></div>
            <div class="grid grid-cols-2 gap-2">
                <label class="text-xs text-slate-500 font-medium">OS<select name="os_ver" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"><option value="">—</option><?php foreach (specOsList() as $ov => $ol): ?><option value="<?= $ov ?>"><?= $h($ol) ?></option><?php endforeach; ?></select></label>
                <label class="text-xs text-slate-500 font-medium"><?= $h(spL('Edisi', 'Edition')) ?><select name="os_pro" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"><option value="1">Pro / Enterprise</option><option value="0">Home</option></select></label>
            </div>
            <div class="text-[11px] text-slate-400"><?= $h(spL('Data aset: ', 'Asset data: ')) ?><span data-f="raw_os"></span></div>
        </div>
        <div class="border-t pt-3 space-y-2"><div class="text-xs font-semibold uppercase text-slate-500"><?= $h(spL('Hasil', 'Result')) ?></div>
            <div class="grid grid-cols-2 gap-2">
                <label class="text-xs text-slate-500 font-medium">Status<select name="status" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"><option value=""><?= $h(spL('Otomatis', 'Automatic')) ?></option><option value="ok"><?= $h(spL('Sesuai (pengecualian)', 'Compliant (exception)')) ?></option><option value="bad"><?= $h(specStatusLabel('bad')) ?></option><option value="warn"><?= $h(specStatusLabel('warn')) ?></option></select></label>
                <label class="text-xs text-slate-500 font-medium"><?= $h(spL('Saran tindakan', 'Action')) ?><input name="action_text" maxlength="255" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
            </div>
            <label class="block text-xs text-slate-500 font-medium"><?= $h(spL('Catatan admin', 'Admin note')) ?><input name="note" maxlength="255" placeholder="<?= $h(spL('mis. Sudah diajukan pembelian, dipakai sampai Maret', 'e.g. Purchase requested, in use until March')) ?>" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
        </div>
        <div class="border-t pt-3 flex flex-wrap justify-between gap-2">
            <button type="submit" name="reset" value="1" class="border border-slate-200 rounded-lg px-3 py-2 font-medium text-slate-700 hover:bg-slate-50" onclick="return confirm(<?= $h(json_encode(spL('Hapus semua koreksi manual aset ini? (isian VGA tidak dihapus)', 'Remove all manual corrections for this asset? (GPU field is kept)'))) ?>)"><?= $h(spL('Kembalikan ke otomatis', 'Reset to automatic')) ?></button>
            <span class="flex gap-2"><button type="button" data-close class="border border-slate-200 rounded-lg px-3 py-2 font-medium text-slate-700 hover:bg-slate-50"><?= $h(spL('Batal', 'Cancel')) ?></button>
            <button class="bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2 font-medium"><?= $h(spL('Simpan', 'Save')) ?></button></span>
        </div>
    </form>
</div>

<script>
(function () {
    // ---- kartu standar: tambah / hapus / ganti jenis ----
    var grid = document.getElementById('tierGrid'), tpl = document.getElementById('tierTpl'), seq = 0;
    function syncKind(card) {
        var k = card.querySelector('.tier-kind').value;
        card.querySelector('.tier-match').classList.toggle('hidden', k === 'umum');
        card.querySelector('.tier-umum').classList.toggle('hidden', k !== 'umum');
        card.querySelector('.lbl-dept').classList.toggle('hidden', k === 'jabatan');
        card.querySelector('.lbl-pos').classList.toggle('hidden', k !== 'jabatan');
    }
    grid.addEventListener('change', function (e) { if (e.target.classList.contains('tier-kind')) syncKind(e.target.closest('.tier-card')); });
    grid.addEventListener('click', function (e) {
        var rm = e.target.closest('.tier-remove');
        if (rm) {
            var card = rm.closest('.tier-card');
            if (grid.querySelectorAll('.tier-card:not(.hidden)').length <= 1) { alert(<?= json_encode(spL('Minimal harus ada 1 standar.', 'At least one standard is required.')) ?>); return; }
            card.querySelector('.tier-del').value = '1';
            card.querySelectorAll('[required]').forEach(function (x) { x.required = false; });
            card.classList.add('hidden');
        }
    });
    document.getElementById('tierAdd').addEventListener('click', function () {
        var key = 'n' + (seq++), c = tpl.cloneNode(true);
        c.removeAttribute('id'); c.classList.remove('hidden');
        c.querySelectorAll('[name]').forEach(function (x) { x.name = x.name.replace('__I__', key); x.disabled = false; });
        grid.insertBefore(c, this);
        c.querySelector('input[name^="tname"]').focus();
    });

    // ---- modal edit aset ----
    var modal = document.getElementById('specModal'), F = document.getElementById('specForm');
    function show(on) { modal.classList.toggle('hidden', !on); modal.classList.toggle('flex', on); }
    document.addEventListener('click', function (e) {
        var b = e.target.closest('.spec-edit');
        if (b) {
            var d = JSON.parse(b.dataset.edit);
            F.asset_id.value = d.id;
            F.querySelector('[data-auto]').textContent = <?= json_encode(spL('Otomatis', 'Automatic')) ?> + ' (' + d.auto_tier + ')';
            F.tier_id.value = d.tier || 0;
            F.cpu_cls.value = d.cls || ''; F.cpu_gen.value = d.gen === null ? '' : d.gen;
            F.ram_gb.value = d.ram === null ? '' : d.ram; F.ssd.value = d.ssd; F.gpu.value = d.gpu;
            F.os_ver.value = d.osv === null ? '' : d.osv; F.os_pro.value = d.pro;
            F.status.value = d.status; F.action_text.value = d.action; F.note.value = d.note;
            F.action_text.placeholder = <?= json_encode(spL('Otomatis: ', 'Automatic: ')) ?> + (d.auto_action || '—');
            ['no', 'info', 'raw_cpu', 'raw_ram', 'raw_sto', 'raw_os', 'gpu_acc'].forEach(function (k) {
                F.querySelector('[data-f="' + k + '"]').textContent = d[k] !== '' ? d[k] : <?= json_encode(spL('(kosong)', '(empty)')) ?>;
            });
            F.querySelector('[data-f="gpu_acc_wrap"]').classList.toggle('hidden', !d.gpu_acc);
            show(true);
        }
        if (e.target.closest('[data-close]')) show(false);
    });
    modal.addEventListener('click', function (e) { if (e.target === modal) show(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') show(false); });
})();
</script>
<?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
