# Panduan Menu Jaringan

Menu **Jaringan** (khusus admin) dipakai untuk mengecek koneksi semua aset yang punya IP address, melihat topologi jaringan, dan menemukan perangkat yang belum terdaftar.

Pengecekan **hanya berjalan saat tombol ditekan**. Tidak ada pengecekan otomatis terjadwal dan tidak ada email.

## 1. Persiapan (sekali saja)

1. **Daftarkan perangkat jaringan di menu Aset.**
   - Router, switch, hub, access point, dan firewall didaftarkan seperti aset biasa.
   - Kategori harus mengandung kata *Router*, *Switch*, *Hub*, *Firewall*, *Gateway*, atau *MikroTik* agar dikenali sebagai perangkat jaringan.
   - Switch biasa (unmanaged) tidak perlu IP: biarkan kolom IP kosong.
2. **Isi tab Data koneksi.**
   - Untuk setiap aset, pilih switch/router tempatnya tersambung. Kolom port boleh diisi (mis. `5`, `eth2`).
   - Agar cepat, pakai **Isi massal**: semua aset di satu lokasi langsung dihubungkan ke switch yang dipilih. Switch/router sendiri diatur satu per satu.
   - Sistem menolak sambungan yang melingkar, misalnya router dihubungkan ke switch yang ada di bawahnya.
   - **Cari & pilih banyak:** di atas tabel ada kotak cari (nama, no aset, IP, jenis, lokasi, "terhubung ke") dan filter Jenis/Lokasi. Centang beberapa baris atau centang judul kolom untuk memilih semua yang tampil, lalu **Terapkan** (hubungkan semuanya ke satu switch/router) atau **Lepas koneksi**.
3. **Opsional, tab Pengaturan:**
   - Batas "Lambat" (bawaan: ping ≥ 100 ms atau paket hilang ≥ 5%).
   - Jumlah paket ping.
   - Daftar subnet untuk scan.

### Form & import khusus Perangkat Jaringan

- Pilih Jenis Aset Switch / Hub / Router / Access Point: form berganti ke isian khusus (Nama, Lokasi, IP, Brand, Type, Jumlah port, Terhubung ke, Port uplink, Serial Number, Tanggal Pembelian, Status). "Terhubung ke" sama dengan data di tab Data koneksi.
- Import banyak perangkat sekaligus: menu Asset > Import dari Excel > **Import Perangkat Jaringan** (atau buka `net_import.php`). Alurnya sama dengan Import CCTV: unduh template, isi, upload, cek preview, Simpan.
- Kategori Switch, Hub, Router, Access Point dibuat otomatis saat import (atau klik "Tambahkan sekarang" di halaman import).
- Router dengan banyak segmen: kolom IP Address di Excel boleh berisi beberapa IP dipisah koma, boleh dengan /24 (mis. `192.168.1.1/24, 192.168.2.1/24`). Di form, isi di kotak **Semua IP / segmen** (satu per baris). IP di segmen server otomatis menjadi **IP utama** untuk cek ping; semua IP tampil di detail aset, topologi & PDF, dan dikenali saat Scan.
- "Terhubung ke" yang berisi perangkat itu sendiri diabaikan (dianggap perangkat paling atas).

### Port & koneksi tambahan

- **Jumlah port LAN (RJ45)** dan **Jumlah port SFP** diisi di form perangkat jaringan (atau kolom Jumlah Port & Port SFP di Excel). Dari angka ini dibuat daftar pilihan port: `eth1…` untuk semua router/switch/hub/AP, ditambah `sfp1…`. Nama port tetap boleh diketik manual.
- Nama port lama (`ether8`, `port8`, atau angka saja `8`) otomatis disimpan sebagai `eth8`. Data lama bisa diseragamkan sekali klik lewat tombol **Ubah sekarang** di tab Data koneksi (muncul bila masih ada nama format lama).
- Setiap sambungan punya dua port: **Port di perangkat atas** dan **Port di perangkat ini** (mis. CCR2004 `eth16` ⇄ RB5009 `eth8`). Port yang sudah terpakai diberi keterangan "terpakai: …" di daftar pilihan.
- **Koneksi tambahan** (tab Data koneksi): untuk perangkat yang tersambung ke lebih dari satu switch/router, mis. RB5009 ke CCR2004 (jalur utama) dan ke Fortinet (koneksi tambahan). Digambar garis putus-putus biru di topologi, ikut di PDF & detail aset.
- Koneksi tambahan juga untuk **NVR / server / PC dengan 2 port LAN**: isi LAN 1 sebagai "Terhubung ke" di tabel (mis. Switch Core, port `eth5 ⇄ eth1`), lalu LAN 2 di kotak Koneksi tambahan (pilih NVR di grup "Aset lain", port `eth2`, juga terhubung ke switch/router kedua). Salah satu sisi koneksi tambahan harus switch / router / AP / firewall.
- Antar 2 perangkat boleh **lebih dari 1 kabel** (mis. switch PoE `sfp1` ⇄ switch FO `eth7, eth8` dan `sfp2` ⇄ `eth3, eth4`). Yang ditolak hanya koneksi yang perangkat **dan** port-nya sama persis. Beberapa port untuk 1 koneksi ditulis dipisah koma (`port3, port4` otomatis menjadi `eth3, eth4`).
- **Switch FO / media converter** (nama atau jenis mengandung *FO*, *fiber*, *optik*, *converter*): hanya meneruskan LAN ↔ fiber optik, jadi boleh dipakai banyak koneksi tanpa batas, termasuk port yang sama, dan port-nya tidak ditandai "terpakai".
- Di Excel, kolom **Koneksi Tambahan** diisi `Nama perangkat (port perangkat tujuan ⇄ port perangkat ini)`, pisahkan beberapa dengan `;`, mis. `Firewall (eth1 ⇄ eth1)`. Ketik `-` untuk menghapus semua koneksi tambahan perangkat itu.

### Printer: koneksi & kepemilikan

- Form printer punya pilihan **Kepemilikan** (milik perusahaan / sewa + nama vendor sewa) dan **Koneksi** (LAN / USB). IP hanya diisi untuk LAN; printer USB tidak ikut dicek di menu Jaringan.

## 2. Cek jaringan

- Klik **Cek sekarang**. Semua aset yang tampil (sesuai filter) dicek per 8 aset, dengan progress bar.
  - Centang beberapa baris jika hanya ingin mengecek sebagian.
  - Tombol **Cek ulang** di tiap baris mengecek satu aset saja.
- Status:
  - **Normal**
  - **Lambat**: ping tinggi atau ada paket hilang.
  - **Mati**: tidak membalas ping maupun port.
- Jika ping diblokir firewall (bawaan Windows), sistem mencoba port TCP:
  - PC/laptop: 445/3389
  - Printer: 9100
  - CCTV/NVR: 80/554
  - Jika salah satu port terbuka, aset dianggap hidup ("Ping diblokir, port … terbuka").
- **Switch diduga mati**: jika semua aset (minimal 2) di bawah sebuah switch tanpa IP mati bersamaan, muncul peringatan merah: *"Kemungkinan Switch … mati atau kabel uplink-nya putus"*.
- **Pantau selama halaman dibuka**: centang untuk mengecek ulang otomatis tiap 1 menit, hanya selama halaman ini terbuka di browser.
- Setiap kali selesai cek, ringkasannya tersimpan di **Riwayat pengecekan**.

## 3. Topologi

Diagram digambar otomatis dari Data koneksi:

- Hijau = normal, kuning = lambat, merah = mati / diduga mati.
- Garis merah putus-putus = jalur yang terputus.
- Aset yang belum dihubungkan tampil di bawah **Belum dihubungkan**.
- Kotak perangkat menampilkan **semua IP yang terdaftar**, satu per baris (IP utama paling atas), diikuti Brand / Type untuk router, switch, hub, dan AP. Kotak otomatis lebih tinggi sesuai jumlah IP, termasuk di Cetak / PDF.
- **Kotak per lokasi** (centang di samping filter lokasi, aktif bawaan): perangkat dengan lokasi sama dibungkus kotak berwarna berlabel "Lokasi · jumlah perangkat". Warna tetap per lokasi. Lokasi yang sama bisa muncul lebih dari sekali bila perangkatnya di bawah switch berbeda. Aset tanpa lokasi tidak diberi kotak. Pilihan ini ikut ke Cetak / PDF.
  - Huruf besar/kecil dan spasi tidak dibedakan (`Ruang Server` = `RUANG SERVER`); label memakai penulisan yang paling banyak dipakai.
  - Di bawah satu switch, aset yang lokasinya sama dengan switch didahulukan, dan cabang yang seluruh isinya satu lokasi (mis. server) ditaruh sebelum switch yang cabangnya berisi lokasi lain, supaya satu lokasi tetap dalam satu kotak.
  - Aset yang **belum dihubungkan** (belum diisi "Terhubung ke") otomatis ditaruh di kotak lokasinya, di bawah switch/router berlokasi sama. Kotaknya bergaris putus-putus tanpa garis koneksi. Bila lokasi aset diganti, posisinya ikut pindah. Aset yang lokasinya tidak ada di diagram tetap tampil di bagian **Belum dihubungkan**.
- Klik kotak perangkat untuk melihat detailnya. Filter lokasi tersedia.
- **Cari perangkat / aset**: ketik nama, IP, no aset, atau brand; kotak yang cocok diberi bingkai biru, yang lain diredupkan, dan layar langsung bergulir ke hasil pertama.

- **Warna kabel per switch / router** (centang di samping "Kotak per lokasi", aktif bawaan): tiap switch / router yang punya perangkat di bawahnya mendapat 1 warna; semua garis koneksi utama darinya memakai warna itu, dan kotaknya diberi strip warna yang sama di sisi kiri. Merah putus-putus tetap = putus, biru putus-putus tetap = koneksi tambahan. Pilihan ini ikut ke Cetak / PDF.

### Geser bebas (atur posisi sendiri, seperti Visio)

- Klik **✥ Geser bebas** di tab Topologi, lalu tahan klik pada kotak dan geser ke mana saja. Garis koneksi, koneksi tambahan, dan kotak lokasi ikut menyesuaikan.
- Tahan **Shift** saat menggeser untuk ikut memindahkan seluruh cabang di bawahnya.
- Klik **Simpan posisi**. Susunan dipakai setiap kali topologi dibuka dan ikut ke Cetak / PDF (gambar diperkecil selebar kertas, dipotong per halaman di sela kotak).
- **Selesai / batal** menutup mode ini; **Kembali ke susunan otomatis** menghapus semua posisi manual.
- Dengan susunan bebas, kotak lokasi menjadi 1 kotak per lokasi yang membungkus semua perangkat di lokasi itu.
- Perangkat baru yang ditambahkan setelah posisi disimpan muncul di posisi otomatisnya; geser bila bertumpuk.

### Hubungkan & ubah koneksi langsung dari topologi

- **Hubungkan**: klik tombol **🔗 Hubungkan** di tab Topologi, klik perangkat A, lalu klik perangkat B. Pilih jenisnya: A terhubung ke B, B terhubung ke A (koneksi utama / "Terhubung ke"), atau **Koneksi tambahan** (kabel ke-2, uplink cadangan), lalu isi port di masing-masing perangkat (boleh dikosongkan). Batal: klik perangkat A lagi atau tekan **Esc**.
- Dari panel detail perangkat juga ada tombol **Hubungkan ke perangkat lain**, **Lepas dari …**, dan **Hapus koneksi tambahan**.
- **Klik garis koneksi** (garis utama maupun biru putus-putus) untuk mengubah port-nya, atau melepas / menghapus koneksi itu.
- **Peringatan port bentrok**: bila port yang diisi sudah dipakai perangkat lain di switch yang sama, muncul peringatan kuning. Ganti port-nya, atau klik **Tetap simpan** bila memang benar (mis. ada hub / switch kecil). Perangkat FO / converter tidak dicek.
- **Peta port**: klik switch / router, di panel detail tampil kotak tiap port: hijau = terpakai, merah = perangkat di port itu mati, abu-abu putus-putus = kosong. Klik kotak port untuk melompat ke perangkatnya. Agar port kosong ikut tampil, isi **Jumlah port LAN** dan **Port SFP** di data aset.
- **Riwayat perubahan koneksi** (di bawah topologi): siapa mengubah apa dan kapan — termasuk perubahan dari tab Data koneksi. Tombol **Batalkan perubahan terakhir** mengembalikan koneksi ke kondisi sebelum perubahan terakhir (bisa diulang untuk perubahan sebelumnya).
- **Simpan gambar (PNG)**: menyimpan topologi seperti yang tampil di layar menjadi file gambar, untuk dikirim lewat WA / email atau ditempel di laporan.

### Cetak / Simpan PDF topologi

- Di tab Topologi pilih lokasi, **Isi cetakan** (semua aset, atau perangkat jaringan saja agar ringkas) dan **Kertas** (A4 tegak / mendatar).
- **Cetak** membuka halaman cetak dengan kop surat dan langsung memunculkan dialog Print. **Simpan PDF** langsung mengunduh file PDF.
- Topologi yang panjang otomatis dipotong per halaman; halaman terakhir berisi daftar perangkat jaringan (terhubung ke mana, jumlah aset di bawahnya, status cek terakhir).

## 4. Scan jaringan

1. Pilih subnet (format `192.168.1.0/24`), lalu klik **Mulai scan**.
2. Sistem mengirim 1 paket ping ke 254 alamat, lalu membaca tabel ARP server. Prosesnya sekitar 10–30 detik.
3. Hasil scan:
   - **Tidak terdaftar** (kuning): perangkat aktif yang IP-nya belum ada di menu Aset, misalnya perangkat baru, HP karyawan, atau perangkat asing.
   - **Aset terdaftar yang tidak ditemukan**: aset yang IP-nya ada di menu Aset tetapi tidak menjawab.
4. Batasan:
   - MAC address hanya terlihat untuk perangkat di subnet yang sama dengan server.
   - Kolom **Perkiraan merek** butuh file `oui.csv` dari https://standards-oui.ieee.org/oui/oui.csv, disimpan sebagai `includes\data\oui.csv`.
5. Hasil scan terakhir tiap subnet disimpan dan tampil lagi saat halaman dibuka.

## 5. Beban jaringan

- 1 kali cek 300 aset dengan 4 paket ping menghasilkan sekitar 180 KB lalu lintas LAN.
- 1 kali scan /24 menghasilkan sekitar 20 KB.
- Di luar saat tombol ditekan tidak ada lalu lintas sama sekali.

## 6. Kebutuhan server

- PHP harus boleh menjalankan `ping.exe` dan `arp.exe` lewat `proc_open`. Fungsi ini sudah aktif karena dipakai live preview CCTV.
- Tabel baru dibuat otomatis saat menu pertama kali dibuka (`CREATE TABLE IF NOT EXISTS`): `net_links`, `net_status`, `net_checks`, dan tabel pendukung lain (mis. `net_topo_pos` untuk posisi Geser bebas, `net_link_log` untuk riwayat perubahan koneksi). Tabel lama tidak diubah.
