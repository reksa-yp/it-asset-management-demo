<?php
/**
 * Signature Email: user membuat gambar signature (JPG) dari template perusahaan.
 * Nama, departemen dan jabatan terisi otomatis dari akun (boleh diketik manual), nomor handphone diisi user.
 * Logo, nama perusahaan, T1, T2 dan alamat diatur ADMIN (lihat includes/signature.php); user tidak bisa
 * mengubahnya. Tata letak dan hiasan digambar aplikasi, warnanya otomatis mengikuti warna logo. Gambar dibuat di browser (canvas), tidak ada tabel database yang dipakai.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/signature.php';
requireLogin();

// ===== Admin menyimpan pengaturan template =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAdmin();
    csrfCheck();
    $cur = signatureSettings();
    $msg = ['ok' => true, 'text' => t('sig_set_saved')];
    $logo = $cur['logo'];
    if (!empty($_POST['remove_logo'])) { deleteSignatureLogo($logo); $logo = ''; }
    $up = handleSignatureUpload('logo');
    if (!$up['ok']) {
        $msg = ['ok' => false, 'text' => t($up['error'])];
    } elseif ($up['file'] !== '') {
        deleteSignatureLogo($logo);
        $logo = $up['file'];
    }
    $addr = preg_split('/\r\n|\r|\n/', trim((string)($_POST['address'] ?? '')), 2);
    if ($msg['ok'] && !saveSignatureSettings([
        'company' => $_POST['company'] ?? '', 't1' => $_POST['t1'] ?? '', 't2' => $_POST['t2'] ?? '',
        'addr1' => $addr[0] ?? '', 'addr2' => $addr[1] ?? '',
        'logo' => $logo,
    ])) {
        $msg = ['ok' => false, 'text' => t('sig_set_failed')];
    }
    $_SESSION['sig_msg'] = $msg;
    header('Location: email_signature.php');
    exit;
}

$sigMsg = $_SESSION['sig_msg'] ?? null;
unset($_SESSION['sig_msg']);

$sig = signatureSettings();
$db = getDB();
$st = $db->prepare("SELECT full_name, department FROM users WHERE id = ?");
$st->execute([(int)$_SESSION['user_id']]);
$me = $st->fetch() ?: [];
$account = [
    'name'     => (string)($me['full_name'] ?? ''),
    'dept'     => (string)($me['department'] ?? ''),
    'position' => getUserPosition($db, (int)$_SESSION['user_id']),
];
$logoUrl = signatureLogoUrl();
$fixed = ['company' => $sig['company'], 't1' => $sig['t1'], 't2' => $sig['t2'], 'addr1' => $sig['addr1'], 'addr2' => $sig['addr2']];
$admin = isAdmin();

$pageTitle = t('page_title_signature');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<p class="text-sm text-slate-500 mb-4 max-w-3xl"><?= t('sig_intro') ?></p>

<?php if ($sigMsg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $sigMsg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= htmlspecialchars($sigMsg['text']) ?></div>
<?php endif; ?>

<div class="grid gap-5 lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)] items-start">
    <div class="bg-white rounded-xl shadow-sm p-5 space-y-4 text-sm">
        <?php foreach ([['sig_name', 'sig_f_name', 'name', 40], ['sig_dept', 'sig_f_dept', 'dept', 30], ['sig_position', 'sig_f_position', 'position', 30]] as [$id, $label, $key, $max]): ?>
            <div>
                <div class="flex items-baseline justify-between gap-2 mb-1">
                    <label class="font-medium" for="<?= $id ?>"><?= t($label) ?></label>
                    <button type="button" class="text-xs text-blue-600 hover:underline" onclick="sigReset('<?= $id ?>', '<?= $key ?>')"><?= t('sig_use_account') ?></button>
                </div>
                <input id="<?= $id ?>" maxlength="<?= $max ?>" class="w-full border rounded-lg px-3 py-2" value="<?= htmlspecialchars($account[$key]) ?>">
            </div>
        <?php endforeach; ?>
        <div>
            <label class="block mb-1 font-medium" for="sig_phone"><?= t('sig_f_phone') ?></label>
            <input id="sig_phone" inputmode="tel" maxlength="20" class="w-full border rounded-lg px-3 py-2" placeholder="0812 3456 7890">
            <p class="text-xs text-slate-400 mt-1"><?= t('sig_phone_hint') ?></p>
        </div>
        <div class="rounded-lg border border-dashed border-slate-300 px-3 py-2 text-xs text-slate-500 space-y-0.5">
            <div><?= t('sig_fixed_title') ?></div>
            <?php if ($sig['t1'] !== '' || $sig['t2'] !== ''): ?>
                <div><?php if ($sig['t1'] !== ''): ?><b class="text-slate-700">T1</b> <?= htmlspecialchars($sig['t1']) ?> &nbsp; <?php endif; ?><?php if ($sig['t2'] !== ''): ?><b class="text-slate-700">T2</b> <?= htmlspecialchars($sig['t2']) ?><?php endif; ?></div>
            <?php endif; ?>
            <?php if ($sig['addr1'] !== '' || $sig['addr2'] !== ''): ?>
                <div class="break-words"><b class="text-slate-700">A</b> <?= htmlspecialchars(trim($sig['addr1'] . ' ' . $sig['addr2'])) ?></div>
            <?php endif; ?>
            <?php if ($sig['t1'] === '' && $sig['t2'] === '' && $sig['addr1'] === '' && $sig['addr2'] === ''): ?>
                <div class="italic"><?= t('sig_fixed_empty') ?></div>
            <?php endif; ?>
        </div>
    </div>

    <div class="space-y-5 min-w-0">
        <div class="bg-white rounded-xl shadow-sm p-5 text-sm min-w-0">
            <div class="text-slate-500 mb-2"><?= t('sig_preview') ?></div>
            <canvas id="sigCanvas" width="1248" height="378" class="block w-full h-auto border border-slate-200 rounded bg-white" style="max-width:624px"></canvas>
            <div class="flex flex-wrap items-center gap-3 mt-4">
                <button type="button" id="btnSigDownload" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg px-4 py-2"><?= icon('download') ?> <?= t('sig_download') ?></button>
                <span id="sigInfo" class="text-xs text-slate-500"></span>
            </div>
            <p class="text-xs text-slate-400 mt-3"><?= t('sig_note') ?> <span id="sigColorNote"></span></p>
        </div>

        <?php if ($admin): ?>
        <!-- ===== Pengaturan template: hanya admin ===== -->
        <form method="post" enctype="multipart/form-data" class="bg-white rounded-xl shadow-sm text-sm">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <div class="p-5 space-y-4">
                <div>
                    <h2 class="font-semibold text-base"><?= t('sig_set_title') ?></h2>
                    <p class="text-xs text-slate-500 mt-0.5"><?= t('sig_set_intro') ?></p>
                </div>
                <div class="grid gap-4 sm:grid-cols-3">
                    <div>
                        <label class="block mb-1 font-medium" for="set_company"><?= t('sig_set_company') ?></label>
                        <input name="company" id="set_company" maxlength="40" class="w-full border rounded-lg px-3 py-2" value="<?= htmlspecialchars($sig['company']) ?>">
                    </div>
                    <div>
                        <label class="block mb-1 font-medium" for="set_t1">T1</label>
                        <input name="t1" id="set_t1" maxlength="30" class="w-full border rounded-lg px-3 py-2" value="<?= htmlspecialchars($sig['t1']) ?>" placeholder="+62 21 0000 0000">
                    </div>
                    <div>
                        <label class="block mb-1 font-medium" for="set_t2">T2</label>
                        <input name="t2" id="set_t2" maxlength="30" class="w-full border rounded-lg px-3 py-2" value="<?= htmlspecialchars($sig['t2']) ?>" placeholder="+62 21 0000 0000">
                    </div>
                </div>
                <div>
                    <label class="block mb-1 font-medium" for="set_address"><?= t('sig_set_address') ?> <span class="text-xs font-normal text-slate-400"><?= t('sig_set_address_hint') ?></span></label>
                    <textarea name="address" id="set_address" rows="2" maxlength="245" class="w-full border rounded-lg px-3 py-2"><?= htmlspecialchars(rtrim($sig['addr1'] . "\n" . $sig['addr2'])) ?></textarea>
                </div>
                <div>
                    <label class="block mb-1 font-medium" for="set_logo"><?= t('sig_set_logo') ?></label>
                    <input type="file" name="logo" id="set_logo" accept=".png,.jpg,.jpeg,image/png,image/jpeg" class="w-full border rounded-lg px-3 py-2 text-sm">
                    <p class="text-xs text-slate-400 mt-1"><?= t('sig_set_logo_hint') ?></p>
                    <?php if ($sig['logo'] !== ''): ?>
                        <label class="flex items-center gap-2 mt-2 text-slate-600"><input type="checkbox" name="remove_logo" value="1" class="h-4 w-4"> <?= t('sig_set_remove_logo') ?></label>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-actions-sticky p-5 flex justify-end gap-3 rounded-b-xl border-t">
                <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium"><?= t('btn_save') ?></button>
            </div>
        </form>
        <?php endif; ?>
    </div>
</div>

<script>
(function () {
    var ACC = <?= json_encode($account, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    var FIX = <?= json_encode($fixed, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    var T = <?= json_encode(['noName' => t('sig_err_name'), 'done' => t('sig_done'), 'auto' => t('sig_colors_auto'), 'neutral' => t('sig_colors_neutral')], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    var LOGO = <?= json_encode($logoUrl) ?>;
    var FONT = '"Segoe UI", system-ui, -apple-system, Roboto, "Helvetica Neue", Arial, sans-serif';
    var W = 1248, H = 378, S = 2; // ukuran hasil; S = skala terhadap ukuran dasar 624 x 189
    var NEUTRAL = { auto: false, dark: '#1f2937', accent: '#64748b', light: '#cbd5e1' };
    var $ = function (id) { return document.getElementById(id); };
    var c = $('sigCanvas'), logo = null, pal = NEUTRAL;

    function rgb2hsl(r, g, b) {
        r /= 255; g /= 255; b /= 255;
        var mx = Math.max(r, g, b), mn = Math.min(r, g, b), h = 0, s = 0, l = (mx + mn) / 2, d = mx - mn;
        if (d) {
            s = d / (1 - Math.abs(2 * l - 1));
            h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
            h *= 60; if (h < 0) h += 360;
        }
        return [h, s, l];
    }
    function hsl(h, s, l) { return 'hsl(' + Math.round(h) + ',' + Math.round(s * 100) + '%,' + Math.round(l * 100) + '%)'; }
    // Warna dominan logo: abaikan piksel transparan, putih, hitam dan abu-abu; ambil rona yang paling banyak.
    function palette(img) {
        try {
            var t = document.createElement('canvas'); t.width = 80; t.height = 80;
            var g = t.getContext('2d'); g.drawImage(img, 0, 0, 80, 80);
            var d = g.getImageData(0, 0, 80, 80).data, bins = [], i, b;
            for (i = 0; i < 36; i++) bins.push({ w: 0, x: 0, y: 0, s: 0 });
            for (i = 0; i < d.length; i += 4) {
                if (d[i + 3] < 128) continue;
                var q = rgb2hsl(d[i], d[i + 1], d[i + 2]);
                if (q[1] < 0.25 || q[2] > 0.92 || q[2] < 0.08) continue;
                b = bins[Math.floor(q[0] / 10) % 36]; b.w += q[1]; b.s += q[1] * q[1];
                b.x += Math.cos(q[0] * Math.PI / 180) * q[1]; b.y += Math.sin(q[0] * Math.PI / 180) * q[1];
            }
            var best = bins.reduce(function (a, n) { return n.w > a.w ? n : a; });
            if (best.w < 8) return NEUTRAL;
            var h = Math.atan2(best.y, best.x) * 180 / Math.PI; if (h < 0) h += 360;
            var s = Math.min(0.85, best.s / best.w);
            return { auto: true, dark: hsl(h, Math.min(s, 0.6), 0.2), accent: hsl(h, s, 0.48), light: hsl(h, Math.min(s, 0.7), 0.78) };
        } catch (e) { return NEUTRAL; }
    }
    // 0823... / 62823... / +62 823... -> "+62 823 2098 8472"
    function fmtPhone(v) {
        var d = String(v).replace(/\D/g, '');
        if (!d) return '';
        if (d.indexOf('62') === 0) d = d.slice(2); else if (d.charAt(0) === '0') d = d.slice(1);
        return '+62 ' + [d.slice(0, 3), d.slice(3, 7), d.slice(7)].filter(Boolean).join(' ');
    }
    function live(id, key) { var el = $(id); return el ? el.value.trim() : FIX[key]; } // admin: pratinjau mengikuti isian form
    function draw() {
        var g = c.getContext('2d');
        g.globalAlpha = 1; g.fillStyle = '#ffffff'; g.fillRect(0, 0, W, H);
        // hiasan bawaan: pita miring di sudut kanan atas, makin ke kiri makin tipis warnanya
        g.save(); g.beginPath(); g.rect(0, 0, W, H); g.clip();
        [[0, 1, pal.accent], [1, .75, pal.accent], [2, 1, pal.light], [3, .7, pal.light], [4, .4, pal.light]].forEach(function (b) {
            var x = W - (40 + b[0] * 34) * S, wd = 20 * S, len = (150 - b[0] * 22) * S;
            g.globalAlpha = b[1]; g.fillStyle = b[2];
            g.beginPath(); g.moveTo(x, 0); g.lineTo(x + wd, 0); g.lineTo(x + wd - len * 0.55, len); g.lineTo(x - len * 0.55, len); g.closePath(); g.fill();
        });
        g.restore(); g.globalAlpha = 1;
        g.strokeStyle = '#e6e6e6'; g.lineWidth = 2; g.strokeRect(1, 1, W - 2, H - 2);
        // logo: dimuat dalam kotak 200 x 46 (ukuran dasar) di kiri atas
        if (logo) {
            var k = Math.min(200 * S / logo.naturalWidth, 46 * S / logo.naturalHeight);
            g.drawImage(logo, 22 * S, 18 * S + (46 * S - logo.naturalHeight * k) / 2, logo.naturalWidth * k, logo.naturalHeight * k);
        }
        var company = live('set_company', 'company'), t1 = live('set_t1', 't1'), t2 = live('set_t2', 't2');
        var addr = $('set_address') ? $('set_address').value.split(/\r\n|\r|\n/) : [FIX.addr1, FIX.addr2];
        var x0 = 22 * S, y = 78 * S;
        g.textBaseline = 'alphabetic';
        g.fillStyle = pal.dark; g.font = '700 ' + 15 * S + 'px ' + FONT;
        g.fillText($('sig_name').value.trim().toUpperCase(), x0, y + 15 * S);
        g.fillStyle = '#333333'; g.font = '400 ' + 12 * S + 'px ' + FONT;
        g.fillText([company, $('sig_dept').value.trim(), $('sig_position').value.trim().toUpperCase()].filter(Boolean).join('   |   '), x0, y + 37 * S);
        var x = x0, yy = y + 63 * S;
        [['T1', t1], ['T2', t2], ['M', fmtPhone($('sig_phone').value)]].forEach(function (p) {
            if (!p[1]) return;
            g.fillStyle = pal.dark; g.font = '700 ' + 12 * S + 'px ' + FONT; g.fillText(p[0], x, yy); x += g.measureText(p[0] + ' ').width;
            g.fillStyle = '#333333'; g.font = '400 ' + 12 * S + 'px ' + FONT; g.fillText(p[1], x, yy); x += g.measureText(p[1]).width + 16 * S;
        });
        var a1 = (addr[0] || '').trim(), a2 = (addr[1] || '').trim();
        if (a1 || a2) {
            g.fillStyle = pal.dark; g.font = '700 ' + 12 * S + 'px ' + FONT; g.fillText('A', x0, y + 85 * S);
            var ax = x0 + g.measureText('A ').width;
            g.fillStyle = '#333333'; g.font = '400 ' + 12 * S + 'px ' + FONT;
            g.fillText(a1 || a2, ax, y + 85 * S);
            if (a1 && a2) g.fillText(a2, x0, y + 101 * S);
        }
        $('sigColorNote').textContent = pal.auto ? T.auto : T.neutral;
        $('sigInfo').textContent = '';
    }
    function loadLogo(src) {
        var img = new Image();
        img.onload = function () { logo = img; pal = palette(img); draw(); };
        img.onerror = function () { logo = null; pal = NEUTRAL; draw(); };
        img.src = src;
    }
    window.sigReset = function (id, key) { $(id).value = ACC[key] || ''; draw(); };
    ['sig_name', 'sig_dept', 'sig_position', 'sig_phone', 'set_company', 'set_t1', 'set_t2', 'set_address'].forEach(function (id) {
        if ($(id)) $(id).addEventListener('input', draw);
    });
    // admin: logo yang baru dipilih langsung tampil di pratinjau sebelum disimpan
    if ($('set_logo')) $('set_logo').addEventListener('change', function () {
        var f = this.files && this.files[0];
        if (f && /^image\/(png|jpeg)$/.test(f.type)) loadLogo(URL.createObjectURL(f));
    });
    // nomor handphone diingat di browser ini supaya tidak perlu diketik ulang
    try { $('sig_phone').value = localStorage.getItem('sigPhone') || ''; } catch (e) {}

    $('btnSigDownload').addEventListener('click', function () {
        var name = $('sig_name').value.trim();
        if (!name) { $('sigInfo').textContent = T.noName; $('sig_name').focus(); return; }
        try { localStorage.setItem('sigPhone', $('sig_phone').value); } catch (e) {}
        var file = 'signature_' + (name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') || 'email') + '.jpg';
        c.toBlob(function (blob) {
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob); a.download = file;
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
            $('sigInfo').textContent = T.done.replace('%s', file);
        }, 'image/jpeg', 0.92);
    });
    draw();
    if (LOGO) loadLogo(LOGO);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(draw);
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
