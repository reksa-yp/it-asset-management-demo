<?php
/**
 * Export Standar Spesifikasi:
 *  ?fmt=xlsx -> Excel 3 sheet (Standar, Per Departemen, Daftar Perangkat), bahasa sesuai pilihan user.
 *  ?fmt=pdf  -> laporan PDF berbahasa Inggris "Desktop & Laptop Specification Standard" (untuk atasan / HQ).
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/spec_standard.php';
require_once __DIR__ . '/vendor/autoload.php';

$db  = getDB();
$fmt = ($_GET['fmt'] ?? 'xlsx') === 'pdf' ? 'pdf' : 'xlsx';

if ($fmt === 'pdf') {
    // Laporan selalu berbahasa Inggris; bahasa user dikembalikan setelah data disusun.
    $prevLang = $_SESSION['lang'] ?? null;
    $_SESSION['lang'] = 'en';
}
$rep = specReport($db);

if ($fmt === 'xlsx') {
    $book = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $title = spL('Standar Spesifikasi PC & Laptop', 'PC & Laptop Specification Standard');
    $book->getProperties()->setTitle($title)->setCreator(t('app_name'));
    $fill = function ($sheet, string $name, array $headers, array $rows, array $widths) use ($title) {
        $sheet->setTitle(mb_substr($name, 0, 31));
        $last = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex(count($headers));
        $sheet->setCellValue('A1', t('app_name') . ' — ' . $title);
        $sheet->setCellValue('A2', t('printed_at') . ': ' . date('d M Y H:i'));
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(13);
        $sheet->getStyle('A2')->getFont()->setItalic(true)->getColor()->setRGB('64748B');
        $sheet->fromArray($headers, null, 'A4');
        if ($rows) $sheet->fromArray($rows, null, 'A5', true);
        $lastRow = 4 + max(1, count($rows));
        $head = $sheet->getStyle("A4:{$last}4");
        $head->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
        $head->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
        $sheet->getStyle("A4:{$last}{$lastRow}")->getBorders()->getAllBorders()
              ->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN)->getColor()->setRGB('CBD5E1');
        $sheet->getStyle("A5:{$last}{$lastRow}")->getAlignment()->setVertical('top')->setWrapText(true);
        foreach ($widths as $i => $w) $sheet->getColumnDimension(\PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i + 1))->setWidth($w);
        $sheet->freezePane('A5');
        $sheet->setAutoFilter("A4:{$last}{$lastRow}");
    };

    $tRows = [];
    foreach ($rep['tiers'] as $t) {
        $tRows[] = [$t['name'], specKinds()[$t['kind']] ?? $t['kind'], $t['kind'] === 'umum' ? spL('Semua yang lain', 'Everyone else') : $t['match_text'],
                    specCpuShort($t['cpu_min']) . ' gen ' . $t['gen_min'] . '+', $t['ram_min'] . ' GB', $t['need_ssd'] ? spL('Ya', 'Yes') : '-', $t['need_gpu'] ? spL('Ya', 'Yes') : '-',
                    (specOsList()[$t['os_min']] ?? '') . ($t['need_pro'] ? ' Pro' : '')];
    }
    $fill($book->getActiveSheet(), spL('Standar', 'Standards'),
        [spL('Standar', 'Standard'), spL('Berlaku untuk', 'Applies to'), spL('Departemen / jabatan', 'Departments / positions'), spL('Prosesor min.', 'Min. CPU'), spL('RAM min.', 'Min. RAM'), 'SSD', 'VGA', spL('OS min.', 'Min. OS')],
        $tRows, [22, 14, 40, 20, 12, 8, 8, 20]);

    $dRows = [];
    foreach ($rep['dept'] as $d => $o) $dRows[] = [$d, implode(', ', array_keys($o['tiers'])), $o['n'], $o['ok'], $o['bad'], $o['warn'], $o['replace'], $o['n'] ? round($o['ok'] / $o['n'] * 100) . '%' : '-'];
    $s = $rep['sum'];
    $dRows[] = [spL('TOTAL', 'TOTAL'), '', $s['n'], $s['ok'], $s['bad'], $s['warn'], $s['replace'], $s['n'] ? round($s['ok'] / $s['n'] * 100) . '%' : '-'];
    $sh = $book->createSheet();
    $fill($sh, spL('Per Departemen', 'By Department'),
        [spL('Departemen', 'Department'), spL('Standar', 'Standard'), spL('Unit', 'Units'), spL('Sesuai', 'Compliant'), spL('Di bawah', 'Below'), spL('Belum lengkap', 'Incomplete'), spL('Ganti unit', 'Replace'), '%'],
        $dRows, [24, 30, 8, 10, 10, 13, 11, 8]);
    $sh->getStyle('A' . (4 + count($dRows)) . ':H' . (4 + count($dRows)))->getFont()->setBold(true);

    $aRows = [];
    foreach ($rep['rows'] as $x) {
        $a = $x['a']; $r = $x['r']; $e = $r['eff'];
        $aRows[] = [specStatusLabel($r['status']), $a['asset_number'], $a['category'], $a['device_name'], $a['owner_names'], $a['department'], implode(', ', $a['positions']),
                    $r['tier']['name'], (string)$a['processor'], (string)$a['ram'], (string)$a['storage'], (string)$a['os_name'], $e['gpu']['text'],
                    specSpecLine($e), implode("\n", array_merge($r['fails'], $r['miss'])), $r['action'], $r['note'], $r['manual'] ? spL('Ya', 'Yes') : ''];
    }
    $sh = $book->createSheet();
    $fill($sh, spL('Daftar Perangkat', 'Devices'),
        ['Status', spL('No. Aset', 'Asset No.'), spL('Jenis', 'Type'), spL('Nama Perangkat', 'Device'), spL('Pemakai', 'User'), spL('Departemen', 'Department'), spL('Jabatan', 'Position'),
         spL('Standar', 'Standard'), spL('Prosesor', 'Processor'), 'RAM', spL('Penyimpanan', 'Storage'), 'OS', 'VGA', spL('Spesifikasi terbaca', 'Spec (read)'),
         spL('Kekurangan', 'Gaps'), spL('Saran', 'Action'), spL('Catatan', 'Note'), spL('Koreksi manual', 'Manual')],
        $aRows, [16, 18, 11, 22, 22, 16, 18, 14, 30, 12, 18, 18, 18, 36, 36, 26, 30, 9]);
    $colors = ['ok' => 'DCFCE7', 'bad' => 'FEE2E2', 'warn' => 'FEF9C3'];
    foreach ($rep['rows'] as $i => $x) {
        $sh->getStyle('A' . (5 + $i))->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor()->setRGB($colors[$x['r']['status']]);
    }
    $book->setActiveSheetIndex(0);

    $file = 'Standar_Spesifikasi_' . date('Ymd_His') . '.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $file . '"');
    header('Cache-Control: max-age=0');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($book))->save('php://output');
    exit;
}

/* ---------- PDF (English) ---------- */
require_once __DIR__ . '/includes/letterhead.php';
$e = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES);
$s = $rep['sum'];
$pct = $s['n'] ? round($s['ok'] / $s['n'] * 100) : 0;
$col = ['ok' => '#15803d', 'bad' => '#b91c1c', 'warn' => '#a16207'];

$html = '<html><head><meta charset="UTF-8"><style>
    body { font-family: DejaVu Sans, Arial, sans-serif; color: #1e293b; font-size: 9.5px; }
    h1 { font-size: 16px; margin: 0 0 2px; } h2 { font-size: 12px; margin: 14px 0 6px; }
    p.sub { font-size: 9px; color: #64748b; margin: 0 0 10px; }
    table { width: 100%; border-collapse: collapse; page-break-inside: auto; } tr { page-break-inside: avoid; }
    th, td { border: 1px solid #cbd5e1; padding: 4px 5px; text-align: left; vertical-align: top; }
    th { background: #f1f5f9; font-size: 8.5px; text-transform: uppercase; }
    td.n { text-align: right; }
    .kpi td { border: 0; padding: 0 6px 0 0; } .kpi div { border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 8px; }
    .kpi b { font-size: 16px; display: block; }
    .gap { color: #b91c1c; } .miss { color: #a16207; } .note { color: #334155; font-style: italic; }
' . letterheadPdfCss() . '</style></head><body>' . letterheadPdfHtml()
    . '<h1>Desktop &amp; Laptop Specification Standard</h1>'
    . '<p class="sub">' . $e(t('app_name')) . ' &bull; Compliance report &bull; ' . $e(date('d M Y H:i')) . '</p>'
    . '<table class="kpi"><tr>'
    . '<td><div><b>' . $s['n'] . '</b>Laptops &amp; PCs checked</div></td>'
    . '<td><div><b style="color:#15803d">' . $s['ok'] . ' (' . $pct . '%)</b>Compliant</div></td>'
    . '<td><div><b style="color:#b91c1c">' . $s['bad'] . '</b>Below standard &bull; ' . $s['replace'] . ' need replacement</div></td>'
    . '<td><div><b style="color:#a16207">' . $s['warn'] . '</b>Incomplete data</div></td>'
    . '</tr></table>';

$html .= '<h2>1. Minimum specification by group</h2><table><thead><tr><th>Standard</th><th>Applies to</th><th>Processor</th><th>RAM</th><th>Storage</th><th>Graphics</th><th>Operating system</th></tr></thead><tbody>';
foreach ($rep['tiers'] as $t) {
    $who = $t['kind'] === 'umum' ? 'All other departments / staff' : (($t['kind'] === 'jabatan' ? 'Positions: ' : 'Departments: ') . ($t['match_text'] !== '' ? $t['match_text'] : '-'));
    $html .= '<tr><td><b>' . $e($t['name']) . '</b></td><td>' . $e($who) . '</td><td>' . $e(specCpuShort($t['cpu_min']) . ' gen ' . $t['gen_min'] . ' or higher (or AMD Ryzen equivalent)') . '</td><td>'
           . $t['ram_min'] . ' GB</td><td>' . ($t['need_ssd'] ? 'SSD' : 'Any') . '</td><td>' . ($t['need_gpu'] ? 'Dedicated graphics card' : 'Integrated OK') . '</td><td>'
           . $e((specOsList()[$t['os_min']] ?? '') . ($t['need_pro'] ? ' Pro' : '') . ' or newer') . '</td></tr>';
}
$html .= '</tbody></table>';

$html .= '<h2>2. Summary by department</h2><table><thead><tr><th>Department</th><th>Standard</th><th>Units</th><th>Compliant</th><th>Below</th><th>Incomplete</th><th>Replace</th><th>%</th></tr></thead><tbody>';
foreach ($rep['dept'] as $d => $o) {
    $html .= '<tr><td>' . $e($d) . '</td><td>' . $e(implode(', ', array_keys($o['tiers']))) . '</td><td class="n">' . $o['n'] . '</td><td class="n">' . $o['ok'] . '</td><td class="n">' . $o['bad'] . '</td><td class="n">' . $o['warn'] . '</td><td class="n">' . $o['replace'] . '</td><td class="n">' . ($o['n'] ? round($o['ok'] / $o['n'] * 100) : 0) . '%</td></tr>';
}
$html .= '<tr><td><b>TOTAL</b></td><td></td><td class="n"><b>' . $s['n'] . '</b></td><td class="n"><b>' . $s['ok'] . '</b></td><td class="n"><b>' . $s['bad'] . '</b></td><td class="n"><b>' . $s['warn'] . '</b></td><td class="n"><b>' . $s['replace'] . '</b></td><td class="n"><b>' . $pct . '%</b></td></tr></tbody></table>';

$html .= '<h2>3. Devices below standard / incomplete</h2>';
$list = array_filter($rep['rows'], fn($x) => $x['r']['status'] !== 'ok');
if (!$list) $html .= '<p>All devices meet the standard.</p>';
else {
    $html .= '<table><thead><tr><th>Status</th><th>Asset</th><th>User / Department</th><th>Standard</th><th>Current specification</th><th>Gaps</th><th>Recommended action</th></tr></thead><tbody>';
    foreach ($list as $x) {
        $a = $x['a']; $r = $x['r'];
        $gaps = implode('', array_map(fn($g) => '<div class="gap">' . $e($g) . '</div>', $r['fails'])) . implode('', array_map(fn($g) => '<div class="miss">' . $e($g) . '</div>', $r['miss']));
        $html .= '<tr><td style="color:' . $col[$r['status']] . ';font-weight:bold">' . $e(specStatusLabel($r['status'])) . '</td><td><b>' . $e($a['asset_number']) . '</b><br>' . $e($a['device_name']) . '</td><td>'
               . $e($a['owner_names']) . '<br>' . $e($a['department']) . ($a['positions'] ? ' &bull; ' . $e(implode(', ', $a['positions'])) : '') . '</td><td>' . $e($r['tier']['name']) . '</td><td>' . $e(specSpecLine($r['eff'])) . '</td><td>' . $gaps
               . '</td><td>' . $e($r['action']) . ($r['note'] !== '' ? '<div class="note">' . $e($r['note']) . '</div>' : '') . '</td></tr>';
    }
    $html .= '</tbody></table>';
}
$html .= '<p class="sub" style="margin-top:10px">Specifications are read from the IT asset register and corrected manually by IT where needed. AMD Ryzen processors are compared with the equivalent Intel generation.</p></body></html>';

if ($prevLang !== null) $_SESSION['lang'] = $prevLang; else unset($_SESSION['lang']);

$opt = new \Dompdf\Options();
$opt->set('isRemoteEnabled', true);
$pdf = new \Dompdf\Dompdf($opt);
$pdf->setPaper('A4', 'landscape');
$pdf->loadHtml($html);
$pdf->render();
$pdf->stream('Specification_Standard_Report_' . date('Ymd') . '.pdf', ['Attachment' => false]);
