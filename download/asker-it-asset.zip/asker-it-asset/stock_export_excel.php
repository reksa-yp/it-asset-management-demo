<?php
/**
 * Export Excel Stok Barang — 3 sheet: Rekap Kategori, Riwayat Transaksi, Rekap User.
 * Mengikuti filter yang sedang aktif di halaman Stok Barang.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/stock.php';
require_once __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

$db = getDB();
ensureStockTables($db);
$f            = stockFilters();
$recap        = getStockRecap($db, $f);
$transactions = getStockTransactions($db, $f, true);
$recapUser    = getStockRecapByUser($transactions);
$period       = stockPeriodLabel($f);

$book = new Spreadsheet();
$book->getProperties()->setTitle(t('stock_report_title'))->setCreator(t('app_name'));

/** Isi 1 sheet: judul, header, baris data, lalu styling sederhana. */
$fillSheet = function ($sheet, string $title, array $headers, array $rows, array $numericCols = []) use ($period) {
    // Nama sheet Excel tidak boleh berisi karakter [ ] : * ? / \\ dan maksimal 31 karakter.
    $sheet->setTitle(mb_substr(trim(preg_replace('/\s+/', ' ', str_replace(['[', ']', ':', '*', '?', '/', '\\'], ' ', $title))), 0, 31));
    $lastCol = Coordinate::stringFromColumnIndex(count($headers));
    $sheet->setCellValue('A1', t('app_name') . ' — ' . t('stock_report_title'));
    $sheet->setCellValue('A2', t('stock_period') . ': ' . $period . '   •   ' . t('printed_at') . ': ' . date('d M Y H:i'));
    $sheet->mergeCells("A1:{$lastCol}1");
    $sheet->mergeCells("A2:{$lastCol}2");
    $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(13);
    $sheet->getStyle('A2')->getFont()->setItalic(true)->getColor()->setRGB('64748B');

    $sheet->fromArray($headers, null, 'A4');
    $sheet->fromArray($rows ?: [[t('stock_no_data')]], null, 'A5', true);
    $lastRow = 4 + max(1, count($rows));

    $head = $sheet->getStyle("A4:{$lastCol}4");
    $head->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
    $head->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
    $sheet->getStyle("A4:{$lastCol}{$lastRow}")->getBorders()->getAllBorders()
          ->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB('CBD5E1');
    foreach ($numericCols as $ci) {
        $col = Coordinate::stringFromColumnIndex($ci);
        $sheet->getStyle("{$col}5:{$col}{$lastRow}")->getAlignment()->setHorizontal('right');
    }
    for ($i = 1; $i <= count($headers); $i++) {
        $sheet->getColumnDimension(Coordinate::stringFromColumnIndex($i))->setAutoSize(true);
    }
    $sheet->freezePane('A5');
    return $lastRow;
};

// Sheet 1: Rekap per kategori
$rows = [];
foreach ($recap as $r) {
    $rows[] = [$r['name'], $r['unit'], $r['opening'], $r['qty_in'], $r['qty_out'], $r['closing'], $r['min_stock'], stockStatusLabel($r['status'])];
}
$s1 = $book->getActiveSheet();
$last = $fillSheet($s1, t('stock_tab_recap'),
    [t('stock_category'), t('stock_unit'), t('stock_opening'), t('stock_type_in'), t('stock_type_out'), t('stock_closing'), t('stock_min'), t('th_status')],
    $rows, [3,4,5,6,7]);
if ($rows) {
    $tot = $last + 1;
    $s1->setCellValue("A{$tot}", t('stock_total'));
    foreach (['C','D','E','F'] as $c) $s1->setCellValue("{$c}{$tot}", "=SUM({$c}5:{$c}{$last})");
    $s1->getStyle("A{$tot}:H{$tot}")->getFont()->setBold(true);
    $s1->getStyle("A{$tot}:H{$tot}")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('EEF4FF');
}
// Kolom No di paling kiri (baris Total tidak diberi nomor; rumus SUM ikut bergeser otomatis).
require_once __DIR__ . '/includes/xls_number.php';
xlsAddNumberColumn($s1, 4, $rows ? $last : 4);
require_once __DIR__ . '/includes/letterhead.php';
$stockBlock = function ($sheet, string $tab, int $count) use ($period) {
    xlsAddTitleBlock($sheet, 4, t('stock_report_title') . ' ' . xlsCompanyName() . ' — ' . $tab,
        [documentCreatedAt(), xlsCountLine('Jumlah data', 'Total rows', $count, [t('stock_period') . ': ' . $period])]);
};
$stockBlock($s1, t('stock_tab_recap'), count($rows));

// Sheet 2: Riwayat transaksi (+ kolom ID Aset untuk transaksi ber-ID)
$trxAssets = getStockTrxAssets($db, array_column($transactions, 'id'));
$rows = [];
foreach ($transactions as $tx) {
    $in = $tx['type'] === 'in';
    $ids = implode(', ', array_column($trxAssets[(int)$tx['id']] ?? [], 'asset_number'));
    $rows[] = [date('d/m/Y', strtotime($tx['trx_date'])), $in ? t('stock_type_in') : t('stock_type_out'), $tx['category_name'],
               $tx['item_name'] ?? '', $in ? (int)$tx['qty'] : '', $in ? '' : (int)$tx['qty'], $tx['unit'],
               $in ? '' : ($tx['recipient_name'] ?? ''), $in ? '' : ($tx['recipient_department'] ?? ''), $tx['note'] ?? '', $ids];
}
$s2 = $book->createSheet();
$fillSheet($s2, t('stock_tab_history'),
    [t('th_date'), t('stock_type'), t('stock_category'), t('stock_item_name'), t('stock_qty_in'), t('stock_qty_out'), t('stock_unit'),
     t('stock_given_to'), t('th_department'), t('stock_note'), t('stock_asset_ids')],
    $rows, [5,6]);
xlsAddNumberColumn($s2, 4, 4 + count($rows));
$stockBlock($s2, t('stock_tab_history'), count($rows));

// Sheet 3: Rekap per user
$rows = [];
foreach ($recapUser as $u) {
    $items = implode(', ', array_map(fn($k, $v) => "$k ($v)", array_keys($u['items']), $u['items']));
    $rows[] = [$u['name'], $u['department'], $items, $u['total'], date('d/m/Y', strtotime($u['last']))];
}
$s3 = $book->createSheet();
$fillSheet($s3, t('stock_tab_user'),
    [t('stock_user'), t('th_department'), t('stock_items_received'), t('stock_total_items'), t('stock_last_received')],
    $rows, [4]);
xlsAddNumberColumn($s3, 4, 4 + count($rows));
$stockBlock($s3, t('stock_tab_user'), count($rows));

$book->setActiveSheetIndex(0);
$name = 'stok_barang_' . ($f['from'] ?: 'awal') . '_sd_' . ($f['to'] ?: date('Y-m-d')) . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $name . '"');
header('Cache-Control: max-age=0');
(new Xlsx($book))->save('php://output');
exit;
