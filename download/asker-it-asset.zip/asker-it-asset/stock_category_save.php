<?php
/** Tambah / edit / hapus kategori barang stok (tabel stock_categories). */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/stock.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: stock.php'); exit; }
csrfCheck();

$db = getDB();
ensureStockTables($db);
$action = $_POST['action'] ?? 'save';
$id     = (int)($_POST['id'] ?? 0);
$msg    = ['ok' => true, 'text' => t('stock_cat_saved')];

if ($action === 'delete') {
    $used = $db->prepare("SELECT COUNT(*) FROM stock_transactions WHERE category_id = ?");
    $used->execute([$id]);
    if ((int)$used->fetchColumn() > 0) {
        $msg = ['ok' => false, 'text' => t('stock_cat_in_use')];
    } else {
        $db->prepare("DELETE FROM stock_categories WHERE id = ?")->execute([$id]);
        $msg = ['ok' => true, 'text' => t('stock_cat_deleted')];
    }
} else {
    $name = mb_substr(trim($_POST['name'] ?? ''), 0, 60);
    $unit = mb_substr(trim($_POST['unit'] ?? ''), 0, 20) ?: 'pcs';
    $min  = max(0, (int)($_POST['min_stock'] ?? 0));
    if ($name === '') {
        $msg = ['ok' => false, 'text' => t('stock_cat_required')];
    } else {
        $dup = $db->prepare("SELECT COUNT(*) FROM stock_categories WHERE name = ? AND id <> ?");
        $dup->execute([$name, $id]);
        if ((int)$dup->fetchColumn() > 0) {
            $msg = ['ok' => false, 'text' => t('stock_cat_duplicate')];
        } elseif ($id) {
            $db->prepare("UPDATE stock_categories SET name=?, unit=?, min_stock=? WHERE id=?")->execute([$name, $unit, $min, $id]);
        } else {
            $db->prepare("INSERT INTO stock_categories (name, unit, min_stock) VALUES (?,?,?)")->execute([$name, $unit, $min]);
        }
    }
}
$_SESSION['stock_msg'] = $msg;
header('Location: stock.php');
