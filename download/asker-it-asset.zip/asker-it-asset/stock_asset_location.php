<?php
/**
 * Ubah lokasi aset berstatus Stok (menu Stok Barang > tab Aset IT Stok).
 * Hanya mengubah kolom assets.location; tidak ada perubahan struktur database.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$back = 'stock.php?tab=assets';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . $back); exit; }
csrfCheck();

$db       = getDB();
$assetId  = (int)($_POST['asset_id'] ?? 0);
$location = mb_substr(trim((string)($_POST['location'] ?? '')), 0, 100);
$cat      = trim((string)($_POST['cat'] ?? ''));
if ($cat !== '') $back .= '&acat=' . urlencode($cat);

$a = $db->prepare("SELECT id, asset_number, status FROM assets WHERE id = ?");
$a->execute([$assetId]);
$asset = $a->fetch();

if (!$asset) {
    $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('asset_stock_err_asset')];
} elseif ($asset['status'] !== 'Stok') {
    $_SESSION['stock_msg'] = ['ok' => false, 'text' => t('asset_stock_err_not_stock', $asset['asset_number'])];
} else {
    $db->prepare("UPDATE assets SET location = ? WHERE id = ?")->execute([$location, $assetId]);
    $_SESSION['stock_msg'] = ['ok' => true, 'text' => t('asset_stock_loc_saved', $asset['asset_number'], $location !== '' ? $location : t('dash'))];
}
header('Location: ' . $back);
exit;
