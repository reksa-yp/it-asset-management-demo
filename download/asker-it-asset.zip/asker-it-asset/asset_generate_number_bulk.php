<?php
/**
 * Buat ulang Nomor Aset otomatis untuk BEBERAPA aset sekaligus (dipanggil
 * dari tombol "Generate Nomor Otomatis" di toolbar menu Penambahan Aset IT,
 * untuk aset yang sedang dicentang).
 *
 * Beda dengan asset_generate_number.php (yang cuma memberi USULAN untuk
 * modal Tambah/Edit), endpoint ini LANGSUNG menimpa kolom asset_number di
 * database untuk tiap aset terpilih. Nomor Aset lama pada aset tersebut akan
 * diganti — data lain (kategori, departement, dst) tidak disentuh sama sekali.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/asset_number.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: assets.php');
    exit;
}
csrfCheck();

$rawIds = $_POST['ids'] ?? [];
$ids = array_values(array_unique(array_filter(array_map('intval', (array)$rawIds), fn($v) => $v > 0)));

if (!$ids) {
    $_SESSION['asset_bulk_msg'] = ['ok' => false, 'text' => t('gen_number_bulk_none_selected')];
    header('Location: assets.php');
    exit;
}

$db = getDB();

$placeholders = implode(',', array_fill(0, count($ids), '?'));
$stmt = $db->prepare("SELECT id, asset_number, category, department, location FROM assets WHERE id IN ($placeholders) ORDER BY id");
$stmt->execute($ids);
$rows = $stmt->fetchAll();

$updateStmt = $db->prepare("UPDATE assets SET asset_number = ? WHERE id = ?");

$updated = 0;
$skipped = 0;

foreach ($rows as $row) {
    // Tablet: format <Awalan>/<Dept>/<Line>/<Urutan>. Dilewati jika Location (line) kosong.
    if (isTabletCategory($row['category'])) {
        $newNumber = nextTabletAssetNumber($db, (string)$row['department'], (string)$row['location'], (int)$row['id']);
        if ($newNumber === null) { $skipped++; continue; }
        if ($newNumber !== $row['asset_number']) $updateStmt->execute([$newNumber, $row['id']]);
        $updated++;
        continue;
    }
    $catAbbr = getCategoryAbbr($db, $row['category']);
    if ($catAbbr === null) {
        // Kategori aset ini tidak/tidak lagi terdaftar di menu Kategori Aset
        // (mis. sudah dihapus admin) -> lewati, tidak bisa dibuatkan singkatannya.
        $skipped++;
        continue;
    }
    $deptAbbr = generateDeptAbbr((string)$row['department']);
    $newNumber = nextAssetNumber($db, $catAbbr, $deptAbbr, (int)$row['id']);

    if ($newNumber !== $row['asset_number']) {
        $updateStmt->execute([$newNumber, $row['id']]);
    }
    $updated++;
}

if ($updated > 0 && $skipped === 0) {
    $_SESSION['asset_bulk_msg'] = ['ok' => true, 'text' => t('gen_number_bulk_success', $updated)];
} elseif ($updated > 0 && $skipped > 0) {
    $_SESSION['asset_bulk_msg'] = ['ok' => true, 'text' => t('gen_number_bulk_partial', $updated, $skipped)];
} else {
    $_SESSION['asset_bulk_msg'] = ['ok' => false, 'text' => t('gen_number_bulk_all_skipped')];
}

header('Location: assets.php');
exit;
