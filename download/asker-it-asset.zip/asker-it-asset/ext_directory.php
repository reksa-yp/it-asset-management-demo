<?php
/**
 * Menu "Ext Telepon" (semua user): daftar Nomor Ext kantor — No, Bagian, Nama, Ext.
 * Data selalu diambil langsung dari aset kategori Ext Telepon (includes/ext_phone.php),
 * jadi otomatis ikut berubah saat Nomor Ext / pengguna / departement aset diperbarui.
 *   ext_directory.php            -> tampilan daftar + pencarian
 *   ext_directory.php?download=1 -> file Excel (A4 landscape, 2 salinan berdampingan)
 * Tampilan nama: nama depan (bawaan) / tengah / belakang / lengkap, dipilih per user.
 * User biasa mengatur namanya sendiri; admin bisa mengatur semua.
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();

$db = getDB();
ensureExtPhoneTable($db);
$me = (int)($_SESSION['user_id'] ?? 0);
$admin = isAdmin();

// ===== Simpan pilihan tampilan nama =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $modes = (array)($_POST['mode'] ?? []);
    $nicks = (array)($_POST['nick'] ?? []);
    $saved = 0;
    foreach ($modes as $uid => $mode) {
        $uid = (int)$uid;
        if (!$admin && $uid !== $me) continue;          // user biasa hanya boleh mengatur namanya sendiri
        $nick = (string)($nicks[$uid] ?? '');
        // Simpan lalu baca ulang dari file, supaya "berhasil" hanya muncul kalau benar-benar tersimpan.
        if (saveExtNameMode($uid, (string)$mode, $nick)
            && extNameModeFor($uid) === (string)$mode
            && extNickFor($uid) === mb_substr(trim(preg_replace('/\s+/', ' ', $nick)), 0, 40)) {
            $saved++;
        } else {
            $failed = true;
        }
    }
    $_SESSION['ext_dir_msg'] = (!empty($failed) || !$saved)
        ? ['ok' => false, 'text' => t('extdir_save_failed') . ' (' . EXT_NAME_FILE . ')']
        : ['ok' => true, 'text' => t('extdir_saved'), 'dl' => true];
    header('Location: ext_directory.php');
    exit;
}

$dir = getExtDirectory($db);

// ===== Cetak langsung (browser) / Unduh PDF =====
if (!empty($_GET['print'])) {
    header('Cache-Control: no-store');
    echo extDirectoryHtml($dir, false);
    exit;
}
if (!empty($_GET['pdf'])) {
    require_once __DIR__ . '/vendor/autoload.php';
    $opt = new \Dompdf\Options();
    $opt->set('isRemoteEnabled', true);
    // Render ulang dengan huruf lebih kecil sampai hasilnya 1 lembar (nama panjang turun baris).
    $fs = null;
    for ($try = 0; $try < 8; $try++) {
        $pdf = new \Dompdf\Dompdf($opt);
        $pdf->setPaper('A4', 'landscape');
        $pdf->loadHtml(extDirectoryHtml($dir, true, $fs), 'UTF-8');
        $pdf->render();
        if ($pdf->getCanvas()->get_page_count() <= 1) break;
        $fs = ($fs ?? 9.5) - ($try < 3 ? 1.0 : 0.5);
        if ($fs < 5) break;
    }
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    $pdfPrefix = trim(preg_replace('/[^A-Za-z0-9]+/', '_', function_exists('assetPrefix') ? assetPrefix() : ''), '_');
    $pdf->stream('NO_EXT_TELEPON_' . ($pdfPrefix !== '' ? $pdfPrefix . '_' : '') . date('Ymd_His') . '.pdf', ['Attachment' => true]);
    exit;
}

// ===== Unduh Excel =====
if (!empty($_GET['download'])) {
    require_once __DIR__ . '/vendor/autoload.php';
    $ss = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    writeExtDirectorySheet($ss, $dir);
    $prefix = trim(preg_replace('/[^A-Za-z0-9]+/', '_', function_exists('assetPrefix') ? assetPrefix() : ''), '_') ?: 'KANTOR';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    // Nama file memuat jam:menit supaya file baru tidak tertukar dengan unduhan sebelumnya.
    header('Content-Disposition: attachment; filename="NO_EXT_TELEPON_' . $prefix . '_' . date('Ymd_His') . '.xlsx"');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($ss))->save('php://output');
    exit;
}

// Pengguna yang tampil di daftar (untuk pengaturan nama oleh admin).
$dirUsers = [];
foreach ($dir as $d) foreach ($d['users'] as $u) $dirUsers[$u['id']] = $u['full_name'];
asort($dirUsers, SORT_NATURAL | SORT_FLAG_CASE);
$myName = (string)(currentUser()['full_name'] ?? '');
$modeLabels = ['first' => t('extdir_mode_first'), 'middle' => t('extdir_mode_middle'), 'last' => t('extdir_mode_last'), 'full' => t('extdir_mode_full')];
$h = fn($v) => htmlspecialchars((string)$v);
$msg = $_SESSION['ext_dir_msg'] ?? null; unset($_SESSION['ext_dir_msg']);

$pageTitle = t('nav_ext_directory');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

$modeSelect = function (int $uid, string $fullName) use ($modeLabels, $h) {
    $cur = extNameModeFor($uid);
    $html = '<select name="mode[' . $uid . ']" class="border rounded-lg px-2 py-1.5 text-sm max-w-full">';
    foreach (extNameModeOptions($fullName) as $m => $example) {
        $html .= '<option value="' . $m . '"' . ($m === $cur ? ' selected' : '') . '>' . $h($modeLabels[$m] . ': ' . $example) . '</option>';
    }
    $html .= '</select>';
    // Nama panggilan: kalau diisi, dipakai di daftar Ext menggantikan pilihan di atas.
    $html .= '<input type="text" name="nick[' . $uid . ']" maxlength="40" value="' . $h(extNickFor($uid)) . '" placeholder="' . $h(t('extdir_nick_ph')) . '" class="border rounded-lg px-2 py-1.5 text-sm w-40">';
    return '<span class="flex flex-wrap items-center gap-2">' . $html . '</span>';
};
?>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>">
        <?= $h($msg['text']) ?>
        <?php if (!empty($msg['dl'])): ?> <a href="ext_directory.php?download=1&amp;t=<?= time() ?>" class="font-semibold underline"><?= t('extdir_dl_again') ?></a><?php endif; ?>
    </div>
<?php endif; ?>

<div class="flex flex-wrap items-center gap-2 mb-3">
    <input type="search" id="extSearch" oninput="filterExt(this.value)" placeholder="<?= $h(t('extdir_search_ph')) ?>"
           class="border rounded-lg px-3 py-2 text-sm w-full sm:w-80">
    <a href="ext_directory.php?download=1&amp;t=<?= time() ?>" class="inline-flex items-center gap-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
        <?= icon('download') ?> <?= t('extdir_btn_download') ?>
    </a>
    <a href="ext_directory.php?print=1&amp;t=<?= time() ?>" target="_blank" rel="noopener" class="inline-flex items-center gap-1 bg-slate-700 hover:bg-slate-800 text-white rounded-lg px-4 py-2 text-sm font-medium">
        <?= icon('printer') ?> <?= t('extdir_btn_print') ?>
    </a>
    <a href="ext_directory.php?pdf=1&amp;t=<?= time() ?>" class="inline-flex items-center gap-1 bg-red-600 hover:bg-red-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
        <?= icon('download') ?> <?= t('extdir_btn_pdf') ?>
    </a>
    <span class="text-sm text-slate-500" id="extCount"><?= count($dir) ?> <?= t('extdir_count') ?></span>
</div>
<p class="text-xs text-slate-400 mb-3"><?= t('extdir_info') ?></p>

<div class="bg-white rounded-xl shadow-sm overflow-x-auto mb-6">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-slate-500 text-left">
            <tr><th class="py-2 px-3 w-14"><?= t('extdir_col_no') ?></th><th class="py-2 px-3"><?= t('extdir_col_bagian') ?></th><th class="py-2 px-3"><?= t('extdir_col_nama') ?></th><th class="py-2 px-3 w-24"><?= t('extdir_col_ext') ?></th></tr>
        </thead>
        <tbody id="extRows">
        <?php foreach ($dir as $i => $d): ?>
            <tr class="border-t hover:bg-slate-50 ext-row" data-s="<?= $h(mb_strtolower($d['bagian'] . ' ' . $d['nama'] . ' ' . $d['ext'])) ?>">
                <td class="py-2 px-3 tabular-nums text-slate-500 ext-no"><?= $i + 1 ?></td>
                <td class="py-2 px-3"><?= $h($d['bagian'] ?: t('dash')) ?></td>
                <td class="py-2 px-3"><?= $h($d['nama'] ?: t('dash')) ?></td>
                <td class="py-2 px-3 font-semibold text-brand-700 tabular-nums"><?= $h($d['ext']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$dir): ?>
            <tr><td colspan="4" class="py-8 text-center text-slate-400"><?= t('extdir_empty') ?></td></tr>
        <?php endif; ?>
        <tr id="extNoMatch" class="hidden"><td colspan="4" class="py-6 text-center text-slate-400"><?= t('extdir_no_match') ?></td></tr>
        </tbody>
    </table>
</div>

<div class="bg-white rounded-xl shadow-sm p-4 text-sm">
    <h2 class="font-semibold text-slate-700 mb-1"><?= t('extdir_name_title') ?></h2>
    <p class="text-xs text-slate-500 mb-3"><?= t($admin ? 'extdir_name_help_admin' : 'extdir_name_help_user') ?></p>
    <form method="post" class="space-y-2">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <?php if ($admin): ?>
            <?php if (!$dirUsers): ?><p class="text-slate-400 text-xs"><?= t('extdir_empty') ?></p><?php endif; ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
            <?php foreach ($dirUsers as $uid => $name): ?>
                <label class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2">
                    <span class="font-medium text-slate-700"><?= $h($name) ?></span>
                    <?= $modeSelect((int)$uid, $name) ?>
                </label>
            <?php endforeach; ?>
            </div>
        <?php else: ?>
            <label class="flex flex-wrap items-center gap-2">
                <span class="text-slate-600"><?= $h($myName) ?></span>
                <?= $modeSelect($me, $myName) ?>
            </label>
        <?php endif; ?>
        <?php if ($admin ? $dirUsers : true): ?>
        <div class="pt-2"><button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('btn_save') ?></button></div>
        <?php endif; ?>
    </form>
</div>

<script>
function filterExt(q) {
    q = (q || '').toLowerCase().trim();
    let n = 0;
    document.querySelectorAll('.ext-row').forEach(tr => {
        const show = !q || tr.dataset.s.includes(q);
        tr.classList.toggle('hidden', !show);
        if (show) tr.querySelector('.ext-no').textContent = ++n;
    });
    document.getElementById('extNoMatch').classList.toggle('hidden', n > 0 || !document.querySelectorAll('.ext-row').length);
    document.getElementById('extCount').textContent = n + ' <?= $h(t('extdir_count')) ?>';
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
