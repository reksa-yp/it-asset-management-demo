# Pusat Notifikasi

Semua notifikasi untuk setiap user tersimpan di satu tempat: **ikon lonceng** di kanan atas (semua halaman)
dan halaman **Notifikasi** (`notifications.php`). Angka merah = jumlah yang belum dibuka.

## Isi notifikasi

| Untuk | Notifikasi |
|---|---|
| Admin | Tiket baru (beserta jumlah foto), tiket dibatalkan pelapor, CCTV mati / online kembali (mengikuti batas menit pop-up CCTV), laporan CCTV dari petugas & temuan checklist, aset perlu di-upgrade (catatan pengerjaan berisi "harus upgrade"), Chat Grup |
| User | Tiket saya diproses / selesai / dikembalikan ke antrian, catatan pengerjaan dari IT, Chat Grup (disebut @nama, pengumuman, pesan baru per grup) |

- Mengetuk notifikasi membuka halamannya dan otomatis menandai **dibaca**.
- Membuka grup chat otomatis menandai notifikasi chat grup itu dibaca.
- Pop-up lama (tiket baru, CCTV, chat) tetap muncul; bila ditutup, notifikasinya tetap ada di daftar.
- Isi pesan chat tidak disalin ke notifikasi (chat tetap tersimpan terenkripsi); notifikasi chat hanya berisi nama grup, pengirim, dan jumlah pesan.
- Halaman Notifikasi: tab Belum dibaca / Semua, filter Tiket / CCTV / Chat / Sistem, pilih beberapa lalu **Tandai dibaca** atau **Hapus**.
- Notifikasi disimpan 90 hari lalu terhapus otomatis.

## Aplikasi Android 

- Lonceng dan menu **Notifikasi** (menu bawah user) tampil juga di aplikasi.
- Pengecekan latar belakang (tiap ±2 menit walau aplikasi ditutup) mengambil dari Pusat Notifikasi, jadi user juga
  mendapat notifikasi HP saat tiketnya diproses / selesai.
- Alamat server diatur di aplikasi Android (Pengaturan).

## Teknis

- Tabel baru `app_notifications` (dibuat otomatis, `CREATE TABLE IF NOT EXISTS`; tabel lama tidak diubah).
- File: `includes/notifications.php`, `notif_api.php`, `notifications.php`; pemicu di `ticket_save.php`,
  `ticket_cancel.php`, `ticket_update_status.php`, `ticket_work_detail_save.php`, `includes/cctv.php`, `includes/chat.php`.
