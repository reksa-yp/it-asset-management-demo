<?php
/**
 * Helper bersama untuk relasi banyak-ke-banyak Aset <-> Pengguna (1 aset bisa
 * dipakai beberapa pengguna sekaligus, semua setara/tanpa "pengguna utama").
 * Dipakai oleh: assets.php, asset_save.php, my_asset.php, tickets.php,
 * includes/auth.php, export_excel.php, asset_print_label.php,
 * includes/asset_detail_template.php, dan import_process.php.
 *
 * Tabel asset_owners baru ada setelah migrasi "Multi Pengguna Aset" (menu
 * Upgrade Sistem) dijalankan. Sebelum migrasi dijalankan, semua fungsi di
 * sini berperilaku aman seolah belum ada pengguna sama sekali (bukan error),
 * supaya server yang belum di-upgrade tetap bisa dipakai seperti biasa.
 */

function assetOwnersTableExists(PDO $db): bool
{
    static $exists = null;
    if ($exists === null) {
        $exists = (bool)$db->query("
            SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_owners'
        ")->fetchColumn();
    }
    return $exists;
}

/**
 * Ambil daftar pengguna untuk BANYAK aset sekaligus.
 * Return: [asset_id => [['id'=>.., 'full_name'=>..], ...]]
 */
function getAssetOwnersMap(PDO $db, array $assetIds): array
{
    $assetIds = array_values(array_unique(array_filter(array_map('intval', $assetIds))));
    if (!$assetIds || !assetOwnersTableExists($db)) return [];

    $placeholders = implode(',', array_fill(0, count($assetIds), '?'));
    $stmt = $db->prepare("
        SELECT ao.asset_id, u.id, u.full_name
        FROM asset_owners ao JOIN users u ON u.id = ao.user_id
        WHERE ao.asset_id IN ($placeholders)
        ORDER BY u.full_name
    ");
    $stmt->execute($assetIds);

    $map = [];
    foreach ($stmt->fetchAll() as $r) {
        $map[(int)$r['asset_id']][] = ['id' => (int)$r['id'], 'full_name' => $r['full_name']];
    }
    return $map;
}

/** Gabungkan daftar pengguna (dari getAssetOwnersMap/getOwnersForAsset) jadi 1 string. */
function ownerNamesLabel(array $owners): string
{
    return $owners ? implode(', ', array_column($owners, 'full_name')) : '';
}

/** Ambil daftar pengguna (id, nama, email) untuk SATU aset. */
function getOwnersForAsset(PDO $db, int $assetId): array
{
    if (!assetOwnersTableExists($db)) return [];
    $stmt = $db->prepare("
        SELECT u.id, u.full_name, u.email
        FROM asset_owners ao JOIN users u ON u.id = ao.user_id
        WHERE ao.asset_id = ? ORDER BY u.full_name
    ");
    $stmt->execute([$assetId]);
    return $stmt->fetchAll();
}

/** Ganti seluruh daftar pengguna suatu aset (dipanggil setiap kali aset disimpan). */
function setAssetOwners(PDO $db, int $assetId, array $userIds): void
{
    if (!assetOwnersTableExists($db)) return;
    $userIds = array_values(array_unique(array_filter(array_map('intval', $userIds))));

    $db->prepare("DELETE FROM asset_owners WHERE asset_id = ?")->execute([$assetId]);
    if ($userIds) {
        $ins = $db->prepare("INSERT IGNORE INTO asset_owners (asset_id, user_id) VALUES (?, ?)");
        foreach ($userIds as $uid) {
            $ins->execute([$assetId, $uid]);
        }
    }
}

/** Cek apakah suatu aset termasuk milik (salah satu penggunanya adalah) user tertentu. */
function assetOwnedByUser(PDO $db, int $assetId, int $userId): bool
{
    if (!assetOwnersTableExists($db)) return false;
    $stmt = $db->prepare("SELECT COUNT(*) FROM asset_owners WHERE asset_id = ? AND user_id = ?");
    $stmt->execute([$assetId, $userId]);
    return (bool)$stmt->fetchColumn();
}

/** ID aset-aset milik seorang user (dipakai my_asset.php & tickets.php). */
function getAssetIdsForUser(PDO $db, int $userId): array
{
    if (!assetOwnersTableExists($db)) return [];
    $stmt = $db->prepare("SELECT asset_id FROM asset_owners WHERE user_id = ?");
    $stmt->execute([$userId]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

/**
 * Departemen & lokasi gabungan dari aset-aset milik seorang user. Dipakai
 * sebagai cadangan info pelapor tiket kalau tiket dibuat tanpa memilih aset.
 * Return: ['department' => '..', 'location' => '..'] (string kosong kalau tidak ada).
 */
function userAssetDeptLocation(PDO $db, int $userId): array
{
    static $cache = [];
    if (isset($cache[$userId])) return $cache[$userId];

    $info = ['department' => '', 'location' => ''];
    $ids  = getAssetIdsForUser($db, $userId);
    if ($ids) {
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $st = $db->prepare("SELECT department, location FROM assets WHERE id IN ($ph) ORDER BY id");
        $st->execute($ids);
        $deps = $locs = [];
        foreach ($st->fetchAll() as $a) {
            if (trim((string)$a['department']) !== '') $deps[trim($a['department'])] = true;
            if (trim((string)$a['location']) !== '')   $locs[trim($a['location'])]   = true;
        }
        $info = [
            'department' => implode(', ', array_keys($deps)),
            'location'   => implode(', ', array_keys($locs)),
        ];
    }
    return $cache[$userId] = $info;
}

/**
 * Departemen & lokasi pelapor untuk 1 baris tiket. Baris harus punya kolom
 * reported_by, user_department, asset_department, asset_location (hasil JOIN
 * users + assets). Urutan sumber: departemen user -> departemen aset tiket ->
 * aset milik pelapor; lokasi aset tiket -> lokasi aset milik pelapor.
 * Return: ['department' => '..', 'location' => '..'] ('-' kalau tidak ada data).
 */
function ticketReporterDeptLocation(PDO $db, array $row): array
{
    $department = trim((string)($row['user_department'] ?? ''));
    if ($department === '') $department = trim((string)($row['asset_department'] ?? ''));
    $location   = trim((string)($row['asset_location'] ?? ''));

    if (($department === '' || $location === '') && !empty($row['reported_by'])) {
        $fallback = userAssetDeptLocation($db, (int)$row['reported_by']);
        if ($department === '') $department = $fallback['department'];
        if ($location === '')   $location   = $fallback['location'];
    }
    return [
        'department' => $department !== '' ? $department : '-',
        'location'   => $location !== '' ? $location : '-',
    ];
}
