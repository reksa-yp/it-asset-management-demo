<?php
/**
 * Helper fitur Scan QR aset.
 *
 * QR di label berisi alamat halaman scan.php?no=<Nomor Aset>, sehingga bisa dibuka langsung
 * dari kamera bawaan HP. Scanner USB / kamera di dalam sistem mengirim teks hasil scan apa
 * adanya (alamat lengkap ATAU hanya nomor aset dari label lama) -> scanExtractAssetNumber().
 * Tidak ada tabel / kolom baru: pencarian memakai assets.asset_number yang sudah ada.
 */

/** Alamat dasar sistem (mis. http://192.168.131.253/it_system_tmnn/) untuk isi QR. */
function scanBaseUrl(): string
{
    $https  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
           || strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
    $host   = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
    // Label dicetak dari PC server lewat "localhost" -> HP tidak bisa membuka alamat itu.
    // Ganti dengan IP jaringan server supaya QR tetap bisa dibuka dari perangkat lain.
    if (preg_match('/^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i', $host, $m)) {
        $ip = gethostbyname((string)gethostname());
        if (filter_var($ip, FILTER_VALIDATE_IP) && strpos($ip, '127.') !== 0) {
            $host = $ip . ($m[2] ?? '');
        }
    }
    $dir = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
    return ($https ? 'https' : 'http') . '://' . $host . $dir . '/';
}

/** Alamat yang dimasukkan ke QR label untuk 1 nomor aset. */
function scanAssetUrl(string $assetNumber): string
{
    // "/" di nomor aset dibiarkan apa adanya supaya QR lebih pendek (lebih mudah terbaca kamera).
    return scanBaseUrl() . 'scan.php?no=' . str_replace('%2F', '/', rawurlencode($assetNumber));
}

/** Ambil nomor aset dari teks hasil scan: alamat scan.php?no=... atau nomor aset polos. */
function scanExtractAssetNumber(string $raw): string
{
    $raw = trim($raw);
    if ($raw === '') return '';
    if (preg_match('/[?&]no=([^&#\s]+)/i', $raw, $m)) {
        return trim(rawurldecode($m[1]));
    }
    return $raw;
}

/** Cari aset berdasarkan nomor aset persis. Null kalau tidak ada. */
function scanFindAsset(PDO $db, string $assetNumber): ?array
{
    if ($assetNumber === '') return null;
    $stmt = $db->prepare("SELECT id, asset_number FROM assets WHERE asset_number = ? LIMIT 1");
    $stmt->execute([$assetNumber]);
    return $stmt->fetch() ?: null;
}
