<?php
/**
 * Bagian "Pekerjaan CCTV" (daftar kartu + form tambah/edit), khusus admin.
 * Variabel yang harus ada: $db, $jobsCtx = ['jobs' => [...], 'date' => 'Y-m-d', 'shift' => '', 'back' => 'cctv_....php?...',
 *   'title' => judul, 'sub' => keterangan, 'show_date' => bool].
 */
require_once __DIR__ . '/cctv_jobs.php';
$jh = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES);
$jTypes  = cctvJobTypes($db);
$jAllTypes = array_column(cctvJobTypes($db, false), null, 'id');
$jNvrs   = cctvNvrList($db);
$jCams   = cctvCameras($db);
$jStock  = cctvJobStockOptions($db);
$jStockCams = cctvJobStockCameras($db);
$jShifts = cctvShiftOptions();
$jMsg = $_SESSION['cctv_job_msg'] ?? null;
unset($_SESSION['cctv_job_msg']);
?>
<section id="pekerjaan" class="bg-white rounded-xl shadow-sm p-4 mt-5 scroll-mt-20">
    <div class="flex flex-wrap items-start justify-between gap-3 mb-3">
        <div>
            <h2 class="font-semibold text-slate-800 flex items-center gap-2"><?= icon('wrench', 'w-5 h-5 text-slate-500') ?> <?= $jh($jobsCtx['title']) ?></h2>
            <p class="text-xs text-slate-500 mt-0.5"><?= $jh($jobsCtx['sub']) ?></p>
        </div>
        <button type="button" class="cj-new inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium" data-type=""><?= icon('plus', 'w-4 h-4') ?> <?= $jh(cL('Tambah pekerjaan', 'Add job')) ?></button>
    </div>
    <?php if ($jMsg): ?><div class="mb-3 text-sm rounded-lg px-3 py-2 <?= $jMsg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $jh($jMsg['msg']) ?></div><?php endif; ?>
    <div class="flex flex-wrap gap-2 mb-3">
        <?php foreach ($jTypes as $t): ?>
            <button type="button" class="cj-new text-xs font-medium rounded-full border border-dashed border-slate-300 bg-slate-50 hover:border-blue-500 hover:text-blue-700 px-3 py-1.5" data-type="<?= (int)$t['id'] ?>"><?= $jh($t['name']) ?></button>
        <?php endforeach; ?>
    </div>
    <?php if (!$jobsCtx['jobs']): ?>
        <p class="text-sm text-slate-400 italic text-center py-5"><?= $jh(cL('Belum ada pekerjaan.', 'No jobs yet.')) ?></p>
    <?php endif; ?>
    <div class="space-y-2">
    <?php foreach ($jobsCtx['jobs'] as $j):
        $edit = [
            'id' => (int)$j['id'], 'date' => $j['job_date'], 'shift' => $j['shift'], 'type' => (int)$j['type_id'], 'nvr' => (int)$j['nvr_id'], 'cam' => (int)$j['camera_id'],
            'd' => $j['detail'], 'status' => $j['status'], 'officers' => $j['officers'], 'note' => (string)$j['note'], 'photos' => $j['photos'],
            'stock' => (int)$j['stock_trx_id'] ? ['key' => '', 'text' => (string)$j['stock_text']] : null,
            'assets' => array_map(fn($l) => $l['asset_number'], $j['assets']),
        ];
        if ((int)$j['stock_trx_id']) {
            $st = $db->prepare("SELECT category_id, item_name, qty FROM stock_transactions WHERE id = ?");
            $st->execute([(int)$j['stock_trx_id']]);
            if ($sr = $st->fetch()) $edit['stock'] = ['key' => $sr['category_id'] . '|' . $sr['item_name'], 'qty' => (int)$sr['qty'], 'text' => (string)$j['stock_text']];
        }
    ?>
        <div class="border border-slate-200 rounded-xl p-3 flex gap-3 items-start">
            <span class="shrink-0 w-9 h-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center"><?= icon($j['kind'] === 'add' || $j['kind'] === 'cam' ? 'camera' : 'wrench', 'w-5 h-5') ?></span>
            <div class="flex-1 min-w-0">
                <div class="font-semibold text-slate-800 text-sm"><?= $jh($j['type_name']) ?></div>
                <div class="text-xs text-slate-500"><?= $jh(implode(' · ', array_filter([
                    $j['nvr_name'], $j['camera_label'],
                    !empty($jobsCtx['show_date']) ? date('d/m/Y', strtotime($j['job_date'])) . ($j['shift'] !== '' ? ' ' . $j['shift'] : '') : '',
                    $j['officers'] ?: $j['created_by_name'],
                ]))) ?></div>
                <?php $lines = cctvJobDetailLines($j); if ($lines || $j['note']): ?>
                <ul class="list-disc pl-5 mt-1 text-sm text-slate-700 space-y-0.5">
                    <?php foreach ($lines as $l): ?><li><?= $jh($l) ?></li><?php endforeach; ?>
                    <?php if ($j['note']): ?><li class="italic text-slate-600"><?= $jh($j['note']) ?></li><?php endif; ?>
                </ul>
                <?php endif; ?>
                <?php if ($j['photos']): ?>
                <div class="flex flex-wrap gap-1.5 mt-2">
                    <?php foreach ($j['photos'] as $ph): ?><a href="<?= $jh(CCTV_PHOTO_URL . '/' . $ph) ?>" target="_blank"><img src="<?= $jh(CCTV_PHOTO_URL . '/' . $ph) ?>" alt="" class="w-16 h-12 object-cover rounded-md border border-slate-200"></a><?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="flex flex-col items-end gap-1.5 shrink-0">
                <?= cctvJobStatusBadge($j['status']) ?>
                <button type="button" class="cj-edit inline-flex items-center gap-1 border border-slate-200 rounded-lg px-2 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50" data-job="<?= $jh(json_encode($edit, JSON_UNESCAPED_UNICODE)) ?>"><?= icon('pencil', 'w-3.5 h-3.5') ?> Edit</button>
                <form method="post" action="cctv_job_save.php" onsubmit="return confirm(<?= $jh(json_encode(cL('Hapus pekerjaan ini? Barang yang diambil dari stok akan dikembalikan ke stok. Aset kamera yang sudah dibuat tidak ikut terhapus.', 'Delete this job? Items taken from stock are returned. Camera assets are kept.'))) ?>)">
                    <input type="hidden" name="csrf_token" value="<?= $jh(csrfToken()) ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="job_id" value="<?= (int)$j['id'] ?>"><input type="hidden" name="back" value="<?= $jh($jobsCtx['back']) ?>">
                    <button class="inline-flex items-center gap-1 text-xs font-medium text-red-600 hover:underline px-1"><?= icon('trash', 'w-3.5 h-3.5') ?> <?= $jh(cL('Hapus', 'Delete')) ?></button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</section>

<!-- Modal tambah / edit pekerjaan -->
<div id="cjModal" class="hidden fixed inset-0 z-50 items-center justify-center p-4 bg-slate-900/50">
    <form method="post" action="cctv_job_save.php" enctype="multipart/form-data" id="cjForm" class="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[92vh] overflow-y-auto p-5 space-y-3 text-sm">
        <input type="hidden" name="csrf_token" value="<?= $jh(csrfToken()) ?>"><input type="hidden" name="act" value="save"><input type="hidden" name="job_id" value="0"><input type="hidden" name="back" value="<?= $jh($jobsCtx['back']) ?>">
        <div class="flex items-center justify-between gap-3">
            <h3 class="font-semibold text-slate-800 text-base" id="cjTitle"></h3>
            <button type="button" data-cj-close class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Tanggal', 'Date')) ?><input type="date" name="job_date" max="<?= date('Y-m-d') ?>" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800" required></label>
            <label class="text-xs font-medium text-slate-500">Shift<select name="shift" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"><option value="">—</option><?php foreach ($jShifts as $s): ?><option value="<?= $jh($s) ?>"><?= $jh($s) ?></option><?php endforeach; ?></select></label>
            <label class="text-xs font-medium text-slate-500">Status<select name="status" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"><?php foreach (cctvJobStatuses() as $k => $l): ?><option value="<?= $k ?>"><?= $jh($l) ?></option><?php endforeach; ?></select></label>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Jenis pekerjaan', 'Job type')) ?>
                <select name="type_id" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800" required>
                    <?php foreach ($jAllTypes as $t): ?><option value="<?= (int)$t['id'] ?>" data-kind="<?= $jh($t['kind']) ?>" data-hint="<?= $jh(mb_strtolower($t['stock_hint'])) ?>" <?= (int)$t['is_active'] ? '' : 'hidden' ?>><?= $jh($t['name']) ?></option><?php endforeach; ?>
                </select></label>
            <label class="text-xs font-medium text-slate-500">NVR
                <select name="nvr_id" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"><option value="0">—</option><?php foreach ($jNvrs as $n): ?><option value="<?= (int)$n['id'] ?>"><?= $jh($n['name'] . ($n['ip_address'] ? ' (' . $n['ip_address'] . ')' : '')) ?></option><?php endforeach; ?></select></label>
        </div>

        <div class="cj-k cj-k-hdd border border-slate-200 rounded-xl p-3 bg-slate-50 space-y-2">
            <div class="text-xs font-semibold uppercase text-slate-500"><?= $jh(cL('Rincian hardisk', 'Hard disk details')) ?></div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Jumlah HDD', 'HDD count')) ?><input type="number" min="1" name="d_qty" value="1" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
                <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Kapasitas / HDD (TB)', 'Capacity / HDD (TB)')) ?><input type="number" min="0" step="0.5" name="d_cap" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
                <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Merek / tipe', 'Brand / type')) ?><input name="d_brand" maxlength="100" placeholder="WD Purple" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
                <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Kapasitas sebelum (TB)', 'Capacity before (TB)')) ?><input type="number" min="0" step="0.5" name="d_before" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
                <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Kapasitas sesudah (TB)', 'Capacity after (TB)')) ?><input type="number" min="0" step="0.5" name="d_after" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
                <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Perkiraan lama rekam', 'Est. recording time')) ?><input name="d_days" maxlength="40" placeholder="± 30 <?= $jh(cL('hari', 'days')) ?>" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
            </div>
        </div>

        <div class="cj-k cj-k-add border border-slate-200 rounded-xl p-3 bg-slate-50 space-y-2">
            <div class="text-xs font-semibold uppercase text-slate-500"><?= $jh(cL('Rincian titik baru', 'New camera points')) ?></div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Jumlah titik', 'Points')) ?><input type="number" min="1" max="64" name="d_qty" value="1" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
                <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Channel awal di NVR', 'First NVR channel')) ?><input type="number" min="1" max="256" name="d_ch" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
                <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Merek / tipe kamera', 'Camera brand / type')) ?><input name="d_model" maxlength="100" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
            </div>
            <label class="block text-xs font-medium text-slate-500"><?= $jh(cL('Lokasi titik baru', 'Location')) ?><input name="d_loc" maxlength="150" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
            <div class="cj-assetpick border border-slate-200 rounded-lg bg-white p-2.5 space-y-1.5">
                <div class="text-xs font-semibold uppercase text-slate-500"><?= $jh(cL('Kamera di menu Aset', 'Camera assets')) ?></div>
                <label class="flex gap-2 items-start"><input type="radio" name="asset_mode" value="stock" class="mt-0.5" <?= $jStockCams ? '' : 'disabled' ?>> <span><?= $jh(cL('Pakai kamera CCTV berstatus Stok', 'Use CCTV cameras with status Stock')) ?> (<?= count($jStockCams) ?> <?= $jh(cL('tersedia', 'available')) ?>) — <?= $jh(cL('jadi Digunakan, NVR & channel terisi', 'set to In use with NVR & channel')) ?></span></label>
                <?php if ($jStockCams): ?>
                <div class="pl-6 max-h-36 overflow-y-auto space-y-1">
                    <?php foreach ($jStockCams as $sc): ?><label class="flex gap-2 items-center text-sm"><input type="checkbox" name="stock_cams[]" value="<?= (int)$sc['id'] ?>" class="cj-sc"> <?= $jh($sc['asset_number'] . ($sc['device_name'] || $sc['motherboard_brand'] ? ' · ' . trim($sc['device_name'] . ' ' . $sc['motherboard_brand']) : '')) ?></label><?php endforeach; ?>
                </div>
                <?php endif; ?>
                <label class="flex gap-2 items-start"><input type="radio" name="asset_mode" value="new" class="mt-0.5"> <span><?= $jh(cL('Buat aset CCTV baru (nomor aset otomatis, sejumlah titik)', 'Create new CCTV assets (auto asset numbers, one per point)')) ?></span></label>
                <label class="flex gap-2 items-start"><input type="radio" name="asset_mode" value="none" class="mt-0.5" checked> <span><?= $jh(cL('Jangan daftarkan dulu', 'Do not register yet')) ?></span></label>
            </div>
            <p class="cj-assetdone hidden text-xs text-slate-600"></p>
        </div>

        <div class="cj-k cj-k-cam cj-k-other space-y-2">
            <label class="block text-xs font-medium text-slate-500"><?= $jh(cL('Kamera terkait', 'Related camera')) ?>
                <select name="camera_id" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"><option value="0">—</option>
                    <?php foreach (cctvNvrGroups($jCams) as $g): ?><optgroup label="<?= $jh($g['name']) ?>"><?php foreach ($g['cams'] as $c): ?><option value="<?= (int)$c['id'] ?>"><?= $jh($c['number'] . ' · ' . ($c['name'] ?: $c['location']) . ($c['channel'] ? ' · ch ' . $c['channel'] : '')) ?></option><?php endforeach; ?></optgroup><?php endforeach; ?>
                </select></label>
            <label class="block text-xs font-medium text-slate-500"><?= $jh(cL('Yang dikerjakan', 'Work done')) ?><input name="d_what" maxlength="250" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
        </div>

        <?php if ($jStock): ?>
        <div class="border border-slate-200 rounded-xl p-3 bg-slate-50 space-y-2">
            <div class="text-xs font-semibold uppercase text-slate-500 flex items-center gap-1.5"><?= icon('package', 'w-4 h-4') ?> <?= $jh(cL('Barang dari Stok Barang', 'Items from stock')) ?></div>
            <label class="flex gap-2 items-start"><input type="checkbox" name="use_stock" value="1" class="mt-0.5 cj-usestock"> <span><?= $jh(cL('Ambil dari stok — dicatat sebagai Barang Keluar untuk "CCTV", stok berkurang otomatis', 'Take from stock — recorded as stock out for "CCTV"')) ?></span></label>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <label class="sm:col-span-2 text-xs font-medium text-slate-500"><?= $jh(cL('Barang', 'Item')) ?>
                    <select name="stock_key" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800">
                        <?php foreach ($jStock as $so): ?><option value="<?= $jh($so['key']) ?>" data-s="<?= (int)$so['s'] ?>" data-unit="<?= $jh($so['unit']) ?>" data-search="<?= $jh(mb_strtolower($so['cat_name'] . ' ' . $so['item'])) ?>" <?= $so['s'] > 0 ? '' : 'disabled' ?>><?= $jh($so['cat_name'] . ' · ' . $so['item'] . ' — ' . cL('sisa ', 'left ') . max(0, $so['s']) . ' ' . $so['unit'] . ($so['s'] > 0 ? '' : cL(' (habis)', ' (out of stock)'))) ?></option><?php endforeach; ?>
                    </select></label>
                <label class="text-xs font-medium text-slate-500"><?= $jh(cL('Jumlah', 'Qty')) ?><input type="number" min="1" name="stock_qty" value="1" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
            </div>
            <p class="text-xs text-slate-500"><?= $jh(cL('Hanya barang yang masih ada stoknya yang bisa dipilih; jumlah tidak boleh melebihi sisa stok.', 'Only items still in stock can be chosen.')) ?></p>
        </div>
        <?php endif; ?>

        <label class="block text-xs font-medium text-slate-500"><?= $jh(cL('Petugas', 'Officers')) ?><input name="officers" maxlength="150" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></label>
        <label class="block text-xs font-medium text-slate-500"><?= $jh(cL('Keterangan', 'Notes')) ?><textarea name="note" rows="2" maxlength="2000" class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800"></textarea></label>
        <div>
            <label class="block text-xs font-medium text-slate-500"><?= $jh(cL('Foto sebelum / sesudah (maks. ', 'Before / after photos (max. ') . CCTV_JOB_PHOTO_MAX . ')') ?>
                <input type="file" name="photos[]" accept="image/*" multiple class="mt-0.5 w-full border rounded-lg px-2 py-1.5 text-sm text-slate-800 bg-white"></label>
            <div id="cjPhotos" class="flex flex-wrap gap-2 mt-1.5"></div>
        </div>
        <div class="flex justify-end gap-2 border-t pt-3">
            <button type="button" data-cj-close class="border border-slate-200 rounded-lg px-4 py-2 font-medium text-slate-700 hover:bg-slate-50"><?= $jh(cL('Batal', 'Cancel')) ?></button>
            <button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium"><?= $jh(cL('Simpan', 'Save')) ?></button>
        </div>
    </form>
</div>
<script>
(function () {
    var modal = document.getElementById('cjModal'), F = document.getElementById('cjForm');
    var ctx = <?= json_encode(['date' => $jobsCtx['date'], 'shift' => $jobsCtx['shift'], 'me' => (string)(currentUser()['full_name'] ?? ''), 'photoUrl' => CCTV_PHOTO_URL,
        't_add' => cL('Tambah pekerjaan CCTV', 'Add CCTV job'), 't_edit' => cL('Edit pekerjaan CCTV', 'Edit CCTV job'), 'remove' => cL('hapus', 'remove'),
        'assets_done' => cL('Aset kamera sudah tercatat: ', 'Camera assets already registered: '), 'stock_over' => cL('Jumlah melebihi sisa stok.', 'Quantity exceeds stock.'),
        'pick_cam' => cL('Centang kamera stok yang dipakai.', 'Tick the stock cameras used.')], JSON_UNESCAPED_UNICODE) ?>;
    function kindOf() { var o = F.type_id.options[F.type_id.selectedIndex]; return o ? o.dataset.kind : 'other'; }
    function syncKind() {
        var k = kindOf();
        F.querySelectorAll('.cj-k').forEach(function (box) {
            var on = box.classList.contains('cj-k-' + k);
            box.classList.toggle('hidden', !on);
            box.querySelectorAll('input,select,textarea').forEach(function (i) { i.disabled = !on || (i.type === 'radio' && i.value === 'stock' && <?= $jStockCams ? 'false' : 'true' ?>); });
        });
    }
    function suggestStock() {
        if (!F.stock_key) return;
        var o = F.type_id.options[F.type_id.selectedIndex], hint = o ? o.dataset.hint : '';
        var match = null;
        if (hint) Array.from(F.stock_key.options).forEach(function (op) { if (!match && !op.disabled && op.dataset.search.indexOf(hint) >= 0) match = op; });
        F.use_stock.checked = !!match;
        if (match) F.stock_key.value = match.value;
        else { var first = Array.from(F.stock_key.options).find(function (op) { return !op.disabled; }); if (first) F.stock_key.value = first.value; }
    }
    function set(name, v) { var els = F.querySelectorAll('[name="' + name + '"]'); els.forEach(function (el) { if (!el.disabled || true) el.value = v == null ? '' : v; }); }
    function open(job, typeId) {
        F.reset();
        F.job_id.value = job ? job.id : 0;
        document.getElementById('cjTitle').textContent = job ? ctx.t_edit : ctx.t_add;
        F.job_date.value = job ? job.date : ctx.date;
        F.shift.value = job ? job.shift : ctx.shift;
        if (job) F.type_id.value = job.type; else if (typeId) F.type_id.value = typeId; else F.type_id.selectedIndex = Array.from(F.type_id.options).findIndex(function (o) { return !o.hidden; });
        F.nvr_id.value = job ? (job.nvr || 0) : 0;
        F.status.value = job ? job.status : 'ok';
        F.officers.value = job ? job.officers : ctx.me;
        F.note.value = job ? job.note : '';
        syncKind();
        var d = job ? (job.d || {}) : {};
        ['qty', 'cap', 'brand', 'before', 'after', 'days', 'ch', 'loc', 'model', 'what'].forEach(function (k) {
            F.querySelectorAll('[name="d_' + k + '"]').forEach(function (el) { el.value = d[k] != null ? d[k] : (k === 'qty' ? 1 : ''); });
        });
        F.camera_id.value = job ? (job.cam || 0) : 0;
        // aset kamera: hanya bisa dipilih sekali
        var done = job && job.assets && job.assets.length;
        F.querySelector('.cj-assetpick').classList.toggle('hidden', !!done);
        var ad = F.querySelector('.cj-assetdone'); ad.classList.toggle('hidden', !done); ad.textContent = done ? ctx.assets_done + job.assets.join(', ') : '';
        if (F.stock_key) {
            if (job) {
                F.use_stock.checked = !!(job.stock && job.stock.key);
                if (job.stock && job.stock.key) {
                    var op = Array.from(F.stock_key.options).find(function (o) { return o.value === job.stock.key; });
                    if (op) { op.disabled = false; F.stock_key.value = op.value; }
                    F.stock_qty.value = job.stock.qty || 1;
                }
            } else suggestStock();
        }
        var ph = document.getElementById('cjPhotos'); ph.innerHTML = '';
        (job ? job.photos : []).forEach(function (p) {
            var w = document.createElement('label'); w.className = 'flex flex-col items-center gap-0.5 text-[11px] text-slate-500';
            w.innerHTML = '<img class="w-16 h-12 object-cover rounded-md border" alt=""><span><input type="checkbox" name="remove_photo[]"> ' + ctx.remove + '</span>';
            w.querySelector('img').src = ctx.photoUrl + '/' + p; w.querySelector('input').value = p; ph.appendChild(w);
        });
        modal.classList.remove('hidden'); modal.classList.add('flex');
    }
    function close() { modal.classList.add('hidden'); modal.classList.remove('flex'); }
    F.type_id.addEventListener('change', function () { syncKind(); if (F.job_id.value === '0') suggestStock(); });
    F.addEventListener('submit', function (e) {
        if (F.use_stock && F.use_stock.checked && !F.use_stock.disabled) {
            var op = F.stock_key.options[F.stock_key.selectedIndex];
            if (op && F.job_id.value === '0' && parseInt(F.stock_qty.value, 10) > parseInt(op.dataset.s, 10)) { e.preventDefault(); alert(ctx.stock_over); return; }
        }
        var m = F.querySelector('input[name="asset_mode"]:checked');
        if (kindOf() === 'add' && m && m.value === 'stock' && !F.querySelector('.cj-sc:checked')) { e.preventDefault(); alert(ctx.pick_cam); }
    });
    document.addEventListener('click', function (e) {
        var n = e.target.closest('.cj-new'); if (n) { open(null, n.dataset.type); return; }
        var ed = e.target.closest('.cj-edit'); if (ed) { open(JSON.parse(ed.dataset.job)); return; }
        if (e.target.closest('[data-cj-close]') || e.target === modal) close();
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
})();
</script>
