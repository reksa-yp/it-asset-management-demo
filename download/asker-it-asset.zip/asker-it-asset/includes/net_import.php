<?php
/**
 * Import Perangkat Jaringan (switch, hub, router, access point) dari Excel — alurnya sama dengan Import CCTV.
 *
 * Sheet "Jaringan":
 *   Nomor Aset | Jenis | Nama Perangkat | Lokasi | IP Address | Brand | Type | Jumlah Port |
 *   Terhubung ke | Port Uplink | Serial Number | Tanggal Pembelian | Status
 *
 * Aturan:
 *   - Nomor Aset kosong -> aset baru (nomor dibuat otomatis), kecuali IP / nama+lokasi sudah dipakai
 *     perangkat jaringan yang ada -> data itu diperbarui.
 *   - Saat memperbarui, sel kosong = data lama tetap; isi "-" untuk mengosongkan.
 *   - "Terhubung ke" boleh menyebut perangkat yang ada di file yang sama (nama / nomor aset / IP).
 *   - Jenis yang belum ada di Kategori Aset (mis. "Access Point") dibuat otomatis.
 * Tidak ada tabel lama yang diubah strukturnya: data masuk ke assets + tabel baru asset_cctv_info (Brand/Type),
 * net_device_info (jumlah port) dan net_links (Terhubung ke).
 */
require_once __DIR__ . '/categories.php';
require_once __DIR__ . '/network.php';
require_once __DIR__ . '/cctv_import.php';   // cctvImpCell(), cctvImpStatus(), cctvImpSaveAsset(), cctvImpAssetRow()

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\DataValidation;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

/** Jenis standar yang ditawarkan di template (dibuat otomatis bila belum ada) => singkatan nomor aset. */
const NET_IMP_STD_KINDS = ['Switch' => 'SW', 'Hub' => 'HUB', 'Router' => 'RTR', 'Access Point' => 'AP'];

function netImpColumns(): array
{
    return [
        'number'   => ['Nomor Aset', 'Asset Number', 22, ['no aset', 'no. aset', 'id aset', 'asset id']],
        'kind'     => ['Jenis', 'Type of Device', 16, ['jenis perangkat', 'jenis aset', 'kategori', 'device type', 'category']],
        'name'     => ['Nama Perangkat', 'Device Name', 26, ['device name', 'nama']],
        'location' => ['Lokasi', 'Location', 22, ['location']],
        'ip'       => ['IP Address', 'IP Address', 16, ['ip', 'alamat ip']],
        'brand'    => ['Brand', 'Brand', 14, ['merk', 'merek']],
        'type'     => ['Type', 'Model', 20, ['tipe', 'model']],
        'ports'    => ['Jumlah Port', 'Ports', 12, ['port', 'jumlah port', 'ports', 'jumlah port lan', 'port lan']],
        'sfp'      => ['Port SFP', 'SFP Ports', 10, ['jumlah port sfp', 'sfp']],
        'parent'   => ['Terhubung ke', 'Connected to', 26, ['terhubung ke (uplink)', 'uplink', 'connected to']],
        'uplink'   => ['Port Uplink', 'Uplink Port', 14, ['port uplink', 'uplink port', 'port di atasnya', 'port di perangkat atas']],
        'own'      => ['Port di Perangkat Ini', 'Port on This Device', 16, ['port perangkat ini', 'own port', 'port sendiri']],
        'extra'    => ['Koneksi Tambahan', 'Extra Links', 36, ['jalur cadangan', 'koneksi lain', 'extra link']],
        'serial'   => ['Serial Number', 'Serial Number', 20, ['sn', 'serial']],
        'date'     => ['Tanggal Pembelian', 'Purchase Date', 16, ['purchase date', 'tgl pembelian']],
        'status'   => ['Status', 'Status', 14, []],
    ];
}

/** Baris judul + peta kolom sheet Jaringan; null bila bukan sheet import jaringan. */
function netImpHeader(Worksheet $ws): ?array
{
    $maxRow = min(20, $ws->getHighestDataRow());
    for ($r = 1; $r <= $maxRow; $r++) {
        $cells = $ws->rangeToArray('A' . $r . ':' . $ws->getHighestDataColumn($r) . $r, null, true, false, true)[$r] ?? [];
        $norm = [];
        foreach ($cells as $col => $v) $norm[$col] = rtrim(mb_strtolower(trim(preg_replace('/\s+/', ' ', (string)$v))), ' *');
        $hasName = in_array('nama perangkat', $norm, true) || in_array('device name', $norm, true);
        $hasLink = in_array('terhubung ke', $norm, true) || in_array('connected to', $norm, true);
        if (!$hasName || !$hasLink) continue;
        $map = [];
        foreach (netImpColumns() as $key => [$id, $en, , $alias]) {
            $want = array_merge([mb_strtolower($id), mb_strtolower($en)], $alias);
            foreach ($norm as $col => $text) {
                if ($text !== '' && in_array($text, $want, true) && !in_array($col, $map, true)) { $map[$key] = $col; break; }
            }
        }
        return ['row' => $r, 'map' => $map];
    }
    return null;
}

function isNetImportSpreadsheet(Spreadsheet $ss): bool
{
    foreach ($ss->getWorksheetIterator() as $ws) if (netImpHeader($ws)) return true;
    return false;
}

/** Kategori perangkat jaringan yang ada di Kategori Aset. */
function netImpCategories(PDO $db): array
{
    return array_values(array_filter(array_column(getAssetCategories($db), 'name'), 'isNetDeviceCategory'));
}

/** Jenis standar yang belum ada di Kategori Aset. */
function netImpMissingStdKinds(PDO $db): array
{
    $have = array_map('mb_strtolower', array_column(getAssetCategories($db), 'name'));
    return array_values(array_filter(array_keys(NET_IMP_STD_KINDS), fn($k) => !in_array(mb_strtolower($k), $have, true)));
}

/** Tambah kategori jaringan (bila belum ada). Return nama kategori yang dipakai. */
function netImpEnsureCategory(PDO $db, string $name): string
{
    foreach (getAssetCategories($db) as $c) if (mb_strtolower($c['name']) === mb_strtolower($name)) return (string)$c['name'];
    $abbr = NET_IMP_STD_KINDS[$name] ?? null;
    if (!$abbr) {
        $words = preg_split('/\s+/', trim(preg_replace('/[^A-Za-z0-9 ]/', ' ', $name)));
        $abbr = count($words) > 1 ? implode('', array_map(fn($w) => $w[0] ?? '', $words)) : substr($words[0] ?? 'NET', 0, 3);
        $abbr = strtoupper($abbr ?: 'NET');
    }
    $sort = (int)$db->query("SELECT COALESCE(MAX(sort_order), 0) FROM asset_categories")->fetchColumn() + 1;
    $db->prepare("INSERT INTO asset_categories (name, abbr, sort_order) VALUES (?, ?, ?)")->execute([$name, $abbr, $sort]);
    return $name;
}

/** "switch", "SWITCH", "ap", "wifi" -> nama kategori yang ada / jenis standar. '' bila tidak dikenali. */
function netImpResolveKind(string $v, array $cats): string
{
    $k = mb_strtolower(trim($v));
    if ($k === '') return '';
    foreach ($cats as $c) if (mb_strtolower($c) === $k) return $c;
    $alias = ['ap' => 'Access Point', 'access point' => 'Access Point', 'wifi' => 'Access Point', 'wi-fi' => 'Access Point',
              'switch' => 'Switch', 'switch hub' => 'Switch', 'hub' => 'Hub', 'router' => 'Router'];
    $std = $alias[$k] ?? '';
    if ($std !== '') {
        foreach ($cats as $c) if (mb_strtolower($c) === mb_strtolower($std)) return $c;
        return $std;                                   // dibuat otomatis saat disimpan
    }
    return isNetDeviceCategory($v) ? trim($v) : '';     // nama kategori jaringan baru, mis. "Firewall"
}

/**
 * Baca & periksa file. Tidak menulis apa pun ke database.
 * Hasil: ['rows' => [...], 'notes' => [...]]. Tiap row: excel_row, d, action new|update|error, asset_id, asset_number,
 * category, parent (['id'=>..] / ['row'=>index] / null), errors[], warnings[].
 */
function netImportPlan(PDO $db, Spreadsheet $ss): array
{
    ensureNetTables($db);
    $cats = netImpCategories($db);
    $notes = [];
    $sheet = null;
    foreach ($ss->getWorksheetIterator() as $ws) { if ($hd = netImpHeader($ws)) { $sheet = [$ws, $hd]; break; } }
    if (!$sheet) return ['rows' => [], 'notes' => [nL('Sheet Jaringan tidak ditemukan. Pakai template import Perangkat Jaringan.', 'Network sheet not found. Use the network import template.')]];
    [$ws, $hd] = $sheet;

    // Perangkat jaringan yang sudah ada.
    $all = netAssets($db);
    $netDev = array_filter($all, fn($a) => $a['is_net']);
    $byIp = $byNameLoc = $keyToId = [];
    $devIps = netDeviceIpsMap($db, array_keys($netDev));
    foreach ($netDev as $a) {
        if ($a['ip'] !== '') $byIp[$a['ip']] = $a['id'];
        foreach ($devIps[$a['id']] ?? [] as $di) $byIp[$di['ip']] = $a['id'];
        $byNameLoc[mb_strtolower($a['name'] . '|' . $a['loc'])] = $a['id'];
        foreach ([$a['name'], $a['number'], $a['ip']] as $k) if ($k !== '') $keyToId[mb_strtolower($k)] = $a['id'];
    }
    $numSt = $db->prepare("SELECT id, category FROM assets WHERE asset_number = ? LIMIT 1");

    $rows = [];
    $seenIp = [];
    for ($r = $hd['row'] + 1, $last = $ws->getHighestDataRow(); $r <= $last; $r++) {
        $d = [];
        foreach (array_keys(netImpColumns()) as $k) $d[$k] = cctvImpCell($ws, $hd['map'][$k] ?? null, $r);
        if (implode('', $d) === '') continue;
        $row = ['excel_row' => $r, 'd' => $d, 'action' => 'new', 'asset_id' => 0, 'asset_number' => '', 'category' => '',
                'parent' => null, 'errors' => [], 'warnings' => [], 'ips' => [], 'main_ip' => ''];
        // IP Address boleh berisi beberapa IP / segmen, mis. "192.168.1.1/24, 192.168.2.1/24".
        // IP utama (untuk ping) = IP di segmen server; semua IP disimpan di tabel net_device_ips.
        if ($d['ip'] !== '' && $d['ip'] !== '-') {
            $pl = netParseIpList($d['ip']);
            if ($pl['bad']) $row['errors'][] = nL('IP Address tidak valid', 'Invalid IP address') . ': ' . implode(', ', $pl['bad']);
            $row['ips'] = $pl['items'];
            $row['main_ip'] = netPickMainIp($pl['items']);
        }
        if ($d['status'] !== '' && !in_array(cctvImpStatus($d['status']), CCTV_IMP_STATUSES, true)) $row['errors'][] = nL('Status harus Digunakan / Stok / Tidak Digunakan', 'Status must be Digunakan / Stok / Tidak Digunakan');
        if ($d['ports'] !== '' && $d['ports'] !== '-' && (!ctype_digit($d['ports']) || (int)$d['ports'] < 1 || (int)$d['ports'] > 9999)) $row['errors'][] = nL('Jumlah Port harus angka', 'Ports must be a number');
        if ($d['sfp'] !== '' && $d['sfp'] !== '-' && (!ctype_digit($d['sfp']) || (int)$d['sfp'] > 64)) $row['errors'][] = nL('Port SFP harus angka', 'SFP ports must be a number');
        // Format lama "16 ⇄ eth8" di Port Uplink: kiri = port perangkat atas, kanan = port perangkat ini.
        if ($d['own'] === '' && $d['uplink'] !== '' && $d['uplink'] !== '-') {
            [$up, $own] = netSplitPortText($d['uplink']);
            if ($own !== '') { $row['d']['uplink'] = $up; $row['d']['own'] = $own; }
        }
        // Koneksi Tambahan: "Firewall (eth1 ⇄ eth1); Router ISP" = (port di perangkat tujuan ⇄ port di perangkat ini), sama dengan urutan Port Uplink.
        $row['extra'] = [];
        if ($d['extra'] !== '' && $d['extra'] !== '-') {
            foreach (preg_split('/\s*;\s*|\n/', $d['extra'], -1, PREG_SPLIT_NO_EMPTY) as $item) {
                if (!preg_match('/^(.*?)\s*(?:\(([^)]*)\))?\s*$/u', trim($item), $mm) || trim($mm[1]) === '') continue;
                [$pb, $pa] = isset($mm[2]) ? netSplitPortText($mm[2]) : ['', ''];   // pb = port perangkat tujuan, pa = port perangkat ini
                $row['extra'][] = ['name' => trim($mm[1]), 'pa' => $pa, 'pb' => $pb, 'ref' => null];
            }
        }
        if ($d['date'] !== '' && $d['date'] !== '-') {
            $pd = tabletParseDate($ws->getCell(($hd['map']['date'] ?? 'A') . $r)->getValue());
            if ($pd === false || $pd === null) $row['errors'][] = nL('Tanggal Pembelian tidak dikenali (pakai format 2025-01-31)', 'Purchase date not recognised (use 2025-01-31)');
            else $row['d']['date'] = $pd;
        }
        if ($d['kind'] !== '') {
            $row['category'] = netImpResolveKind($d['kind'], $cats);
            if ($row['category'] === '') $row['errors'][] = nL('Jenis harus Switch / Hub / Router / Access Point (atau kategori jaringan lain)', 'Type must be Switch / Hub / Router / Access Point') . ": {$d['kind']}";
            elseif (!in_array($row['category'], $cats, true)) $row['warnings'][] = nL('Kategori "' . $row['category'] . '" belum ada, dibuat otomatis', 'Category "' . $row['category'] . '" will be created');
        }

        // Cocokkan dengan perangkat yang sudah ada.
        $match = null;
        if ($d['number'] !== '') {
            $numSt->execute([$d['number']]);
            $found = $numSt->fetch();
            if ($found && !isNetDeviceCategory((string)$found['category'])) $row['errors'][] = nL('Nomor Aset sudah dipakai aset ', 'Asset number already used by a ') . $found['category'];
            elseif ($found) $match = (int)$found['id'];
        } elseif ($row['main_ip'] !== '' && isset($byIp[$row['main_ip']])) {
            $match = $byIp[$row['main_ip']];
        } elseif (isset($byNameLoc[mb_strtolower($d['name'] . '|' . $d['location'])])) {
            $match = $byNameLoc[mb_strtolower($d['name'] . '|' . $d['location'])];
        }
        if ($match) {
            $row['action'] = 'update';
            $row['asset_id'] = $match;
            $row['asset_number'] = $all[$match]['number'] ?? $d['number'];
            if ($row['category'] === '') $row['category'] = $all[$match]['type'] ?? '';
        } else {
            $row['asset_number'] = $d['number'];
            if ($d['kind'] === '') $row['errors'][] = nL('Jenis wajib diisi (Switch / Hub / Router / Access Point)', 'Type is required');
            if ($d['name'] === '' || $d['name'] === '-') $row['errors'][] = nL('Nama Perangkat wajib diisi', 'Device name is required');
            if ($d['location'] === '' || $d['location'] === '-') $row['errors'][] = nL('Lokasi wajib diisi', 'Location is required');
        }
        $ipKey = $row['main_ip'];
        if ($ipKey !== '' && isset($seenIp[$ipKey])) $row['errors'][] = nL('IP dobel dengan baris ', 'Duplicate IP with row ') . $seenIp[$ipKey];
        if ($row['errors']) $row['action'] = 'error';
        if ($ipKey !== '') $seenIp[$ipKey] = $r;
        $rows[] = $row;
    }

    // "Terhubung ke": perangkat yang ada, atau baris lain di file ini (nama / nomor aset / IP).
    $fileKey = [];
    foreach ($rows as $i => $row) {
        if ($row['action'] === 'error') continue;
        foreach (array_merge([$row['d']['name'], $row['asset_number']], array_column($row['ips'], 'ip')) as $k) if ($k !== '' && $k !== '-') $fileKey[mb_strtolower($k)] = $i;
    }
    $errKey = [];
    foreach ($rows as $i => $row) if ($row['action'] === 'error' && $row['d']['name'] !== '') $errKey[mb_strtolower($row['d']['name'])] = $row['excel_row'];
    foreach ($rows as $i => &$row) {
        $p = $row['d']['parent'];
        if ($p === '' || $p === '-') continue;
        $k = mb_strtolower($p);
        // Terhubung ke dirinya sendiri -> dianggap perangkat paling atas (kolom diabaikan).
        if ($k === mb_strtolower($row['d']['name']) || ($row['asset_number'] !== '' && $k === mb_strtolower($row['asset_number']))) {
            $row['d']['parent'] = '';
            $row['warnings'][] = nL('"Terhubung ke" berisi perangkat ini sendiri, diabaikan (dianggap perangkat paling atas)', '"Connected to" is the device itself, ignored (top level)');
            continue;
        }
        if (isset($fileKey[$k]) && $fileKey[$k] !== $i) {
            $j = $fileKey[$k];
            $row['parent'] = $rows[$j]['asset_id'] ? ['id' => $rows[$j]['asset_id']] : ['row' => $j];
        } elseif (isset($keyToId[$k]) && $keyToId[$k] !== $row['asset_id']) {
            $row['parent'] = ['id' => $keyToId[$k]];
        } elseif (isset($errKey[$k])) {
            $row['errors'][] = nL('"Terhubung ke" menunjuk perangkat di baris ' . $errKey[$k] . ' yang masih error. Perbaiki baris itu dulu', '"Connected to" refers to row ' . $errKey[$k] . ' which has errors') . ": $p";
            $row['action'] = 'error';
        } else {
            $row['errors'][] = nL('"Terhubung ke" tidak ditemukan (isi nama / nomor aset / IP switch atau router)', '"Connected to" not found') . ": $p";
            $row['action'] = 'error';
        }
    }
    unset($row);
    // Koneksi tambahan: cari perangkat tujuan (baris lain di file / perangkat yang sudah ada).
    foreach ($rows as $i => &$row) {
        foreach ($row['extra'] as &$x) {
            $k = mb_strtolower($x['name']);
            if (isset($fileKey[$k]) && $fileKey[$k] !== $i) { $j = $fileKey[$k]; $x['ref'] = $rows[$j]['asset_id'] ? ['id' => $rows[$j]['asset_id']] : ['row' => $j]; }
            elseif (isset($keyToId[$k]) && $keyToId[$k] !== $row['asset_id']) $x['ref'] = ['id' => $keyToId[$k]];
            else { $row['errors'][] = nL('Koneksi tambahan tidak ditemukan', 'Extra link device not found') . ': ' . $x['name']; $row['action'] = 'error'; }
        }
        unset($x);
    }
    unset($row);
    return ['rows' => $rows, 'notes' => $notes];
}

/** Simpan hasil netImportPlan(). Baris error dilewati. */
function netImportApply(PDO $db, array $plan): array
{
    ensureNetTables($db);
    $hasDate = (bool)$db->query("SELECT COUNT(*) FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'assets' AND COLUMN_NAME = 'purchase_date'")->fetchColumn();
    $res = ['new' => 0, 'upd' => 0, 'skipped' => 0, 'link_fail' => 0, 'cats' => [], 'numbers' => []];
    $val = fn(string $new, $old) => $new === '' ? (string)$old : ($new === '-' ? '' : $new);
    $ids = [];

    $db->beginTransaction();
    try {
        foreach ($plan['rows'] as $i => $row) {
            if ($row['action'] === 'error') { $res['skipped']++; continue; }
            $d = $row['d'];
            $before = array_column(getAssetCategories($db), 'name');
            $cat = netImpEnsureCategory($db, $row['category']);
            if (!in_array($cat, $before, true)) $res['cats'][] = $cat;
            $old  = $row['asset_id'] ? cctvImpAssetRow($db, $row['asset_id']) : [];
            $info = $row['asset_id'] ? (cctvInfoMap($db, [$row['asset_id']])[$row['asset_id']] ?? []) : [];
            $brand = $val($d['brand'], $info['brand'] ?? '');
            $type  = $val($d['type'], $info['model'] ?? '');
            $fields = [
                'category'          => $cat,
                'device_name'       => $val($d['name'], $old['device_name'] ?? ''),
                'location'          => $val($d['location'], $old['location'] ?? ''),
                'ip_address'        => $d['ip'] === '' ? (string)($old['ip_address'] ?? '') : ($d['ip'] === '-' ? '' : $row['main_ip']),
                'serial_number'     => $val($d['serial'], $old['serial_number'] ?? ''),
                'motherboard_brand' => trim($brand . ' ' . $type),
                'status'            => $d['status'] !== '' ? cctvImpStatus($d['status']) : ($old['status'] ?? 'Digunakan'),
            ];
            if ($hasDate) $fields['purchase_date'] = $d['date'] === '-' ? null : ($d['date'] === '' ? ($old['purchase_date'] ?? null) : $d['date']);
            if (!$row['asset_id']) unset($fields['category']);   // aset baru: kategori diisi lewat parameter
            $assetId = cctvImpSaveAsset($db, (int)$row['asset_id'], $cat, $row['asset_number'], $fields, $res);
            saveCctvInfo($db, $assetId, $brand, $type);
            if ($d['ip'] !== '') netSaveDeviceIps($db, $assetId, $d['ip'] === '-' ? [] : $row['ips']);
            if ($d['sfp'] !== '') netSaveSfp($db, $assetId, $d['sfp'] === '-' ? null : (int)$d['sfp']);
            if ($d['ports'] !== '') {
                netSaveDeviceInfo($db, $assetId, $d['ports'] === '-' ? null : (int)$d['ports']);
            }
            $ids[$i] = $assetId;
            $res[$row['asset_id'] ? 'upd' : 'new']++;
        }
        // Sambungan dipasang setelah semua perangkat tersimpan (induk boleh ada di baris bawah).
        foreach ($plan['rows'] as $i => $row) {
            if (!isset($ids[$i])) continue;
            $p = $row['d']['parent'];
            $cur = netLinkOf($db, $ids[$i]);
            $port = $val($row['d']['uplink'], $cur['port']);
            if ($p === '-') $parent = null;
            elseif ($row['parent']) $parent = isset($row['parent']['id']) ? (int)$row['parent']['id'] : ($ids[$row['parent']['row']] ?? null);
            else $parent = $cur['parent'];
            if (!($p === '' && $row['d']['uplink'] === '' && $row['d']['own'] === '')) {
                if (netSetLink($db, $ids[$i], $parent, $port)) {
                    $curOwn = netAssets($db)[$ids[$i]]['own_port'] ?? '';
                    netSaveOwnPort($db, $ids[$i], $parent ? $val($row['d']['own'], $curOwn) : '');
                } else $res['link_fail']++;
            }
            // Koneksi tambahan: "-" = hapus semua milik perangkat ini; isi = ganti / tambah per pasangan perangkat.
            if ($row['d']['extra'] === '-') netClearExtraLinks($db, $ids[$i]);
            // Pasangan perangkat yang disebut di sel ini diganti seluruhnya (boleh lebih dari 1 kabel ke perangkat yang sama).
            $cleared = [];
            foreach ($row['extra'] as $x) {
                $other = isset($x['ref']['id']) ? (int)$x['ref']['id'] : ($ids[$x['ref']['row']] ?? 0);
                if (!$other) continue;
                if (!isset($cleared[$other])) {
                    $db->prepare("DELETE FROM net_links_extra WHERE (asset_id = ? AND other_id = ?) OR (asset_id = ? AND other_id = ?)")->execute([$ids[$i], $other, $other, $ids[$i]]);
                    $cleared[$other] = true;
                }
                if (netAddExtraLink($db, $ids[$i], $other, $x['pa'], $x['pb']) !== '') $res['link_fail']++;
            }
        }
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        throw $e;
    }
    return $res;
}

/** Template Excel. $withData = isi dengan perangkat jaringan yang sudah ada (edit massal lalu import lagi). */
function writeNetImportTemplate(PDO $db, Spreadsheet $ss, bool $withData = false, ?array $onlyIds = null): void
{
    ensureNetTables($db);
    $en = function_exists('currentLang') && currentLang() === 'en';
    $cats = netImpCategories($db);
    $kinds = array_values(array_unique(array_merge($cats, netImpMissingStdKinds($db))));
    $all = netAssets($db);
    $netDev = array_filter($all, fn($a) => $a['is_net']);
    $listDev = $netDev;   // pilihan "Terhubung ke" tetap semua perangkat jaringan
    // Export Excel (menu Asset): hanya aset terpilih, format sama dengan template import.
    if ($onlyIds !== null) { $keep = array_flip(array_map('intval', $onlyIds)); $netDev = array_filter($netDev, fn($a) => isset($keep[$a['id']])); }

    $rows = [];
    if ($withData) {
        $ids = array_keys($netDev);
        $info = cctvInfoMap($db, $ids);
        $ports = netDeviceInfoMap($db, $ids);
        $ipsMap = netDeviceIpsMap($db, $ids);
        $extrasAll = netExtraLinks($db);
        $extra = [];
        if ($ids) {
            $st = $db->prepare("SELECT id, ip_address, serial_number, purchase_date, status FROM assets WHERE id IN (" . implode(',', array_fill(0, count($ids), '?')) . ")");
            $st->execute($ids);
            foreach ($st->fetchAll() as $r) $extra[(int)$r['id']] = $r;
        }
        uasort($netDev, fn($x, $y) => strcmp($x['number'], $y['number']));
        foreach ($netDev as $a) {
            $e = $extra[$a['id']] ?? [];
            $ex = [];
            foreach ($extrasAll as $l) if ($l['a'] === $a['id'] && isset($all[$l['b']])) $ex[] = $all[$l['b']]['name'] . (($l['port_a'] !== '' || $l['port_b'] !== '') ? ' (' . $l['port_b'] . ' ⇄ ' . $l['port_a'] . ')' : '');
            $rows[] = [$a['number'], $a['type'], $a['name'], $a['loc'], isset($ipsMap[$a['id']]) ? netIpListText($ipsMap[$a['id']]) : (string)($e['ip_address'] ?? $a['ip']),
                $info[$a['id']]['brand'] ?? '', $info[$a['id']]['model'] ?? '', $ports[$a['id']] ?? '', $a['sfp'] ?: '',
                $a['parent'] ? ($all[$a['parent']]['name'] ?? '') : '', $a['port'], $a['own_port'], implode('; ', $ex),
                (string)($e['serial_number'] ?? ''), (string)($e['purchase_date'] ?? ''), (string)($e['status'] ?? $a['asset_status'])];
        }
    }

    $ws = $ss->getActiveSheet();
    $ws->setTitle($en ? 'Network' : 'Jaringan');
    $sheetRef = "'" . $ws->getTitle() . "'";
    $cols = netImpColumns();
    $c = 1;
    foreach ($cols as [$id, $e, $w]) {
        $L = Coordinate::stringFromColumnIndex($c++);
        $ws->setCellValue($L . '1', $en ? $e : $id);
        $ws->getColumnDimension($L)->setWidth($w);
    }
    $lastCol = Coordinate::stringFromColumnIndex(count($cols));
    foreach ($rows as $i => $vals) {
        foreach (array_values($vals) as $j => $v) $ws->setCellValueExplicit(Coordinate::stringFromColumnIndex($j + 1) . ($i + 2), (string)$v, DataType::TYPE_STRING);
    }
    $ws->getStyle("A1:{$lastCol}1")->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
    $ws->getStyle("A1:{$lastCol}1")->getFill()->setFillType('solid')->getStartColor()->setRGB('4338CA');
    $ws->freezePane('A2');
    xlsAddTitleBlock($ws, 1, ($onlyIds !== null ? ($en ? 'Network Device Data ' : 'Data Perangkat Jaringan ') : ($en ? 'Network Device Import ' : 'Import Perangkat Jaringan ')) . xlsCompanyName(), xlsTemplateLines());
    $ws->getStyle("A9:{$lastCol}1000")->getNumberFormat()->setFormatCode('@');
    $ws->getStyle("A8:{$lastCol}" . max(8, 8 + count($rows)))->getBorders()->getAllBorders()->setBorderStyle('thin')->getColor()->setRGB('CBD5E1');

    // Daftar pilihan (sheet tersembunyi): Jenis, Status, Terhubung ke (perangkat yang ada + nama di sheet ini).
    $ls = $ss->createSheet();
    $ls->setTitle('Daftar');
    foreach ($kinds as $i => $k) $ls->setCellValueExplicit('A' . ($i + 1), $k, DataType::TYPE_STRING);
    foreach (CCTV_IMP_STATUSES as $i => $s) $ls->setCellValue('B' . ($i + 1), $s);
    $names = array_values(array_unique(array_map(fn($a) => $a['name'], $listDev)));
    foreach ($names as $i => $n) $ls->setCellValueExplicit('C' . ($i + 1), $n, DataType::TYPE_STRING);
    $start = count($names) + 1;
    $prev = count($names) ? '$C$1:$C$' . count($names) : null;
    for ($i = 0; $i < 300; $i++) {
        $src = "{$sheetRef}!C" . (9 + $i);
        $dupe = $prev ? "COUNTIF({$prev},{$src})>0" : 'FALSE';
        $ls->setCellValue('C' . ($start + $i), "=IF(OR({$src}=\"\",{$dupe}),\"\",{$src})");
    }
    $ls->setSheetState(Worksheet::SHEETSTATE_HIDDEN);
    $dv = function (string $range, string $formula, bool $strict, string $msg) use ($ws) {
        $v = new DataValidation();
        $v->setType(DataValidation::TYPE_LIST)->setFormula1($formula)->setShowDropDown(true)->setAllowBlank(true)
          ->setShowErrorMessage($strict)->setErrorStyle($strict ? DataValidation::STYLE_STOP : DataValidation::STYLE_INFORMATION)
          ->setErrorTitle('Pilihan')->setError($msg);
        $ws->setDataValidation($range, $v);
    };
    $colOf = function (string $key) { $i = array_search($key, array_keys(netImpColumns()), true); return Coordinate::stringFromColumnIndex($i + 1); };
    $dv($colOf('kind') . '9:' . $colOf('kind') . '1000', 'Daftar!$A$1:$A$' . max(1, count($kinds)), false, implode(' / ', $kinds));
    $dv($colOf('parent') . '9:' . $colOf('parent') . '1000', 'Daftar!$C$1:$C$' . ($start + 299), false, '');
    $dv($colOf('status') . '9:' . $colOf('status') . '1000', 'Daftar!$B$1:$B$3', true, 'Digunakan / Stok / Tidak Digunakan');

    $help = $ss->createSheet();
    $help->setTitle($en ? 'Guide' : 'Petunjuk');
    $lines = $en ? [
        'Network device import guide (switch, hub, router, access point)', '',
        '1. One row = one device. For new devices, Type, Device Name and Location are required.',
        '2. Type: Switch / Hub / Router / Access Point (dropdown). A type missing from Asset Categories is created automatically.',
        '3. IP Address: fill for managed switches, routers and APs. Leave EMPTY for unmanaged switches/hubs. Routers with several segments may list several IPs separated by commas, /24 allowed. The IP in the server segment becomes the main IP for ping.',
        '4. Connected to: the upstream device (switch/router) this device is plugged into — its name, asset number or IP. It may refer to another row in this file.',
        '5. Uplink Port = port on the upstream device (e.g. eth8). Port on This Device = port of this device used for that cable (e.g. eth16 / sfp1).',
        '5b. Extra Links (optional): other devices this one is also cabled to, separated by ";", ports in brackets as (port on the other device ⇄ port on this device), same order as Uplink Port. Example: Firewall (eth1 ⇄ eth1); Router ISP (eth16 ⇄ eth2). Type "-" to remove all.',
        '6. Asset Number empty = new asset, numbered automatically. If the IP or name + location already exists, that device is updated instead.',
        '7. When updating: an empty cell keeps the old value; type "-" to clear it.',
        '8. After uploading, a preview shows new / updated / error rows. Nothing is saved until you click Save.',
    ] : [
        'Petunjuk import Perangkat Jaringan (switch, hub, router, access point)', '',
        '1. 1 baris = 1 perangkat. Untuk perangkat baru, Jenis, Nama Perangkat dan Lokasi wajib diisi.',
        '2. Jenis: Switch / Hub / Router / Access Point (pilih dari daftar). Jenis yang belum ada di Kategori Aset dibuat otomatis.',
        '3. IP Address: isi untuk switch managed, router dan access point. KOSONGKAN untuk switch/hub biasa (unmanaged). Router dengan banyak segmen boleh diisi beberapa IP dipisah koma, boleh dengan /24 (mis. 192.168.1.1/24, 192.168.2.1/24). IP di segmen server otomatis jadi IP utama untuk cek ping.',
        '4. Terhubung ke: perangkat di atasnya (switch/router) tempat kabel perangkat ini dicolok — isi nama, nomor aset, atau IP-nya. Boleh menyebut baris lain di file ini.',
        '5. Port Uplink = port di perangkat atasnya (mis. eth8). Port di Perangkat Ini = port perangkat ini yang dipakai kabel itu (mis. eth16 / sfp1). Jumlah Port & Port SFP dipakai untuk daftar pilihan port di menu Jaringan.',
        '5b. Koneksi Tambahan (opsional): perangkat lain yang juga dikabel ke perangkat ini, pisahkan dengan ";", port dalam kurung (port di perangkat tujuan ⇄ port di perangkat ini), urutannya sama dengan Port Uplink ⇄ Port di Perangkat Ini. Contoh: Firewall (eth1 ⇄ eth1); Router ISP (eth16 ⇄ eth2). Ketik "-" untuk menghapus semua.',
        '6. Nomor Aset kosong = aset baru, nomor dibuat otomatis. Jika IP atau nama + lokasi sudah ada, perangkat itu yang diperbarui.',
        '7. Saat memperbarui: sel kosong = data lama tetap; ketik "-" untuk mengosongkan.',
        '8. Setelah upload muncul preview baris baru / diperbarui / error. Data baru tersimpan setelah klik Simpan.',
    ];
    $lines[] = '';
    $lines[] = $en ? 'Example rows:' : 'Contoh baris:';
    $lines[] = '(kosong) | Router | Router Utama | Ruang Server | 192.168.1.1/24, 192.168.2.1/24 | MikroTik | RB5009UG | 8 | 1 | (kosong) | | | | | | Digunakan';
    $lines[] = '(kosong) | Router | Firewall | Ruang Server | 192.168.1.254 | Fortinet | FortiGate 100E | 18 | | Router Utama | eth1 | eth1 | | | | Digunakan';
    $lines[] = '(kosong) | Switch | Switch Core | Ruang Server | 192.168.1.2 | TP-Link | TL-SG3428 | 24 | 4 | Router Utama | eth2 | sfp1 | Firewall (eth5 ⇄ eth2) | | | Digunakan';
    $lines[] = '(kosong) | Switch | Switch Gudang | Gudang | (kosong) | TP-Link | TL-SF1008D | 8 | | Switch Core | eth5 | eth1 | | | | Digunakan';
    foreach ($lines as $i => $l) $help->setCellValue('A' . ($i + 1), $l);
    $help->getStyle('A1')->getFont()->setBold(true)->setSize(13);
    $help->getColumnDimension('A')->setWidth(140);
    $ss->setActiveSheetIndex(0);
}
