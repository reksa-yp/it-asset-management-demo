<?php
/**
 * Nametag meja (tent card) 29,1 x 13,5 cm, dicetak di kertas F4 (33 x 21,5 cm) landscape.
 * Data per user disimpan di tabel BARU nametags (CREATE TABLE IF NOT EXISTS; tabel lama tidak diubah).
 * Foto: assets/uploads/nametag/. Gambar cetak dibuat dengan GD + font Montserrat (assets/fonts, lisensi OFL).
 *
 * Koordinat desain memakai satuan "px 150 dpi": seluruh nametag 1719 x 797 (= 291 x 135 mm),
 * satu sisi 1719 x 399. Sisi atas = sisi bawah diputar 180 derajat (supaya terbaca setelah dilipat).
 */

const NT_W = 1719;
const NT_H = 797;
const NT_HALF = 399;
const NT_CX = 826;      // tengah area teks (antara foto & motif)
const NT_SHIFT = 54;    // motif kanan digeser dari desain awal 30 cm
const NT_PHOTO_DIR = __DIR__ . '/../assets/uploads/nametag';
const NT_PHOTO_URL = 'assets/uploads/nametag';

function ntL(string $id, string $en): string
{
    return function_exists('currentLang') && currentLang() === 'en' ? $en : $id;
}

function ntEnsure(PDO $db): void
{
    static $done = false;
    if ($done) return;
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS nametags (
            user_id INT UNSIGNED NOT NULL PRIMARY KEY,
            full_name VARCHAR(150) NOT NULL,
            nick VARCHAR(60) NULL,
            department VARCHAR(120) NULL,
            position VARCHAR(150) NULL,
            photo VARCHAR(255) NULL,
            zoom SMALLINT NOT NULL DEFAULT 100,
            pos_x SMALLINT NOT NULL DEFAULT 0,
            pos_y SMALLINT NOT NULL DEFAULT 0,
            updated_by INT UNSIGNED NULL,
            updated_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) { /* sudah ada */ }
    $done = true;
}

/** Motif garis (sisi bawah, koordinat seluruh nametag). [x1, x2, y, jenis m=biru l=muda o=garis tepi] */
function ntPattern(): array
{
    $rows = [[430, [[1548, 1632, 'm'], [1652, 1736, 'l']]], [462, [[1530, 1614, 'm'], [1636, 1718, 'l'], [1740, 1754, 'm']]],
        [492, [[1511, 1596, 'o'], [1618, 1700, 'l'], [1722, 1754, 'm']]], [523, [[1495, 1579, 'm'], [1600, 1683, 'l'], [1704, 1754, 'm']]],
        [554, [[1478, 1561, 'm'], [1583, 1666, 'l'], [1687, 1754, 'm']]], [586, [[1670, 1754, 'm']]], [617, [[1652, 1736, 'm']]],
        [648, [[1634, 1718, 'm'], [1740, 1754, 'l']]], [679, [[1617, 1700, 'm'], [1724, 1754, 'l']]], [711, [[1600, 1683, 'o'], [1708, 1754, 'l']]],
        [742, [[1583, 1666, 'm'], [1690, 1754, 'l']]], [773, [[1565, 1649, 'm'], [1673, 1754, 'l']]]];
    $out = [];
    foreach ($rows as [$y, $segs]) foreach ($segs as [$a, $b, $t]) $out[] = [$a - NT_SHIFT, $b - NT_SHIFT, $y, $t];
    return $out;
}

/** Data bawaan dari akun user (nama, departemen, jabatan). */
function ntDefaults(PDO $db, int $uid): array
{
    $st = $db->prepare("SELECT id, full_name, department FROM users WHERE id = ?");
    $st->execute([$uid]);
    $u = $st->fetch();
    if (!$u) return [];
    $pos = '';
    try { require_once __DIR__ . '/user_position.php'; $pos = getUserPosition($db, $uid); } catch (Throwable $e) {}
    $full = trim((string)$u['full_name']);
    return ['user_id' => $uid, 'full_name' => $full, 'nick' => preg_split('/\s+/', $full)[0] ?? '', 'department' => (string)($u['department'] ?? ''),
            'position' => $pos, 'photo' => '', 'zoom' => 100, 'pos_x' => 0, 'pos_y' => 0, 'saved' => false];
}

/** Data nametag user: yang tersimpan, atau bawaan dari akun. */
function ntGet(PDO $db, int $uid): array
{
    ntEnsure($db);
    $d = ntDefaults($db, $uid);
    if (!$d) return [];
    try {
        $st = $db->prepare("SELECT * FROM nametags WHERE user_id = ?");
        $st->execute([$uid]);
        if ($r = $st->fetch()) {
            foreach (['full_name', 'nick', 'department', 'position', 'photo'] as $k) $d[$k] = (string)($r[$k] ?? '');
            foreach (['zoom', 'pos_x', 'pos_y'] as $k) $d[$k] = (int)$r[$k];
            $d['saved'] = true;
            $d['updated_at'] = $r['updated_at'];
        }
    } catch (Throwable $e) {}
    if ($d['photo'] !== '' && !is_file(NT_PHOTO_DIR . '/' . basename($d['photo']))) $d['photo'] = '';
    return $d;
}

/** Simpan foto unggahan (JPG/PNG/WEBP), diperkecil maks. 900 px tinggi. Return nama file atau '' bila gagal. */
function ntStorePhoto(int $uid, array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) return '';
    if ($file['size'] > 15 * 1024 * 1024) return '';
    $info = @getimagesize($file['tmp_name']);
    $mime = $info['mime'] ?? '';
    $src = $mime === 'image/jpeg' ? @imagecreatefromjpeg($file['tmp_name'])
         : ($mime === 'image/png' ? @imagecreatefrompng($file['tmp_name'])
         : ($mime === 'image/webp' && function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($file['tmp_name']) : false));
    if (!$src) return '';
    // Putar sesuai EXIF (foto HP sering tersimpan miring).
    if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
        $o = (int)(@exif_read_data($file['tmp_name'])['Orientation'] ?? 1);
        if ($o === 3) $src = imagerotate($src, 180, 0); elseif ($o === 6) $src = imagerotate($src, -90, 0); elseif ($o === 8) $src = imagerotate($src, 90, 0);
    }
    $w = imagesx($src); $h = imagesy($src);
    $scale = min(1, 900 / max(1, $h), 1200 / max(1, $w));
    $nw = max(1, (int)round($w * $scale)); $nh = max(1, (int)round($h * $scale));
    $dst = imagecreatetruecolor($nw, $nh);
    imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
    if (!is_dir(NT_PHOTO_DIR)) @mkdir(NT_PHOTO_DIR, 0775, true);
    $name = 'u' . $uid . '_' . bin2hex(random_bytes(6)) . '.jpg';
    $ok = imagejpeg($dst, NT_PHOTO_DIR . '/' . $name, 88);
    imagedestroy($src); imagedestroy($dst);
    return $ok ? $name : '';
}

function ntSave(PDO $db, int $uid, array $in, ?array $file, int $by): array
{
    ntEnsure($db);
    $cur = ntGet($db, $uid);
    if (!$cur) return ['ok' => false, 'msg' => ntL('User tidak ditemukan.', 'User not found.')];
    $full = mb_substr(trim((string)($in['full_name'] ?? '')), 0, 150);
    if ($full === '') return ['ok' => false, 'msg' => ntL('Nama lengkap wajib diisi.', 'Full name is required.')];
    $photo = $cur['photo'];
    if ($file && ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
        $new = ntStorePhoto($uid, $file);
        if ($new === '') return ['ok' => false, 'msg' => ntL('Foto gagal diunggah. Gunakan file JPG atau PNG (maks. 15 MB).', 'Photo upload failed. Use a JPG or PNG file (max 15 MB).')];
        if ($photo !== '') @unlink(NT_PHOTO_DIR . '/' . basename($photo));
        $photo = $new;
    }
    if (!empty($in['remove_photo']) && $photo !== '') { @unlink(NT_PHOTO_DIR . '/' . basename($photo)); $photo = ''; }
    $clamp = fn($v, $a, $b) => max($a, min($b, (int)$v));
    $row = [$uid, $full, mb_substr(trim((string)($in['nick'] ?? '')), 0, 60), mb_substr(trim((string)($in['department'] ?? '')), 0, 120),
            mb_substr(trim((string)($in['position'] ?? '')), 0, 150), $photo ?: null,
            $clamp($in['zoom'] ?? 100, 100, 250), $clamp($in['pos_x'] ?? 0, -50, 50), $clamp($in['pos_y'] ?? 0, -50, 50), $by, date('Y-m-d H:i:s')];
    $db->prepare("DELETE FROM nametags WHERE user_id = ?")->execute([$uid]);
    $db->prepare("INSERT INTO nametags (user_id, full_name, nick, department, position, photo, zoom, pos_x, pos_y, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
       ->execute($row);
    return ['ok' => true, 'msg' => ntL('Data nametag disimpan.', 'Name tag saved.')];
}

function ntLineName(array $d): string
{
    $f = mb_strtoupper(trim($d['full_name'])); $n = mb_strtoupper(trim((string)$d['nick']));
    return $n !== '' ? $f . ' / ' . $n : $f;
}

function ntLineDept(array $d): string
{
    $a = mb_strtoupper(trim((string)$d['department'])); $b = mb_strtoupper(trim((string)$d['position']));
    return $a !== '' && $b !== '' ? $a . ' / ' . $b : ($a . $b);
}

/** Gambar nametag (PNG) dengan GD. $dpi 300 untuk cetak. */
function ntRenderPng(array $d, int $dpi = 300): string
{
    $s = $dpi / 150;
    $W = (int)round(NT_W * $s); $H = (int)round(NT_H * $s); $HH = (int)round(NT_HALF * $s);
    $fontB = realpath(__DIR__ . '/../assets/fonts/Montserrat-Bold.ttf');
    $fontR = realpath(__DIR__ . '/../assets/fonts/Montserrat-Regular.ttf');

    $half = imagecreatetruecolor($W, $HH);
    imagealphablending($half, true);
    $bg = imagecolorallocate($half, 0x22, 0x2e, 0x47);
    $mid = imagecolorallocate($half, 0x6e, 0xaf, 0xde);
    $light = imagecolorallocate($half, 0xba, 0xd9, 0xf0);
    $white = imagecolorallocate($half, 255, 255, 255);
    $ph = imagecolorallocate($half, 0x2c, 0x3a, 0x5c);
    $ph2 = imagecolorallocate($half, 0x3f, 0x51, 0x79);
    imagefilledrectangle($half, 0, 0, $W, $HH, $bg);
    $R = fn($v) => (int)round($v * $s);

    // Foto (cover + perbesar/geser, sama dengan pratinjau di halaman)
    $bx = 38; $by = 123; $bw = 190; $bh = 249;
    $photo = $d['photo'] !== '' ? NT_PHOTO_DIR . '/' . basename($d['photo']) : '';
    $img = $photo !== '' && is_file($photo) ? @imagecreatefromjpeg($photo) : false;
    if ($img) {
        $sw = imagesx($img); $sh = imagesy($img);
        $ar = $bw / $bh;
        if ($sw / $sh > $ar) { $cw = $sh * $ar; $ch = $sh; $cx = ($sw - $cw) / 2; $cy = 0; }
        else { $cw = $sw; $ch = $sw / $ar; $cx = 0; $cy = ($sh - $ch) / 2; }
        $z = max(1, $d['zoom'] / 100);
        $vx = $cx + $cw * (1 - 1 / $z) * (0.5 + $d['pos_x'] / 100);
        $vy = $cy + $ch * (1 - 1 / $z) * (0.5 + $d['pos_y'] / 100);
        imagecopyresampled($half, $img, $R($bx), $R($by), (int)$vx, (int)$vy, $R($bw), $R($bh), (int)($cw / $z), (int)($ch / $z));
        imagedestroy($img);
    } else {
        imagefilledrectangle($half, $R($bx), $R($by), $R($bx + $bw), $R($by + $bh), $ph);
        imagefilledellipse($half, $R(133), $R(212), $R(76), $R(76), $ph2);
        imagefilledellipse($half, $R(133), $R(372), $R(130), $R(160), $ph2);
        imagefilledrectangle($half, $R($bx), $R($by + $bh) + 1, $R($bx + $bw), $HH, $bg);
    }
    imagesetthickness($half, max(1, $R(3)));
    imagerectangle($half, $R($bx), $R($by), $R($bx + $bw), $R($by + $bh), $mid);

    // Logo
    $logo = @imagecreatefrompng(__DIR__ . '/../assets/img/nametag_logo.png');
    if ($logo) {
        imagecopyresampled($half, $logo, $R(35), $R(22), 0, 0, $R(195), $R(80), imagesx($logo), imagesy($logo));
        imagedestroy($logo);
    }

    // Motif garis
    foreach (ntPattern() as [$a, $b, $y, $t]) {
        $y -= 402;
        if ($t === 'o') { imagesetthickness($half, max(1, $R(2.5))); imagerectangle($half, $R($a), $R($y - 5), $R($b), $R($y + 5), $light); }
        else imagefilledrectangle($half, $R($a), $R($y - 5), $R($b), $R($y + 5), $t === 'm' ? $mid : $light);
    }

    // Teks: diperkecil otomatis bila terlalu panjang, rata tengah di x = NT_CX
    $text = function (string $str, string $font, float $sizePx, float $baseline, float $maxW) use ($half, $white, $R) {
        if ($str === '' || !$font) return;
        $pt = $R($sizePx) * 0.75;                     // GD: ukuran dalam poin (96 dpi)
        for ($i = 0; $i < 60; $i++) {
            $bb = imagettfbbox($pt, 0, $font, $str);
            $w = $bb[2] - $bb[0];
            if ($w <= $R($maxW)) break;
            $pt *= 0.97;
        }
        $bb = imagettfbbox($pt, 0, $font, $str);
        imagettftext($half, $pt, 0, (int)($R(NT_CX) - ($bb[2] - $bb[0]) / 2 - $bb[0]), $R($baseline), $white, $font, $str);
    };
    $text(ntLineName($d), $fontB, 84, 188, 1136);
    $text(ntLineDept($d), $fontR, 50, 310, 1166);

    // Gabungkan: sisi bawah + sisi atas (diputar 180)
    $out = imagecreatetruecolor($W, $H);
    imagecopy($out, $half, 0, $H - $HH, 0, 0, $W, $HH);
    $top = imagerotate($half, 180, 0);
    imagecopy($out, $top, 0, 0, 0, 0, $W, $HH);
    imagedestroy($top); imagedestroy($half);
    $fold = imagecolorallocate($out, 0x3a, 0x4a, 0x6e);
    imagesetthickness($out, max(1, $R(2)));
    imageline($out, 0, (int)($H / 2), $W, (int)($H / 2), $fold);
    $mid2 = imagecolorallocate($out, 0x6e, 0xaf, 0xde);
    imagesetthickness($out, max(1, $R(3)));
    imagerectangle($out, 1, 1, $W - 2, $H - 2, $mid2);
    ob_start();
    imagepng($out, null, 6);
    imagedestroy($out);
    return (string)ob_get_clean();
}

/** Halaman cetak F4 landscape (HTML untuk browser & Dompdf). $img = src gambar nametag. */
function ntSheetHtml(string $img, bool $forPdf): string
{
    // F4 330 x 215 mm; nametag 291 x 135 mm di tengah (kiri 19,5 mm, atas 40 mm). Tanda potong di sudut, tanda lipat di tengah.
    $marks = '';
    $L = 19.5; $T = 40; $Wd = 291; $Ht = 135;
    foreach ([[$L, $T], [$L + $Wd, $T], [$L, $T + $Ht], [$L + $Wd, $T + $Ht]] as [$x, $y]) {
        $hx = $x < 100 ? $x - 9 : $x + 2; $vy = $y < 100 ? $y - 9 : $y + 2;
        $marks .= '<div style="position:absolute;left:' . $hx . 'mm;top:' . ($y - 0.15) . 'mm;width:7mm;height:0;border-top:0.3mm solid #000"></div>';
        $marks .= '<div style="position:absolute;left:' . ($x - 0.15) . 'mm;top:' . $vy . 'mm;width:0;height:7mm;border-left:0.3mm solid #000"></div>';
    }
    $fy = $T + $Ht / 2;
    $marks .= '<div style="position:absolute;left:' . ($L - 9) . 'mm;top:' . ($fy - 0.1) . 'mm;width:7mm;border-top:0.3mm dashed #000"></div>';
    $marks .= '<div style="position:absolute;left:' . ($L + $Wd + 2) . 'mm;top:' . ($fy - 0.1) . 'mm;width:7mm;border-top:0.3mm dashed #000"></div>';
    $marks .= '<div style="position:absolute;left:' . $L . 'mm;top:' . ($T + $Ht + 8) . 'mm;font:7pt Arial,sans-serif;color:#555">'
            . 'Potong di tanda sudut (29,1 x 13,5 cm), lipat di garis putus-putus tengah. Kertas F4 (21,5 x 33 cm), skala 100%.</div>';
    return '<div class="sheet" style="position:relative;width:330mm;height:215mm;overflow:hidden">'
         . '<img src="' . $img . '" style="position:absolute;left:' . $L . 'mm;top:' . $T . 'mm;width:' . $Wd . 'mm;height:' . $Ht . 'mm">' . $marks . '</div>';
}
