<?php
/**
 * Isian khusus kategori TABLET.
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA:
 * - 8 isian tablet memakai kolom aset yang sudah ada:
 *     User            -> asset_owners (sama seperti aset lain)
 *     Departement     -> assets.department
 *     Location        -> assets.location  (nama line, mis. "Line 1")
 *     Assets No       -> assets.asset_number
 *     Serial Number   -> assets.serial_number
 *     IP              -> assets.ip_address
 *     Received Date   -> assets.purchase_date
 *     Brand Type      -> assets.motherboard_brand
 * - Hanya ID Tablet & Status Condition (Bagus/Rusak) yang disimpan di tabel BARU
 *   asset_tablet_details. Tabel lama TIDAK di-ALTER. Tanpa foreign key ke tabel lama.
 * - Tabel baru dibuat otomatis (CREATE TABLE IF NOT EXISTS) saat halaman aset dibuka,
 *   atau manual lewat sql/tablet_tables.sql.
 */

require_once __DIR__ . '/asset_number.php';

const TABLET_CONDITIONS = ['Bagus', 'Rusak'];

/** Kategori dianggap Tablet jika namanya mengandung kata "tablet" (mis. "Tablet", "Tablet Android"). */
function isTabletCategory(?string $category): bool
{
    return $category !== null && stripos($category, 'tablet') !== false;
}

function tabletTableExists(PDO $db): bool
{
    static $exists = null;
    if ($exists === null) {
        $stmt = $db->query("SELECT COUNT(*) FROM information_schema.TABLES
                            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_tablet_details'");
        $exists = (bool)$stmt->fetchColumn();
    }
    return $exists;
}

/** Buat tabel asset_tablet_details jika belum ada. Tidak menyentuh tabel lain. */
function ensureTabletTable(PDO $db): void
{
    if (tabletTableExists($db)) return;
    $db->exec("
        CREATE TABLE IF NOT EXISTS asset_tablet_details (
            asset_id          INT UNSIGNED NOT NULL PRIMARY KEY,
            tablet_id         VARCHAR(50)  DEFAULT NULL,
            tablet_condition  ENUM('Bagus','Rusak') NOT NULL DEFAULT 'Bagus',
            updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_tablet_id (tablet_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
}

/** Detail tablet untuk banyak aset sekaligus: [asset_id => ['tablet_id'=>..., 'tablet_condition'=>...]] */
function getTabletDetailsMap(PDO $db, array $assetIds): array
{
    $assetIds = array_values(array_filter(array_map('intval', $assetIds)));
    if (!$assetIds || !tabletTableExists($db)) return [];
    $ph = implode(',', array_fill(0, count($assetIds), '?'));
    $stmt = $db->prepare("SELECT asset_id, tablet_id, tablet_condition FROM asset_tablet_details WHERE asset_id IN ($ph)");
    $stmt->execute($assetIds);
    $map = [];
    foreach ($stmt->fetchAll() as $r) { $map[(int)$r['asset_id']] = $r; }
    return $map;
}

/** Simpan / perbarui detail tablet untuk 1 aset. */
function saveTabletDetails(PDO $db, int $assetId, string $tabletId, string $condition): void
{
    ensureTabletTable($db);
    $condition = in_array($condition, TABLET_CONDITIONS, true) ? $condition : 'Bagus';
    $tabletId  = mb_substr(trim($tabletId), 0, 50);
    $db->prepare("
        INSERT INTO asset_tablet_details (asset_id, tablet_id, tablet_condition) VALUES (?,?,?)
        ON DUPLICATE KEY UPDATE tablet_id = VALUES(tablet_id), tablet_condition = VALUES(tablet_condition)
    ")->execute([$assetId, $tabletId !== '' ? $tabletId : null, $condition]);
}

/** Hapus detail tablet milik aset yang dihapus (dipanggil dari hapus aset). */
function deleteTabletDetails(PDO $db, array $assetIds): void
{
    $assetIds = array_values(array_filter(array_map('intval', $assetIds)));
    if (!$assetIds || !tabletTableExists($db)) return;
    $ph = implode(',', array_fill(0, count($assetIds), '?'));
    $db->prepare("DELETE FROM asset_tablet_details WHERE asset_id IN ($ph)")->execute($assetIds);
}

/** Apakah ID Tablet sudah dipakai tablet lain (yang asetnya masih ada)? */
function tabletIdTaken(PDO $db, string $tabletId, int $excludeAssetId = 0): bool
{
    $tabletId = trim($tabletId);
    if ($tabletId === '' || !tabletTableExists($db)) return false;
    $stmt = $db->prepare("SELECT COUNT(*) FROM asset_tablet_details d JOIN assets a ON a.id = d.asset_id
                          WHERE d.tablet_id = ? AND d.asset_id <> ?");
    $stmt->execute([$tabletId, $excludeAssetId]);
    return (int)$stmt->fetchColumn() > 0;
}

/** Panjang maksimal Nomor Aset (kolom assets.asset_number = VARCHAR(30)). */
const ASSET_NUMBER_MAX_LEN = 30;

/**
 * Kode line dari isian Location: "Line 1" -> "LINE1". Kosong jika Location kosong.
 * Kalau $maxLen diisi dan kodenya terlalu panjang, Location disingkat: huruf awal tiap kata +
 * angka utuh, mis. "Needle Detector Columbia 1" -> "NDC1", "Needle Detector GAP/ON 3" -> "NDGO3".
 */
function tabletLineCode(string $location, int $maxLen = 0): string
{
    $code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $location));
    if ($maxLen > 0 && strlen($code) > $maxLen) {
        $abbr = '';
        foreach (preg_split('/[^A-Za-z0-9]+/', $location, -1, PREG_SPLIT_NO_EMPTY) as $w) {
            if (ctype_digit($w)) { $abbr .= $w; }
            elseif (preg_match('/^([A-Za-z])[A-Za-z]*(\d+)$/', $w, $m)) { $abbr .= $m[1] . $m[2]; } // "Columbia1" -> "C1"
            else { $abbr .= $w[0]; }
        }
        $code = substr(strtoupper($abbr !== '' ? $abbr : $code), 0, $maxLen);
    }
    return $code;
}

/**
 * Nomor Aset otomatis khusus tablet: <Awalan>/<Singkatan Departement>/<Line>/<Urutan 3 digit>.
 * Nomor urut dihitung per kombinasi Departement + Line. Mengembalikan null jika Location kosong.
 * (generateDeptAbbr ada di includes/asset_number.php — aturan singkatan sama dengan aset lain.)
 */
function nextTabletAssetNumber(PDO $db, string $department, string $location, ?int $excludeId = null): ?string
{
    // Nomor Aset maks 30 karakter: sisakan tempat untuk "<Awalan>/<Dept>/" dan "/001".
    $deptPart = assetPrefix() . '/' . generateDeptAbbr($department) . '/';
    $line = tabletLineCode($location, max(1, ASSET_NUMBER_MAX_LEN - strlen($deptPart) - 4));
    if ($line === '') return null;
    $prefix = $deptPart . $line . '/';

    $stmt = $db->prepare("SELECT asset_number FROM assets WHERE asset_number LIKE ?" . ($excludeId ? " AND id <> ?" : ""));
    $stmt->execute($excludeId ? [$prefix . '%', $excludeId] : [$prefix . '%']);
    $max = 0;
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $num) {
        if (preg_match('#^' . preg_quote($prefix, '#') . '(\d+)$#i', $num, $m)) $max = max($max, (int)$m[1]);
    }

    $check = $db->prepare("SELECT COUNT(*) FROM assets WHERE asset_number = ?" . ($excludeId ? " AND id <> ?" : ""));
    $next = $max + 1;
    do {
        $candidate = $prefix . sprintf('%03d', $next);
        $check->execute($excludeId ? [$candidate, $excludeId] : [$candidate]);
        $exists = (bool)$check->fetchColumn();
        if ($exists) $next++;
    } while ($exists);
    return $candidate;
}
