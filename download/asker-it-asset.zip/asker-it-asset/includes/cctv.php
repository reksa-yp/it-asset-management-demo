<?php
/**
 * CCTV: monitoring status kamera (lewat NVR / IP kamera), log kamera mati, notifikasi (web + email),
 * checklist pemeriksaan per shift/harian dan laporan bulanan.
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA: hanya membuat tabel BARU (CREATE TABLE IF NOT EXISTS),
 * tidak ada ALTER pada tabel lama. Kamera = aset dengan kategori yang mengandung kata "CCTV"/"Kamera"/"Camera".
 * Pengaturan (NVR tidak disimpan di sini, tapi di tabel cctv_nvr) disimpan di includes/data/cctv_settings.json.
 *
 * File ini juga dipakai oleh cctv_check.php dari Task Scheduler (CLI, tanpa sesi login),
 * jadi fungsi-fungsi inti di sini tidak boleh bergantung pada $_SESSION.
 */

// Zona waktu WIB. XAMPP bawaan memakai Europe/Berlin (php.ini), sehingga jam di log/email CCTV
// mundur 5-6 jam. Dipaksa Asia/Jakarta di sini (berlaku juga untuk Task Scheduler / php.exe).
if (date_default_timezone_get() !== 'Asia/Jakarta') date_default_timezone_set('Asia/Jakarta');


const CCTV_SETTINGS_FILE = __DIR__ . '/data/cctv_settings.json';
const CCTV_SEEN_FILE     = __DIR__ . '/data/cctv_seen.json';
const CCTV_PHOTO_DIR     = __DIR__ . '/../assets/uploads/cctv';
const CCTV_PHOTO_URL     = 'assets/uploads/cctv';
const CCTV_STATES        = ['on', 'off', 'vl', 'unknown'];
const CCTV_DEFAULT_ITEMS = [
    ['G', 'Gambar jelas, tidak buram'],
    ['P', 'Posisi/arah sesuai'],
    ['R', 'Rekaman berjalan (playback 1 jam terakhir)'],
    ['J', 'Jam & tanggal di layar benar'],
    ['M', 'Night vision / IR berfungsi'],
    ['F', 'Fisik, kabel & housing aman'],
];

/** Jenis masalah yang bisa dilaporkan petugas (kode => [ID, EN]). */
const CCTV_REPORT_ISSUES = [
    'mati'    => ['Mati / tidak ada gambar', 'Dead / no picture'],
    'buram'   => ['Gambar buram / kotor', 'Blurry / dirty picture'],
    'posisi'  => ['Posisi / arah bergeser', 'Position / angle moved'],
    'malam'   => ['Night vision / IR tidak berfungsi', 'Night vision / IR not working'],
    'fisik'   => ['Rusak fisik / kabel / housing', 'Physical / cable / housing damage'],
    'rekaman' => ['Rekaman tidak berjalan', 'Recording not running'],
    'jam'     => ['Jam / tanggal di layar salah', 'Wrong on-screen date / time'],
    'lainnya' => ['Lainnya', 'Other'],
];
/** Item checklist -> jenis masalah laporan (temuan checklist otomatis jadi laporan petugas). */
const CCTV_ITEM_ISSUE = ['G' => 'buram', 'P' => 'posisi', 'R' => 'rekaman', 'J' => 'jam', 'M' => 'malam', 'F' => 'fisik'];

/** Teks dua bahasa untuk halaman CCTV (bahasa Indonesia jika tidak ada sesi, mis. dari Task Scheduler). */
function cL(string $id, string $en): string
{
    if (!function_exists('currentLang') || session_status() !== PHP_SESSION_ACTIVE) return $id;
    return currentLang() === 'en' ? $en : $id;
}

function isCctvCategory(?string $category): bool
{
    return $category !== null && preg_match('/cctv|kamera|camera/i', $category) === 1;
}

/** Kategori perekam: NVR / DVR / XVR (dan bukan kategori kamera). */
function isNvrCategory(?string $category): bool
{
    return $category !== null && preg_match('/\b(nvr|dvr|xvr)\b/i', $category) === 1 && !isCctvCategory($category);
}

/** Cara baca status NVR dari nama brand. */
function cctvBrandMethod(string $brand): string
{
    if (preg_match('/hik|hilook/i', $brand)) return 'hikvision';
    if (preg_match('/dahua|imou/i', $brand)) return 'dahua';
    return $brand === '' ? 'hikvision' : 'ping';
}

/* ================================================================== Tabel */

function cctvTableExists(PDO $db, string $table, bool $refresh = false): bool
{
    static $cache = [];
    if (!isset($cache[$table]) || $refresh) {
        $st = $db->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
        $st->execute([$table]);
        $cache[$table] = (bool)$st->fetchColumn();
    }
    return $cache[$table];
}

/** Buat semua tabel CCTV yang belum ada (tanpa mengubah tabel lain). */
function ensureCctvTables(PDO $db): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    $ddl = [
        'cctv_nvr' => "CREATE TABLE IF NOT EXISTS cctv_nvr (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            name        VARCHAR(60)  NOT NULL,
            brand       VARCHAR(20)  NOT NULL DEFAULT 'hikvision',   -- hikvision | dahua | ping
            ip_address  VARCHAR(60)  NOT NULL,
            port        INT UNSIGNED NOT NULL DEFAULT 80,
            username    VARCHAR(60)  DEFAULT NULL,
            password    VARCHAR(120) DEFAULT NULL,
            is_active   TINYINT(1)   NOT NULL DEFAULT 1,
            last_state  VARCHAR(12)  DEFAULT NULL,
            last_detail VARCHAR(255) DEFAULT NULL,
            last_check  DATETIME     DEFAULT NULL,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'cctv_cameras' => "CREATE TABLE IF NOT EXISTS cctv_cameras (
            asset_id    INT UNSIGNED NOT NULL PRIMARY KEY,           -- assets.id (tanpa foreign key)
            nvr_id      INT UNSIGNED DEFAULT NULL,
            channel     INT UNSIGNED DEFAULT NULL,
            ip_address  VARCHAR(60)  DEFAULT NULL,                   -- kosong = pakai IP di data aset
            port        INT UNSIGNED DEFAULT NULL,                   -- kosong = 554 (RTSP)
            monitored   TINYINT(1)   NOT NULL DEFAULT 1,
            updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'cctv_status' => "CREATE TABLE IF NOT EXISTS cctv_status (
            asset_id     INT UNSIGNED NOT NULL PRIMARY KEY,
            state        VARCHAR(12)  NOT NULL DEFAULT 'unknown',    -- on | off | vl | unknown
            fail_count   INT UNSIGNED NOT NULL DEFAULT 0,
            fail_since   DATETIME     DEFAULT NULL,
            since        DATETIME     DEFAULT NULL,
            last_check   DATETIME     DEFAULT NULL,
            detail       VARCHAR(255) DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'cctv_events' => "CREATE TABLE IF NOT EXISTS cctv_events (
            id           INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            asset_id     INT UNSIGNED NOT NULL,
            kind         VARCHAR(12)  NOT NULL,                      -- off | vl
            started_at   DATETIME     NOT NULL,
            ended_at     DATETIME     DEFAULT NULL,
            duration_sec INT UNSIGNED DEFAULT NULL,
            detail       VARCHAR(255) DEFAULT NULL,
            note         VARCHAR(255) DEFAULT NULL,                  -- keterangan admin
            INDEX idx_cctv_ev_asset (asset_id),
            INDEX idx_cctv_ev_start (started_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'cctv_notices' => "CREATE TABLE IF NOT EXISTS cctv_notices (
            id           INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            asset_id     INT UNSIGNED NOT NULL,
            event_id     INT UNSIGNED DEFAULT NULL,
            type         VARCHAR(10)  NOT NULL,                      -- down | up
            message      VARCHAR(255) NOT NULL,
            created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'cctv_check_items' => "CREATE TABLE IF NOT EXISTS cctv_check_items (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            code        VARCHAR(5)   NOT NULL,
            label       VARCHAR(100) NOT NULL,
            sort_order  INT UNSIGNED NOT NULL DEFAULT 0,
            is_active   TINYINT(1)   NOT NULL DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'cctv_checklists' => "CREATE TABLE IF NOT EXISTS cctv_checklists (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            check_date  DATE         NOT NULL,
            shift       VARCHAR(30)  NOT NULL,
            user_id     INT UNSIGNED DEFAULT NULL,
            user_name   VARCHAR(100) DEFAULT NULL,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_cctv_cl (check_date, shift)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'cctv_checklist_results' => "CREATE TABLE IF NOT EXISTS cctv_checklist_results (
            id              INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            checklist_id    INT UNSIGNED NOT NULL,
            asset_id        INT UNSIGNED NOT NULL,
            status_snapshot VARCHAR(12)  DEFAULT NULL,
            results         TEXT,                                    -- JSON {kode: 1 (OK) | 2 (bermasalah)}
            note            VARCHAR(255) DEFAULT NULL,
            photo           VARCHAR(255) DEFAULT NULL,
            INDEX idx_cctv_res_cl (checklist_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'cctv_reports' => "CREATE TABLE IF NOT EXISTS cctv_reports (
            id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            asset_id      INT UNSIGNED NOT NULL,
            issue         VARCHAR(40)  NOT NULL,                     -- jenis masalah (lihat CCTV_REPORT_ISSUES)
            note          VARCHAR(255) DEFAULT NULL,
            photo         VARCHAR(255) DEFAULT NULL,
            reported_by   INT UNSIGNED DEFAULT NULL,
            reporter_name VARCHAR(100) DEFAULT NULL,
            reported_at   DATETIME     NOT NULL,
            status        VARCHAR(10)  NOT NULL DEFAULT 'open',      -- open | done
            handled_by    INT UNSIGNED DEFAULT NULL,
            handled_name  VARCHAR(100) DEFAULT NULL,
            handled_at    DATETIME     DEFAULT NULL,
            admin_note    VARCHAR(255) DEFAULT NULL,
            INDEX idx_cctv_rep_asset (asset_id),
            INDEX idx_cctv_rep_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'asset_cctv_info' => "CREATE TABLE IF NOT EXISTS asset_cctv_info (
            asset_id    INT UNSIGNED NOT NULL PRIMARY KEY,           -- assets.id (tanpa foreign key)
            brand       VARCHAR(60)  DEFAULT NULL,
            model       VARCHAR(80)  DEFAULT NULL,                   -- Type / seri kamera
            updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'cctv_checklist_nvr' => "CREATE TABLE IF NOT EXISTS cctv_checklist_nvr (
            checklist_id INT UNSIGNED NOT NULL,                      -- cctv_checklists.id
            nvr_key      INT UNSIGNED NOT NULL,                      -- cctv_nvr.id, 0 = kamera tanpa NVR
            user_id      INT UNSIGNED DEFAULT NULL,
            user_name    VARCHAR(100) DEFAULT NULL,
            updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (checklist_id, nvr_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'cctv_nvr_assets' => "CREATE TABLE IF NOT EXISTS cctv_nvr_assets (
            asset_id    INT UNSIGNED NOT NULL PRIMARY KEY,           -- aset kategori NVR (assets.id)
            nvr_id      INT UNSIGNED NOT NULL,                       -- cctv_nvr.id yang dibuat otomatis dari aset itu
            updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'user_cctv_access' => "CREATE TABLE IF NOT EXISTS user_cctv_access (
            user_id     INT UNSIGNED NOT NULL PRIMARY KEY,           -- users.id (tanpa foreign key)
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        // Kejadian mati yang sudah dikirim email (email dikirim setelah kamera mati >= email_after_min menit).
        'cctv_email_log' => "CREATE TABLE IF NOT EXISTS cctv_email_log (
            event_id   INT UNSIGNED NOT NULL PRIMARY KEY,
            sent_at    DATETIME     NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        // Snapshot tampilan kamera per bulan (List View CCTV), file di assets/uploads/cctv/snap/YYYY-MM/.
        'cctv_snapshots' => "CREATE TABLE IF NOT EXISTS cctv_snapshots (
            asset_id   INT UNSIGNED NOT NULL,
            ym         CHAR(7)      NOT NULL,
            path       VARCHAR(255) NOT NULL,
            state      VARCHAR(12)  DEFAULT NULL,
            taken_at   DATETIME     NOT NULL,
            PRIMARY KEY (asset_id, ym)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        // Hari libur checklist yang diisi manual (libur nasional, cuti bersama, cuti perusahaan).
        'cctv_holidays' => "CREATE TABLE IF NOT EXISTS cctv_holidays (
            holiday_date DATE NOT NULL PRIMARY KEY,
            name         VARCHAR(100) NOT NULL,
            created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    ];
    foreach ($ddl as $table => $sql) {
        if (!cctvTableExists($db, $table)) { $db->exec($sql); cctvTableExists($db, $table, true); }
    }
    // Item checklist bawaan saat pertama kali dipakai.
    if ((int)$db->query("SELECT COUNT(*) FROM cctv_check_items")->fetchColumn() === 0) {
        $ins = $db->prepare("INSERT INTO cctv_check_items (code, label, sort_order, is_active) VALUES (?, ?, ?, 1)");
        foreach (CCTV_DEFAULT_ITEMS as $i => [$code, $label]) $ins->execute([$code, $label, $i + 1]);
    }
    // (Versi umum: checklist susulan otomatis tidak dijalankan. Pakai menu Pengaturan > 6 > Isi checklist susulan jika perlu.)
}

/**
 * Checklist susulan "semua kamera OK" untuk hari kerja $from..$to (hari libur & shift yang sudah terisi dilewati).
 * Disimpan per bulan; hasil kamera dimasukkan per 300 baris. Return ['n' => jumlah checklist, 'error' => string].
 */
function cctvBackfillChecklists(PDO $db, string $from, string $to, int $userId, string $name): array
{
    @set_time_limit(0);
    @ignore_user_abort(true);
    $shifts = cctvShiftOptions();
    $groups = cctvNvrGroups(cctvCameras($db));
    $camIds = [];
    foreach ($groups as $g) foreach ($g['cams'] as $c) $camIds[] = (int)$c['id'];
    if (!$camIds || $from > $to) return ['n' => 0, 'error' => ''];
    $marks = json_encode(array_fill_keys(array_column(cctvCheckItems($db), 'code'), 1));
    $times = [0 => '08:00:00', 1 => '16:00:00', 2 => '23:30:00'];
    $off = cctvOffDays($db, $from, $to);
    $st = $db->prepare("SELECT check_date, shift FROM cctv_checklists WHERE check_date BETWEEN ? AND ?");
    $st->execute([$from, $to]);
    $have = [];
    foreach ($st->fetchAll() as $r) $have[substr((string)$r['check_date'], 0, 10) . '|' . $r['shift']] = true;
    $byMonth = [];
    for ($t = strtotime($from); $t <= strtotime($to); $t = strtotime('+1 day', $t)) {
        $d = date('Y-m-d', $t);
        if (isset($off[$d])) continue;
        foreach ($shifts as $i => $sh) if (!isset($have[$d . '|' . $sh])) $byMonth[substr($d, 0, 7)][] = [$d, $sh, $i];
    }
    $n = 0;
    $insCl  = $db->prepare("INSERT INTO cctv_checklists (check_date, shift, user_id, user_name, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)");
    $insNvr = $db->prepare("INSERT INTO cctv_checklist_nvr (checklist_id, nvr_key, user_id, user_name, updated_at) VALUES (?, ?, ?, ?, ?)");
    try {
        foreach ($byMonth as $rows) {
            $db->beginTransaction();
            $buf = [];
            $flush = function () use ($db, &$buf, $marks) {
                if (!$buf) return;
                $args = [];
                foreach ($buf as [$cl, $aid]) array_push($args, $cl, $aid, $marks);
                $db->prepare("INSERT INTO cctv_checklist_results (checklist_id, asset_id, status_snapshot, results, note, photo) VALUES "
                    . implode(',', array_fill(0, count($buf), "(?, ?, 'on', ?, NULL, NULL)")))->execute($args);
                $buf = [];
            };
            foreach ($rows as [$d, $sh, $i]) {
                $at = $d . ' ' . ($times[$i] ?? '12:00:00');
                $insCl->execute([$d, $sh, $userId ?: null, $name, $at, $at]);
                $clId = (int)$db->lastInsertId();
                foreach (array_keys($groups) as $gk) $insNvr->execute([$clId, $gk, $userId ?: null, $name, $at]);
                foreach ($camIds as $aid) { $buf[] = [$clId, $aid]; if (count($buf) >= 300) $flush(); }
                $n++;
            }
            $flush();
            $db->commit();
        }
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        return ['n' => $n, 'error' => $e->getMessage()];
    }
    return ['n' => $n, 'error' => ''];
}

/**
 * Sekali saja setelah update: checklist 1 Januari tahun ini s.d. kemarin otomatis terisi "semua OK" (hari kerja).
 * Petugas = admin pertama dengan tanda "(susulan)". Jika terputus, dilanjutkan pada pembukaan berikutnya.
 */
function cctvAutoBackfillOnce(PDO $db): void
{
    static $ran = false;
    if ($ran) return;
    $ran = true;
    $flag = dirname(CCTV_SETTINGS_FILE) . '/cctv_susulan_done.json';
    if (is_file($flag)) return;
    $lock = @fopen(dirname(CCTV_SETTINGS_FILE) . '/cctv_susulan.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) return;        // sedang dijalankan oleh proses lain
    try {
        if (!cctvCameras($db)) return;                              // belum ada kamera: coba lagi nanti
        $adm = $db->query("SELECT id, full_name FROM users WHERE role = 'admin' ORDER BY id LIMIT 1")->fetch() ?: ['id' => 0, 'full_name' => 'Admin IT'];
        $from = date('Y') . '-01-01';
        $to   = date('Y-m-d', strtotime('-1 day'));
        $res = cctvBackfillChecklists($db, $from, $to, (int)$adm['id'], trim((string)$adm['full_name']) . ' (susulan)');
        if ($res['error'] === '') {
            @file_put_contents($flag, json_encode(['from' => $from, 'to' => $to, 'checklists' => $res['n'], 'at' => date('Y-m-d H:i:s')]));
        }
    } catch (Throwable $e) {
        // abaikan: dicoba lagi pada pembukaan berikutnya
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

/* ================================================================== Pengaturan (JSON) */

function cctvSettingsDefaults(): array
{
    return [
        'checklist_mode' => 'shift',                 // shift | daily
        'shifts'         => ['Pagi', 'Sore'],         // checklist 2x sehari (malam tidak ada); bisa diubah di Pengaturan
        'shift_roles'    => ['Pagi' => 'admin', 'Sore' => 'admin'],   // siapa yang mengisi: admin | cctv | both
        'shift_v'        => 2,                       // versi pengaturan shift (2 = Pagi & Sore)
        'fail_threshold' => 2,
        'email_after_min'=> 30,                      // email CCTV mati dikirim & kejadian masuk Log CCTV mati setelah kamera mati sekian menit (0 = langsung)
        'interval_min'   => 2,                       // informasi saja (jadwal sebenarnya di Task Scheduler)
        'notify_web'     => true,
        'web_after_min'  => 10,                      // pop-up web baru muncul bila kamera mati >= sekian menit (0 = langsung)
        'notify_recover' => true,
        'notify_email'   => false,
        'email_to'       => '',
        'smtp_host'      => '',
        'smtp_port'      => 587,
        'smtp_secure'    => 'tls',                   // tls | ssl | none
        'smtp_user'      => '',
        'smtp_pass'      => '',
        'smtp_from'      => '',
        'smtp_from_name' => 'IT System - CCTV',
        'off_weekdays'   => [6, 7],                  // hari libur mingguan checklist (1 = Senin ... 7 = Minggu)
        'snapshot_schedule' => 'first_monday',       // snapshot List View otomatis: first_monday (Senin pertama tiap bulan) | daily | off
        'snapshot_hour'  => 9,                       // mulai jam berapa snapshot otomatis diambil
        'snapshot_last'  => '',                      // tanggal snapshot otomatis terakhir (Y-m-d)
        'nvr_public_ip'  => [],                      // IP publik per NVR untuk cover checklist [nvr_id => ip]
        'rtsp_port'      => [],                      // port RTSP per NVR untuk live preview [nvr_id => port], bawaan 554
        'ffmpeg_path'    => '',                      // lokasi ffmpeg.exe untuk live preview RTSP (kosong = cari otomatis)
        'check_key'      => '',                      // kunci rahasia untuk memicu cek lewat URL (opsional)
        'last_run'       => '',
        'last_run_info'  => '',
    ];
}

function cctvSettings(bool $refresh = false): array
{
    static $cache = null;
    if ($cache === null || $refresh) {
        $cache = cctvSettingsDefaults();
        if (is_file(CCTV_SETTINGS_FILE)) {
            $data = json_decode((string)file_get_contents(CCTV_SETTINGS_FILE), true);
            if (is_array($data)) {
                foreach ($cache as $k => $v) {
                    if (array_key_exists($k, $data)) $cache[$k] = is_array($v) ? (array)$data[$k] : (is_bool($v) ? (bool)$data[$k] : (is_int($v) ? (int)$data[$k] : (string)$data[$k]));
                }
            }
        }
        $cache['shifts'] = array_values(array_filter(array_map('trim', $cache['shifts']), 'strlen')) ?: ['Pagi'];
        // Pengaturan lama (Pagi, Siang/Sore, Malam) -> Pagi, Sore (checklist 2x sehari, malam tidak ada).
        // Hanya sekali: setelah disimpan dengan shift_v = 2, shift Malam yang ditambah lagi lewat Pengaturan tetap dipakai.
        $oldShifts = is_array($data ?? null) && !isset($data['shift_v'])
            && in_array($cache['shifts'], [['Pagi', 'Siang', 'Malam'], ['Pagi', 'Sore', 'Malam']], true);
        if ($oldShifts) {
            $cache['shifts'] = ['Pagi', 'Sore'];
            $cache['shift_roles'] = ['Pagi' => 'admin', 'Sore' => 'admin'];
            // Sekali saja: checklist lama ber-shift "Siang" ikut menjadi "Sore", lalu pengaturan disimpan.
            try {
                if (function_exists('getDB') && cctvTableExists(getDB(), 'cctv_checklists')) {
                    getDB()->exec("UPDATE cctv_checklists SET shift = 'Sore' WHERE shift = 'Siang'
                                   AND check_date NOT IN (SELECT d FROM (SELECT check_date AS d FROM cctv_checklists WHERE shift = 'Sore') x)");
                }
                if (is_file(CCTV_SETTINGS_FILE) && is_array($data ?? null)) {
                    $data['shifts'] = $cache['shifts'];
                    $data['shift_roles'] = $cache['shift_roles'];
                    $data['shift_v'] = 2;
                    @file_put_contents(CCTV_SETTINGS_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
                }
            } catch (Throwable $e) { /* abaikan: hanya merapikan data lama */ }
        }
        $roles = [];
        foreach ($cache['shifts'] as $i => $sh) {
            $r = $cache['shift_roles'][$sh] ?? null;
            if (!in_array($r, ['admin', 'cctv', 'both'], true)) $r = ($i === count($cache['shifts']) - 1 && count($cache['shifts']) >= 3) ? 'cctv' : 'admin';
            $roles[$sh] = $r;
        }
        $cache['shift_roles'] = $roles;
        $cache['fail_threshold'] = max(1, min(10, (int)$cache['fail_threshold']));
        $cache['off_weekdays'] = array_values(array_unique(array_filter(array_map('intval', (array)$cache['off_weekdays']), fn($d) => $d >= 1 && $d <= 7)));
    }
    return $cache;
}

function saveCctvSettings(array $changes): bool
{
    $data = array_merge(cctvSettings(true), $changes);
    $dir = dirname(CCTV_SETTINGS_FILE);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $ok = file_put_contents(CCTV_SETTINGS_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
    cctvSettings(true);
    return $ok;
}

/**
 * Urutan shift yang sedang berjalan menurut jam sekarang.
 * 2 shift (Pagi, Sore): Pagi sampai 12:00, Sore mulai 12:00. 3 shift: 07-15, 15-23, 23-07.
 * $strict = true: sebelum jam 07 hari ini belum ada shift yang dimulai (-1, untuk hitungan kepatuhan).
 */
function cctvShiftIndexNow(array $shifts, bool $strict = false): int
{
    $hr = (int)date('G');
    $n = count($shifts);
    if ($n >= 3) return $hr >= 7 && $hr < 15 ? 0 : ($hr >= 15 && $hr < 23 ? 1 : ($hr >= 23 || !$strict ? 2 : -1));
    if ($n === 2) return $hr < 12 ? ($strict && $hr < 7 ? -1 : 0) : 1;
    return 0;
}

/** Shift yang dipakai checklist (mode harian = satu "shift" bernama Harian). */
function cctvShiftOptions(): array
{
    $s = cctvSettings();
    return $s['checklist_mode'] === 'daily' ? ['Harian'] : $s['shifts'];
}

/** Siapa yang mengisi checklist shift ini: admin | cctv | both. */
function cctvShiftRole(string $shift): string
{
    $s = cctvSettings();
    if ($s['checklist_mode'] === 'daily') return 'both';
    return $s['shift_roles'][$shift] ?? 'both';
}

function cctvShiftRoleLabel(string $role): string
{
    return ['admin' => cL('Admin IT', 'IT admin'), 'cctv' => cL('User CCTV yang ditunjuk', 'Assigned CCTV user'), 'both' => cL('Admin & user CCTV', 'Admin & CCTV user')][$role] ?? $role;
}

/** User yang sedang login boleh mengisi checklist shift ini? */
function cctvCanFillShift(string $shift): bool
{
    $role = cctvShiftRole($shift);
    if (isAdmin()) return $role !== 'cctv';
    return isCctvUser() && $role !== 'admin';
}

/* ================================================================== Akses user (Checklist CCTV) */

function cctvUserMap(PDO $db): array
{
    if (!cctvTableExists($db, 'user_cctv_access')) return [];
    $out = [];
    foreach ($db->query("SELECT user_id FROM user_cctv_access")->fetchAll(PDO::FETCH_COLUMN) as $id) $out[(int)$id] = true;
    return $out;
}

function setCctvAccess(PDO $db, int $userId, bool $on): void
{
    if ($userId <= 0) return;
    if ($on) ensureCctvTables($db);
    if (!cctvTableExists($db, 'user_cctv_access')) return;
    $db->prepare("DELETE FROM user_cctv_access WHERE user_id = ?")->execute([$userId]);
    if ($on) $db->prepare("INSERT INTO user_cctv_access (user_id) VALUES (?)")->execute([$userId]);
}

/** User biasa yang boleh mengisi checklist CCTV (admin selalu boleh). */
function isCctvUser(): bool
{
    static $cache = null;
    if ($cache !== null) return $cache;
    if (empty($_SESSION['user_id']) || isAdmin()) return $cache = false;
    try {
        $db = getDB();
        if (!cctvTableExists($db, 'user_cctv_access')) return $cache = false;
        $st = $db->prepare("SELECT 1 FROM user_cctv_access WHERE user_id = ?");
        $st->execute([(int)$_SESSION['user_id']]);
        return $cache = (bool)$st->fetchColumn();
    } catch (Throwable $e) {
        return $cache = false;
    }
}

function requireAdminOrCctv(): void
{
    requireLogin();
    if (isAdmin() || isCctvUser()) return;
    requireAdmin();
}

/* ================================================================== Data kamera */

function cctvNvrList(PDO $db, bool $activeOnly = false): array
{
    ensureCctvTables($db);
    $rows = $db->query("SELECT * FROM cctv_nvr ORDER BY name")->fetchAll();
    if ($activeOnly) $rows = array_values(array_filter($rows, fn($r) => (int)$r['is_active'] === 1));
    $out = [];
    foreach ($rows as $r) $out[(int)$r['id']] = $r;
    return $out;
}

/** Semua aset CCTV + pemetaan NVR/channel + status terakhir, urut nomor aset. */
function cctvCameras(PDO $db): array
{
    ensureCctvTables($db);
    $assets = $db->query("SELECT id, asset_number, category, device_name, location, department, ip_address, status FROM assets ORDER BY asset_number")->fetchAll();
    $assets = array_values(array_filter($assets, fn($a) => isCctvCategory($a['category'])));
    if (!$assets) return [];
    $map = []; $stat = [];
    foreach ($db->query("SELECT * FROM cctv_cameras")->fetchAll() as $r) $map[(int)$r['asset_id']] = $r;
    foreach ($db->query("SELECT * FROM cctv_status")->fetchAll() as $r) $stat[(int)$r['asset_id']] = $r;
    $nvrs = cctvNvrList($db);
    $out = [];
    foreach ($assets as $a) {
        $id = (int)$a['id'];
        $m  = $map[$id] ?? [];
        $s  = $stat[$id] ?? [];
        $nvrId = (int)($m['nvr_id'] ?? 0);
        $out[] = [
            'id'         => $id,
            'number'     => (string)$a['asset_number'],
            'name'       => (string)($a['device_name'] ?? ''),
            'location'   => (string)($a['location'] ?? ''),
            'department' => (string)($a['department'] ?? ''),
            'asset_ip'   => (string)($a['ip_address'] ?? ''),
            'asset_status' => (string)($a['status'] ?? ''),
            'nvr_id'     => $nvrId ?: null,
            'nvr_name'   => $nvrId && isset($nvrs[$nvrId]) ? (string)$nvrs[$nvrId]['name'] : '',
            'channel'    => isset($m['channel']) && $m['channel'] !== null && $m['channel'] !== '' ? (int)$m['channel'] : null,
            'ip'         => trim((string)($m['ip_address'] ?? '')) !== '' ? trim((string)$m['ip_address']) : trim((string)($a['ip_address'] ?? '')),
            'ip_override'=> trim((string)($m['ip_address'] ?? '')),
            'port'       => isset($m['port']) && (int)$m['port'] > 0 ? (int)$m['port'] : null,
            'monitored'  => $m ? (int)$m['monitored'] === 1 : true,
            'state'      => (string)($s['state'] ?? 'unknown'),
            'since'      => $s['since'] ?? null,
            'last_check' => $s['last_check'] ?? null,
            'detail'     => (string)($s['detail'] ?? ''),
        ];
    }
    return $out;
}

/** Cara kamera dicek: 'nvr', 'ip' atau '' (belum bisa dipantau). */
function cctvCheckMethod(array $cam): string
{
    if (!$cam['monitored']) return '';
    if ($cam['nvr_id'] && $cam['channel']) return 'nvr';
    if ($cam['ip'] !== '' && filter_var($cam['ip'], FILTER_VALIDATE_IP)) return 'ip';
    return '';
}

function cctvStateLabel(string $state): string
{
    return [
        'on'      => cL('Online', 'Online'),
        'off'     => cL('Offline', 'Offline'),
        'vl'      => cL('Video loss', 'Video loss'),
        'unknown' => cL('Belum dipantau', 'Not monitored'),
    ][$state] ?? $state;
}

function cctvStateBadge(string $state): string
{
    $cls = [
        'on'      => 'bg-green-100 text-green-700',
        'off'     => 'bg-red-100 text-red-700',
        'vl'      => 'bg-amber-100 text-amber-700',
        'unknown' => 'bg-slate-100 text-slate-500',
    ][$state] ?? 'bg-slate-100 text-slate-500';
    return '<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold whitespace-nowrap ' . $cls . '">'
         . '<span class="w-1.5 h-1.5 rounded-full bg-current"></span>' . htmlspecialchars(cctvStateLabel($state)) . '</span>';
}

function cctvDuration(int $sec): string
{
    $sec = max(0, $sec);
    $d = intdiv($sec, 86400); $h = intdiv($sec % 86400, 3600); $m = intdiv($sec % 3600, 60);
    if ($d) return $d . 'h ' . $h . 'j ' . str_pad((string)$m, 2, '0', STR_PAD_LEFT) . 'm';
    return $h . 'j ' . str_pad((string)$m, 2, '0', STR_PAD_LEFT) . 'm';
}

/* ================================================================== Membaca status dari NVR / kamera */

/** HTTP GET dengan Digest/Basic auth. Return [httpCode, body] ; httpCode 0 = tidak terhubung. */
function cctvHttpGet(string $url, string $user, string $pass, int $timeout = 5): array
{
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT        => $timeout + 3,
            CURLOPT_HTTPAUTH       => CURLAUTH_DIGEST | CURLAUTH_BASIC,
            CURLOPT_USERPWD        => $user . ':' . $pass,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return [$body === false ? 0 : $code, $body === false ? '' : (string)$body];
    }
    // Cadangan tanpa ekstensi curl: hanya Basic auth.
    $ctx = stream_context_create(['http' => [
        'timeout' => $timeout, 'ignore_errors' => true,
        'header'  => 'Authorization: Basic ' . base64_encode($user . ':' . $pass),
    ]]);
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) return [0, ''];
    $code = 0;
    foreach ($http_response_header ?? [] as $h) if (preg_match('#^HTTP/\S+\s+(\d+)#', $h, $m)) $code = (int)$m[1];
    return [$code, (string)$body];
}

/** Cek port TCP terbuka (pengganti ping, tidak butuh hak administrator). */
function cctvTcpAlive(string $ip, int $port, float $timeout = 2.0): bool
{
    $fp = @fsockopen($ip, $port, $errno, $errstr, $timeout);
    if ($fp) { fclose($fp); return true; }
    return false;
}

/**
 * Status semua channel satu NVR.
 * Return ['ok' => bool, 'detail' => string, 'channels' => [no => 'on'|'off'|'vl']].
 * ok=false berarti NVR tidak bisa dihubungi / login gagal (semua kameranya dianggap mati).
 */
function cctvReadNvr(array $nvr): array
{
    $brand = strtolower((string)$nvr['brand']);
    $ip    = trim((string)$nvr['ip_address']);
    $port  = (int)$nvr['port'] ?: 80;
    $user  = (string)$nvr['username'];
    $pass  = (string)$nvr['password'];
    $base  = ($port === 443 ? 'https://' : 'http://') . $ip . ($port === 80 || $port === 443 ? '' : ':' . $port);

    if ($brand === 'ping') {
        $ok = cctvTcpAlive($ip, $port);
        return ['ok' => $ok, 'detail' => $ok ? 'NVR merespons' : 'NVR tidak merespons (port ' . $port . ')', 'channels' => []];
    }

    if ($brand === 'dahua') {
        [$code, $body] = cctvHttpGet($base . '/cgi-bin/LogicDeviceManager.cgi?action=getCameraState&uniqueChannels[0]=-1', $user, $pass);
        if ($code === 0) return ['ok' => false, 'detail' => 'NVR tidak merespons', 'channels' => []];
        if ($code === 401) return ['ok' => false, 'busy' => true, 'detail' => 'Login NVR gagal (cek user/password)', 'channels' => []];
        $ch = [];
        if ($code === 200 && preg_match_all('/states\[(\d+)\]\.channel=(\d+)/', $body, $mm, PREG_SET_ORDER)) {
            foreach ($mm as $m) {
                $state = preg_match('/states\[' . $m[1] . '\]\.connectionState=(\w+)/', $body, $s) ? $s[1] : '';
                $ch[(int)$m[2] + 1] = strcasecmp($state, 'Connected') === 0 ? 'on' : 'off';
            }
        }
        // DVR analog / tambahan: channel yang sedang video loss.
        [$c2, $b2] = cctvHttpGet($base . '/cgi-bin/eventManager.cgi?action=getEventIndexes&code=VideoLoss', $user, $pass);
        if ($c2 === 200 && preg_match_all('/channels\[\d+\]=(\d+)/', $b2, $vl)) {
            foreach ($vl[1] as $n) { $no = (int)$n + 1; if (($ch[$no] ?? 'on') === 'on') $ch[$no] = 'vl'; }
        }
        if (!$ch && $code !== 200) return ['ok' => false, 'busy' => true, 'detail' => 'NVR membalas HTTP ' . $code, 'channels' => []];
        return ['ok' => true, 'detail' => 'NVR online · ' . count($ch) . ' channel terbaca', 'channels' => $ch];
    }

    // Hikvision (ISAPI). NVR: InputProxy (kamera IP). DVR/analog: workingstatus.
    [$code, $body] = cctvHttpGet($base . '/ISAPI/ContentMgmt/InputProxy/channels/status', $user, $pass);
    if ($code >= 500) { sleep(3); [$code, $body] = cctvHttpGet($base . '/ISAPI/ContentMgmt/InputProxy/channels/status', $user, $pass); }   // NVR sibuk: coba sekali lagi
    if ($code === 0) return ['ok' => false, 'detail' => 'NVR tidak merespons', 'channels' => []];
    if ($code === 401) return ['ok' => false, 'busy' => true, 'detail' => 'Login NVR gagal (cek user/password)', 'channels' => []];
    $ch = [];
    if ($code === 200 && preg_match_all('#<InputProxyChannelStatus[^>]*>(.*?)</InputProxyChannelStatus>#s', $body, $mm)) {
        foreach ($mm[1] as $blk) {
            if (!preg_match('#<id>(\d+)</id>#', $blk, $id)) continue;
            $online = preg_match('#<online>\s*true\s*</online>#i', $blk) === 1;
            $ch[(int)$id[1]] = $online ? 'on' : 'off';
        }
    }
    [$c2, $b2] = cctvHttpGet($base . '/ISAPI/System/workingstatus?format=xml', $user, $pass);
    if ($c2 === 200 && preg_match_all('#<ChanStatus[^>]*>(.*?)</ChanStatus>#s', $b2, $ws)) {
        foreach ($ws[1] as $blk) {
            if (!preg_match('#<chanNo>(\d+)</chanNo>#', $blk, $no)) continue;
            $n = (int)$no[1];
            if (isset($ch[$n]) && $ch[$n] === 'off') continue;
            $online   = !preg_match('#<online>\s*(0|false)\s*</online>#i', $blk);
            $sigLost  = preg_match('#<signal>\s*(1|true)\s*</signal>#i', $blk) === 1;   // ISAPI: signal 0 = normal, 1 = sinyal hilang
            $ch[$n] = !$online ? 'off' : ($sigLost ? 'vl' : ($ch[$n] ?? 'on'));
        }
    }
    if (!$ch) {
        return $code === 200 || $c2 === 200
            ? ['ok' => true, 'detail' => 'NVR online, tetapi daftar channel tidak terbaca', 'channels' => []]
            : ['ok' => false, 'busy' => true, 'detail' => 'NVR membalas HTTP ' . $code . ' (status kamera tidak diubah)', 'channels' => []];
    }
    return ['ok' => true, 'detail' => 'NVR online · ' . count($ch) . ' channel terbaca', 'channels' => $ch];
}

/* ================================================================== Proses cek (Task Scheduler) */

/**
 * Cek semua kamera sekali, simpan status, buka/tutup log, kirim notifikasi.
 * Return ringkasan ['checked','on','off','vl','skipped','down'=>[...],'up'=>[...],'nvr'=>[...],'email'=>string].
 */
function runCctvCheck(PDO $db): array
{
    ensureCctvTables($db);
    $set   = cctvSettings(true);
    $limit = $set['fail_threshold'];
    $now   = date('Y-m-d H:i:s');
    $nvrs  = cctvNvrList($db, true);
    $nvrRes = [];
    foreach ($nvrs as $id => $n) {
        $r = cctvReadNvr($n);
        $nvrRes[$id] = $r;
        $db->prepare("UPDATE cctv_nvr SET last_state = ?, last_detail = ?, last_check = ? WHERE id = ?")
           ->execute([$r['ok'] ? 'on' : 'off', mb_substr($r['detail'], 0, 250), $now, $id]);
    }

    $sum = ['checked' => 0, 'on' => 0, 'off' => 0, 'vl' => 0, 'skipped' => 0, 'down' => [], 'up' => [], 'nvr' => [], 'email' => ''];
    foreach ($nvrs as $id => $n) $sum['nvr'][] = $n['name'] . ': ' . $nvrRes[$id]['detail'];

    $getSt = $db->prepare("SELECT * FROM cctv_status WHERE asset_id = ?");
    $insSt = $db->prepare("INSERT INTO cctv_status (asset_id, state, fail_count, fail_since, since, last_check, detail) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $updSt = $db->prepare("UPDATE cctv_status SET state = ?, fail_count = ?, fail_since = ?, since = ?, last_check = ?, detail = ? WHERE asset_id = ?");

    foreach (cctvCameras($db) as $cam) {
        $method = cctvCheckMethod($cam);
        if ($method === '' || ($method === 'nvr' && !isset($nvrRes[$cam['nvr_id']]))) { $sum['skipped']++; continue; }
        $sum['checked']++;
        if ($method === 'nvr') {
            $r = $nvrRes[$cam['nvr_id']];
            if (!$r['ok'] && !empty($r['busy'])) { $raw = 'unknown'; $detail = $r['detail']; }   // NVR hidup tapi menjawab error: jangan anggap kamera mati
            elseif (!$r['ok']) { $raw = 'off'; $detail = $r['detail']; }
            elseif (isset($r['channels'][$cam['channel']])) { $raw = $r['channels'][$cam['channel']]; $detail = $cam['nvr_name'] . ' ch ' . $cam['channel']; }
            elseif (!$r['channels']) { $raw = 'unknown'; $detail = $r['detail']; }
            else { $raw = 'off'; $detail = 'Channel ' . $cam['channel'] . ' tidak ada di ' . $cam['nvr_name']; }
        } else {
            $port = $cam['port'] ?: 554;
            $alive = cctvTcpAlive($cam['ip'], $port) || (!$cam['port'] && cctvTcpAlive($cam['ip'], 80));
            $raw = $alive ? 'on' : 'off';
            $detail = $cam['ip'] . ($alive ? '' : ' tidak merespons');
        }
        if ($raw === 'unknown') { $sum['skipped']++; $sum['checked']--; continue; }

        $getSt->execute([$cam['id']]);
        $st = $getSt->fetch();
        if (!$st) {
            // Pertama kali dipantau: catat apa adanya (tanpa notifikasi untuk kamera yang sudah mati sejak awal).
            $insSt->execute([$cam['id'], $raw, $raw === 'on' ? 0 : $limit, $raw === 'on' ? null : $now, $now, $now, $detail]);
            if ($raw !== 'on') cctvOpenEvent($db, $cam, $raw, $now, $detail);
            $sum[$raw]++;
            continue;
        }
        $state = (string)$st['state'];
        $fail  = (int)$st['fail_count'];
        if ($raw === 'on') {
            if ($state !== 'on' && $state !== 'unknown') {
                $ev = cctvCloseEvent($db, $cam['id'], $now);
                $sum['up'][] = ['cam' => $cam, 'event' => $ev];
                // Pop-up "online kembali" hanya bila pop-up "mati" untuk kejadian ini sudah pernah muncul (gangguan singkat tidak dilaporkan).
                if (!empty($ev['id']) && cctvHasDownNotice($db, (int)$ev['id'])) {
                    cctvAddNotice($db, $cam['id'], (int)$ev['id'], 'up', $cam['number'] . ' ' . ($cam['name'] ?: $cam['location']) . ' online kembali'
                        . (isset($ev['duration_sec']) ? ' (mati ' . cctvDuration((int)$ev['duration_sec']) . ')' : ''));
                }
            }
            $updSt->execute(['on', 0, null, $state === 'on' ? $st['since'] : $now, $now, $detail, $cam['id']]);
            $sum['on']++;
            continue;
        }
        // raw = off / vl
        $fail++;
        $failSince = $st['fail_since'] ?: $now;
        if (($state === 'on' || $state === 'unknown') && $fail >= $limit) {
            $ev = cctvOpenEvent($db, $cam, $raw, $failSince, $detail);
            $updSt->execute([$raw, $fail, $failSince, $failSince, $now, $detail, $cam['id']]);
            $sum['down'][] = ['cam' => $cam, 'kind' => $raw, 'since' => $failSince, 'detail' => $detail];
            $sum[$raw]++;
        } elseif ($state === 'on' || $state === 'unknown') {
            $updSt->execute([$state, $fail, $failSince, $st['since'], $now, $detail, $cam['id']]);   // belum mencapai batas
            $sum['on']++;
        } else {
            $updSt->execute([$state, $fail, $failSince, $st['since'], $now, $detail, $cam['id']]);   // masih mati
            $sum[$state === 'vl' ? 'vl' : 'off']++;
        }
    }

    // Pop-up web: kamera yang sudah mati >= web_after_min menit (sekali per kejadian), sehingga kamera yang putus-nyambung sebentar tidak memunculkan pop-up.
    $webCut = date('Y-m-d H:i:s', strtotime($now) - max(0, (int)$set['web_after_min']) * 60);
    $pendWeb = $db->prepare("SELECT e.* FROM cctv_events e WHERE e.ended_at IS NULL AND e.started_at <= ?
                             AND NOT EXISTS (SELECT 1 FROM cctv_notices n WHERE n.event_id = e.id AND n.type = 'down') ORDER BY e.started_at");
    $pendWeb->execute([$webCut]);
    $webRows = $pendWeb->fetchAll();
    if ($webRows) {
        $camWeb = [];
        foreach (cctvCameras($db) as $c) $camWeb[(int)$c['id']] = $c;
        foreach ($webRows as $e) {
            $c = $camWeb[(int)$e['asset_id']] ?? null;
            if (!$c) continue;
            $mins = (int)floor((strtotime($now) - strtotime((string)$e['started_at'])) / 60);
            cctvAddNotice($db, (int)$c['id'], (int)$e['id'], 'down', $c['number'] . ' ' . ($c['name'] ?: $c['location']) . ' ' . strtoupper(cctvStateLabel((string)$e['kind']))
                . ' sejak ' . date('H:i', strtotime((string)$e['started_at'])) . ($mins > 0 ? ' (' . cctvDuration($mins * 60) . ')' : '') . ' · ' . (string)$e['detail']);
        }
    }

    // Email: kamera yang sudah mati >= email_after_min menit (sekali per kejadian). Email "online kembali" hanya untuk
    // kejadian yang sebelumnya sudah diemailkan, sehingga gangguan singkat tidak mengirim email sama sekali.
    if ($set['notify_email']) {
        $delay = max(0, (int)$set['email_after_min']);
        $cut = date('Y-m-d H:i:s', strtotime($now) - $delay * 60);
        $camById = [];
        foreach (cctvCameras($db) as $c) $camById[(int)$c['id']] = $c;
        $pend = $db->prepare("SELECT e.* FROM cctv_events e LEFT JOIN cctv_email_log m ON m.event_id = e.id
                              WHERE e.ended_at IS NULL AND m.event_id IS NULL AND e.started_at <= ? ORDER BY e.started_at");
        $pend->execute([$cut]);
        $mailDown = [];
        foreach ($pend->fetchAll() as $e) {
            if (!isset($camById[(int)$e['asset_id']])) continue;
            $mailDown[] = ['cam' => $camById[(int)$e['asset_id']], 'kind' => (string)$e['kind'], 'since' => (string)$e['started_at'],
                           'detail' => (string)$e['detail'], 'event_id' => (int)$e['id'], 'dur' => strtotime($now) - strtotime((string)$e['started_at'])];
        }
        $mailUp = [];
        if ($set['notify_recover'] && $sum['up']) {
            $chk = $db->prepare("SELECT 1 FROM cctv_email_log WHERE event_id = ?");
            foreach ($sum['up'] as $u) {
                if (empty($u['event']['id'])) continue;
                $chk->execute([(int)$u['event']['id']]);
                if ($chk->fetchColumn()) $mailUp[] = $u;
            }
        }
        if ($mailDown || $mailUp) {
            $sum['email'] = cctvSendStatusEmail(['down' => $mailDown, 'up' => $mailUp, 'delay_min' => $delay] + $sum);
            if ($sum['email'] === '') {
                $log = $db->prepare("INSERT INTO cctv_email_log (event_id, sent_at) VALUES (?, ?)");
                foreach ($mailDown as $d) $log->execute([$d['event_id'], $now]);
            }
            $sum['emailed_down'] = count($mailDown);
            $sum['emailed_up'] = count($mailUp);
        }
    }
    $info = sprintf('%d dicek: %d online, %d offline, %d video loss, %d belum dipantau', $sum['checked'], $sum['on'], $sum['off'], $sum['vl'], $sum['skipped']);
    saveCctvSettings(['last_run' => $now, 'last_run_info' => $info]);
    return $sum;
}

function cctvOpenEvent(PDO $db, array $cam, string $kind, string $since, string $detail): ?int
{
    $open = $db->prepare("SELECT id FROM cctv_events WHERE asset_id = ? AND ended_at IS NULL");
    $open->execute([$cam['id']]);
    if ($id = $open->fetchColumn()) return (int)$id;
    $db->prepare("INSERT INTO cctv_events (asset_id, kind, started_at, detail) VALUES (?, ?, ?, ?)")
       ->execute([$cam['id'], $kind, $since, mb_substr($detail, 0, 250)]);
    return (int)$db->lastInsertId();
}

function cctvCloseEvent(PDO $db, int $assetId, string $now): array
{
    $st = $db->prepare("SELECT * FROM cctv_events WHERE asset_id = ? AND ended_at IS NULL ORDER BY id DESC");
    $st->execute([$assetId]);
    $ev = $st->fetch();
    if (!$ev) return [];
    $dur = max(0, strtotime($now) - strtotime((string)$ev['started_at']));
    $db->prepare("UPDATE cctv_events SET ended_at = ?, duration_sec = ? WHERE asset_id = ? AND ended_at IS NULL")->execute([$now, $dur, $assetId]);
    $ev['ended_at'] = $now; $ev['duration_sec'] = $dur;
    return $ev;
}

function cctvHasDownNotice(PDO $db, int $eventId): bool
{
    $st = $db->prepare("SELECT 1 FROM cctv_notices WHERE event_id = ? AND type = 'down' LIMIT 1");
    $st->execute([$eventId]);
    return (bool)$st->fetchColumn();
}

function cctvAddNotice(PDO $db, int $assetId, ?int $eventId, string $type, string $message): void
{
    $db->prepare("INSERT INTO cctv_notices (asset_id, event_id, type, message, created_at) VALUES (?, ?, ?, ?, ?)")
       ->execute([$assetId, $eventId, $type, mb_substr($message, 0, 250), date('Y-m-d H:i:s')]);
}

/* ================================================================== Notifikasi web (popup admin) */

function cctvSeen(?callable $fn = null): array
{
    $dir = dirname(CCTV_SEEN_FILE);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $fp = @fopen(CCTV_SEEN_FILE, 'c+');
    if (!$fp) return [];
    flock($fp, $fn ? LOCK_EX : LOCK_SH);
    $data = json_decode((string)stream_get_contents($fp), true);
    if (!is_array($data)) $data = [];
    if ($fn) {
        $data = $fn($data);
        ftruncate($fp, 0); rewind($fp);
        fwrite($fp, json_encode($data));
        fflush($fp);
    }
    flock($fp, LOCK_UN);
    fclose($fp);
    return $data;
}

/** Pemberitahuan CCTV yang belum dilihat admin ini (maks 10 terbaru). */
function cctvUnseenNotices(PDO $db, int $userId): array
{
    if (!cctvTableExists($db, 'cctv_notices')) return ['max_id' => 0, 'items' => []];
    $max  = (int)$db->query("SELECT COALESCE(MAX(id), 0) FROM cctv_notices")->fetchColumn();
    $seen = cctvSeen();
    if (!isset($seen[$userId])) {                // admin baru / pertama kali: jangan banjiri notifikasi lama
        cctvSeen(function ($d) use ($userId, $max) { $d[$userId] = $max; return $d; });
        return ['max_id' => $max, 'items' => []];
    }
    $since = (int)$seen[$userId];
    if ($max <= $since) return ['max_id' => $max, 'items' => []];
    $st = $db->prepare("SELECT id, type, message, created_at FROM cctv_notices WHERE id > ? ORDER BY id DESC LIMIT 10");
    $st->execute([$since]);
    $items = array_reverse($st->fetchAll());
    foreach ($items as &$i) $i['created_at'] = date('d M Y H:i', strtotime((string)$i['created_at']));
    return ['max_id' => $max, 'items' => $items];
}

/* ================================================================== Email (SMTP sederhana, tanpa pustaka tambahan) */

/**
 * Kirim email HTML lewat SMTP (STARTTLS / SSL / tanpa enkripsi, AUTH LOGIN).
 * Return '' jika berhasil, atau pesan error.
 */
function cctvSmtpSend(array $s, array $to, string $subject, string $html): string
{
    $host = trim((string)$s['smtp_host']);
    $port = (int)$s['smtp_port'] ?: 587;
    $sec  = (string)$s['smtp_secure'];
    $from = trim((string)$s['smtp_from']) ?: trim((string)$s['smtp_user']);
    if ($host === '' || $from === '' || !$to) return 'Pengaturan SMTP / penerima belum lengkap';

    $remote = ($sec === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port;
    $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]]);
    $fp = @stream_socket_client($remote, $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) return 'Tidak bisa terhubung ke ' . $host . ':' . $port . ' (' . $errstr . ')';
    stream_set_timeout($fp, 20);

    $read = function () use ($fp): string {
        $out = '';
        while (($line = fgets($fp, 1024)) !== false) {
            $out .= $line;
            if (strlen($line) < 4 || $line[3] !== '-') break;
        }
        return $out;
    };
    $cmd = function (string $c, array $okCodes) use ($fp, $read): string {
        if ($c !== '') fwrite($fp, $c . "\r\n");
        $r = $read();
        if (!in_array((int)substr($r, 0, 3), $okCodes, true)) throw new RuntimeException(trim($r) ?: 'tidak ada balasan');
        return $r;
    };
    try {
        $cmd('', [220]);
        $ehloHost = gethostname() ?: 'localhost';
        $ehlo = $cmd('EHLO ' . $ehloHost, [250]);
        if ($sec === 'tls') {
            $cmd('STARTTLS', [220]);
            if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT | (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT') ? STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT : 0))) {
                throw new RuntimeException('STARTTLS gagal');
            }
            $ehlo = $cmd('EHLO ' . $ehloHost, [250]);
        }
        if (trim((string)$s['smtp_user']) !== '') {
            $cmd('AUTH LOGIN', [334]);
            $cmd(base64_encode((string)$s['smtp_user']), [334]);
            $cmd(base64_encode((string)$s['smtp_pass']), [235]);
        }
        $cmd('MAIL FROM:<' . $from . '>', [250]);
        foreach ($to as $rcpt) $cmd('RCPT TO:<' . $rcpt . '>', [250, 251]);
        $cmd('DATA', [354]);
        $fromName = trim((string)$s['smtp_from_name']) ?: 'IT System';
        $headers = [
            'Date: ' . date('r'),
            'From: =?UTF-8?B?' . base64_encode($fromName) . '?= <' . $from . '>',
            'To: ' . implode(', ', $to),
            'Subject: =?UTF-8?B?' . base64_encode($subject) . '?=',
            'Message-ID: <' . bin2hex(random_bytes(8)) . '@' . (explode('@', $from)[1] ?? 'localhost') . '>',
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            'Content-Transfer-Encoding: base64',
        ];
        $body = implode("\r\n", $headers) . "\r\n\r\n" . chunk_split(base64_encode($html), 76, "\r\n");
        $cmd($body . "\r\n.", [250]);
        @fwrite($fp, "QUIT\r\n");
        fclose($fp);
        return '';
    } catch (Throwable $e) {
        @fclose($fp);
        return 'SMTP: ' . $e->getMessage();
    }
}

function cctvEmailRecipients(array $s): array
{
    $list = preg_split('/[\s,;]+/', (string)$s['email_to'], -1, PREG_SPLIT_NO_EMPTY);
    return array_values(array_unique(array_filter($list, fn($e) => filter_var($e, FILTER_VALIDATE_EMAIL))));
}

/** Email ringkasan perubahan status hasil satu kali cek. Return '' jika terkirim, atau pesan error. */
function cctvSendStatusEmail(array $sum): string
{
    $s  = cctvSettings();
    $to = cctvEmailRecipients($s);
    if (!$to) return 'Penerima email belum diisi';
    $e  = fn($v) => htmlspecialchars((string)$v);
    $rows = '';
    foreach ($sum['down'] as $d) {
        $c = $d['cam'];
        $rows .= '<tr><td style="padding:6px 8px;border:1px solid #e2e8f0;color:#b42318;font-weight:bold">' . $e(strtoupper(cctvStateLabel($d['kind']))) . '</td>'
               . '<td style="padding:6px 8px;border:1px solid #e2e8f0">' . $e($c['number']) . '</td>'
               . '<td style="padding:6px 8px;border:1px solid #e2e8f0"><b>' . $e($c['name'] ?: '-') . '</b></td>'
               . '<td style="padding:6px 8px;border:1px solid #e2e8f0">' . $e($c['location']) . '</td>'
               . '<td style="padding:6px 8px;border:1px solid #e2e8f0">' . $e(date('d M Y H:i', strtotime($d['since']))) . '</td>'
               . '<td style="padding:6px 8px;border:1px solid #e2e8f0">' . $e($d['detail']) . (isset($d['dur']) ? '<br><b>Sudah mati ' . $e(cctvDuration((int)$d['dur'])) . '</b>' : '') . '</td></tr>';
    }
    if ($s['notify_recover']) {
        foreach ($sum['up'] as $u) {
            $c = $u['cam'];
            $rows .= '<tr><td style="padding:6px 8px;border:1px solid #e2e8f0;color:#157a4a;font-weight:bold">ONLINE KEMBALI</td>'
                   . '<td style="padding:6px 8px;border:1px solid #e2e8f0">' . $e($c['number']) . '</td>'
               . '<td style="padding:6px 8px;border:1px solid #e2e8f0"><b>' . $e($c['name'] ?: '-') . '</b></td>'
                   . '<td style="padding:6px 8px;border:1px solid #e2e8f0">' . $e($c['location']) . '</td>'
                   . '<td style="padding:6px 8px;border:1px solid #e2e8f0">' . $e(date('d M Y H:i')) . '</td>'
                   . '<td style="padding:6px 8px;border:1px solid #e2e8f0">' . (isset($u['event']['duration_sec']) ? 'Mati selama ' . $e(cctvDuration((int)$u['event']['duration_sec'])) : '') . '</td></tr>';
        }
    }
    $nDown = count($sum['down']);
    $subject = $nDown
        ? '[CCTV] ' . $nDown . ' kamera mati' . (!empty($sum['delay_min']) ? ' lebih dari ' . (int)$sum['delay_min'] . ' menit' : '') . ': ' . implode(', ', array_map(fn($d) => $d['cam']['name'] ?: ($d['cam']['location'] ?: $d['cam']['number']), array_slice($sum['down'], 0, 3))) . ($nDown > 3 ? ', ...' : '')
        : '[CCTV] ' . count($sum['up']) . ' kamera online kembali';
    $html = '<div style="font-family:Arial,sans-serif;font-size:13px;color:#1e293b">'
          . '<p style="font-size:15px;font-weight:bold;margin:0 0 6px">Laporan status CCTV</p>'
          . '<p style="margin:0 0 10px;color:#475569">Dicek otomatis oleh IT System pada ' . $e(date('d M Y H:i')) . '. '
          . 'Total saat ini: ' . (int)$sum['on'] . ' online, ' . (int)$sum['off'] . ' offline, ' . (int)$sum['vl'] . ' video loss.</p>'
          . '<table style="border-collapse:collapse;font-size:12px"><tr style="background:#eef2ff">'
          . '<th style="padding:6px 8px;border:1px solid #e2e8f0;text-align:left">Status</th><th style="padding:6px 8px;border:1px solid #e2e8f0;text-align:left">No. Aset</th>'
          . '<th style="padding:6px 8px;border:1px solid #e2e8f0;text-align:left">Nama CCTV</th><th style="padding:6px 8px;border:1px solid #e2e8f0;text-align:left">Lokasi</th><th style="padding:6px 8px;border:1px solid #e2e8f0;text-align:left">Waktu</th>'
          . '<th style="padding:6px 8px;border:1px solid #e2e8f0;text-align:left">Keterangan</th></tr>' . $rows . '</table>'
          . '<p style="margin:12px 0 0;color:#64748b;font-size:11px">Email ini dikirim otomatis. Lihat detail di menu CCTV aplikasi IT System.</p></div>';
    return cctvSmtpSend($s, $to, $subject, $html);
}

/* ================================================================== Checklist */

function cctvCheckItems(PDO $db, bool $activeOnly = true): array
{
    ensureCctvTables($db);
    $rows = $db->query("SELECT * FROM cctv_check_items ORDER BY sort_order, id")->fetchAll();
    return $activeOnly ? array_values(array_filter($rows, fn($r) => (int)$r['is_active'] === 1)) : $rows;
}

function cctvGetChecklist(PDO $db, string $date, string $shift): ?array
{
    ensureCctvTables($db);
    $st = $db->prepare("SELECT * FROM cctv_checklists WHERE check_date = ? AND shift = ?");
    $st->execute([$date, $shift]);
    $cl = $st->fetch();
    if (!$cl) return null;
    $r = $db->prepare("SELECT * FROM cctv_checklist_results WHERE checklist_id = ?");
    $r->execute([(int)$cl['id']]);
    $cl['results'] = [];
    foreach ($r->fetchAll() as $row) {
        $row['marks'] = json_decode((string)$row['results'], true) ?: [];
        $cl['results'][(int)$row['asset_id']] = $row;
    }
    $cl['nvr_info'] = [];
    $n = $db->prepare("SELECT * FROM cctv_checklist_nvr WHERE checklist_id = ?");
    $n->execute([(int)$cl['id']]);
    foreach ($n->fetchAll() as $row) $cl['nvr_info'][(int)$row['nvr_key']] = $row;
    return $cl;
}

/**
 * Kelompokkan kamera per NVR (urut nama NVR; kamera tanpa NVR paling akhir).
 * Return [nvr_key => ['key' => int, 'name' => string, 'cams' => [...]]], nvr_key 0 = tanpa NVR.
 */
function cctvNvrGroups(array $cams): array
{
    $g = [];
    foreach ($cams as $c) {
        $k = (int)($c['nvr_id'] ?? 0);
        if (!isset($g[$k])) $g[$k] = ['key' => $k, 'name' => $k ? ($c['nvr_name'] ?: 'NVR #' . $k) : cL('Tanpa NVR (IP langsung)', 'No NVR (direct IP)'), 'cams' => []];
        $g[$k]['cams'][] = $c;
    }
    uasort($g, fn($a, $b) => ($a['key'] === 0) <=> ($b['key'] === 0) ?: strnatcasecmp($a['name'], $b['name']));
    foreach ($g as &$grp) usort($grp['cams'], fn($a, $b) => ($a['channel'] ?? 999) <=> ($b['channel'] ?? 999) ?: strcmp($a['number'], $b['number']));
    unset($grp);
    return $g;
}

/** Petugas pemeriksa untuk 1 NVR di checklist (fallback: petugas checklist). */
function cctvChecklistOfficer(?array $cl, int $nvrKey): array
{
    if (!$cl) return ['name' => '', 'user_id' => 0, 'at' => null];
    $i = $cl['nvr_info'][$nvrKey] ?? null;
    return $i ? ['name' => (string)$i['user_name'], 'user_id' => (int)$i['user_id'], 'at' => $i['updated_at']]
              : ['name' => (string)$cl['user_name'], 'user_id' => (int)$cl['user_id'], 'at' => $cl['updated_at']];
}

/** Simpan foto checklist (JPG/PNG/WEBP maks 8 MB). Return path relatif atau ''. */
function cctvSavePhoto(array $file, int $assetId, string $date): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) return '';
    if ($file['size'] > 8 * 1024 * 1024) return '';
    $mime = (@getimagesize($file['tmp_name']))['mime'] ?? '';
    $ext  = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? '';
    if ($ext === '') return '';
    $sub = date('Y/m', strtotime($date));
    $dir = CCTV_PHOTO_DIR . '/' . $sub;
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return '';
    $name = 'cctv_' . $assetId . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3)) . '.' . $ext;
    return move_uploaded_file($file['tmp_name'], $dir . '/' . $name) ? $sub . '/' . $name : '';
}

/* ================================================================== Laporan */

function cctvMonthNames(): array
{
    return cL('id', 'en') === 'en'
        ? ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
        : ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
}

/** Nama hari (1 = Senin ... 7 = Minggu). */
function cctvWeekdayNames(): array
{
    return [1 => cL('Senin', 'Monday'), 2 => cL('Selasa', 'Tuesday'), 3 => cL('Rabu', 'Wednesday'), 4 => cL('Kamis', 'Thursday'),
            5 => cL('Jumat', 'Friday'), 6 => cL('Sabtu', 'Saturday'), 7 => cL('Minggu', 'Sunday')];
}

/** Libur yang diisi manual: [tanggal => nama] antara $from dan $to (Y-m-d). */
function cctvHolidayMap(PDO $db, string $from, string $to): array
{
    if (!cctvTableExists($db, 'cctv_holidays')) return [];
    $st = $db->prepare("SELECT holiday_date, name FROM cctv_holidays WHERE holiday_date BETWEEN ? AND ? ORDER BY holiday_date");
    $st->execute([$from, $to]);
    $out = [];
    foreach ($st->fetchAll() as $r) $out[substr((string)$r['holiday_date'], 0, 10)] = (string)$r['name'];
    return $out;
}

/**
 * Hari tanpa kewajiban checklist antara $from dan $to: [tanggal => keterangan].
 * Libur mingguan (default Sabtu & Minggu, CCTV > Pengaturan) + libur yang diisi manual.
 */
function cctvOffDays(PDO $db, string $from, string $to): array
{
    $week = array_flip(cctvSettings()['off_weekdays']);
    $names = cctvWeekdayNames();
    $hol = cctvHolidayMap($db, $from, $to);
    $out = [];
    for ($t = strtotime($from); $t <= strtotime($to); $t = strtotime('+1 day', $t)) {
        $d = date('Y-m-d', $t);
        if (isset($hol[$d])) $out[$d] = $hol[$d];
        elseif (isset($week[(int)date('N', $t)])) $out[$d] = $names[(int)date('N', $t)];
    }
    return $out;
}

/** Data laporan bulanan: kamera × tanggal, temuan, kepatuhan shift, log mati. $ym = 'YYYY-MM'. */
function cctvMonthReport(PDO $db, string $ym, ?int $nvrKey = null): array
{
    ensureCctvTables($db);
    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) $ym = date('Y-m');
    $start = $ym . '-01';
    $days  = (int)date('t', strtotime($start));
    $end   = $ym . '-' . str_pad((string)$days, 2, '0', STR_PAD_LEFT);
    $today = date('Y-m-d');
    $lastDay = $end < $today ? $days : ($start > $today ? 0 : (int)date('j'));

    $cams  = cctvCameras($db);
    if ($nvrKey !== null) $cams = array_values(array_filter($cams, fn($c) => (int)($c['nvr_id'] ?? 0) === $nvrKey));
    $groups = cctvNvrGroups($cams);
    $camIds = array_flip(array_column($cams, 'id'));
    $groupOf = [];
    foreach ($cams as $c) $groupOf[$c['id']] = (int)($c['nvr_id'] ?? 0);
    $items = cctvCheckItems($db, false);
    $itemLabel = [];
    foreach ($items as $it) $itemLabel[$it['code']] = $it['label'];

    $cl = $db->prepare("SELECT * FROM cctv_checklists WHERE check_date BETWEEN ? AND ? ORDER BY check_date, id");
    $cl->execute([$start, $end]);
    $lists = $cl->fetchAll();
    $byId = [];
    foreach ($lists as $l) $byId[(int)$l['id']] = $l;

    $grid = [];      // [assetId][day] => ['n' => shifts checked, 'bad' => count]
    $filledGroup = []; // 'tanggal|shift|nvr_key' => true
    $notes = [];
    $detail = [];    // baris detail untuk Excel
    if ($byId) {
        $ids = implode(',', array_map('intval', array_keys($byId)));
        foreach ($db->query("SELECT * FROM cctv_checklist_results WHERE checklist_id IN ($ids) ORDER BY checklist_id, id")->fetchAll() as $r) {
            $l = $byId[(int)$r['checklist_id']];
            $day = (int)date('j', strtotime($l['check_date']));
            $aid = (int)$r['asset_id'];
            if (!isset($camIds[$aid])) continue;                // kamera NVR lain (saat laporan difilter per NVR)
            $filledGroup[$l['check_date'] . '|' . $l['shift'] . '|' . $groupOf[$aid]] = true;
            $marks = json_decode((string)$r['results'], true) ?: [];
            $badCodes = array_keys(array_filter($marks, fn($v) => (int)$v === 2));
            $isBad = $badCodes || in_array($r['status_snapshot'], ['off', 'vl'], true);
            $grid[$aid][$day]['n'] = ($grid[$aid][$day]['n'] ?? 0) + 1;
            $grid[$aid][$day]['bad'] = ($grid[$aid][$day]['bad'] ?? 0) + ($isBad ? 1 : 0);
            $detail[] = ['date' => $l['check_date'], 'shift' => $l['shift'], 'user' => $l['user_name'], 'asset_id' => $aid,
                         'status' => (string)$r['status_snapshot'], 'marks' => $marks, 'note' => (string)$r['note'], 'photo' => (string)$r['photo']];
            if ($isBad) {
                $notes[] = ['date' => $l['check_date'], 'shift' => $l['shift'], 'asset_id' => $aid,
                            'items' => $badCodes ? implode(', ', $badCodes) : 'Status',
                            'status' => (string)$r['status_snapshot'], 'note' => (string)$r['note']];
            }
        }
    }

    // Kepatuhan: shift yang wajib vs yang terisi (sampai hari ini).
    $shifts = cctvShiftOptions();
    $due = 0; $done = 0; $missed = [];
    $multi = count($groups) > 1;
    // Hari ini: shift yang belum dimulai belum dihitung (2 shift: Sore mulai 12:00; 3 shift: 07-15, 15-23, 23-07).
    $curIdx = cctvShiftIndexNow($shifts, true);
    $offDays = cctvOffDays($db, $start, $end);
    for ($d = 1; $d <= $lastDay; $d++) {
        $date = $ym . '-' . str_pad((string)$d, 2, '0', STR_PAD_LEFT);
        foreach ($shifts as $si => $sh) {
            foreach ($groups as $gk => $grp) {
                $isFilled = isset($filledGroup[$date . '|' . $sh . '|' . $gk]);
                if ($date === $today && $si > $curIdx && !$isFilled) continue;
                if (isset($offDays[$date])) continue;                 // hari libur: tidak wajib checklist
                $due++;
                if ($isFilled) $done++; else $missed[] = date('d/m', strtotime($date)) . ' ' . $sh . ($multi ? ' (' . $grp['name'] . ')' : '');
            }
        }
    }

    // Log mati bulan ini (yang beririsan dengan bulan ini).
    $ev = $db->prepare("SELECT * FROM cctv_events WHERE started_at <= ? AND (ended_at IS NULL OR ended_at >= ?) ORDER BY started_at");
    $ev->execute([$end . ' 23:59:59', $start . ' 00:00:00']);
    $events = array_values(array_filter($ev->fetchAll(), fn($e) => isset($camIds[(int)$e['asset_id']])));
    // Hanya kamera yang mati >= batas menit (sama dengan batas email) yang masuk log & rekap; gangguan singkat diabaikan.
    $logMin = cctvLogAfterMin();
    $shortCount = 0;
    if ($logMin > 0) {
        $nowTs = time();
        $events = array_values(array_filter($events, function ($e) use ($logMin, $nowTs, &$shortCount) {
            $dur = $e['ended_at'] ? strtotime((string)$e['ended_at']) - strtotime((string)$e['started_at'])
                                  : $nowTs - strtotime((string)$e['started_at']);
            if ($dur >= $logMin * 60) return true;
            if ($e['ended_at']) $shortCount++;      // sudah hidup lagi sebelum batas -> tidak dicatat
            return false;                           // masih mati tapi belum sampai batas -> menunggu
        }));
    }
    $monthStartTs = strtotime($start . ' 00:00:00');
    $monthEndTs   = min(time(), strtotime($end . ' 23:59:59'));
    $periodSec    = max(1, $monthEndTs - $monthStartTs);
    $down = [];
    foreach ($events as &$e) {
        $s = max(strtotime((string)$e['started_at']), $monthStartTs);
        $t = $e['ended_at'] ? min(strtotime((string)$e['ended_at']), $monthEndTs) : $monthEndTs;
        $e['in_month_sec'] = max(0, $t - $s);
        $aid = (int)$e['asset_id'];
        $down[$aid]['n'] = ($down[$aid]['n'] ?? 0) + 1;
        $down[$aid]['sec'] = ($down[$aid]['sec'] ?? 0) + $e['in_month_sec'];
    }
    unset($e);

    $camById = [];
    foreach ($cams as $c) $camById[$c['id']] = $c;
    $rp = $db->prepare("SELECT * FROM cctv_reports WHERE reported_at BETWEEN ? AND ? ORDER BY reported_at");
    $rp->execute([$start . ' 00:00:00', $end . ' 23:59:59']);
    return [
        'reports' => array_values(array_filter($rp->fetchAll(), fn($r) => isset($camIds[(int)$r['asset_id']]))),
        'groups' => $groups, 'nvr_key' => $nvrKey,
        'ym' => $ym, 'start' => $start, 'end' => $end, 'days' => $days, 'last_day' => $lastDay,
        'cams' => $cams, 'cam_by_id' => $camById, 'grid' => $grid, 'notes' => $notes, 'detail' => $detail,
        'items' => $items, 'item_label' => $itemLabel, 'shifts' => $shifts,
        'due' => $due, 'done' => $done, 'missed' => $missed,
        'off' => $offDays,
        'events' => $events, 'down' => $down, 'period_sec' => $periodSec,
        'log_min' => $logMin, 'short_count' => $shortCount,
        'issues' => count($notes),
    ];
}

/** Batas menit kamera mati sebelum masuk Log CCTV mati (mengikuti pengaturan "Kirim email jika kamera mati selama"). */
function cctvLogAfterMin(): int
{
    return max(0, (int)(cctvSettings()['email_after_min'] ?? 30));
}

function cctvMonthTitle(string $ym): string
{
    $ts = strtotime($ym . '-01');
    return cctvMonthNames()[(int)date('n', $ts) - 1] . ' ' . date('Y', $ts);
}

/** Nama & jabatan penandatangan laporan. */
function cctvSigners(PDO $db): array
{
    require_once __DIR__ . '/user_position.php';
    $me = currentUser();
    $asstTitle = function_exists('t') ? t('stock_ba_sign_asst') : 'Asisten Manager GA';
    $mgrTitle  = function_exists('t') ? t('stock_ba_sign_mgr') : 'Manager HR-GA';
    return [
        ['label' => cL('Dibuat oleh', 'Prepared by'), 'name' => (string)($me['full_name'] ?? ''), 'title' => getUserPosition($db, (int)($me['id'] ?? $_SESSION['user_id'] ?? 0))],
        ['label' => cL('Mengetahui', 'Acknowledged'), 'name' => findUserNameByPosition($db, $asstTitle), 'title' => $asstTitle],
        ['label' => cL('Mengetahui', 'Acknowledged'), 'name' => findUserNameByPosition($db, $mgrTitle), 'title' => $mgrTitle],
    ];
}

/* ================================================================== Laporan petugas (CCTV mati / rusak) */

function cctvIssueLabel(string $code): string
{
    $l = CCTV_REPORT_ISSUES[$code] ?? [$code, $code];
    return cL($l[0], $l[1]);
}

/** Laporan terbuka per kamera: [asset_id => [laporan,...]]. */
function cctvOpenReports(PDO $db): array
{
    if (!cctvTableExists($db, 'cctv_reports')) return [];
    $out = [];
    foreach ($db->query("SELECT * FROM cctv_reports WHERE status = 'open' ORDER BY reported_at DESC")->fetchAll() as $r) $out[(int)$r['asset_id']][] = $r;
    return $out;
}

/** Simpan laporan petugas + pemberitahuan admin (web) + email. Return [id, emailError]. */
function cctvCreateReport(PDO $db, array $cam, string $issue, string $note, string $photo, array $user): array
{
    ensureCctvTables($db);
    $now = date('Y-m-d H:i:s');
    $db->prepare("INSERT INTO cctv_reports (asset_id, issue, note, photo, reported_by, reporter_name, reported_at, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'open')")
       ->execute([$cam['id'], $issue, $note !== '' ? $note : null, $photo !== '' ? $photo : null, (int)$user['id'], (string)$user['full_name'], $now]);
    $id = (int)$db->lastInsertId();
    $label = (CCTV_REPORT_ISSUES[$issue][0] ?? $issue);
    cctvAddNotice($db, $cam['id'], null, 'report', 'Laporan ' . $user['full_name'] . ': ' . ($cam['name'] ?: ($cam['location'] ?: $cam['number'])) . ' - ' . $label . ($note !== '' ? ' (' . mb_substr($note, 0, 80) . ')' : ''));
    $err = '';
    $s = cctvSettings();
    if ($s['notify_email']) {
        $to = cctvEmailRecipients($s);
        if ($to) {
            $e = fn($v) => htmlspecialchars((string)$v);
            $html = '<div style="font-family:Arial,sans-serif;font-size:13px;color:#1e293b">'
                  . '<p style="font-size:15px;font-weight:bold;margin:0 0 8px">Laporan CCTV dari petugas</p>'
                  . '<table style="border-collapse:collapse;font-size:12px">'
                  . '<tr><td style="padding:4px 10px 4px 0;color:#64748b">Nama CCTV</td><td style="padding:4px 0"><b>' . $e($cam['name'] ?: '-') . '</b> (' . $e($cam['number']) . ')</td></tr>'
                  . '<tr><td style="padding:4px 10px 4px 0;color:#64748b">Lokasi</td><td style="padding:4px 0">' . $e($cam['location'] ?: '-') . '</td></tr>'
                  . '<tr><td style="padding:4px 10px 4px 0;color:#64748b">Masalah</td><td style="padding:4px 0;color:#b42318;font-weight:bold">' . $e($label) . '</td></tr>'
                  . '<tr><td style="padding:4px 10px 4px 0;color:#64748b">Keterangan</td><td style="padding:4px 0">' . $e($note !== '' ? $note : '-') . '</td></tr>'
                  . '<tr><td style="padding:4px 10px 4px 0;color:#64748b">Pelapor</td><td style="padding:4px 0">' . $e($user['full_name']) . '</td></tr>'
                  . '<tr><td style="padding:4px 10px 4px 0;color:#64748b">Waktu</td><td style="padding:4px 0">' . $e(date('d M Y H:i', strtotime($now))) . '</td></tr>'
                  . '<tr><td style="padding:4px 10px 4px 0;color:#64748b">Status monitoring</td><td style="padding:4px 0">' . $e(cctvStateLabel(cctvCheckMethod($cam) === '' ? 'unknown' : $cam['state'])) . '</td></tr>'
                  . '</table>' . ($photo !== '' ? '<p style="margin:10px 0 0">Foto terlampir di aplikasi (menu CCTV &rarr; Laporan petugas).</p>' : '')
                  . '<p style="margin:12px 0 0;color:#64748b;font-size:11px">Email ini dikirim otomatis oleh IT System.</p></div>';
            $err = cctvSmtpSend($s, $to, '[CCTV] Laporan: ' . ($cam['name'] ?: ($cam['location'] ?: $cam['number'])) . ' - ' . $label, $html);
        }
    }
    return [$id, $err];
}

/**
 * Temuan checklist (item bertanda ✗) otomatis masuk ke Laporan petugas dengan status "Belum ditangani".
 * Satu laporan per kamera per checklist (tanggal + shift): bila checklist disimpan ulang, laporan yang
 * masih terbuka diperbarui, bukan dibuat dobel. $rows = [asset_id => ['marks' => [kode => 1|2], 'note' => ..]].
 * Return [dibuat, diperbarui].
 */
function cctvChecklistFindingsToReports(PDO $db, string $date, string $shift, array $rows, array $photos, array $camById, array $items, array $user): array
{
    ensureCctvTables($db);
    $label = [];
    foreach ($items as $it) $label[$it['code']] = $it['label'];
    $tag = 'Checklist ' . $shift . ' ' . date('d/m/Y', strtotime($date)) . ':';
    $find = $db->prepare("SELECT id FROM cctv_reports WHERE asset_id = ? AND status = 'open' AND note LIKE ? ORDER BY id DESC LIMIT 1");
    $upd  = $db->prepare("UPDATE cctv_reports SET issue = ?, note = ?, photo = COALESCE(?, photo), reporter_name = ? WHERE id = ?");
    $ins  = $db->prepare("INSERT INTO cctv_reports (asset_id, issue, note, photo, reported_by, reporter_name, reported_at, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'open')");
    $made = $updated = 0;
    foreach ($rows as $aid => $r) {
        $bad = array_keys(array_filter($r['marks'], fn($v) => (int)$v === 2));
        if (!$bad) continue;
        $issue = CCTV_ITEM_ISSUE[$bad[0]] ?? 'lainnya';
        // Nama masalah (mis. "Posisi / arah bergeser"), bukan label item checklist yang kalimatnya positif.
        $what = implode(', ', array_map(fn($c) => isset(CCTV_ITEM_ISSUE[$c]) ? CCTV_REPORT_ISSUES[CCTV_ITEM_ISSUE[$c]][0] : ($label[$c] ?? $c) . ' (bermasalah)', $bad));
        $note = mb_substr($tag . ' ' . $what . ($r['note'] !== '' ? ' — ' . $r['note'] : ''), 0, 250);
        $photo = ($photos[$aid] ?? '') !== '' ? $photos[$aid] : null;
        $find->execute([$aid, $tag . '%']);
        $id = (int)$find->fetchColumn();
        if ($id) { $upd->execute([$issue, $note, $photo, (string)$user['full_name'], $id]); $updated++; continue; }
        $ins->execute([$aid, $issue, $note, $photo, (int)$user['id'], (string)$user['full_name'], date('Y-m-d H:i:s')]);
        $made++;
        $cam = $camById[$aid] ?? ['name' => '', 'location' => '', 'number' => '#' . $aid];
        cctvAddNotice($db, (int)$aid, null, 'report', 'Temuan checklist ' . $user['full_name'] . ': ' . ($cam['name'] ?: ($cam['location'] ?: $cam['number'])) . ' - ' . $what . ($r['note'] !== '' ? ' (' . mb_substr($r['note'], 0, 80) . ')' : ''));
        // Untuk Chat Grup: dikirim ke grup temuan CCTV setelah checklist tersimpan (lihat cctv_checklist.php).
        $GLOBALS['cctv_chat_findings'][] = ['title' => ($cam['name'] ?: ($cam['location'] ?: $cam['number'])) . ': ' . $what . ($r['note'] !== '' ? ' — ' . mb_substr($r['note'], 0, 80) : ''),
                                            'photo_file' => $photo ? CCTV_PHOTO_DIR . '/' . $photo : ''];
    }
    return [$made, $updated];
}

/** Laporan ini dibuat otomatis dari checklist? */
function cctvIsChecklistReport(array $r): bool
{
    return strncmp((string)($r['note'] ?? ''), 'Checklist ', 10) === 0;
}

/* ================================================================== Brand & Type kamera (form Asset kategori CCTV) */

/** [asset_id => ['brand' => .., 'model' => ..]] */
function cctvInfoMap(PDO $db, array $assetIds): array
{
    $ids = array_values(array_filter(array_map('intval', $assetIds)));
    if (!$ids || !cctvTableExists($db, 'asset_cctv_info')) return [];
    $out = [];
    foreach (array_chunk($ids, 500) as $chunk) {
        $st = $db->prepare("SELECT asset_id, brand, model FROM asset_cctv_info WHERE asset_id IN (" . implode(',', array_fill(0, count($chunk), '?')) . ")");
        $st->execute($chunk);
        foreach ($st->fetchAll() as $r) $out[(int)$r['asset_id']] = ['brand' => (string)$r['brand'], 'model' => (string)$r['model']];
    }
    return $out;
}

function saveCctvInfo(PDO $db, int $assetId, string $brand, string $model): void
{
    ensureCctvTables($db);
    $db->prepare("DELETE FROM asset_cctv_info WHERE asset_id = ?")->execute([$assetId]);
    $db->prepare("INSERT INTO asset_cctv_info (asset_id, brand, model, updated_at) VALUES (?, ?, ?, ?)")
       ->execute([$assetId, mb_substr($brand, 0, 60) ?: null, mb_substr($model, 0, 80) ?: null, date('Y-m-d H:i:s')]);
}

/** Hapus data CCTV milik aset yang dihapus (brand/type, pemetaan NVR, status). */
function deleteCctvAssetData(PDO $db, array $assetIds): void
{
    $ids = array_values(array_filter(array_map('intval', $assetIds)));
    if (!$ids) return;
    $in = implode(',', array_fill(0, count($ids), '?'));
    foreach (['asset_cctv_info', 'cctv_cameras', 'cctv_status'] as $t) {
        if (cctvTableExists($db, $t)) $db->prepare("DELETE FROM $t WHERE asset_id IN ($in)")->execute($ids);
    }
}

/** Tombol kecil untuk membuka halaman web kamera (pengganti tombol VNC pada aset CCTV). */
function cctvWebButton(?string $ip): string
{
    if (!isAdmin()) return '';
    $ip = trim((string)$ip);
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return '';
    return ' <a href="http://' . $ip . '/" target="_blank" rel="noopener" title="' . htmlspecialchars(cL('Buka halaman web kamera', 'Open camera web page')) . '"'
         . ' class="inline-flex items-center gap-1 align-middle ml-1 px-1.5 py-0.5 rounded border border-sky-300 bg-sky-50 text-sky-700 hover:bg-sky-100 text-xs font-medium">'
         . icon('camera', 'w-3.5 h-3.5') . 'Web</a>';
}

/* ================================================================== Aset NVR <-> daftar NVR monitoring, aset CCTV <-> NVR/channel */

/** [asset_id => baris cctv_nvr] untuk aset kategori NVR yang sudah terhubung. */
function cctvNvrAssetMap(PDO $db, array $assetIds = []): array
{
    if (!cctvTableExists($db, 'cctv_nvr_assets')) return [];
    $rows = $db->query("SELECT l.asset_id, n.* FROM cctv_nvr_assets l JOIN cctv_nvr n ON n.id = l.nvr_id")->fetchAll();
    $want = $assetIds ? array_flip(array_map('intval', $assetIds)) : null;
    $out = [];
    foreach ($rows as $r) if ($want === null || isset($want[(int)$r['asset_id']])) $out[(int)$r['asset_id']] = $r;
    return $out;
}

/** [nvr_id => asset_id] kebalikan dari cctvNvrAssetMap. */
function cctvNvrToAsset(PDO $db): array
{
    if (!cctvTableExists($db, 'cctv_nvr_assets')) return [];
    $out = [];
    foreach ($db->query("SELECT asset_id, nvr_id FROM cctv_nvr_assets")->fetchAll() as $r) $out[(int)$r['nvr_id']] = (int)$r['asset_id'];
    return $out;
}

/**
 * Simpan aset NVR -> otomatis buat / perbarui NVR di menu CCTV (tabel cctv_nvr) dan hubungkan.
 * $d: name, ip, port, brand, username, password ('' = tidak diubah).
 */
function saveNvrFromAsset(PDO $db, int $assetId, array $d): int
{
    ensureCctvTables($db);
    $st = $db->prepare("SELECT nvr_id FROM cctv_nvr_assets WHERE asset_id = ?");
    $st->execute([$assetId]);
    $nvrId = (int)$st->fetchColumn();
    if ($nvrId) {
        $chk = $db->prepare("SELECT id FROM cctv_nvr WHERE id = ?");
        $chk->execute([$nvrId]);
        if (!$chk->fetchColumn()) $nvrId = 0;                 // NVR-nya sudah dihapus dari Pengaturan -> buat lagi
    }
    $name  = mb_substr(trim((string)$d['name']), 0, 60) ?: 'NVR';
    $ip    = trim((string)$d['ip']);
    $port  = max(1, min(65535, (int)($d['port'] ?: 80)));
    $brand = cctvBrandMethod((string)$d['brand']);
    $user  = mb_substr(trim((string)$d['username']), 0, 60);
    $pass  = (string)$d['password'];
    if ($nvrId) {
        $sql = "UPDATE cctv_nvr SET name = ?, brand = ?, ip_address = ?, port = ?, username = ?" . ($pass !== '' ? ", password = ?" : "") . " WHERE id = ?";
        $args = [$name, $brand, $ip, $port, $user];
        if ($pass !== '') $args[] = $pass;
        $args[] = $nvrId;
        $db->prepare($sql)->execute($args);
    } else {
        $db->prepare("INSERT INTO cctv_nvr (name, brand, ip_address, port, username, password, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?)")
           ->execute([$name, $brand, $ip, $port, $user, $pass, date('Y-m-d H:i:s')]);
        $nvrId = (int)$db->lastInsertId();
        $db->prepare("DELETE FROM cctv_nvr_assets WHERE asset_id = ?")->execute([$assetId]);
        $db->prepare("INSERT INTO cctv_nvr_assets (asset_id, nvr_id, updated_at) VALUES (?, ?, ?)")->execute([$assetId, $nvrId, date('Y-m-d H:i:s')]);
    }
    return $nvrId;
}

/** Aset NVR dihapus -> NVR monitoring-nya ikut dihapus dan kameranya dilepas dari NVR itu. */
function deleteNvrAssets(PDO $db, array $assetIds): void
{
    $ids = array_values(array_filter(array_map('intval', $assetIds)));
    if (!$ids || !cctvTableExists($db, 'cctv_nvr_assets')) return;
    $in = implode(',', array_fill(0, count($ids), '?'));
    $st = $db->prepare("SELECT nvr_id FROM cctv_nvr_assets WHERE asset_id IN ($in)");
    $st->execute($ids);
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $nid) {
        $db->prepare("DELETE FROM cctv_nvr WHERE id = ?")->execute([(int)$nid]);
        $db->prepare("UPDATE cctv_cameras SET nvr_id = NULL, channel = NULL WHERE nvr_id = ?")->execute([(int)$nid]);
    }
    $db->prepare("DELETE FROM cctv_nvr_assets WHERE asset_id IN ($in)")->execute($ids);
}

/** Pemetaan NVR & channel 1 kamera (dari form Asset CCTV); IP/port khusus & centang Pantau tetap. */
function saveCameraNvr(PDO $db, int $assetId, int $nvrId, int $channel): void
{
    ensureCctvTables($db);
    $st = $db->prepare("SELECT asset_id FROM cctv_cameras WHERE asset_id = ?");
    $st->execute([$assetId]);
    $nvr = $nvrId ?: null;
    $ch  = $nvrId && $channel > 0 ? $channel : null;
    if ($st->fetchColumn()) {
        $db->prepare("UPDATE cctv_cameras SET nvr_id = ?, channel = ?, updated_at = ? WHERE asset_id = ?")->execute([$nvr, $ch, date('Y-m-d H:i:s'), $assetId]);
    } else {
        $db->prepare("INSERT INTO cctv_cameras (asset_id, nvr_id, channel, monitored, updated_at) VALUES (?, ?, ?, 1, ?)")->execute([$assetId, $nvr, $ch, date('Y-m-d H:i:s')]);
    }
}

/** [asset_id => ['nvr_id' => .., 'channel' => ..]] untuk form Asset CCTV. */
function cctvCameraMap(PDO $db, array $assetIds): array
{
    $ids = array_values(array_filter(array_map('intval', $assetIds)));
    if (!$ids || !cctvTableExists($db, 'cctv_cameras')) return [];
    $out = [];
    foreach (array_chunk($ids, 500) as $chunk) {
        $st = $db->prepare("SELECT asset_id, nvr_id, channel FROM cctv_cameras WHERE asset_id IN (" . implode(',', array_fill(0, count($chunk), '?')) . ")");
        $st->execute($chunk);
        foreach ($st->fetchAll() as $r) $out[(int)$r['asset_id']] = ['nvr_id' => (int)$r['nvr_id'], 'channel' => $r['channel'] !== null ? (int)$r['channel'] : ''];
    }
    return $out;
}
