<?php
/**
 * Fitur Mutasi Aset: pencatatan pemindahan kepemilikan aset dari user lama ke user baru
 * (atau dikembalikan ke Stok IT), lengkap dengan Berita Acara.
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA:
 * - Hanya MEMBUAT 1 tabel BARU jika belum ada: asset_mutations.
 * - Tidak ALTER / DROP tabel lama. Tanpa foreign key ke tabel lama.
 * - Nama user, departement, lokasi & nomor aset disimpan sebagai salinan (snapshot),
 *   jadi riwayat tetap utuh walau user/aset nanti diubah atau dihapus.
 *
 * Mutasi dicatat dari 3 tempat:
 *   1. Menu Mutasi Aset (mutations.php -> mutation_save.php)          sumber: 'menu'
 *   2. Menu Stok Barang > Serahkan ke User (stock_asset_handover.php)   sumber: 'stock'
 *   3. Edit aset di menu Aset lalu pengguna diganti (asset_save.php)    sumber: 'asset_form'
 */

const MUTATION_REASONS    = ['rotation', 'resign', 'replacement', 'loan', 'return', 'handover', 'other'];
const MUTATION_CONDITIONS = ['good', 'minor', 'broken'];

function mutationTableExists(PDO $db): bool
{
    static $exists = null;
    if ($exists === null) {
        $exists = (bool)$db->query("SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_mutations'")->fetchColumn();
    }
    return $exists;
}

/** Buat tabel asset_mutations jika belum ada (CREATE TABLE IF NOT EXISTS — tidak menyentuh tabel lain). */
function ensureMutationTable(PDO $db): void
{
    if (mutationTableExists($db)) return;
    $db->exec("
        CREATE TABLE IF NOT EXISTS asset_mutations (
            id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            mutation_number  VARCHAR(30)  NOT NULL UNIQUE,
            mutation_date    DATE         NOT NULL,
            asset_id         INT UNSIGNED NOT NULL,
            asset_number     VARCHAR(30)  NOT NULL,
            asset_category   VARCHAR(60)  DEFAULT NULL,
            asset_name       VARCHAR(150) DEFAULT NULL,
            from_user_ids    VARCHAR(255) DEFAULT NULL,
            from_user_names  VARCHAR(500) DEFAULT NULL,
            from_department  VARCHAR(100) DEFAULT NULL,
            from_location    VARCHAR(100) DEFAULT NULL,
            to_user_ids      VARCHAR(255) DEFAULT NULL,
            to_user_names    VARCHAR(500) DEFAULT NULL,
            to_department    VARCHAR(100) DEFAULT NULL,
            to_location      VARCHAR(100) DEFAULT NULL,
            reason           VARCHAR(30)  NOT NULL DEFAULT 'other',
            asset_condition  VARCHAR(20)  NOT NULL DEFAULT 'good',
            note             TEXT         DEFAULT NULL,
            source           VARCHAR(20)  NOT NULL DEFAULT 'menu',
            created_by       INT UNSIGNED DEFAULT NULL,
            created_by_name  VARCHAR(100) DEFAULT NULL,
            created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_mut_asset (asset_id),
            INDEX idx_mut_date (mutation_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
}

/** Nomor mutasi otomatis: MUT-YYYYMM-0001 (urut per bulan tanggal mutasi). */
function nextMutationNumber(PDO $db, string $date): string
{
    $prefix = 'MUT-' . date('Ym', strtotime($date)) . '-';
    $stmt = $db->prepare("SELECT mutation_number FROM asset_mutations WHERE mutation_number LIKE ?");
    $stmt->execute([$prefix . '%']);
    $max = 0;
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $n) {
        if (preg_match('/^' . preg_quote($prefix, '/') . '(\d+)$/', $n, $m)) $max = max($max, (int)$m[1]);
    }
    return $prefix . sprintf('%04d', $max + 1);
}

/** Pengguna aset saat ini: [['id'=>, 'full_name'=>, 'department'=>], ...] urut nama. */
function mutationCurrentOwners(PDO $db, int $assetId): array
{
    if (!assetOwnersTableExists($db)) return [];
    $stmt = $db->prepare("SELECT u.id, u.full_name, u.department FROM asset_owners ao JOIN users u ON u.id = ao.user_id
                          WHERE ao.asset_id = ? ORDER BY u.full_name, u.id");
    $stmt->execute([$assetId]);
    return $stmt->fetchAll();
}

/**
 * Catat 1 mutasi. $before = data aset + pengguna SEBELUM dipindah (lihat mutationSnapshot()),
 * $after = snapshot SESUDAH dipindah. Dipanggil di dalam transaksi pemanggil.
 */
function recordAssetMutation(PDO $db, array $before, array $after, array $meta): string
{
    ensureMutationTable($db);
    $date   = $meta['date'] ?? date('Y-m-d');
    $number = nextMutationNumber($db, $date);
    $me     = function_exists('currentUser') ? currentUser() : null;
    $reason = in_array($meta['reason'] ?? '', MUTATION_REASONS, true) ? $meta['reason'] : 'other';
    $cond   = in_array($meta['condition'] ?? '', MUTATION_CONDITIONS, true) ? $meta['condition'] : 'good';
    $cut    = fn($v, $n) => ($v === null || $v === '') ? null : mb_substr((string)$v, 0, $n);

    $db->prepare("INSERT INTO asset_mutations
        (mutation_number, mutation_date, asset_id, asset_number, asset_category, asset_name,
         from_user_ids, from_user_names, from_department, from_location,
         to_user_ids, to_user_names, to_department, to_location,
         reason, asset_condition, note, source, created_by, created_by_name)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
       ->execute([
           $number, $date, $before['asset_id'], $before['asset_number'], $cut($before['category'], 60), $cut($before['asset_name'], 150),
           $cut($before['user_ids'], 255), $cut($before['user_names'], 500), $cut($before['department'], 100), $cut($before['location'], 100),
           $cut($after['user_ids'], 255), $cut($after['user_names'], 500), $cut($after['department'], 100), $cut($after['location'], 100),
           $reason, $cond, $cut(trim((string)($meta['note'] ?? '')), 2000), $meta['source'] ?? 'menu',
           $me['id'] ?? null, $cut($me['full_name'] ?? null, 100),
       ]);
    return $number;
}

/** Foto kondisi kepemilikan aset saat ini (dipakai sebelum & sesudah mutasi). */
function mutationSnapshot(PDO $db, int $assetId): ?array
{
    $stmt = $db->prepare("SELECT id, asset_number, category, device_name, department, location, status FROM assets WHERE id = ?");
    $stmt->execute([$assetId]);
    $a = $stmt->fetch();
    if (!$a) return null;
    $owners = mutationCurrentOwners($db, $assetId);
    return [
        'asset_id'     => (int)$a['id'],
        'asset_number' => $a['asset_number'],
        'category'     => $a['category'],
        'asset_name'   => $a['device_name'],
        'status'       => $a['status'],
        'department'   => $a['department'],
        'location'     => $a['location'],
        'owner_ids'    => array_map('intval', array_column($owners, 'id')),
        'user_ids'     => implode(',', array_column($owners, 'id')),
        'user_names'   => implode(', ', array_column($owners, 'full_name')),
    ];
}

/** Filter halaman Mutasi Aset (default: tahun berjalan). */
function mutationFilters(): array
{
    $isDate = fn($d) => (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $d);
    $from = trim($_GET['from'] ?? '');
    $to   = trim($_GET['to'] ?? '');
    if (!isset($_GET['from']) && !isset($_GET['to'])) {
        $from = date('Y-01-01');
        $to   = date('Y-12-31');
    }
    $reason = $_GET['reason'] ?? '';
    return [
        'from'     => $isDate($from) ? $from : '',
        'to'       => $isDate($to) ? $to : '',
        'category' => trim($_GET['category'] ?? ''),
        'reason'   => in_array($reason, MUTATION_REASONS, true) ? $reason : '',
        'q'        => trim($_GET['q'] ?? ''),
    ];
}

function mutationFilterQuery(array $f): string
{
    return http_build_query(array_filter($f, fn($v) => $v !== '' && $v !== null)) ?: 'from=&to=';
}

/** Daftar mutasi sesuai filter (terbaru di atas). */
function getMutations(PDO $db, array $f): array
{
    $w = []; $p = [];
    if ($f['from'] !== '')     { $w[] = 'm.mutation_date >= ?'; $p[] = $f['from']; }
    if ($f['to'] !== '')       { $w[] = 'm.mutation_date <= ?'; $p[] = $f['to']; }
    if ($f['category'] !== '') { $w[] = 'm.asset_category = ?'; $p[] = $f['category']; }
    if ($f['reason'] !== '')   { $w[] = 'm.reason = ?';         $p[] = $f['reason']; }
    if ($f['q'] !== '') {
        $w[] = '(m.mutation_number LIKE ? OR m.asset_number LIKE ? OR m.asset_name LIKE ? OR m.from_user_names LIKE ?
                 OR m.to_user_names LIKE ? OR m.from_department LIKE ? OR m.to_department LIKE ? OR m.note LIKE ?)';
        array_push($p, ...array_fill(0, 8, '%' . $f['q'] . '%'));
    }
    $sql = "SELECT m.* FROM asset_mutations m" . ($w ? ' WHERE ' . implode(' AND ', $w) : '') . " ORDER BY m.mutation_date DESC, m.id DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($p);
    return $stmt->fetchAll();
}

/** Riwayat mutasi 1 aset (untuk Detail Aset / PDF). */
function getAssetMutationHistory(PDO $db, int $assetId): array
{
    if (!mutationTableExists($db)) return [];
    $stmt = $db->prepare("SELECT * FROM asset_mutations WHERE asset_id = ? ORDER BY mutation_date DESC, id DESC");
    $stmt->execute([$assetId]);
    return $stmt->fetchAll();
}

function mutationReasonLabel(string $r): string    { return t('mut_reason_' . (in_array($r, MUTATION_REASONS, true) ? $r : 'other')); }
function mutationConditionLabel(string $c): string { return t('mut_cond_' . (in_array($c, MUTATION_CONDITIONS, true) ? $c : 'good')); }

/** Label pihak (user atau "Stok IT"). */
function mutationPartyLabel(?string $names): string
{
    return trim((string)$names) !== '' ? (string)$names : t('mut_party_stock');
}
