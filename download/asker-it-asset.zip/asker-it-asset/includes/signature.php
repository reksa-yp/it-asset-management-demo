<?php
/**
 * Signature Email: pengaturan yang diatur admin (logo, nama perusahaan, T1, T2, alamat).
 *
 * Disimpan di file JSON (includes/data/signature_settings.json), BUKAN di database.
 * Logo yang diunggah admin disimpan di assets/uploads/signature/.
 * Tata letak dan hiasan signature digambar oleh aplikasi; warnanya mengikuti warna logo.
 * User tidak bisa mengubah logo, nama perusahaan, T1, T2 maupun alamat.
 */

const SIGNATURE_SETTINGS_FILE = __DIR__ . '/data/signature_settings.json';
const SIGNATURE_UPLOAD_DIR    = __DIR__ . '/../assets/uploads/signature';
const SIGNATURE_UPLOAD_URL    = 'assets/uploads/signature';
const SIGNATURE_MAX_SIZE      = 3 * 1024 * 1024; // 3 MB
const SIGNATURE_TYPES         = ['image/png' => 'png', 'image/jpeg' => 'jpg'];
const SIGNATURE_DEFAULTS      = ['company' => '', 't1' => '', 't2' => '', 'addr1' => '', 'addr2' => '', 'logo' => ''];

/** Pengaturan aktif = bawaan ditimpa isi file JSON. */
function signatureSettings(): array
{
    static $cache = null;
    if ($cache === null) {
        $cache = SIGNATURE_DEFAULTS;
        if (is_file(SIGNATURE_SETTINGS_FILE)) {
            $data = json_decode((string)file_get_contents(SIGNATURE_SETTINGS_FILE), true);
            if (is_array($data)) {
                foreach (['company', 't1', 't2', 'addr1', 'addr2'] as $k) {
                    if (isset($data[$k])) $cache[$k] = trim((string)$data[$k]);
                }
                if (isset($data['logo'])) $cache['logo'] = basename((string)$data['logo']);
            }
        }
    }
    return $cache;
}

function saveSignatureSettings(array $s): bool
{
    $dir = dirname(SIGNATURE_SETTINGS_FILE);
    if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
    $cut = fn($v, int $n) => function_exists('mb_substr') ? mb_substr(trim((string)$v), 0, $n) : substr(trim((string)$v), 0, $n);
    $data = [
        'company' => $cut($s['company'] ?? '', 40),
        't1'      => $cut($s['t1'] ?? '', 30),
        't2'      => $cut($s['t2'] ?? '', 30),
        'addr1'   => $cut($s['addr1'] ?? '', 120),
        'addr2'   => $cut($s['addr2'] ?? '', 120),
        'logo'    => basename((string)($s['logo'] ?? '')),
        'updated_at' => date('Y-m-d H:i:s'),
    ];
    return file_put_contents(SIGNATURE_SETTINGS_FILE,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
}

/** URL logo signature yang diunggah admin, atau '' jika belum ada. */
function signatureLogoUrl(): string
{
    $logo = signatureSettings()['logo'];
    if ($logo === '' || !is_file(SIGNATURE_UPLOAD_DIR . '/' . $logo)) return '';
    return SIGNATURE_UPLOAD_URL . '/' . rawurlencode($logo) . '?v=' . filemtime(SIGNATURE_UPLOAD_DIR . '/' . $logo);
}

function deleteSignatureLogo(string $file): void
{
    $file = basename($file);
    if ($file !== '' && is_file(SIGNATURE_UPLOAD_DIR . '/' . $file)) { @unlink(SIGNATURE_UPLOAD_DIR . '/' . $file); }
}

/**
 * Proses unggahan logo (PNG/JPG).
 * Return ['ok' => bool, 'file' => nama file baru ('' jika tidak ada unggahan), 'error' => kunci bahasa].
 */
function handleSignatureUpload(string $field): array
{
    $f = $_FILES[$field] ?? null;
    if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return ['ok' => true, 'file' => '', 'error' => ''];
    if ($f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) return ['ok' => false, 'file' => '', 'error' => 'sig_err_upload'];
    if ($f['size'] > SIGNATURE_MAX_SIZE) return ['ok' => false, 'file' => '', 'error' => 'sig_err_size'];
    $info = @getimagesize($f['tmp_name']);
    $mime = $info['mime'] ?? '';
    if (!$info || !isset(SIGNATURE_TYPES[$mime])) return ['ok' => false, 'file' => '', 'error' => 'sig_err_type'];
    if (!is_dir(SIGNATURE_UPLOAD_DIR)) { @mkdir(SIGNATURE_UPLOAD_DIR, 0775, true); }
    $name = 'logo_' . date('Ymd_His') . '.' . SIGNATURE_TYPES[$mime]; // nama file dibuat sistem, bukan dari user
    if (!move_uploaded_file($f['tmp_name'], SIGNATURE_UPLOAD_DIR . '/' . $name)) return ['ok' => false, 'file' => '', 'error' => 'sig_err_upload'];
    return ['ok' => true, 'file' => $name, 'error' => ''];
}
