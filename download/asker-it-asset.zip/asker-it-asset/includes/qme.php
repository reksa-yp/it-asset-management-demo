<?php
/**
 * Akses tambahan QME: user biasa yang boleh mengelola aset kategori TABLET saja
 * (lihat, tambah, ubah, hapus, export/import Excel, cetak label/detail/PDF).
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA: role di tabel users tetap 'user'. Daftar user QME
 * disimpan di tabel BARU user_qme_access (tanpa ALTER, tanpa foreign key), dibuat otomatis.
 */

function qmeTableExists(PDO $db, bool $refresh = false): bool
{
    static $exists = null;
    if ($exists === null || $refresh) {
        $exists = (bool)$db->query("SELECT COUNT(*) FROM information_schema.TABLES
                                    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'user_qme_access'")->fetchColumn();
    }
    return $exists;
}

function ensureQmeTable(PDO $db): void
{
    if (qmeTableExists($db)) return;
    $db->exec("
        CREATE TABLE IF NOT EXISTS user_qme_access (
            user_id     INT UNSIGNED NOT NULL PRIMARY KEY,   -- users.id (tanpa foreign key)
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    qmeTableExists($db, true);
}

/** [user_id => true] semua user yang punya akses QME. */
function qmeUserMap(PDO $db): array
{
    if (!qmeTableExists($db)) return [];
    $out = [];
    foreach ($db->query("SELECT user_id FROM user_qme_access")->fetchAll(PDO::FETCH_COLUMN) as $id) $out[(int)$id] = true;
    return $out;
}

function setQmeAccess(PDO $db, int $userId, bool $on): void
{
    if ($userId <= 0) return;
    if ($on) ensureQmeTable($db);
    if (!qmeTableExists($db)) return;
    $db->prepare("DELETE FROM user_qme_access WHERE user_id = ?")->execute([$userId]);
    if ($on) $db->prepare("INSERT INTO user_qme_access (user_id) VALUES (?)")->execute([$userId]);
}

/** User yang sedang login punya akses QME (dan bukan admin)? */
function isQmeUser(): bool
{
    static $cache = null;
    if ($cache !== null) return $cache;
    if (empty($_SESSION['user_id']) || isAdmin()) return $cache = false;
    try {
        $db = getDB();
        if (!qmeTableExists($db)) return $cache = false;
        $st = $db->prepare("SELECT 1 FROM user_qme_access WHERE user_id = ?");
        $st->execute([(int)$_SESSION['user_id']]);
        return $cache = (bool)$st->fetchColumn();
    } catch (Throwable $e) {
        return $cache = false;
    }
}

/** Halaman untuk admin ATAU user QME. */
function requireAdminOrQme(): void
{
    requireLogin();
    if (isAdmin() || isQmeUser()) return;
    requireAdmin();   // tampilkan pesan 403 yang sama
}

/** Kategori tablet yang terdaftar (untuk user QME). */
function qmeTabletCategories(PDO $db): array
{
    require_once __DIR__ . '/categories.php';
    $cats = array_values(array_filter(array_column(getAssetCategories($db), 'name'), 'isTabletCategory'));
    return $cats ?: ['Tablet'];
}

function qmeDeny(string $message = ''): void
{
    http_response_code(403);
    die('<div style="font-family:sans-serif;padding:40px;text-align:center">
            <h2>403 - ' . htmlspecialchars(t('qme_denied_title')) . '</h2>
            <p>' . htmlspecialchars($message !== '' ? $message : t('qme_denied_text')) . '</p>
            <a href="assets.php">' . htmlspecialchars(t('qme_back')) . '</a>
         </div>');
}

/** User QME: semua aset ini harus kategori Tablet. Admin: selalu lolos. */
function qmeAssertTabletAssets(PDO $db, array $assetIds): void
{
    if (isAdmin()) return;
    $assetIds = array_values(array_filter(array_map('intval', $assetIds)));
    if (!$assetIds) return;
    $st = $db->prepare("SELECT asset_number, category FROM assets WHERE id IN (" . implode(',', array_fill(0, count($assetIds), '?')) . ")");
    $st->execute($assetIds);
    foreach ($st->fetchAll() as $r) {
        if (!isTabletCategory($r['category'])) qmeDeny(t('qme_denied_asset', $r['asset_number'], $r['category']));
    }
}
