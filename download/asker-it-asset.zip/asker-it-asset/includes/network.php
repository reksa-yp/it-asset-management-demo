<?php
/**
 * Menu Jaringan: cek manual aset ber-IP (ping + port TCP cadangan), topologi dari kolom "Terhubung ke",
 * dan scan subnet untuk menemukan perangkat yang belum terdaftar.
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA: hanya membuat tabel BARU (CREATE TABLE IF NOT EXISTS), tidak ada ALTER.
 *   net_links   : aset -> terhubung ke aset mana (switch/router) + port
 *   net_status  : hasil cek terakhir per aset
 *   net_checks  : riwayat setiap kali "Cek sekarang" dijalankan
 *   net_device_info : jumlah port perangkat jaringan (form & import Perangkat Jaringan)
 *   net_device_ips  : semua IP / segmen perangkat jaringan (router dengan banyak segmen), kolom IP aset = IP utama
 *   net_links_extra : koneksi tambahan antarperangkat jaringan (jalur cadangan / perangkat dengan 2 uplink), port di kedua sisi
 *   net_link_ports  : port di sisi aset itu sendiri untuk koneksi utama (net_links.port = port di perangkat atasnya)
 *   net_port_cfg    : jumlah port SFP perangkat (jumlah port RJ45/LAN ada di net_device_info)
 *   net_link_log    : riwayat perubahan koneksi (siapa, kapan, apa) + data untuk "Batalkan perubahan terakhir"
 *   net_topo_pos    : posisi bebas kotak di topologi (mode "Geser bebas"); -1 = Internet, -2 = Belum dihubungkan; kosong = otomatis
 * Pengaturan disimpan di includes/data/net_settings.json, hasil scan di includes/data/net_scan_*.json.
 * Pengecekan HANYA berjalan saat tombol ditekan (tidak ada jadwal otomatis).
 */

const NET_SETTINGS_FILE = __DIR__ . '/data/net_settings.json';

/** Teks dua bahasa. */
function nL(string $id, string $en): string
{
    return function_exists('currentLang') && currentLang() === 'en' ? $en : $id;
}

function ensureNetTables(PDO $db): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    $sqls = [
        "CREATE TABLE IF NOT EXISTS net_links (
            asset_id        INT UNSIGNED NOT NULL PRIMARY KEY,
            parent_asset_id INT UNSIGNED DEFAULT NULL,
            port            VARCHAR(30)  DEFAULT NULL,
            updated_at      DATETIME     DEFAULT NULL,
            KEY idx_parent (parent_asset_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS net_status (
            asset_id   INT UNSIGNED NOT NULL PRIMARY KEY,
            state      VARCHAR(10)  NOT NULL DEFAULT 'na',
            ms         INT          DEFAULT NULL,
            loss       TINYINT      DEFAULT NULL,
            method     VARCHAR(20)  DEFAULT NULL,
            detail     VARCHAR(250) DEFAULT NULL,
            checked_at DATETIME     DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS net_checks (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            checked_at  DATETIME     NOT NULL,
            total       INT          NOT NULL DEFAULT 0,
            ok          INT          NOT NULL DEFAULT 0,
            warn        INT          NOT NULL DEFAULT 0,
            err         INT          NOT NULL DEFAULT 0,
            user_name   VARCHAR(100) DEFAULT NULL,
            summary     TEXT         DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS net_device_info (
            asset_id   INT UNSIGNED NOT NULL PRIMARY KEY,
            ports      SMALLINT     DEFAULT NULL,
            updated_at DATETIME     DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS net_device_ips (
            asset_id   INT UNSIGNED NOT NULL,
            sort       SMALLINT     NOT NULL DEFAULT 0,
            ip         VARCHAR(45)  NOT NULL,
            prefix     TINYINT      DEFAULT NULL,
            PRIMARY KEY (asset_id, sort),
            KEY idx_ip (ip)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS net_links_extra (
            id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            asset_id   INT UNSIGNED NOT NULL,
            other_id   INT UNSIGNED NOT NULL,
            port_a     VARCHAR(30)  DEFAULT NULL,
            port_b     VARCHAR(30)  DEFAULT NULL,
            created_at DATETIME     DEFAULT NULL,
            KEY idx_asset (asset_id),
            KEY idx_other (other_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS net_link_ports (
            asset_id   INT UNSIGNED NOT NULL PRIMARY KEY,
            own_port   VARCHAR(30)  DEFAULT NULL,
            updated_at DATETIME     DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS net_port_cfg (
            asset_id   INT UNSIGNED NOT NULL PRIMARY KEY,
            sfp        SMALLINT     DEFAULT NULL,
            updated_at DATETIME     DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS net_link_log (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            created_at  DATETIME     NOT NULL,
            user_name   VARCHAR(100) DEFAULT NULL,
            action      VARCHAR(20)  NOT NULL,
            detail      VARCHAR(255) DEFAULT NULL,
            undo_data   TEXT,
            undone      TINYINT(1)   NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS net_topo_pos (
            asset_id   INT          NOT NULL PRIMARY KEY,
            x          INT          NOT NULL DEFAULT 0,
            y          INT          NOT NULL DEFAULT 0,
            updated_at DATETIME     DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    ];
    foreach ($sqls as $q) {
        try { $db->exec($q); } catch (Throwable $e) { /* abaikan: tabel sudah ada / dialek lain */ }
    }
}

function netSettingsDefaults(): array
{
    return [
        'warn_ms'    => 100,          // ping rata-rata >= ini = Lambat
        'warn_loss'  => 5,            // paket hilang (%) >= ini = Lambat
        'ping_count' => 4,            // jumlah paket ping per aset
        'subnets'    => [],           // daftar subnet untuk scan, mis. "192.168.1.0/24"
    ];
}

function netSettings(): array
{
    $s = netSettingsDefaults();
    if (is_file(NET_SETTINGS_FILE)) {
        $d = json_decode((string)@file_get_contents(NET_SETTINGS_FILE), true);
        if (is_array($d)) foreach ($s as $k => $v) if (array_key_exists($k, $d)) $s[$k] = is_array($v) ? (array)$d[$k] : (int)$d[$k];
    }
    $s['ping_count'] = in_array($s['ping_count'], [1, 2, 4], true) ? $s['ping_count'] : 4;
    return $s;
}

function saveNetSettings(array $changes): bool
{
    $s = array_merge(netSettings(), $changes);
    if (!is_dir(dirname(NET_SETTINGS_FILE))) @mkdir(dirname(NET_SETTINGS_FILE), 0775, true);
    return @file_put_contents(NET_SETTINGS_FILE, json_encode($s, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
}

/** Pola nama kategori perangkat jaringan: switch, hub, router, access point, firewall, gateway. */
const NET_DEVICE_PATTERN = '/switch|router|\\bhub\\b|firewall|gateway|mikrotik|access ?point|\\bap\\b|wi-?fi|wireless/i';

/** Kategori aset = perangkat jaringan (form & import khusus "Perangkat Jaringan"). */
function isNetDeviceCategory(?string $category): bool
{
    if ($category === null || $category === '') return false;
    if (preg_match('/cctv|kamera|camera|\\b(nvr|dvr|xvr)\\b|tablet|telepon|phone|printer/i', $category)) return false;
    return (bool)preg_match(NET_DEVICE_PATTERN, $category);
}

/** Jenis aset yang bisa menjadi "induk" koneksi (switch, router, hub, access point, firewall). */
function netIsNetworkDevice(string $category, string $name = ''): bool
{
    return isNetDeviceCategory($category) || (bool)preg_match('/switch|router|mikrotik/i', $name);
}

/** [asset_id => jumlah port] */
function netDeviceInfoMap(PDO $db, array $assetIds): array
{
    ensureNetTables($db);
    $map = [];
    $assetIds = array_values(array_unique(array_filter(array_map('intval', $assetIds))));
    foreach (array_chunk($assetIds, 500) as $chunk) {
        $st = $db->prepare("SELECT asset_id, ports FROM net_device_info WHERE asset_id IN (" . implode(',', array_fill(0, count($chunk), '?')) . ")");
        $st->execute($chunk);
        foreach ($st->fetchAll() as $r) $map[(int)$r['asset_id']] = $r['ports'] !== null ? (int)$r['ports'] : null;
    }
    return $map;
}

function netSaveDeviceInfo(PDO $db, int $assetId, ?int $ports): void
{
    ensureNetTables($db);
    $db->prepare("DELETE FROM net_device_info WHERE asset_id = ?")->execute([$assetId]);
    if ($ports !== null && $ports > 0) {
        $db->prepare("INSERT INTO net_device_info (asset_id, ports, updated_at) VALUES (?, ?, ?)")->execute([$assetId, min($ports, 9999), date('Y-m-d H:i:s')]);
    }
}

/**
 * Baca daftar IP: "192.168.1.1/24, 192.168.10.1; 10.10.10.1" (pemisah koma, titik koma, spasi, baris baru).
 * Return ['items' => [['ip' => .., 'prefix' => int|null], ...], 'bad' => [teks yang bukan IP]].
 */
function netParseIpList(string $raw): array
{
    $items = []; $bad = []; $seen = [];
    foreach (preg_split('/[\s,;|]+/', trim($raw), -1, PREG_SPLIT_NO_EMPTY) as $tok) {
        if (!preg_match('#^(\d{1,3}(?:\.\d{1,3}){3})(?:/(\d{1,2}))?$#', $tok, $m) || !filter_var($m[1], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
            || (isset($m[2]) && $m[2] !== '' && ((int)$m[2] < 1 || (int)$m[2] > 32))) { $bad[] = $tok; continue; }
        if (isset($seen[$m[1]])) continue;
        $seen[$m[1]] = true;
        $items[] = ['ip' => $m[1], 'prefix' => isset($m[2]) && $m[2] !== '' ? (int)$m[2] : null];
    }
    return ['items' => $items, 'bad' => $bad];
}

/** Teks daftar IP untuk ditampilkan / ditulis ke Excel: "192.168.1.1/24, 10.10.10.1". */
function netIpListText(array $items): string
{
    return implode(', ', array_map(fn($i) => $i['ip'] . ($i['prefix'] !== null ? '/' . $i['prefix'] : ''), $items));
}

/**
 * IP utama (disimpan di kolom IP aset & dipakai untuk ping): IP di segmen yang sama dengan server,
 * lalu IP lokal (192.168/10/172.16-31) yang bukan alamat jaringan, lalu IP pertama.
 */
function netPickMainIp(array $items): string
{
    if (!$items) return '';
    $server = (string)($_SERVER['SERVER_ADDR'] ?? '');
    $srv24 = preg_match('/^(\d+\.\d+\.\d+)\./', $server, $m) ? $m[1] . '.' : '';
    $host = fn($i) => !preg_match('/\.(0|255)$/', $i['ip']);
    foreach ($items as $i) if ($srv24 !== '' && strpos($i['ip'], $srv24) === 0 && $host($i)) return $i['ip'];
    foreach ($items as $i) if ($host($i) && preg_match('/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/', $i['ip'])) return $i['ip'];
    foreach ($items as $i) if ($host($i)) return $i['ip'];
    return $items[0]['ip'];
}

/** [asset_id => [['ip','prefix'], ...]] */
function netDeviceIpsMap(PDO $db, array $assetIds): array
{
    ensureNetTables($db);
    $map = [];
    $assetIds = array_values(array_unique(array_filter(array_map('intval', $assetIds))));
    foreach (array_chunk($assetIds, 500) as $chunk) {
        $st = $db->prepare("SELECT asset_id, ip, prefix FROM net_device_ips WHERE asset_id IN (" . implode(',', array_fill(0, count($chunk), '?')) . ") ORDER BY asset_id, sort");
        $st->execute($chunk);
        foreach ($st->fetchAll() as $r) $map[(int)$r['asset_id']][] = ['ip' => (string)$r['ip'], 'prefix' => $r['prefix'] !== null ? (int)$r['prefix'] : null];
    }
    return $map;
}

/** Simpan semua IP / segmen perangkat (urutan dipertahankan). Kosong = hapus. */
function netSaveDeviceIps(PDO $db, int $assetId, array $items): void
{
    ensureNetTables($db);
    $db->prepare("DELETE FROM net_device_ips WHERE asset_id = ?")->execute([$assetId]);
    if (count($items) < 2 && !array_filter($items, fn($i) => $i['prefix'] !== null)) return;   // 1 IP polos cukup di kolom IP aset
    $ins = $db->prepare("INSERT INTO net_device_ips (asset_id, sort, ip, prefix) VALUES (?, ?, ?, ?)");
    foreach (array_values($items) as $n => $i) $ins->execute([$assetId, $n, $i['ip'], $i['prefix']]);
}

/* ------------------------------------------------------------------ Koneksi tambahan */

/**
 * Media converter LAN <-> Fiber Optik (mis. "Main Switch FO", "Switch FO", "Converter FO"):
 * hanya meneruskan sinyal, jadi boleh punya banyak koneksi, termasuk port yang sama dipakai bersama.
 * Dikenali dari nama / jenis aset yang mengandung FO, fiber, optik/optic, atau converter/konverter.
 */
function netIsMultiDevice(array $node): bool
{
    return (bool)preg_match('/\bFO\b|fib(er|re)|opti[ck]|[ck]onverter/i', ($node['name'] ?? '') . ' ' . ($node['type'] ?? ''));
}

/** Semua koneksi tambahan: [['id','a','b','port'], ...] (a = perangkat pemilik baris, b = perangkat tujuan). */
function netExtraLinks(PDO $db): array
{
    ensureNetTables($db);
    try {
        return array_map(fn($r) => ['id' => (int)$r['id'], 'a' => (int)$r['asset_id'], 'b' => (int)$r['other_id'],
                                    'port_a' => (string)($r['port_a'] ?? ''), 'port_b' => (string)($r['port_b'] ?? '')],
            $db->query("SELECT id, asset_id, other_id, port_a, port_b FROM net_links_extra ORDER BY id")->fetchAll());
    } catch (Throwable $e) { return []; }
}

/**
 * Tambah koneksi tambahan antara 2 perangkat jaringan. Return '' bila berhasil, atau pesan alasan ditolak.
 * Ditolak bila: perangkat sama, salah satu bukan perangkat jaringan, sudah jadi "Terhubung ke" utama, atau sudah ada.
 */
function netAddExtraLink(PDO $db, int $a, int $b, string $portA, string $portB = ''): string
{
    $all = netAssets($db);
    if ($a === $b) return nL('Perangkat tidak bisa terhubung ke dirinya sendiri', 'A device cannot link to itself');
    // Salah satu sisi boleh aset apa saja (NVR, server, PC dengan 2 LAN), sisi lainnya harus switch / router / AP / firewall.
    if (!isset($all[$a], $all[$b])) return nL('Perangkat tidak ditemukan', 'Device not found');
    if (!$all[$a]['is_net'] && !$all[$b]['is_net']) return nL('Salah satu sisi harus switch / router / AP / firewall', 'One side must be a network device');
    // Kabel kedua ke perangkat yang sama dengan jalur utama boleh, asal port-nya berbeda dari jalur utama.
    $cmpA = mb_strtolower(netEthName(trim($portA))); $cmpB = mb_strtolower(netEthName(trim($portB)));
    $multi = netIsMultiDevice($all[$a]) || netIsMultiDevice($all[$b]);
    if (!$multi && $all[$a]['parent'] === $b && $cmpA === mb_strtolower($all[$a]['own_port']) && $cmpB === mb_strtolower($all[$a]['port'])) return nL('Sama dengan koneksi utama ("Terhubung ke") — isi port yang berbeda', 'Same as the main link — use different ports');
    if (!$multi && $all[$b]['parent'] === $a && $cmpB === mb_strtolower($all[$b]['own_port']) && $cmpA === mb_strtolower($all[$b]['port'])) return nL('Sama dengan koneksi utama ("Terhubung ke") — isi port yang berbeda', 'Same as the main link — use different ports');
    // Antar 2 perangkat boleh lebih dari 1 kabel (mis. sfp1 & sfp2 ke switch yang sama). Yang ditolak hanya
    // koneksi yang perangkat DAN port-nya sama persis dengan yang sudah ada.
    $pa = mb_strtolower(netEthName(trim($portA))); $pb = mb_strtolower(netEthName(trim($portB)));
    if (netIsMultiDevice($all[$a]) || netIsMultiDevice($all[$b])) $pa = $pb = null;   // switch FO / converter: tanpa cek dobel
    if ($pa !== null) foreach (netExtraLinks($db) as $l) {
        $same = ($l['a'] === $a && $l['b'] === $b && mb_strtolower($l['port_a']) === $pa && mb_strtolower($l['port_b']) === $pb)
             || ($l['a'] === $b && $l['b'] === $a && mb_strtolower($l['port_a']) === $pb && mb_strtolower($l['port_b']) === $pa);
        if ($same) return nL('Koneksi ini sudah ada (perangkat & port sama)', 'This link already exists (same devices & ports)');
    }
    $cut = fn(string $p) => trim($p) !== '' ? mb_substr(netEthName(trim($p)), 0, 30) : null;
    $db->prepare("INSERT INTO net_links_extra (asset_id, other_id, port_a, port_b, created_at) VALUES (?, ?, ?, ?, ?)")
       ->execute([$a, $b, $cut($portA), $cut($portB), date('Y-m-d H:i:s')]);
    return '';
}

function netDeleteExtraLink(PDO $db, int $id): void
{
    ensureNetTables($db);
    $db->prepare("DELETE FROM net_links_extra WHERE id = ?")->execute([$id]);
}

/** Hapus semua koneksi tambahan yang melibatkan perangkat ini. */
function netClearExtraLinks(PDO $db, int $assetId): void
{
    ensureNetTables($db);
    $db->prepare("DELETE FROM net_links_extra WHERE asset_id = ? OR other_id = ?")->execute([$assetId, $assetId]);
}

/** Teks koneksi tambahan 1 perangkat: "Firewall (1 ⇄ eth1); Router ISP". */
function netExtraText(array $all, array $extras, int $id): string
{
    $out = [];
    foreach ($extras as $l) {
        if ($l['a'] !== $id && $l['b'] !== $id) continue;
        $mine = $l['a'] === $id;
        $o = $all[$mine ? $l['b'] : $l['a']] ?? null;
        $lbl = netPortLabel($mine ? $l['port_b'] : $l['port_a'], $mine ? $l['port_a'] : $l['port_b']);
        if ($o) $out[] = $o['name'] . ($lbl !== '' ? ' (' . $lbl . ')' : '');
    }
    return implode('; ', $out);
}

/* ------------------------------------------------------------------ Port */

/** Label sambungan: "eth8 ⇄ eth16" (port di perangkat atas ⇄ port di perangkat ini). */
function netPortLabel(string $upPort, string $ownPort): string
{
    $upPort = trim($upPort); $ownPort = trim($ownPort);
    if ($upPort !== '' && $ownPort !== '') return $upPort . ' ⇄ ' . $ownPort;
    return $upPort !== '' ? $upPort : ($ownPort !== '' ? '⇄ ' . $ownPort : '');
}

/**
 * Nama-nama port sebuah perangkat untuk pilihan (datalist): "eth1.." untuk semua perangkat,
 * ditambah "sfp1.." sesuai jumlah port SFP. Tetap boleh diketik manual.
 */
function netPortNames(array $node): array
{
    $n = (int)($node['ports'] ?? 0); $sfp = (int)($node['sfp'] ?? 0);
    $pre = 'eth';   // semua router / switch / hub / AP memakai nama eth1, eth2, ... (seragam)
    $out = [];
    for ($i = 1; $i <= min($n, 128); $i++) $out[] = $pre . $i;
    for ($i = 1; $i <= min($sfp, 16); $i++) $out[] = 'sfp' . $i;
    return $out;
}

/** Port yang sudah dipakai: [device_id => [nama port (huruf kecil) => "tersambung ke X"]]. */
function netUsedPorts(array $all, array $extras): array
{
    $used = [];
    $put = function (int $dev, string $port, string $to) use (&$used) {
        foreach (preg_split('/\s*[,\/;]\s*/', trim($port)) as $pp) if ($pp !== '') $used[$dev][mb_strtolower(netEthName($pp))] = $to;
    };
    foreach ($all as $a) {
        if (!$a['parent'] || !isset($all[$a['parent']])) continue;
        $put($a['parent'], $a['port'], $a['name']);
        $put($a['id'], $a['own_port'] ?? '', $all[$a['parent']]['name']);
    }
    foreach ($extras as $l) {
        if (!isset($all[$l['a']], $all[$l['b']])) continue;
        $put($l['a'], $l['port_a'], $all[$l['b']]['name']);
        $put($l['b'], $l['port_b'], $all[$l['a']]['name']);
    }
    return $used;
}

/** Simpan jumlah port SFP (null / 0 = hapus). */
function netSaveSfp(PDO $db, int $assetId, ?int $sfp): void
{
    ensureNetTables($db);
    $db->prepare("DELETE FROM net_port_cfg WHERE asset_id = ?")->execute([$assetId]);
    if ($sfp) $db->prepare("INSERT INTO net_port_cfg (asset_id, sfp, updated_at) VALUES (?, ?, ?)")->execute([$assetId, min($sfp, 64), date('Y-m-d H:i:s')]);
}

/** Simpan port di sisi aset ini untuk koneksi utama. */
function netSaveOwnPort(PDO $db, int $assetId, string $port): void
{
    ensureNetTables($db);
    $db->prepare("DELETE FROM net_link_ports WHERE asset_id = ?")->execute([$assetId]);
    $port = netEthName(trim($port));
    if ($port !== '') $db->prepare("INSERT INTO net_link_ports (asset_id, own_port, updated_at) VALUES (?, ?, ?)")->execute([$assetId, mb_substr($port, 0, 30), date('Y-m-d H:i:s')]);
}

/** Ubah satu nama port lama "ether8" / "port8" / "Port 8" / "8" menjadi "eth8". Nama lain (sfp1, wan, dll.) tidak diubah. */
function netEthName(string $p): string
{
    if (preg_match('/[,\/;]/', $p)) {   // beberapa port sekaligus (mis. LACP / 2 kabel): "port3, port4" -> "eth3, eth4"
        return implode(', ', array_map('netEthName', array_values(array_filter(array_map('trim', preg_split('/\s*[,\/;]\s*/', $p)), 'strlen'))));
    }
    return preg_match('/^\s*(?:ether|port|eth)?\s*(\d+)\s*$/i', $p, $m) ? 'eth' . (int)$m[1] : $p;
}

/** Jumlah / jalankan penyeragaman nama port lama menjadi eth. $apply=false hanya menghitung. */
function netNormalizePortNames(PDO $db, bool $apply): int
{
    ensureNetTables($db);
    $n = 0;
    $conv = function (string $v) {
        if (strpos($v, '⇄') !== false) { [$a, $b] = netSplitPortText($v); return netEthName($a) . ' ⇄ ' . netEthName($b); }
        return netEthName($v);
    };
    foreach ([['net_links', 'asset_id', ['port']], ['net_link_ports', 'asset_id', ['own_port']], ['net_links_extra', 'id', ['port_a', 'port_b']]] as [$tbl, $key, $cols]) {
        try { $rows = $db->query("SELECT $key AS k, " . implode(', ', $cols) . " FROM $tbl")->fetchAll(); } catch (Throwable $e) { continue; }
        foreach ($rows as $r) {
            foreach ($cols as $c) {
                $old = (string)($r[$c] ?? ''); if ($old === '') continue;
                $new = $conv($old);
                if ($new !== $old) { $n++; if ($apply) $db->prepare("UPDATE $tbl SET $c = ? WHERE $key = ?")->execute([$new, $r['k']]); }
            }
        }
    }
    return $n;
}

/** Pecah teks lama "16 ⇄ eth8" / "16 - eth8" / "16 > eth8" menjadi [port atas, port sendiri]. */
function netSplitPortText(string $t): array
{
    $parts = preg_split('/\s*(?:⇄|<->|<=>|->|=>|>|\s-\s)\s*/u', trim($t), 2);
    return count($parts) === 2 ? [trim($parts[0]), trim($parts[1])] : [trim($t), ''];
}

/** Data koneksi 1 aset: ['parent' => id|null, 'port' => '']. */
function netLinkOf(PDO $db, int $assetId): array
{
    ensureNetTables($db);
    $st = $db->prepare("SELECT parent_asset_id, port FROM net_links WHERE asset_id = ?");
    $st->execute([$assetId]);
    $r = $st->fetch();
    return ['parent' => $r && $r['parent_asset_id'] ? (int)$r['parent_asset_id'] : null, 'port' => (string)($r['port'] ?? '')];
}

/** Tombol "Web" untuk membuka halaman pengaturan perangkat (printer, switch managed, router, AP) di tab baru. */
function netWebButton(?string $ip): string
{
    if (!function_exists('isAdmin') || !isAdmin()) return '';
    $ip = netFirstIp($ip);
    if ($ip === '') return '';
    return ' <a href="http://' . $ip . '/" target="_blank" rel="noopener" title="' . htmlspecialchars(nL('Buka halaman web perangkat', 'Open device web page')) . '"'
         . ' class="inline-flex items-center gap-1 align-middle ml-1 px-1.5 py-0.5 rounded border border-sky-300 bg-sky-50 text-sky-700 hover:bg-sky-100 text-xs font-medium">'
         . icon('globe', 'w-3.5 h-3.5') . 'Web</a>';
}

/** IPv4 pertama yang valid dari kolom IP aset (kolom bisa berisi beberapa IP / teks). */
function netFirstIp(?string $raw): string
{
    return preg_match('/\b(\d{1,3}(?:\.\d{1,3}){3})\b/', (string)$raw, $m) && filter_var($m[1], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ? $m[1] : '';
}

/**
 * Semua aset yang ikut menu Jaringan: aset ber-IP + perangkat jaringan (switch/router) walau tanpa IP.
 * Return [id => [...]] lengkap dengan induk, port, dan hasil cek terakhir.
 */
function netAssets(PDO $db): array
{
    ensureNetTables($db);
    $links = [];
    foreach ($db->query("SELECT * FROM net_links")->fetchAll() as $r) $links[(int)$r['asset_id']] = $r;
    $stat = [];
    foreach ($db->query("SELECT * FROM net_status")->fetchAll() as $r) $stat[(int)$r['asset_id']] = $r;
    $ipsAll = [];
    try { foreach ($db->query("SELECT asset_id, ip, prefix FROM net_device_ips ORDER BY asset_id, sort")->fetchAll() as $r) $ipsAll[(int)$r['asset_id']][] = $r['ip'] . ($r['prefix'] !== null ? '/' . $r['prefix'] : ''); } catch (Throwable $e) {}
    $own = $portsN = $sfpN = [];
    try { foreach ($db->query("SELECT asset_id, own_port FROM net_link_ports")->fetchAll() as $r) $own[(int)$r['asset_id']] = (string)$r['own_port']; } catch (Throwable $e) {}
    try { foreach ($db->query("SELECT asset_id, ports FROM net_device_info")->fetchAll() as $r) $portsN[(int)$r['asset_id']] = (int)$r['ports']; } catch (Throwable $e) {}
    try { foreach ($db->query("SELECT asset_id, sfp FROM net_port_cfg")->fetchAll() as $r) $sfpN[(int)$r['asset_id']] = (int)$r['sfp']; } catch (Throwable $e) {}
    $out = [];
    foreach ($db->query("SELECT id, asset_number, category, device_name, location, ip_address, status, motherboard_brand FROM assets ORDER BY asset_number")->fetchAll() as $a) {
        $id  = (int)$a['id'];
        $ip  = netFirstIp($a['ip_address'] ?? '');
        $net = netIsNetworkDevice((string)$a['category'], (string)$a['device_name']);
        if ($ip === '' && !$net) continue;
        $l = $links[$id] ?? null; $s = $stat[$id] ?? null;
        $out[$id] = [
            'id' => $id, 'number' => (string)$a['asset_number'], 'type' => (string)$a['category'],
            'name' => (string)($a['device_name'] ?: $a['asset_number']), 'loc' => (string)($a['location'] ?? ''),
            'ip' => $ip, 'is_net' => $net, 'asset_status' => (string)($a['status'] ?? ''),
            'parent' => $l && $l['parent_asset_id'] ? (int)$l['parent_asset_id'] : null, 'port' => (string)($l['port'] ?? ''),
            'state' => $s['state'] ?? null, 'ms' => isset($s['ms']) ? (int)$s['ms'] : null, 'loss' => isset($s['loss']) ? (int)$s['loss'] : null,
            'method' => (string)($s['method'] ?? ''), 'detail' => (string)($s['detail'] ?? ''), 'checked_at' => $s['checked_at'] ?? null,
            'ips' => $ipsAll[$id] ?? [],
            'own_port' => $own[$id] ?? '', 'ports' => $portsN[$id] ?? 0, 'sfp' => $sfpN[$id] ?? 0, 'brand' => (string)($a['motherboard_brand'] ?? ''),
        ];
    }
    // Induk yang tidak lagi ada / tidak ikut daftar -> dianggap belum dihubungkan.
    foreach ($out as &$a) if ($a['parent'] !== null && !isset($out[$a['parent']])) $a['parent'] = null;
    unset($a);
    return $out;
}

/** Port TCP cadangan bila ping diblokir firewall (Windows memblokir ping secara bawaan). */
function netTcpPorts(string $type): array
{
    $t = strtolower($type);
    if (preg_match('/printer/', $t)) return [9100, 80, 631, 443];
    if (preg_match('/pc|laptop|desktop|komputer|server/', $t)) return [445, 3389, 135, 80];
    if (preg_match('/cctv|nvr|dvr|kamera|camera/', $t)) return [80, 554, 8000, 443];
    if (preg_match('/telepon|phone|pabx/', $t)) return [80, 5060, 443];
    return [80, 443, 22, 23, 8080];
}

/** Lokasi program ping. */
function netPingBin(): string
{
    foreach (['C:\\Windows\\System32\\PING.EXE', 'C:\\Windows\\Sysnative\\PING.EXE', '/bin/ping', '/usr/bin/ping', '/sbin/ping'] as $p) if (@is_file($p)) return $p;
    return 'ping';
}

/** Argumen ping per OS: $count paket, tunggu balasan maks. $waitMs. */
function netPingArgs(string $ip, int $count, int $waitMs): array
{
    if (DIRECTORY_SEPARATOR === '\\') return [netPingBin(), '-n', (string)$count, '-w', (string)$waitMs, $ip];
    return [netPingBin(), '-c', (string)$count, '-i', '0.2', '-W', (string)max(1, (int)ceil($waitMs / 1000)), $ip];
}

/**
 * Jalankan banyak ping BERSAMAAN (maks. $parallel proses), tanpa shell, output lewat file sementara (aman di Windows).
 * Return [ip => ['replies' => n, 'sent' => n, 'avg' => ms|null, 'max' => ms|null]].
 */
function netPingMany(array $ips, int $count = 4, int $waitMs = 1000, int $parallel = 24): array
{
    $ips = array_values(array_unique(array_filter($ips)));
    $res = []; $queue = $ips; $running = [];
    if (!function_exists('proc_open')) {
        foreach ($ips as $ip) $res[$ip] = ['replies' => 0, 'sent' => $count, 'avg' => null, 'max' => null, 'error' => 'proc_open nonaktif'];
        return $res;
    }
    $deadline = microtime(true) + 25 + $count * 2;
    while ($queue || $running) {
        while ($queue && count($running) < $parallel) {
            $ip = array_shift($queue);
            $fo = tempnam(sys_get_temp_dir(), 'npo');
            $p = @proc_open(netPingArgs($ip, $count, $waitMs), [0 => ['pipe', 'r'], 1 => ['file', $fo, 'w'], 2 => ['file', $fo, 'a']], $pipes, null, null, ['bypass_shell' => true]);
            if (!is_resource($p)) { @unlink($fo); $res[$ip] = ['replies' => 0, 'sent' => $count, 'avg' => null, 'max' => null, 'error' => 'ping gagal dijalankan']; continue; }
            fclose($pipes[0]);
            $running[$ip] = [$p, $fo];
        }
        foreach ($running as $ip => [$p, $fo]) {
            $st = proc_get_status($p);
            if ($st['running'] && microtime(true) < $deadline) continue;
            if ($st['running']) proc_terminate($p);
            proc_close($p);
            $res[$ip] = netParsePing((string)@file_get_contents($fo), $count);
            @unlink($fo);
            unset($running[$ip]);
        }
        if ($running) usleep(40000);
    }
    return $res;
}

/**
 * Baca hasil ping tanpa bergantung bahasa Windows: baris balasan selalu memuat "TTL=",
 * waktu ditulis "time=12ms" / "waktu<1ms" / "time=0.4 ms".
 */
function netParsePing(string $out, int $count): array
{
    $replies = 0; $times = [];
    foreach (preg_split('/\r?\n/', $out) as $line) {
        if (stripos($line, 'ttl=') === false) continue;
        $replies++;
        if (preg_match('/[=<]\s*([\d.]+)\s*ms/i', $line, $m)) $times[] = max(1, (int)round((float)$m[1]));
    }
    return ['replies' => min($replies, $count), 'sent' => $count,
            'avg' => $times ? (int)round(array_sum($times) / count($times)) : null, 'max' => $times ? max($times) : null];
}

/** Coba sambung ke salah satu port. Return [port, ms] atau null. */
function netTcpProbe(string $ip, array $ports, float $timeout = 1.0): ?array
{
    $r = netTcpProbeMany([$ip => $ports], $timeout);
    return $r[$ip] ?? null;
}

/** Socket async benar-benar tersambung? (SO_ERROR bila ekstensi sockets aktif, kalau tidak lewat uji baca.) */
function netSockConnected($s): bool
{
    if (function_exists('socket_import_stream') && ($sk = @socket_import_stream($s))) {
        $e = @socket_get_option($sk, SOL_SOCKET, SO_ERROR);
        if ($e !== false) return (int)$e === 0 && @stream_socket_get_name($s, true) !== false;
    }
    if (@stream_socket_get_name($s, true) === false) return false;
    @fread($s, 1);                       // koneksi gagal (ditolak/tak terjangkau) -> error -> EOF
    return !feof($s);
}

/**
 * Coba sambung TCP ke banyak alamat & port SEKALIGUS (non-blocking), total maks. $timeout detik.
 * $targets = [ip => [port, ...]]. Return [ip => [port, ms]] untuk yang ada port terbuka.
 */
function netTcpProbeMany(array $targets, float $timeout = 1.2): array
{
    $socks = []; $meta = []; $found = [];
    $t0 = microtime(true);
    foreach ($targets as $ip => $ports) foreach ($ports as $port) {
        $s = @stream_socket_client('tcp://' . $ip . ':' . (int)$port, $en, $es, $timeout, STREAM_CLIENT_CONNECT | STREAM_CLIENT_ASYNC_CONNECT);
        if (!$s) continue;
        stream_set_blocking($s, false);
        $k = (int)$s; $socks[$k] = $s; $meta[$k] = [$ip, (int)$port];
    }
    $end = $t0 + $timeout;
    while ($socks && ($left = $end - microtime(true)) > 0) {
        $w = array_values($socks); $e = array_values($socks); $r = null;
        $n = @stream_select($r, $w, $e, 0, (int)min(200000, $left * 1000000));
        if ($n === false) break;
        foreach (array_merge($w ?: [], $e ?: []) as $s) {
            $k = (int)$s; if (!isset($socks[$k])) continue;
            [$ip, $port] = $meta[$k];
            if (netSockConnected($s) && !isset($found[$ip])) $found[$ip] = [$port, max(1, (int)round((microtime(true) - $t0) * 1000))];
            @fclose($s); unset($socks[$k]);
        }
    }
    foreach ($socks as $s) @fclose($s);
    return $found;
}

/**
 * Cek sekumpulan aset (dipanggil per kelompok kecil dari halaman agar progress terlihat & tidak timeout).
 * Simpan ke net_status. Return [id => hasil].
 */
function netCheckAssets(PDO $db, array $ids): array
{
    ensureNetTables($db);
    @set_time_limit(120);
    $set = netSettings();
    $all = netAssets($db);
    $list = [];
    foreach ($ids as $id) if (isset($all[(int)$id]) && $all[(int)$id]['ip'] !== '') $list[(int)$id] = $all[(int)$id];
    if (!$list) return [];
    $ping = netPingMany(array_column($list, 'ip'), (int)$set['ping_count'], 1000);
    $now = date('Y-m-d H:i:s');
    $del = $db->prepare("DELETE FROM net_status WHERE asset_id = ?");
    $ins = $db->prepare("INSERT INTO net_status (asset_id, state, ms, loss, method, detail, checked_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
    // Yang tidak membalas ping: coba port TCP sekaligus (Windows/PC sering memblokir ping).
    $tcpT = [];
    foreach ($list as $a) if (($ping[$a['ip']]['replies'] ?? 0) === 0) $tcpT[$a['ip']] = netTcpPorts($a['type']);
    $tcpR = $tcpT ? netTcpProbeMany($tcpT) : [];
    $out = [];
    foreach ($list as $id => $a) {
        $p = $ping[$a['ip']] ?? ['replies' => 0, 'sent' => (int)$set['ping_count'], 'avg' => null];
        $loss = (int)round(100 * (1 - $p['replies'] / max(1, $p['sent'])));
        if ($p['replies'] > 0) {
            $ms = (int)$p['avg']; $method = 'ping';
            $state = ($ms >= $set['warn_ms'] || $loss >= $set['warn_loss']) ? 'warn' : 'ok';
            $detail = $p['replies'] . '/' . $p['sent'] . ' ' . nL('balasan ping', 'ping replies') . ($p['max'] ? ', maks ' . $p['max'] . ' ms' : '');
        } elseif ($tcp = $tcpR[$a['ip']] ?? null) {
            // Ping diblokir firewall tapi perangkat hidup.
            [$port, $ms] = $tcp; $loss = 0; $method = 'tcp ' . $port;
            $state = $ms >= $set['warn_ms'] ? 'warn' : 'ok';
            $detail = nL('Ping diblokir, port ' . $port . ' terbuka', 'Ping blocked, port ' . $port . ' open');
        } else {
            $ms = null; $loss = 100; $method = 'ping+tcp'; $state = 'err';
            $detail = !empty($p['error']) ? $p['error'] : nL('Tidak merespons ping maupun port ', 'No reply to ping or ports ') . implode('/', netTcpPorts($a['type']));
        }
        $del->execute([$id]);
        $ins->execute([$id, $state, $ms, $loss, $method, mb_substr($detail, 0, 250), $now]);
        $out[$id] = ['id' => $id, 'state' => $state, 'ms' => $ms, 'loss' => $loss, 'method' => $method, 'detail' => $detail, 'checked_at' => $now];
    }
    return $out;
}

/** Simpan ringkasan satu kali "Cek sekarang" ke riwayat. */
function netLogCheck(PDO $db, array $ids, string $user): void
{
    ensureNetTables($db);
    $all = netAssets($db); $c = ['ok' => 0, 'warn' => 0, 'err' => 0]; $bad = [];
    foreach ($ids as $id) {
        $a = $all[(int)$id] ?? null; if (!$a || !$a['state'] || !isset($c[$a['state']])) continue;
        $c[$a['state']]++;
        if ($a['state'] !== 'ok') $bad[] = $a['name'] . ' (' . $a['ip'] . ') ' . ($a['state'] === 'err' ? 'MATI' : 'LAMBAT ' . $a['ms'] . ' ms / ' . $a['loss'] . '%');
    }
    $sus = array_map(fn($s) => nL('Diduga mati: ', 'Suspected down: ') . $s['name'], netSuspects($all));
    $db->prepare("INSERT INTO net_checks (checked_at, total, ok, warn, err, user_name, summary) VALUES (?, ?, ?, ?, ?, ?, ?)")
       ->execute([date('Y-m-d H:i:s'), array_sum($c), $c['ok'], $c['warn'], $c['err'], mb_substr($user, 0, 100), implode("\n", array_merge($sus, $bad)) ?: null]);
}

/** Semua keturunan (aset di bawah) sebuah perangkat. */
function netDescendants(array $all, int $id): array
{
    $out = []; $stack = [$id]; $seen = [$id => true];
    while ($stack) {
        $cur = array_pop($stack);
        foreach ($all as $a) if ($a['parent'] === $cur && !isset($seen[$a['id']])) { $seen[$a['id']] = true; $out[] = $a; $stack[] = $a['id']; }
    }
    return $out;
}

/**
 * Switch/hub tanpa IP yang diduga mati: SEMUA aset ber-IP di bawahnya (minimal 2) mati pada pengecekan terakhir.
 * Return daftar ['id','name','down','total','names','parent_name','port'].
 */
function netSuspects(array $all): array
{
    $out = [];
    foreach ($all as $a) {
        if ($a['ip'] !== '' || !$a['is_net']) continue;
        $kids = array_values(array_filter(netDescendants($all, $a['id']), fn($k) => $k['ip'] !== '' && $k['state']));
        if (count($kids) < 2) continue;
        $down = array_filter($kids, fn($k) => $k['state'] === 'err');
        if (count($down) === count($kids)) {
            $out[] = ['id' => $a['id'], 'name' => $a['name'], 'down' => count($down), 'total' => count($kids),
                      'names' => array_column($kids, 'name'), 'parent_name' => $a['parent'] ? ($all[$a['parent']]['name'] ?? '') : '', 'port' => $a['port']];
        }
    }
    // Tampilkan yang paling atas saja (bila switch induk dan anaknya sama-sama diduga mati).
    $ids = array_column($out, 'id');
    return array_values(array_filter($out, function ($s) use ($all, $ids) {
        $p = $all[$s['id']]['parent'] ?? null;
        while ($p) { if (in_array($p, $ids, true)) return false; $p = $all[$p]['parent'] ?? null; }
        return true;
    }));
}

/** Simpan "Terhubung ke" untuk satu aset (null = belum dihubungkan). Cegah lingkaran. */
function netSetLink(PDO $db, int $id, ?int $parent, string $port): bool
{
    $port = netEthName(trim($port));   // ether8 / port8 -> eth8
    ensureNetTables($db);
    $all = netAssets($db);
    if (!isset($all[$id])) return false;
    if ($parent !== null) {
        if ($parent === $id || !isset($all[$parent])) return false;
        foreach (netDescendants($all, $id) as $d) if ($d['id'] === $parent) return false;   // induk tidak boleh "di bawah" aset ini
    }
    $db->prepare("DELETE FROM net_links WHERE asset_id = ?")->execute([$id]);
    if ($parent !== null || $port !== '') {
        $db->prepare("INSERT INTO net_links (asset_id, parent_asset_id, port, updated_at) VALUES (?, ?, ?, ?)")
           ->execute([$id, $parent, $port !== '' ? mb_substr($port, 0, 30) : null, date('Y-m-d H:i:s')]);
    }
    return true;
}

/* ================================================================== Scan subnet */

/** "192.168.1.0/24" -> ['192.168.1.', 1, 254]. Hanya /24 (maks. 254 alamat) agar ringan. */
function netParseSubnet(string $s): ?array
{
    if (!preg_match('/^\s*(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.\d{1,3}(?:\/24)?\s*$/', $s, $m)) return null;
    foreach ([1, 2, 3] as $i) if ((int)$m[$i] > 255) return null;
    return [$m[1] . '.' . $m[2] . '.' . $m[3] . '.', 1, 254];
}

/** Tabel ARP server: [ip => mac] (hanya perangkat di subnet yang sama dengan server yang punya MAC). */
function netArpTable(): array
{
    $out = [];
    if (!function_exists('proc_open')) return $out;
    $bin = 'arp';
    foreach (['C:\\Windows\\System32\\ARP.EXE', 'C:\\Windows\\Sysnative\\ARP.EXE', '/usr/sbin/arp', '/sbin/arp'] as $c) if (@is_file($c)) { $bin = $c; break; }
    $p = @proc_open([$bin, '-a'], [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes, null, null, ['bypass_shell' => true]);
    if (is_resource($p)) {
        fclose($pipes[0]);
        $txt = (string)stream_get_contents($pipes[1]); fclose($pipes[1]); fclose($pipes[2]); proc_close($p);
        foreach (preg_split('/\r?\n/', $txt) as $line) {
            if (preg_match('/(\d{1,3}(?:\.\d{1,3}){3}).*?([0-9a-f]{2}([-:])[0-9a-f]{2}(?:\3[0-9a-f]{2}){4})/i', $line, $m)) {
                $mac = strtoupper(str_replace('-', ':', $m[2]));
                if ($mac !== 'FF:FF:FF:FF:FF:FF' && strpos($mac, '01:00:5E') !== 0) $out[$m[1]] = $mac;
            }
        }
    }
    return $out;
}

/**
 * Merek perkiraan dari MAC. Butuh file daftar OUI resmi IEEE (oui.csv) di includes/data/ —
 * unduh dari https://standards-oui.ieee.org/oui/oui.csv. Tanpa file itu kolom merek dikosongkan.
 */
function netVendor(string $mac): string
{
    static $map = null;
    if ($map === null) {
        $map = [];
        $f = __DIR__ . '/data/oui.csv';
        if (is_file($f) && ($h = @fopen($f, 'r'))) {
            while (($row = fgetcsv($h)) !== false) {
                if (isset($row[1], $row[2]) && preg_match('/^[0-9A-F]{6}$/i', $row[1])) $map[strtoupper($row[1])] = trim($row[2]);
            }
            fclose($h);
        }
    }
    $key = strtoupper(substr(str_replace([':', '-'], '', $mac), 0, 6));
    return $map[$key] ?? '';
}

function netOuiAvailable(): bool
{
    return is_file(__DIR__ . '/data/oui.csv');
}

/** Ping 1 paket ke sekelompok alamat (bagian dari scan). Return [ip => ms] untuk yang membalas. */
function netScanChunk(array $ips): array
{
    $r = netPingMany($ips, 1, 600, 48);
    $out = [];
    foreach ($r as $ip => $p) if ($p['replies'] > 0) $out[$ip] = (int)($p['avg'] ?? 1);
    return $out;
}

function netScanFile(string $prefix): string
{
    return __DIR__ . '/data/net_scan_' . preg_replace('/[^0-9]/', '_', rtrim($prefix, '.')) . '.json';
}

/** Posisi bebas topologi: [asset_id => [x, y]] (asset_id -1 / -2 = kotak Internet / Belum dihubungkan). */
function netTopoPosMap(PDO $db): array
{
    ensureNetTables($db);
    $out = [];
    try { foreach ($db->query("SELECT asset_id, x, y FROM net_topo_pos")->fetchAll() as $r) $out[(int)$r['asset_id']] = [(int)$r['x'], (int)$r['y']]; } catch (Throwable $e) {}
    return $out;
}

/** Simpan posisi bebas topologi. $map = [asset_id => [x, y]]; posisi lama perangkat lain tetap. */
function netSaveTopoPos(PDO $db, array $map): void
{
    ensureNetTables($db);
    $del = $db->prepare("DELETE FROM net_topo_pos WHERE asset_id = ?");
    $ins = $db->prepare("INSERT INTO net_topo_pos (asset_id, x, y, updated_at) VALUES (?, ?, ?, ?)");
    $now = date('Y-m-d H:i:s');
    foreach ($map as $id => $xy) {
        $id = (int)$id;
        if ($id === 0 || !is_array($xy) || count($xy) < 2) continue;
        $x = max(0, min(100000, (int)$xy[0])); $y = max(0, min(100000, (int)$xy[1]));
        $del->execute([$id]);
        $ins->execute([$id, $x, $y, $now]);
    }
}

/** Hapus semua posisi bebas (kembali ke susunan otomatis). */
function netResetTopoPos(PDO $db): void
{
    ensureNetTables($db);
    $db->exec("DELETE FROM net_topo_pos");
}

/* ================================================================== Riwayat perubahan koneksi */

/** Catat perubahan koneksi. $undo = data untuk membatalkan (null = tidak bisa dibatalkan). */
function netLogLink(PDO $db, string $action, string $detail, ?array $undo = null): void
{
    ensureNetTables($db);
    $me = function_exists('currentUser') ? currentUser() : null;
    try {
        $db->prepare("INSERT INTO net_link_log (created_at, user_name, action, detail, undo_data, undone) VALUES (?, ?, ?, ?, ?, 0)")
           ->execute([date('Y-m-d H:i:s'), (string)($me['full_name'] ?? ''), mb_substr($action, 0, 20), mb_substr($detail, 0, 255), $undo ? json_encode($undo) : null]);
    } catch (Throwable $e) { /* riwayat tidak boleh menggagalkan penyimpanan */ }
}

/** Riwayat terbaru: [['id','at','user','action','detail','undone','can_undo'], ...]. */
function netLinkLog(PDO $db, int $limit = 30): array
{
    ensureNetTables($db);
    try {
        $rows = $db->query("SELECT * FROM net_link_log ORDER BY id DESC LIMIT " . max(1, min(200, $limit)))->fetchAll();
    } catch (Throwable $e) { return []; }
    return array_map(fn($r) => ['id' => (int)$r['id'], 'at' => (string)$r['created_at'], 'user' => (string)($r['user_name'] ?? ''), 'action' => (string)$r['action'],
        'detail' => (string)($r['detail'] ?? ''), 'undone' => (bool)$r['undone'], 'can_undo' => !$r['undone'] && $r['undo_data'] !== null], $rows);
}

/** Teks 1 koneksi utama: "A terhubung ke B (eth3 ⇄ eth1)". */
function netLinkText(array $all, int $id, ?int $parent, string $port, string $own): string
{
    $n = fn($i) => $all[$i]['name'] ?? ('#' . $i);
    if (!$parent) return $n($id) . ' ' . nL('tidak terhubung', 'not linked');
    $pl = netPortLabel($port, $own);
    return $n($id) . ' ' . nL('terhubung ke', 'linked to') . ' ' . $n($parent) . ($pl !== '' ? ' (' . $pl . ')' : '');
}

/** Ubah port koneksi tambahan. */
function netUpdateExtraLink(PDO $db, int $id, string $portA, string $portB): void
{
    ensureNetTables($db);
    $cut = fn(string $p) => trim($p) !== '' ? mb_substr(netEthName(trim($p)), 0, 30) : null;
    $db->prepare("UPDATE net_links_extra SET port_a = ?, port_b = ? WHERE id = ?")->execute([$cut($portA), $cut($portB), $id]);
}

/** Batalkan perubahan terakhir yang bisa dibatalkan. Return '' bila berhasil, atau pesan alasan. */
function netUndoLastLink(PDO $db): string
{
    ensureNetTables($db);
    $r = $db->query("SELECT * FROM net_link_log WHERE undone = 0 AND undo_data IS NOT NULL ORDER BY id DESC LIMIT 1")->fetch();
    if (!$r) return nL('Tidak ada perubahan yang bisa dibatalkan.', 'Nothing to undo.');
    $u = json_decode((string)$r['undo_data'], true) ?: [];
    switch ($u['t'] ?? '') {
        case 'main':
            $parent = !empty($u['parent']) ? (int)$u['parent'] : null;
            if (!netSetLink($db, (int)$u['id'], $parent, (string)($u['port'] ?? ''))) return nL('Tidak bisa dibatalkan: akan membuat sambungan melingkar.', 'Cannot undo: circular link.');
            netSaveOwnPort($db, (int)$u['id'], $parent ? (string)($u['own'] ?? '') : '');
            break;
        case 'extra_del':
            netDeleteExtraLink($db, (int)$u['id']);
            break;
        case 'extra_ins':
            $x = $u['row'] ?? [];
            $db->prepare("INSERT INTO net_links_extra (asset_id, other_id, port_a, port_b, created_at) VALUES (?, ?, ?, ?, ?)")
               ->execute([(int)$x['a'], (int)$x['b'], ($x['port_a'] ?? '') !== '' ? $x['port_a'] : null, ($x['port_b'] ?? '') !== '' ? $x['port_b'] : null, date('Y-m-d H:i:s')]);
            break;
        case 'extra_ports':
            netUpdateExtraLink($db, (int)$u['id'], (string)($u['port_a'] ?? ''), (string)($u['port_b'] ?? ''));
            break;
        default:
            return nL('Data riwayat tidak dikenali.', 'Unknown history data.');
    }
    $db->prepare("UPDATE net_link_log SET undone = 1 WHERE id = ?")->execute([(int)$r['id']]);
    netLogLink($db, 'undo', nL('Dibatalkan: ', 'Undone: ') . $r['detail']);
    return '';
}
