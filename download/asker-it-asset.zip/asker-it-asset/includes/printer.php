<?php
/**
 * Isian khusus aset Printer: koneksi (USB / LAN) dan kepemilikan (milik perusahaan / sewa + nama vendor sewa).
 * Disimpan di tabel BARU asset_printer_info (CREATE TABLE IF NOT EXISTS). Tabel lama tidak diubah.
 * Printer USB tidak punya IP (kolom IP dikosongkan saat disimpan), jadi tidak ikut dicek di menu Jaringan.
 */

const PRINTER_CONNECTIONS = ['LAN', 'USB'];
const PRINTER_OWNERSHIPS  = ['Milik Perusahaan', 'Sewa'];

function isPrinterCategory(?string $category): bool
{
    return $category !== null && stripos($category, 'printer') !== false;
}

function ensurePrinterTable(PDO $db): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS asset_printer_info (
            asset_id      INT UNSIGNED NOT NULL PRIMARY KEY,
            connection    VARCHAR(10)  NOT NULL DEFAULT 'LAN',
            ownership     VARCHAR(30)  NOT NULL DEFAULT 'Milik Perusahaan',
            rental_vendor VARCHAR(100) DEFAULT NULL,
            updated_at    DATETIME     DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) { /* tabel sudah ada / dialek lain */ }
}

/** "usb" -> USB, "lan"/"network"/"jaringan"/"wifi" -> LAN; lainnya ''. */
function printerNormConnection(string $v): string
{
    $k = strtolower(trim($v));
    if ($k === 'usb') return 'USB';
    if (in_array($k, ['lan', 'network', 'jaringan', 'ethernet', 'wifi', 'wi-fi', 'wireless'], true)) return 'LAN';
    return '';
}

/** "sewa"/"rental" -> Sewa, "milik"/"perusahaan"/"own" -> Milik Perusahaan; lainnya ''. */
function printerNormOwnership(string $v): string
{
    $k = strtolower(trim($v));
    if ($k === '') return '';
    if (preg_match('/sewa|rent|rental/', $k)) return 'Sewa';
    if (preg_match('/milik|perusahaan|company|own|aset/', $k)) return 'Milik Perusahaan';
    return '';
}

/** [asset_id => ['connection','ownership','rental_vendor']] */
function printerInfoMap(PDO $db, array $assetIds): array
{
    ensurePrinterTable($db);
    $map = [];
    $assetIds = array_values(array_unique(array_filter(array_map('intval', $assetIds))));
    foreach (array_chunk($assetIds, 500) as $chunk) {
        $st = $db->prepare("SELECT asset_id, connection, ownership, rental_vendor FROM asset_printer_info WHERE asset_id IN (" . implode(',', array_fill(0, count($chunk), '?')) . ")");
        $st->execute($chunk);
        foreach ($st->fetchAll() as $r) $map[(int)$r['asset_id']] = ['connection' => (string)$r['connection'], 'ownership' => (string)$r['ownership'], 'rental_vendor' => (string)($r['rental_vendor'] ?? '')];
    }
    return $map;
}

function savePrinterInfo(PDO $db, int $assetId, string $connection, string $ownership, string $vendor): void
{
    ensurePrinterTable($db);
    $connection = printerNormConnection($connection) ?: 'LAN';
    $ownership  = printerNormOwnership($ownership) ?: 'Milik Perusahaan';
    $vendor     = $ownership === 'Sewa' ? mb_substr(trim($vendor), 0, 100) : '';
    $db->prepare("DELETE FROM asset_printer_info WHERE asset_id = ?")->execute([$assetId]);
    $db->prepare("INSERT INTO asset_printer_info (asset_id, connection, ownership, rental_vendor, updated_at) VALUES (?, ?, ?, ?, ?)")
       ->execute([$assetId, $connection, $ownership, $vendor !== '' ? $vendor : null, date('Y-m-d H:i:s')]);
}

/** Label kepemilikan (ID/EN). */
function printerOwnershipLabel(string $own): string
{
    $en = function_exists('currentLang') && currentLang() === 'en';
    if ($own === 'Sewa') return $en ? 'Rented' : 'Sewa';
    return $en ? 'Company-owned' : 'Milik Perusahaan';
}
