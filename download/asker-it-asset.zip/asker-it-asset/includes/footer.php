        <footer class="mt-8 pt-4 pb-2 text-center text-xs text-slate-400 print:hidden">@Copyright by ASKER</footer>
    </main>
</div>
</div>

<?php if (function_exists('isAdmin') && isAdmin()): ?>
<!-- ===== Popup notifikasi tiket IT baru (khusus admin, tampil di semua halaman) ===== -->
<div id="ticketNotifyModal" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-md max-h-[80vh] flex flex-col">
        <div class="flex items-center justify-between px-5 py-4 border-b">
            <div class="flex items-center gap-2">
                <span class="flex h-8 w-8 items-center justify-center rounded-full bg-amber-100 text-amber-600"><?= icon('bell', 'w-4 h-4') ?></span>
                <h3 class="font-semibold text-slate-800"><?= t('ticket_notify_title') ?></h3>
            </div>
            <button type="button" data-modal-close id="btnCloseTicketNotify" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button>
        </div>
        <div id="ticketNotifyBody" class="px-5 py-4 overflow-y-auto space-y-3 text-sm">
            <!-- diisi otomatis lewat JavaScript -->
        </div>
        <div class="px-5 py-3 border-t flex justify-end gap-2">
            <button type="button" id="btnCloseTicketNotify2" class="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm"><?= t('btn_close') ?></button>
            <button type="button" id="btnGoToTicketing" class="px-4 py-2 rounded-lg bg-brand-600 text-white hover:bg-brand-700 text-sm"><?= t('btn_go_to_ticketing') ?></button>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
    // Cache-busting sama seperti style.css di header.php.
    $appJsPath = __DIR__ . '/../assets/js/app.js';
    $appJsVer  = is_file($appJsPath) ? filemtime($appJsPath) : time();
?>
<script src="assets/js/app.js?v=<?= $appJsVer ?>"></script>
<?php if (function_exists('currentLang') && currentLang() === 'en'): ?>
<!-- Global automatic translation for user-entered/read-only text across application menus. Editable controls are deliberately not rewritten. -->
<script>
(function () {
  'use strict';
  var csrf = <?= json_encode(function_exists('csrfToken') ? csrfToken() : '') ?>;
  var cachePrefix = 'auto_en_v1:';
  var queue = [], running = false, queued = new WeakSet(), translatedNodes = new WeakSet();
  var maxNodesPerPage = 100, queuedCount = 0;
  var idHints = /\b(tidak|belum|sudah|untuk|dengan|karena|karna|rusak|ganti|pengajuan|komputer|laptop|mouse|keyboard|printer|menyala|mati|error|masalah|kendala|perbaikan|pengerjaan|pemeriksaan|hasil|alasan|catatan|barang|minta|tolong|buka|akses|masuk|keluar|normal|bermasalah|terjadi|mohon|diproses|dibeli|diganti|baru|lama|hilang|terputus|lambat|tidak bisa|tidak dapat|belum bisa|sudah selesai)\b/i;
  function shouldSkip(node) {
    if (!node || !node.parentElement || !node.nodeValue) return true;
    var text = node.nodeValue.trim();
    if (text.length < 5 || /^[\d\W_]+$/.test(text) || !idHints.test(text)) return true;
    var el = node.parentElement;
    if (el.closest('script,style,noscript,textarea,input,select,option,button,[contenteditable="true"],.notranslate,[data-no-auto-translate],[data-auto-translate],nav,header,footer')) return true;
    if (el.closest('[data-translated="1"]')) return true;
    return false;
  }
  function getCache(text) {
    try { return localStorage.getItem(cachePrefix + text); } catch (_) { return null; }
  }
  function setCache(text, value) {
    try { localStorage.setItem(cachePrefix + text, value); } catch (_) {}
  }
  async function translate(text) {
    var cached = getCache(text);
    if (cached) return cached;
    var res = await fetch('request_translate.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'},
      body: new URLSearchParams({csrf_token: csrf, text: text})
    });
    var data = await res.json();
    if (!res.ok || !data.ok || !data.translatedText) throw new Error(data.error || 'Translation unavailable');
    setCache(text, data.translatedText);
    return data.translatedText;
  }
  function enqueue(node) {
    if (shouldSkip(node) || queued.has(node) || translatedNodes.has(node) || queuedCount >= maxNodesPerPage) return;
    queued.add(node); queue.push({node: node, original: node.nodeValue}); queuedCount++;
    drain();
  }
  async function drain() {
    if (running) return;
    running = true;
    while (queue.length) {
      var item = queue.shift(), node = item.node;
      if (!node || !node.isConnected || !node.parentElement) continue;
      try {
        var translated = await translate(item.original.trim());
        if (node.isConnected && node.nodeValue.trim() === item.original.trim()) {
          var leading = (item.original.match(/^\s*/) || [''])[0];
          var trailing = (item.original.match(/\s*$/) || [''])[0];
          node.nodeValue = leading + translated + trailing;
          translatedNodes.add(node);
          node.parentElement.setAttribute('title', 'Automatically translated to English');
        }
      } catch (e) {
        // Preserve the original text if translation fails; never block page functionality.
        if (node.parentElement) node.parentElement.setAttribute('title', 'Automatic translation unavailable; original text is shown.');
      }
      await new Promise(function (resolve) { setTimeout(resolve, 220); });
    }
    running = false;
  }
  function scan(root) {
    if (!root) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    var node;
    while ((node = walker.nextNode())) enqueue(node);
  }
  scan(document.body);
  var observer = new MutationObserver(function (records) {
    records.forEach(function (record) {
      if (record.type === 'childList') record.addedNodes.forEach(function (n) { if (n.nodeType === 3) enqueue(n); else if (n.nodeType === 1) scan(n); });
    });
  });
  observer.observe(document.body, {childList: true, subtree: true});
})();
</script>
<?php endif; ?>
<?php if (!empty($extraScripts)) echo $extraScripts; ?>
<?php if (function_exists('isAdmin') && isAdmin()): ?>
<script>
(function() {
    var modal   = document.getElementById('ticketNotifyModal');
    var body    = document.getElementById('ticketNotifyBody');
    var csrf    = '<?= htmlspecialchars(csrfToken(), ENT_QUOTES) ?>';
    var nameLabel       = '<?= htmlspecialchars(t('ticket_notify_name'), ENT_QUOTES) ?>';
    var departmentLabel = '<?= htmlspecialchars(t('field_department'), ENT_QUOTES) ?>';
    var locationLabel   = '<?= htmlspecialchars(t('field_location'), ENT_QUOTES) ?>';
    var pending = 0; // id tiket terbaru yang sedang ditampilkan di popup ini

    function escapeHtml(str) {
        var d = document.createElement('div');
        d.textContent = str;
        return d.innerHTML;
    }

    function infoRow(label, value) {
        return '<div class="flex gap-2">' +
               '<dt class="w-24 shrink-0 text-slate-400">' + label + '</dt>' +
               '<dd class="text-slate-700 font-medium break-words">' + escapeHtml(value || '-') + '</dd>' +
               '</div>';
    }

    function renderTickets(tickets) {
        body.innerHTML = tickets.map(function(t) {
            return '<div class="border border-slate-100 rounded-lg p-3">' +
                   '<div class="flex justify-between items-start gap-2">' +
                   '<span class="font-medium text-slate-800">' + escapeHtml(t.ticket_number) + '</span>' +
                   '<span class="text-xs text-slate-400 whitespace-nowrap">' + escapeHtml(t.created_at) + '</span>' +
                   '</div>' +
                   '<p class="text-slate-600 mt-1">' + escapeHtml(t.problem_detail) + '</p>' +
                   '<dl class="mt-2 pt-2 border-t border-slate-100 space-y-1 text-xs">' +
                   infoRow(nameLabel, t.pelapor) +
                   infoRow(departmentLabel, t.department) +
                   infoRow(locationLabel, t.location) +
                   '</dl>' +
                   '</div>';
        }).join('');
    }

    function showModal(tickets, maxId) {
        pending = maxId;
        renderTickets(tickets);
        modal.classList.remove('hidden');
    }

    function hideModal() {
        modal.classList.add('hidden');
        dismissPending();
    }

    // Kirim status "sudah dilihat" ke server. Pakai sendBeacon kalau tersedia supaya
    // requestnya tetap terkirim andal walau halaman langsung berpindah (contoh: saat
    // tombol "Lihat Ticketing" diklik dan browser langsung navigasi ke tickets.php).
    function dismissPending() {
        if (pending <= 0) return;
        var data = 'last_id=' + encodeURIComponent(pending) + '&csrf_token=' + encodeURIComponent(csrf);
        if (navigator.sendBeacon) {
            navigator.sendBeacon('ticket_notify_dismiss.php', new Blob([data], {type: 'application/x-www-form-urlencoded'}));
        } else {
            fetch('ticket_notify_dismiss.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: data
            }).catch(function() {});
        }
        pending = 0;
    }

    function goToTicketing() {
        dismissPending();
        modal.classList.add('hidden');
        window.location.href = 'tickets.php';
    }

    function checkNewTickets() {
        fetch('ticket_notify_check.php', {headers: {'X-Requested-With': 'XMLHttpRequest'}})
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (!data.ok || !data.tickets || data.tickets.length === 0) return;

                if (modal.classList.contains('hidden')) {
                    // popup belum tampil -> tampilkan seperti biasa
                    showModal(data.tickets, data.max_id);
                } else if (data.max_id > pending) {
                    // popup masih terbuka, tapi ada tiket LEBIH BARU yang masuk ->
                    // update daftar di popup yang sama tanpa menutupnya
                    showModal(data.tickets, data.max_id);
                }
            })
            .catch(function() {});
    }

    document.getElementById('btnCloseTicketNotify').addEventListener('click', hideModal);
    document.getElementById('btnCloseTicketNotify2').addEventListener('click', hideModal);
    document.getElementById('btnGoToTicketing').addEventListener('click', goToTicketing);
    modal.addEventListener('click', function(e) {
        if (e.target === modal) hideModal(); // klik di luar kotak = tutup manual juga
    });

    checkNewTickets();
    setInterval(checkNewTickets, 5000); // cek tiket baru tiap 5 detik selama admin membuka halaman ini (ringan untuk server)
})();
</script>
<!-- ===== Notifikasi CCTV mati / hidup kembali (khusus admin, lihat cctv_notify_check.php) ===== -->
<div id="cctvToast" class="hidden fixed bottom-4 right-4 z-50 w-[calc(100%-2rem)] max-w-sm bg-white rounded-xl shadow-xl border-l-4 border-red-500 print:hidden">
    <div class="flex items-center justify-between px-4 pt-3">
        <p class="font-semibold text-slate-800 flex items-center gap-2"><?= icon('camera', 'w-4 h-4') ?> CCTV</p>
        <button type="button" id="cctvToastClose" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-4 h-4') ?></button>
    </div>
    <div id="cctvToastBody" class="px-4 py-2 space-y-1.5 text-sm max-h-60 overflow-y-auto"></div>
    <div class="px-4 pb-3 flex justify-end gap-2">
        <button type="button" id="cctvToastClose2" class="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm"><?= t('btn_close') ?></button>
        <a href="cctv.php" id="cctvToastOpen" class="px-3 py-1.5 rounded-lg bg-brand-600 text-white hover:bg-brand-700 text-sm"><?= htmlspecialchars(cL('Buka CCTV', 'Open CCTV')) ?></a>
    </div>
</div>
<script>
(function () {
    var box = document.getElementById('cctvToast'), body = document.getElementById('cctvToastBody');
    var csrf = '<?= htmlspecialchars(csrfToken(), ENT_QUOTES) ?>', pending = 0, appAlerted = 0;
    function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
    function dismiss() {
        box.classList.add('hidden');
        if (pending <= 0) return;
        var data = 'last_id=' + encodeURIComponent(pending) + '&csrf_token=' + encodeURIComponent(csrf);
        if (navigator.sendBeacon) navigator.sendBeacon('cctv_notify_check.php', new Blob([data], {type: 'application/x-www-form-urlencoded'}));
        else fetch('cctv_notify_check.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: data}).catch(function () {});
    }
    function check() {
        fetch('cctv_notify_check.php', {headers: {'X-Requested-With': 'XMLHttpRequest'}})
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d.ok || !d.items || !d.items.length || d.max_id <= pending) return;
                pending = d.max_id;
                var down = d.items.some(function (i) { return i.type === 'down' || i.type === 'report'; });
                box.classList.toggle('border-red-500', down);
                box.classList.toggle('border-green-500', !down);
                body.innerHTML = d.items.map(function (i) {
                    return '<div class="flex gap-2"><span class="mt-1.5 w-2 h-2 rounded-full shrink-0 ' + (i.type === 'down' ? 'bg-red-500' : (i.type === 'report' ? 'bg-amber-500' : 'bg-green-500')) + '"></span>' +
                           '<div><p class="text-slate-700">' + esc(i.message) + '</p><p class="text-xs text-slate-400">' + esc(i.created_at) + '</p></div></div>';
                }).join('');
                box.classList.remove('hidden');
                // Di dalam aplikasi Android: bunyikan nada notifikasi yang sama dengan tiket.
                if (window.TMNNApp && TMNNApp.ticketAlert && d.max_id > appAlerted) {
                    appAlerted = d.max_id;
                    try {
                        TMNNApp.ticketAlert(JSON.stringify(d.items.map(function (i) {
                            return {id: i.id, ticket_number: 'CCTV', pelapor: 'Monitoring CCTV', department: '', location: '', problem_detail: i.message, created_at: i.created_at};
                        })));
                    } catch (e) {}
                }
            })
            .catch(function () {});
    }
    document.getElementById('cctvToastClose').addEventListener('click', dismiss);
    document.getElementById('cctvToastClose2').addEventListener('click', dismiss);
    document.getElementById('cctvToastOpen').addEventListener('click', dismiss);
    check();
    setInterval(check, 30000); // cek pemberitahuan CCTV tiap 30 detik
})();
</script>
<!-- ===== Popup pengajuan baru khusus admin ===== -->
<div id="requestToast" class="hidden fixed bottom-4 right-4 z-[70] w-[calc(100%-2rem)] max-w-sm rounded-xl bg-white shadow-xl border border-violet-200 border-l-4 border-l-violet-500 print:hidden">
  <div class="flex items-center justify-between px-4 pt-3"><p class="font-semibold text-slate-800 flex items-center gap-2"><?= icon('clipboard-list','w-4 h-4') ?> Pengajuan Baru</p><button id="requestToastClose" type="button" class="text-slate-400 hover:text-slate-700" aria-label="Tutup"><?= icon('x','w-4 h-4') ?></button></div>
  <div id="requestToastBody" class="px-4 py-3 space-y-2 text-sm"></div>
  <div class="px-4 pb-3 flex justify-end"><a id="requestToastOpen" href="request.php" class="rounded-lg bg-brand-600 px-3 py-2 text-sm font-semibold text-white hover:bg-brand-700">Buka Pengajuan</a></div>
</div>
<script>
(function(){
 var box=document.getElementById('requestToast'), body=document.getElementById('requestToastBody'), close=document.getElementById('requestToastClose'), open=document.getElementById('requestToastOpen');
 if(!box||!body)return;
 var storageKey='requestPopupSeen_<?= (int)($_SESSION['user_id'] ?? 0) ?>';
 var seen=0; try{seen=parseInt(localStorage.getItem(storageKey)||'0',10)||0;}catch(e){}
 var current=0;
 function esc(v){var d=document.createElement('div');d.textContent=v==null?'':String(v);return d.innerHTML;}
 function hide(){box.classList.add('hidden');}
 function check(){fetch('request_notify_check.php',{credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}}).then(function(r){return r.json();}).then(function(d){if(!d.ok||!d.items||!d.items.length)return;var fresh=d.items.filter(function(i){return i.id>seen;});if(!fresh.length)return;current=Math.max.apply(null,fresh.map(function(i){return i.id;}));body.innerHTML=fresh.map(function(i){return '<div class="rounded-lg border border-slate-100 p-2.5"><p class="font-semibold text-slate-800">'+esc(i.title)+'</p><p class="text-slate-600 mt-1">'+esc(i.body)+'</p><p class="text-xs text-slate-400 mt-1">'+esc(i.created_at)+'</p></div>';}).join('');open.href=fresh[0].url||'request.php';box.classList.remove('hidden');
 if(window.TMNNApp&&TMNNApp.ticketAlert){try{TMNNApp.ticketAlert(JSON.stringify(fresh.map(function(i){return {id:i.id,ticket_number:'PENGAJUAN',pelapor:'Pengajuan baru',department:'',location:'',problem_detail:i.title+' — '+i.body,created_at:i.created_at};})));}catch(e){}}
 }).catch(function(){});}
 function dismiss(){if(current>seen){seen=current;try{localStorage.setItem(storageKey,String(seen));}catch(e){}}hide();}
 close.addEventListener('click',dismiss);open.addEventListener('click',dismiss);check();setInterval(check,7000);
})();
</script>
<?php endif; ?>
<script>
// Kirim aksi (mis. hapus) lewat POST + token CSRF, bukan lewat link biasa.
window.postAction = function (url, fields) {
    var f = document.createElement('form'); f.method = 'post'; f.action = url; f.style.display = 'none';
    var add = function (k, v) { var i = document.createElement('input'); i.type = 'hidden'; i.name = k; i.value = v; f.appendChild(i); };
    add('csrf_token', <?= json_encode(csrfToken()) ?>);
    Object.keys(fields || {}).forEach(function (k) { add(k, fields[k]); });
    document.body.appendChild(f); f.submit();
};
</script>
<!-- ===== Kamera langsung (dipakai Chat Grup & foto tiket) ===== -->
<div id="itCam" class="hidden fixed inset-0 z-[95] bg-black flex flex-col" role="dialog" aria-modal="true">
    <video id="itCamVideo" autoplay playsinline muted class="flex-1 min-h-0 w-full object-contain bg-black"></video>
    <div class="flex items-center justify-between gap-3 px-4 py-4 bg-black/80" style="padding-bottom: max(1rem, env(safe-area-inset-bottom, 0px))">
        <button type="button" id="itCamClose" class="text-white text-sm font-medium px-3 py-2 rounded-lg bg-white/10"><?= currentLang() === 'en' ? 'Cancel' : 'Batal' ?></button>
        <button type="button" id="itCamShot" class="w-16 h-16 rounded-full bg-white ring-4 ring-white/40" aria-label="<?= currentLang() === 'en' ? 'Take photo' : 'Ambil foto' ?>"></button>
        <button type="button" id="itCamFlip" class="text-white text-sm font-medium px-3 py-2 rounded-lg bg-white/10"><?= currentLang() === 'en' ? 'Switch' : 'Ganti kamera' ?></button>
    </div>
</div>
<script>
/**
 * window.itCamera(fallbackInput, onFile): buka kamera untuk memotret.
 *  1. Aplikasi Android yang sudah mendukung: TMNNApp.takePhoto(namaCallback) -> callback(dataUrl JPEG).
 *  2. Browser dengan akses kamera (HTTPS / alamat yang diizinkan): kamera langsung di halaman (webcam laptop / kamera HP).
 *  3. Selain itu: input file biasa (HP: kamera atau galeri, tergantung perangkat; laptop: pilih file).
 */
(function () {
    var box = document.getElementById('itCam'), video = document.getElementById('itCamVideo'), stream = null, facing = 'environment', done = null;
    function stop() { if (stream) stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; video.srcObject = null; box.classList.add('hidden'); }
    function start() {
        if (stream) stream.getTracks().forEach(function (t) { t.stop(); });
        return navigator.mediaDevices.getUserMedia({video: {facingMode: {ideal: facing}, width: {ideal: 1920}, height: {ideal: 1080}}, audio: false}).then(function (s) {
            stream = s; video.srcObject = s; box.classList.remove('hidden');
        });
    }
    document.getElementById('itCamClose').onclick = stop;
    document.getElementById('itCamFlip').onclick = function () { facing = facing === 'environment' ? 'user' : 'environment'; start().catch(function () {}); };
    document.getElementById('itCamShot').onclick = function () {
        if (!video.videoWidth) return;
        var c = document.createElement('canvas'); c.width = video.videoWidth; c.height = video.videoHeight;
        c.getContext('2d').drawImage(video, 0, 0);
        c.toBlob(function (b) { stop(); if (b && done) done(new File([b], 'kamera_' + Date.now() + '.jpg', {type: 'image/jpeg'})); }, 'image/jpeg', 0.9);
    };
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && stream) stop(); });
    window.itCamera = function (fallbackInput, onFile) {
        done = onFile;
        if (window.TMNNApp && typeof TMNNApp.takePhoto === 'function') {
            window.__itCamResult = function (dataUrl) {
                if (!dataUrl) return;
                fetch(dataUrl).then(function (r) { return r.blob(); }).then(function (b) { onFile(new File([b], 'kamera_' + Date.now() + '.jpg', {type: b.type || 'image/jpeg'})); });
            };
            try { TMNNApp.takePhoto('__itCamResult'); return; } catch (e) {}
        }
        if (window.isSecureContext && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            facing = 'environment';
            start().catch(function () { if (fallbackInput) fallbackInput.click(); });
            return;
        }
        if (fallbackInput) fallbackInput.click();
        // Laptop/PC lewat http:// tidak diizinkan browser membuka webcam langsung.
        if (window.matchMedia('(pointer: fine)').matches && !window.TMNNApp && window.chatToast) {
            window.chatToast(<?= json_encode(currentLang() === 'en'
                ? 'The browser only opens the webcam directly over HTTPS. For now, choose a photo file.'
                : 'Webcam laptop hanya bisa dibuka langsung bila sistem memakai HTTPS. Untuk sementara pilih file foto.') ?>);
        }
    };
})();
</script>

<!-- ===== Chat Grup: angka belum dibaca di menu + notifikasi pesan baru (semua user) ===== -->
<div id="chatNotif" class="hidden fixed top-4 right-4 z-[90] w-[min(360px,calc(100%-2rem))]"></div>
<div id="chatToastMsg" class="hidden fixed bottom-24 lg:bottom-6 right-4 z-[90] max-w-sm bg-slate-900 text-white text-sm rounded-lg px-4 py-2.5 shadow-lg"></div>
<script>
(function () {
    function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
    var tt;
    window.chatToast = function (msg, bad) {
        var t = document.getElementById('chatToastMsg'); t.textContent = msg; t.classList.toggle('bg-red-700', !!bad); t.classList.toggle('bg-slate-900', !bad);
        t.classList.remove('hidden'); clearTimeout(tt); tt = setTimeout(function () { t.classList.add('hidden'); }, 4000);
    };
    // Angka pesan belum dibaca di menu Chat Grup (sidebar & menu bawah HP)
    window.chatSetBadge = function (n) {
        Array.prototype.forEach.call(document.querySelectorAll('a[href="chat.php"]'), function (a) {
            var b = a.querySelector('.chat-badge');
            if (!n) { if (b) b.remove(); return; }
            if (!b) {
                b = document.createElement('span');
                var inBottom = !!a.closest('#bottomNav');
                b.className = 'chat-badge bg-red-500 text-white text-[10px] font-bold rounded-full px-1.5 leading-4 ' + (inBottom ? 'absolute -top-1 right-0' : 'ml-auto');
                (inBottom ? (a.querySelector('span') || a) : a).appendChild(b);
            }
            b.textContent = n > 99 ? '99+' : n;
        });
    };
    var KEY = 'chatNotified_<?= (int)($_SESSION['user_id'] ?? 0) ?>', nt;
    function getSeen() { try { return +(localStorage.getItem(KEY) || 0); } catch (e) { return 0; } }
    function setSeen(v) { try { localStorage.setItem(KEY, String(v)); } catch (e) {} }
    function show(m) {
        var box = document.getElementById('chatNotif');
        box.innerHTML = '<a href="chat.php?g=' + m.g + '&m=' + m.id + '" class="flex gap-3 bg-white rounded-xl shadow-xl border border-slate-200 border-l-4 ' + (m.mention ? 'border-l-amber-500' : 'border-l-blue-600') + ' p-3">'
            + '<span class="w-9 h-9 rounded-full bg-blue-600 text-white grid place-items-center font-bold shrink-0">' + esc(m.group.charAt(0).toUpperCase()) + '</span>'
            + '<span class="min-w-0"><b class="block text-sm text-slate-800">' + (m.mention ? '<?= currentLang() === 'en' ? 'You were mentioned in ' : 'Anda disebut di ' ?>' : '') + esc(m.group) + '</b>'
            + '<span class="block text-sm text-slate-600 truncate">' + esc(m.text) + '</span></span></a>';
        box.classList.remove('hidden'); clearTimeout(nt); nt = setTimeout(function () { box.classList.add('hidden'); }, 8000);
    }
    function check() {
        var since = getSeen();
        fetch('chat_api.php?a=unread&since=' + since, {credentials: 'same-origin'}).then(function (r) { return r.json(); }).then(function (d) {
            if (!d || !d.ok) return;
            if (!(window.CHAT_CUR && document.getElementById('chatApp'))) window.chatSetBadge(d.total);
            if (!since) { setSeen(d.max_id || 0); return; }       // pertama kali: jangan bunyikan pesan lama
            if (!d.new || !d.new.length) { if (d.max_id > since) setSeen(d.max_id); return; }
            setSeen(Math.max(d.max_id, since));
            var fresh = d.new.filter(function (m) { return !(window.CHAT_CUR === m.g && document.visibilityState === 'visible'); });
            if (!fresh.length) return;
            show(fresh[fresh.length - 1]);
            // Di dalam aplikasi Android: bunyi & notifikasi HP memakai jalur yang sama dengan notifikasi tiket.
            if (window.TMNNApp && TMNNApp.ticketAlert) {
                try { TMNNApp.ticketAlert(JSON.stringify(fresh.map(function (m) { return {id: 800000000 + m.id, ticket_number: 'Chat · ' + m.group, pelapor: m.group, department: '', location: '', problem_detail: m.text, created_at: ''}; }))); } catch (e) {}
            }
        }).catch(function () {});
    }
    check();
    setInterval(check, 15000);   // cek pesan chat baru tiap 15 detik
})();
</script>
<script>
// Tombol Esc menutup pop-up yang sedang terbuka (sama seperti menekan tombol X di pojok kanan atas).
document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    var open = Array.prototype.filter.call(document.querySelectorAll('.fixed.inset-0'), function (m) {
        return !m.classList.contains('hidden') && getComputedStyle(m).display !== 'none' && m.querySelector('[data-modal-close]');
    });
    if (open.length) open[open.length - 1].querySelector('[data-modal-close]').click();
});
</script>
<?php
// Ajakan donasi: hanya untuk admin, muncul setiap aplikasi dibuka sampai kode donatur dimasukkan (lihat includes/donate.php)
if (function_exists('isAdmin') && isAdmin()):
    require_once __DIR__ . '/donate.php';
    if (!donateIsDonor()):
        $dEn = function_exists('currentLang') && currentLang() === 'en';
?>
<div id="donateModal" class="hidden fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/50 print:hidden">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-sm max-h-[92vh] overflow-y-auto">
        <div class="px-5 pt-5 pb-3 text-center">
            <h3 class="font-semibold text-slate-800 text-lg"><?= $dEn ? 'Support this app' : 'Dukung aplikasi ini' ?></h3>
            <p class="mt-1 text-sm text-slate-500"><?= $dEn
                ? 'This app is free and open source. If it helps your work, a donation keeps it maintained.'
                : 'Aplikasi ini gratis dan open source. Bila bermanfaat untuk pekerjaan Anda, donasi membantu pengembangannya.' ?></p>
            <img src="assets/img/saweria-qr.png" alt="QR Saweria" width="311" height="321" class="mx-auto mt-3 w-36 h-auto">
            <a href="<?= htmlspecialchars(DONATE_SAWERIA_URL) ?>" target="_blank" rel="noopener" class="mt-3 inline-flex items-center justify-center w-full bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg px-4 py-2 text-sm"><?= $dEn ? 'Donate via Saweria' : 'Donasi lewat Saweria' ?></a>
        </div>
        <form id="donateForm" class="px-5 py-3 border-t bg-slate-50 rounded-b-xl" autocomplete="off">
            <label for="donateCode" class="block text-xs font-medium text-slate-600"><?= $dEn ? 'Already donated? Enter your donor code (sent by the developer):' : 'Sudah donasi? Masukkan kode donatur (dikirim oleh pengembang):' ?></label>
            <div class="mt-1.5 flex gap-2">
                <input id="donateCode" type="text" placeholder="DNR1...." class="flex-1 min-w-0 border rounded-lg px-3 py-2 text-sm font-mono">
                <button type="submit" class="px-3 py-2 rounded-lg bg-brand-600 text-white hover:bg-brand-700 text-sm"><?= $dEn ? 'Activate' : 'Aktifkan' ?></button>
            </div>
            <?php if (DONATE_CONTACT_WA !== '' || DONATE_CONTACT_EMAIL !== ''): ?>
            <p class="mt-1.5 text-xs text-slate-500"><?= $dEn ? 'Donated but have no code? Send your donation proof to the developer:' : 'Sudah donasi tapi belum punya kode? Kirim bukti donasi ke pengembang:' ?>
                <?php if (DONATE_CONTACT_WA !== ''): ?><a href="https://wa.me/<?= htmlspecialchars(DONATE_CONTACT_WA) ?>?text=<?= rawurlencode($dEn ? 'Hello, I have donated to ASKER IT Asset and would like a donor code.' : 'Halo, saya sudah donasi untuk ASKER IT Asset dan ingin meminta kode donatur.') ?>" target="_blank" rel="noopener" class="text-brand-700 underline">WhatsApp</a><?php endif; ?>
                <?php if (DONATE_CONTACT_WA !== '' && DONATE_CONTACT_EMAIL !== ''): ?> · <?php endif; ?>
                <?php if (DONATE_CONTACT_EMAIL !== ''): ?><a href="mailto:<?= htmlspecialchars(DONATE_CONTACT_EMAIL) ?>?subject=<?= rawurlencode('Kode donatur ASKER IT Asset') ?>" class="text-brand-700 underline">Email</a><?php endif; ?></p>
            <?php endif; ?>
            <p id="donateMsg" class="mt-1.5 text-xs min-h-[1rem]"></p>
            <button type="button" data-modal-close id="donateLater" class="mt-1 w-full px-3 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-white text-sm"><?= $dEn ? 'Later' : 'Nanti' ?></button>
        </form>
    </div>
</div>
<script>
(function () {
    var m = document.getElementById('donateModal'); if (!m) return;
    var KEY = 'donatePopupShown', seen = false;
    try { seen = sessionStorage.getItem(KEY) === '1'; } catch (e) {}
    if (!seen) {                                   // sekali tiap aplikasi dibuka (tab / sesi browser baru)
        m.classList.remove('hidden');
        try { sessionStorage.setItem(KEY, '1'); } catch (e) {}
    }
    document.getElementById('donateLater').addEventListener('click', function () { m.classList.add('hidden'); });
    document.getElementById('donateForm').addEventListener('submit', function (ev) {
        ev.preventDefault();
        var msg = document.getElementById('donateMsg'), fd = new FormData();
        fd.append('code', document.getElementById('donateCode').value);
        fd.append('csrf_token', <?= json_encode(csrfToken()) ?>);
        fetch('donate_activate.php', {method: 'POST', body: fd, credentials: 'same-origin'})
            .then(function (r) { return r.json(); })
            .then(function (d) {
                msg.className = 'mt-1.5 text-xs ' + (d.ok ? 'text-emerald-600' : 'text-red-600');
                msg.textContent = d.message || '';
                if (d.ok) setTimeout(function () { m.remove(); }, 1500);
            })
            .catch(function () { msg.className = 'mt-1.5 text-xs text-red-600'; msg.textContent = <?= json_encode($dEn ? 'Connection error.' : 'Koneksi gagal.') ?>; });
    });
})();
</script>
<?php endif; endif; ?>
</body>
</html>
