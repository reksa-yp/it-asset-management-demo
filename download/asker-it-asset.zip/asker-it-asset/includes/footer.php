        <footer class="mt-8 pt-4 pb-2 text-center text-xs text-slate-400 print:hidden">@Copyright by ASKER</footer>
    </main>
</div>
</div>

<?php if (function_exists('isAdmin') && isAdmin()): ?>
<!-- ===== Popup notifikasi tiket IT baru (khusus admin, tampil di semua halaman) ===== -->
<div id="ticketNotifyModal" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-md max-h-[80vh] flex flex-col">
        <div class="flex items-center justify-between px-5 py-4 border-b">
            <div class="flex items-center gap-2">
                <span class="flex h-8 w-8 items-center justify-center rounded-full bg-amber-100 text-amber-600"><?= icon('bell', 'w-4 h-4') ?></span>
                <h3 class="font-semibold text-slate-800"><?= t('ticket_notify_title') ?></h3>
            </div>
            <button type="button" data-modal-close id="btnCloseTicketNotify" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button>
        </div>
        <div id="ticketNotifyBody" class="px-5 py-4 overflow-y-auto space-y-3 text-sm">
            <!-- diisi otomatis lewat JavaScript -->
        </div>
        <div class="px-5 py-3 border-t flex justify-end gap-2">
            <button type="button" id="btnCloseTicketNotify2" class="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm"><?= t('btn_close') ?></button>
            <button type="button" id="btnGoToTicketing" class="px-4 py-2 rounded-lg bg-brand-600 text-white hover:bg-brand-700 text-sm"><?= t('btn_go_to_ticketing') ?></button>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
    // Cache-busting sama seperti style.css di header.php.
    $appJsPath = __DIR__ . '/../assets/js/app.js';
    $appJsVer  = is_file($appJsPath) ? filemtime($appJsPath) : time();
?>
<script src="assets/js/app.js?v=<?= $appJsVer ?>"></script>
<?php if (!empty($extraScripts)) echo $extraScripts; ?>
<?php if (function_exists('isAdmin') && isAdmin()): ?>
<script>
(function() {
    var modal   = document.getElementById('ticketNotifyModal');
    var body    = document.getElementById('ticketNotifyBody');
    var csrf    = '<?= htmlspecialchars(csrfToken(), ENT_QUOTES) ?>';
    var nameLabel       = '<?= htmlspecialchars(t('ticket_notify_name'), ENT_QUOTES) ?>';
    var departmentLabel = '<?= htmlspecialchars(t('field_department'), ENT_QUOTES) ?>';
    var locationLabel   = '<?= htmlspecialchars(t('field_location'), ENT_QUOTES) ?>';
    var pending = 0; // id tiket terbaru yang sedang ditampilkan di popup ini

    function escapeHtml(str) {
        var d = document.createElement('div');
        d.textContent = str;
        return d.innerHTML;
    }

    function infoRow(label, value) {
        return '<div class="flex gap-2">' +
               '<dt class="w-24 shrink-0 text-slate-400">' + label + '</dt>' +
               '<dd class="text-slate-700 font-medium break-words">' + escapeHtml(value || '-') + '</dd>' +
               '</div>';
    }

    function renderTickets(tickets) {
        body.innerHTML = tickets.map(function(t) {
            return '<div class="border border-slate-100 rounded-lg p-3">' +
                   '<div class="flex justify-between items-start gap-2">' +
                   '<span class="font-medium text-slate-800">' + escapeHtml(t.ticket_number) + '</span>' +
                   '<span class="text-xs text-slate-400 whitespace-nowrap">' + escapeHtml(t.created_at) + '</span>' +
                   '</div>' +
                   '<p class="text-slate-600 mt-1">' + escapeHtml(t.problem_detail) + '</p>' +
                   '<dl class="mt-2 pt-2 border-t border-slate-100 space-y-1 text-xs">' +
                   infoRow(nameLabel, t.pelapor) +
                   infoRow(departmentLabel, t.department) +
                   infoRow(locationLabel, t.location) +
                   '</dl>' +
                   '</div>';
        }).join('');
    }

    function showModal(tickets, maxId) {
        pending = maxId;
        renderTickets(tickets);
        modal.classList.remove('hidden');
    }

    function hideModal() {
        modal.classList.add('hidden');
        dismissPending();
    }

    // Kirim status "sudah dilihat" ke server. Pakai sendBeacon kalau tersedia supaya
    // requestnya tetap terkirim andal walau halaman langsung berpindah (contoh: saat
    // tombol "Lihat Ticketing" diklik dan browser langsung navigasi ke tickets.php).
    function dismissPending() {
        if (pending <= 0) return;
        var data = 'last_id=' + encodeURIComponent(pending) + '&csrf_token=' + encodeURIComponent(csrf);
        if (navigator.sendBeacon) {
            navigator.sendBeacon('ticket_notify_dismiss.php', new Blob([data], {type: 'application/x-www-form-urlencoded'}));
        } else {
            fetch('ticket_notify_dismiss.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: data
            }).catch(function() {});
        }
        pending = 0;
    }

    function goToTicketing() {
        dismissPending();
        modal.classList.add('hidden');
        window.location.href = 'tickets.php';
    }

    function checkNewTickets() {
        fetch('ticket_notify_check.php', {headers: {'X-Requested-With': 'XMLHttpRequest'}})
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (!data.ok || !data.tickets || data.tickets.length === 0) return;

                if (modal.classList.contains('hidden')) {
                    // popup belum tampil -> tampilkan seperti biasa
                    showModal(data.tickets, data.max_id);
                } else if (data.max_id > pending) {
                    // popup masih terbuka, tapi ada tiket LEBIH BARU yang masuk ->
                    // update daftar di popup yang sama tanpa menutupnya
                    showModal(data.tickets, data.max_id);
                }
            })
            .catch(function() {});
    }

    document.getElementById('btnCloseTicketNotify').addEventListener('click', hideModal);
    document.getElementById('btnCloseTicketNotify2').addEventListener('click', hideModal);
    document.getElementById('btnGoToTicketing').addEventListener('click', goToTicketing);
    modal.addEventListener('click', function(e) {
        if (e.target === modal) hideModal(); // klik di luar kotak = tutup manual juga
    });

    checkNewTickets();
    setInterval(checkNewTickets, 1000); // polling setiap 1 detik selama admin membuka halaman ini
})();
</script>
<!-- ===== Notifikasi CCTV mati / hidup kembali (khusus admin, lihat cctv_notify_check.php) ===== -->
<div id="cctvToast" class="hidden fixed bottom-4 right-4 z-50 w-[calc(100%-2rem)] max-w-sm bg-white rounded-xl shadow-xl border-l-4 border-red-500 print:hidden">
    <div class="flex items-center justify-between px-4 pt-3">
        <p class="font-semibold text-slate-800 flex items-center gap-2"><?= icon('camera', 'w-4 h-4') ?> CCTV</p>
        <button type="button" id="cctvToastClose" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-4 h-4') ?></button>
    </div>
    <div id="cctvToastBody" class="px-4 py-2 space-y-1.5 text-sm max-h-60 overflow-y-auto"></div>
    <div class="px-4 pb-3 flex justify-end gap-2">
        <button type="button" id="cctvToastClose2" class="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm"><?= t('btn_close') ?></button>
        <a href="cctv.php" id="cctvToastOpen" class="px-3 py-1.5 rounded-lg bg-brand-600 text-white hover:bg-brand-700 text-sm"><?= htmlspecialchars(cL('Buka CCTV', 'Open CCTV')) ?></a>
    </div>
</div>
<script>
(function () {
    var box = document.getElementById('cctvToast'), body = document.getElementById('cctvToastBody');
    var csrf = '<?= htmlspecialchars(csrfToken(), ENT_QUOTES) ?>', pending = 0, appAlerted = 0;
    function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
    function dismiss() {
        box.classList.add('hidden');
        if (pending <= 0) return;
        var data = 'last_id=' + encodeURIComponent(pending) + '&csrf_token=' + encodeURIComponent(csrf);
        if (navigator.sendBeacon) navigator.sendBeacon('cctv_notify_check.php', new Blob([data], {type: 'application/x-www-form-urlencoded'}));
        else fetch('cctv_notify_check.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: data}).catch(function () {});
    }
    function check() {
        fetch('cctv_notify_check.php', {headers: {'X-Requested-With': 'XMLHttpRequest'}})
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d.ok || !d.items || !d.items.length || d.max_id <= pending) return;
                pending = d.max_id;
                var down = d.items.some(function (i) { return i.type === 'down' || i.type === 'report'; });
                box.classList.toggle('border-red-500', down);
                box.classList.toggle('border-green-500', !down);
                body.innerHTML = d.items.map(function (i) {
                    return '<div class="flex gap-2"><span class="mt-1.5 w-2 h-2 rounded-full shrink-0 ' + (i.type === 'down' ? 'bg-red-500' : (i.type === 'report' ? 'bg-amber-500' : 'bg-green-500')) + '"></span>' +
                           '<div><p class="text-slate-700">' + esc(i.message) + '</p><p class="text-xs text-slate-400">' + esc(i.created_at) + '</p></div></div>';
                }).join('');
                box.classList.remove('hidden');
                // Di dalam aplikasi Android: bunyikan nada notifikasi yang sama dengan tiket.
                if (window.TMNNApp && TMNNApp.ticketAlert && d.max_id > appAlerted) {
                    appAlerted = d.max_id;
                    try {
                        TMNNApp.ticketAlert(JSON.stringify(d.items.map(function (i) {
                            return {id: i.id, ticket_number: 'CCTV', pelapor: 'Monitoring CCTV', department: '', location: '', problem_detail: i.message, created_at: i.created_at};
                        })));
                    } catch (e) {}
                }
            })
            .catch(function () {});
    }
    document.getElementById('cctvToastClose').addEventListener('click', dismiss);
    document.getElementById('cctvToastClose2').addEventListener('click', dismiss);
    document.getElementById('cctvToastOpen').addEventListener('click', dismiss);
    check();
    setInterval(check, 30000); // cek pemberitahuan CCTV tiap 30 detik
})();
</script>
<?php endif; ?>
<script>
// Tombol Esc menutup pop-up yang sedang terbuka (sama seperti menekan tombol X di pojok kanan atas).
document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    var open = Array.prototype.filter.call(document.querySelectorAll('.fixed.inset-0'), function (m) {
        return !m.classList.contains('hidden') && getComputedStyle(m).display !== 'none' && m.querySelector('[data-modal-close]');
    });
    if (open.length) open[open.length - 1].querySelector('[data-modal-close]').click();
});
</script>
</body>
</html>
