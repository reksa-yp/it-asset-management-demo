<?php
/**
 * Import Excel GABUNGAN Aset + User (template_aset_user.xlsx).
 *
 * 1 baris = 1 aset beserta 1 penggunanya, diisi sekali jalan:
 *   - Bagian USER : sama dengan isian menu Tambah User (Nama Lengkap, Username, Email,
 *                   Departement, Password, Username PC, Password PC, Role, Status).
 *   - Bagian ASET : sama dengan isian menu Tambah Aset (Kategori, Nama Perangkat, Status,
 *                   Lokasi, Serial Number, Tanggal Pembelian, jaringan, hardware, OS,
 *                   software, dan isian khusus Tablet).
 *
 * Aturan:
 *   - User dicocokkan lewat Username (kalau kosong, lewat Nama Lengkap). User baru wajib
 *     punya Nama Lengkap, Username, dan Password. User lama hanya diperbarui kolom yang diisi.
 *   - Aset dicocokkan lewat ID Aset (kalau kosong: lewat Serial Number). Aset baru tanpa ID Aset -> nomor otomatis.
 *     Aset lama hanya diperbarui kolom yang diisi.
 *   - 1 aset dipakai beberapa user: tulis beberapa baris dengan ID Aset yang sama,
 *     masing-masing dengan user yang berbeda.
 *   - Baris yang hanya berisi user (tanpa Kategori & ID Aset) -> hanya user yang disimpan.
 *   - Baris yang hanya berisi aset (tanpa user) -> aset Stok / tanpa pengguna.
 *
 * Tidak mengubah struktur database. Transaksi (commit/rollback) diatur pemanggil.
 */
require_once __DIR__ . '/categories.php';
require_once __DIR__ . '/asset_number.php';
require_once __DIR__ . '/tablet.php';
require_once __DIR__ . '/tablet_excel.php';

/** Kolom template: judul => [kunci, grup]. Urutan = urutan kolom di Excel. */
function assetUserImportColumns(): array
{
    return [
        // ----- USER -----
        'Nama Lengkap'           => ['full_name',   'user'],
        'Username'               => ['username',    'user'],
        'Email'                  => ['email',       'user'],
        'Departement'            => ['department',  'user'],
        'Password'               => ['password',    'user'],
        'Username PC'            => ['pc_username', 'user'],
        'Password PC'            => ['pc_password', 'user'],
        'Role'                   => ['role',        'user'],
        'Status User'            => ['user_status', 'user'],
        // ----- ASET -----
        'ID Aset'                => ['asset_number',      'asset'],
        'Kategori'               => ['category',          'asset'],
        'Nama Perangkat'         => ['device_name',       'asset'],
        'Status Aset'            => ['status',            'asset'],
        'Lokasi'                 => ['location',          'asset'],
        'Serial Number'          => ['serial_number',     'asset'],
        'Tanggal Pembelian'      => ['purchase_date',     'asset'],
        'IP Address'             => ['ip_address',        'asset'],
        'Hostname'               => ['hostname',          'asset'],
        'Processor'              => ['processor',         'asset'],
        'RAM'                    => ['ram',               'asset'],
        'Penyimpanan'            => ['storage',           'asset'],
        'Motherboard/Brand'      => ['motherboard_brand', 'asset'],
        'Monitor'                => ['monitor_info',      'asset'],
        'Printer'                => ['printer_info',      'asset'],
        'Aksesoris'              => ['accessories',       'asset'],
        'OS'                     => ['os_name',           'asset'],
        'Status OS'              => ['os_status',         'asset'],
        'Software'               => ['software',          'asset'],
        'Serial Number Software' => ['software_serial',   'asset'],
        'Status Software'        => ['software_status',   'asset'],
        'ID Tablet'              => ['tablet_id',         'asset'],
        'Kondisi Tablet'         => ['tablet_condition',  'asset'],
    ];
}

/** Sheet dianggap format gabungan Aset + User jika punya kolom Username/Nama Lengkap DAN Kategori/ID Aset. */
function isAssetUserXlsHeader(array $headerRow): bool
{
    $t = array_map(fn($v) => mb_strtolower(trim((string)$v)), $headerRow);
    return (in_array('username', $t, true) || in_array('nama lengkap', $t, true))
        && (in_array('kategori', $t, true) || in_array('id aset', $t, true));
}

/** Tulis sheet template (header berwarna per grup, contoh isian, pilihan dropdown) + sheet Petunjuk. */
function writeAssetUserTemplate(\PhpOffice\PhpSpreadsheet\Spreadsheet $ss, array $categoryNames): void
{
    $cols  = assetUserImportColumns();
    $sheet = $ss->getActiveSheet();
    $sheet->setTitle('Aset & User');
    $titles = array_keys($cols);
    $sheet->fromArray($titles, null, 'A1');

    $examples = [
        ['Budi Santoso', 'budi', 'budi@perusahaan.co.id', 'Finance', 'Budi#2026', 'budi.pc', 'PcBudi123', 'user', 'Aktif',
         '', 'Laptop', 'Lenovo ThinkPad E14', '', 'Lantai 2', 'PF3XK21A', '2025-03-14', '192.168.1.45', 'LT-FIN-01',
         'Intel Core i5-1135G7', '8 GB', 'SSD 512 GB', 'Lenovo ThinkPad E14', '', '', 'Mouse Logitech B100',
         'Windows 11 Pro', 'Original', 'Microsoft Office 2021; Anydesk', 'XXXXX-11111; -', 'Original; Original', '', ''],
        ['Siti Rahmawati', 'siti', 'siti@perusahaan.co.id', 'HRD', 'Siti#2026', '', '', 'user', 'Aktif',
         '', 'Desktop PC', 'PC-HRD-01', '', 'Ruang HRD', 'SN771024', '2024-08-01', '192.168.1.60', 'PC-HRD-01',
         'Intel Core i3-10100', '8 GB', 'SSD 256 GB', 'ASUS PRIME H510M', 'LG 22MK430', 'Epson L3210', '',
         'Windows 10 Pro', 'Original', 'Microsoft Office 2019', '', 'Original', '', ''],
        ['Andi Pratama', 'andi', '', 'Produksi', 'Andi#2026', '', '', 'user', 'Aktif',
         '', 'Tablet', 'Samsung Galaxy Tab A9+', '', 'Line 1', 'R9TW20ABC', '2025-01-10', '192.168.1.120', '',
         '', '4 GB', '64 GB', 'Samsung Galaxy Tab A9+', '', '', '', 'Android 14', 'Original', '', '', '', 'TAB-PRD-01', 'Bagus'],
        ['', '', '', 'IT', '', '', '', '', '',
         '', 'Monitor', 'Dell E2220H', 'Stok', 'Gudang IT', 'CN0H6X', '2025-06-02', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''],
    ];
    $sheet->fromArray($examples, null, 'A2');

    $n = count($titles);
    $lastCol = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($n);
    $lastRow = 1 + count($examples);
    $i = 0;
    foreach ($cols as $title => [$key, $group]) {
        $i++;
        $col = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i);
        $style = $sheet->getStyle($col . '1');
        $style->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
        $style->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
              ->getStartColor()->setRGB($group === 'user' ? '0F766E' : '1F3DD1');
        $style->getAlignment()->setHorizontal('center')->setVertical('center')->setWrapText(true);
        $sheet->getColumnDimension($col)->setWidth(max(12, min(34, mb_strlen($title) + 6)));
        // Tanggal Pembelian ditulis sebagai teks supaya tidak berubah format
        if ($key === 'purchase_date') {
            $sheet->getStyle("{$col}2:{$col}1000")->getNumberFormat()->setFormatCode('@');
        }
        // Pilihan dropdown supaya isian seragam
        $list = [
            'role'             => '"user,admin"',
            'user_status'      => '"Aktif,Nonaktif"',
            'status'           => '"Digunakan,Stok,Tidak Digunakan"',
            'os_status'        => '"Original,Belum Original"',
            'tablet_condition' => '"Bagus,Rusak"',
            'category'         => $categoryNames ? '"' . implode(',', array_map(fn($c) => str_replace(['"', ','], '', $c), $categoryNames)) . '"' : null,
        ][$key] ?? null;
        if ($list && strlen($list) <= 255) {
            $dv = $sheet->getCell($col . '2')->getDataValidation();
            $dv->setType(\PhpOffice\PhpSpreadsheet\Cell\DataValidation::TYPE_LIST)
               ->setErrorStyle(\PhpOffice\PhpSpreadsheet\Cell\DataValidation::STYLE_INFORMATION)
               ->setAllowBlank(true)->setShowDropDown(true)->setFormula1($list);
            $sheet->setDataValidation("{$col}2:{$col}1000", clone $dv);
        }
    }
    $sheet->getRowDimension(1)->setRowHeight(32);
    $sheet->freezePane('C2');
    $sheet->getStyle("A1:{$lastCol}{$lastRow}")->getBorders()->getAllBorders()
          ->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN)->getColor()->setRGB('CBD5E1');
    $sheet->getStyle("A2:{$lastCol}{$lastRow}")->getFont()->getColor()->setRGB('64748B');

    // Sheet Petunjuk (tidak ikut di-import)
    $help = $ss->createSheet();
    $help->setTitle('Petunjuk');
    $lines = [
        'Petunjuk Import Aset + User',
        '',
        '1. Satu baris = satu aset beserta satu penggunanya. Kolom hijau = data USER, kolom biru = data ASET.',
        '2. Baris contoh (teks abu-abu) boleh dihapus atau ditimpa sebelum di-upload.',
        '3. USER dicocokkan lewat Username. Username yang sudah ada -> diperbarui, yang belum ada -> dibuat baru.',
        '   User baru WAJIB diisi Nama Lengkap, Username, dan Password. Untuk user lama, Password boleh dikosongkan (tidak diubah).',
        '4. Role: user / admin (default user). Status User: Aktif / Nonaktif (default Aktif).',
        '5. ASET dicocokkan lewat ID Aset (kalau ID Aset kosong: lewat Serial Number). Aset baru tanpa ID Aset dibuat nomor otomatis ({PREFIX}/Departement/Jenis/Urutan;',
        '   khusus Tablet: {PREFIX}/Departement/Line/Urutan, Line diambil dari kolom Lokasi).',
        '6. Kategori harus sama dengan daftar di menu Kategori Aset: ' . implode(', ', $categoryNames) . '.',
        '7. Status Aset: Digunakan / Stok / Tidak Digunakan. Kalau kosong: Digunakan jika ada user, Stok jika tanpa user.',
        '8. Departement, Email, Username PC & Password PC aset otomatis mengikuti data user pertamanya (sama seperti form Aset).',
        '9. Satu aset dipakai beberapa user: tulis beberapa baris dengan ID Aset yang sama, isi user yang berbeda di tiap baris.',
        '10. Software lebih dari satu dipisah titik koma (;). Serial Number & Status Software diisi berurutan, "-" jika tidak ada serial.',
        '11. Tanggal Pembelian: format 2025-03-14 atau 14/03/2025.',
        '12. ID Tablet & Kondisi Tablet (Bagus/Rusak) hanya dipakai untuk Kategori Tablet.',
        '13. Data yang sudah ada hanya diubah pada kolom yang diisi. Kolom kosong tidak menghapus data lama.',
        '14. Baris hanya berisi user (tanpa Kategori & ID Aset) -> hanya user yang disimpan.',
        '15. Import ulang file yang sama aman selama ID Aset atau Serial Number terisi. Aset tanpa ID Aset DAN tanpa Serial Number akan dibuat baru lagi.',
    ];
    foreach ($lines as $k => $line) {
        $help->setCellValue('A' . ($k + 1), str_replace('{PREFIX}', assetPrefix(), $line));
    }
    $help->getStyle('A1')->getFont()->setBold(true)->setSize(13);
    $help->getColumnDimension('A')->setWidth(130);
    $ss->setActiveSheetIndex(0);
}

/** Baca & simpan isi sheet gabungan. Return ringkasan + daftar pesan per baris. */
function importAssetUserSheet(PDO $db, \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet): array
{
    $out = ['users_new' => 0, 'users_upd' => 0, 'assets_new' => 0, 'assets_upd' => 0, 'skipped' => 0, 'errors' => []];
    $cols = assetUserImportColumns();

    // Petakan judul kolom -> huruf kolom (tanpa beda huruf besar/kecil)
    $byLower = [];
    foreach ($cols as $title => [$key]) $byLower[mb_strtolower($title)] = $key;
    $byLower['status'] = 'status';                 // judul lama/alternatif
    $byLower['motherboard/brand type'] = 'motherboard_brand';
    $byLower['hardisk'] = 'storage';
    $byLower['email pengguna'] = 'email';
    $byLower['status kondisi'] = 'tablet_condition';

    $highestCol = $sheet->getHighestDataColumn();
    $highestRow = $sheet->getHighestDataRow();
    $header = $sheet->rangeToArray("A1:{$highestCol}1", null, true, false, true)[1] ?? [];
    $map = [];
    foreach ($header as $letter => $title) {
        $k = $byLower[mb_strtolower(trim((string)$title))] ?? null;
        if ($k && !isset($map[$k])) $map[$k] = $letter;
    }

    $categories = getAssetCategories($db);
    $catByLower = [];
    foreach ($categories as $c) $catByLower[mb_strtolower($c['name'])] = $c;

    $findUserByUsername = $db->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
    $findUserByName     = $db->prepare("SELECT * FROM users WHERE full_name = ? LIMIT 1");
    $findAsset          = $db->prepare("SELECT * FROM assets WHERE asset_number = ? LIMIT 1");
    $findSerial         = $db->prepare("SELECT * FROM assets WHERE serial_number = ? ORDER BY id LIMIT 1");
    ensureTabletTable($db);   // tabel detail tablet dibuat jika belum ada

    $userCache = [];          // username/nama (lower) -> user id
    $assetOwners = [];        // asset id -> [user ids dari file]
    $touchedAssets = [];      // asset id -> true
    $changedUsers = [];       // user id -> true
    $explicitStatus = [];     // asset id -> true jika kolom Status Aset diisi

    for ($r = 2; $r <= $highestRow; $r++) {
        // Nilai tampil (seperti yang terlihat di Excel) untuk semua kolom; nilai asli untuk tanggal.
        $rowFmt = $sheet->rangeToArray("A{$r}:{$highestCol}{$r}", null, true, true, true)[$r] ?? [];
        $rowRaw = $sheet->rangeToArray("A{$r}:{$highestCol}{$r}", null, true, false, true)[$r] ?? [];
        $get = function (string $k, bool $raw = false) use ($map, $rowFmt, $rowRaw) {
            if (!isset($map[$k])) return '';
            $v = ($raw ? $rowRaw : $rowFmt)[$map[$k]] ?? '';
            return is_string($v) ? trim($v) : $v;
        };
        $s = fn(string $k) => trim((string)$get($k));

        $hasUser  = $s('username') !== '' || $s('full_name') !== '';
        $hasAsset = $s('category') !== '' || $s('asset_number') !== '';
        if (!$hasUser && !$hasAsset) continue;               // baris kosong
        $label = "Baris $r";

        // ================= USER =================
        $userId = null;
        if ($hasUser) {
            $username = $s('username');
            $fullName = $s('full_name');
            $cacheKey = mb_strtolower($username !== '' ? 'u:' . $username : 'n:' . $fullName);
            if (isset($userCache[$cacheKey])) {
                $userId = $userCache[$cacheKey];
            } else {
                $existing = null;
                if ($username !== '') { $findUserByUsername->execute([$username]); $existing = $findUserByUsername->fetch() ?: null; }
                elseif ($fullName !== '') { $findUserByName->execute([$fullName]); $existing = $findUserByName->fetch() ?: null; }

                $roleRaw = mb_strtolower($s('role'));
                $role = in_array($roleRaw, ['admin', 'user'], true) ? $roleRaw : null;
                $stRaw = mb_strtolower($s('user_status'));
                $active = in_array($stRaw, ['nonaktif', 'tidak aktif', 'inactive', '0', 'tidak', 'no'], true) ? 0
                        : ($stRaw !== '' ? 1 : null);
                $fields = [
                    'full_name' => $fullName, 'email' => $s('email'), 'department' => $s('department'),
                    'pc_username' => $s('pc_username'), 'pc_password' => $s('pc_password'),
                ];
                if ($existing) {
                    $set = []; $params = [];
                    foreach ($fields as $col => $v) { if ($v !== '') { $set[] = "$col = ?"; $params[] = $v; } }
                    if ($role !== null)   { $set[] = 'role = ?';      $params[] = $role; }
                    if ($active !== null) { $set[] = 'is_active = ?'; $params[] = $active; }
                    if ($s('password') !== '') { $set[] = 'password = ?'; $params[] = password_hash($s('password'), PASSWORD_BCRYPT); }
                    if ($set) {
                        $params[] = (int)$existing['id'];
                        $db->prepare("UPDATE users SET " . implode(', ', $set) . " WHERE id = ?")->execute($params);
                        $out['users_upd']++;
                        $changedUsers[(int)$existing['id']] = true;
                    }
                    $userId = (int)$existing['id'];
                } elseif ($username === '' || $fullName === '' || $s('password') === '') {
                    $out['errors'][] = "$label: user baru " . ($fullName ?: $username) . " dilewati (wajib isi Nama Lengkap, Username, Password).";
                } else {
                    $db->prepare("INSERT INTO users (full_name, username, email, department, password, pc_username, pc_password, role, is_active)
                                  VALUES (?,?,?,?,?,?,?,?,?)")
                       ->execute([$fullName, $username, $fields['email'] ?: null, $fields['department'] ?: null,
                                  password_hash($s('password'), PASSWORD_BCRYPT), $fields['pc_username'] ?: null,
                                  $fields['pc_password'] ?: null, $role ?? 'user', $active ?? 1]);
                    $userId = (int)$db->lastInsertId();
                    $out['users_new']++;
                }
                if ($userId) $userCache[$cacheKey] = $userId;
            }
        }

        if (!$hasAsset) continue;

        // ================= ASET =================
        $catRaw = $s('category');
        $assetNumber = $s('asset_number');
        $existingAsset = null;
        if ($assetNumber !== '') { $findAsset->execute([$assetNumber]); $existingAsset = $findAsset->fetch() ?: null; }
        // ID Aset kosong tapi Serial Number diisi -> cocokkan lewat Serial Number supaya import ulang tidak membuat aset ganda
        if (!$existingAsset && $assetNumber === '' && $s('serial_number') !== '') {
            $findSerial->execute([$s('serial_number')]);
            $existingAsset = $findSerial->fetch() ?: null;
            if ($existingAsset) $assetNumber = $existingAsset['asset_number'];
        }

        $cat = $catRaw !== '' ? ($catByLower[mb_strtolower($catRaw)] ?? null) : null;
        if ($catRaw !== '' && !$cat) {
            $out['errors'][] = "$label: Kategori \"$catRaw\" tidak dikenal, aset dilewati.";
            $out['skipped']++;
            continue;
        }
        if (!$existingAsset && !$cat) {
            $out['errors'][] = "$label: aset baru wajib diisi Kategori, aset dilewati.";
            $out['skipped']++;
            continue;
        }
        $category = $cat ? $cat['name'] : $existingAsset['category'];
        $isTablet = isTabletCategory($category);

        // Departement untuk nomor otomatis: dari user baris ini, kolom Departement, atau data aset lama
        $dept = $s('department');
        if ($dept === '' && $userId) {
            $d = $db->prepare("SELECT department FROM users WHERE id = ?"); $d->execute([$userId]);
            $dept = (string)$d->fetchColumn();
        }

        if (!$existingAsset && $assetNumber === '') {
            if ($isTablet) {
                $assetNumber = nextTabletAssetNumber($db, $dept, $s('location')) ?? '';
                if ($assetNumber === '') {
                    $out['errors'][] = "$label: Tablet tanpa ID Aset wajib diisi Lokasi (Line) untuk nomor otomatis, aset dilewati.";
                    $out['skipped']++;
                    continue;
                }
            } else {
                $assetNumber = nextAssetNumber($db, getCategoryAbbr($db, $category) ?: 'AST', generateDeptAbbr($dept));
            }
        }
        if (mb_strlen($assetNumber) > 30) {
            $out['errors'][] = "$label: ID Aset \"$assetNumber\" lebih dari 30 karakter, aset dilewati.";
            $out['skipped']++;
            continue;
        }

        // Kolom teks biasa
        $data = [];
        foreach (['device_name', 'location', 'serial_number', 'ip_address', 'hostname', 'processor', 'ram', 'storage',
                  'motherboard_brand', 'monitor_info', 'printer_info', 'accessories', 'os_name'] as $k) {
            if ($s($k) !== '') $data[$k] = mb_substr($s($k), 0, $k === 'ip_address' ? 45 : 150);
        }
        if ($cat) $data['category'] = $category;
        $stRaw = $s('status');
        $stMap = ['digunakan' => 'Digunakan', 'in use' => 'Digunakan', 'stok' => 'Stok', 'in stock' => 'Stok',
                  'tidak digunakan' => 'Tidak Digunakan', 'not in use' => 'Tidak Digunakan'];
        if ($stRaw !== '') {
            if (!isset($stMap[mb_strtolower($stRaw)])) $out['errors'][] = "$label: Status Aset \"$stRaw\" tidak dikenal, diabaikan.";
            else $data['status'] = $stMap[mb_strtolower($stRaw)];
        }
        if ($s('os_status') !== '') $data['os_status'] = mb_strtolower($s('os_status')) === 'original' ? 'Original' : 'Belum Original';
        $pdRaw = $get('purchase_date', true);
        $pd = tabletParseDate($pdRaw === '' ? null : $pdRaw);
        if ($pd === false) $out['errors'][] = "$label: Tanggal Pembelian tidak dikenali, diabaikan.";
        elseif ($pd) $data['purchase_date'] = $pd;

        $statusGiven = isset($data['status']);
        if ($existingAsset) {
            $assetId = (int)$existingAsset['id'];
            if ($data) {
                $set = implode(', ', array_map(fn($k) => "`$k` = ?", array_keys($data)));
                $db->prepare("UPDATE assets SET $set WHERE id = ?")->execute([...array_values($data), $assetId]);
            }
            if (!isset($touchedAssets[$assetId])) $out['assets_upd']++;
        } else {
            $data['asset_number'] = $assetNumber;
            $data['category'] = $category;
            $data['status'] = $data['status'] ?? ($userId ? 'Digunakan' : 'Stok');
            $data['os_status'] = $data['os_status'] ?? 'Belum Original';
            if (!$userId && $s('department') !== '') $data['department'] = $s('department');
            $colsSql = implode(', ', array_map(fn($k) => "`$k`", array_keys($data)));
            $db->prepare("INSERT INTO assets ($colsSql) VALUES (" . implode(',', array_fill(0, count($data), '?')) . ")")
               ->execute(array_values($data));
            $assetId = (int)$db->lastInsertId();
            $out['assets_new']++;
            // Supaya baris berikutnya dengan ID Aset yang sama (atau nomor otomatis) menemukan aset ini
        }
        $touchedAssets[$assetId] = true;
        if ($statusGiven) $explicitStatus[$assetId] = true;
        if ($userId) $assetOwners[$assetId][] = $userId;

        // Software (lebih dari satu dipisah ;) -> ganti daftar software aset
        if ($s('software') !== '') {
            $names = array_map('trim', explode(';', $s('software')));
            $serials = array_map('trim', explode(';', $s('software_serial')));
            $stats = array_map('trim', explode(';', $s('software_status')));
            $items = [];
            foreach ($names as $i => $nm) {
                if ($nm === '') continue;
                $ser = $serials[$i] ?? '';
                $items[] = ['name' => $nm, 'serial' => $ser === '-' ? '' : $ser, 'original' => mb_strtolower($stats[$i] ?? '') === 'original'];
            }
            setAssetSoftware($db, $assetId, $items);
        }

        // Isian khusus Tablet
        if ($isTablet && ($s('tablet_id') !== '' || $s('tablet_condition') !== '')) {
            $cur = getTabletDetailsMap($db, [$assetId])[$assetId] ?? ['tablet_id' => '', 'tablet_condition' => 'Bagus'];
            $cond = tabletParseCondition($s('tablet_condition'));
            saveTabletDetails($db, $assetId,
                $s('tablet_id') !== '' ? $s('tablet_id') : (string)$cur['tablet_id'],
                $cond ?: (string)($cur['tablet_condition'] ?: 'Bagus'));
        }
    }

    // Pengguna aset = semua user yang tertulis untuk aset itu di file (aset tanpa user di file: pengguna lama tetap)
    foreach ($assetOwners as $assetId => $uids) {
        setAssetOwners($db, (int)$assetId, $uids);
        if (empty($explicitStatus[$assetId])) {   // punya pengguna & status tidak diisi -> Digunakan
            $db->prepare("UPDATE assets SET status = 'Digunakan' WHERE id = ? AND status = 'Stok'")->execute([(int)$assetId]);
        }
    }
    // Departement, Email, Username & Password PC aset mengikuti user pertamanya
    $sync = array_keys($assetOwners);
    if ($changedUsers) $sync = array_merge($sync, assetIdsOfUsers($db, array_keys($changedUsers)));
    if ($sync) syncAssetsUserData($db, array_values(array_unique(array_map('intval', $sync))));

    return $out;
}
