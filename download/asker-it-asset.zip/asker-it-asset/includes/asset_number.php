<?php
/**
 * Logika pembuatan Nomor Aset otomatis, format:
 *   <Awalan>/<Singkatan Departement>/<Singkatan Jenis Aset>/<Urutan 3 digit>
 *
 * Dipakai bersama oleh:
 *  - asset_generate_number.php       (satu aset, dipanggil dari modal Tambah/Edit)
 *  - asset_generate_number_bulk.php  (banyak aset sekaligus, dari tombol toolbar)
 */
require_once __DIR__ . '/categories.php';

/**
 * Singkatan Departement: kalau nama Departement sudah pendek & satu kata,
 * dipakai apa adanya (uppercase). Kalau beberapa kata, diambil huruf awal
 * tiap kata (maks 4 huruf). Kalau satu kata panjang, diambil 3 huruf awal.
 * Aset tanpa Departement (misal masih status Stok, belum ada pemilik)
 * memakai kode "STOK".
 */
function generateDeptAbbr(string $dept): string
{
    $dept = trim($dept);
    if ($dept === '') return 'STOK';

    $words = preg_split('/[\s\/\-_]+/', $dept, -1, PREG_SPLIT_NO_EMPTY);
    if (count($words) <= 1) {
        $w = $words[0] ?? $dept;
        return strtoupper(mb_substr($w, 0, mb_strlen($w) <= 5 ? mb_strlen($w) : 3));
    }
    $initials = '';
    foreach ($words as $w) {
        $initials .= mb_substr($w, 0, 1);
        if (mb_strlen($initials) >= 4) break;
    }
    return strtoupper($initials);
}

/**
 * Cari urutan tertinggi yang sudah dipakai untuk satu Jenis Aset (catAbbr),
 * lintas Departement manapun, dengan membaca digit di akhir Nomor Aset yang
 * formatnya <Awalan>/<apa saja>/<catAbbr>/<digit>. Nomor Aset lama yang tidak
 * mengikuti format ini otomatis diabaikan.
 */
function findMaxAssetSeq(PDO $db, string $catAbbr): int
{
    $stmt = $db->prepare("SELECT asset_number FROM assets WHERE asset_number LIKE ?");
    $stmt->execute([assetPrefix() . '/%/' . $catAbbr . '/%']);

    $max = 0;
    $pattern = '#^' . preg_quote(assetPrefix(), '#') . '/[^/]+/' . preg_quote($catAbbr, '#') . '/(\d+)$#i';
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $num) {
        if (preg_match($pattern, $num, $m)) {
            $max = max($max, (int)$m[1]);
        }
    }
    return $max;
}

/**
 * Buat satu usulan Nomor Aset yang belum terpakai, untuk kombinasi
 * Jenis Aset + Departement tertentu. $excludeId dipakai supaya nomor aset
 * milik aset yang sedang di-generate ulang sendiri tidak dianggap tabrakan.
 */
function nextAssetNumber(PDO $db, string $catAbbr, string $deptAbbr, ?int $excludeId = null): string
{
    $max = findMaxAssetSeq($db, $catAbbr);
    $next = $max + 1;

    $checkStmt = $db->prepare("SELECT COUNT(*) FROM assets WHERE asset_number = ?" . ($excludeId ? " AND id <> ?" : ""));
    do {
        $candidate = sprintf('%s/%s/%s/%03d', assetPrefix(), $deptAbbr, $catAbbr, $next);
        $params = $excludeId ? [$candidate, $excludeId] : [$candidate];
        $checkStmt->execute($params);
        $exists = (bool)$checkStmt->fetchColumn();
        if ($exists) $next++;
    } while ($exists);

    return $candidate;
}

/**
 * Departement yang dipakai untuk Nomor Aset: departement USER PERTAMA aset itu (urut nama,
 * sama dengan aturan includes/asset_user_sync.php). Tanpa pengguna -> $fallback (boleh kosong = STOK).
 */
function assetNumberDepartment(PDO $db, array $ownerIds, string $fallback = ''): string
{
    $ownerIds = array_values(array_unique(array_filter(array_map('intval', $ownerIds))));
    if ($ownerIds) {
        $stmt = $db->prepare("SELECT department FROM users WHERE id IN (" . implode(',', array_fill(0, count($ownerIds), '?')) . ")
                              ORDER BY full_name, id LIMIT 1");
        $stmt->execute($ownerIds);
        $dept = $stmt->fetchColumn();
        if ($dept !== false && trim((string)$dept) !== '') return trim((string)$dept);
    }
    return trim($fallback);
}

/**
 * Buat usulan Nomor Aset untuk 1 aset (dipakai tombol "Buatkan Otomatis" DAN saat Simpan dengan
 * Nomor Aset dikosongkan). Tablet memakai format khusus (lihat includes/tablet.php).
 * Return: ['ok' => true, 'asset_number' => ..] atau ['ok' => false, 'message' => ..]
 */
function suggestAssetNumber(PDO $db, string $category, string $department, string $location = '', ?int $excludeId = null): array
{
    if (trim($category) === '') return ['ok' => false, 'message' => t('gen_number_select_category_first')];
    if (function_exists('isTabletCategory') && isTabletCategory($category)) {
        $candidate = nextTabletAssetNumber($db, $department, trim($location), $excludeId);
        return $candidate === null
            ? ['ok' => false, 'message' => t('tablet_gen_need_location')]
            : ['ok' => true, 'asset_number' => $candidate];
    }
    $catAbbr = getCategoryAbbr($db, $category);
    if ($catAbbr === null) return ['ok' => false, 'message' => t('gen_number_invalid_category')];
    return ['ok' => true, 'asset_number' => nextAssetNumber($db, $catAbbr, generateDeptAbbr($department), $excludeId)];
}

