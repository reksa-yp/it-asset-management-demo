<?php
/**
 * Helper untuk daftar Software per aset (1 aset bisa punya lebih dari 1
 * software, masing-masing dengan Serial Number & status Original/Belum
 * Original sendiri-sendiri). Lihat tabel asset_software (migrasi "Daftar
 * Software Aset" di menu Upgrade Sistem).
 */

function assetSoftwareTableExists(PDO $db): bool
{
    static $exists = null;
    if ($exists === null) {
        $exists = (bool)$db->query("
            SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_software'
        ")->fetchColumn();
    }
    return $exists;
}

/** Ambil daftar software 1 aset, urut sesuai input. */
function getSoftwareForAsset(PDO $db, int $assetId): array
{
    if (!assetSoftwareTableExists($db)) return [];
    $stmt = $db->prepare("
        SELECT id, software_name, serial_number, status
        FROM asset_software WHERE asset_id = ? ORDER BY sort_order, id
    ");
    $stmt->execute([$assetId]);
    return $stmt->fetchAll();
}

/** Ambil daftar software untuk banyak aset sekaligus (hindari query N+1). */
function getAssetSoftwareMap(PDO $db, array $assetIds): array
{
    $assetIds = array_values(array_unique(array_filter(array_map('intval', $assetIds))));
    if (!$assetIds || !assetSoftwareTableExists($db)) return [];
    $placeholders = implode(',', array_fill(0, count($assetIds), '?'));
    $stmt = $db->prepare("
        SELECT asset_id, id, software_name, serial_number, status
        FROM asset_software WHERE asset_id IN ($placeholders) ORDER BY asset_id, sort_order, id
    ");
    $stmt->execute($assetIds);
    $map = [];
    foreach ($stmt->fetchAll() as $r) {
        $map[(int)$r['asset_id']][] = [
            'id'             => (int)$r['id'],
            'software_name'  => $r['software_name'],
            'serial_number'  => $r['serial_number'],
            'status'         => $r['status'],
        ];
    }
    return $map;
}

/**
 * Ganti seluruh daftar software 1 aset. $items = array of
 * ['name' => .., 'serial' => .., 'original' => bool]. Baris dengan nama
 * kosong dilewati (tidak disimpan).
 */
function setAssetSoftware(PDO $db, int $assetId, array $items): void
{
    if (!assetSoftwareTableExists($db)) return;
    $db->prepare("DELETE FROM asset_software WHERE asset_id = ?")->execute([$assetId]);
    if (!$items) return;
    $ins = $db->prepare("
        INSERT INTO asset_software (asset_id, software_name, serial_number, status, sort_order)
        VALUES (?, ?, ?, ?, ?)
    ");
    $order = 0;
    foreach ($items as $item) {
        $name = trim((string)($item['name'] ?? ''));
        if ($name === '') continue;
        $serial = trim((string)($item['serial'] ?? ''));
        $status = !empty($item['original']) ? 'Original' : 'Belum Original';
        $ins->execute([$assetId, $name, $serial !== '' ? $serial : null, $status, $order]);
        $order++;
    }
}

/** Ringkasan nama-nama software (dipisah koma), untuk tampilan ringkas. */
function softwareNamesLabel(array $items): string
{
    return $items ? implode(', ', array_column($items, 'software_name')) : '';
}
