<?php
/**
 * Topologi jaringan versi server (untuk Cetak & Simpan PDF). Susunannya sama dengan tampilan di menu
 * Jaringan > Topologi (yang digambar JavaScript), tapi dibuat di PHP supaya bisa dipotong per halaman A4.
 */
require_once __DIR__ . '/network.php';

/** Status tampilan 1 node: hasil cek; switch tanpa IP = 'err' bila semua (min. 2) aset ber-IP di bawahnya mati. */
function netTopoState(array $all, array $a): string
{
    if (!empty($a['virtual'])) return 'na';
    if ($a['ip'] !== '') return $a['state'] ?: 'na';
    $kids = array_filter(netDescendants($all, $a['id']), fn($k) => $k['ip'] !== '' && $k['state']);
    return count($kids) >= 2 && count(array_filter($kids, fn($k) => $k['state'] === 'err')) === count($kids) ? 'err' : 'na';
}

/**
 * Baris-baris topologi (urutan dari atas ke bawah).
 * $loc = filter lokasi ('' = semua); $netOnly = hanya switch/router/AP (aset biasa diringkas jadi jumlah).
 * Tiap baris: ['a' => node, 'd' => kedalaman, 'p' => index baris induk|null, 'state' => ..., 'below' => jumlah aset di bawahnya].
 */
function netTopoRows(array $all, string $loc = '', bool $netOnly = false, bool $grp = false, bool $cable = false): array
{
    $children = [];
    foreach ($all as $a) if ($a['parent']) $children[$a['parent']][] = $a;
    // Kotak per lokasi: anak yang lokasinya sama dengan induknya didahulukan, lalu dikelompokkan per lokasi;
    // cabang yang seluruh isinya 1 lokasi didahulukan supaya aset satu lokasi tidak terpotong cabang lokasi lain.
    $pure = [];
    $isPure = function (array $k) use (&$pure, $all) {
        if (!isset($pure[$k['id']])) {
            $L = netTopoLocKey($k['loc'] ?? ''); $pure[$k['id']] = 0;
            foreach (netDescendants($all, $k['id']) as $d) if (netTopoLocKey($d['loc'] ?? '') !== $L) { $pure[$k['id']] = 1; break; }
        }
        return $pure[$k['id']];
    };
    foreach ($children as $pid => &$list) {
        $pl = netTopoLocKey($all[$pid]['loc'] ?? '');
        usort($list, fn($x, $y) => ($grp ? (((netTopoLocKey($x['loc']) === $pl) ? 0 : 1) <=> ((netTopoLocKey($y['loc']) === $pl) ? 0 : 1)) ?: strcmp(netTopoLocKey($x['loc']), netTopoLocKey($y['loc'])) ?: ($isPure($x) <=> $isPure($y)) : 0)
            ?: ($y['is_net'] <=> $x['is_net']) ?: strcasecmp($x['name'], $y['name']));
    }
    unset($list);
    $keep = function (array $a) use ($loc, $all) {
        if ($loc === '' || $a['loc'] === $loc) return true;
        foreach (netDescendants($all, $a['id']) as $k) if ($k['loc'] === $loc) return true;
        return false;
    };
    $rows = [];
    $walk = function (array $a, int $d, ?int $p) use (&$walk, &$rows, $children, $keep, $netOnly, $all) {
        if (!$keep($a)) return;
        if ($netOnly && !$a['is_net']) return;
        $rows[] = ['a' => $a, 'd' => $d, 'p' => $p, 'state' => netTopoState($all, $a), 'below' => count(netDescendants($all, $a['id']))];
        $me = count($rows) - 1;
        foreach ($children[$a['id']] ?? [] as $k) $walk($k, $d + 1, $me);
    };
    $roots = array_filter($all, fn($a) => !$a['parent']);
    $netRoots = array_filter($roots, fn($a) => $a['is_net'] || !empty($children[$a['id']]));
    usort($netRoots, fn($x, $y) => ($y['is_net'] <=> $x['is_net']) ?: strcasecmp($x['name'], $y['name']));
    if ($grp && $netRoots) {
        // Perangkat paling atas berlokasi sama dibuat berdampingan (urutan lokasi = kemunculan pertama);
        // yang tanpa cabang lokasi lain didahulukan.
        $rg = [];
        foreach (array_values($netRoots) as $i => $a) $rg[netTopoLocKey($a['loc'] ?? '')][] = [$a, $i];
        $netRoots = [];
        foreach ($rg as $k => $g) {
            usort($g, fn($x, $y) => ($k !== '' ? ($isPure($x[0]) <=> $isPure($y[0])) : 0) ?: ($x[1] <=> $y[1]));
            foreach ($g as $x) $netRoots[] = $x[0];
        }
    }
    if ($netRoots) {
        $rows[] = ['a' => ['id' => -1, 'name' => 'Internet / Router ISP', 'ip' => '', 'port' => '', 'virtual' => true, 'is_net' => true], 'd' => 0, 'p' => null, 'state' => 'na', 'below' => 0];
        foreach ($netRoots as $a) $walk($a, 1, 0);
        if (count($rows) === 1) $rows = [];
    }
    if (!$netOnly) {
        $netIds = array_column($netRoots, 'id');
        $loose = array_filter($roots, fn($a) => !in_array($a['id'], $netIds, true) && $keep($a));
        // Kotak per lokasi: aset yang belum dihubungkan ditaruh di kotak lokasinya (di bawah perangkat pertama
        // berlokasi sama), tanpa garis koneksi ('float'). Sisanya tetap di "Belum dihubungkan".
        if ($grp && $loose && $rows) {
            $anchor = [];
            // Utamakan switch/router berlokasi sama yang punya cabang, lalu perangkat jaringan, lalu baris pertama.
            $rank = [];
            foreach ($rows as $i => $r) {
                $k = netTopoLoc($r['a']); if ($k === '') continue;
                $sc = !empty($r['a']['is_net']) ? ((isset($rows[$i + 1]) && $rows[$i + 1]['d'] > $r['d']) ? 2 : 1) : 0;
                if (!isset($anchor[$k]) || $sc > $rank[$k]) { $anchor[$k] = $i; $rank[$k] = $sc; }
            }
            $ins = [];
            foreach ($loose as $key => $a) {
                $k = netTopoLocKey($a['loc'] ?? '');
                if ($k !== '' && isset($anchor[$k])) { $ins[$anchor[$k]][] = $a; unset($loose[$key]); }
            }
            foreach ($ins as &$l) usort($l, fn($x, $y) => strcasecmp($x['name'], $y['name']));
            unset($l);
            if ($ins) {
                $new = []; $map = [];
                foreach ($rows as $i => $r) {
                    $map[$i] = count($new);
                    if ($r['p'] !== null) $r['p'] = $map[$r['p']];
                    $new[] = $r;
                    foreach ($ins[$i] ?? [] as $a) $new[] = ['a' => $a, 'd' => $r['d'] + 1, 'p' => null, 'float' => true, 'state' => netTopoState($all, $a), 'below' => 0];
                }
                $rows = $new;
            }
        }
        usort($loose, fn($x, $y) => ($grp ? strcmp(netTopoLocKey($x['loc']), netTopoLocKey($y['loc'])) : 0) ?: strcasecmp($x['name'], $y['name']));
        if ($loose) {
            $rows[] = ['a' => ['id' => -2, 'name' => nL('Belum dihubungkan', 'Not linked'), 'ip' => '', 'port' => '', 'virtual' => true, 'is_net' => false], 'd' => 0, 'p' => null, 'state' => 'na', 'below' => 0];
            $g = count($rows) - 1;
            foreach ($loose as $a) $rows[] = ['a' => $a, 'd' => 1, 'p' => $g, 'state' => netTopoState($all, $a), 'below' => 0];
        }
    }
    // Warna kabel per switch / router (sama dengan tampilan web): tiap perangkat yang punya baris anak (bukan
    // kotak virtual) mendapat 1 warna; 'cab' = warna garis ke induk, 'cab_own' = strip warna di kotak induk.
    if ($cable) {
        $pal = ['#0d9488', '#7c3aed', '#ea580c', '#92400e', '#65a30d', '#db2777', '#ca8a04', '#475569', '#059669', '#9333ea', '#c2410c', '#0f766e', '#a16207', '#be185d', '#15803d', '#6d28d9'];
        $cab = [];
        foreach ($rows as $r) {
            if ($r['p'] === null || !empty($r['float'])) continue;
            $pid = $rows[$r['p']]['a']['id'];
            if ($pid > 0 && !isset($cab[$pid])) $cab[$pid] = $pal[count($cab) % count($pal)];
        }
        foreach ($rows as &$r) {
            $r['cab'] = ($r['p'] !== null && empty($r['float'])) ? ($cab[$rows[$r['p']]['a']['id']] ?? null) : null;
            $r['cab_own'] = $cab[$r['a']['id']] ?? null;
        }
        unset($r);
    }
    // Tandai baris pertama tiap kelompok lokasi (butuh ruang label di atasnya).
    $prev = null;
    foreach ($rows as &$r) {
        $L = netTopoLoc($r['a']);
        $r['gtop'] = $grp && $L !== '' && $L !== $prev;
        $r['grp'] = $grp;
        $prev = $L;
    }
    unset($r);
    return $rows;
}

/** Kunci lokasi: tanpa beda huruf besar/kecil & spasi ("Ruang Server" = "RUANG SERVER"). */
function netTopoLocKey($s): string
{
    return mb_strtolower(preg_replace('/\s+/u', ' ', trim((string)$s)));
}

/** Lokasi (kunci) untuk kotak lokasi ('' = tanpa kotak). */
function netTopoLoc(array $a): string
{
    return !empty($a['virtual']) ? '' : netTopoLocKey($a['loc'] ?? '');
}

/** Label kotak per kunci lokasi: penulisan yang paling banyak dipakai. */
function netTopoLocNames(array $rows): array
{
    $cnt = [];
    foreach ($rows as $r) {
        $k = netTopoLoc($r['a']); if ($k === '') continue;
        $t = preg_replace('/\s+/u', ' ', trim((string)$r['a']['loc']));
        $cnt[$k][$t] = ($cnt[$k][$t] ?? 0) + 1;
    }
    $out = [];
    foreach ($cnt as $k => $c) { uksort($c, fn($x, $y) => ($c[$y] <=> $c[$x]) ?: strcmp($x, $y)); $out[$k] = array_key_first($c); }
    return $out;
}

/** Ruang label kotak lokasi (px). */
const NET_TOPO_LBL = 20;

/** Ukuran gambar topologi cetak (px). */
const NET_TOPO_NW = 178, NET_TOPO_NH = 32, NET_TOPO_GX = 128, NET_TOPO_GY = 38, NET_TOPO_PAD = 8;

/** Tinggi kotak 1 baris: router/switch/hub/AP yang punya Brand/Type dapat baris ke-3. */
function netTopoRowH(array $r): int
{
    $a = $r['a'];
    if (!empty($a['virtual'])) return NET_TOPO_NH;
    $nIp = max(1, count(netTopoIpLines($a)));
    return NET_TOPO_NH + ($nIp - 1) * 11 + ((!empty($a['is_net']) && trim((string)($a['brand'] ?? '')) !== '') ? 11 : 0);
}

/** Semua IP terdaftar perangkat, IP utama paling atas (1 baris per IP di kotak topologi). */
function netTopoIpLines(array $a): array
{
    if (!empty($a['virtual'])) return [];
    $l = array_values($a['ips'] ?? []);
    if (!$l) return ($a['ip'] ?? '') !== '' ? [$a['ip']] : [];
    foreach ($l as $k => $v) {
        if (explode('/', $v)[0] === ($a['ip'] ?? '')) { if ($k > 0) { array_splice($l, $k, 1); array_unshift($l, $v); } break; }
    }
    return $l;
}

function netTopoWidth(array $rows, int $nExtra = 0): int
{
    $maxD = $rows ? max(array_column($rows, 'd')) : 0;
    return NET_TOPO_PAD * 2 + $maxD * NET_TOPO_GX + NET_TOPO_NW + ($nExtra ? 60 + $nExtra * 12 : 0);
}

/**
 * SVG untuk baris $from..$to-1 (satu halaman). Garis ke induk yang ada di halaman sebelumnya
 * digambar dari tepi atas, supaya sambungan antarhalaman tetap terbaca.
 * $netOnly: teks kecil memuat jumlah aset di bawah perangkat.
 */
function netTopoSvg(array $rows, int $from, int $to, bool $netOnly = false, array $extras = []): string
{
    $NW = NET_TOPO_NW; $NH = NET_TOPO_NH; $GX = NET_TOPO_GX; $GY = NET_TOPO_GY; $P = NET_TOPO_PAD;
    $W = netTopoWidth($rows, count($extras));
    // Posisi Y bertumpuk karena tinggi kotak bisa berbeda (perangkat jaringan + brand type).
    $GAP = $GY - $NH; $ys = []; $hs = []; $yy = $P;
    for ($i = $from; $i < $to; $i++) {
        // Baris pertama halaman yang ada di kotak lokasi juga diberi label (kotak lanjutan).
        if (!empty($rows[$i]['gtop']) || ($i === $from && !empty($rows[$i]['grp']) && netTopoLoc($rows[$i]['a']) !== '')) $yy += NET_TOPO_LBL;
        $ys[$i] = $yy; $hs[$i] = netTopoRowH($rows[$i]); $yy += $hs[$i] + $GAP;
    }
    $H = $yy - $GAP + $P;
    $col = ['ok' => ['#ecfdf3', '#15803d'], 'warn' => ['#fffbeb', '#b45309'], 'err' => ['#fef2f2', '#b91c1c'], 'na' => ['#ffffff', '#94a3b8']];
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES | ENT_XML1, 'UTF-8');
    $x = fn($i) => $P + $rows[$i]['d'] * $GX;
    $y = fn($i) => $ys[$i];
    $lines = $nodes = $boxes = '';
    // Kotak lokasi: baris berurutan dengan lokasi sama dibungkus 1 kotak berwarna + label lokasi.
    if ($to > $from && !empty($rows[$from]['grp'])) {
        $pal = [['#eff6ff', '#3b82f6'], ['#f0fdf4', '#22c55e'], ['#fff7ed', '#f97316'], ['#faf5ff', '#a855f7'], ['#ecfeff', '#06b6d4'], ['#fdf2f8', '#ec4899'], ['#fefce8', '#eab308']];
        $locIdx = []; $locNames = netTopoLocNames($rows);
        foreach ($rows as $r) { $L = netTopoLoc($r['a']); if ($L !== '' && !isset($locIdx[$L])) $locIdx[$L] = count($locIdx); }   // warna tetap antarhalaman
        $runs = []; $cur = null;
        for ($i = $from; $i < $to; $i++) {
            $L = netTopoLoc($rows[$i]['a']);
            if ($L === '') { $cur = null; continue; }
            if ($cur !== null && $runs[$cur]['loc'] === $L && empty($rows[$i]['gtop'])) {
                $runs[$cur]['x1'] = min($runs[$cur]['x1'], $x($i)); $runs[$cur]['x2'] = max($runs[$cur]['x2'], $x($i) + $NW);
                $runs[$cur]['y2'] = $ys[$i] + $hs[$i]; $runs[$cur]['n']++;
            } else {
                $runs[] = ['loc' => $L, 'x1' => $x($i), 'x2' => $x($i) + $NW, 'y1' => $ys[$i], 'y2' => $ys[$i] + $hs[$i], 'n' => 1];
                $cur = count($runs) - 1;
            }
        }
        foreach ($runs as $g) {
            [$bg, $bd] = $pal[$locIdx[$g['loc']] % count($pal)];
            $bx = $g['x1'] - 6; $by = $g['y1'] - NET_TOPO_LBL + 4; $bw = $g['x2'] - $g['x1'] + 12; $bh = $g['y2'] - $by + 5;
            $lbl = ($locNames[$g['loc']] ?? $g['loc']) . ' · ' . $g['n'] . ' ' . nL('perangkat', 'devices');
            $lw = min($bw - 4, mb_strlen($lbl) * 5.3 + 12);
            $boxes .= '<rect x="' . $bx . '" y="' . $by . '" width="' . $bw . '" height="' . $bh . '" rx="8" ry="8" fill="' . $bg . '" stroke="' . $bd . '" stroke-width="1" stroke-dasharray="5,3"/>'
                . '<rect x="' . ($bx + 6) . '" y="' . ($by - 6) . '" width="' . $lw . '" height="13" rx="6" ry="6" fill="' . $bd . '" stroke="' . $bd . '" stroke-width="0.5" stroke-dasharray="2000,1"/>'
                . '<text x="' . ($bx + 12) . '" y="' . ($by + 3.5) . '" font-size="8.5" font-weight="bold" fill="#ffffff" font-family="Helvetica">' . $e($lbl) . '</text>';
        }
    }
    for ($i = $from; $i < $to; $i++) {
        $r = $rows[$i]; $a = $r['a']; $st = $r['state'];
        if ($r['p'] !== null) {
            $px = $x($r['p']) + 16;
            $py = $r['p'] >= $from ? $y($r['p']) + $hs[$r['p']] : 0;
            $cy = $y($i) + $NH / 2;
            $red = $st === 'err';
            $lines .= '<path d="M' . $px . ',' . $py . ' L' . $px . ',' . $cy . ' L' . $x($i) . ',' . $cy . '" fill="none" stroke="' . ($red ? '#b91c1c' : ($r['cab'] ?? null ?: '#94a3b8')) . '" stroke-width="' . ($red ? 1.8 : (!empty($r['cab']) ? 1.6 : 1.1)) . '"' . ($red ? ' stroke-dasharray="5,4"' : ' stroke-dasharray="2000,1"') . '/>';
            $pl = netPortLabel((string)($a['port'] ?? ''), (string)($a['own_port'] ?? ''));
            if ($pl !== '') $lines .= '<text x="' . ($px + 5) . '" y="' . ($cy - 3) . '" font-size="8.5" fill="' . (($r['cab'] ?? null) ?: '#64748b') . '" font-family="DejaVu Sans Mono">' . $e($pl) . '</text>';
        }
        [$bg, $bd] = $col[$st] ?? $col['na'];
        $virtual = !empty($a['virtual']);
        $name = mb_strlen($a['name']) > 26 ? mb_substr($a['name'], 0, 25) . '…' : $a['name'];
        $subs = netTopoIpLines($a);
        if (!$virtual && !$subs) $subs = [nL('tanpa IP', 'no IP') . ($st === 'err' ? ' · ' . nL('diduga mati', 'suspected down') : '')];
        if (!$virtual && $netOnly && $r['below']) $subs[0] .= ' · ' . $r['below'] . ' ' . nL('aset', 'assets');
        $sub = $subs ? 'x' : '';
        $bt = (!$virtual && !empty($a['is_net'])) ? trim((string)$a['brand']) : '';
        if (mb_strlen($bt) > 32) $bt = mb_substr($bt, 0, 31) . '…';
        $nodes .= '<rect x="' . $x($i) . '" y="' . $y($i) . '" width="' . $NW . '" height="' . $hs[$i] . '" rx="6" ry="6" fill="' . $bg . '" stroke="' . $bd . '" stroke-width="1.3"' . ($virtual || !empty($r['float']) ? ' stroke-dasharray="4,3"' : ' stroke-dasharray="2000,1"') . '/>'
            . (!empty($r['cab_own']) ? '<rect x="' . ($x($i) + 2.5) . '" y="' . ($y($i) + 5) . '" width="3.5" height="' . ($hs[$i] - 10) . '" rx="1.5" ry="1.5" fill="' . $r['cab_own'] . '" stroke="' . $r['cab_own'] . '" stroke-width="0.3" stroke-dasharray="2000,1"/>' : '')
            . '<text x="' . ($x($i) + 8) . '" y="' . ($y($i) + ($sub !== '' ? 13 : 20)) . '" font-size="10.5" font-weight="bold" fill="#1e293b" font-family="Helvetica">' . $e($name) . '</text>'
            . implode('', array_map(fn($t, $n) => '<text x="' . ($x($i) + 8) . '" y="' . ($y($i) + 26 + $n * 11) . '" font-size="8.5" fill="#475569" font-family="Helvetica">' . $e(mb_strlen($t) > 40 ? mb_substr($t, 0, 39) . '…' : $t) . '</text>', $subs, array_keys($subs)))
            . ($bt !== '' ? '<text x="' . ($x($i) + 8) . '" y="' . ($y($i) + 26 + max(1, count($subs)) * 11) . '" font-size="8.5" fill="#4338ca" font-family="Helvetica">' . $e($bt) . '</text>' : '');
    }
    // Koneksi tambahan (garis putus-putus biru) bila kedua perangkat ada di halaman ini.
    $extraLines = '';
    $rowOf = [];
    for ($i = $from; $i < $to; $i++) $rowOf[$rows[$i]['a']['id']] = $i;
    $pairSeen = [];
    foreach (array_values($extras) as $k => $l) {
        if (!isset($rowOf[$l['a']], $rowOf[$l['b']])) continue;
        $ia = $rowOf[$l['a']]; $ib = $rowOf[$l['b']];
        $pk = min($l['a'], $l['b']) . '-' . max($l['a'], $l['b']);
        $pi = $pairSeen[$pk] = isset($pairSeen[$pk]) ? $pairSeen[$pk] + 1 : 0;   // kabel ke-2 antar perangkat yang sama digeser
        $off = $pi * 9 - ($pi ? 4 : 0);
        $ax = $x($ia) + $NW; $bx = $x($ib) + $NW; $ay = $y($ia) + $hs[$ia] / 2 + $off; $by = $y($ib) + $hs[$ib] / 2 + $off;
        $X = max($ax, $bx) + 34 + $k * 12;
        $extraLines .= '<path d="M' . $ax . ',' . $ay . ' L' . $X . ',' . $ay . ' L' . $X . ',' . $by . ' L' . $bx . ',' . $by . '" fill="none" stroke="#2563eb" stroke-width="1.4" stroke-dasharray="6,4"/>';
        if ($l['port_a'] !== '') $extraLines .= '<text x="' . ($ax + 3) . '" y="' . ($ay - 3) . '" font-size="8" fill="#2563eb" font-family="DejaVu Sans Mono">' . $e($l['port_a']) . '</text>';
        if ($l['port_b'] !== '') $extraLines .= '<text x="' . ($bx + 3) . '" y="' . ($by - 3) . '" font-size="8" fill="#2563eb" font-family="DejaVu Sans Mono">' . $e($l['port_b']) . '</text>';
    }
    // Garis tambahan (putus-putus, siku) digambar paling akhir. Garis/kotak penuh diberi pola "2000,1" karena
    // pustaka SVG di PDF membawa pola putus-putus ke elemen berikutnya bila tidak ditulis.
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' . $W . '" height="' . $H . '" viewBox="0 0 ' . $W . ' ' . $H . '">' . $boxes . $lines . $nodes . $extraLines . '</svg>';
}

/**
 * Bagi baris ke halaman. $availW / $availH = ruang gambar per halaman (px CSS, 96 dpi).
 * Return ['scale' => skala, 'pages' => [[from, to], ...]].
 */
function netTopoPages(array $rows, float $availW, float $availH, float $firstPageH, int $nExtra = 0): array
{
    $scale = min(1.0, $availW / max(1, netTopoWidth($rows, $nExtra)));
    $pages = [];
    $i = 0; $n = count($rows); $first = true;
    $GAP = NET_TOPO_GY - NET_TOPO_NH;
    while ($i < $n) {
        $limit = ($first ? $firstPageH : $availH) / $scale - NET_TOPO_PAD * 2 + $GAP;
        $used = 0; $j = $i;
        $rh = fn($k) => netTopoRowH($rows[$k]) + $GAP + ((!empty($rows[$k]['gtop']) || ($k === $i && !empty($rows[$k]['grp']))) ? NET_TOPO_LBL : 0);
        while ($j < $n && ($used + $rh($j) <= $limit || $j === $i)) { $used += $rh($j); $j++; }
        $pages[] = [$i, $j];
        $i = $j; $first = false;
    }
    return ['scale' => $scale, 'pages' => $pages];
}

// ======================================================================================
// Susunan bebas (mode "Geser bebas" di menu Jaringan > Topologi) untuk Cetak / PDF.
// Ukuran & aturan garis sama dengan tampilan web; gambar diperkecil selebar kertas lalu
// dipotong per halaman di sela-sela kotak (kotak tidak terbelah).
// ======================================================================================
const NET_FREE_NW = 190, NET_FREE_NH = 40;

/** Posisi semua baris: posisi tersimpan, atau posisi otomatis (sama dengan susunan web). */
function netTopoFreeLayout(array $rows, array $saved): array
{
    $NW = NET_FREE_NW; $NH = NET_FREE_NH;
    $pos = []; $yy = 14; $W = 0; $H = 0;
    foreach ($rows as $i => $r) {
        $a = $r['a'];
        if (!empty($r['gtop'])) $yy += 24;
        $h = !empty($a['virtual']) ? $NH : $NH + (max(1, count(netTopoIpLines($a))) - 1) * 14 + ((!empty($a['is_net']) && trim((string)($a['brand'] ?? '')) !== '') ? 14 : 0);
        $x = 14 + $r['d'] * 150; $y = $yy; $yy += $h + 10;
        if (isset($saved[$a['id']])) [$x, $y] = $saved[$a['id']];
        $pos[$a['id']] = ['x' => $x, 'y' => $y, 'h' => $h];
        $W = max($W, $x + $NW + 60); $H = max($H, $y + $h + 30);
    }
    return ['pos' => $pos, 'W' => $W, 'H' => $H];
}

/** Garis siku antar 2 kotak (port dari JavaScript web). Return titik-titik + posisi label. */
function netTopoFreeElbow(array $A, array $B, int $off = 0, bool $tree = false): array
{
    $NW = NET_FREE_NW; $NH = NET_FREE_NH;
    $bmy = $B['y'] + min($B['h'], $NH) / 2 + $off;
    if ($tree && $B['y'] >= $A['y'] + $A['h'] - 4 && ($B['x'] >= $A['x'] + 40 || $B['x'] + $NW <= $A['x'] + $NW - 40)) {
        $rgt = $B['x'] >= $A['x'] + 40; $tx = ($rgt ? $A['x'] + 18 : $A['x'] + $NW - 18) + $off; $ex = $rgt ? $B['x'] : $B['x'] + $NW;
        return ['pts' => [[$tx, $A['y'] + $A['h']], [$tx, $bmy], [$ex, $bmy]], 'lx' => $rgt ? $tx + 6 : $ex + 6, 'ly' => $bmy - 4, 'ax' => $tx + 4, 'ay' => $A['y'] + $A['h'] + 12];
    }
    $acx = $A['x'] + $NW / 2; $bcx = $B['x'] + $NW / 2;
    if ($B['y'] >= $A['y'] + $A['h'] + 16 || $A['y'] >= $B['y'] + $B['h'] + 16) {
        $down = $B['y'] > $A['y']; $y1 = $down ? $A['y'] + $A['h'] : $A['y']; $y2 = $down ? $B['y'] : $B['y'] + $B['h']; $my = round(($y1 + $y2) / 2) + $off;
        $ax = $acx + $off; $bx = $bcx + $off;
        return ['pts' => [[$ax, $y1], [$ax, $my], [$bx, $my], [$bx, $y2]], 'lx' => $bx + 4, 'ly' => $down ? $y2 - 4 : $y2 + 12, 'ax' => $ax + 4, 'ay' => $down ? $y1 + 12 : $y1 - 4];
    }
    $right = $B['x'] > $A['x']; $x1 = $right ? $A['x'] + $NW : $A['x']; $x2 = $right ? $B['x'] : $B['x'] + $NW; $mx = round(($x1 + $x2) / 2) + $off;
    $ay = $A['y'] + min($A['h'], $NH) / 2 + $off; $by = $B['y'] + min($B['h'], $NH) / 2 + $off;
    if (abs($x2 - $x1) < 20) { $mx = max($A['x'], $B['x']) + $NW + 30 + $off; $x1 = $A['x'] + $NW; $x2 = $B['x'] + $NW; }
    return ['pts' => [[$x1, $ay], [$mx, $ay], [$mx, $by], [$x2, $by]], 'lx' => $x2 + ($x2 > $mx ? -60 : 4), 'ly' => $by - 4, 'ax' => $x1 + ($x1 < $mx ? 4 : -60), 'ay' => $ay - 4];
}

/** Potong garis siku (segmen tegak/datar) ke jendela y0..y1, geser ke koordinat halaman. */
function netTopoFreeClip(array $pts, float $y0, float $y1): array
{
    $out = [];
    for ($i = 0; $i < count($pts) - 1; $i++) {
        [$ax, $ay] = $pts[$i]; [$bx, $by] = $pts[$i + 1];
        $lo = min($ay, $by); $hi = max($ay, $by);
        if ($hi < $y0 || $lo > $y1) continue;
        $out[] = [[$ax, max($y0, min($y1, $ay)) - $y0], [$bx, max($y0, min($y1, $by)) - $y0]];
    }
    return $out;
}

/** Bagi gambar bebas ke halaman: potong di sela kotak. Return ['scale', 'pages' => [[y0, y1], ...]]. */
function netTopoFreePages(array $L, float $availW, float $availH, float $firstPageH): array
{
    $scale = min(1.0, $availW / max(1, $L['W']));
    $boxes = array_values($L['pos']);
    $pages = []; $y0 = 0.0; $first = true;
    while ($y0 < $L['H'] - 1) {
        $lim = $y0 + ($first ? $firstPageH : $availH) / $scale;
        if ($lim >= $L['H']) { $pages[] = [$y0, (float)$L['H']]; break; }
        $cut = $lim;
        // geser garis potong ke atas sampai tidak membelah kotak
        for ($guard = 0; $guard < 200; $guard++) {
            $hit = null;
            foreach ($boxes as $b) if ($b['y'] - 26 < $cut && $b['y'] + $b['h'] + 4 > $cut) { $hit = $b; break; }
            if (!$hit) break;
            $cut = $hit['y'] - 27;
        }
        if ($cut <= $y0 + 40) $cut = $lim;   // kotak lebih tinggi dari halaman: potong paksa
        $pages[] = [$y0, $cut]; $y0 = $cut; $first = false;
    }
    return ['scale' => $scale, 'pages' => $pages ?: [[0.0, (float)$L['H']]]];
}

/** SVG susunan bebas untuk jendela y0..y1. */
function netTopoFreeSvg(array $rows, array $L, float $y0, float $y1, bool $netOnly = false, array $extras = []): string
{
    $NW = NET_FREE_NW; $NH = NET_FREE_NH; $pos = $L['pos'];
    $W = (int)$L['W']; $Hh = (int)ceil($y1 - $y0);
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES | ENT_XML1, 'UTF-8');
    $path = function (array $segs, string $stroke, float $sw, string $dash) {
        $o = '';
        foreach ($segs as [$p, $q]) $o .= '<path d="M' . round($p[0], 1) . ',' . round($p[1], 1) . ' L' . round($q[0], 1) . ',' . round($q[1], 1) . '" fill="none" stroke="' . $stroke . '" stroke-width="' . $sw . '" stroke-dasharray="' . $dash . '"/>';
        return $o;
    };
    $in = fn($y) => $y >= $y0 && $y <= $y1;
    $boxes = $lines = $nodes = $extraLines = '';
    // Kotak lokasi: 1 kotak per lokasi = batas luar semua perangkatnya.
    if (!empty($rows[0]['grp'])) {
        $pal = [['#eff6ff', '#3b82f6'], ['#f0fdf4', '#22c55e'], ['#fff7ed', '#f97316'], ['#faf5ff', '#a855f7'], ['#ecfeff', '#06b6d4'], ['#fdf2f8', '#ec4899'], ['#fefce8', '#eab308']];
        $names = netTopoLocNames($rows); $g = []; $idx = [];
        foreach ($rows as $r) {
            $k = netTopoLoc($r['a']); if ($k === '') continue;
            if (!isset($idx[$k])) $idx[$k] = count($idx);
            $p = $pos[$r['a']['id']];
            if (!isset($g[$k])) $g[$k] = ['x1' => $p['x'], 'x2' => $p['x'] + $NW, 'y1' => $p['y'], 'y2' => $p['y'] + $p['h'], 'n' => 0];
            $g[$k]['x1'] = min($g[$k]['x1'], $p['x']); $g[$k]['x2'] = max($g[$k]['x2'], $p['x'] + $NW);
            $g[$k]['y1'] = min($g[$k]['y1'], $p['y']); $g[$k]['y2'] = max($g[$k]['y2'], $p['y'] + $p['h']); $g[$k]['n']++;
        }
        foreach ($g as $k => $b) {
            [$bg, $bd] = $pal[$idx[$k] % count($pal)];
            $bx = $b['x1'] - 8; $by = $b['y1'] - 20; $bw = $b['x2'] - $b['x1'] + 16; $bh = $b['y2'] - $by + 6;
            if ($by + $bh < $y0 || $by > $y1) continue;
            $ty = max($by, $y0 - 2); $tb = min($by + $bh, $y1 + 2);
            $boxes .= '<rect x="' . $bx . '" y="' . round($ty - $y0, 1) . '" width="' . $bw . '" height="' . round($tb - $ty, 1) . '" rx="9" ry="9" fill="' . $bg . '" stroke="' . $bd . '" stroke-width="1.1" stroke-dasharray="6,3"/>';
            if ($in($by)) {
                $lbl = ($names[$k] ?? $k) . ' · ' . $b['n'] . ' ' . nL('perangkat', 'devices');
                $lw = min($bw - 4, mb_strlen($lbl) * 6.4 + 14);
                $boxes .= '<rect x="' . ($bx + 8) . '" y="' . round($by - 8 - $y0, 1) . '" width="' . $lw . '" height="16" rx="8" ry="8" fill="' . $bd . '" stroke="' . $bd . '" stroke-width="0.5" stroke-dasharray="2000,1"/>'
                    . '<text x="' . ($bx + 15) . '" y="' . round($by + 3.5 - $y0, 1) . '" font-size="10" font-weight="bold" fill="#ffffff" font-family="Helvetica">' . $e($lbl) . '</text>';
            }
        }
    }
    foreach ($rows as $i => $r) {
        $a = $r['a']; $p = $pos[$a['id']]; $st = $r['state']; $virtual = !empty($a['virtual']);
        // garis ke induk
        if ($r['p'] !== null && empty($r['float'])) {
            $pp = $pos[$rows[$r['p']]['a']['id']] ?? null;
            if ($pp) {
                $el = netTopoFreeElbow($pp, $p, 0, true); $red = $st === 'err';
                $lines .= $path(netTopoFreeClip($el['pts'], $y0, $y1), $red ? '#b91c1c' : (($r['cab'] ?? null) ?: '#94a3b8'), $red ? 1.8 : (!empty($r['cab']) ? 1.7 : 1.2), $red ? '5,4' : '2000,1');
                $pl = netPortLabel((string)($a['port'] ?? ''), (string)($a['own_port'] ?? ''));
                if ($pl !== '' && $in($el['ly'])) $lines .= '<text x="' . $el['lx'] . '" y="' . round($el['ly'] - $y0, 1) . '" font-size="9.5" fill="' . (($r['cab'] ?? null) ?: '#64748b') . '" font-family="DejaVu Sans Mono">' . $e($pl) . '</text>';
            }
        }
        if ($p['y'] < $y0 - 1 || $p['y'] + $p['h'] > $y1 + 1) continue;   // kotak ada di halaman lain
        $col = ['ok' => ['#ecfdf3', '#15803d'], 'warn' => ['#fffbeb', '#b45309'], 'err' => ['#fef2f2', '#b91c1c'], 'na' => ['#ffffff', '#94a3b8']];
        [$bg, $bd] = $col[$st] ?? $col['na'];
        $name = mb_strlen($a['name']) > 24 ? mb_substr($a['name'], 0, 23) . '…' : $a['name'];
        $subs = netTopoIpLines($a);
        if (!$virtual && !$subs) $subs = [nL('tanpa IP', 'no IP') . ($st === 'err' ? ' · ' . nL('diduga mati', 'suspected down') : '')];
        if (!$virtual && $netOnly && $r['below']) $subs[0] .= ' · ' . $r['below'] . ' ' . nL('aset', 'assets');
        $bt = (!$virtual && !empty($a['is_net'])) ? trim((string)$a['brand']) : '';
        if (mb_strlen($bt) > 32) $bt = mb_substr($bt, 0, 31) . '…';
        $y = $p['y'] - $y0;
        $nodes .= '<rect x="' . $p['x'] . '" y="' . round($y, 1) . '" width="' . $NW . '" height="' . $p['h'] . '" rx="7" ry="7" fill="' . $bg . '" stroke="' . $bd . '" stroke-width="1.4" stroke-dasharray="' . ($virtual || !empty($r['float']) ? '4,3' : '2000,1') . '"/>'
            . (!empty($r['cab_own']) ? '<rect x="' . ($p['x'] + 3) . '" y="' . round($y + 6, 1) . '" width="4" height="' . ($p['h'] - 12) . '" rx="2" ry="2" fill="' . $r['cab_own'] . '" stroke="' . $r['cab_own'] . '" stroke-width="0.3" stroke-dasharray="2000,1"/>' : '')
            . '<text x="' . ($p['x'] + 10) . '" y="' . round($y + ($subs ? 17 : 25), 1) . '" font-size="12" font-weight="bold" fill="#1e293b" font-family="Helvetica">' . $e($name) . '</text>';
        foreach ($subs as $n => $t) $nodes .= '<text x="' . ($p['x'] + 10) . '" y="' . round($y + 31 + $n * 14, 1) . '" font-size="10" fill="#475569" font-family="Helvetica">' . $e(mb_strlen($t) > 34 ? mb_substr($t, 0, 33) . '…' : $t) . '</text>';
        if ($bt !== '') $nodes .= '<text x="' . ($p['x'] + 10) . '" y="' . round($y + 31 + max(1, count($subs)) * 14, 1) . '" font-size="10" fill="#4338ca" font-family="Helvetica">' . $e($bt) . '</text>';
    }
    // Koneksi tambahan
    $pairSeen = [];
    foreach (array_values($extras) as $k => $l) {
        $A = $pos[$l['a']] ?? null; $B = $pos[$l['b']] ?? null; if (!$A || !$B) continue;
        $pk = min($l['a'], $l['b']) . '-' . max($l['a'], $l['b']);
        $pi = $pairSeen[$pk] = isset($pairSeen[$pk]) ? $pairSeen[$pk] + 1 : 0;
        if ($B['x'] >= $A['x'] + $NW + 20 || $A['x'] >= $B['x'] + $NW + 20) $el = netTopoFreeElbow($A, $B, $pi * 8);
        else {
            $o2 = $pi * 8; $ay = $A['y'] + min($A['h'], $NH) / 2 + $o2; $by = $B['y'] + min($B['h'], $NH) / 2 + $o2; $X = max($A['x'], $B['x']) + $NW + 24 + ($k % 12) * 8;
            $el = ['pts' => [[$A['x'] + $NW, $ay], [$X, $ay], [$X, $by], [$B['x'] + $NW, $by]], 'ax' => $A['x'] + $NW + 4, 'ay' => $ay - 4, 'lx' => $B['x'] + $NW + 4, 'ly' => $by - 4];
        }
        $extraLines .= $path(netTopoFreeClip($el['pts'], $y0, $y1), '#2563eb', 1.5, '6,4');
        if ($l['port_a'] !== '' && $in($el['ay'])) $extraLines .= '<text x="' . $el['ax'] . '" y="' . round($el['ay'] - $y0, 1) . '" font-size="9" fill="#2563eb" font-family="DejaVu Sans Mono">' . $e($l['port_a']) . '</text>';
        if ($l['port_b'] !== '' && $in($el['ly'])) $extraLines .= '<text x="' . $el['lx'] . '" y="' . round($el['ly'] - $y0, 1) . '" font-size="9" fill="#2563eb" font-family="DejaVu Sans Mono">' . $e($l['port_b']) . '</text>';
    }
    // Garis putus-putus digambar paling akhir; garis/kotak penuh memakai pola "2000,1" (lihat netTopoSvg).
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' . $W . '" height="' . max(1, $Hh) . '" viewBox="0 0 ' . $W . ' ' . max(1, $Hh) . '">' . $boxes . $lines . $nodes . $extraLines . '</svg>';
}
