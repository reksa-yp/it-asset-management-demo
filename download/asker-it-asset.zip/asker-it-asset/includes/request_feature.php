<?php
function ensureRequestTable(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS user_requests (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        request_number VARCHAR(32) NOT NULL UNIQUE,
        user_id INT UNSIGNED NOT NULL,
        request_type ENUM('Baru','Penggantian') NOT NULL DEFAULT 'Baru',
        category VARCHAR(80) NOT NULL,
        item_description TEXT NOT NULL,
        reason TEXT NOT NULL,
        image_path VARCHAR(255) DEFAULT NULL,
        status ENUM('Menunggu','Disetujui','Ditolak','Selesai') NOT NULL DEFAULT 'Menunggu',
        admin_note TEXT DEFAULT NULL,
        handled_by INT UNSIGNED DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user_requests_user (user_id),
        INDEX idx_user_requests_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    // Migrasi aman: simpan siapa yang membuat pengajuan jika dia mewakili user lain.
    try {
        $col = $db->query("SHOW COLUMNS FROM user_requests LIKE 'submitted_by_user_id'")->fetch(PDO::FETCH_ASSOC);
        if (!$col) {
            $db->exec("ALTER TABLE user_requests ADD COLUMN submitted_by_user_id INT UNSIGNED DEFAULT NULL AFTER user_id, ADD INDEX idx_user_requests_submitter (submitted_by_user_id)");
            $db->exec("UPDATE user_requests SET submitted_by_user_id = user_id WHERE submitted_by_user_id IS NULL");
        }
    } catch (Throwable $e) {}
    // Kolom untuk pengajuan atas nama orang baru yang belum memiliki akun.
    try {
        $col = $db->query("SHOW COLUMNS FROM user_requests LIKE 'target_manual_name'")->fetch(PDO::FETCH_ASSOC);
        if (!$col) $db->exec("ALTER TABLE user_requests ADD COLUMN target_manual_name VARCHAR(190) DEFAULT NULL, ADD COLUMN target_manual_department VARCHAR(120) DEFAULT NULL");
    } catch (Throwable $e) {}
    // Kolom terjemahan opsional; teks asli tetap disimpan tanpa perubahan.
    foreach (['item_description_en', 'reason_en', 'admin_note_en'] as $translationColumn) {
        try {
            $col = $db->query("SHOW COLUMNS FROM user_requests LIKE '" . $translationColumn . "'")->fetch(PDO::FETCH_ASSOC);
            if (!$col) $db->exec("ALTER TABLE user_requests ADD COLUMN `" . $translationColumn . "` TEXT DEFAULT NULL");
        } catch (Throwable $e) {}
    }
    // Migrasi aman satu kali: pertahankan seluruh data dan tambahkan status pembatalan.
    try {
        $col = $db->query("SHOW COLUMNS FROM user_requests LIKE 'status'")->fetch(PDO::FETCH_ASSOC);
        if ($col && strpos((string)$col['Type'], "'Dibatalkan'") === false) {
            $db->exec("ALTER TABLE user_requests MODIFY status ENUM('Menunggu','Disetujui','Ditolak','Selesai','Dibatalkan') NOT NULL DEFAULT 'Menunggu'");
        }
    } catch (Throwable $e) {}
}

/**
 * Terjemahan otomatis Indonesia -> Inggris (server-side, hasil disimpan ke kolom *_en).
 * Memakai konfigurasi includes/translation_config.php (MyMemory bawaan / LibreTranslate).
 * Mengembalikan null bila layanan tidak tersedia (teks asli tetap dipakai).
 */
function requestTranslateServer(string $text): ?string
{
    $text = trim($text);
    if ($text === '') return '';
    if (isset($GLOBALS['REQ_TRANSLATE_FN']) && is_callable($GLOBALS['REQ_TRANSLATE_FN'])) return ($GLOBALS['REQ_TRANSLATE_FN'])($text);   // untuk pengujian
    static $failed = false;
    if ($failed) return null;                                   // 1x gagal -> jangan menunda halaman dengan percobaan berulang
    $cfgFile = __DIR__ . '/translation_config.php';
    $cfg = is_file($cfgFile) ? (require $cfgFile) : [];
    $provider = strtolower((string)($cfg['provider'] ?? 'mymemory'));
    $base = rtrim((string)($cfg['api_url'] ?? 'https://api.mymemory.translated.net'), '/');
    $key = (string)($cfg['api_key'] ?? '');
    $timeout = max(3, min(10, (int)($cfg['timeout_seconds'] ?? 8)));
    $src = (string)($cfg['source_language'] ?? 'id');
    $http = function (string $url, ?array $post) use ($timeout): ?array {
        $body = false;
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            $opt = [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_TIMEOUT => $timeout, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTPHEADER => ['Accept: application/json', 'User-Agent: IT-System/1.0']];
            if ($post !== null) { $opt[CURLOPT_POST] = true; $opt[CURLOPT_POSTFIELDS] = http_build_query($post); }
            curl_setopt_array($ch, $opt); $body = curl_exec($ch); curl_close($ch);
        } else {
            $h = "Accept: application/json\r\nUser-Agent: IT-System/1.0\r\n";
            $ctx = stream_context_create(['http' => $post !== null
                ? ['method' => 'POST', 'header' => $h . "Content-Type: application/x-www-form-urlencoded\r\n", 'content' => http_build_query($post), 'timeout' => $timeout, 'ignore_errors' => true]
                : ['method' => 'GET', 'header' => $h, 'timeout' => $timeout, 'ignore_errors' => true]]);
            $body = @file_get_contents($url, false, $ctx);
        }
        $j = is_string($body) ? json_decode($body, true) : null;
        return is_array($j) ? $j : null;
    };
    if ($provider === 'mymemory') {
        $parts = preg_split('/(?<=\n)|(?<=[.!?])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY) ?: [$text];
        $chunks = []; $buf = '';
        foreach ($parts as $part) {
            $part = trim($part); if ($part === '') continue;
            foreach ((strlen($part) > 430 ? str_split($part, 430) : [$part]) as $piece) {
                if ($buf !== '' && strlen($buf . ' ' . $piece) > 430) { $chunks[] = $buf; $buf = ''; }
                $buf = $buf === '' ? $piece : $buf . ' ' . $piece;
            }
        }
        if ($buf !== '') $chunks[] = $buf;
        $out = [];
        foreach ($chunks as $c) {
            $p = ['q' => $c, 'langpair' => $src . '|en']; if ($key !== '') $p['key'] = $key;
            $d = $http($base . '/get?' . http_build_query($p), null);
            if (!is_array($d) || (int)($d['responseStatus'] ?? 0) !== 200 || !isset($d['responseData']['translatedText'])) { $failed = true; return null; }
            $out[] = html_entity_decode((string)$d['responseData']['translatedText'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        return implode(' ', $out);
    }
    $p = ['q' => $text, 'source' => $src, 'target' => 'en', 'format' => 'text']; if ($key !== '') $p['api_key'] = $key;
    $d = $http($base . '/translate', $p);
    if (!is_array($d) || !isset($d['translatedText']) || !is_string($d['translatedText'])) { $failed = true; return null; }
    return $d['translatedText'];
}

/**
 * Saat bahasa Inggris aktif: lengkapi terjemahan (detail, alasan, catatan admin) yang belum ada, simpan ke database,
 * lalu isi $rows[*]['*_en']. Maksimal $limit terjemahan per muat halaman supaya halaman tetap cepat.
 */
function requestEnsureEnglish(PDO $db, array &$rows, int $limit = 12): void
{
    if (!function_exists('currentLang') || currentLang() !== 'en') return;
    $pairs = ['item_description' => 'item_description_en', 'reason' => 'reason_en', 'admin_note' => 'admin_note_en'];
    $done = 0;
    foreach ($rows as &$r) {
        foreach ($pairs as $src => $dst) {
            if ($done >= $limit) break 2;
            if (!array_key_exists($src, $r) || trim((string)$r[$src]) === '' || trim((string)($r[$dst] ?? '')) !== '') continue;
            $tr = requestTranslateServer((string)$r[$src]);
            $done++;
            if ($tr === null) break 2;                      // layanan tidak tersedia: hentikan, pakai teks asli
            if (trim($tr) === '') continue;
            try { $db->prepare("UPDATE user_requests SET `$dst` = ? WHERE id = ?")->execute([$tr, (int)$r['id']]); } catch (Throwable $e) {}
            $r[$dst] = $tr;
        }
    }
    unset($r);
}
