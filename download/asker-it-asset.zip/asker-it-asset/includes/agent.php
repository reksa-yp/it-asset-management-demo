<?php
/**
 * Lokasi server (kantor / hosting) dan Agen Kantor.
 *
 * Aplikasi yang dipasang di hosting tidak bisa menjangkau perangkat di jaringan lokal kantor (192.168.x.x):
 * tidak bisa ping, scan subnet, atau membaca NVR lokal. Agen Kantor adalah script PHP kecil yang dijalankan di
 * satu PC kantor yang selalu menyala. Agen hanya membuat koneksi KELUAR ke hosting (agent_api.php), jadi tidak
 * perlu IP publik, port forwarding, maupun VPN:
 *   - "probe" : permintaan HTTP / TCP yang hasilnya disimpan sementara (status NVR, snapshot kamera, kamera ber-IP).
 *               Server menandai probe yang dibutuhkan, agen mengambilnya pada polling berikutnya.
 *   - "job"   : perintah sekali jalan yang ditunggu hasilnya (ping, cek port TCP, tabel ARP) untuk menu Jaringan.
 *
 * Tidak ada tabel database baru: semua tersimpan sebagai file di includes/data/agent/ (folder ditolak dari browser).
 */

const AGENT_FILE    = __DIR__ . '/data/agent.json';
const AGENT_DIR     = __DIR__ . '/data/agent';
const AGENT_VERSION = '1.0';

function agentDefaults(): array
{
    return [
        'server_mode' => 'auto',   // auto | office | hosting (dipilih di installer, bisa diubah di menu Agen Kantor)
        'detected'    => '',       // hasil deteksi otomatis: office | hosting
        'detected_at' => '',
        'enabled'     => false,    // Agen Kantor dipakai
        'key'         => '',       // kunci rahasia agen
        'public_url'  => '',       // alamat aplikasi yang dihubungi agen (kosong = otomatis dari browser admin)
        'last_seen'   => 0,        // unix time polling terakhir dari agen
        'info'        => [],       // info PC agen: host, php, versi
        'hot_until'   => 0,        // sampai kapan agen diminta polling cepat (halaman Jaringan / live view terbuka)
        'last_cctv'   => 0,        // unix time cek CCTV terakhir yang dipicu agen
    ];
}

function agentSettings(bool $refresh = false): array
{
    static $cache = null;
    if ($cache === null || $refresh) {
        $cache = agentDefaults();
        if (is_file(AGENT_FILE)) {
            $d = json_decode((string)@file_get_contents(AGENT_FILE), true);
            if (is_array($d)) foreach ($cache as $k => $v) if (array_key_exists($k, $d)) {
                $cache[$k] = is_array($v) ? (array)$d[$k] : (is_bool($v) ? (bool)$d[$k] : (is_int($v) ? (int)$d[$k] : (string)$d[$k]));
            }
        }
        if (!in_array($cache['server_mode'], ['auto', 'office', 'hosting'], true)) $cache['server_mode'] = 'auto';
    }
    return $cache;
}

/** Simpan sebagian pengaturan agen (baca-ubah-tulis dengan kunci file agar aman dipanggil bersamaan). */
function saveAgentSettings(array $changes): bool
{
    if (!is_dir(dirname(AGENT_FILE))) @mkdir(dirname(AGENT_FILE), 0775, true);
    $fp = @fopen(AGENT_FILE, 'c+');
    if (!$fp) return false;
    flock($fp, LOCK_EX);
    $raw = stream_get_contents($fp);
    $d = json_decode((string)$raw, true);
    $d = array_merge(agentDefaults(), is_array($d) ? $d : [], $changes);
    ftruncate($fp, 0); rewind($fp);
    $ok = fwrite($fp, json_encode($d, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) !== false;
    fflush($fp); flock($fp, LOCK_UN); fclose($fp);
    agentSettings(true);
    return $ok;
}

/**
 * Deteksi lokasi server: Windows (XAMPP) = kantor. Linux tanpa proc_open atau tanpa izin ping = hosting.
 * Hasil disimpan agar tidak menjalankan ping setiap halaman dibuka.
 */
function agentDetectServer(bool $force = false): string
{
    $s = agentSettings();
    if (!$force && in_array($s['detected'], ['office', 'hosting'], true)) return $s['detected'];
    $mode = 'hosting';
    if (PHP_OS_FAMILY === 'Windows') {
        $mode = 'office';
    } elseif (function_exists('proc_open') && !in_array('proc_open', array_map('trim', explode(',', (string)ini_get('disable_functions'))), true)) {
        $bin = 'ping';
        foreach (['/bin/ping', '/usr/bin/ping', '/sbin/ping'] as $p) if (@is_file($p)) { $bin = $p; break; }
        $p = @proc_open([$bin, '-c', '1', '-W', '1', '127.0.0.1'], [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes, null, null);
        if (is_resource($p)) {
            fclose($pipes[0]);
            $out = (string)stream_get_contents($pipes[1]);
            fclose($pipes[1]); fclose($pipes[2]);
            $code = proc_close($p);
            if ($code === 0 && stripos($out, 'ttl=') !== false) $mode = 'office';
        }
    }
    saveAgentSettings(['detected' => $mode, 'detected_at' => date('Y-m-d H:i:s')]);
    return $mode;
}

/** 'office' = server di jaringan kantor (bisa ping & menjangkau IP lokal), 'hosting' = server di internet. */
function serverMode(): string
{
    $s = agentSettings();
    return $s['server_mode'] === 'auto' ? agentDetectServer() : $s['server_mode'];
}

function isHostingServer(): bool
{
    return serverMode() === 'hosting';
}

/** Agen Kantor diaktifkan dan punya kunci. */
function agentEnabled(): bool
{
    $s = agentSettings();
    return $s['enabled'] && $s['key'] !== '';
}

/** Agen melapor dalam 3 menit terakhir. */
function agentOnline(): bool
{
    return agentEnabled() && time() - (int)agentSettings()['last_seen'] <= 180;
}

/**
 * Cara menjangkau jaringan lokal kantor untuk ping/scan/kamera ber-IP:
 * 'local' = langsung dari server, 'agent' = lewat Agen Kantor, 'none' = tidak bisa (hosting tanpa agen).
 */
function agentLanMode(): string
{
    if (!isHostingServer()) return 'local';
    return agentEnabled() ? 'agent' : 'none';
}

/** Minta agen polling cepat selama $sec detik (dipanggil saat halaman yang butuh agen sedang dibuka). */
function agentTouchHot(int $sec = 300): void
{
    if (!agentEnabled()) return;
    $until = time() + $sec;
    if ((int)agentSettings()['hot_until'] < $until - 30) saveAgentSettings(['hot_until' => $until]);
}

/** Alamat IP privat / lokal (tidak bisa dijangkau dari hosting). */
function agentIsPrivateHost(string $host): bool
{
    $host = trim((string)preg_replace('#^[a-z]+://#i', '', $host));
    $host = (string)preg_replace('#[:/].*$#', '', $host);
    if ($host === '' || strcasecmp($host, 'localhost') === 0 || preg_match('/\.local$/i', $host)) return true;
    if (!filter_var($host, FILTER_VALIDATE_IP)) return false;
    return !filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
}

function agentDir(string $sub): string
{
    $d = AGENT_DIR . '/' . $sub;
    if (!is_dir($d)) @mkdir($d, 0775, true);
    return $d;
}

/** Waktu sekarang dengan pecahan detik (untuk umur cache). */
function agentNow(): float
{
    return microtime(true);
}

/* ================================================================== Probe (HTTP / TCP dengan cache) */

function agentProbeId(string $kind, string $target, string $user = ''): string
{
    return sha1($kind . '|' . $target . '|' . $user);
}

function agentProbeRead(string $id): ?array
{
    $f = agentDir('probe') . '/' . $id . '.json';
    if (!is_file($f)) return null;
    $d = json_decode((string)@file_get_contents($f), true);
    return is_array($d) ? $d : null;
}

function agentProbeWrite(string $id, array $d): void
{
    $f = agentDir('probe') . '/' . $id . '.json';
    $tmp = $f . '.' . getmypid() . '.tmp';
    if (@file_put_contents($tmp, json_encode($d, JSON_UNESCAPED_SLASHES)) !== false) @rename($tmp, $f);
}

/**
 * Ambil hasil probe lewat agen. $kind 'http' ($target = URL) atau 'tcp' ($target = "host:port").
 * Hasil yang umurnya <= $maxAge detik langsung dipakai; kalau tidak ada, probe ditandai "dibutuhkan" dan,
 * bila $wait > 0, ditunggu sampai agen mengirim hasil (maks. $wait detik).
 * Return [code, body]: code -1 = belum ada hasil (menunggu agen), 0 = tidak terjangkau, lainnya = kode HTTP (tcp: 1 = terbuka).
 */
function agentProbe(string $kind, string $target, string $user, string $pass, int $timeout, float $maxAge, int $wait = 0): array
{
    $id = agentProbeId($kind, $target, $user);
    $now = agentNow();
    $p = agentProbeRead($id) ?? ['kind' => $kind, 'target' => $target, 'user' => $user, 'res_at' => 0, 'sent_at' => 0];
    $fresh = function (?array $x) use ($maxAge): bool { return $x && !empty($x['res_at']) && agentNow() - (float)$x['res_at'] <= $maxAge; };
    $result = function (array $x) use ($id): array {
        $body = is_file(agentDir('probe') . '/' . $id . '.bin') ? (string)@file_get_contents(agentDir('probe') . '/' . $id . '.bin') : '';
        return [(int)$x['code'], $body];
    };
    // Tandai dibutuhkan (dengan umur maksimum terkecil yang diminta dalam 20 detik terakhir).
    $p['pass'] = $pass;
    $p['timeout'] = $timeout;
    $p['max_age'] = (!empty($p['want_at']) && $now - (float)$p['want_at'] < 20) ? min((float)($p['max_age'] ?? $maxAge), $maxAge) : $maxAge;
    $p['want_at'] = $now;
    if ($fresh($p)) { agentProbeWrite($id, $p); return $result($p); }
    agentProbeWrite($id, $p);
    if ($wait > 0) {
        agentTouchHot(120);
        $end = $now + $wait;
        while (agentNow() < $end) {
            usleep(400000);
            clearstatcache();
            $x = agentProbeRead($id);
            if ($fresh($x)) return $result($x);
        }
    }
    // Hasil lama (lebih tua dari $maxAge) tetap lebih baik daripada tidak ada, kecuali sudah > 10 menit.
    if (!empty($p['res_at']) && $now - (float)$p['res_at'] <= 600 && $maxAge >= 30) return $result($p);
    return [-1, ''];
}

/** Daftar probe yang perlu dikerjakan agen sekarang (dibutuhkan dalam 2 menit terakhir dan hasilnya sudah kedaluwarsa). */
function agentPendingProbes(int $limit = 40): array
{
    $out = [];
    $now = agentNow();
    foreach ((array)@glob(agentDir('probe') . '/*.json') as $f) {
        $p = json_decode((string)@file_get_contents($f), true);
        if (!is_array($p)) continue;
        $id = basename($f, '.json');
        if ($now - (float)($p['want_at'] ?? 0) > 86400) { @unlink($f); @unlink(substr($f, 0, -5) . '.bin'); continue; }   // tidak dipakai lagi
        if ($now - (float)($p['want_at'] ?? 0) > max(120, (float)($p['max_age'] ?? 60) * 1.5)) continue;   // tidak dibutuhkan lagi
        $age = $now - (float)($p['res_at'] ?? 0);
        if ($age < max(1.0, (float)($p['max_age'] ?? 60) * 0.8)) continue;
        if ($now - (float)($p['sent_at'] ?? 0) < min(20, max(4, (int)($p['timeout'] ?? 8) + 4))) continue;   // sedang dikerjakan agen
        $p['sent_at'] = $now;
        agentProbeWrite($id, $p);
        $out[] = ['id' => $id, 'kind' => (string)$p['kind'], 'target' => (string)$p['target'], 'user' => (string)($p['user'] ?? ''),
                  'pass' => (string)($p['pass'] ?? ''), 'timeout' => (int)($p['timeout'] ?? 8)];
        if (count($out) >= $limit) break;
    }
    return $out;
}

/** Simpan hasil probe dari agen. $res = [id => ['code' => int, 'body' => base64]] */
function agentStoreProbeResults(array $res): int
{
    $n = 0;
    foreach ($res as $id => $r) {
        if (!preg_match('/^[0-9a-f]{40}$/', (string)$id) || !is_array($r)) continue;
        $p = agentProbeRead($id);
        if (!$p) continue;
        $body = base64_decode((string)($r['body'] ?? ''), true);
        $bin = agentDir('probe') . '/' . $id . '.bin';
        $tmp = $bin . '.' . getmypid() . '.tmp';
        if (@file_put_contents($tmp, $body === false ? '' : $body) !== false) @rename($tmp, $bin);
        $p['code'] = (int)($r['code'] ?? 0);
        $p['res_at'] = agentNow();
        $p['sent_at'] = 0;
        agentProbeWrite($id, $p);
        $n++;
    }
    return $n;
}

/* ================================================================== Job (perintah yang ditunggu hasilnya) */

/**
 * Kirim perintah ke agen lalu tunggu hasilnya. $type: ping | tcp | arp. Return hasil (array) atau null bila agen
 * tidak menjawab dalam $wait detik.
 */
function agentRunJob(string $type, array $params, int $wait = 40): ?array
{
    if (!agentEnabled()) return null;
    $id = bin2hex(random_bytes(8));
    $dir = agentDir('job');
    @file_put_contents($dir . '/' . $id . '.json', json_encode(['type' => $type, 'params' => $params, 'created' => agentNow(), 'sent_at' => 0], JSON_UNESCAPED_SLASHES), LOCK_EX);
    agentTouchHot(300);
    @set_time_limit($wait + 30);
    $end = agentNow() + $wait;
    $resFile = $dir . '/' . $id . '.res.json';
    while (agentNow() < $end) {
        usleep(300000);
        clearstatcache(true, $resFile);
        if (is_file($resFile)) {
            $r = json_decode((string)@file_get_contents($resFile), true);
            @unlink($resFile); @unlink($dir . '/' . $id . '.json');
            return is_array($r) ? $r : [];
        }
    }
    @unlink($dir . '/' . $id . '.json');   // agen tidak sempat: batalkan
    return null;
}

/** Job yang belum dikirim ke agen (atau sudah dikirim > 60 detik tanpa hasil). */
function agentPendingJobs(): array
{
    $out = [];
    $now = agentNow();
    foreach ((array)@glob(agentDir('job') . '/*.json') as $f) {
        if (substr($f, -9) === '.res.json') {
            if ($now - (float)@filemtime($f) > 600) @unlink($f);
            continue;
        }
        $j = json_decode((string)@file_get_contents($f), true);
        if (!is_array($j)) continue;
        if ($now - (float)($j['created'] ?? 0) > 300) { @unlink($f); continue; }
        if ($now - (float)($j['sent_at'] ?? 0) < 60) continue;
        $j['sent_at'] = $now;
        @file_put_contents($f, json_encode($j, JSON_UNESCAPED_SLASHES), LOCK_EX);
        $out[] = ['id' => basename($f, '.json'), 'type' => (string)$j['type'], 'params' => (array)$j['params']];
    }
    return $out;
}

function agentStoreJobResults(array $res): int
{
    $n = 0;
    $dir = agentDir('job');
    foreach ($res as $id => $r) {
        if (!preg_match('/^[0-9a-f]{16}$/', (string)$id) || !is_file($dir . '/' . $id . '.json')) continue;
        @file_put_contents($dir . '/' . $id . '.res.json', json_encode(is_array($r) ? $r : [], JSON_UNESCAPED_SLASHES), LOCK_EX);
        $n++;
    }
    return $n;
}

/** Ada pekerjaan yang membuat agen sebaiknya polling cepat? */
function agentIsHot(): bool
{
    if ((int)agentSettings()['hot_until'] > time()) return true;
    foreach ((array)@glob(agentDir('job') . '/*.json') as $f) if (substr($f, -9) !== '.res.json') return true;
    return false;
}

/* ================================================================== Tampilan */

/** Teks status agen untuk ditampilkan di halaman. */
function agentStatusText(): string
{
    $s = agentSettings();
    if (!agentEnabled()) return function_exists('cL') ? cL('Agen Kantor tidak aktif', 'Office Agent is off') : 'Agen Kantor tidak aktif';
    if (!$s['last_seen']) return function_exists('cL') ? cL('Agen Kantor aktif, belum pernah melapor', 'Office Agent on, never reported') : 'Agen Kantor belum pernah melapor';
    $ago = time() - (int)$s['last_seen'];
    $when = $ago < 90 ? $ago . (function_exists('cL') ? cL(' detik lalu', ' s ago') : ' detik lalu') : date('d M H:i', (int)$s['last_seen']);
    $host = (string)($s['info']['host'] ?? '');
    return (function_exists('cL') ? cL('Agen Kantor terakhir melapor ', 'Office Agent last reported ') : 'Agen Kantor terakhir melapor ') . $when . ($host !== '' ? ' · ' . $host : '');
}

/** Alamat dasar aplikasi untuk agen, mis. https://domain.com/asker-it-asset/ */
function agentBaseUrl(): string
{
    $s = agentSettings();
    if (trim($s['public_url']) !== '') return rtrim(trim($s['public_url']), '/') . '/';
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    $host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
    $dir = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
    return ($https ? 'https' : 'http') . '://' . $host . $dir . '/';
}
