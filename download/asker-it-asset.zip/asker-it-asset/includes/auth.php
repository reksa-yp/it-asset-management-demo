<?php
/**
 * Session bootstrap + helper RBAC (Role-Based Access Control).
 * Include file ini di baris PALING ATAS setiap halaman yang butuh login.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/lang.php';
require_once __DIR__ . '/icons.php';
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/asset_owners.php';
require_once __DIR__ . '/user_position.php';
require_once __DIR__ . '/asset_software.php';
require_once __DIR__ . '/tablet.php';
require_once __DIR__ . '/asset_user_sync.php';
require_once __DIR__ . '/ticket_cancel.php';
initLang();

/** Wajib login. Redirect ke login.php kalau belum ada sesi. */
function requireLogin(): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

/** Wajib role admin. Panggil setelah requireLogin(). */
function requireAdmin(): void
{
    requireLogin();
    if (($_SESSION['role'] ?? '') !== 'admin') {
        http_response_code(403);
        die('<div style="font-family:sans-serif;padding:40px;text-align:center">
                <h2>403 - Akses Ditolak</h2>
                <p>Halaman ini khusus untuk Admin.</p>
                <a href="my_asset.php">Kembali ke Aset Saya</a>
             </div>');
    }
}

function currentUser(): array
{
    return [
        'id'        => $_SESSION['user_id']   ?? null,
        'username'  => $_SESSION['username']  ?? null,
        'full_name' => $_SESSION['full_name'] ?? null,
        'role'      => $_SESSION['role']      ?? null,
    ];
}

function isAdmin(): bool
{
    return ($_SESSION['role'] ?? '') === 'admin';
}

/**
 * Ambil 1 baris aset dari DB dengan validasi kepemilikan:
 * - Admin boleh akses aset siapa saja.
 * - User biasa hanya boleh akses aset yang salah satu penggunanya adalah dirinya
 *   (1 aset sekarang bisa dipakai beberapa pengguna sekaligus, lihat includes/asset_owners.php).
 * Return null kalau tidak ditemukan / bukan pemiliknya (jangan bocorkan mana penyebabnya).
 */
function getAssetForCurrentUser(int $assetId): ?array
{
    $db = getDB();
    $stmt = $db->prepare("SELECT a.* FROM assets a WHERE a.id = ?");
    $stmt->execute([$assetId]);
    $asset = $stmt->fetch();
    if (!$asset) return null;

    if (!isAdmin() && !assetOwnedByUser($db, $assetId, (int)$_SESSION['user_id'])) {
        return null; // bukan pemilik -> perlakukan seolah tidak ditemukan
    }

    // owner_name: gabungan nama semua pengguna aset ini, dipisah ", " (dipakai
    // detail aset, print, PDF, dan label).
    $asset['owner_name'] = ownerNamesLabel(getOwnersForAsset($db, $assetId));
    // Daftar software aset ini (bisa lebih dari satu, masing-masing dengan
    // Serial Number & status Original/Belum Original sendiri).
    $asset['software_items'] = getSoftwareForAsset($db, $assetId);
    return $asset;
}

/** Simple CSRF token helper */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrfCheck(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        die('CSRF token tidak valid. Silakan ulangi.');
    }
}
