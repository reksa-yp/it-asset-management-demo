<?php
/**
 * Pengaturan tampilan sistem: nama aplikasi & logo.
 *
 * Disimpan di file JSON (includes/data/app_settings.json), BUKAN di database,
 * jadi struktur database tidak berubah sama sekali.
 * File logo disimpan di folder assets/uploads/logo/.
 *
 * Jika belum pernah diatur, sistem memakai nama bawaan dari file bahasa
 * (key 'app_name') dan logo teks "IT" seperti sebelumnya.
 */

const APP_SETTINGS_FILE = __DIR__ . '/data/app_settings.json';
const APP_LOGO_DIR      = __DIR__ . '/../assets/uploads/logo';
const APP_LOGO_URL_DIR  = 'assets/uploads/logo';
const APP_LOGO_MAX_SIZE = 2 * 1024 * 1024; // 2 MB
const APP_LOGO_TYPES    = [                 // mime => ekstensi (SVG sengaja tidak diizinkan demi keamanan)
    'image/png'  => 'png',
    'image/jpeg' => 'jpg',
    'image/webp' => 'webp',
    'image/gif'  => 'gif',
];

const APP_ASSET_PREFIX_DEFAULT = 'AST'; // awalan Nomor Aset bawaan (bisa diubah di Pengaturan Sistem)

/** Rapikan awalan Nomor Aset: huruf besar/angka saja, maksimal 6 karakter ('' = belum diatur). */
function normalizeAssetPrefix(string $prefix): string
{
    return substr(preg_replace('/[^A-Z0-9]/', '', strtoupper($prefix)), 0, 6);
}

/** Awalan Nomor Aset otomatis, mis. "AST" -> AST/FIN/PC/001. */
function assetPrefix(): string
{
    $p = appSettings()['asset_prefix'];
    return $p !== '' ? $p : APP_ASSET_PREFIX_DEFAULT;
}

/** Baca pengaturan (cache per-request). */
function appSettings(): array
{
    static $cache = null;
    if ($cache === null) {
        $cache = ['app_name' => '', 'logo' => '', 'asset_prefix' => ''];
        if (is_file(APP_SETTINGS_FILE)) {
            $data = json_decode((string)file_get_contents(APP_SETTINGS_FILE), true);
            if (is_array($data)) {
                $cache['app_name'] = trim((string)($data['app_name'] ?? ''));
                $cache['logo']     = basename((string)($data['logo'] ?? ''));
                $cache['asset_prefix'] = normalizeAssetPrefix((string)($data['asset_prefix'] ?? ''));
            }
        }
    }
    return $cache;
}

/** Simpan pengaturan ke file JSON. */
function saveAppSettings(array $settings): bool
{
    $dir = dirname(APP_SETTINGS_FILE);
    if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
    $data = [
        'app_name'   => trim((string)($settings['app_name'] ?? '')),
        'logo'       => basename((string)($settings['logo'] ?? '')),
        // Kalau pemanggil tidak mengirim asset_prefix, nilai yang tersimpan dipertahankan.
        'asset_prefix' => normalizeAssetPrefix((string)($settings['asset_prefix'] ?? appSettings()['asset_prefix'])),
        'updated_at' => date('Y-m-d H:i:s'),
    ];
    return file_put_contents(
        APP_SETTINGS_FILE,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        LOCK_EX
    ) !== false;
}

/** Nama aplikasi yang diatur admin ('' = pakai nama bawaan dari file bahasa). */
function customAppName(): string
{
    return appSettings()['app_name'];
}

/** Path file logo di server, atau '' jika belum ada logo. */
function appLogoPath(): string
{
    $logo = appSettings()['logo'];
    if ($logo === '') return '';
    $path = APP_LOGO_DIR . '/' . $logo;
    return is_file($path) ? $path : '';
}

/** URL logo (dengan cache-busting), atau '' jika belum ada logo. */
function appLogoUrl(): string
{
    $path = appLogoPath();
    if ($path === '') return '';
    return APP_LOGO_URL_DIR . '/' . rawurlencode(basename($path)) . '?v=' . filemtime($path);
}

/** Logo sebagai data URI base64 — dipakai di cetak & PDF (dompdf) supaya tidak bergantung URL. */
function appLogoDataUri(): string
{
    $path = appLogoPath();
    if ($path === '') return '';
    $info = @getimagesize($path);
    $mime = $info['mime'] ?? 'image/png';
    return 'data:' . $mime . ';base64,' . base64_encode((string)file_get_contents($path));
}

/** Inisial untuk logo teks saat belum ada logo gambar (mis. "IT Asset Management" -> "IT"). */
function appInitials(): string
{
    $name  = trim(t('app_name'));
    $first = preg_split('/\s+/', $name)[0] ?? 'IT';
    $ini   = function_exists('mb_substr') ? mb_substr($first, 0, 2) : substr($first, 0, 2);
    return strtoupper($ini !== '' ? $ini : 'IT');
}

/**
 * HTML logo siap pakai.
 * $boxClass  : kelas ukuran/bentuk kotak, mis. 'w-8 h-8 rounded-lg'
 * $textClass : kelas untuk logo teks (warna latar & font) saat belum ada logo gambar
 */
function appLogoHtml(string $boxClass = 'w-8 h-8 rounded-lg', string $textClass = 'bg-brand-500 text-white font-bold'): string
{
    $url = appLogoUrl();
    $alt = htmlspecialchars(t('app_name'), ENT_QUOTES);
    if ($url !== '') {
        return '<img src="' . htmlspecialchars($url, ENT_QUOTES) . '" alt="' . $alt . '" class="' . $boxClass
             . ' object-contain bg-white p-0.5 shrink-0">';
    }
    return '<div class="' . $boxClass . ' ' . $textClass . ' flex items-center justify-center shrink-0">'
         . htmlspecialchars(appInitials()) . '</div>';
}

/** Tag <link rel="icon"> untuk favicon di tab browser (hanya jika ada logo). */
function appFaviconTag(): string
{
    $url = appLogoUrl();
    return $url !== '' ? '<link rel="icon" href="' . htmlspecialchars($url, ENT_QUOTES) . '">' : '';
}

/**
 * Proses upload logo dari $_FILES[$field].
 * Mengembalikan ['ok'=>true, 'file'=>nama file baru] atau ['ok'=>false, 'error'=>kunci pesan].
 */
function handleLogoUpload(string $field): array
{
    $f = $_FILES[$field] ?? null;
    if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return ['ok' => true, 'file' => ''];
    }
    if ($f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) {
        return ['ok' => false, 'error' => 'settings_logo_upload_failed'];
    }
    if ($f['size'] > APP_LOGO_MAX_SIZE) {
        return ['ok' => false, 'error' => 'settings_logo_too_big'];
    }
    $info = @getimagesize($f['tmp_name']);
    $mime = $info['mime'] ?? '';
    if (!isset(APP_LOGO_TYPES[$mime])) {
        return ['ok' => false, 'error' => 'settings_logo_invalid_type'];
    }
    if (!is_dir(APP_LOGO_DIR) && !@mkdir(APP_LOGO_DIR, 0775, true)) {
        return ['ok' => false, 'error' => 'settings_logo_upload_failed'];
    }
    $name = 'logo_' . date('Ymd_His') . '.' . APP_LOGO_TYPES[$mime];
    if (!move_uploaded_file($f['tmp_name'], APP_LOGO_DIR . '/' . $name)) {
        return ['ok' => false, 'error' => 'settings_logo_upload_failed'];
    }
    return ['ok' => true, 'file' => $name];
}

/** Hapus file logo lama dari server. */
function deleteLogoFile(string $file): void
{
    $file = basename($file);
    if ($file !== '' && is_file(APP_LOGO_DIR . '/' . $file)) {
        @unlink(APP_LOGO_DIR . '/' . $file);
    }
}
