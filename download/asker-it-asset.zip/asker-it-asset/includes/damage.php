<?php
/**
 * Menu Aset Rusak.
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA:
 * - Hanya MEMBUAT 1 tabel BARU: asset_damages (dibuat otomatis saat menu dibuka).
 * - Kolom assets.status (ENUM Digunakan/Stok/Tidak Digunakan) TIDAK diubah.
 *   Selama rusak, status aset = 'Tidak Digunakan'. Selesai diperbaiki -> 'Stok'
 *   (atau 'Digunakan' bila pengguna tidak dilepas). Disposal -> tetap 'Tidak Digunakan'.
 */

/** Status catatan kerusakan. open = aset masih dianggap rusak. */
const DAMAGE_STATES = [
    'broken'   => ['open' => true,  'badge' => 'bg-red-100 text-red-700'],
    'repair'   => ['open' => true,  'badge' => 'bg-amber-100 text-amber-800'],
    'fixed'    => ['open' => false, 'badge' => 'bg-green-100 text-green-700'],
    'disposed' => ['open' => false, 'badge' => 'bg-slate-200 text-slate-700'],
];

function damageStateLabel(string $s): string { return t('dmg_state_' . (isset(DAMAGE_STATES[$s]) ? $s : 'broken')); }
function damageStateBadge(string $s): string { return DAMAGE_STATES[$s]['badge'] ?? DAMAGE_STATES['broken']['badge']; }
function damageStateOpen(string $s): bool   { return DAMAGE_STATES[$s]['open'] ?? true; }

function damageTableExists(PDO $db, bool $refresh = false): bool
{
    static $exists = null;
    if ($exists === null || $refresh) {
        $exists = (bool)$db->query("SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_damages'")->fetchColumn();
    }
    return $exists;
}

/** Buat tabel asset_damages jika belum ada. Panggil SEBELUM beginTransaction. */
function ensureDamageTable(PDO $db): void
{
    if (damageTableExists($db)) return;
    $db->exec("
        CREATE TABLE IF NOT EXISTS asset_damages (
            id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            asset_id          INT UNSIGNED NOT NULL,              -- assets.id (tanpa foreign key)
            asset_number      VARCHAR(30)  NOT NULL,              -- salinan nomor aset saat dicatat
            asset_category    VARCHAR(60)  DEFAULT NULL,
            asset_name        VARCHAR(150) DEFAULT NULL,
            damage_date       DATE         NOT NULL,              -- tanggal rusak
            issue             VARCHAR(255) NOT NULL,              -- kerusakan
            storage_location  VARCHAR(100) NOT NULL,              -- lokasi penyimpanan aset rusak
            last_user_names   VARCHAR(500) DEFAULT NULL,          -- pengguna saat rusak (salinan)
            last_department   VARCHAR(100) DEFAULT NULL,
            prev_status       VARCHAR(20)  DEFAULT NULL,          -- status aset sebelum ditandai rusak
            state             VARCHAR(20)  NOT NULL DEFAULT 'broken', -- broken / repair / fixed / disposed
            note              TEXT         DEFAULT NULL,
            closed_date       DATE         DEFAULT NULL,          -- tanggal selesai diperbaiki / disposal
            created_by        INT UNSIGNED DEFAULT NULL,
            created_by_name   VARCHAR(100) DEFAULT NULL,
            created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_dmg_asset (asset_id),
            INDEX idx_dmg_state (state),
            INDEX idx_dmg_date (damage_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    damageTableExists($db, true);
}

/** Catatan rusak yang masih terbuka per aset: [asset_id => row]. */
function getOpenDamageMap(PDO $db, array $assetIds = []): array
{
    if (!damageTableExists($db)) return [];
    $sql = "SELECT * FROM asset_damages WHERE state IN ('broken','repair')";
    $params = [];
    $assetIds = array_values(array_filter(array_map('intval', $assetIds)));
    if ($assetIds) {
        $sql .= ' AND asset_id IN (' . implode(',', array_fill(0, count($assetIds), '?')) . ')';
        $params = $assetIds;
    }
    $stmt = $db->prepare($sql . ' ORDER BY id');
    $stmt->execute($params);
    $out = [];
    foreach ($stmt->fetchAll() as $r) $out[(int)$r['asset_id']] = $r;
    return $out;
}

/** Filter halaman Aset Rusak (dipakai juga oleh export & print supaya hasilnya sama). */
function damageFilters(): array
{
    $isDate = fn($d) => (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $d);
    $state  = (string)($_GET['state'] ?? 'open');
    if ($state !== 'open' && $state !== 'all' && !isset(DAMAGE_STATES[$state])) $state = 'open';
    return [
        'state' => $state,
        'from'  => $isDate($_GET['from'] ?? '') ? $_GET['from'] : '',
        'to'    => $isDate($_GET['to'] ?? '') ? $_GET['to'] : '',
        'cat'   => trim((string)($_GET['cat'] ?? '')),
        'q'     => trim((string)($_GET['q'] ?? '')),
    ];
}

function damageFilterQuery(array $f): string
{
    return http_build_query(array_filter($f, fn($v) => $v !== ''));
}

function getDamages(PDO $db, array $f): array
{
    if (!damageTableExists($db)) return [];
    $where = []; $p = [];
    if ($f['state'] === 'open')      { $where[] = "d.state IN ('broken','repair')"; }
    elseif ($f['state'] !== 'all')   { $where[] = 'd.state = ?'; $p[] = $f['state']; }
    if ($f['from']) { $where[] = 'd.damage_date >= ?'; $p[] = $f['from']; }
    if ($f['to'])   { $where[] = 'd.damage_date <= ?'; $p[] = $f['to']; }
    if ($f['cat'] !== '') { $where[] = 'COALESCE(a.category, d.asset_category) = ?'; $p[] = $f['cat']; }
    if ($f['q'] !== '') {
        $where[] = '(d.asset_number LIKE ? OR a.asset_number LIKE ? OR d.asset_name LIKE ? OR d.issue LIKE ? OR d.storage_location LIKE ?
                    OR d.last_user_names LIKE ? OR d.last_department LIKE ? OR d.note LIKE ?)';
        $like = '%' . $f['q'] . '%';
        array_push($p, $like, $like, $like, $like, $like, $like, $like, $like);
    }
    $sql = "SELECT d.*, a.asset_number AS current_number, a.category AS current_category, a.device_name AS current_name,
                   a.status AS asset_status, a.serial_number
            FROM asset_damages d LEFT JOIN assets a ON a.id = d.asset_id"
         . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
         . " ORDER BY FIELD(d.state,'broken','repair','fixed','disposed'), d.damage_date DESC, d.id DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($p);
    return $stmt->fetchAll();
}

/** Jumlah catatan per status (tanpa filter status). */
function getDamageCounts(PDO $db): array
{
    $out = array_fill_keys(array_keys(DAMAGE_STATES), 0);
    if (!damageTableExists($db)) return $out;
    foreach ($db->query("SELECT state, COUNT(*) n FROM asset_damages GROUP BY state") as $r) {
        if (isset($out[$r['state']])) $out[$r['state']] = (int)$r['n'];
    }
    return $out;
}

/** Riwayat kerusakan 1 aset (terbaru dulu) — untuk detail / print / PDF aset. */
function getAssetDamageHistory(PDO $db, int $assetId): array
{
    if (!damageTableExists($db)) return [];
    $stmt = $db->prepare("SELECT * FROM asset_damages WHERE asset_id = ? ORDER BY damage_date DESC, id DESC");
    $stmt->execute([$assetId]);
    return $stmt->fetchAll();
}

/** Lokasi penyimpanan yang pernah dipakai (untuk saran isian). */
function getDamageStorageOptions(PDO $db): array
{
    if (!damageTableExists($db)) return [];
    return $db->query("SELECT storage_location FROM asset_damages GROUP BY storage_location ORDER BY MAX(id) DESC LIMIT 30")
              ->fetchAll(PDO::FETCH_COLUMN);
}

/** Lama rusak dalam hari (sampai tanggal selesai, atau hari ini bila masih terbuka). */
function damageDays(array $d): int
{
    $end = $d['closed_date'] ?: date('Y-m-d');
    return max(0, (int)floor((strtotime($end) - strtotime($d['damage_date'])) / 86400));
}
