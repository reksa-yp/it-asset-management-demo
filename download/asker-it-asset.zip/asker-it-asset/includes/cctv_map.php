<?php
/**
 * Map CCTV: layout PDF/gambar + titik kamera (dan switch) yang bisa digeser, diberi warna, dan dihubungkan
 * ke switch PoE (sinkron dengan topologi jaringan: tabel net_links milik menu Jaringan).
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA: hanya membuat tabel BARU (CREATE TABLE IF NOT EXISTS), tidak ada ALTER.
 *   cctv_maps        : daftar peta (nama, file gambar hasil render PDF, ukuran)
 *   cctv_map_points  : titik di peta (kamera / switch) + posisi, arah, warna khusus, kategori, tgl pasang
 *   cctv_map_cfg     : pengaturan (jumlah hari "CCTV Baru", warna baru & dummy)
 *   cctv_map_nvr     : warna tiap NVR (diatur sendiri oleh admin)
 * Koneksi kamera -> switch + port TIDAK disimpan di sini, tetapi lewat netSetLink() (net_links), jadi topologi
 * di menu Jaringan otomatis ikut berubah.
 */
require_once __DIR__ . '/cctv.php';
require_once __DIR__ . '/network.php';

const CCTV_MAP_DIR = __DIR__ . '/../assets/uploads/cctv_map';
const CCTV_MAP_URL = 'assets/uploads/cctv_map';
const CCTV_MAP_NVR_COLORS = ['#f59e0b', '#0891b2', '#16a34a', '#9333ea', '#ea580c', '#db2777', '#65a30d', '#475569'];

function ensureCctvMapTables(PDO $db): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    $ddl = [
        "CREATE TABLE IF NOT EXISTS cctv_maps (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            name        VARCHAR(100) NOT NULL,
            image       VARCHAR(160) NOT NULL,
            pdf         VARCHAR(160) DEFAULT NULL,
            width       INT UNSIGNED NOT NULL DEFAULT 0,
            height      INT UNSIGNED NOT NULL DEFAULT 0,
            sort_order  INT UNSIGNED NOT NULL DEFAULT 0,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS cctv_map_points (
            id           INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            map_id       INT UNSIGNED NOT NULL,
            kind         VARCHAR(4)   NOT NULL DEFAULT 'cam',      -- cam | sw | plan
            asset_id     INT UNSIGNED DEFAULT NULL,                -- assets.id (NULL = dummy / tanpa aset)
            name         VARCHAR(100) DEFAULT NULL,                -- nama bebas (untuk dummy)
            label        VARCHAR(12)  DEFAULT NULL,                -- nomor yang tampil di titik
            x            DOUBLE       NOT NULL DEFAULT 0,          -- posisi 0..1 dari lebar gambar
            y            DOUBLE       NOT NULL DEFAULT 0,          -- posisi 0..1 dari tinggi gambar
            angle        SMALLINT     NOT NULL DEFAULT 0,
            fov          SMALLINT     NOT NULL DEFAULT 70,
            rng          SMALLINT     NOT NULL DEFAULT 45,         -- jarak pandang (permil dari lebar gambar)
            color        VARCHAR(9)   DEFAULT NULL,                -- warna khusus (kosong = otomatis)
            cat          VARCHAR(6)   NOT NULL DEFAULT 'lama',     -- baru | lama | dummy
            installed_at DATE         DEFAULT NULL,
            note         VARCHAR(255) DEFAULT NULL,
            updated_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_cmp_map (map_id),
            UNIQUE KEY uq_cmp (map_id, kind, asset_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS cctv_map_cfg (
            k VARCHAR(30) NOT NULL PRIMARY KEY,
            v VARCHAR(100) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS cctv_map_nvr (
            nvr_id INT UNSIGNED NOT NULL PRIMARY KEY,
            color  VARCHAR(9) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    ];
    foreach ($ddl as $q) {
        try { $db->exec($q); } catch (Throwable $e) { /* abaikan: tabel sudah ada */ }
    }
}

function cctvMapColor(string $c, string $fallback = ''): string
{
    $c = trim($c);
    return preg_match('/^#[0-9a-fA-F]{6}$/', $c) ? strtolower($c) : $fallback;
}

/** Letak kotak keterangan di peta: "x,y,w,h" (pecahan 0..1 dari ukuran gambar). Kosong bila tidak valid. */
function cctvMapLegRect(string $v): string
{
    if (!preg_match('/^(\d*\.?\d+),(\d*\.?\d+),(\d*\.?\d+),(\d*\.?\d+)$/', trim($v), $m)) return '';
    [$x, $y, $w, $h] = [(float)$m[1], (float)$m[2], (float)$m[3], (float)$m[4]];
    if ($w < .03 || $h < .03 || $x < 0 || $y < 0 || $x + $w > 1.001 || $y + $h > 1.001) return '';
    return round($x, 5) . ',' . round($y, 5) . ',' . round($w, 5) . ',' . round($h, 5);
}

function cctvMapCfg(PDO $db): array
{
    ensureCctvMapTables($db);
    $cfg = ['days' => 7, 'baru_color' => '#e11d48', 'dummy_color' => '#64748b'];
    foreach ($db->query("SELECT k, v FROM cctv_map_cfg")->fetchAll() as $r) {
        if ($r['k'] === 'days') $cfg['days'] = max(1, min(90, (int)$r['v']));
        elseif (in_array($r['k'], ['baru_color', 'dummy_color'], true)) $cfg[$r['k']] = cctvMapColor($r['v'], $cfg[$r['k']]);
        elseif (preg_match('/^leg_\d+$/', $r['k']) && cctvMapLegRect($r['v']) !== '') $cfg[$r['k']] = $r['v'];   // letak keterangan per peta
    }
    return $cfg;
}

function cctvMapSaveCfg(PDO $db, string $k, string $v): void
{
    ensureCctvMapTables($db);
    $db->prepare("REPLACE INTO cctv_map_cfg (k, v) VALUES (?, ?)")->execute([$k, $v]);
}

/** Warna tiap NVR: pilihan admin, atau warna bawaan berurutan bila belum dipilih. */
function cctvMapNvrColors(PDO $db, array $nvrs): array
{
    ensureCctvMapTables($db);
    $saved = [];
    foreach ($db->query("SELECT nvr_id, color FROM cctv_map_nvr")->fetchAll() as $r) $saved[(int)$r['nvr_id']] = $r['color'];
    $out = []; $i = 0;
    foreach ($nvrs as $id => $n) {
        $out[(int)$id] = $saved[(int)$id] ?? CCTV_MAP_NVR_COLORS[$i % count(CCTV_MAP_NVR_COLORS)];
        $i++;
    }
    return $out;
}

/** Semua data untuk halaman peta (dikirim ke JavaScript sebagai JSON). */
function cctvMapData(PDO $db): array
{
    ensureCctvMapTables($db);
    $cfg  = cctvMapCfg($db);
    $nvrs = cctvNvrList($db);
    $cols = cctvMapNvrColors($db, $nvrs);

    $maps = [];
    foreach ($db->query("SELECT id, name, image, pdf, width, height FROM cctv_maps ORDER BY sort_order, id")->fetchAll() as $m) {
        $maps[] = ['id' => (int)$m['id'], 'name' => $m['name'], 'url' => CCTV_MAP_URL . '/' . $m['image'], 'pdf' => $m['pdf'] ? CCTV_MAP_URL . '/' . $m['pdf'] : '', 'w' => (int)$m['width'], 'h' => (int)$m['height']];
    }
    $pts = [];
    foreach ($db->query("SELECT * FROM cctv_map_points ORDER BY id")->fetchAll() as $p) {
        $pts[] = [
            'id' => (int)$p['id'], 'map' => (int)$p['map_id'], 'kind' => $p['kind'], 'asset' => $p['asset_id'] !== null ? (int)$p['asset_id'] : null,
            'name' => (string)$p['name'], 'label' => (string)$p['label'], 'x' => (float)$p['x'], 'y' => (float)$p['y'],
            'ang' => (int)$p['angle'], 'fov' => (int)$p['fov'], 'rng' => (int)$p['rng'] / 1000,
            'color' => (string)$p['color'], 'cat' => $p['cat'], 'date' => (string)$p['installed_at'], 'note' => (string)$p['note'],
        ];
    }
    $cams = [];
    $camList = cctvCameras($db);
    foreach ($camList as $c) {
        $cams[$c['id']] = [
            'id' => $c['id'], 'no' => $c['number'], 'name' => $c['name'] !== '' ? $c['name'] : $c['number'], 'loc' => $c['location'], 'ip' => $c['ip'],
            'nvr' => $c['nvr_id'], 'nvr_name' => $c['nvr_name'], 'ch' => $c['channel'], 'state' => $c['state'],
        ];
    }
    // Nomor urut global (sama dengan List View: per NVR berurutan channel, NVR berikutnya melanjutkan, tanpa NVR di akhir).
    // Dipakai untuk mencocokkan nomor di layout PDF (1..N) dengan kamera saat "Impor titik dari PDF".
    $seq = 0;
    foreach (cctvNvrGroups($camList) as $g) foreach ($g['cams'] as $c) if (isset($cams[$c['id']])) $cams[$c['id']]['seq'] = ++$seq;
    $nets = []; $links = [];
    $all = netAssets($db);
    foreach ($all as $a) {
        if ($a['parent']) $links[$a['id']] = ['parent' => $a['parent'], 'port' => $a['port']];
        if ($a['is_net']) $nets[$a['id']] = [
            'id' => $a['id'], 'no' => $a['number'], 'name' => $a['name'], 'brand' => $a['brand'], 'ip' => $a['ip'], 'loc' => $a['loc'],
            'ports' => netPortNames($a), 'nports' => (int)$a['ports'], 'parent' => $a['parent'], 'uplink' => $a['port'],
        ];
    }
    return [
        'cfg' => $cfg, 'maps' => $maps, 'pts' => $pts, 'cams' => $cams, 'nets' => $nets,
        'nvrs' => array_values(array_map(fn($n) => ['id' => (int)$n['id'], 'name' => $n['name'], 'color' => $cols[(int)$n['id']]], $nvrs)),
        'links' => $links, 'used' => cctvMapUsedPorts($db, $all),
        'linkable' => array_keys($all),      // aset yang punya IP / perangkat jaringan (syarat bisa masuk net_links)
    ];
}

/** Port terpakai per perangkat: [id perangkat => [port huruf kecil => "tersambung ke X"]]. */
function cctvMapUsedPorts(PDO $db, ?array $all = null): array
{
    $all = $all ?? netAssets($db);
    $u = netUsedPorts($all, netExtraLinks($db));
    return $u ? $u : (object)[];
}

/** Simpan / ubah 1 titik. Return baris titik (format JSON halaman) atau melempar RuntimeException. */
function cctvMapSavePoint(PDO $db, array $in): array
{
    ensureCctvMapTables($db);
    $id    = (int)($in['id'] ?? 0);
    $map   = (int)($in['map'] ?? 0);
    $kind  = in_array($in['kind'] ?? 'cam', ['sw', 'plan'], true) ? $in['kind'] : 'cam';   // plan = rencana titik baru (penanda saja)
    $asset = (int)($in['asset'] ?? 0) ?: null;
    if (!$db->query("SELECT 1 FROM cctv_maps WHERE id = " . $map)->fetchColumn()) throw new RuntimeException('Peta tidak ditemukan.');
    if ($kind === 'sw' && !$asset) throw new RuntimeException('Pilih perangkat switch.');
    $cat = in_array($in['cat'] ?? '', ['baru', 'lama', 'dummy'], true) ? $in['cat'] : 'lama';
    if ($kind === 'sw') $cat = 'lama';
    if ($kind === 'plan') { $cat = 'lama'; $asset = null; }
    if ($kind === 'cam' && !$asset) $cat = 'dummy';
    $date = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($in['date'] ?? '')) ? $in['date'] : null;
    $row = [
        $map, $kind, $asset, mb_substr(trim((string)($in['name'] ?? '')), 0, 100), mb_substr(trim((string)($in['label'] ?? '')), 0, 12),
        max(0, min(1, (float)($in['x'] ?? 0))), max(0, min(1, (float)($in['y'] ?? 0))),
        ((int)($in['ang'] ?? 0) % 360 + 360) % 360, max(20, min(360, (int)($in['fov'] ?? 70))), max(10, min(150, (int)round(((float)($in['rng'] ?? 0.045)) * 1000))),
        cctvMapColor((string)($in['color'] ?? '')) ?: null, $cat, $date, mb_substr(trim((string)($in['note'] ?? '')), 0, 255),
    ];
    if ($id) {
        $st = $db->prepare("UPDATE cctv_map_points SET map_id=?, kind=?, asset_id=?, name=?, label=?, x=?, y=?, angle=?, fov=?, rng=?, color=?, cat=?, installed_at=?, note=?, updated_at=NOW() WHERE id=?");
        $st->execute([...$row, $id]);
    } else {
        if ($asset) {
            $dup = $db->prepare("SELECT id FROM cctv_map_points WHERE map_id=? AND kind=? AND asset_id=?");
            $dup->execute([$map, $kind, $asset]);
            if ($dup->fetchColumn()) throw new RuntimeException('Perangkat ini sudah ada di peta.');
        }
        $st = $db->prepare("INSERT INTO cctv_map_points (map_id, kind, asset_id, name, label, x, y, angle, fov, rng, color, cat, installed_at, note) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $st->execute($row);
        $id = (int)$db->lastInsertId();
    }
    return [
        'id' => $id, 'map' => $map, 'kind' => $kind, 'asset' => $asset, 'name' => $row[3], 'label' => $row[4], 'x' => $row[5], 'y' => $row[6],
        'ang' => $row[7], 'fov' => $row[8], 'rng' => $row[9] / 1000, 'color' => (string)$row[10], 'cat' => $cat, 'date' => (string)$date, 'note' => $row[13],
    ];
}

/** Simpan gambar peta (hasil render PDF di browser, JPEG/PNG) + PDF asli (opsional). Return [file, w, h, pdf]. */
function cctvMapStoreFiles(array $img, ?array $pdf): array
{
    if (($img['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('Gambar peta gagal diunggah (cek batas upload PHP).');
    $info = @getimagesize($img['tmp_name']);
    if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG], true)) throw new RuntimeException('Gambar peta harus JPEG atau PNG.');
    if ($info[0] > 8000 || $info[1] > 8000) throw new RuntimeException('Ukuran gambar terlalu besar (maks. 8000 px).');
    if (!is_dir(CCTV_MAP_DIR) && !@mkdir(CCTV_MAP_DIR, 0775, true)) throw new RuntimeException('Folder assets/uploads/cctv_map tidak bisa dibuat.');
    $base = 'map_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3));
    $file = $base . ($info[2] === IMAGETYPE_PNG ? '.png' : '.jpg');
    if (!move_uploaded_file($img['tmp_name'], CCTV_MAP_DIR . '/' . $file)) throw new RuntimeException('Gagal menyimpan gambar peta.');
    $pdfName = null;
    if ($pdf && ($pdf['error'] ?? 1) === UPLOAD_ERR_OK && is_uploaded_file($pdf['tmp_name'])) {
        $head = (string)@file_get_contents($pdf['tmp_name'], false, null, 0, 5);
        if ($head === '%PDF-') {
            $pdfName = $base . '.pdf';
            @move_uploaded_file($pdf['tmp_name'], CCTV_MAP_DIR . '/' . $pdfName);
        }
    }
    return [$file, (int)$info[0], (int)$info[1], $pdfName];
}

function cctvMapRemoveFiles(PDO $db, int $mapId): void
{
    $st = $db->prepare("SELECT image, pdf FROM cctv_maps WHERE id = ?");
    $st->execute([$mapId]);
    if ($r = $st->fetch()) foreach ([$r['image'], $r['pdf']] as $f) if ($f && preg_match('/^[A-Za-z0-9_.-]+$/', $f)) @unlink(CCTV_MAP_DIR . '/' . $f);
}


/**
 * Dokumen cetak / PDF Map CCTV: halaman 1 = kop surat + judul + tanggal update + peta (ukuran pasti mm),
 * halaman 2 dst = daftar CCTV beserta NVR dan switch/port. Tabel + CSS sederhana supaya sama di browser dan Dompdf.
 * $pdf = true -> gambar JPG (Dompdf tanpa GD) dan tanpa skrip print.
 */
function cctvMapDocHtml(string $title, string $summary, array $rows, string $imgSrc, int $iw, int $ih, string $paper, bool $pdf, array $plans = []): string
{
    require_once __DIR__ . '/letterhead.php';
    $h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    $a3 = $paper === 'A3'; $land = $iw >= $ih;
    $pw = $land ? ($a3 ? 420 : 297) : ($a3 ? 297 : 210); $ph = $land ? ($a3 ? 297 : 210) : ($a3 ? 420 : 297);
    $mg = 8; $k = $a3 ? 1.35 : 1;
    $headH = (19 + 9 + 6.5) * $k;      // kop + pita judul + baris tanggal
    $footH = 9 * $k;
    $bw = $pw - 2 * $mg; $bh = $ph - 2 * $mg - $headH - $footH - 2;
    $sc = min($bw / $iw, $bh / $ih); $w = floor($iw * $sc * 10) / 10; $hh = floor($ih * $sc * 10) / 10;
    $ext = $pdf ? 'jpg' : 'png';
    $logo = letterheadImage('logo', $ext); $lines = letterheadImage('lines', $ext); $mark = letterheadImage('mark', $ext);
    $addr = letterheadAddress(); $company = (string)array_shift($addr);
    $updated = preg_replace('/^[^:]+:\s*(?:[A-Za-z]+,\s*)?/', '', documentCreatedAt());
    $updated = preg_replace('/\s+\d{2}:\d{2}$/', '', $updated);
    $kop = '<table class="kop"><tr><td class="l">' . ($logo ? '<img src="' . $logo . '" style="height:' . (16 * $k) . 'mm">' : '') . '</td>'
         . '<td class="r">' . ($lines ? '<img src="' . $lines . '" style="height:' . (16 * $k) . 'mm">' : '') . '</td></tr></table>';
    $foot = '<table class="foot"><tr><td>' . ($mark ? '<img src="' . $mark . '" style="height:' . (6 * $k) . 'mm;vertical-align:middle"> ' : '') . '<b>' . $h($company) . '</b>  ' . $h(implode(' ', array_slice($addr, 0, 3))) . '</td>'
          . '<td class="r">' . $h(end($addr)) . '</td></tr></table>';
    $band = fn(string $t) => '<div class="band">' . $h(mb_strtoupper($t)) . '</div>';

    // Daftar dipisah per NVR (NVR 1, NVR 2, ...; "Dummy" dan "-" di akhir). Tiap NVR mulai di halaman baru.
    $groups = [];
    foreach ($rows as $r) $groups[(string)($r['nvr'] ?? '-')][] = $r;
    uksort($groups, function ($a, $b) {
        $ra = in_array($a, ['-', 'Dummy'], true) ? 1 : 0; $rb = in_array($b, ['-', 'Dummy'], true) ? 1 : 0;
        return $ra <=> $rb ?: strnatcasecmp($a, $b);
    });
    if (!$groups) $groups = ['-' => []];
    $fs = $a3 ? 9 : 7.4;
    $css = '*{-webkit-print-color-adjust:exact;print-color-adjust:exact}@page{' . ($pdf ? '' : 'size:' . $paper . ' ' . ($land ? 'landscape' : 'portrait') . ';') . 'margin:' . $mg . 'mm}'
         . 'body{margin:0;font-family:Arial,Helvetica,sans-serif;color:#111}'
         . '.kop{width:100%;border-collapse:collapse;border-bottom:.6mm solid #173A68}.kop td{border:0;padding:0 0 1mm 0}.kop .r{text-align:right}'
         . '.band{background:#173A68;color:#fff;text-align:center;font-weight:bold;font-size:' . (12 * $k) . 'pt;padding:' . (1.4 * $k) . 'mm 0;margin-top:2mm;letter-spacing:.3px}'
         . '.upd{text-align:center;font-size:' . (8 * $k) . 'pt;font-style:italic;color:#475569;padding:1mm 0 1.5mm}'
         . '.map{text-align:center;height:' . ($hh + 1) . 'mm}.map img{width:' . $w . 'mm;height:' . $hh . 'mm}'
         . '.foot{width:100%;border-collapse:collapse;border-top:.3mm solid #9AA7BA;margin-top:1.5mm;font-size:' . (7 * $k) . 'pt;color:#334155}.foot td{border:0;padding:1mm 0 0}.foot .r{text-align:right}'
         . '.pg2{page-break-before:always}'
         . 'table.list{width:100%;border-collapse:collapse;table-layout:fixed;border:.4mm solid #173A68;font-size:' . $fs . 'pt;line-height:1.2;margin-top:2mm}'
         . 'table.list th{background:#DCE6F5;color:#173A68;border:1px solid #9AA7BA;padding:1mm 1mm;text-align:center}'
         . 'table.list td{border:1px solid #9AA7BA;padding:.7mm 1.2mm;word-wrap:break-word}table.list tr.z td{background:#F3F6FB}'
         . 'table.list tr{page-break-inside:avoid}td.c{text-align:center}thead{display:table-header-group}';
    $thead = '<thead><tr><th style="width:6%">NO</th><th style="width:27%">NAMA CCTV</th><th style="width:14%">IP</th><th style="width:6%">CH</th><th style="width:25%">SWITCH / PORT</th><th style="width:12%">TGL PASANG</th><th style="width:10%">STATUS</th></tr></thead>';
    $body = '<div class="pg1">' . $kop . $band($title) . '<div class="upd">' . $h('Diperbarui: ' . $updated . ($summary !== '' ? '  •  ' . $summary : '')) . '</div>'
          . '<div class="map"><img src="' . $imgSrc . '"></div>' . $foot . '</div>';
    foreach ($groups as $gName => $gRows) {
        $tr = '';
        foreach ($gRows as $i => $r) {
            $tr .= '<tr' . ($i % 2 ? ' class="z"' : '') . '><td class="c">' . $h($r['no'] ?? '') . '</td><td>' . $h($r['name'] ?? '') . '</td><td>' . $h($r['ip'] ?? '') . '</td><td class="c">' . $h($r['ch'] ?? '') . '</td><td>' . $h($r['sw'] ?? '') . '</td><td class="c">' . $h($r['date'] ?? '') . '</td><td class="c">' . $h($r['st'] ?? '') . '</td></tr>';
        }
        if (!$gRows) $tr = '<tr><td colspan="7" class="c">-</td></tr>';
        $label = $gName === '-' ? 'CCTV tanpa NVR' : $gName;
        $body .= '<div class="pg2">' . $kop . $band('Daftar CCTV - ' . $label) . '<div class="upd">' . $h('Diperbarui: ' . $updated . '  •  ' . count($gRows) . ' CCTV') . '</div>'
               . '<table class="list">' . $thead . '<tbody>' . $tr . '</tbody></table>' . $foot . '</div>';
    }
    if ($plans) {
        $pr = '';
        foreach ($plans as $i => $r) $pr .= '<tr' . ($i % 2 ? ' class="z"' : '') . '><td class="c">' . $h($r['no'] ?? '') . '</td><td>' . $h($r['name'] ?? '') . '</td><td>' . $h($r['note'] ?? '') . '</td></tr>';
        $body .= '<div class="pg2">' . $kop . $band('Rencana pemasangan titik baru') . '<div class="upd">' . $h('Diperbarui: ' . $updated . '  •  ' . count($plans) . ' rencana (belum dipasang)') . '</div>'
               . '<table class="list"><thead><tr><th style="width:8%">NO</th><th style="width:30%">NAMA RENCANA</th><th>CATATAN</th></tr></thead><tbody>' . $pr . '</tbody></table>' . $foot . '</div>';
    }
    $js = $pdf ? '' : '<script>window.onload=function(){setTimeout(function(){window.print()},400)}</script>';
    return '<!doctype html><html><head><meta charset="utf-8"><title>' . $h($title) . '</title><style>' . $css . '</style></head><body>' . $body . $js . '</body></html>';
}
