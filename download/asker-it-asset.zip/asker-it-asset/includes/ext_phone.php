<?php
/**
 * Isian & export khusus kategori EXT TELEPON.
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA:
 * - Isian Ext Telepon memakai kolom aset yang sudah ada:
 *     Nama Perangkat -> assets.device_name      Pengguna    -> asset_owners
 *     Departement    -> assets.department       Lokasi      -> assets.location
 *     Brand Type     -> assets.motherboard_brand Status     -> assets.status
 *     Tanggal Pembelian -> assets.purchase_date  ID Aset    -> assets.asset_number (otomatis)
 * - Hanya Nomor Ext yang disimpan di tabel BARU asset_ext_numbers (tanpa ALTER tabel lama,
 *   tanpa foreign key). Tabel dibuat otomatis (CREATE TABLE IF NOT EXISTS).
 */

/** Kategori dianggap Ext Telepon jika namanya mengandung "telepon"/"telephone"/"phone ext" (mis. "Ext Telepon"). */
function isExtPhoneCategory(?string $category): bool
{
    if ($category === null || $category === '') return false;
    return (bool)preg_match('/telepon|telephone|\bphone\b/i', $category);
}

function extPhoneTableExists(PDO $db, bool $refresh = false): bool
{
    static $exists = null;
    if ($exists === null || $refresh) {
        $exists = (bool)$db->query("SELECT COUNT(*) FROM information_schema.TABLES
                                    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_ext_numbers'")->fetchColumn();
    }
    return $exists;
}

/** Buat tabel asset_ext_numbers jika belum ada. Tidak menyentuh tabel lain. */
function ensureExtPhoneTable(PDO $db): void
{
    if (extPhoneTableExists($db)) return;
    $db->exec("
        CREATE TABLE IF NOT EXISTS asset_ext_numbers (
            asset_id    INT UNSIGNED NOT NULL PRIMARY KEY,   -- assets.id (tanpa foreign key)
            ext_number  VARCHAR(30)  NOT NULL,
            updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_ext_number (ext_number)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    extPhoneTableExists($db, true);
}

/** [asset_id => nomor ext] untuk banyak aset sekaligus. */
function getExtNumberMap(PDO $db, array $assetIds): array
{
    $assetIds = array_values(array_filter(array_map('intval', $assetIds)));
    if (!$assetIds || !extPhoneTableExists($db)) return [];
    $map = [];
    foreach (array_chunk($assetIds, 500) as $chunk) {
        $st = $db->prepare("SELECT asset_id, ext_number FROM asset_ext_numbers WHERE asset_id IN (" . implode(',', array_fill(0, count($chunk), '?')) . ")");
        $st->execute($chunk);
        foreach ($st->fetchAll() as $r) { $map[(int)$r['asset_id']] = (string)$r['ext_number']; }
    }
    return $map;
}

/** Simpan Nomor Ext 1 aset; kosong = hapus. */
function saveExtNumber(PDO $db, int $assetId, string $ext): void
{
    ensureExtPhoneTable($db);
    $ext = mb_substr(trim($ext), 0, 30);
    if ($ext === '') {
        $db->prepare("DELETE FROM asset_ext_numbers WHERE asset_id = ?")->execute([$assetId]);
        return;
    }
    $db->prepare("DELETE FROM asset_ext_numbers WHERE asset_id = ?")->execute([$assetId]);
    $db->prepare("INSERT INTO asset_ext_numbers (asset_id, ext_number) VALUES (?, ?)")->execute([$assetId, $ext]);
}

function deleteExtNumbers(PDO $db, array $assetIds): void
{
    $assetIds = array_values(array_filter(array_map('intval', $assetIds)));
    if (!$assetIds || !extPhoneTableExists($db)) return;
    $db->prepare("DELETE FROM asset_ext_numbers WHERE asset_id IN (" . implode(',', array_fill(0, count($assetIds), '?')) . ")")->execute($assetIds);
}

/**
 * Sheet Excel khusus Ext Telepon (kolom sama dengan file contoh dari user):
 * No, ID Aset, Kategori, Nama Perangkat, Nomor Ext, Pengguna, Jabatan, Departement, Brand Type,
 * Lokasi, Status, Tanggal Input, Riwayat Tiket, Riwayat Perbaikan, Tanggal Pembelian.
 */
function writeExtPhoneSheet(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, array $assets, array $ownersMap, string $title): void
{
    $db = getDB();
    $extMap = getExtNumberMap($db, array_column($assets, 'id'));
    $positionMap = function_exists('getUserPositionMap') ? getUserPositionMap($db) : [];
    $statusKey = ['Digunakan' => 'status_used', 'Stok' => 'status_stock', 'Tidak Digunakan' => 'status_unused'];
    $tix = $db->prepare("SELECT ticket_number, status, created_at FROM tickets WHERE asset_id = ? ORDER BY created_at DESC");

    // Kolom SAMA dengan template import Ext Telepon (bisa langsung diedit lalu diimport ulang).
    $headers = [
        t('xls_hdr_asset_id'), t('xls_hdr_category'), t('xls_hdr_device_name'), t('ext_lbl_number'), t('xls_hdr_users'),
        t('xls_hdr_department'), t('tablet_lbl_brand'), t('xls_hdr_location'), t('xls_hdr_status'), t('xls_hdr_purchase_date'),
    ];
    $rows = [];
    foreach ($assets as $a) {
        $owners = $ownersMap[$a['id']] ?? [];
        $rows[] = [
            $a['asset_number'],
            $a['category'],
            $a['device_name'] ?? '',
            $extMap[(int)$a['id']] ?? '',
            ownerNamesLabel($owners),
            $a['department'] ?? '',
            $a['motherboard_brand'] ?? '',
            $a['location'] ?? '',
            isset($statusKey[$a['status']]) ? t($statusKey[$a['status']]) : $a['status'],
            !empty($a['purchase_date'] ?? null) ? date('Y-m-d', strtotime($a['purchase_date'])) : '',
        ];
    }

    $C = fn(int $i) => \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i);
    $sheet->setTitle($title);
    $sheet->fromArray($headers, null, 'A1');
    foreach ($rows as $r => $row) {
        foreach ($row as $c => $val) {
            // Teks semua (Nomor Ext / tanggal tidak diubah Excel), kecuali Nomor Ext yang murni angka tetap angka.
            $cell = $C($c + 1) . ($r + 2);
            if ($c === 3 && preg_match('/^\d{1,9}$/', (string)$val)) { $sheet->setCellValue($cell, (int)$val); continue; }
            $sheet->setCellValueExplicit($cell, (string)$val, \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
        }
    }
    $last = $C(count($headers));
    $lastRow = max(1, 1 + count($rows));
    $sheet->getStyle("A1:{$last}1")->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
    $sheet->getStyle("A1:{$last}1")->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
    $sheet->getStyle("A1:{$last}1")->getAlignment()->setHorizontal('center');
    $sheet->getStyle("A1:{$last}{$lastRow}")->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
    $sheet->getStyle("D2:D{$lastRow}")->getAlignment()->setHorizontal('center');
    foreach ([20, 13, 24, 11, 26, 18, 14, 16, 12, 17] as $i => $w) {
        $sheet->getColumnDimension($C($i + 1))->setWidth($w);
    }
    $sheet->freezePane('A2');
    require_once __DIR__ . '/xls_number.php';
    xlsAddNumberColumn($sheet, 1, $lastRow);
    xlsAddAssetTitleBlock($sheet, array_column($assets, 'category'), count($assets));
}

/* =====================================================================
 * IMPORT EXCEL EXT TELEPON
 * File dikenali dari kolom "Nomor Ext". Kolom sama dengan hasil export
 * (Jabatan, Tanggal Input, Riwayat diabaikan karena diisi sistem).
 * ===================================================================== */

const EXT_XLS_FIELDS = ['asset_number', 'category', 'device_name', 'ext', 'users', 'department', 'brand', 'location', 'status', 'purchase'];

function extXlsHeaderAliases(): array
{
    return [
        'id aset' => 'asset_number', 'asset id' => 'asset_number', 'nomor aset' => 'asset_number',
        'kategori' => 'category', 'category' => 'category', 'jenis aset' => 'category',
        'nama perangkat' => 'device_name', 'device name' => 'device_name',
        'nomor ext' => 'ext', 'no ext' => 'ext', 'ext number' => 'ext', 'ext' => 'ext', 'extension' => 'ext',
        'pengguna' => 'users', 'users' => 'users', 'user' => 'users', 'nama' => 'users',
        'departement' => 'department', 'department' => 'department', 'departemen' => 'department', 'bagian' => 'department',
        'brand type' => 'brand', 'motherboard/brand type' => 'brand',
        'lokasi' => 'location', 'location' => 'location',
        'status' => 'status',
        'tanggal pembelian' => 'purchase', 'purchase date' => 'purchase',
    ];
}

/** Sheet format Ext Telepon = punya kolom "Nomor Ext" / "Ext Number". */
function isExtPhoneXlsHeader(array $headerRow): bool
{
    foreach ($headerRow as $title) {
        if (in_array(mb_strtolower(trim((string)$title)), ['nomor ext', 'no ext', 'ext number'], true)) return true;
    }
    return false;
}

function readExtPhoneSheetRows(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet): array
{
    require_once __DIR__ . '/tablet_excel.php';
    $aliases = extXlsHeaderAliases();
    $colMap = [];
    foreach (readSheetHeader($sheet) as $letter => $title) {
        $k = $aliases[mb_strtolower(trim((string)$title))] ?? null;
        if ($k && !isset($colMap[$k])) $colMap[$k] = $letter;
    }
    $rows = [];
    $highestRow = $sheet->getHighestDataRow();
    for ($r = xlsHeaderRowIndex($sheet) + 1; $r <= $highestRow; $r++) {
        $item = ['row' => $r]; $empty = true;
        foreach (EXT_XLS_FIELDS as $f) {
            if (!isset($colMap[$f])) continue;
            $cell = $sheet->getCell($colMap[$f] . $r);
            if ($f === 'purchase') {
                $v = $cell->getValue();
                if ($v instanceof \PhpOffice\PhpSpreadsheet\RichText\RichText) $v = $v->getPlainText();
                if (is_string($v)) $v = trim($v);
                $item[$f] = $v;
                if ($v !== null && $v !== '') $empty = false;
            } else {
                $v = trim((string)$cell->getFormattedValue());
                $item[$f] = $v;
                if ($v !== '' && $f !== 'category') $empty = false;   // baris yang hanya berisi Kategori dianggap kosong
            }
        }
        if (!$empty) $rows[] = $item;
    }
    return ['columns' => array_keys($colMap), 'rows' => $rows];
}

/** Teks status dari file -> nilai status aset. null = kosong, false = tidak dikenali. */
function extParseStatus(string $v)
{
    $v = mb_strtolower(trim($v));
    if ($v === '' || $v === '-') return null;
    if (in_array($v, ['digunakan', 'dipakai', 'used', 'in use'], true)) return 'Digunakan';
    if (in_array($v, ['stok', 'stock', 'in stock'], true)) return 'Stok';
    if (in_array($v, ['tidak digunakan', 'unused', 'not used'], true)) return 'Tidak Digunakan';
    return false;
}

/**
 * Proses baris Ext Telepon (dipanggil di dalam transaksi; Preview = rollBack, Simpan = commit).
 * - ID Aset ada & kategorinya Ext Telepon -> UPDATE.   - ID Aset kosong -> aset baru, nomor otomatis.
 * - ID Aset milik kategori lain           -> ditolak.  - Sel kosong pada aset lama -> nilai lama tetap.
 * - Pengguna dicocokkan ke master User; Departement kosong -> dari user pertama.
 * - Status kosong -> otomatis: ada pengguna = Digunakan, tidak ada = Stok.
 */
function processExtPhoneRows(PDO $db, array $parsed): array
{
    require_once __DIR__ . '/tablet_excel.php';   // tabletParseDate
    $cols = array_flip($parsed['columns']);
    $has = fn(string $f) => isset($cols[$f]);
    $extCats = array_values(array_filter(array_column(getAssetCategories($db), 'name'), 'isExtPhoneCategory'));
    $defaultCat = $extCats[0] ?? 'Ext Telepon';
    $hasPurchaseDateCol = (bool)$db->query("SELECT COUNT(*) FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'assets' AND COLUMN_NAME = 'purchase_date'")->fetchColumn();
    $findAsset = $db->prepare("SELECT * FROM assets WHERE asset_number = ? LIMIT 1");
    $findUser  = $db->prepare("SELECT id, full_name, department, email FROM users WHERE LOWER(TRIM(full_name)) = LOWER(?) LIMIT 1");

    $out = ['rows' => [], 'inserted' => 0, 'updated' => 0, 'errors' => 0, 'warnings' => 0];
    $seen = [];
    foreach ($parsed['rows'] as $in) {
        $res = ['row' => $in['row'], 'action' => '', 'asset_number' => $in['asset_number'] ?? '', 'data' => $in, 'errors' => [], 'warnings' => []];
        $get = fn(string $f) => trim((string)($in[$f] ?? ''));

        $category = $defaultCat;
        if ($has('category') && $get('category') !== '') {
            if (!isExtPhoneCategory($get('category'))) $res['errors'][] = t('ext_imp_err_category', $get('category'));
            else { $m = array_values(array_filter($extCats, fn($c) => strcasecmp($c, $get('category')) === 0)); $category = $m[0] ?? $defaultCat; }
        }
        $purchase = $has('purchase') ? tabletParseDate($in['purchase']) : null;
        if ($purchase === false) { $res['errors'][] = t('ext_imp_err_date', (string)$in['purchase']); $purchase = null; }
        $status = $has('status') ? extParseStatus($get('status')) : null;
        if ($status === false) { $res['errors'][] = t('ext_imp_err_status', $get('status')); $status = null; }

        $ownerIds = []; $firstUser = null; $namesGiven = false;
        if ($has('users')) {
            $names = array_filter(array_map('trim', preg_split('/[,;]/', $get('users'))), fn($v) => $v !== '' && $v !== '-');
            $namesGiven = (bool)$names;
            foreach ($names as $n) {
                $findUser->execute([$n]);
                $u = $findUser->fetch();
                if ($u) { $ownerIds[] = (int)$u['id']; $firstUser = $firstUser ?? $u; }
                else { $res['warnings'][] = t('tablet_imp_warn_user', $n); }
            }
        }
        $department = $has('department') ? $get('department') : '';
        if ($department === '' && $firstUser) $department = trim((string)$firstUser['department']);

        $assetNumber = $get('asset_number');
        $existing = null;
        if ($assetNumber !== '') {
            if (mb_strlen($assetNumber) > ASSET_NUMBER_MAX_LEN) $res['errors'][] = t('tablet_imp_err_number_long', $assetNumber);
            $findAsset->execute([$assetNumber]);
            $existing = $findAsset->fetch() ?: null;
            if ($existing && !isExtPhoneCategory($existing['category'])) $res['errors'][] = t('ext_imp_err_not_ext', $assetNumber, $existing['category']);
            if (isset($seen[mb_strtolower($assetNumber)])) $res['errors'][] = t('tablet_imp_err_dup_number', $assetNumber, $seen[mb_strtolower($assetNumber)]);
        }
        if ($res['errors']) { $res['action'] = 'error'; $out['errors']++; $out['rows'][] = $res; continue; }

        $db->exec('SAVEPOINT ext_row');
        try {
            if ($assetNumber === '') {
                $sg = suggestAssetNumber($db, $category, assetNumberDepartment($db, $ownerIds, $department), $get('location'));
                if (!$sg['ok']) throw new PDOException($sg['message']);
                $assetNumber = $sg['asset_number'];
                $res['asset_number'] = $assetNumber;
                $res['warnings'][] = t('tablet_imp_info_auto_number', $assetNumber);
            }
            $seen[mb_strtolower($assetNumber)] = $in['row'];

            $keepOwners = ($existing && $namesGiven && !$ownerIds) || (!$has('users') && $existing);
            $val = function (string $field, string $col, $new) use ($existing, $has) {
                if (!$has($field) || $new === '') return $existing ? $existing[$col] : null;
                return $new;
            };
            $fields = [
                'category'          => $category,
                'department'        => $department !== '' ? $department : ($existing['department'] ?? null),
                'device_name'       => $val('device_name', 'device_name', mb_substr($get('device_name'), 0, 100)),
                'location'          => $val('location', 'location', $get('location')),
                'motherboard_brand' => $val('brand', 'motherboard_brand', $get('brand')),
            ];
            if ($hasPurchaseDateCol) $fields['purchase_date'] = $purchase ?? ($existing['purchase_date'] ?? null);
            if ($firstUser) $fields['owner_email'] = trim((string)$firstUser['email']) !== '' ? $firstUser['email'] : null;
            elseif ($has('users') && !$namesGiven) $fields['owner_email'] = null;

            if ($existing) {
                $assetId = (int)$existing['id'];
                $set = implode(', ', array_map(fn($k) => "$k = ?", array_keys($fields)));
                $db->prepare("UPDATE assets SET $set WHERE id = ?")->execute([...array_values($fields), $assetId]);
                $res['action'] = 'update'; $out['updated']++;
            } else {
                $fields = ['asset_number' => $assetNumber, 'status' => 'Stok'] + $fields;
                $db->prepare("INSERT INTO assets (" . implode(', ', array_keys($fields)) . ") VALUES (" . implode(',', array_fill(0, count($fields), '?')) . ")")
                   ->execute(array_values($fields));
                $assetId = (int)$db->lastInsertId();
                $res['action'] = 'insert'; $out['inserted']++;
            }
            if (!$keepOwners) setAssetOwners($db, $assetId, $ownerIds);

            // Status: dari file; kosong -> otomatis dari jumlah pengguna.
            if ($status === null) {
                $ownerCount = assetOwnersTableExists($db)
                    ? (int)$db->query("SELECT COUNT(*) FROM asset_owners WHERE asset_id = " . $assetId)->fetchColumn()
                    : count($ownerIds);
                $status = $ownerCount > 0 ? 'Digunakan' : 'Stok';
                if ($existing && $existing['status'] === 'Tidak Digunakan' && $ownerCount === 0) $status = 'Tidak Digunakan';
            }
            $db->prepare("UPDATE assets SET status = ? WHERE id = ?")->execute([$status, $assetId]);

            // Nomor Ext (tabel sudah dibuat sebelum transaksi; kosong = nilai lama tetap).
            if ($has('ext') && $get('ext') !== '') {
                $db->prepare("DELETE FROM asset_ext_numbers WHERE asset_id = ?")->execute([$assetId]);
                $db->prepare("INSERT INTO asset_ext_numbers (asset_id, ext_number) VALUES (?, ?)")->execute([$assetId, mb_substr($get('ext'), 0, 30)]);
            }
            $db->exec('RELEASE SAVEPOINT ext_row');
        } catch (PDOException $e) {
            $db->exec('ROLLBACK TO SAVEPOINT ext_row');
            if ($res['action'] === 'insert') $out['inserted']--;
            if ($res['action'] === 'update') $out['updated']--;
            $res['action'] = 'error';
            $res['errors'][] = t('tablet_imp_err_db', $e->getMessage());
            $out['errors']++; $out['rows'][] = $res;
            continue;
        }
        if ($res['warnings']) $out['warnings']++;
        $out['rows'][] = $res;
    }
    return $out;
}

/** Template import Ext Telepon (kop + judul, judul kolom di baris 8, 1 baris contoh). */
function writeExtPhoneTemplate(\PhpOffice\PhpSpreadsheet\Spreadsheet $ss): void
{
    $sheet = $ss->getActiveSheet();
    $sheet->setTitle('Inventory');
    $headers = [t('xls_hdr_asset_id'), t('xls_hdr_category'), t('xls_hdr_device_name'), t('ext_lbl_number'), t('xls_hdr_users'),
                t('xls_hdr_department'), t('tablet_lbl_brand'), t('xls_hdr_location'), t('xls_hdr_status'), t('xls_hdr_purchase_date')];
    $sheet->fromArray($headers, null, 'A1');
    $C = fn(int $i) => \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i);
    $last = $C(count($headers));
    $sheet->getStyle("A1:{$last}1")->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
    $sheet->getStyle("A1:{$last}1")->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
    $sheet->getStyle("A1:{$last}1")->getAlignment()->setHorizontal('center');
    $sheet->getStyle("A1:{$last}1")->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
    foreach ([20, 13, 24, 11, 26, 18, 14, 16, 12, 17] as $i => $w) $sheet->getColumnDimension($C($i + 1))->setWidth($w);
    $sheet->getStyle('A:J')->getNumberFormat()->setFormatCode('@');
    require_once __DIR__ . '/xls_number.php';
    xlsAddTitleBlock($sheet, 1, xlsL('Template Import Ext Telepon ', 'Phone Extension Import Template ') . xlsCompanyName(), xlsTemplateLines());
    $help = $ss->createSheet();
    $help->setTitle(t('tablet_tpl_help_sheet'));
    foreach ([t('ext_tpl_help_title'), '', t('ext_tpl_help_1'), t('ext_tpl_help_2'), t('ext_tpl_help_3'), t('ext_tpl_help_4'), t('ext_tpl_help_5'), t('ext_tpl_help_6')] as $i => $line) {
        $help->setCellValue('A' . ($i + 1), $line);
    }
    $help->getStyle('A1')->getFont()->setBold(true)->setSize(13);
    $help->getColumnDimension('A')->setWidth(120);
    $ss->setActiveSheetIndex(0);
}

/* =====================================================================
 * DAFTAR NOMOR EXT (menu "Ext Telepon" untuk semua user)
 * Selalu dibaca langsung dari aset Ext Telepon, jadi otomatis ikut berubah
 * kalau Nomor Ext / pengguna / departement aset diperbarui.
 * Bagian = Departement aset. Nama = nama pengguna aset (dipisah koma), ditampilkan
 * sebagian sesuai pilihan per user: nama depan (bawaan), tengah, belakang, atau lengkap.
 * Pilihan disimpan di includes/data/ext_name_display.json (tanpa tabel baru).
 * ===================================================================== */
const EXT_NAME_MODES = ['first', 'middle', 'last', 'full'];
const EXT_NAME_FILE  = __DIR__ . '/data/ext_name_display.json';

/**
 * Pengaturan nama per user: [user_id => ['mode' => first|middle|last|full, 'nick' => nama panggilan]].
 * Nama panggilan (kalau diisi) selalu dipakai, mengalahkan pilihan mode.
 * Format lama (user_id => "mode") tetap dibaca.
 */
function extNameModes(bool $refresh = false): array
{
    static $cache = null;
    if ($cache === null || $refresh) {
        $cache = [];
        if (is_file(EXT_NAME_FILE)) {
            $d = json_decode((string)file_get_contents(EXT_NAME_FILE), true);
            if (is_array($d)) foreach ($d as $k => $v) {
                $mode = is_array($v) ? (string)($v['mode'] ?? 'first') : (string)$v;
                $nick = is_array($v) ? trim((string)($v['nick'] ?? '')) : '';
                $cache[(int)$k] = ['mode' => in_array($mode, EXT_NAME_MODES, true) ? $mode : 'first', 'nick' => $nick];
            }
        }
    }
    return $cache;
}

function extNameModeFor(int $userId): string
{
    return extNameModes()[$userId]['mode'] ?? 'first';
}

function extNickFor(int $userId): string
{
    return extNameModes()[$userId]['nick'] ?? '';
}

/** Nama yang tampil di daftar Ext untuk 1 user. */
function extDisplayName(int $userId, string $fullName): string
{
    $nick = extNickFor($userId);
    return $nick !== '' ? $nick : extNamePart($fullName, extNameModeFor($userId));
}

function saveExtNameMode(int $userId, string $mode, ?string $nick = null): bool
{
    if (!in_array($mode, EXT_NAME_MODES, true) || $userId <= 0) return false;
    $all = extNameModes();
    $nick = $nick === null ? ($all[$userId]['nick'] ?? '') : mb_substr(trim(preg_replace('/\s+/', ' ', $nick)), 0, 40);
    if ($mode === 'first' && $nick === '') unset($all[$userId]);
    else $all[$userId] = ['mode' => $mode, 'nick' => $nick];
    if (!is_dir(dirname(EXT_NAME_FILE))) @mkdir(dirname(EXT_NAME_FILE), 0775, true);
    $ok = @file_put_contents(EXT_NAME_FILE, json_encode($all, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX) !== false;
    clearstatcache(true, EXT_NAME_FILE);
    extNameModes(true);
    return $ok;
}

/**
 * Bagian nama sesuai mode. "Mr." / "Mrs." / "Bpk." / "Ibu" di depan ikut dipertahankan.
 * Nama 1 kata -> selalu kata itu. Nama tengah tidak ada -> nama depan.
 */
function extNamePart(string $fullName, string $mode): string
{
    $fullName = trim(preg_replace('/\s+/', ' ', $fullName));
    if ($mode === 'full' || $fullName === '') return $fullName;
    $title = '';
    if (preg_match('/^((?:mr|mrs|ms|miss|bpk|bapak|ibu|pak|bu)\.?)\s+(.+)$/i', $fullName, $m)) { $title = $m[1] . ' '; $fullName = $m[2]; }
    $parts = explode(' ', $fullName);
    $n = count($parts);
    if ($n === 1) return $title . $parts[0];
    switch ($mode) {
        case 'last':   $pick = $parts[$n - 1]; break;
        case 'middle': $pick = $n >= 3 ? implode(' ', array_slice($parts, 1, $n - 2)) : $parts[0]; break;
        default:       $pick = $parts[0];
    }
    return $title . $pick;
}

/** Contoh hasil tiap mode untuk 1 nama (dipakai pilihan di menu). */
function extNameModeOptions(string $fullName): array
{
    $o = [];
    foreach (EXT_NAME_MODES as $m) $o[$m] = extNamePart($fullName, $m);
    return $o;
}

function getExtDirectory(PDO $db): array
{
    if (!extPhoneTableExists($db)) return [];
    $rows = $db->query("SELECT a.id, a.category, a.department, a.location, x.ext_number
                        FROM asset_ext_numbers x JOIN assets a ON a.id = x.asset_id
                        WHERE TRIM(x.ext_number) <> ''")->fetchAll();
    $rows = array_values(array_filter($rows, fn($r) => isExtPhoneCategory($r['category'])));
    $owners = getAssetOwnersMap($db, array_column($rows, 'id'));
    $out = [];
    foreach ($rows as $r) {
        $ow = $owners[(int)$r['id']] ?? [];
        $out[] = [
            'bagian' => trim((string)$r['department']) !== '' ? trim((string)$r['department']) : trim((string)$r['location']),
            'nama'   => implode(', ', array_map(fn($o) => extDisplayName((int)$o['id'], (string)$o['full_name']), $ow)),
            'ext'    => trim((string)$r['ext_number']),
            'users'  => array_map(fn($o) => ['id' => (int)$o['id'], 'full_name' => (string)$o['full_name']], $ow),
        ];
    }
    // Nomor Ext yang sama (mis. 2 pesawat telepon di Cutting dengan ext 142) digabung jadi 1 baris:
    // Bagian & Nama digabung tanpa dobel.
    $merged = [];
    $uniq = function (array $parts): string {
        $seen = [];
        foreach ($parts as $p) foreach (preg_split('/\s*,\s*/', (string)$p) as $x) {
            $x = trim($x);
            if ($x !== '' && $x !== '-' && !isset($seen[mb_strtolower($x)])) $seen[mb_strtolower($x)] = $x;
        }
        return implode(', ', $seen);
    };
    foreach ($out as $row) {
        $k = mb_strtolower(preg_replace('/\s+/', '', $row['ext']));
        if (!isset($merged[$k])) { $merged[$k] = $row; continue; }
        $merged[$k]['bagian'] = $uniq([$merged[$k]['bagian'], $row['bagian']]);
        $merged[$k]['nama']   = $uniq([$merged[$k]['nama'], $row['nama']]);
        foreach ($row['users'] as $u) {
            if (!in_array($u['id'], array_column($merged[$k]['users'], 'id'), true)) $merged[$k]['users'][] = $u;
        }
    }
    $out = array_values($merged);
    // Urut per Bagian, lalu nomor ext.
    usort($out, fn($a, $b) => [mb_strtolower($a['bagian']), (int)$a['ext'], $a['ext']] <=> [mb_strtolower($b['bagian']), (int)$b['ext'], $b['ext']]);
    return $out;
}

/** Bagi daftar jadi 2 kolom berurutan (kiri: 1..n/2, kanan: sisanya) kalau barisnya banyak. */
function extDirectoryHalves(array $dir): array
{
    // Sesuai permintaan: semua nomor dalam 1 daftar (tidak dibagi 2 kolom).
    return [$dir];
}

/**
 * File Excel daftar Nomor Ext: 1 salinan di 1 lembar A4 landscape.
 * Kop perusahaan (logo kiri + ornamen kanan) selebar halaman, pita judul NO EXTENTION TELEPON,
 * tanggal diperbarui & jumlah, lalu tabel NO | BAGIAN | NAMA | EXT. Kalau barisnya banyak, tabel
 * dilanjutkan di kolom kanan (A-D lalu F-I) dengan nomor urut bersambung. Teks panjang turun baris.
 */
function writeExtDirectorySheet(\PhpOffice\PhpSpreadsheet\Spreadsheet $ss, array $dir): void
{
    require_once __DIR__ . '/letterhead.php';
    $sh = $ss->getActiveSheet();
    $sh->setTitle('EXT');
    $navy = '173A68'; $blue = '1F3DD1'; $soft = 'DCE6F5'; $zebra = 'F3F6FB'; $grid = '9AA7BA';
    $n = count($dir);
    $halves = extDirectoryHalves($dir);
    $two = count($halves) === 2;
    $hdr = 5; $first = $hdr + 1;
    $last = $hdr + max(1, count($halves[0]));
    $foot = $last + 2;
    $lastCol = 'D';   // isi hanya di separuh kiri halaman; kolom F-I sengaja kosong
    $addr = function_exists('letterheadAddress') ? letterheadAddress() : [];
    $company = (string)($addr[0] ?? '');
    $phone = (string)end($addr);
    $updated = function_exists('documentCreatedAt') ? preg_replace('/^[^:]+:\s*/', '', documentCreatedAt()) : date('d M Y H:i');
    [$logo, $orn] = extLetterheadFiles();
    $thin = ['borders' => ['allBorders' => ['borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN, 'color' => ['rgb' => $grid]]]];
    $solid = \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID;
    $maxLen = fn(string $k, int $min) => max($min, ...array_map(fn($d) => mb_strlen((string)$d[$k]), $dir ?: [[$k => '']]));
    $wBag  = min(30, max(18, $maxLen('bagian', 10) * 1.1 + 2));
    $wNama = min(50, max(30, $maxLen('nama', 10) * 1.05 + 2));

    $sh->getRowDimension(1)->setRowHeight(40);
    $sh->getRowDimension(2)->setRowHeight(5);
    $sh->getRowDimension(3)->setRowHeight(24);
    $sh->getRowDimension(4)->setRowHeight(15);
    $sh->getRowDimension($hdr)->setRowHeight(17);

    // Kop selebar halaman: logo kiri, ornamen kanan, garis biru tua di bawahnya.
    if (is_file($logo)) {
        $d = new \PhpOffice\PhpSpreadsheet\Worksheet\Drawing();
        $d->setName('Logo'); $d->setPath($logo); $d->setHeight(46);
        $d->setCoordinates('A1'); $d->setOffsetX(2); $d->setOffsetY(4); $d->setWorksheet($sh);
    }
    if (is_file($orn)) {
        $d = new \PhpOffice\PhpSpreadsheet\Worksheet\Drawing();
        $d->setName('Ornamen'); $d->setPath($orn); $d->setHeight(46);
        $d->setCoordinates('C1'); $d->setOffsetX(max(4, (int)round(($wNama + 7) * 7.2) - 92)); $d->setOffsetY(4); $d->setWorksheet($sh);
    }
    $sh->getStyle("A2:{$lastCol}2")->getBorders()->getBottom()
       ->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_MEDIUM)->getColor()->setRGB($navy);
    $sh->mergeCells("A3:{$lastCol}3");
    $sh->setCellValue('A3', 'NO EXTENTION TELEPON');
    $sh->getStyle("A3:{$lastCol}3")->getFill()->setFillType($solid)->getStartColor()->setRGB($navy);
    $sh->getStyle('A3')->getFont()->setBold(true)->setSize(14)->getColor()->setRGB('FFFFFF');
    $sh->getStyle('A3')->getAlignment()->setHorizontal('center')->setVertical('center');
    $sh->mergeCells("A4:{$lastCol}4");
    $sh->setCellValueExplicit('A4', xlsL2('Diperbarui: ', 'Updated: ') . $updated . '   •   ' . $n . xlsL2(' nomor ext', ' extensions'),
        \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
    $sh->getStyle('A4')->getFont()->setSize(8.5)->setItalic(true)->getColor()->setRGB('475569');
    $sh->getStyle('A4')->getAlignment()->setHorizontal('center')->setVertical('center');

    $no = 0;
    foreach ($halves as $hi => $part) {
        [$cNo, $cBag, $cNama, $cExt] = $hi === 0 ? ['A', 'B', 'C', 'D'] : ['F', 'G', 'H', 'I'];
        $sh->fromArray(['NO', 'BAGIAN', 'NAMA', 'EXT'], null, "{$cNo}{$hdr}");
        $sh->getStyle("{$cNo}{$hdr}:{$cExt}{$hdr}")->getFont()->setBold(true)->setSize(9.5)->getColor()->setRGB($navy);
        $sh->getStyle("{$cNo}{$hdr}:{$cExt}{$hdr}")->getFill()->setFillType($solid)->getStartColor()->setRGB($soft);
        $sh->getStyle("{$cNo}{$hdr}:{$cExt}{$hdr}")->getAlignment()->setHorizontal('center')->setVertical('center');
        $i = 0;
        foreach ($part as $d) {
            $r = $first + $i; $no++;
            $sh->setCellValue("{$cNo}{$r}", $no);
            $sh->setCellValueExplicit("{$cBag}{$r}", mb_strtoupper($d['bagian']), \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            $sh->setCellValueExplicit("{$cNama}{$r}", mb_strtoupper($d['nama'] !== '' ? $d['nama'] : '-'), \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            if (preg_match('/^\d{1,9}$/', $d['ext'])) $sh->setCellValue("{$cExt}{$r}", (int)$d['ext']);
            else $sh->setCellValueExplicit("{$cExt}{$r}", mb_strtoupper($d['ext']), \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            if ($i % 2 === 1) $sh->getStyle("{$cNo}{$r}:{$cExt}{$r}")->getFill()->setFillType($solid)->getStartColor()->setRGB($zebra);
            $i++;
        }
        $end = $first + max(1, count($part)) - 1;
        $sh->getStyle("{$cNo}{$hdr}:{$cExt}{$end}")->applyFromArray($thin);
        $sh->getStyle("{$cNo}{$hdr}:{$cExt}{$end}")->getBorders()->getOutline()
           ->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_MEDIUM)->getColor()->setRGB($navy);
        $sh->getStyle("{$cNo}{$first}:{$cExt}{$end}")->getFont()->setSize(9.5);
        $sh->getStyle("{$cNo}{$first}:{$cNo}{$end}")->getAlignment()->setHorizontal('center');
        $sh->getStyle("{$cNo}{$first}:{$cNo}{$end}")->getFont()->getColor()->setRGB('64748B');
        $sh->getStyle("{$cExt}{$first}:{$cExt}{$end}")->getAlignment()->setHorizontal('center');
        $sh->getStyle("{$cExt}{$first}:{$cExt}{$end}")->getFont()->setBold(true)->getColor()->setRGB($blue);
        $sh->getStyle("{$cBag}{$first}:{$cNama}{$end}")->getAlignment()->setWrapText(true);
        $sh->getColumnDimension($cNo)->setWidth(5);
        $sh->getColumnDimension($cBag)->setWidth($wBag);
        $sh->getColumnDimension($cNama)->setWidth($wNama);
        $sh->getColumnDimension($cExt)->setWidth(7);
    }
    // Separuh kanan kosong: lebar kolom E-I sama dengan daftar di kiri supaya daftar menempati setengah lembar.
    foreach (['E' => 3, 'F' => 5, 'G' => $wBag, 'H' => $wNama, 'I' => 7] as $c => $w) $sh->getColumnDimension($c)->setWidth($w);

    $sh->mergeCells("A{$foot}:{$lastCol}{$foot}");
    $sh->setCellValueExplicit("A{$foot}", trim($company . ($phone !== '' && $phone !== $company ? '   •   ' . $phone : '')),
        \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
    $sh->getStyle("A{$foot}")->getFont()->setSize(8)->setBold(true)->getColor()->setRGB($navy);
    $sh->getStyle("A{$foot}")->getAlignment()->setHorizontal('center');

    $sh->getStyle("A1:{$lastCol}{$foot}")->getFont()->setName('Calibri');
    $sh->getStyle("A{$first}:{$lastCol}{$last}")->getAlignment()->setVertical('center');
    $ps = $sh->getPageSetup();
    $ps->setOrientation(\PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_LANDSCAPE);
    $ps->setPaperSize(\PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4);
    $ps->setFitToPage(true)->setFitToWidth(1)->setFitToHeight(1);
    $ps->setHorizontalCentered(false);
    $ps->setPrintArea("A1:I{$foot}");
    $m = $sh->getPageMargins();
    $m->setTop(0.35)->setBottom(0.35)->setLeft(0.35)->setRight(0.35)->setHeader(0)->setFooter(0);
    $sh->setShowGridlines(false);
    $sh->setSelectedCell('A1');
}

/** File gambar kop untuk Excel: [logo, ornamen] ('' kalau tidak ada). Mendukung kop tetap (kantor) dan kop yang diatur admin (installer). */
function extLetterheadFiles(): array
{
    if (function_exists('letterheadImagePath')) {
        return [letterheadImagePath('logo'), letterheadImagePath('ornament')];
    }
    $dir = __DIR__ . '/../assets/img/letterhead/';
    return [is_file($dir . 'logo.png') ? $dir . 'logo.png' : '', is_file($dir . 'lines.png') ? $dir . 'lines.png' : ''];
}

/** Teks dua bahasa (tidak bergantung pada includes/xls_number.php). */
function xlsL2(string $id, string $en): string
{
    return (function_exists('currentLang') ? currentLang() === 'id' : true) ? $id : $en;
}

/**
 * Daftar Nomor Ext siap cetak / PDF: 1 salinan, A4 landscape, kop perusahaan selebar halaman.
 * Baris banyak -> tabel dilanjutkan di kolom kanan (nomor bersambung). Teks panjang turun baris;
 * huruf mengecil sendiri bila perlu supaya tetap 1 lembar. Tabel + CSS sederhana (browser & Dompdf).
 * $pdf = true -> gambar JPG (Dompdf tanpa GD) dan tanpa tombol/skrip print.
 */
function extDirectoryHtml(array $dir, bool $pdf = false, ?float $fontPt = null): string
{
    require_once __DIR__ . '/letterhead.php';
    $h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    $n = count($dir);
    $halves = extDirectoryHalves($dir);
    $lines = 0;
    foreach ($halves[0] as $d) $lines += max(1, (int)ceil(mb_strlen($d['nama']) / 40), (int)ceil(mb_strlen($d['bagian']) / 24));
    $fs = $fontPt ?? ($lines <= 30 ? 9.5 : ($lines <= 40 ? 8.5 : ($lines <= 50 ? 7.6 : ($lines <= 60 ? 6.8 : 6.2))));
    $pad = $fs >= 9 ? 2 : ($fs >= 7.5 ? 1 : 0.4);
    $addr = letterheadAddress();
    $company = (string)($addr[0] ?? '');
    $phone = (string)end($addr);
    $updated = preg_replace('/^[^:]+:\s*/', '', documentCreatedAt());
    // Kop kantor: gambar tetap (logo/lines). Versi installer: kop yang diatur admin (slot logo/ornament).
    $custom = defined('LETTERHEAD_SLOTS');
    $logo = $custom ? letterheadImage('logo') : letterheadImage('logo', $pdf ? 'jpg' : 'png');
    $orn  = $custom ? letterheadImage('ornament') : letterheadImage('lines', $pdf ? 'jpg' : 'png');
    $l = fn($id, $en) => (function_exists('currentLang') && currentLang() !== 'id') ? $en : $id;

    $no = 0;
    $tables = [];
    foreach ($halves as $part) {
        $rows = '';
        $i = 0;
        foreach ($part as $d) {
            $no++;
            $rows .= '<tr' . ($i++ % 2 ? ' class="z"' : '') . '><td class="no">' . $no . '</td><td>' . $h(mb_strtoupper($d['bagian'])) . '</td><td>'
                  . $h(mb_strtoupper($d['nama'] !== '' ? $d['nama'] : '-')) . '</td><td class="ext">' . $h(mb_strtoupper($d['ext'])) . '</td></tr>';
        }
        if (!$part) $rows = '<tr><td colspan="4" class="no">-</td></tr>';
        $tables[] = '<table class="list"><thead><tr><th style="width:7%">NO</th><th style="width:32%">BAGIAN</th><th>NAMA</th><th style="width:9%">EXT</th></tr></thead><tbody>' . $rows . '</tbody></table>';
    }
    $body = $tables[0];

    $copy = '<div class="copy">'
          . '<table class="kop"><tr><td class="l">' . ($logo ? '<img src="' . $logo . '" style="height:13mm;max-width:60mm" alt="">' : '') . '</td>'
          . '<td class="r">' . ($orn ? '<img src="' . $orn . '" style="height:13mm;max-width:45mm" alt="">' : '') . '</td></tr></table>'
          . '<div class="band">NO EXTENTION TELEPON</div>'
          . '<div class="upd">' . $h($l('Diperbarui: ', 'Updated: ') . $updated . '  •  ' . $n . $l(' nomor ext', ' extensions')) . '</div>'
          . $body
          . '<div class="foot">' . $h($company . ($phone !== '' && $phone !== $company ? '  •  ' . $phone : '')) . '</div>'
          . '</div>';

    $css = '@page { size: A4 landscape; margin: 8mm 9mm; }'
         . 'body { font-family: Arial, Helvetica, sans-serif; color:#111; margin:0; }'
         . '.page { width:279mm; margin:0 auto; }'
         . 'table.sheet { width:100%; border-collapse:collapse; table-layout:fixed; }'
         . 'table.sheet > tbody > tr > td, table.sheet > tr > td { vertical-align:top; padding:0; }'
         . '.kop { width:100%; border-collapse:collapse; border-bottom:2px solid #173A68; margin-bottom:2mm; }'
         . '.kop td { padding:0 0 1.5mm 0; border:0; } .kop .r { text-align:right; }'
         . '.band { background:#173A68; color:#fff; text-align:center; font-weight:bold; font-size:12.5pt; padding:1.4mm 0; letter-spacing:.3px; }'
         . '.upd { text-align:center; font-size:7.5pt; font-style:italic; color:#475569; padding:1mm 0 1.6mm; }'
         . 'table.list { width:100%; border-collapse:collapse; table-layout:fixed; border:1.4px solid #173A68; font-size:' . $fs . 'pt; line-height:1.18; }'
         . 'table.list th { background:#DCE6F5; color:#173A68; font-weight:bold; text-align:center; padding:' . $pad . 'px 3px; border:1px solid #9AA7BA; }'
         . 'table.list td { padding:' . $pad . 'px 4px; border:1px solid #9AA7BA; vertical-align:middle; word-wrap:break-word; overflow-wrap:anywhere; }'
         . 'table.list tr.z td { background:#F3F6FB; }'
         . 'td.no { text-align:center; color:#64748b; } td.ext { text-align:center; font-weight:bold; color:#1F3DD1; }'
         . 'table.list tr { page-break-inside:avoid; }'
         . '.foot { text-align:center; font-size:7.5pt; font-weight:bold; color:#173A68; padding-top:2mm; }'
         . '.bar { text-align:center; margin:4mm 0; font-family:Arial, sans-serif; }'
         . '.bar a, .bar button { display:inline-block; background:#1F3DD1; color:#fff; border:0; border-radius:6px; padding:8px 16px; font-size:13px; text-decoration:none; margin:0 4px; cursor:pointer; }'
         . '.bar a.o { background:#fff; color:#1F3DD1; border:1px solid #1F3DD1; }'
         . '@media print { .bar { display:none; } body { -webkit-print-color-adjust:exact; print-color-adjust:exact; } }';
    $bar = $pdf ? '' : '<div class="bar"><button onclick="window.print()">' . $h($l('Print / Simpan PDF', 'Print / Save as PDF')) . '</button>'
        . '<a href="ext_directory.php?pdf=1&amp;t=' . time() . '">' . $h($l('Unduh PDF', 'Download PDF')) . '</a>'
        . '<a class="o" href="ext_directory.php">' . $h($l('Kembali', 'Back')) . '</a></div>';
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>NO EXTENTION TELEPON</title><style>' . $css . '</style></head><body>'
         . $bar
         . '<div class="page"><table class="sheet"><tr><td style="width:50%;padding-right:5mm">' . $copy . '</td><td></td></tr></table></div>'
         . ($pdf ? '' : '<script>'
            // Kecilkan huruf sampai muat 1 lembar A4 landscape (tinggi area cetak ±194 mm), lalu buka dialog print.
            . 'function fitExt(){var mm=document.createElement("div");mm.style.height="100mm";document.body.appendChild(mm);var px=mm.offsetHeight/100;mm.remove();'
            . 'var max=188*px,c=document.querySelector(".copy"),t=document.querySelectorAll("table.list"),f=' . $fs . ';'
            . 'while(c.offsetHeight>max&&f>5){f-=0.25;t.forEach(function(x){x.style.fontSize=f+"pt";});}}'
            . 'window.addEventListener("load",function(){fitExt();setTimeout(function(){window.print();},300);});</script>')
         . '</body></html>';
}
