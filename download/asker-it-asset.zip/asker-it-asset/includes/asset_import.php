<?php
/**
 * Import Excel format UMUM aset (template_inventory_it.xlsx / hasil export sheet "Inventory").
 * Isi fungsi ini dipindah apa adanya dari import_process.php supaya bisa dipakai juga oleh
 * tablet_import_preview.php (file campuran: sheet Inventory + sheet Tablet).
 * Transaksi (beginTransaction/commit) diatur oleh pemanggil.
 *
 * Return: [jumlah baru, jumlah diperbarui, jumlah dilewati]
 */
require_once __DIR__ . '/asset_number.php';
require_once __DIR__ . '/categories.php';

function importGenericAssetSheet(PDO $db, \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet): array
{
    // Daftar Jenis Aset yang valid mengikuti kategori yang dikelola admin lewat menu Kategori Aset.
    $validCategories = array_column(getAssetCategories($db), 'name');
    $validStatuses   = ['Digunakan','Stok','Tidak Digunakan'];

    $rows  = $sheet->toArray(null, true, true, true); // keyed by column letter (A, B, C...)

    $headerRow = array_shift($rows); // baris pertama = header
    // File Excel bisa berupa hasil export bahasa Indonesia ATAU bahasa Inggris
    // (fitur auto-translate export). Judul kolom bahasa Inggris dipetakan balik
    // ke judul Indonesia di sini, supaya logika di bawah (yang memakai judul
    // Indonesia sebagai kunci) tetap jalan untuk kedua bahasa.
    $headerAliasesEn = [
        'Asset ID'      => 'ID Aset',
        'Category'      => 'Kategori',
        'Device Name'   => 'Nama Perangkat',
        'Users'         => 'Pengguna',
        'Department'    => 'Departement',
        'OS Status'     => 'Status OS',
        'Software Status' => 'Status Software',
        'Storage'       => 'Penyimpanan',
        'Location'      => 'Lokasi',
        'Accessories'   => 'Aksesoris',
        'PC Username'   => 'Username PC',
        'PC Password'   => 'Password PC',
        'User Email'    => 'Email Pengguna',
        'Purchase Date' => 'Tanggal Pembelian',
    ];

    // Petakan nama kolom -> huruf kolom, agar tidak bergantung urutan.
    // Catatan khusus: template punya 2 kolom berjudul sama "Serial Number"
    // (satu untuk OS, satu untuk Software). Dibedakan berdasarkan judul
    // kolom sebelumnya (OS -> "Serial Number OS", Software -> "Serial Number Software").
    $colMap = [];
    $prevTitle = null;
    foreach ($headerRow as $letter => $title) {
        $title = trim((string)$title);
        if (isset($headerAliasesEn[$title])) {
            $title = $headerAliasesEn[$title];
        }
        if ($title === 'Serial Number') {
            if ($prevTitle === 'OS') {
                $colMap['Serial Number OS'] = $letter;
            } elseif ($prevTitle === 'Software') {
                $colMap['Serial Number Software'] = $letter;
            } else {
                $colMap['Serial Number'] = $letter;
            }
        } else {
            $colMap[$title] = $letter;
        }
        $prevTitle = $title;
    }

    // 'ID Aset' boleh tidak ada / dikosongkan: aset baru mendapat Nomor Aset otomatis.
    $required = ['Kategori'];
    foreach ($required as $r) {
        if (!isset($colMap[$r])) {
            throw new Exception("Kolom wajib '$r' tidak ditemukan. Pastikan format sesuai template.");
        }
    }

    $findUser = $db->prepare("SELECT id FROM users WHERE full_name = ? LIMIT 1");
    $findAsset = $db->prepare("SELECT id FROM assets WHERE asset_number = ? LIMIT 1");

    $insert = $db->prepare("INSERT INTO assets
        (asset_number, category, device_name, department, owner_email, ip_address, hostname, os_name,
         serial_number, os_status, processor, ram, storage, location, status,
         printer_info, monitor_info, accessories, pc_username, pc_password)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

    $update = $db->prepare("UPDATE assets SET
        category=?, device_name=?, department=?, owner_email=?, ip_address=?, hostname=?, os_name=?,
        serial_number=?, os_status=?, processor=?, ram=?, storage=?, location=?, status=?,
        printer_info=?, monitor_info=?, accessories=?, pc_username=?, pc_password=?
        WHERE asset_number=?");

    $get = fn(array $row, string $key) => isset($colMap[$key]) ? trim((string)($row[$colMap[$key]] ?? '')) : '';

    $inserted = 0; $updated = 0; $skipped = 0;

    foreach ($rows as $row) {
        $assetNumber = $get($row, 'ID Aset');
        // ID Aset kosong = aset BARU dengan nomor otomatis (dibuat di bawah, setelah jenis & pengguna terbaca).
        // Baris yang benar-benar kosong tetap dilewati.
        if ($assetNumber === '' && $get($row, 'Kategori') === '' && $get($row, 'Nama Perangkat') === '' && $get($row, 'Pengguna') === '') {
            $skipped++; continue;
        }

        $category = $get($row, 'Kategori');
        if (!in_array($category, $validCategories, true)) { $category = 'Aksesoris'; }

        $status = $get($row, 'Status');
        // Terima juga nilai Status bahasa Inggris (hasil export dengan translate aktif).
        $statusValueAliasesEn = ['In Use' => 'Digunakan', 'In Stock' => 'Stok', 'Not In Use' => 'Tidak Digunakan'];
        $status = $statusValueAliasesEn[$status] ?? $status;
        if (!in_array($status, $validStatuses, true)) { $status = 'Stok'; }

        // Kolom "Pengguna" sekarang bisa berisi lebih dari 1 nama sekaligus
        // (1 aset bisa dipakai beberapa pengguna), dipisah koma atau titik koma.
        // Departement & Email Pengguna dibaca langsung dari kolomnya sendiri di
        // Excel, tidak lagi otomatis diambil dari data 1 user tertentu.
        $ownerNames = array_filter(array_map('trim', preg_split('/[,;]/', $get($row, 'Pengguna'))), fn($v) => $v !== '');
        $ownerIds = [];
        foreach ($ownerNames as $ownerName) {
            $findUser->execute([$ownerName]);
            $u = $findUser->fetch();
            if ($u) { $ownerIds[] = (int)$u['id']; }
        }
        $department = $get($row, 'Departement');
        $ownerEmail = $get($row, 'Email Pengguna');
        $osStatus = strtolower($get($row, 'Status OS')) === 'original' ? 'Original' : 'Belum Original';

        $data = [
            $category,
            $get($row, 'Nama Perangkat'),
            $department,
            $ownerEmail,
            $get($row, 'IP Address'),
            $get($row, 'Hostname'),
            $get($row, 'OS'),
            $get($row, 'Serial Number OS'),
            $osStatus,
            $get($row, 'Processor'),
            $get($row, 'RAM'),
            // Kolom "Hardisk" diganti nama jadi "Penyimpanan" di template terbaru,
            // tapi file Excel lama (header masih "Hardisk") tetap kebaca normal.
            $get($row, 'Penyimpanan') ?: $get($row, 'Hardisk'),
            $get($row, 'Lokasi'),
            $status,
            $get($row, 'Printer'),
            $get($row, 'Monitor'),
            $get($row, 'Aksesoris'),
            $get($row, 'Username PC') ?: null, // kolom opsional
            $get($row, 'Password PC') ?: null, // kolom opsional
        ];

        // Software bisa lebih dari satu -> kolom Software/Serial Number Software/
        // Status Software dipisah ";" (format yang sama dipakai saat export), lalu
        // digabung jadi beberapa entri sejajar (item ke-1 semua kolom = 1 software).
        $softwareNames    = array_map('trim', preg_split('/;/', $get($row, 'Software')));
        $softwareSerials  = array_map('trim', preg_split('/;/', $get($row, 'Serial Number Software')));
        $softwareStatuses = array_map('trim', preg_split('/;/', $get($row, 'Status Software')));
        $softwareItems = [];
        foreach ($softwareNames as $i => $name) {
            if ($name === '') continue;
            $softwareItems[] = [
                'name'     => $name,
                'serial'   => ($softwareSerials[$i] ?? '') !== '-' ? ($softwareSerials[$i] ?? '') : '',
                'original' => strtolower($softwareStatuses[$i] ?? '') === 'original',
            ];
        }

        if ($assetNumber === '') {
            // Format sama dengan form Tambah Aset: departement diambil dari pengguna pertama (atau kolom Departement).
            $suggest = suggestAssetNumber($db, $category, assetNumberDepartment($db, $ownerIds, $department), $get($row, 'Lokasi'));
            if (!$suggest['ok']) { $skipped++; continue; }   // mis. Tablet tanpa Lokasi
            $assetNumber = $suggest['asset_number'];
        }

        $findAsset->execute([$assetNumber]);
        $existing = $findAsset->fetch();
        if ($existing) {
            $update->execute([...$data, $assetNumber]);
            $assetId = (int)$existing['id'];
            $updated++;
        } else {
            $insert->execute([$assetNumber, ...$data]);
            $assetId = (int)$db->lastInsertId();
            $inserted++;
        }
        setAssetOwners($db, $assetId, $ownerIds);
        // Jika user ditemukan, data Departement/Email/Login PC diambil dari master User.
        // Jika tidak ada user yang cocok, nilai dari file Excel tetap dipakai.
        if ($ownerIds) { syncAssetUserData($db, (int)$assetId); }
        if ($softwareItems) {
            setAssetSoftware($db, $assetId, $softwareItems);
        }
    }


    return [$inserted, $updated, $skipped];
}
