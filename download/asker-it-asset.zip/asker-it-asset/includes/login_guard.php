<?php
/**
 * Pembatas percobaan login: 5 kali salah dalam 10 menit (per username ATAU per alamat IP)
 * -> dikunci 10 menit. Semua percobaan dicatat di tabel baru login_attempts
 * (dibuat otomatis, CREATE TABLE IF NOT EXISTS; tabel lama tidak diubah). Catatan > 90 hari dihapus otomatis.
 */

const LOGIN_MAX_FAIL    = 5;
const LOGIN_WINDOW_SEC  = 600;   // 10 menit

function ensureLoginAttemptsTable(PDO $db): void
{
    static $done = false;
    if ($done) return;
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS login_attempts (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) NOT NULL,
            ip VARCHAR(45) NOT NULL,
            success TINYINT(1) NOT NULL DEFAULT 0,
            user_agent VARCHAR(255) NULL,
            created_at DATETIME NOT NULL,
            INDEX idx_user (username, created_at),
            INDEX idx_ip (ip, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) { /* sudah ada */ }
    $done = true;
}

function loginClientIp(): string
{
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
}

/** Sisa detik terkunci (0 = boleh mencoba). */
function loginLockedSeconds(PDO $db, string $username): int
{
    try {
        ensureLoginAttemptsTable($db);
        $since = date('Y-m-d H:i:s', time() - LOGIN_WINDOW_SEC);
        $wait = 0;
        foreach ([['username', mb_strtolower($username)], ['ip', loginClientIp()]] as [$col, $val]) {
            if ($val === '') continue;
            $st = $db->prepare("SELECT created_at FROM login_attempts WHERE $col = ? AND success = 0 AND created_at >= ?
                                AND created_at > COALESCE((SELECT MAX(created_at) FROM login_attempts WHERE $col = ? AND success = 1), '2000-01-01')
                                ORDER BY created_at DESC LIMIT " . LOGIN_MAX_FAIL);
            $st->execute([$val, $since, $val]);
            $rows = $st->fetchAll(PDO::FETCH_COLUMN);
            if (count($rows) >= LOGIN_MAX_FAIL) {
                $wait = max($wait, strtotime((string)$rows[0]) + LOGIN_WINDOW_SEC - time());
            }
        }
        return max(0, $wait);
    } catch (Throwable $e) {
        return 0;   // pembatas gagal dicek -> login tetap bisa (jangan mengunci semua orang)
    }
}

function loginRecord(PDO $db, string $username, bool $success): void
{
    try {
        ensureLoginAttemptsTable($db);
        $db->prepare("INSERT INTO login_attempts (username, ip, success, user_agent, created_at) VALUES (?, ?, ?, ?, ?)")
           ->execute([mb_substr(mb_strtolower($username), 0, 100), loginClientIp(), $success ? 1 : 0, mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255), date('Y-m-d H:i:s')]);
        if (random_int(1, 50) === 1) $db->exec("DELETE FROM login_attempts WHERE created_at < '" . date('Y-m-d H:i:s', time() - 90 * 86400) . "'");
    } catch (Throwable $e) {}
}
