<?php
/**
 * Standar Spesifikasi PC & Laptop (khusus admin).
 *
 * - Admin menentukan beberapa "standar" (spesifikasi minimal): prosesor, generasi, RAM, OS,
 *   edisi Pro, SSD, VGA. Tiap standar berlaku untuk departemen atau jabatan tertentu;
 *   satu standar "umum" berlaku untuk semua yang tidak cocok dengan standar lain.
 * - Spesifikasi tiap Laptop / Desktop PC dibaca otomatis dari teks data aset
 *   (processor, ram, storage, os_name) + isian VGA (tabel asset_gpu) / kolom aksesoris.
 * - Admin bisa mengoreksi hasil baca, memilih standar, status, saran, dan catatan per aset.
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA:
 * - Hanya MEMBUAT 3 tabel BARU jika belum ada: spec_tiers, spec_overrides, asset_gpu.
 * - Tidak ALTER / DROP tabel lama dan tidak mengubah isi tabel aset.
 *
 * Dipakai oleh: spec_standard.php, spec_standard_export.php, assets.php / asset_save.php (isian VGA),
 * includes/asset_detail_template.php (detail / cetak / PDF aset).
 */

function spL(string $id, string $en): string
{
    return function_exists('currentLang') && currentLang() === 'en' ? $en : $id;
}

/** Buat 3 tabel baru jika belum ada (CREATE TABLE IF NOT EXISTS — tidak menyentuh tabel lain). */
function specEnsure(PDO $db): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    $sql = [
        "CREATE TABLE IF NOT EXISTS spec_tiers (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            name        VARCHAR(100) NOT NULL,
            kind        VARCHAR(20)  NOT NULL DEFAULT 'departemen',   -- umum | departemen | jabatan
            match_text  VARCHAR(500) NOT NULL DEFAULT '',             -- daftar departemen / kata kunci jabatan, pisah koma
            cpu_min     VARCHAR(10)  NOT NULL DEFAULT 'i3',
            gen_min     INT          NOT NULL DEFAULT 10,
            ram_min     INT          NOT NULL DEFAULT 8,
            os_min      INT          NOT NULL DEFAULT 11,
            need_pro    TINYINT(1)   NOT NULL DEFAULT 1,
            need_ssd    TINYINT(1)   NOT NULL DEFAULT 1,
            need_gpu    TINYINT(1)   NOT NULL DEFAULT 0,
            sort_order  INT          NOT NULL DEFAULT 0,
            updated_at  DATETIME     NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS spec_overrides (
            asset_id    INT UNSIGNED NOT NULL PRIMARY KEY,             -- assets.id (tanpa foreign key)
            tier_id     INT UNSIGNED NULL,
            cpu_cls     VARCHAR(10)  NULL,
            cpu_gen     INT          NULL,
            ram_gb      INT          NULL,
            ssd         TINYINT(1)   NULL,
            os_ver      INT          NULL,
            os_pro      TINYINT(1)   NULL,
            status      VARCHAR(10)  NULL,                             -- ok | bad | warn (paksa)
            action_text VARCHAR(255) NULL,
            note        VARCHAR(255) NULL,
            updated_by  VARCHAR(150) NULL,
            updated_at  DATETIME     NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS asset_gpu (
            asset_id    INT UNSIGNED NOT NULL PRIMARY KEY,             -- assets.id (tanpa foreign key)
            gpu         VARCHAR(150) NOT NULL DEFAULT '',
            updated_at  DATETIME     NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    ];
    foreach ($sql as $q) {
        try { $db->exec($q); } catch (Throwable $e) { /* tabel sudah ada / dibuat manual */ }
    }
    try {
        if ((int)$db->query("SELECT COUNT(*) FROM spec_tiers")->fetchColumn() === 0) {
            // Standar awal sesuai permintaan IT; departemen CAD / Multimedia diisi admin di halaman Standar Spesifikasi.
            $ins = $db->prepare("INSERT INTO spec_tiers (name, kind, match_text, cpu_min, gen_min, ram_min, os_min, need_pro, need_ssd, need_gpu, sort_order, updated_at)
                                 VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())");
            foreach ([
                ['Admin & Staff', 'umum', '', 'i3', 10, 8, 11, 1, 1, 0, 1],
                ['CAD', 'departemen', '', 'i5', 10, 8, 11, 1, 1, 1, 2],
                ['Multimedia', 'departemen', '', 'i7', 10, 16, 11, 1, 1, 0, 3],
                ['Manager', 'jabatan', 'Manager, GM, General Manager, Direktur, Director', 'i5', 10, 8, 11, 1, 1, 0, 4],
            ] as $r) $ins->execute($r);
        }
    } catch (Throwable $e) { }
}

/* ===================== Data ===================== */

function specCpuClasses(): array
{
    return ['celeron' => 'Celeron / Athlon', 'pentium' => 'Pentium', 'i3' => 'Core i3 / Ryzen 3', 'i5' => 'Core i5 / Ryzen 5', 'i7' => 'Core i7 / Ryzen 7', 'i9' => 'Core i9 / Ryzen 9'];
}
function specCpuRank(string $c): int { return ['celeron' => 0, 'pentium' => 1, 'i3' => 2, 'i5' => 3, 'i7' => 4, 'i9' => 5][$c] ?? 0; }
function specCpuShort(string $c): string { return ['celeron' => 'Celeron', 'pentium' => 'Pentium'][$c] ?? 'Core ' . $c; }
function specOsList(): array { return [7 => 'Windows 7', 8 => 'Windows 8.1', 10 => 'Windows 10', 11 => 'Windows 11']; }
function specKinds(): array { return ['umum' => spL('Umum', 'General'), 'departemen' => spL('Departemen', 'Department'), 'jabatan' => spL('Jabatan', 'Position')]; }

function specTiers(PDO $db): array
{
    $rows = $db->query("SELECT * FROM spec_tiers ORDER BY sort_order, id")->fetchAll();
    foreach ($rows as &$r) {
        foreach (['id', 'gen_min', 'ram_min', 'os_min', 'need_pro', 'need_ssd', 'need_gpu', 'sort_order'] as $k) $r[$k] = (int)$r[$k];
    }
    return $rows;
}

/** Simpan seluruh daftar standar dari form (baris baru id=0, baris hilang = dihapus). */
function specSaveTiers(PDO $db, array $post): array
{
    $ids = (array)($post['tid'] ?? []);
    $keep = []; $hasUmum = false; $order = 0;
    $classes = specCpuClasses(); $oses = specOsList();
    $db->beginTransaction();
    try {
        foreach ($ids as $i => $id) {
            $id = (int)$id;
            if (!empty($post['tdel'][$i])) continue;
            $name = mb_substr(trim((string)($post['tname'][$i] ?? '')), 0, 100);
            if ($name === '') continue;
            $kind = (string)($post['tkind'][$i] ?? 'departemen');
            if (!isset(specKinds()[$kind])) $kind = 'departemen';
            if ($kind === 'umum') { if ($hasUmum) $kind = 'departemen'; else $hasUmum = true; }
            $cpu = (string)($post['tcpu'][$i] ?? 'i3'); if (!isset($classes[$cpu])) $cpu = 'i3';
            $os  = (int)($post['tos'][$i] ?? 11);      if (!isset($oses[$os])) $os = 11;
            $match = implode(', ', array_filter(array_map('trim', explode(',', (string)($post['tmatch'][$i] ?? '')))));
            $v = [$name, $kind, mb_substr($match, 0, 500), $cpu,
                  max(1, min(30, (int)($post['tgen'][$i] ?? 10))), max(1, min(1024, (int)($post['tram'][$i] ?? 8))), $os,
                  !empty($post['tpro'][$i]) ? 1 : 0, !empty($post['tssd'][$i]) ? 1 : 0, !empty($post['tgpu'][$i]) ? 1 : 0, ++$order];
            if ($id > 0) {
                $db->prepare("UPDATE spec_tiers SET name=?, kind=?, match_text=?, cpu_min=?, gen_min=?, ram_min=?, os_min=?, need_pro=?, need_ssd=?, need_gpu=?, sort_order=?, updated_at=NOW() WHERE id=?")
                   ->execute(array_merge($v, [$id]));
                $keep[] = $id;
            } else {
                $db->prepare("INSERT INTO spec_tiers (name, kind, match_text, cpu_min, gen_min, ram_min, os_min, need_pro, need_ssd, need_gpu, sort_order, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())")
                   ->execute($v);
                $keep[] = (int)$db->lastInsertId();
            }
        }
        if (!$keep) { $db->rollBack(); return ['ok' => false, 'msg' => spL('Minimal harus ada 1 standar.', 'At least one standard is required.')]; }
        if (!$hasUmum) {   // harus ada 1 standar umum sebagai cadangan: pakai yang pertama
            $db->prepare("UPDATE spec_tiers SET kind='umum' WHERE id=?")->execute([$keep[0]]);
        }
        $in = implode(',', array_map('intval', $keep));
        $db->exec("DELETE FROM spec_tiers WHERE id NOT IN ($in)");
        $db->exec("UPDATE spec_overrides SET tier_id = NULL WHERE tier_id IS NOT NULL AND tier_id NOT IN ($in)");
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        return ['ok' => false, 'msg' => $e->getMessage()];
    }
    return ['ok' => true, 'msg' => spL('Standar spesifikasi disimpan.', 'Specification standards saved.')];
}

/** Laptop & Desktop PC (semua status kecuali Tidak Digunakan). */
function specIsPcCategory(string $cat): bool
{
    $c = mb_strtolower($cat);
    return strpos($c, 'laptop') !== false || strpos($c, 'desktop') !== false || strpos($c, 'notebook') !== false
        || in_array($c, ['pc', 'komputer', 'computer', 'all in one', 'all-in-one', 'aio'], true);
}

function specAssets(PDO $db): array
{
    $rows = $db->query("SELECT id, asset_number, category, device_name, department, processor, ram, storage, os_name, accessories, status
                        FROM assets ORDER BY department, asset_number")->fetchAll();
    $rows = array_values(array_filter($rows, fn($r) => specIsPcCategory((string)$r['category']) && (string)$r['status'] !== 'Tidak Digunakan'));
    if (!$rows) return [];
    $ids = array_map(fn($r) => (int)$r['id'], $rows);
    require_once __DIR__ . '/asset_owners.php';
    require_once __DIR__ . '/user_position.php';
    $owners = getAssetOwnersMap($db, $ids);
    $uids = [];
    foreach ($owners as $list) foreach ($list as $o) $uids[] = (int)$o['id'];
    $posMap = $uids ? getUserPositionMap($db, array_values(array_unique($uids))) : [];
    $gpu = specGpuMap($db, $ids);
    $ov  = specOverrideMap($db);
    foreach ($rows as &$r) {
        $id = (int)$r['id'];
        $list = $owners[$id] ?? [];
        $r['owner_names'] = implode(', ', array_column($list, 'full_name'));
        $r['positions'] = array_values(array_filter(array_map(fn($o) => (string)($posMap[(int)$o['id']] ?? ''), $list)));
        $r['gpu'] = $gpu[$id] ?? null;
        $r['ov'] = $ov[$id] ?? [];
    }
    return $rows;
}

function specGpuMap(PDO $db, array $ids = []): array
{
    $map = [];
    try {
        foreach ($db->query("SELECT asset_id, gpu FROM asset_gpu")->fetchAll() as $r) $map[(int)$r['asset_id']] = (string)$r['gpu'];
    } catch (Throwable $e) { }
    return $map;
}

function specGetGpu(PDO $db, int $assetId): ?string
{
    try {
        $s = $db->prepare("SELECT gpu FROM asset_gpu WHERE asset_id = ?");
        $s->execute([$assetId]);
        $v = $s->fetchColumn();
        return $v === false ? null : (string)$v;
    } catch (Throwable $e) { return null; }
}

/** Simpan isian VGA 1 aset ('' = hapus). */
function specSetGpu(PDO $db, int $assetId, string $gpu): void
{
    specEnsure($db);
    $gpu = mb_substr(trim(preg_replace('/\s+/u', ' ', $gpu)), 0, 150);
    if ($gpu === '') { $db->prepare("DELETE FROM asset_gpu WHERE asset_id = ?")->execute([$assetId]); return; }
    $db->prepare("INSERT INTO asset_gpu (asset_id, gpu, updated_at) VALUES (?,?,NOW())
                  ON DUPLICATE KEY UPDATE gpu = VALUES(gpu), updated_at = NOW()")->execute([$assetId, $gpu]);
}

function specOverrideMap(PDO $db): array
{
    $map = [];
    try {
        foreach ($db->query("SELECT * FROM spec_overrides")->fetchAll() as $r) $map[(int)$r['asset_id']] = $r;
    } catch (Throwable $e) { }
    return $map;
}

/* ===================== Pembaca teks spesifikasi ===================== */

/** "Intel(R) Core(TM) i5-1035G1" -> ['cls'=>'i5','gen'=>10,'label'=>'Core i5 gen 10']; null bila tidak terbaca. */
function specParseCpu(string $t): ?array
{
    $s = mb_strtolower($t);
    if (trim($s) === '') return null;
    if (preg_match('/celeron|athlon|atom|\bsempron/', $s)) return ['cls' => 'celeron', 'gen' => null, 'label' => preg_match('/athlon/', $s) ? 'Athlon' : 'Celeron'];
    if (preg_match('/pentium/', $s)) return ['cls' => 'pentium', 'gen' => null, 'label' => 'Pentium'];
    if (preg_match('/ultra\s*([579])\b/', $s, $m)) {
        $c = ['5' => 'i5', '7' => 'i7', '9' => 'i9'][$m[1]];
        return ['cls' => $c, 'gen' => 14, 'label' => 'Core Ultra ' . $m[1]];
    }
    if (preg_match('/\bi([3579])\s*[- ]?\s*(\d{4,5})/', $s, $m)) {
        $d = $m[2];
        $g = strlen($d) === 5 ? (int)substr($d, 0, 2) : (preg_match('/^1[0-4]/', $d) ? (int)substr($d, 0, 2) : (int)$d[0]);
        return ['cls' => 'i' . $m[1], 'gen' => $g, 'label' => 'Core i' . $m[1] . ' gen ' . $g];
    }
    if (preg_match('/\bi([3579])\b.{0,20}?(?:gen(?:erasi|eration)?\.?\s*(\d{1,2})|(\d{1,2})\s*(?:th|st|nd|rd)\s*gen)/', $s, $m)) {
        $g = (int)($m[2] !== '' ? $m[2] : ($m[3] ?? 0));
        return ['cls' => 'i' . $m[1], 'gen' => $g, 'label' => 'Core i' . $m[1] . ' gen ' . $g];
    }
    if (preg_match('/ryzen\s*([3579])\s*(?:pro\s*)?(\d)(\d{3})/', $s, $m)) {
        // Perkiraan setara generasi Intel: Ryzen 2000≈8, 3000≈10, 4000/5000≈11, 6000/7000≈12, 8000+≈13
        $eq = [1 => 7, 2 => 8, 3 => 10, 4 => 11, 5 => 11, 6 => 12, 7 => 12][(int)$m[2]] ?? 13;
        return ['cls' => 'i' . $m[1], 'gen' => $eq, 'label' => 'Ryzen ' . $m[1] . ' ' . $m[2] . $m[3] . ' (≈ gen ' . $eq . ')'];
    }
    if (preg_match('/\bi([3579])\b/', $s, $m)) return ['cls' => 'i' . $m[1], 'gen' => null, 'label' => 'Core i' . $m[1] . ' (gen ?)'];
    return null;
}

/** "8 GB DDR4" -> 8, "2x8GB" -> 16, "8192 MB" -> 8. */
function specParseRam(string $t): ?int
{
    $s = mb_strtolower($t);
    if (preg_match('/(\d+)\s*x\s*(\d+)\s*gb/', $s, $m)) return (int)$m[1] * (int)$m[2];
    if (preg_match('/(\d+(?:[.,]\d+)?)\s*gb/', $s, $m)) return (int)round((float)str_replace(',', '.', $m[1]));
    if (preg_match('/(\d{4,6})\s*mb/', $s, $m)) return (int)round((int)$m[1] / 1024);
    if (preg_match('/^\s*(\d{1,3})\s*$/', $s, $m)) return (int)$m[1];
    return null;
}

/** true = ada SSD, false = hanya HDD, null = kosong. */
function specParseSsd(string $t): ?bool
{
    $s = mb_strtolower(trim($t));
    if ($s === '' || $s === '-') return null;
    return (bool)preg_match('/ssd|nvme|m\.2|solid\s*state|emmc/', $s);
}

/** "Windows 11 Pro" -> ['v'=>11,'pro'=>true,'label'=>'Win 11 Pro']; ['v'=>null] bila bukan Windows; null bila kosong. */
function specParseOs(string $t): ?array
{
    $s = mb_strtolower(trim($t));
    if ($s === '' || $s === '-') return null;
    if (!preg_match('/(?:windows|win)\s*(11|10|8\.1|8|7|xp)/', $s, $m)) return ['v' => null, 'pro' => false, 'label' => $t];
    $v = $m[1] === 'xp' ? 5 : (int)floor((float)$m[1]);
    $pro = (bool)preg_match('/\bpro\b|professional|enterprise|education|\bltsc\b/', $s);
    return ['v' => $v, 'pro' => $pro, 'label' => 'Win ' . $m[1] . ($pro ? ' Pro' : (preg_match('/home|single language|core/', $s) ? ' Home' : ''))];
}

/** Kartu grafis terpisah dari merek/seri (bukan kabel/port VGA, bukan grafis bawaan). */
function specGpuKeyword(string $t): bool
{
    return (bool)preg_match('/nvidia|geforce|quadro|\brtx\b|\bgtx\b|\bgt\s?\d{3,4}\b|radeon\s*(?:rx|pro|r[579]|hd\s*\d{4})|\brx\s?\d{3,4}\b|firepro|intel\s*arc|\barc\s*a\d{3}/i', $t);
}
function specGpuIntegrated(string $t): bool
{
    return (bool)preg_match('/onboard|on-board|integrated|bawaan|uhd|iris|intel\s*hd|vega\s*\d|radeon\s*graphics|tidak ada|^\s*(?:-|none|no|tidak)\s*$/i', $t);
}

/**
 * Status VGA aset: ['has'=>true|false|null, 'text'=>..., 'src'=>'vga'|'aksesoris'|'', 'unclear'=>bool]
 * Isian VGA (asset_gpu) diutamakan; bila kosong dibaca dari kolom aksesoris.
 */
function specGpuInfo(?string $gpu, string $accessories): array
{
    $gpu = trim((string)$gpu);
    if ($gpu !== '') {
        if (specGpuIntegrated($gpu) && !specGpuKeyword($gpu)) return ['has' => false, 'text' => $gpu, 'src' => 'vga', 'unclear' => false];
        return ['has' => true, 'text' => $gpu, 'src' => 'vga', 'unclear' => false];
    }
    $found = specGpuFromAccessories($accessories);
    if ($found['text'] !== '') return ['has' => $found['unclear'] ? null : true, 'text' => $found['text'], 'src' => 'aksesoris', 'unclear' => $found['unclear']];
    return ['has' => null, 'text' => '', 'src' => '', 'unclear' => false];
}

/** Cari kartu grafis di teks aksesoris "Nama (Brand/Type), ...". */
function specGpuFromAccessories(string $acc): array
{
    $acc = trim($acc);
    if ($acc === '') return ['text' => '', 'unclear' => false];
    $parts = preg_split('/,(?![^(]*\))/u', $acc);   // pisah koma di luar tanda kurung
    $unclear = '';
    foreach ($parts as $p) {
        $p = trim($p);
        if ($p === '') continue;
        if (specGpuKeyword($p)) return ['text' => $p, 'unclear' => false];
        // kata VGA / kartu grafis tanpa merek -> perlu dicek; abaikan kabel, port, konverter, splitter
        if ($unclear === '' && preg_match('/\bvga\b|graphic|grafis|video\s*card/i', $p)
            && !preg_match('/kabel|cable|port|konverter|converter|adapter|adaptor|splitter|switch|\bto\s+vga|vga\s+to|hdmi|monitor|proyektor|projector|extender/i', $p)) {
            $unclear = $p;
        }
    }
    return $unclear !== '' ? ['text' => $unclear, 'unclear' => true] : ['text' => '', 'unclear' => false];
}

/* ===================== Penilaian ===================== */

function specTierScore(array $t): int
{
    return specCpuRank($t['cpu_min']) * 1000 + $t['gen_min'] * 10 + (int)$t['ram_min'] + ($t['need_gpu'] ? 5 : 0);
}

function specMatchList(string $s): array
{
    return array_values(array_filter(array_map(fn($x) => mb_strtolower(trim($x)), explode(',', $s)), fn($x) => $x !== ''));
}

/** Standar untuk 1 aset: [tier, alasan]. */
function specTierFor(array $a, array $tiers): array
{
    $byId = array_column($tiers, null, 'id');
    $ovTier = (int)($a['ov']['tier_id'] ?? 0);
    if ($ovTier && isset($byId[$ovTier])) return [$byId[$ovTier], spL('Dipilih manual', 'Set manually')];
    $dept = mb_strtolower(trim((string)$a['department']));
    $hits = [];
    foreach ($tiers as $t) {
        if ($t['kind'] === 'departemen' && $dept !== '' && in_array($dept, specMatchList($t['match_text']), true)) {
            $hits[] = [$t, spL('Departemen ', 'Department ') . $a['department']];
        }
        if ($t['kind'] === 'jabatan') {
            foreach ($a['positions'] as $pos) {
                foreach (specMatchList($t['match_text']) as $kw) {
                    if (preg_match('/(?<![\p{L}\p{N}])' . preg_quote($kw, '/') . '(?![\p{L}\p{N}])/iu', $pos)) { $hits[] = [$t, spL('Jabatan ', 'Position ') . $pos]; break 2; }
                }
            }
        }
    }
    if ($hits) {
        usort($hits, fn($x, $y) => specTierScore($y[0]) <=> specTierScore($x[0]));
        return $hits[0];
    }
    foreach ($tiers as $t) if ($t['kind'] === 'umum') return [$t, spL('Standar umum', 'General standard')];
    return [$tiers[0], spL('Standar umum', 'General standard')];
}

/** Spesifikasi efektif (hasil baca otomatis + koreksi admin). */
function specEffective(array $a): array
{
    $o = $a['ov'] ?? [];
    $cpu = specParseCpu((string)$a['processor']);
    $autoCpu = $cpu;
    if (!empty($o['cpu_cls'])) {
        $g = $o['cpu_gen'] !== null && $o['cpu_gen'] !== '' ? (int)$o['cpu_gen'] : ($cpu['gen'] ?? null);
        $cpu = ['cls' => $o['cpu_cls'], 'gen' => $g, 'label' => specCpuShort($o['cpu_cls']) . ($g !== null && !in_array($o['cpu_cls'], ['celeron', 'pentium'], true) ? ' gen ' . $g : '')];
    }
    $ram = specParseRam((string)$a['ram']);
    if (isset($o['ram_gb']) && $o['ram_gb'] !== null && $o['ram_gb'] !== '') $ram = (int)$o['ram_gb'];
    $ssd = specParseSsd((string)$a['storage']);
    if (isset($o['ssd']) && $o['ssd'] !== null && $o['ssd'] !== '') $ssd = (bool)(int)$o['ssd'];
    $os = specParseOs((string)$a['os_name']);
    if (isset($o['os_ver']) && $o['os_ver'] !== null && $o['os_ver'] !== '') {
        $v = (int)$o['os_ver']; $pro = (bool)(int)($o['os_pro'] ?? 0);
        $os = ['v' => $v, 'pro' => $pro, 'label' => 'Win ' . ($v === 8 ? '8.1' : $v) . ($pro ? ' Pro' : ' Home')];
    }
    return ['cpu' => $cpu, 'auto_cpu' => $autoCpu, 'ram' => $ram, 'ssd' => $ssd, 'os' => $os,
            'gpu' => specGpuInfo($a['gpu'] ?? null, (string)$a['accessories'])];
}

/** Nilai 1 aset terhadap standarnya. */
function specEvaluate(array $a, array $tiers): array
{
    [$t, $why] = specTierFor($a, $tiers);
    $e = specEffective($a);
    $fails = []; $miss = []; $fix = [];
    $cpu = $e['cpu'];
    if (!$cpu) $miss[] = spL('Prosesor tidak terbaca', 'Processor not recognised');
    else {
        $low = specCpuRank($cpu['cls']) < specCpuRank($t['cpu_min'])
            || ($cpu['gen'] !== null && $cpu['gen'] < $t['gen_min']);
        if ($low) { $fails[] = $cpu['label'] . ' < ' . specCpuShort($t['cpu_min']) . ' gen ' . $t['gen_min'] . '+'; $fix[] = 'replace'; }
        elseif ($cpu['gen'] === null && !in_array($cpu['cls'], ['celeron', 'pentium'], true)) $miss[] = spL('Generasi prosesor tidak terbaca', 'Processor generation unknown');
    }
    if ($e['ram'] === null) $miss[] = spL('RAM belum diisi', 'RAM not filled in');
    elseif ($e['ram'] < $t['ram_min']) { $fails[] = 'RAM ' . $e['ram'] . ' GB < ' . $t['ram_min'] . ' GB'; $fix[] = spL('tambah RAM', 'add RAM'); }
    if ($t['need_ssd']) {
        if ($e['ssd'] === null) $miss[] = spL('Penyimpanan belum diisi', 'Storage not filled in');
        elseif (!$e['ssd']) { $fails[] = spL('Masih HDD, belum SSD', 'HDD only, no SSD'); $fix[] = spL('pasang SSD', 'install SSD'); }
    }
    if ($t['need_gpu']) {
        $g = $e['gpu'];
        if ($g['unclear']) $miss[] = spL('VGA perlu dicek: ', 'Graphics card unclear: ') . $g['text'];
        elseif ($g['has'] === null) $miss[] = spL('VGA belum diisi', 'Graphics card not filled in');
        elseif (!$g['has']) { $fails[] = spL('Belum ada kartu grafis (VGA)', 'No dedicated graphics card'); $fix[] = spL('pasang VGA', 'install graphics card'); }
    }
    $os = $e['os'];
    $osName = specOsList()[$t['os_min']] ?? ('Windows ' . $t['os_min']);
    if ($os === null) $miss[] = spL('OS belum diisi', 'OS not filled in');
    elseif ($os['v'] === null) $miss[] = spL('OS tidak dikenali', 'OS not recognised');
    else {
        $osLow = $os['v'] < $t['os_min']; $edLow = $t['need_pro'] && !$os['pro'];
        if ($osLow || $edLow) {
            $fails[] = ($osLow ? $os['label'] . ' < ' . $osName : $os['label']) . ($edLow ? spL(' (bukan edisi Pro)', ' (not Pro edition)') : '');
            // Windows 11 butuh Intel gen 8+ / Ryzen 2000+: prosesor lebih lama -> ganti unit
            if ($osLow && $t['os_min'] >= 11 && $cpu && ($cpu['gen'] !== null ? $cpu['gen'] < 8 : in_array($cpu['cls'], ['celeron', 'pentium'], true))) $fix[] = 'replace';
            else $fix[] = $osLow ? spL('upgrade ke ', 'upgrade to ') . $osName . ($t['need_pro'] ? ' Pro' : '') : spL('upgrade lisensi ke Pro', 'upgrade licence to Pro');
        }
    }
    $status = $fails ? 'bad' : ($miss ? 'warn' : 'ok');
    $fix = array_values(array_unique($fix));
    $action = in_array('replace', $fix, true) ? spL('Ganti unit', 'Replace unit') : ($fix ? spL('Upgrade: ', 'Upgrade: ') . implode(', ', $fix) : '');
    $o = $a['ov'] ?? [];
    $auto = $status;
    if (!empty($o['status']) && in_array($o['status'], ['ok', 'bad', 'warn'], true)) $status = $o['status'];
    if ($status === 'ok' && $auto !== 'ok') $action = '';
    if (trim((string)($o['action_text'] ?? '')) !== '') $action = trim((string)$o['action_text']);
    $manual = false;
    foreach (['tier_id', 'cpu_cls', 'ram_gb', 'ssd', 'os_ver', 'status', 'action_text', 'note'] as $k) if (isset($o[$k]) && $o[$k] !== null && $o[$k] !== '') $manual = true;
    return ['tier' => $t, 'why' => $why, 'eff' => $e, 'fails' => $fails, 'miss' => $miss, 'status' => $status, 'auto_status' => $auto,
            'action' => $action, 'replace' => $action === spL('Ganti unit', 'Replace unit'), 'note' => trim((string)($o['note'] ?? '')), 'manual' => $manual];
}

function specStatusLabel(string $s): string
{
    return ['ok' => spL('Sesuai', 'Compliant'), 'bad' => spL('Di bawah standar', 'Below standard'), 'warn' => spL('Data belum lengkap', 'Incomplete data')][$s] ?? $s;
}

/** Ringkas 1 baris spesifikasi efektif. */
function specSpecLine(array $e): string
{
    $p = [];
    $p[] = $e['cpu'] ? $e['cpu']['label'] : '?';
    $p[] = $e['ram'] !== null ? $e['ram'] . ' GB' : 'RAM ?';
    $p[] = $e['ssd'] === null ? spL('Storage ?', 'Storage ?') : ($e['ssd'] ? 'SSD' : 'HDD');
    $p[] = $e['os'] && $e['os']['v'] !== null ? $e['os']['label'] : 'OS ?';
    if ($e['gpu']['text'] !== '' && $e['gpu']['has'] !== false) $p[] = $e['gpu']['text'];
    return implode(' · ', $p);
}

function specTierRule(array $t): string
{
    $r = specCpuShort($t['cpu_min']) . ' gen ' . $t['gen_min'] . '+, RAM ' . $t['ram_min'] . ' GB';
    if ($t['need_ssd']) $r .= ', SSD';
    if ($t['need_gpu']) $r .= ', VGA';
    $r .= ', ' . (specOsList()[$t['os_min']] ?? 'Windows ' . $t['os_min']) . ($t['need_pro'] ? ' Pro' : '');
    return $r;
}

/** Semua hasil: rows + ringkasan + per departemen. */
function specReport(PDO $db): array
{
    specEnsure($db);
    $tiers = specTiers($db);
    $rows = [];
    if ($tiers) foreach (specAssets($db) as $a) $rows[] = ['a' => $a, 'r' => specEvaluate($a, $tiers)];
    $sum = ['n' => count($rows), 'ok' => 0, 'bad' => 0, 'warn' => 0, 'replace' => 0];
    $dept = [];
    foreach ($rows as $x) {
        $s = $x['r']['status']; $sum[$s]++;
        if ($s === 'bad' && $x['r']['replace']) $sum['replace']++;
        $d = trim((string)$x['a']['department']) !== '' ? trim((string)$x['a']['department']) : '—';
        $dept[$d] = $dept[$d] ?? ['n' => 0, 'ok' => 0, 'bad' => 0, 'warn' => 0, 'replace' => 0, 'tiers' => []];
        $dept[$d]['n']++; $dept[$d][$s]++;
        if ($s === 'bad' && $x['r']['replace']) $dept[$d]['replace']++;
        $dept[$d]['tiers'][$x['r']['tier']['name']] = true;
    }
    ksort($dept, SORT_NATURAL | SORT_FLAG_CASE);
    $order = ['bad' => 0, 'warn' => 1, 'ok' => 2];
    usort($rows, fn($x, $y) => [$order[$x['r']['status']], (string)$x['a']['department'], (string)$x['a']['asset_number']]
                           <=> [$order[$y['r']['status']], (string)$y['a']['department'], (string)$y['a']['asset_number']]);
    return ['tiers' => $tiers, 'rows' => $rows, 'sum' => $sum, 'dept' => $dept];
}

/** Simpan koreksi manual 1 aset dari form Edit. Nilai yang sama dengan hasil baca otomatis tidak disimpan. */
function specSaveOverride(PDO $db, int $assetId, array $p, string $by): void
{
    $st = $db->prepare("SELECT id, processor, ram, storage, os_name FROM assets WHERE id = ?");
    $st->execute([$assetId]);
    $a = $st->fetch();
    if (!$a) return;
    $autoCpu = specParseCpu((string)$a['processor']); $autoRam = specParseRam((string)$a['ram']);
    $autoSsd = specParseSsd((string)$a['storage']);  $autoOs = specParseOs((string)$a['os_name']);
    $v = ['tier_id' => null, 'cpu_cls' => null, 'cpu_gen' => null, 'ram_gb' => null, 'ssd' => null, 'os_ver' => null, 'os_pro' => null, 'status' => null, 'action_text' => null, 'note' => null];
    if ((int)($p['tier_id'] ?? 0) > 0) $v['tier_id'] = (int)$p['tier_id'];
    $cls = (string)($p['cpu_cls'] ?? ''); $gen = trim((string)($p['cpu_gen'] ?? ''));
    if (isset(specCpuClasses()[$cls])) {
        $genV = $gen === '' ? null : max(1, min(30, (int)$gen));
        if (!$autoCpu || $autoCpu['cls'] !== $cls || $autoCpu['gen'] !== $genV) { $v['cpu_cls'] = $cls; $v['cpu_gen'] = $genV; }
    }
    $ram = trim((string)($p['ram_gb'] ?? ''));
    if ($ram !== '' && (int)$ram !== $autoRam) $v['ram_gb'] = max(1, min(1024, (int)$ram));
    $ssd = (string)($p['ssd'] ?? '');
    if ($ssd !== '' && ($ssd === '1') !== $autoSsd) $v['ssd'] = $ssd === '1' ? 1 : 0;
    $os = (int)($p['os_ver'] ?? 0); $pro = ($p['os_pro'] ?? '') === '1';
    if (isset(specOsList()[$os]) && (!$autoOs || $autoOs['v'] !== $os || $autoOs['pro'] !== $pro)) { $v['os_ver'] = $os; $v['os_pro'] = $pro ? 1 : 0; }
    if (in_array($p['status'] ?? '', ['ok', 'bad', 'warn'], true)) $v['status'] = $p['status'];
    $act = mb_substr(trim((string)($p['action_text'] ?? '')), 0, 255); if ($act !== '') $v['action_text'] = $act;
    $note = mb_substr(trim((string)($p['note'] ?? '')), 0, 255); if ($note !== '') $v['note'] = $note;

    if (array_key_exists('gpu', $p)) specSetGpu($db, $assetId, (string)$p['gpu']);   // isian VGA milik aset

    $db->prepare("DELETE FROM spec_overrides WHERE asset_id = ?")->execute([$assetId]);
    if (array_filter($v, fn($x) => $x !== null)) {
        $db->prepare("INSERT INTO spec_overrides (asset_id, tier_id, cpu_cls, cpu_gen, ram_gb, ssd, os_ver, os_pro, status, action_text, note, updated_by, updated_at)
                      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW())")
           ->execute([$assetId, $v['tier_id'], $v['cpu_cls'], $v['cpu_gen'], $v['ram_gb'], $v['ssd'], $v['os_ver'], $v['os_pro'], $v['status'], $v['action_text'], $v['note'], $by]);
    }
}

/** Aset yang VGA-nya terdeteksi di aksesoris tetapi isian VGA masih kosong (untuk tombol salin). */
function specGpuCopyCandidates(PDO $db): array
{
    specEnsure($db);
    $gpu = specGpuMap($db);
    $out = [];
    foreach ($db->query("SELECT id, asset_number, category, device_name, department, accessories, status FROM assets ORDER BY asset_number")->fetchAll() as $a) {
        if (!specIsPcCategory((string)$a['category']) || isset($gpu[(int)$a['id']])) continue;
        $f = specGpuFromAccessories((string)$a['accessories']);
        if ($f['text'] !== '') $out[] = $a + ['found' => $f['text'], 'unclear' => $f['unclear']];
    }
    return $out;
}
