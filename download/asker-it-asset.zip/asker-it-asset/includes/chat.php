<?php
/**
 * Chat Grup: pesan & foto antar user terdaftar, tersimpan TERENKRIPSI (AES-256-GCM) di server.
 *
 * Tabel baru (dibuat otomatis, CREATE TABLE IF NOT EXISTS; tabel lama tidak diubah):
 *   chat_groups    : grup (nama, semua user / anggota pilihan, grup pengumuman, pesan disematkan)
 *   chat_members   : anggota grup pilihan
 *   chat_messages  : pesan (isi & keterangan kartu terenkripsi), foto (file terenkripsi), balasan, sebut nama, hapus
 *   chat_reads     : pesan terakhir yang sudah dibaca tiap user per grup (angka belum dibaca & "dibaca oleh")
 *
 * Kunci enkripsi : includes/data/chat_key.php  -> WAJIB dicadangkan (menu Chat > Kelola grup > Unduh cadangan kunci).
 * File foto      : includes/data/chat_photos/TAHUN/BULAN/*.enc (terenkripsi, hanya dibuka lewat chat_photo.php).
 * Pengaturan     : includes/data/chat_settings.json (lama simpan foto, grup temuan CCTV, tanggal cadangan kunci).
 */

const CHAT_KEY_FILE      = __DIR__ . '/data/chat_key.php';
const CHAT_SETTINGS_FILE = __DIR__ . '/data/chat_settings.json';
const CHAT_PHOTO_DIR     = __DIR__ . '/data/chat_photos';
const CHAT_PHOTO_MAX     = 8388608;   // 8 MB per foto (setelah dikecilkan di HP biasanya < 500 KB)
const CHAT_DELETE_WINDOW = 3600;      // user boleh menghapus pesannya sendiri dalam 1 jam
const CHAT_COLORS        = ['#274fe6', '#0f766e', '#b45309', '#7c3aed', '#be123c', '#0369a1', '#4d7c0f'];

function chL(string $id, string $en): string
{
    return (function_exists('currentLang') && currentLang() === 'en') ? $en : $id;
}

function ensureChatTables(PDO $db): void
{
    static $done = false;
    if ($done) return;
    $sql = [
        "CREATE TABLE IF NOT EXISTS chat_groups (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            color TINYINT UNSIGNED NOT NULL DEFAULT 0,
            is_all TINYINT(1) NOT NULL DEFAULT 0,
            is_announce TINYINT(1) NOT NULL DEFAULT 0,
            pinned_msg_id INT UNSIGNED NULL,
            created_by INT UNSIGNED NULL,
            created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS chat_members (
            group_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            PRIMARY KEY (group_id, user_id),
            INDEX idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS chat_messages (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            group_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL DEFAULT 0,
            kind VARCHAR(10) NOT NULL DEFAULT 'msg',
            body MEDIUMTEXT NULL,
            reply_to INT UNSIGNED NULL,
            mentions VARCHAR(255) NULL,
            photo_path VARCHAR(255) NULL,
            photo_size INT UNSIGNED NULL,
            photo_orig INT UNSIGNED NULL,
            photo_purged TINYINT(1) NOT NULL DEFAULT 0,
            deleted_by INT UNSIGNED NULL,
            deleted_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            INDEX idx_group (group_id, id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS chat_reads (
            group_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            last_read_id INT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (group_id, user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    ];
    foreach ($sql as $q) {
        try { $db->exec($q); } catch (Throwable $e) { /* sudah ada */ }
    }
    // Grup awal "Semua Karyawan" (semua user terdaftar, grup pengumuman) dibuat sekali saja.
    try {
        if ((int)$db->query("SELECT COUNT(*) FROM chat_groups")->fetchColumn() === 0) {
            $db->prepare("INSERT INTO chat_groups (name, color, is_all, is_announce, created_at) VALUES (?, 1, 1, 1, ?)")
               ->execute([chL('Semua Karyawan', 'All Staff'), date('Y-m-d H:i:s')]);
        }
    } catch (Throwable $e) {}
    $done = true;
}

/* ================================================================== Pengaturan */

function chatSettings(): array
{
    $d = is_file(CHAT_SETTINGS_FILE) ? json_decode((string)file_get_contents(CHAT_SETTINGS_FILE), true) : null;
    return array_merge(['retention' => 90, 'cctv_group' => 0, 'key_backup_at' => '', 'last_cleanup' => ''], is_array($d) ? $d : []);
}

function chatSaveSettings(array $s): void
{
    @file_put_contents(CHAT_SETTINGS_FILE, json_encode(array_merge(chatSettings(), $s), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
}

/* ================================================================== Enkripsi */

/** Kunci 32 byte. Dibuat sekali; TIDAK dibuat ulang kalau sudah ada pesan (supaya kunci lama yang hilang ketahuan). */
function chatKey(PDO $db): string
{
    static $key = null;
    if ($key !== null) return $key;
    if (is_file(CHAT_KEY_FILE)) {
        $raw = base64_decode((string)(include CHAT_KEY_FILE), true);
        if (is_string($raw) && strlen($raw) === 32) return $key = $raw;
    }
    $has = 0;
    try { $has = (int)$db->query("SELECT COUNT(*) FROM chat_messages")->fetchColumn(); } catch (Throwable $e) {}
    if ($has > 0) throw new RuntimeException(chL(
        'Kunci enkripsi chat (includes/data/chat_key.php) tidak ditemukan. Kembalikan file cadangan kunci ke folder includes/data/.',
        'The chat encryption key (includes/data/chat_key.php) is missing. Restore the key backup file to includes/data/.'));
    $raw = random_bytes(32);
    $php = "<?php\n// Kunci enkripsi Chat Grup IT System. JANGAN dihapus/diubah. Simpan cadangannya di tempat terpisah.\n// Dibuat: " . date('Y-m-d H:i:s') . "\nreturn '" . base64_encode($raw) . "';\n";
    if (@file_put_contents(CHAT_KEY_FILE, $php, LOCK_EX) === false) throw new RuntimeException('Tidak bisa menulis ' . CHAT_KEY_FILE);
    return $key = $raw;
}

function chatEncrypt(PDO $db, string $plain): string
{
    $iv = random_bytes(12); $tag = '';
    $ct = openssl_encrypt($plain, 'aes-256-gcm', chatKey($db), OPENSSL_RAW_DATA, $iv, $tag);
    return 'v1:' . base64_encode($iv . $tag . $ct);
}

function chatDecrypt(PDO $db, ?string $data): ?string
{
    if ($data === null || $data === '') return null;
    if (strncmp($data, 'v1:', 3) !== 0) return null;
    $raw = base64_decode(substr($data, 3), true);
    if ($raw === false || strlen($raw) < 28) return null;
    $out = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', chatKey($db), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    return $out === false ? null : $out;
}

/* ================================================================== User & anggota */

/** Semua user aktif: [id => ['id','name','dept','admin']] */
function chatUsers(PDO $db): array
{
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = [];
    foreach ($db->query("SELECT id, full_name, department, role FROM users WHERE is_active = 1 ORDER BY full_name")->fetchAll() as $u) {
        $cache[(int)$u['id']] = ['id' => (int)$u['id'], 'name' => (string)$u['full_name'], 'dept' => (string)($u['department'] ?? ''), 'admin' => $u['role'] === 'admin'];
    }
    return $cache;
}

function chatGroups(PDO $db): array
{
    $out = [];
    foreach ($db->query("SELECT * FROM chat_groups ORDER BY name")->fetchAll() as $g) $out[(int)$g['id']] = $g;
    return $out;
}

/** Id anggota aktif sebuah grup. User nonaktif otomatis tidak ikut. */
function chatMemberIds(PDO $db, array $g): array
{
    $users = chatUsers($db);
    if ((int)$g['is_all'] === 1) return array_keys($users);
    $st = $db->prepare("SELECT user_id FROM chat_members WHERE group_id = ?");
    $st->execute([(int)$g['id']]);
    return array_values(array_filter(array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)), fn($id) => isset($users[$id])));
}

/** Grup yang diikuti user: [id => row] */
function chatMyGroups(PDO $db, int $uid): array
{
    $users = chatUsers($db);
    if (!isset($users[$uid])) return [];
    $st = $db->prepare("SELECT group_id FROM chat_members WHERE user_id = ?");
    $st->execute([$uid]);
    $mine = array_flip(array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)));
    return array_filter(chatGroups($db), fn($g) => (int)$g['is_all'] === 1 || isset($mine[(int)$g['id']]));
}

function chatCanWrite(array $g): bool
{
    return (int)$g['is_announce'] !== 1 || isAdmin();
}

/* ================================================================== Pesan */

/** Simpan pesan. $card = ['type','ref','title','sub','url'] atau null. $photo = ['path','size','orig'] atau null. Return id. */
function chatPost(PDO $db, int $groupId, int $userId, string $text, ?array $card = null, ?array $photo = null, int $replyTo = 0, string $kind = 'msg'): int
{
    ensureChatTables($db);
    $mentions = '';
    $ids = [];
    if ($text !== '' && preg_match_all('/@([\p{L}\p{N}_]+)/u', $text, $m)) {
        $g = chatGroups($db)[$groupId] ?? null;
        $users = chatUsers($db);
        $ids = [];
        if ($g) foreach (chatMemberIds($db, $g) as $id) {
            $first = mb_strtolower(preg_split('/\s+/', trim($users[$id]['name']))[0] ?? '');
            foreach ($m[1] as $n) if ($first !== '' && mb_strtolower($n) === $first) $ids[$id] = $id;
        }
        if ($ids) $mentions = ',' . implode(',', $ids) . ',';
    }
    $body = chatEncrypt($db, json_encode(['t' => $text, 'c' => $card], JSON_UNESCAPED_UNICODE));
    $db->prepare("INSERT INTO chat_messages (group_id, user_id, kind, body, reply_to, mentions, photo_path, photo_size, photo_orig, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
       ->execute([$groupId, $userId, $kind, $body, $replyTo ?: null, $mentions ?: null, $photo['path'] ?? null, $photo['size'] ?? null, $photo['orig'] ?? null, date('Y-m-d H:i:s')]);
    $id = (int)$db->lastInsertId();
    if ($userId > 0) chatMarkRead($db, $groupId, $userId, $id);
    // Pusat Notifikasi: tanpa isi pesan (isi chat tetap hanya tersimpan terenkripsi).
    try {
        if (is_file(__DIR__ . '/notifications.php')) {
            require_once __DIR__ . '/notifications.php';
            $g = chatGroups($db)[$groupId] ?? null;
            if ($g) {
                $users = chatUsers($db);
                $sender = $userId > 0 ? (string)($users[$userId]['name'] ?? 'User') : 'IT System';
                notifChatMessage($db, $g, chatMemberIds($db, $g), $userId, $sender, array_values($ids), $id);
            }
        }
    } catch (Throwable $e) {}
    return $id;
}

/** Simpan file foto (bytes) terenkripsi. Return ['path','size','orig'] atau null. */
function chatStorePhotoBytes(PDO $db, string $bytes, int $orig = 0): ?array
{
    if ($bytes === '' || strlen($bytes) > CHAT_PHOTO_MAX) return null;
    $info = @getimagesizefromstring($bytes);
    if (!$info || !in_array($info['mime'] ?? '', ['image/jpeg', 'image/png', 'image/webp'], true)) return null;
    $sub = date('Y/m');
    $dir = CHAT_PHOTO_DIR . '/' . $sub;
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return null;
    $name = bin2hex(random_bytes(12)) . '.enc';
    $enc = chatEncrypt($db, $info['mime'] . "\n" . $bytes);
    if (@file_put_contents($dir . '/' . $name, $enc, LOCK_EX) === false) return null;
    return ['path' => $sub . '/' . $name, 'size' => strlen($bytes), 'orig' => $orig ?: strlen($bytes)];
}

function chatMarkRead(PDO $db, int $groupId, int $userId, int $lastId): void
{
    // Grup dibuka/dibaca: notifikasi chat grup ini di Pusat Notifikasi ikut ditandai dibaca.
    if (is_file(__DIR__ . '/notifications.php')) {
        require_once __DIR__ . '/notifications.php';
        notifMarkReadRef($db, $userId, ['chat_msg', 'chat_announce', 'chat_mention'], $groupId);
    }
    try {
        $st = $db->prepare("UPDATE chat_reads SET last_read_id = ? WHERE group_id = ? AND user_id = ? AND last_read_id < ?");
        $st->execute([$lastId, $groupId, $userId, $lastId]);
        if ($st->rowCount() === 0) {
            $chk = $db->prepare("SELECT 1 FROM chat_reads WHERE group_id = ? AND user_id = ?");
            $chk->execute([$groupId, $userId]);
            if (!$chk->fetchColumn()) $db->prepare("INSERT INTO chat_reads (group_id, user_id, last_read_id) VALUES (?, ?, ?)")->execute([$groupId, $userId, $lastId]);
        }
    } catch (Throwable $e) {}
}

/** Ringkasan grup untuk user: belum dibaca, disebut, pesan terakhir. */
function chatSummary(PDO $db, int $uid): array
{
    $groups = chatMyGroups($db, $uid);
    if (!$groups) return [];
    $ids = array_keys($groups);
    $in = implode(',', array_map('intval', $ids));
    $reads = [];
    $st = $db->prepare("SELECT group_id, last_read_id FROM chat_reads WHERE user_id = ? AND group_id IN ($in)");
    $st->execute([$uid]);
    foreach ($st->fetchAll() as $r) $reads[(int)$r['group_id']] = (int)$r['last_read_id'];
    $out = [];
    $last = $db->prepare("SELECT * FROM chat_messages WHERE group_id = ? ORDER BY id DESC LIMIT 1");
    $cnt  = $db->prepare("SELECT COUNT(*) AS n, MAX(id) AS mx, SUM(CASE WHEN mentions LIKE ? THEN 1 ELSE 0 END) AS at FROM chat_messages WHERE group_id = ? AND id > ? AND user_id <> ? AND deleted_by IS NULL");
    $users = chatUsers($db);
    foreach ($groups as $gid => $g) {
        $last->execute([$gid]);
        $lm = $last->fetch();
        $cnt->execute(['%,' . $uid . ',%', $gid, $reads[$gid] ?? 0, $uid]);
        $c = $cnt->fetch();
        $out[] = [
            'id' => $gid, 'name' => (string)$g['name'], 'color' => CHAT_COLORS[(int)$g['color'] % count(CHAT_COLORS)],
            'all' => (int)$g['is_all'] === 1, 'announce' => (int)$g['is_announce'] === 1,
            'unread' => (int)($c['n'] ?? 0), 'mention' => (int)($c['at'] ?? 0) > 0,
            'last_at' => $lm ? (string)$lm['created_at'] : '', 'last_id' => $lm ? (int)$lm['id'] : 0,
            'last' => $lm ? chatSnippet($db, $lm, $uid, $users) : '',
        ];
    }
    usort($out, fn($a, $b) => strcmp($b['last_at'], $a['last_at']) ?: strcmp($a['name'], $b['name']));
    return $out;
}

function chatSnippet(PDO $db, array $m, int $uid, array $users): string
{
    if ($m['deleted_by']) return chL('Pesan ini dihapus', 'This message was deleted');
    $b = json_decode((string)chatDecrypt($db, $m['body']), true) ?: [];
    $who = (int)$m['user_id'] === $uid ? chL('Anda', 'You') : ((int)$m['user_id'] === 0 ? 'IT System' : (preg_split('/\s+/', $users[(int)$m['user_id']]['name'] ?? '?')[0]));
    if ($m['kind'] === 'sys') return (string)($b['t'] ?? '');
    $t = !empty($b['c']) ? (($b['c']['type'] ?? '') === 'temuan' ? '⚠ ' : '🔗 ') . ($b['c']['title'] ?? '') : '';
    if ($m['photo_path'] || $m['photo_purged']) $t = '📷 ' . chL('Foto', 'Photo') . ($t !== '' ? ' · ' . $t : '');
    $txt = (string)($b['t'] ?? '');
    $t = trim($t . ($t !== '' && $txt !== '' ? ' · ' : '') . $txt);
    return $who . ': ' . mb_strimwidth($t, 0, 90, '…');
}

/** Bentuk pesan untuk browser (sudah didekripsi). */
function chatMessageOut(PDO $db, array $m, array $users): array
{
    $uid = (int)$m['user_id'];
    $o = ['id' => (int)$m['id'], 'u' => $uid, 'kind' => $m['kind'], 'at' => (string)$m['created_at'],
          'name' => $uid === 0 ? 'IT System' : ($users[$uid]['name'] ?? chL('(user nonaktif)', '(inactive user)')),
          'dept' => $uid === 0 ? chL('otomatis', 'automatic') : ($users[$uid]['dept'] ?? ''),
          'color' => $uid === 0 ? '#475569' : CHAT_COLORS[$uid % count(CHAT_COLORS)],
          'reply' => (int)($m['reply_to'] ?? 0), 'deleted' => $m['deleted_by'] ? ((int)$m['deleted_by'] === $uid ? 'self' : 'admin') : ''];
    if (!$m['deleted_by']) {
        $b = json_decode((string)chatDecrypt($db, $m['body']), true);
        $o['text'] = is_array($b) ? (string)($b['t'] ?? '') : chL('[pesan tidak bisa dibuka: kunci enkripsi berbeda]', '[cannot decrypt: different key]');
        $o['card'] = is_array($b) ? ($b['c'] ?? null) : null;
        $o['photo'] = $m['photo_path'] ? 'chat_photo.php?id=' . (int)$m['id'] : '';
        $o['purged'] = (int)$m['photo_purged'] === 1;
        $o['size'] = (int)($m['photo_size'] ?? 0);
        $o['orig'] = (int)($m['photo_orig'] ?? 0);
    }
    return $o;
}

/** Hapus foto lama (lebih dari N hari) sekali sehari. Teks pesan tetap ada. */
function chatCleanup(PDO $db): void
{
    $s = chatSettings();
    if ($s['last_cleanup'] === date('Y-m-d')) return;
    chatSaveSettings(['last_cleanup' => date('Y-m-d')]);
    $lim = date('Y-m-d H:i:s', time() - max(7, (int)$s['retention']) * 86400);
    $st = $db->prepare("SELECT id, photo_path FROM chat_messages WHERE photo_path IS NOT NULL AND created_at < ? LIMIT 2000");
    $st->execute([$lim]);
    $upd = $db->prepare("UPDATE chat_messages SET photo_path = NULL, photo_purged = 1 WHERE id = ?");
    foreach ($st->fetchAll() as $r) {
        $f = CHAT_PHOTO_DIR . '/' . $r['photo_path'];
        if (strpos((string)$r['photo_path'], '..') === false && is_file($f)) @unlink($f);
        $upd->execute([(int)$r['id']]);
    }
}

/** Statistik penyimpanan untuk admin. */
function chatStats(PDO $db): array
{
    $r = $db->query("SELECT COUNT(*) AS n, SUM(CASE WHEN photo_path IS NOT NULL THEN 1 ELSE 0 END) AS p, SUM(CASE WHEN photo_path IS NOT NULL THEN photo_size ELSE 0 END) AS ps, SUM(LENGTH(body)) AS tb FROM chat_messages")->fetch();
    return ['messages' => (int)$r['n'], 'photos' => (int)$r['p'], 'photo_bytes' => (int)$r['ps'], 'text_bytes' => (int)$r['tb']];
}

/* ================================================================== Integrasi */

/** Temuan checklist CCTV -> kartu di grup yang dipilih admin (Kelola grup > Grup untuk temuan CCTV). */
function chatPostCctvFindings(PDO $db, array $findings, string $who, string $shift, string $date): void
{
    try {
        ensureChatTables($db);
        $gid = (int)chatSettings()['cctv_group'];
        if ($gid <= 0 || !isset(chatGroups($db)[$gid]) || !$findings) return;
        $sub = 'Checklist ' . $shift . ' ' . date('d/m/Y', strtotime($date)) . ' · ' . $who;
        if (count($findings) > 5) {
            $lines = array_map(fn($f) => '• ' . $f['title'], $findings);
            chatPost($db, $gid, 0, chL(count($findings) . ' temuan baru dari checklist:', count($findings) . ' new checklist findings:') . "\n" . implode("\n", $lines),
                ['type' => 'temuan', 'ref' => $sub, 'title' => chL('Temuan checklist CCTV', 'CCTV checklist findings'), 'sub' => chL('Semua masuk ke Laporan petugas', 'All added to officer reports'), 'url' => 'cctv_lapor.php']);
            return;
        }
        foreach ($findings as $f) {
            $photo = null;
            if (!empty($f['photo_file']) && is_file($f['photo_file'])) $photo = chatStorePhotoBytes($db, (string)file_get_contents($f['photo_file']));
            chatPost($db, $gid, 0, '', ['type' => 'temuan', 'ref' => $sub, 'title' => $f['title'], 'sub' => chL('Masuk ke Laporan petugas', 'Added to officer reports'), 'url' => 'cctv_lapor.php'], $photo);
        }
    } catch (Throwable $e) {
        // chat hanya pelengkap: checklist tetap tersimpan
    }
}
