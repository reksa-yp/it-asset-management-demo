<?php
/**
 * Jendela Scan QR aset (scanner USB / ketik nomor aset / kamera) + scriptnya.
 * Dipakai oleh assets.php dan dashboard.php. Tombol pemanggil: onclick="startScanQr()".
 *  - Di dalam aplikasi Android (versi 2.1+): langsung membuka kamera aplikasi.
 *  - Di browser: membuka jendela ini (scanner USB; kamera hanya lewat HTTPS).
 */
?>
<!-- ===== Modal Scan QR aset (scanner USB / ketik manual / kamera) ===== -->
<div id="scanModal" class="hidden fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-md">
        <div class="flex items-center justify-between px-5 py-4 border-b">
            <h3 class="font-semibold text-slate-800"><?= t('scan_title') ?></h3>
            <button type="button" onclick="closeScanModal()" class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button>
        </div>
        <form action="scan.php" method="get" class="px-5 py-4 space-y-3 text-sm" onsubmit="stopScanCamera()">
            <p class="text-slate-500"><?= t('scan_modal_hint') ?></p>
            <div class="flex gap-2">
                <input type="text" name="q" id="scanInput" autocomplete="off" required placeholder="<?= htmlspecialchars(t('scan_input_ph')) ?>"
                       class="flex-1 min-w-0 border border-slate-300 rounded-lg px-3 py-2 font-mono">
                <button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium"><?= t('btn_search') ?></button>
            </div>
            <button type="button" id="scanCamBtn" onclick="toggleScanCamera()" class="w-full border border-slate-300 hover:bg-slate-50 rounded-lg px-4 py-2 font-medium text-slate-700"><?= t('scan_camera_btn') ?></button>
            <video id="scanVideo" class="hidden w-full rounded-lg bg-black" playsinline muted></video>
            <p id="scanCamMsg" class="hidden text-xs bg-amber-50 text-amber-800 rounded-lg px-3 py-2"></p>
        </form>
    </div>
</div>
<script>
const SCAN_T = <?= json_encode([
    'cam' => t('scan_camera_btn'), 'stop' => t('scan_camera_stop'), 'https' => t('scan_camera_need_https'),
    'error' => t('scan_camera_error'), 'unsupported' => t('scan_camera_unsupported'),
], JSON_UNESCAPED_UNICODE) ?>;
let scanStream = null, scanTimer = null;
function openScanModal() {
    document.getElementById('scanModal').classList.remove('hidden');
    const i = document.getElementById('scanInput'); i.value = ''; setTimeout(() => i.focus(), 50);
}
function closeScanModal() { stopScanCamera(); document.getElementById('scanModal').classList.add('hidden'); }
function scanMsg(text) {
    const el = document.getElementById('scanCamMsg');
    el.textContent = text || ''; el.classList.toggle('hidden', !text);
}
function stopScanCamera() {
    if (scanTimer) { clearInterval(scanTimer); scanTimer = null; }
    if (scanStream) { scanStream.getTracks().forEach(t => t.stop()); scanStream = null; }
    document.getElementById('scanVideo').classList.add('hidden');
    document.getElementById('scanCamBtn').textContent = SCAN_T.cam;
}
function scanGo(text) {
    stopScanCamera();
    window.location.href = 'scan.php?q=' + encodeURIComponent(text);
}
/** Pembaca QR: BarcodeDetector bawaan browser; kalau tidak ada, pustaka jsQR dimuat dari CDN. */
function loadJsQR() {
    return new Promise((resolve, reject) => {
        if (window.jsQR) return resolve();
        const s = document.createElement('script');
        s.src = 'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js';
        s.onload = resolve; s.onerror = reject;
        document.head.appendChild(s);
    });
}
async function toggleScanCamera() {
    // Di dalam aplikasi Android: pakai kamera aplikasi (tidak butuh HTTPS).
    if (window.TMNNApp && TMNNApp.scan) { closeScanModal(); TMNNApp.scan(); return; }
    if (scanStream) { stopScanCamera(); return; }
    scanMsg('');
    // Browser hanya mengizinkan kamera di HTTPS (atau localhost).
    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { scanMsg(SCAN_T.https); return; }
    let detector = null;
    try {
        if ('BarcodeDetector' in window) detector = new BarcodeDetector({ formats: ['qr_code'] });
        else await loadJsQR();
    } catch (e) { scanMsg(SCAN_T.unsupported); return; }
    const video = document.getElementById('scanVideo');
    try {
        scanStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
    } catch (e) { scanStream = null; scanMsg(SCAN_T.error); return; }
    video.srcObject = scanStream;
    video.classList.remove('hidden');
    document.getElementById('scanCamBtn').textContent = SCAN_T.stop;
    await video.play();
    const canvas = document.createElement('canvas'), ctx = canvas.getContext('2d', { willReadFrequently: true });
    let busy = false;
    scanTimer = setInterval(async () => {
        if (busy || !scanStream || video.readyState < 2 || !video.videoWidth) return;
        busy = true;
        try {
            let text = '';
            if (detector) {
                const codes = await detector.detect(video);
                if (codes.length) text = codes[0].rawValue || '';
            } else {
                canvas.width = video.videoWidth; canvas.height = video.videoHeight;
                ctx.drawImage(video, 0, 0);
                const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
                const code = window.jsQR(img.data, img.width, img.height);
                if (code) text = code.data || '';
            }
            if (text) scanGo(text);
        } catch (e) { /* frame belum siap: coba lagi di putaran berikutnya */ }
        busy = false;
    }, 250);
}
</script>
<script>
function startScanQr() {
    if (window.TMNNApp && TMNNApp.scan) { TMNNApp.scan(); return; }
    openScanModal();
}
</script>
