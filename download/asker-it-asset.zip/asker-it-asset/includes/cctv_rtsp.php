<?php
/**
 * Live preview CCTV lewat RTSP sub-stream (ffmpeg di server).
 *   Hikvision : rtsp://user:pass@IP:554/Streaming/Channels/{ch}02   (cadangan firmware lama: /h264/ch{ch}/sub/av_stream)
 *   Dahua     : rtsp://user:pass@IP:554/cam/realmonitor?channel={ch}&subtype=1
 * RTSP adalah layanan terpisah dari web NVR, jadi tetap jalan walau halaman web NVR sedang bermasalah.
 * Butuh ffmpeg.exe di server (mis. C:\xampp\ffmpeg\bin\ffmpeg.exe), versi 5 atau lebih baru.
 * Port RTSP per NVR disimpan di pengaturan CCTV (rtsp_port), tanpa mengubah tabel database.
 */
require_once __DIR__ . '/cctv.php';

/** Lokasi ffmpeg: dari Pengaturan, lalu lokasi umum di Windows/XAMPP, lalu PATH. '' = tidak ditemukan. */
function cctvFfmpegPath(): string
{
    static $found = null;
    if ($found !== null) return $found;
    $set = trim((string)(cctvSettings()['ffmpeg_path'] ?? ''));
    $root = dirname(__DIR__);
    $cands = array_filter([
        $set,
        'C:\\xampp\\ffmpeg\\bin\\ffmpeg.exe', 'C:\\xampp\\ffmpeg\\ffmpeg.exe', 'C:\\ffmpeg\\bin\\ffmpeg.exe', 'C:\\ffmpeg\\ffmpeg.exe',
        $root . '/tools/ffmpeg/bin/ffmpeg.exe', $root . '/tools/ffmpeg/ffmpeg.exe',
        '/usr/bin/ffmpeg', '/usr/local/bin/ffmpeg',
    ]);
    foreach ($cands as $p) if (@is_file($p)) return $found = $p;
    // Hasil ekstrak ZIP biasanya ada di subfolder, mis. C:\xampp\ffmpeg\ffmpeg-8.0-essentials_build\bin\ffmpeg.exe
    foreach (['C:/xampp/ffmpeg/*/bin/ffmpeg.exe', 'C:/xampp/*/bin/ffmpeg.exe', 'C:/ffmpeg/*/bin/ffmpeg.exe', $root . '/tools/ffmpeg/*/bin/ffmpeg.exe'] as $pat) {
        foreach ((array)@glob($pat) as $p) if (@is_file($p)) return $found = $p;
    }
    // Terakhir: ffmpeg yang ada di PATH Windows/Linux.
    $out = cctvRunProc(['ffmpeg', '-hide_banner', '-version'], 5, $err, $code);
    return $found = ($code === 0 && stripos($out, 'ffmpeg version') !== false) ? 'ffmpeg' : '';
}

/** Versi ffmpeg (baris pertama), untuk ditampilkan di Pengaturan. */
function cctvFfmpegVersion(string $bin): string
{
    if ($bin === '') return '';
    $out = cctvRunProc([$bin, '-hide_banner', '-version'], 5, $err, $code);
    return preg_match('/ffmpeg version (\S+)/', $out, $m) ? $m[1] : '';
}

/**
 * Jalankan program tanpa shell. stdout & stderr lewat file sementara (pipe non-blocking tidak didukung PHP di Windows).
 * Proses dihentikan bila melewati $timeout detik. Return isi stdout; $err = stderr; $code = exit code (-1 = timeout/gagal).
 */
function cctvRunProc(array $cmd, int $timeout, ?string &$err = null, ?int &$code = null): string
{
    $err = ''; $code = -1;
    if (!function_exists('proc_open')) { $err = 'proc_open dinonaktifkan di php.ini'; return ''; }
    $tmp = sys_get_temp_dir();
    $fo = tempnam($tmp, 'cco'); $fe = tempnam($tmp, 'cce');
    $p = @proc_open($cmd, [0 => ['pipe', 'r'], 1 => ['file', $fo, 'w'], 2 => ['file', $fe, 'w']], $pipes, null, null, ['bypass_shell' => true]);
    if (!is_resource($p)) { @unlink($fo); @unlink($fe); $err = 'Program tidak bisa dijalankan'; return ''; }
    fclose($pipes[0]);
    $end = microtime(true) + $timeout;
    do {
        $st = proc_get_status($p);
        if (!$st['running']) { $code = (int)$st['exitcode']; break; }
        usleep(50000);
    } while (microtime(true) < $end);
    if ($st['running']) { proc_terminate($p); $code = -1; $err = 'timeout'; }
    proc_close($p);
    $out = (string)@file_get_contents($fo);
    $err = trim($err . ' ' . (string)@file_get_contents($fe));
    @unlink($fo); @unlink($fe);
    return $out;
}

/** Port RTSP NVR (pengaturan per NVR, bawaan 554). */
function cctvRtspPort(array $nvr): int
{
    $ports = (array)(cctvSettings()['rtsp_port'] ?? []);
    $p = (int)($ports[(string)(int)$nvr['id']] ?? 0);
    return $p > 0 && $p < 65536 ? $p : 554;
}

/** Alamat RTSP sub-stream. $fmt: 'std' (format sekarang) atau 'old' (firmware Hikvision lama). $mask = sembunyikan password. */
function cctvRtspUrl(array $nvr, int $ch, string $fmt = 'std', bool $mask = false): string
{
    $tpl = cctvNvrConn($nvr)['rtsp_tpl'];
    if ($tpl !== '') return cctvFillTemplate($tpl, $nvr, $ch, cctvRtspPort($nvr), $mask);   // alamat RTSP manual (merek apa pun)
    $auth = rawurlencode((string)$nvr['username']) . ':' . ($mask ? '****' : rawurlencode((string)$nvr['password'])) . '@';
    $base = 'rtsp://' . ((string)$nvr['username'] !== '' ? $auth : '') . cctvNvrHost($nvr) . ':' . cctvRtspPort($nvr);
    if (strtolower((string)$nvr['brand']) === 'dahua') return $base . '/cam/realmonitor?channel=' . $ch . '&subtype=1';
    return $fmt === 'old' ? $base . '/h264/ch' . $ch . '/sub/av_stream' : $base . '/Streaming/Channels/' . $ch . '02';
}

/** Ubah pesan error ffmpeg menjadi kalimat yang mudah dipahami. */
function cctvRtspError(string $stderr, int $code): string
{
    $e = strtolower($stderr);
    if ($code === -1 && strpos($e, 'timeout') !== false && strpos($e, 'rtsp') === false) return cL('NVR tidak mengirim gambar (timeout)', 'No picture from NVR (timeout)');
    if (strpos($e, '401') !== false || strpos($e, 'unauthorized') !== false) return cL('Login RTSP ditolak (cek user/password NVR)', 'RTSP login rejected (check NVR user/password)');
    if (strpos($e, '404') !== false || strpos($e, 'not found') !== false) return cL('Channel tidak ditemukan di NVR (RTSP 404)', 'Channel not found on NVR (RTSP 404)');
    if (strpos($e, 'connection refused') !== false) return cL('Port RTSP ditolak (cek port RTSP NVR)', 'RTSP port refused (check NVR RTSP port)');
    if (strpos($e, 'timed out') !== false || strpos($e, 'timeout') !== false) return cL('NVR tidak merespons RTSP (timeout)', 'NVR RTSP not responding (timeout)');
    if (strpos($e, '503') !== false || strpos($e, '453') !== false) return cL('NVR sibuk / sesi RTSP penuh', 'NVR busy / RTSP sessions full');
    if (strpos($e, 'option timeout not found') !== false || strpos($e, 'unrecognized option') !== false) return cL('Versi ffmpeg terlalu lama (butuh versi 5 ke atas)', 'ffmpeg too old (need version 5+)');
    $last = trim((string)preg_replace('/\s+/', ' ', mb_substr($stderr, -160)));
    return cL('Gagal membuka RTSP', 'RTSP failed') . ($last !== '' ? ': ' . $last : '');
}

/** Argumen ffmpeg bersama untuk membuka RTSP (TCP, timeout 5 detik, buffer kecil agar cepat). */
function cctvRtspInputArgs(string $url): array
{
    return ['-hide_banner', '-loglevel', 'error', '-rtsp_transport', 'tcp', '-timeout', '5000000',
            '-analyzeduration', '1000000', '-probesize', '1000000', '-fflags', 'nobuffer', '-i', $url];
}

/**
 * Ambil 1 frame JPEG dari sub-stream. Return bytes atau ''; $err = pesan bila gagal.
 * Format URL yang berhasil diingat per NVR (std/old) di $prefFile.
 */
function cctvRtspFrame(array $nvr, int $ch, ?string &$err = null, int $width = 480, string $prefFile = ''): string
{
    $err = '';
    $bin = cctvFfmpegPath();
    if ($bin === '') { $err = cL('ffmpeg belum terpasang di server (lihat CCTV > Pengaturan > 1)', 'ffmpeg is not installed on the server'); return ''; }
    if ($ch < 1) { $err = 'Channel?'; return ''; }
    $pref = $prefFile !== '' && is_file($prefFile) ? (json_decode((string)@file_get_contents($prefFile), true) ?: []) : [];
    $key  = 'rtsp_' . (int)$nvr['id'];
    $fmts = (strtolower((string)$nvr['brand']) !== 'hikvision' || cctvNvrConn($nvr)['rtsp_tpl'] !== '') ? ['std'] : (($pref[$key] ?? '') === 'old' ? ['old', 'std'] : ['std', 'old']);
    foreach ($fmts as $i => $fmt) {
        $out = cctvRunProc(array_merge([$bin], cctvRtspInputArgs(cctvRtspUrl($nvr, $ch, $fmt)),
            ['-frames:v', '1', '-vf', 'scale=' . $width . ':-2', '-q:v', '5', '-f', 'image2', '-vcodec', 'mjpeg', 'pipe:1']), 12, $se, $code);
        if ($out !== '' && strncmp($out, "\xFF\xD8", 2) === 0) {
            if ($prefFile !== '' && ($pref[$key] ?? 'std') !== $fmt) { $pref[$key] = $fmt; @file_put_contents($prefFile, json_encode($pref), LOCK_EX); }
            return $out;
        }
        $err = cctvRtspError($se, $code);
        // Format lama hanya dicoba bila format sekarang ditolak sebagai "tidak ditemukan".
        if ($i === 0 && stripos($se, '404') === false && stripos($se, 'not found') === false) break;
    }
    return '';
}

/** Live view memakai video RTSP (ffmpeg) untuk NVR ini? Selain itu memakai snapshot HTTP yang diperbarui berkala. */
function cctvLiveUsesVideo(array $nvr): bool
{
    return cctvNvrConn($nvr)['live'] !== 'snap' && cctvRtspAllowed($nvr) && cctvFfmpegPath() !== '';
}

/** Kamera di NVR ini bisa ditampilkan (video RTSP atau snapshot)? */
function cctvLiveAvailable(array $nvr): bool
{
    return (int)($nvr['is_active'] ?? 1) === 1 && (cctvLiveUsesVideo($nvr) || cctvSnapAllowed($nvr));
}

/**
 * 1 gambar JPEG untuk live preview: RTSP (bila ffmpeg ada & diizinkan), lalu cadangan snapshot HTTP
 * (tanpa ffmpeg, jalan di hosting, Cloudflare Tunnel & Agen Kantor). Return bytes atau ''; $err = pesan.
 * $wait = detik menunggu Agen Kantor.
 */
function cctvLiveFrame(array $nvr, int $ch, ?string &$err = null, int $width = 480, string $prefFile = '', int $wait = 0): string
{
    require_once __DIR__ . '/cctv_snapshot.php';
    $err = '';
    $rtspErr = '';
    if (cctvLiveUsesVideo($nvr)) {
        $jpg = cctvRtspFrame($nvr, $ch, $rtspErr, $width, $prefFile);
        if ($jpg !== '') return $jpg;
    }
    if (!cctvSnapAllowed($nvr)) {
        $err = $rtspErr !== '' ? $rtspErr : (cctvNvrUnreachable($nvr)
            ? cL('IP lokal NVR tidak bisa dijangkau dari hosting (ubah Cara terhubung)', 'NVR local IP is unreachable from hosting')
            : cL('Isi alamat snapshot / RTSP manual untuk merek ini di Pengaturan', 'Set a manual snapshot / RTSP address for this brand'));
        return '';
    }
    $pref = $prefFile !== '' && is_file($prefFile) ? (json_decode((string)@file_get_contents($prefFile), true) ?: []) : [];
    $key = 'snap_' . (int)$nvr['id'];
    $jpg = cctvSnapshotFetch($nvr, $ch, $code, 6, (int)($pref[$key] ?? 0), $okIdx, $width <= 480 ? 20 : 2, $wait);
    if ($jpg !== '') {
        if ($prefFile !== '' && $okIdx !== null && (int)($pref[$key] ?? 0) !== $okIdx) { $pref[$key] = $okIdx; @file_put_contents($prefFile, json_encode($pref), LOCK_EX); }
        return cctvSnapshotResize($jpg, $width, (int)round($width * 0.75));
    }
    $err = $code === -1 ? cL('Menunggu gambar dari Agen Kantor…', 'Waiting for the Office Agent…')
        : ($code === 0 ? cL('NVR tidak terjangkau', 'NVR unreachable')
        : ($code === 401 ? cL('Login NVR ditolak (cek user/password)', 'NVR login rejected')
        : cL('Snapshot gagal (HTTP ', 'Snapshot failed (HTTP ') . $code . ')'));
    if ($rtspErr !== '') $err = $rtspErr . ' · ' . $err;
    return '';
}
