<?php
/**
 * Kolom nomor urut ("No") di kolom paling kiri file Export Excel.
 *
 * Dipanggil SETELAH sheet selesai diisi & diberi gaya, tepat sebelum file disimpan:
 *     xlsAddNumberColumn($sheet, $barisHeader, $barisDataTerakhir);
 * Kolom A baru disisipkan; isi, rumus (mis. SUM), lebar kolom, dan sel gabungan lain ikut bergeser
 * ke kanan secara otomatis. Baris judul di atas header tetap mulai dari kolom A.
 *
 * Aman untuk file yang di-import lagi: semua import di sistem ini mengenali kolom dari JUDUL
 * kolomnya, bukan dari posisinya, jadi kolom "No" diabaikan saat import.
 */

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

/**
 * @param int      $headerRow   baris judul kolom (mis. 1 atau 4)
 * @param int|null $lastDataRow baris data terakhir yang diberi nomor; null = sampai baris terisi terakhir.
 *                              Baris setelahnya (mis. baris Total) tidak diberi nomor.
 */
function xlsAddNumberColumn(Worksheet $sheet, int $headerRow = 1, ?int $lastDataRow = null, string $label = 'No'): void
{
    $highestRow = $sheet->getHighestDataRow();
    if ($lastDataRow === null) $lastDataRow = $highestRow;
    $freeze = $sheet->getFreezePane();

    $sheet->insertNewColumnBefore('A', 1);

    // Baris judul di atas header (nama laporan, periode): kembalikan supaya mulai dari kolom A.
    foreach ($sheet->getMergeCells() as $range) {
        [$start, $end] = Coordinate::rangeBoundaries($range);
        if ($start[1] >= $headerRow || $start[0] !== 2) continue;
        $sheet->unmergeCells($range);
        $from = 'B' . $start[1];
        $to   = 'A' . $start[1];
        $sheet->duplicateStyle($sheet->getStyle($from), $to);
        $sheet->setCellValue($to, $sheet->getCell($from)->getValue());
        $sheet->setCellValue($from, null);
        $sheet->mergeCells($to . ':' . Coordinate::stringFromColumnIndex($end[0]) . $end[1]);
    }
    for ($r = 1; $r < $headerRow; $r++) {
        $b = $sheet->getCell('B' . $r);
        if ($b->getValue() !== null && $b->getValue() !== '' && !$b->isInMergeRange()) {
            $sheet->duplicateStyle($sheet->getStyle('B' . $r), 'A' . $r);
            $sheet->setCellValue('A' . $r, $b->getValue());
            $b->setValue(null);
        }
    }

    // Gaya kolom No mengikuti kolom di sebelahnya (warna header, garis tepi, baris Total).
    for ($r = $headerRow; $r <= max($highestRow, $headerRow); $r++) {
        $sheet->duplicateStyle($sheet->getStyle('B' . $r), 'A' . $r);
    }

    $sheet->setCellValueExplicit('A' . $headerRow, $label, DataType::TYPE_STRING);
    $n = 0;
    for ($r = $headerRow + 1; $r <= $lastDataRow; $r++) {
        $sheet->setCellValue('A' . $r, ++$n);
    }
    if ($lastDataRow > $headerRow) {
        $sheet->getStyle('A' . $headerRow . ':A' . $lastDataRow)->getAlignment()->setHorizontal('center');
    }
    $sheet->getColumnDimension('A')->setAutoSize(false)->setWidth(max(5, strlen((string)$n) + 3));

    // Panel beku tetap seperti semula (hanya baris judul), tidak ikut membekukan kolom No.
    if ($freeze) $sheet->freezePane($freeze);
}

/**
 * Baris tempat judul kolom berada. File hasil export dan template import punya kop + judul di atas
 * tabel (judul kolom di baris 8), jadi judul kolom tidak selalu di baris 1. Dicari baris pertama
 * (maks. 20 baris teratas) yang memuat sel "ID Aset" / "Asset ID" / "Username" / "Nama Lengkap".
 * Tidak ketemu -> 1 (file lama tanpa kop).
 */
function xlsHeaderRowIndex(Worksheet $sheet): int
{
    $needles = ['id aset', 'asset id', 'username', 'nama lengkap', 'full name'];
    $maxRow = min(20, $sheet->getHighestDataRow());
    for ($r = 1; $r <= $maxRow; $r++) {
        $highestCol = $sheet->getHighestDataColumn($r);
        foreach ($sheet->rangeToArray("A{$r}:{$highestCol}{$r}", null, false, false, false)[0] ?? [] as $v) {
            if (in_array(mb_strtolower(trim((string)$v)), $needles, true)) return $r;
        }
    }
    return 1;
}

/** Nama singkat perusahaan di judul file Excel (diatur di menu Kop Surat; boleh kosong). */
function xlsCompanyName(): string
{
    require_once __DIR__ . '/letterhead.php';
    $s = letterheadSettings();
    return $s['short_name'] !== '' ? $s['short_name'] : $s['company_name'];
}

/** Teks dua bahasa mengikuti bahasa aktif. */
function xlsL(string $id, string $en): string
{
    return (function_exists('currentLang') ? currentLang() === 'id' : true) ? $id : $en;
}

/** Baris "Jumlah ...: N" di bawah tanggal dibuat, plus keterangan tambahan (periode, filter) dipisah " | ". */
function xlsCountLine(string $labelId, string $labelEn, int $count, array $extra = []): string
{
    $parts = array_merge([xlsL($labelId, $labelEn) . ': ' . $count], array_values(array_filter($extra, fn($v) => trim((string)$v) !== '')));
    return implode('   |   ', $parts);
}

/** Dua baris keterangan untuk template import. */
function xlsTemplateLines(): array
{
    require_once __DIR__ . '/letterhead.php';
    return [
        documentCreatedAt(),
        xlsL('Isi data mulai baris 9. Jangan mengubah judul kolom di baris 8.', 'Fill in data from row 9. Do not change the column titles in row 8.'),
    ];
}

/**
 * Kop + judul di atas tabel, sama untuk SEMUA file Excel (export & template import):
 *   baris 1-3 logo perusahaan (menu Kop Surat), baris 5 judul, baris 6-7 keterangan, baris 8 judul kolom.
 * Baris lama di atas judul kolom (jika ada) dibuang dulu. Panggil SETELAH xlsAddNumberColumn().
 *
 * @param int      $headerRow baris judul kolom saat ini (1 jika belum ada baris judul di atasnya)
 * @param string[] $lines     maksimal 2 baris keterangan (baris 6 dan 7)
 */
function xlsAddTitleBlock(Worksheet $sheet, int $headerRow, string $title, array $lines): void
{
    $freeze = $sheet->getFreezePane();
    if ($headerRow > 1) {
        foreach ($sheet->getMergeCells() as $range) {
            if (Coordinate::rangeBoundaries($range)[0][1] < $headerRow) $sheet->unmergeCells($range);
        }
        $sheet->removeRow(1, $headerRow - 1);
    }
    $lastCol = $sheet->getHighestDataColumn();
    $sheet->insertNewRowBefore(1, 7);
    // Baris baru tidak boleh mewarisi gaya judul kolom (warna/garis tepi) maupun tinggi barisnya.
    $sheet->duplicateStyle(new \PhpOffice\PhpSpreadsheet\Style\Style(), "A1:{$lastCol}7");
    foreach ([4, 5, 6, 7] as $r) $sheet->getRowDimension($r)->setRowHeight(-1);

    $lines = array_slice(array_values($lines), 0, 2);
    $sheet->setCellValueExplicit('A5', trim(preg_replace('/ {2,}/', ' ', $title), " \t—-"), DataType::TYPE_STRING);
    foreach ($lines as $i => $line) $sheet->setCellValueExplicit('A' . (6 + $i), (string)$line, DataType::TYPE_STRING);
    foreach ([5, 6, 7] as $r) $sheet->mergeCells("A{$r}:{$lastCol}{$r}");
    $sheet->getStyle('A5')->getFont()->setBold(true)->setSize(14);
    $sheet->getStyle('A6:A7')->getFont()->getColor()->setRGB('475569');
    foreach ([1, 2, 3] as $r) $sheet->getRowDimension($r)->setRowHeight(19);

    require_once __DIR__ . '/letterhead.php';
    $logo = letterheadImagePath('logo');   // logo kop dari menu Kop Surat (atau logo aplikasi)
    if ($logo !== '' && is_file($logo)) {
        $d = new \PhpOffice\PhpSpreadsheet\Worksheet\Drawing();
        $d->setName('Logo');
        $d->setPath($logo);
        $d->setHeight(70);
        $d->setCoordinates('A1');
        $d->setOffsetX(4);
        $d->setOffsetY(2);
        $d->setWorksheet($sheet);
    }
    // Panel beku ikut pindah bersama judul kolom (kolom yang dibekukan tetap).
    if ($freeze && preg_match('/^([A-Z]+)(\d+)$/', $freeze, $m)) {
        $sheet->freezePane($m[1] . max(9, (int)$m[2] + 7 - ($headerRow - 1)));
    }
}

/** "Desktop PC", "Laptop" -> "Data Desktop PC dan Laptop TMNN". Lebih dari 4 jenis (atau kosong) -> "Data Aset IT TMNN". */
function xlsAssetExportTitle(array $categories, ?string $company = null): string
{
    $company = $company ?? xlsCompanyName();
    $id   = function_exists('currentLang') ? currentLang() === 'id' : true;
    $cats = array_values(array_unique(array_filter(array_map(fn($c) => trim((string)$c), $categories), fn($c) => $c !== '')));
    if (!$cats || count($cats) > 4) return trim($id ? "Data Aset IT {$company}" : "IT Asset Data {$company}");
    $last = array_pop($cats);
    $list = ($cats ? implode(', ', $cats) . ($id ? ' dan ' : ' and ') : '') . $last;
    return trim($id ? "Data {$list} {$company}" : "{$list} Data {$company}");
}

/** Kop + judul otomatis + tanggal dibuat + jumlah aset untuk export Aset / Tablet. */
function xlsAddAssetTitleBlock(Worksheet $sheet, array $categories, int $assetCount, int $headerRow = 1): void
{
    require_once __DIR__ . '/letterhead.php';
    xlsAddTitleBlock($sheet, $headerRow, xlsAssetExportTitle($categories), [
        documentCreatedAt(),
        xlsL('Jumlah aset: ', 'Total assets: ') . $assetCount . xlsL(' unit', ''),
    ]);
}
