<?php
/**
 * Aksesoris aset: bisa lebih dari satu, tiap baris berisi Nama dan Brand/Type
 * (diisi di form Tambah/Edit Aset seperti isian Software).
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA:
 * - Hanya MEMBUAT 1 tabel BARU jika belum ada: asset_accessories. Tidak ALTER / DROP tabel lama.
 * - Kolom lama assets.accessories TETAP dipakai sebagai ringkasan teks, format
 *   "Nama (Brand/Type), Nama (Brand/Type)". Jadi daftar aset, export / import Excel,
 *   cetak, dan Export Audit yang membaca kolom itu tetap bekerja tanpa diubah.
 * - Kalau kolom assets.accessories diubah dari tempat lain (import Excel, form upgrade),
 *   teks kolom itulah yang dipakai: baris di tabel hanya dianggap berlaku selama
 *   ringkasannya masih sama dengan isi kolom. Aksesoris lama (teks bebas dipisah koma)
 *   otomatis terbaca sebagai baris-baris nama.
 *
 * Dipakai oleh: assets.php, asset_save.php, mutation_print.php
 */

const ACCESSORIES_COLUMN_MAX = 150; // panjang kolom assets.accessories (VARCHAR(150))

function assetAccessoriesTableExists(PDO $db, bool $refresh = false): bool
{
    static $exists = null;
    if ($exists === null || $refresh) {
        $exists = (bool)$db->query("SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_accessories'")->fetchColumn();
    }
    return $exists;
}

/** Buat tabel asset_accessories jika belum ada (CREATE TABLE IF NOT EXISTS — tidak menyentuh tabel lain). */
function ensureAssetAccessoriesTable(PDO $db): void
{
    if (assetAccessoriesTableExists($db)) return;
    $db->exec("
        CREATE TABLE IF NOT EXISTS asset_accessories (
            id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            asset_id        INT UNSIGNED NOT NULL,              -- assets.id (tanpa foreign key)
            accessory_name  VARCHAR(100) NOT NULL,
            brand_type      VARCHAR(100) DEFAULT NULL,
            sort_order      INT UNSIGNED NOT NULL DEFAULT 0,
            created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_acc_asset (asset_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    assetAccessoriesTableExists($db, true);
}

/** Rapikan daftar isian: buang baris tanpa nama, potong panjang. Return: [['name' => .., 'brand' => ..], ...] */
function cleanAccessoryItems(array $items): array
{
    $out = [];
    foreach ($items as $it) {
        $name  = mb_substr(trim((string)($it['name'] ?? '')), 0, 100);
        $brand = mb_substr(trim((string)($it['brand'] ?? '')), 0, 100);
        if ($name === '') continue;
        $out[] = ['name' => $name, 'brand' => $brand];
    }
    return $out;
}

/** Ringkasan teks lengkap: "Mouse (Logitech B100), Charger (ASUS 45W)". */
function accessoriesSummary(array $items): string
{
    return implode(', ', array_map(
        fn($it) => $it['name'] . ($it['brand'] !== '' ? ' (' . $it['brand'] . ')' : ''),
        cleanAccessoryItems($items)
    ));
}

/** Ringkasan yang disimpan di kolom assets.accessories (dipotong sesuai panjang kolom). */
function accessoriesColumnText(array $items): string
{
    return mb_substr(accessoriesSummary($items), 0, ACCESSORIES_COLUMN_MAX);
}

/**
 * Baca teks kolom assets.accessories menjadi baris-baris.
 * Pemisah: koma / titik koma / baris baru (yang di luar tanda kurung). "Nama (Brand)" -> nama + brand.
 */
function parseAccessoriesText(?string $text): array
{
    $text = trim((string)$text);
    if ($text === '') return [];
    $parts = []; $buf = ''; $depth = 0;
    foreach (preg_split('//u', $text, -1, PREG_SPLIT_NO_EMPTY) as $ch) {
        if ($ch === '(') $depth++;
        if ($ch === ')' && $depth > 0) $depth--;
        if ($depth === 0 && ($ch === ',' || $ch === ';' || $ch === "\n")) { $parts[] = $buf; $buf = ''; continue; }
        $buf .= $ch;
    }
    $parts[] = $buf;

    $items = [];
    foreach ($parts as $p) {
        $p = trim($p);
        if ($p === '') continue;
        if (preg_match('/^(.*\S)\s*\(([^()]*)\)$/u', $p, $m)) {
            $items[] = ['name' => trim($m[1]), 'brand' => trim($m[2])];
        } else {
            $items[] = ['name' => $p, 'brand' => ''];
        }
    }
    return cleanAccessoryItems($items);
}

/**
 * Aksesoris untuk banyak aset sekaligus. $assets = baris aset (minimal kolom id & accessories).
 * Return: [asset_id => [['name' => .., 'brand' => ..], ...]]
 */
function getAccessoryItemsForAssets(PDO $db, array $assets): array
{
    $ids = array_values(array_unique(array_filter(array_map(fn($a) => (int)($a['id'] ?? 0), $assets))));
    $rowsByAsset = [];
    if ($ids && assetAccessoriesTableExists($db)) {
        $stmt = $db->prepare("SELECT asset_id, accessory_name, brand_type FROM asset_accessories
                              WHERE asset_id IN (" . implode(',', array_fill(0, count($ids), '?')) . ")
                              ORDER BY asset_id, sort_order, id");
        $stmt->execute($ids);
        foreach ($stmt->fetchAll() as $r) {
            $rowsByAsset[(int)$r['asset_id']][] = ['name' => (string)$r['accessory_name'], 'brand' => (string)$r['brand_type']];
        }
    }
    $map = [];
    foreach ($assets as $a) {
        $id   = (int)($a['id'] ?? 0);
        $text = trim((string)($a['accessories'] ?? ''));
        $rows = $rowsByAsset[$id] ?? [];
        // Baris tabel berlaku hanya jika ringkasannya masih sama dengan isi kolom;
        // kalau kolom diubah dari tempat lain (import Excel dll), teks kolom yang dipakai.
        $map[$id] = ($rows && accessoriesColumnText($rows) === $text) ? $rows : parseAccessoriesText($text);
    }
    return $map;
}

/** Ganti seluruh daftar aksesoris 1 aset (tabel + kolom ringkasan assets.accessories). */
function setAssetAccessories(PDO $db, int $assetId, array $items): void
{
    $items = cleanAccessoryItems($items);
    if (assetAccessoriesTableExists($db)) {
        $db->prepare("DELETE FROM asset_accessories WHERE asset_id = ?")->execute([$assetId]);
        $ins = $db->prepare("INSERT INTO asset_accessories (asset_id, accessory_name, brand_type, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($items as $i => $it) {
            $ins->execute([$assetId, $it['name'], $it['brand'] !== '' ? $it['brand'] : null, $i]);
        }
    }
    $text = accessoriesColumnText($items);
    $db->prepare("UPDATE assets SET accessories = ? WHERE id = ?")->execute([$text !== '' ? $text : null, $assetId]);
}
