<?php
$user      = currentUser();
$isAdmin   = isAdmin();
$current   = basename($_SERVER['PHP_SELF']);

function navItem(string $file, string $icon, string $label, string $current): string
{
    $active = ($file === $current);
    $cls = $active
        ? 'bg-brand-600 text-white shadow-sm'
        : 'text-slate-300 hover:bg-slate-700/60 hover:text-white';
    return "<a href=\"$file\" class=\"flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors $cls\">"
         . "<span class=\"w-5 flex justify-center\">" . icon($icon, 'w-5 h-5') . "</span>"
         . "<span class=\"sidebar-label\">$label</span></a>";
}
?>
<!-- Overlay untuk mobile saat sidebar terbuka -->
<div id="sidebarOverlay" class="fixed inset-0 bg-black/40 z-30 hidden lg:hidden"></div>

<aside id="sidebar"
       class="fixed lg:static z-40 h-full w-64 bg-slate-800 text-white flex flex-col
              transition-all duration-200 -translate-x-full lg:translate-x-0">
    <div class="flex items-center justify-between px-4 h-16 border-b border-slate-700 shrink-0">
        <div class="flex items-center gap-2 overflow-hidden">
            <?= appLogoHtml('w-8 h-8 rounded-lg', 'bg-brand-500 text-white font-bold text-sm') ?>
            <span class="font-semibold sidebar-label text-sm leading-tight line-clamp-2" title="<?= htmlspecialchars(t('app_name')) ?>"><?= htmlspecialchars(t('app_name')) ?></span>
        </div>
        <button id="btnCloseSidebar" class="lg:hidden text-slate-300 hover:text-white"><?= icon('x', 'w-5 h-5') ?></button>
    </div>

    <nav class="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        <?php if ($isAdmin): ?>
            <?= navItem('dashboard.php', 'dashboard', t('nav_dashboard'), $current) ?>
            <?= navItem('assets.php', 'laptop', t('nav_assets'), $current) ?>
            <?= navItem('categories.php', 'tag', t('nav_categories'), $current) ?>
            <?= navItem('users.php', 'users', t('nav_users'), $current) ?>
            <?= navItem('tickets.php', 'ticket', t('nav_tickets'), $current) ?>
            <?= navItem('stock.php', 'package', t('nav_stock'), $current) ?>
            <?= navItem('mutations.php', 'transfer', t('nav_mutations'), $current) ?>
            <?= navItem('damages.php', 'alert', t('nav_damages'), $current) ?>
            <?= navItem('audit_export.php', 'sheet', t('nav_audit'), $current) ?>
            <?= navItem('pc_password.php', 'key', t('nav_pcpw'), $current) ?>
            <?= navItem('my_asset.php', 'monitor', t('nav_my_asset'), $current) ?>
            <?= navItem('email_signature.php', 'mail', t('nav_signature'), $current) ?>
            <?= navItem('settings.php', 'settings', t('nav_settings'), $current) ?>
        <?php else: ?>
            <?= navItem('my_asset.php', 'monitor', t('nav_my_asset'), $current) ?>
            <?= navItem('tickets.php', 'ticket', t('nav_tickets_user'), $current) ?>
            <?= navItem('ticket_queue.php', 'clock', t('nav_ticket_queue'), $current) ?>
            <?= navItem('email_signature.php', 'mail', t('nav_signature'), $current) ?>
        <?php endif; ?>

        <div class="border-t border-slate-700 my-3"></div>
        <a href="logout.php"
           onclick="return confirm('<?= htmlspecialchars(t('confirm_logout'), ENT_QUOTES) ?>')"
           class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-red-300 hover:bg-red-500/20 hover:text-red-200">
            <span class="w-5 flex justify-center"><?= icon('logout', 'w-5 h-5') ?></span>
            <span class="sidebar-label"><?= t('nav_logout') ?></span>
        </a>
    </nav>

    <div class="px-4 py-3 border-t border-slate-700 text-xs text-slate-400 sidebar-label">
        <?= t('signed_in_as') ?><br>
        <span class="text-white font-medium"><?= htmlspecialchars($user['full_name'] ?? '-') ?></span>
        (<?= htmlspecialchars($user['role'] ?? '-') ?>)
    </div>
</aside>

<div class="flex-1 flex flex-col min-w-0">
    <!-- Topbar -->
    <header class="h-16 bg-white border-b flex items-center justify-between gap-2 px-3 sm:px-4 shrink-0">
        <div class="flex items-center gap-2 sm:gap-3 min-w-0">
            <button id="btnHamburger" class="p-2 rounded-lg hover:bg-slate-100 text-slate-600 shrink-0">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M4 6h16M4 12h16M4 18h16" stroke-linecap="round"/>
                </svg>
            </button>
            <h1 class="font-semibold text-base sm:text-lg text-slate-700 truncate" title="<?= htmlspecialchars($pageTitle) ?>"><?= htmlspecialchars($pageTitle) ?></h1>
        </div>
        <div class="flex items-center gap-2 sm:gap-3 text-sm shrink-0">
            <?php $curLang = currentLang(); $curUrl = htmlspecialchars($_SERVER['REQUEST_URI'] ?? 'dashboard.php', ENT_QUOTES); ?>
            <div class="hidden sm:flex items-center gap-1 bg-slate-100 rounded-full p-1">
                <a href="set_lang.php?lang=id&redirect=<?= $curUrl ?>"
                   class="px-2 py-0.5 rounded-full text-xs font-semibold transition <?= $curLang === 'id' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-700' ?>">ID</a>
                <a href="set_lang.php?lang=en&redirect=<?= $curUrl ?>"
                   class="px-2 py-0.5 rounded-full text-xs font-semibold transition <?= $curLang === 'en' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-700' ?>">EN</a>
            </div>
            <!-- Menu akun (klik ikon user): nama, role, bahasa, Logout -->
            <div class="relative" id="userMenuWrap">
                <button type="button" id="btnUserMenu" aria-haspopup="true" aria-expanded="false" aria-controls="userMenu"
                        class="flex items-center gap-2 rounded-full pl-1 pr-2 py-1 hover:bg-slate-100 transition">
                    <span class="w-8 h-8 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center font-semibold">
                        <?= strtoupper(substr($user['full_name'] ?? 'U', 0, 1)) ?>
                    </span>
                    <span class="hidden sm:inline text-slate-600 max-w-[12rem] truncate"><?= htmlspecialchars($user['full_name'] ?? '') ?></span>
                    <svg class="w-4 h-4 text-slate-400 transition-transform" id="userMenuChevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path d="M6 9l6 6 6-6" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
                <div id="userMenu" role="menu"
                     class="hidden absolute right-0 mt-2 w-60 bg-white rounded-xl shadow-lg border border-slate-200 py-2 z-40">
                    <div class="px-4 pb-2 mb-1 border-b border-slate-100">
                        <p class="font-semibold text-slate-800 truncate"><?= htmlspecialchars($user['full_name'] ?? '-') ?></p>
                        <p class="text-xs text-slate-500 truncate"><?= htmlspecialchars($user['username'] ?? '') ?> &middot; <?= htmlspecialchars(($user['role'] ?? '') === 'admin' ? t('role_admin') : t('role_user')) ?></p>
                        <?php
                        // Profil singkat user yang login: jabatan, departement, email.
                        $profileInfo = ['position' => '', 'department' => '', 'email' => ''];
                        try {
                            $pfDb = getDB();
                            $pfSt = $pfDb->prepare("SELECT email, department FROM users WHERE id = ?");
                            $pfSt->execute([(int)($user['id'] ?? 0)]);
                            if ($pfRow = $pfSt->fetch()) {
                                $profileInfo['email'] = (string)($pfRow['email'] ?? '');
                                $profileInfo['department'] = (string)($pfRow['department'] ?? '');
                            }
                            $profileInfo['position'] = getUserPosition($pfDb, (int)($user['id'] ?? 0));
                        } catch (Throwable $e) { /* profil hanya pelengkap, menu tetap tampil */ }
                        ?>
                        <dl class="mt-2 space-y-1 text-xs">
                            <?php foreach ([['field_position', $profileInfo['position']], ['field_department', $profileInfo['department']], ['field_email', $profileInfo['email']]] as $pf): ?>
                                <div class="flex gap-2">
                                    <dt class="w-20 shrink-0 text-slate-400"><?= t($pf[0]) ?></dt>
                                    <dd class="min-w-0 break-words font-medium text-slate-700"><?= htmlspecialchars($pf[1] !== '' ? $pf[1] : t('dash')) ?></dd>
                                </div>
                            <?php endforeach; ?>
                        </dl>
                    </div>
                    <!-- Pilihan bahasa (di layar kecil tombol ID/EN di atas disembunyikan) -->
                    <div class="sm:hidden flex items-center gap-1 px-4 py-2">
                        <a href="set_lang.php?lang=id&redirect=<?= $curUrl ?>" class="px-2 py-0.5 rounded-full text-xs font-semibold <?= $curLang === 'id' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600' ?>">ID</a>
                        <a href="set_lang.php?lang=en&redirect=<?= $curUrl ?>" class="px-2 py-0.5 rounded-full text-xs font-semibold <?= $curLang === 'en' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600' ?>">EN</a>
                    </div>
                    <a href="change_password.php" role="menuitem" class="flex items-center gap-2 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                        <?= icon('lock', 'w-4 h-4') ?> <?= t('nav_selfpw') ?>
                    </a>
                    <a href="logout.php" role="menuitem"
                       onclick="return confirm('<?= htmlspecialchars(t('confirm_logout'), ENT_QUOTES) ?>')"
                       class="flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                        <?= icon('logout', 'w-4 h-4') ?> <?= t('nav_logout') ?>
                    </a>
                </div>
            </div>
        </div>
    </header>
    <script>
    (function () {
        var btn = document.getElementById('btnUserMenu'), menu = document.getElementById('userMenu'),
            chev = document.getElementById('userMenuChevron'), wrap = document.getElementById('userMenuWrap');
        if (!btn || !menu) return;
        function setOpen(open) {
            menu.classList.toggle('hidden', !open);
            chev.classList.toggle('rotate-180', open);
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        }
        btn.addEventListener('click', function (e) { e.stopPropagation(); setOpen(menu.classList.contains('hidden')); });
        document.addEventListener('click', function (e) { if (!wrap.contains(e.target)) setOpen(false); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setOpen(false); });
    })();
    </script>

    <main class="flex-1 overflow-y-auto overflow-x-hidden p-3 sm:p-4 lg:p-6">
