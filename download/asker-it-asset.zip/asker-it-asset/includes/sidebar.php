<?php
$user      = currentUser();
$isAdmin   = isAdmin();
$current   = basename($_SERVER['PHP_SELF']);

function navItem(string $file, string $icon, string $label, string $current): string
{
    $active = ($file === $current) || ($file === 'cctv.php' && strpos($current, 'cctv_') === 0);
    $cls = $active
        ? 'bg-brand-600 text-white shadow-sm'
        : 'text-slate-300 hover:bg-slate-700/60 hover:text-white';
    return "<a href=\"$file\" class=\"flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors $cls\">"
         . "<span class=\"w-5 flex justify-center\">" . icon($icon, 'w-5 h-5') . "</span>"
         . "<span class=\"sidebar-label\">$label</span></a>";
}
?>
<!-- Overlay untuk mobile saat sidebar terbuka -->
<div id="sidebarOverlay" class="fixed inset-0 bg-black/40 z-30 hidden lg:hidden"></div>

<aside id="sidebar"
       class="fixed lg:static z-40 h-full w-64 bg-slate-800 text-white flex flex-col
              transition-all duration-200 -translate-x-full lg:translate-x-0">
    <div class="flex items-center justify-between px-4 h-16 border-b border-slate-700 shrink-0">
        <div class="flex items-center gap-2 overflow-hidden">
            <?= appLogoHtml('w-8 h-8 rounded-lg', 'bg-brand-500 text-white font-bold text-sm') ?>
            <span class="font-semibold sidebar-label text-sm leading-tight line-clamp-2" title="<?= htmlspecialchars(t('app_name')) ?>"><?= htmlspecialchars(t('app_name')) ?></span>
        </div>
        <button id="btnCloseSidebar" class="lg:hidden text-slate-300 hover:text-white"><?= icon('x', 'w-5 h-5') ?></button>
    </div>

    <nav class="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        <?php if ($isAdmin): ?>
            <?= navItem('dashboard.php', 'dashboard', t('nav_dashboard'), $current) ?>
            <?= navItem('assets.php', 'laptop', t('nav_assets'), $current) ?>
            <?= navItem('categories.php', 'tag', t('nav_categories'), $current) ?>
            <?= navItem('users.php', 'users', t('nav_users'), $current) ?>
            <?= navItem('tickets.php', 'ticket', t('nav_tickets'), $current) ?>
            <?= navItem('request.php', 'file-plus-2', currentLang() === 'en' ? 'Special Requests' : 'Pengajuan Khusus', $current) ?>
            <?= navItem('chat.php', 'chat', currentLang() === 'en' ? 'Group Chat' : 'Chat Grup', $current) ?>
            <?= navItem('stock.php', 'package', t('nav_stock'), $current) ?>
            <?= navItem('mutations.php', 'transfer', t('nav_mutations'), $current) ?>
            <?= navItem('damages.php', 'alert', t('nav_damages'), $current) ?>
            <?= navItem('cctv.php', 'camera', t('nav_cctv'), $current) ?>
            <?= navItem('network.php', 'network', t('nav_network'), $current) ?>
            <?= navItem('audit_export.php', 'sheet', t('nav_audit'), $current) ?>
            <?= navItem('spec_standard.php', 'pc', currentLang() === 'en' ? 'Spec Standard' : 'Standar Spesifikasi', $current) ?>
            <?= navItem('pc_password.php', 'key', t('nav_pcpw'), $current) ?>
            <?= navItem('my_asset.php', 'monitor', t('nav_my_asset'), $current) ?>
            <?= navItem('ext_directory.php', 'phone', t('nav_ext_directory'), $current) ?>
            <?= navItem('email_signature.php', 'mail', t('nav_signature'), $current) ?>
            <?= navItem('nametag.php', 'idcard', 'Nametag', $current) ?>
            <?= navItem('letterhead_settings.php', 'file-text', t('nav_letterhead'), $current) ?>
            <?= navItem('settings.php', 'settings', t('nav_settings'), $current) ?>
        <?php else: ?>
            <?= navItem('my_asset.php', 'monitor', t('nav_my_asset'), $current) ?>
            <?= navItem('tickets.php', 'ticket', t('nav_tickets_user'), $current) ?>
            <?= navItem('request.php', 'file-plus-2', currentLang() === 'en' ? 'Special Requests' : 'Pengajuan Khusus', $current) ?>
            <?= navItem('chat.php', 'chat', currentLang() === 'en' ? 'Group Chat' : 'Chat Grup', $current) ?>
            <?= navItem('ticket_queue.php', 'clock', t('nav_ticket_queue'), $current) ?>
            <?php if (function_exists('isCctvUser') && isCctvUser()): ?>
                <?= navItem('cctv_checklist.php', 'camera', t('nav_cctv_checklist'), $current) ?>
            <?php endif; ?>
            <?php if (function_exists('isQmeUser') && isQmeUser()): ?>
                <?= navItem('assets.php', 'tablet', t('nav_qme_tablet'), $current) ?>
            <?php endif; ?>
            <?= navItem('ext_directory.php', 'phone', t('nav_ext_directory'), $current) ?>
            <?= navItem('email_signature.php', 'mail', t('nav_signature'), $current) ?>
            <?= navItem('nametag.php', 'idcard', 'Nametag', $current) ?>
        <?php endif; ?>

        <div class="border-t border-slate-700 my-3"></div>
        <a href="logout.php"
           onclick="return confirm('<?= htmlspecialchars(t('confirm_logout'), ENT_QUOTES) ?>')"
           class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-red-300 hover:bg-red-500/20 hover:text-red-200">
            <span class="w-5 flex justify-center"><?= icon('logout', 'w-5 h-5') ?></span>
            <span class="sidebar-label"><?= t('nav_logout') ?></span>
        </a>
    </nav>

    <div class="px-4 py-3 border-t border-slate-700 text-xs text-slate-400 sidebar-label">
        <?= t('signed_in_as') ?><br>
        <span class="text-white font-medium"><?= htmlspecialchars($user['full_name'] ?? '-') ?></span>
        (<?= htmlspecialchars($user['role'] ?? '-') ?>)
    </div>
</aside>

<?php
// ===== Menu bawah (bottom navigation) untuk user di HP / aplikasi Android =====
// User (bukan admin) di layar kecil (HP): semua menu tampil sebagai tombol di bawah layar, tidak lagi di balik tombol garis 3.
// Admin dan layar lebar (laptop/PC) tetap memakai sidebar seperti biasa. Cukup ganti file ini di server.
$bottomNav = [];
if (!$isAdmin) {
    $en = currentLang() === 'en';
    $bottomNav[] = ['my_asset.php', 'monitor', $en ? 'My Assets' : 'Aset Saya'];
    $bottomNav[] = ['tickets.php', 'ticket', $en ? 'Tickets' : 'Tiket IT'];
    $bottomNav[] = ['request.php', 'file-plus-2', $en ? 'Special Requests' : 'Pengajuan'];
    $bottomNav[] = ['chat.php', 'chat', 'Chat'];
    $bottomNav[] = ['notifications.php', 'bell', $en ? 'Alerts' : 'Notifikasi'];
    $bottomNav[] = ['ticket_queue.php', 'clock', $en ? 'Queue' : 'Antrian'];
    if (function_exists('isQmeUser') && isQmeUser()) $bottomNav[] = ['assets.php', 'tablet', 'Tablet'];
    if (function_exists('isCctvUser') && isCctvUser()) $bottomNav[] = ['cctv_checklist.php', 'camera', 'CCTV'];
    $bottomNav[] = ['ext_directory.php', 'phone', $en ? 'Phone Ext' : 'Ext Telp'];
    $bottomNav[] = ['email_signature.php', 'mail', 'Signature'];
    $bottomNav[] = ['nametag.php', 'idcard', 'Nametag'];
}
if ($bottomNav):
    // Maks. 6 tombol per baris; lebih dari itu (mis. user QME + CCTV) jadi 2 baris, supaya tidak ada menu yang tersembunyi.
    $bnCols = count($bottomNav) <= 6 ? count($bottomNav) : (int)ceil(count($bottomNav) / 2); ?>
<nav id="bottomNav" aria-label="Menu" class="lg:hidden fixed inset-x-0 bottom-0 z-30 bg-white border-t border-slate-200 shadow-[0_-2px_10px_rgba(15,23,42,.06)] print:hidden"
     style="padding-bottom: env(safe-area-inset-bottom, 0px)">
    <div class="grid px-1" style="grid-template-columns: repeat(<?= $bnCols ?>, minmax(0, 1fr))">
    <?php foreach ($bottomNav as [$bnFile, $bnIcon, $bnLabel]):
        $bnActive = $bnFile === $current || ($bnFile === 'cctv_checklist.php' && strpos($current, 'cctv_') === 0);
        $bnCls = 'flex flex-col items-center justify-center gap-0.5 py-1.5 px-0.5 min-w-0 text-[11px] leading-tight font-medium text-center rounded-lg '
               . ($bnActive ? 'text-brand-700' : 'text-slate-500 active:bg-slate-100');
        $bnIco = '<span class="relative flex items-center justify-center w-11 h-7 rounded-full ' . ($bnActive ? 'bg-brand-100' : '') . '">' . icon($bnIcon, 'w-5 h-5')
               . ($bnFile === 'notifications.php' ? '<span data-notif-badge class="hidden absolute -top-1 right-0.5 min-w-[1.1rem] h-[1.1rem] px-1 rounded-full bg-red-600 text-white text-[10px] font-bold leading-[1.1rem] text-center"></span>' : '') . '</span>';
        ?>
        <a href="<?= $bnFile ?>" class="<?= $bnCls ?>"<?= $bnActive ? ' aria-current="page"' : '' ?>><?= $bnIco ?><span class="truncate max-w-full"><?= htmlspecialchars($bnLabel) ?></span></a>
        <?php
    endforeach; ?>
    </div>
</nav>
<style>
    /* Ruang di bawah konten supaya tidak tertutup menu bawah; notifikasi melayang ikut naik. */
    @media (max-width: 1023.98px) {
        main.has-bottom-nav { padding-bottom: calc(<?= count($bottomNav) > 6 ? '9.5rem' : '5.5rem' ?> + env(safe-area-inset-bottom, 0px)) !important; }
        #cctvToast { bottom: calc(<?= count($bottomNav) > 6 ? '9.5rem' : '5.5rem' ?> + env(safe-area-inset-bottom, 0px)) !important; }
    }
</style>
<?php endif; ?>

<div class="flex-1 flex flex-col min-w-0">
    <!-- Topbar -->
    <header class="h-16 bg-white border-b flex items-center justify-between gap-2 px-3 sm:px-4 shrink-0">
        <div class="flex items-center gap-2 sm:gap-3 min-w-0">
            <button id="btnHamburger" class="p-2 rounded-lg hover:bg-slate-100 text-slate-600 shrink-0<?= $bottomNav ? ' max-lg:hidden' : '' ?>">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M4 6h16M4 12h16M4 18h16" stroke-linecap="round"/>
                </svg>
            </button>
            <h1 class="font-semibold text-base sm:text-lg text-slate-700 truncate" title="<?= htmlspecialchars($pageTitle) ?>"><?= htmlspecialchars($pageTitle) ?></h1>
        </div>
        <div class="flex items-center gap-2 sm:gap-3 text-sm shrink-0">
            <?php $curLang = currentLang(); $curUrl = htmlspecialchars($_SERVER['REQUEST_URI'] ?? 'dashboard.php', ENT_QUOTES); ?>
            <?php
            // ===== Lonceng Pusat Notifikasi (includes/notifications.php, notif_api.php) =====
            $notifInit = ['total' => 0, 'max_id' => 0];
            try { require_once __DIR__ . '/notifications.php'; $notifInit = notifUnreadCounts(getDB(), (int)($user['id'] ?? 0)); } catch (Throwable $e) {}
            ?>
            <div class="relative" id="notifWrap">
                <button type="button" id="btnNotif" aria-haspopup="true" aria-expanded="false" aria-controls="notifMenu" title="<?= htmlspecialchars(notifL('Notifikasi', 'Notifications')) ?>"
                        class="relative p-2 rounded-full hover:bg-slate-100 text-slate-600">
                    <?= icon('bell', 'w-5 h-5') ?>
                    <span data-notif-badge class="<?= $notifInit['total'] ? '' : 'hidden ' ?>absolute top-0.5 right-0.5 min-w-[1.1rem] h-[1.1rem] px-1 rounded-full bg-red-600 text-white text-[10px] font-bold leading-[1.1rem] text-center ring-2 ring-white"><?= $notifInit['total'] > 99 ? '99+' : (int)$notifInit['total'] ?></span>
                </button>
                <div id="notifMenu" role="dialog" aria-label="<?= htmlspecialchars(notifL('Notifikasi', 'Notifications')) ?>"
                     class="hidden fixed sm:absolute inset-x-2 sm:inset-x-auto top-16 sm:top-auto sm:right-0 sm:mt-2 sm:w-96 bg-white rounded-xl shadow-xl border border-slate-200 z-40 flex flex-col max-h-[75vh]">
                    <div class="flex items-center justify-between px-4 pt-3">
                        <p class="font-semibold text-slate-800"><?= htmlspecialchars(notifL('Notifikasi', 'Notifications')) ?></p>
                        <button type="button" id="notifReadAll" class="text-xs text-brand-700 hover:underline"><?= htmlspecialchars(notifL('Tandai semua dibaca', 'Mark all as read')) ?></button>
                    </div>
                    <div class="flex gap-4 px-4 mt-2 border-b border-slate-100 text-sm" role="tablist">
                        <button type="button" data-ntab="unread" class="pb-2 border-b-2 font-medium"><?= htmlspecialchars(notifL('Belum dibaca', 'Unread')) ?> <span data-ncount></span></button>
                        <button type="button" data-ntab="all" class="pb-2 border-b-2 font-medium"><?= htmlspecialchars(notifL('Semua', 'All')) ?></button>
                    </div>
                    <div class="flex flex-wrap gap-1.5 px-4 py-2" id="notifChips"></div>
                    <ul id="notifList" class="overflow-y-auto overscroll-contain divide-y divide-slate-100 min-h-[4rem]"></ul>
                    <a href="notifications.php" class="block text-center text-sm font-medium text-brand-700 py-2.5 border-t border-slate-100 hover:bg-slate-50"><?= htmlspecialchars(notifL('Lihat semua notifikasi', 'See all notifications')) ?></a>
                </div>
            </div>
            <div class="hidden sm:flex items-center gap-1 bg-slate-100 rounded-full p-1">
                <a href="set_lang.php?lang=id&redirect=<?= $curUrl ?>"
                   class="px-2 py-0.5 rounded-full text-xs font-semibold transition <?= $curLang === 'id' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-700' ?>">ID</a>
                <a href="set_lang.php?lang=en&redirect=<?= $curUrl ?>"
                   class="px-2 py-0.5 rounded-full text-xs font-semibold transition <?= $curLang === 'en' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-700' ?>">EN</a>
            </div>
            <!-- Menu akun (klik ikon user): nama, role, bahasa, Logout -->
            <div class="relative" id="userMenuWrap">
                <button type="button" id="btnUserMenu" aria-haspopup="true" aria-expanded="false" aria-controls="userMenu"
                        class="flex items-center gap-2 rounded-full pl-1 pr-2 py-1 hover:bg-slate-100 transition">
                    <span class="w-8 h-8 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center font-semibold">
                        <?= strtoupper(substr($user['full_name'] ?? 'U', 0, 1)) ?>
                    </span>
                    <span class="hidden sm:inline text-slate-600 max-w-[12rem] truncate"><?= htmlspecialchars($user['full_name'] ?? '') ?></span>
                    <svg class="w-4 h-4 text-slate-400 transition-transform" id="userMenuChevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path d="M6 9l6 6 6-6" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
                <div id="userMenu" role="menu"
                     class="hidden absolute right-0 mt-2 w-60 bg-white rounded-xl shadow-lg border border-slate-200 py-2 z-40">
                    <div class="px-4 pb-2 mb-1 border-b border-slate-100">
                        <p class="font-semibold text-slate-800 truncate"><?= htmlspecialchars($user['full_name'] ?? '-') ?></p>
                        <p class="text-xs text-slate-500 truncate"><?= htmlspecialchars($user['username'] ?? '') ?> &middot; <?= htmlspecialchars(($user['role'] ?? '') === 'admin' ? t('role_admin') : t('role_user')) ?></p>
                        <?php
                        // Profil singkat user yang login: jabatan, departement, email.
                        $profileInfo = ['position' => '', 'department' => '', 'email' => ''];
                        try {
                            $pfDb = getDB();
                            $pfSt = $pfDb->prepare("SELECT email, department FROM users WHERE id = ?");
                            $pfSt->execute([(int)($user['id'] ?? 0)]);
                            if ($pfRow = $pfSt->fetch()) {
                                $profileInfo['email'] = (string)($pfRow['email'] ?? '');
                                $profileInfo['department'] = (string)($pfRow['department'] ?? '');
                            }
                            $profileInfo['position'] = getUserPosition($pfDb, (int)($user['id'] ?? 0));
                        } catch (Throwable $e) { /* profil hanya pelengkap, menu tetap tampil */ }
                        ?>
                        <dl class="mt-2 space-y-1 text-xs">
                            <?php foreach ([['field_position', $profileInfo['position']], ['field_department', $profileInfo['department']], ['field_email', $profileInfo['email']]] as $pf): ?>
                                <div class="flex gap-2">
                                    <dt class="w-20 shrink-0 text-slate-400"><?= t($pf[0]) ?></dt>
                                    <dd class="min-w-0 break-words font-medium text-slate-700"><?= htmlspecialchars($pf[1] !== '' ? $pf[1] : t('dash')) ?></dd>
                                </div>
                            <?php endforeach; ?>
                        </dl>
                    </div>
                    <!-- Pilihan bahasa (di layar kecil tombol ID/EN di atas disembunyikan) -->
                    <div class="sm:hidden flex items-center gap-1 px-4 py-2">
                        <a href="set_lang.php?lang=id&redirect=<?= $curUrl ?>" class="px-2 py-0.5 rounded-full text-xs font-semibold <?= $curLang === 'id' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600' ?>">ID</a>
                        <a href="set_lang.php?lang=en&redirect=<?= $curUrl ?>" class="px-2 py-0.5 rounded-full text-xs font-semibold <?= $curLang === 'en' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600' ?>">EN</a>
                    </div>
                    <a href="change_password.php" role="menuitem" class="flex items-center gap-2 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                        <?= icon('lock', 'w-4 h-4') ?> <?= t('nav_selfpw') ?>
                    </a>
                    <a href="logout.php" role="menuitem"
                       onclick="return confirm('<?= htmlspecialchars(t('confirm_logout'), ENT_QUOTES) ?>')"
                       class="flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                        <?= icon('logout', 'w-4 h-4') ?> <?= t('nav_logout') ?>
                    </a>
                </div>
            </div>
        </div>
    </header>
    <script>
    (function () {
        var btn = document.getElementById('btnUserMenu'), menu = document.getElementById('userMenu'),
            chev = document.getElementById('userMenuChevron'), wrap = document.getElementById('userMenuWrap');
        if (!btn || !menu) return;
        function setOpen(open) {
            menu.classList.toggle('hidden', !open);
            chev.classList.toggle('rotate-180', open);
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        }
        btn.addEventListener('click', function (e) { e.stopPropagation(); setOpen(menu.classList.contains('hidden')); });
        document.addEventListener('click', function (e) { if (!wrap.contains(e.target)) setOpen(false); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setOpen(false); });
    })();
    </script>
    <script>
    /* Lonceng notifikasi: daftar, tandai dibaca, dan cek notifikasi baru tiap 20 detik. */
    (function () {
        var btn = document.getElementById('btnNotif'), menu = document.getElementById('notifMenu'), wrap = document.getElementById('notifWrap');
        if (!btn || !menu) return;
        var list = document.getElementById('notifList'), chips = document.getElementById('notifChips');
        var CSRF = <?= json_encode(csrfToken()) ?>;
        var CATS = <?= json_encode(array_map(fn($c) => ['label' => $c['label'], 'cls' => $c['cls'], 'icon' => icon($c['icon'], 'w-4 h-4')], notifCats()), JSON_UNESCAPED_UNICODE) ?>;
        var L = <?= json_encode(['all' => notifL('Semua', 'All'), 'empty_unread' => notifL('Semua notifikasi sudah dibaca.', 'You are all caught up.'), 'empty' => notifL('Belum ada notifikasi.', 'No notifications yet.'), 'loading' => notifL('Memuat…', 'Loading…')], JSON_UNESCAPED_UNICODE) ?>;
        var state = {tab: <?= $notifInit['total'] ? "'unread'" : "'all'" ?>, cat: '', max: <?= (int)$notifInit['max_id'] ?>, open: false};
        // Jenis yang sudah punya pop-up sendiri (tiket baru, CCTV, chat) tidak dimunculkan dua kali.
        var HAS_POPUP = {ticket_new: 1, chat_msg: 1, chat_announce: 1, chat_mention: 1};
        function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
        function setBadge(n) {
            document.querySelectorAll('[data-notif-badge]').forEach(function (b) { b.textContent = n > 99 ? '99+' : n; b.classList.toggle('hidden', !n); });
            document.querySelectorAll('[data-ncount]').forEach(function (b) { b.textContent = n ? '(' + n + ')' : ''; });
        }
        function render(d) {
            setBadge(d.unread || 0);
            document.querySelectorAll('[data-ntab]').forEach(function (b) {
                var on = b.getAttribute('data-ntab') === state.tab;
                b.className = 'pb-2 border-b-2 font-medium ' + (on ? 'border-brand-600 text-brand-700' : 'border-transparent text-slate-500 hover:text-slate-700');
            });
            var byCat = d.by_cat || {}, html = '<button type="button" data-ncat="" class="' + chipCls(state.cat === '') + '">' + esc(L.all) + (d.unread ? ' ' + d.unread : '') + '</button>';
            Object.keys(CATS).forEach(function (k) { html += '<button type="button" data-ncat="' + k + '" class="' + chipCls(state.cat === k) + '">' + esc(CATS[k].label) + (byCat[k] ? ' ' + byCat[k] : '') + '</button>'; });
            chips.innerHTML = html;
            var items = d.items || [];
            list.innerHTML = items.length ? items.map(function (x) {
                var c = CATS[x.cat] || CATS.system;
                return '<li><a href="' + esc(x.open) + '" class="flex items-start gap-3 px-4 py-3 hover:bg-slate-50 ' + (x.read ? '' : 'bg-brand-50/40') + '">'
                    + '<span class="w-8 h-8 rounded-full flex items-center justify-center shrink-0 ' + c.cls + '">' + c.icon + '</span>'
                    + '<span class="min-w-0 flex-1"><span class="block text-sm leading-snug ' + (x.read ? 'text-slate-700' : 'font-semibold text-slate-800') + '">' + esc(x.title) + '</span>'
                    + (x.body ? '<span class="block text-xs text-slate-500 leading-snug break-words">' + esc(x.body) + '</span>' : '')
                    + '<span class="block text-[11px] text-slate-400 mt-0.5" title="' + esc(x.time) + '">' + esc(c.label) + ' · ' + esc(x.ago) + '</span></span>'
                    + (x.read ? '' : '<span class="w-2 h-2 rounded-full bg-brand-600 mt-2 shrink-0"></span>') + '</a></li>';
            }).join('') : '<li class="px-4 py-8 text-center text-sm text-slate-500">' + esc(state.tab === 'unread' ? L.empty_unread : L.empty) + '</li>';
        }
        function chipCls(on) { return 'text-xs px-2.5 py-0.5 rounded-full border ' + (on ? 'bg-brand-600 border-brand-600 text-white' : 'border-slate-200 text-slate-600 hover:bg-slate-50'); }
        function load() {
            fetch('notif_api.php?a=list&limit=20&tab=' + state.tab + '&cat=' + encodeURIComponent(state.cat), {credentials: 'same-origin', headers: {'X-Requested-With': 'XMLHttpRequest'}})
                .then(function (r) { return r.json(); }).then(function (d) { if (d.ok) render(d); }).catch(function () {});
        }
        function setOpen(open) {
            state.open = open;
            menu.classList.toggle('hidden', !open);
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
            if (open) { list.innerHTML = '<li class="px-4 py-6 text-center text-sm text-slate-400">' + esc(L.loading) + '</li>'; load(); }
        }
        btn.addEventListener('click', function (e) { e.stopPropagation(); setOpen(menu.classList.contains('hidden')); });
        document.addEventListener('click', function (e) { if (state.open && !wrap.contains(e.target)) setOpen(false); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && state.open) setOpen(false); });
        menu.addEventListener('click', function (e) {
            var t = e.target.closest('[data-ntab]'); if (t) { state.tab = t.getAttribute('data-ntab'); load(); return; }
            var c = e.target.closest('[data-ncat]'); if (c) { state.cat = c.getAttribute('data-ncat'); load(); return; }
        });
        document.getElementById('notifReadAll').addEventListener('click', function () {
            fetch('notif_api.php', {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'a=read&all=1&csrf_token=' + encodeURIComponent(CSRF)}).then(function () { load(); }).catch(function () {});
        });
        // Notifikasi baru: perbarui lencana; jenis tanpa pop-up sendiri (status tiket, sistem) diberi toast + notifikasi HP.
        var toastEl;
        function toast(x) {
            if (!toastEl) {
                toastEl = document.createElement('a');
                toastEl.className = 'fixed z-50 right-4 left-4 sm:left-auto sm:w-96 bg-white border border-slate-200 shadow-xl rounded-xl px-4 py-3 flex gap-3 items-start print:hidden';
                toastEl.style.bottom = 'calc(1rem + env(safe-area-inset-bottom, 0px))';
                document.body.appendChild(toastEl);
            }
            var c = CATS[x.cat] || CATS.system;
            toastEl.href = x.open;
            toastEl.innerHTML = '<span class="w-8 h-8 rounded-full flex items-center justify-center shrink-0 ' + c.cls + '">' + c.icon + '</span><span class="min-w-0"><span class="block text-sm font-semibold text-slate-800">' + esc(x.title) + '</span><span class="block text-xs text-slate-500">' + esc(x.body) + '</span></span>';
            toastEl.classList.remove('hidden');
            clearTimeout(toast.t); toast.t = setTimeout(function () { toastEl.classList.add('hidden'); }, 8000);
        }
        function poll() {
            if (document.hidden) return;
            fetch('notif_api.php?a=unread&since=' + state.max, {credentials: 'same-origin', headers: {'X-Requested-With': 'XMLHttpRequest'}})
                .then(function (r) { return r.json(); }).then(function (d) {
                    if (!d.ok) return;
                    setBadge(d.unread || 0);
                    (d.items || []).forEach(function (x) {
                        if (HAS_POPUP[x.type] || x.cat === 'cctv') return;
                        toast(x);
                        try { if (window.TMNNApp && TMNNApp.notify) TMNNApp.notify(JSON.stringify(x)); } catch (e) {}
                    });
                    if (d.max_id > state.max) { state.max = d.max_id; if (state.open) load(); }
                }).catch(function () {});
        }
        setInterval(poll, 20000);
        setTimeout(poll, 1500);
        document.addEventListener('visibilitychange', function () { if (!document.hidden) poll(); });
    })();
    </script>

    <main class="flex-1 overflow-y-auto overflow-x-hidden p-3 sm:p-4 lg:p-6<?= $bottomNav ? ' has-bottom-nav' : '' ?>">
