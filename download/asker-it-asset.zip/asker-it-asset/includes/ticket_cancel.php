<?php
/**
 * Pembatalan tiket oleh user.
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA:
 * - Kolom tickets.status (ENUM Menunggu/Proses/Selesai) TIDAK diubah.
 * - Pembatalan dicatat di tabel BARU ticket_cancellations (siapa, alasan, kapan).
 * - Tiket yang dibatalkan diberi status 'Selesai' dengan resolved_at KOSONG, sehingga
 *   otomatis keluar dari antrian (Menunggu/Proses) dan tidak terhitung sebagai
 *   "Perbaikan Selesai Hari Ini". Di semua tampilan statusnya ditampilkan "Dibatalkan".
 */

const TICKET_CANCELLED = 'Dibatalkan';

function ticketCancelTableExists(PDO $db): bool
{
    static $exists = null;
    if ($exists === null) {
        $exists = (bool)$db->query("SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ticket_cancellations'")->fetchColumn();
    }
    return $exists;
}

function ensureTicketCancelTable(PDO $db): void
{
    if (ticketCancelTableExists($db)) return;
    $db->exec("
        CREATE TABLE IF NOT EXISTS ticket_cancellations (
            ticket_id     INT UNSIGNED NOT NULL PRIMARY KEY,
            cancelled_by  INT UNSIGNED DEFAULT NULL,
            reason        VARCHAR(255) DEFAULT NULL,
            cancelled_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
}

/** [ticket_id => ['reason'=>..., 'cancelled_at'=>..., 'cancelled_by_name'=>...]] */
function getTicketCancelMap(PDO $db, array $ticketIds): array
{
    $ticketIds = array_values(array_filter(array_map('intval', $ticketIds)));
    if (!$ticketIds || !ticketCancelTableExists($db)) return [];
    $ph = implode(',', array_fill(0, count($ticketIds), '?'));
    $stmt = $db->prepare("SELECT c.ticket_id, c.reason, c.cancelled_at, u.full_name AS cancelled_by_name
                          FROM ticket_cancellations c LEFT JOIN users u ON u.id = c.cancelled_by
                          WHERE c.ticket_id IN ($ph)");
    $stmt->execute($ticketIds);
    $map = [];
    foreach ($stmt->fetchAll() as $r) { $map[(int)$r['ticket_id']] = $r; }
    return $map;
}

/** Tandai baris tiket yang dibatalkan: status -> 'Dibatalkan' + info pembatalan. */
function applyTicketCancellations(PDO $db, array $tickets): array
{
    $map = getTicketCancelMap($db, array_column($tickets, 'id'));
    foreach ($tickets as &$t) {
        $c = $map[(int)($t['id'] ?? 0)] ?? null;
        $t['is_cancelled']  = (bool)$c;
        $t['cancel_reason'] = $c['reason'] ?? '';
        $t['cancelled_at']  = $c['cancelled_at'] ?? null;
        $t['cancelled_by_name'] = $c['cancelled_by_name'] ?? '';
        if ($c) $t['status'] = TICKET_CANCELLED;
    }
    unset($t);
    return $tickets;
}

/** Potongan SQL: tiket BUKAN yang dibatalkan (untuk alias tabel tiket $alias). */
function sqlNotCancelled(PDO $db, string $alias = 't'): string
{
    return ticketCancelTableExists($db)
        ? " AND NOT EXISTS (SELECT 1 FROM ticket_cancellations tc WHERE tc.ticket_id = {$alias}.id)"
        : '';
}

/**
 * Jumlah tiket yang SELESAI HARI INI (kartu "Perbaikan Selesai Hari Ini" di Dashboard).
 *
 * Waktu selesai dibaca dari riwayat status (ticket_logs.changed_at, diisi jam server database —
 * jam yang sama dengan Tanggal Dibuat tiket), yaitu saat tiket PERTAMA KALI menjadi Selesai
 * sejak terakhir kali berstatus lain. Jadi:
 * - tidak terpengaruh beda zona waktu antara PHP dan database,
 * - tiket lama yang statusnya disimpan ulang (klik Update lagi) tidak ikut terhitung hari ini,
 * - tiket yang dibatalkan user tidak dihitung.
 * Tiket lama yang belum punya riwayat status memakai kolom resolved_at.
 */
function countTicketsFixedToday(PDO $db): int
{
    return count(getTicketsFixedToday($db));
}

/**
 * Daftar tiket yang selesai hari ini (aturan sama dengan di atas), lengkap dengan waktu dibuat
 * dan waktu selesainya, supaya angka di kartu Dashboard bisa dicek tiket per tiket.
 */
function getTicketsFixedToday(PDO $db): array
{
    $doneAt = "COALESCE(
                (SELECT MIN(l.changed_at) FROM ticket_logs l
                  WHERE l.ticket_id = t.id AND l.status = 'Selesai'
                    AND l.id > COALESCE((SELECT MAX(l2.id) FROM ticket_logs l2
                                          WHERE l2.ticket_id = t.id AND l2.status <> 'Selesai'), 0)),
                t.resolved_at)";
    return $db->query("
        SELECT t.id, t.ticket_number, t.problem_detail, t.created_at, $doneAt AS done_at,
               u.full_name AS pelapor, h.full_name AS handler
        FROM tickets t
        JOIN users u ON u.id = t.reported_by
        LEFT JOIN users h ON h.id = t.handled_by
        WHERE t.status = 'Selesai' AND t.resolved_at IS NOT NULL" . sqlNotCancelled($db, 't') . "
          AND DATE($doneAt) = CURDATE()
        ORDER BY done_at DESC
    ")->fetchAll();
}

/**
 * Waktu selesai untuk banyak tiket sekaligus: [id tiket => 'YYYY-MM-DD HH:MM:SS'].
 * Aturannya sama dengan getTicketsFixedToday(): saat tiket pertama kali menjadi Selesai sejak terakhir
 * berstatus lain (dari ticket_logs); tiket tanpa riwayat memakai kolom resolved_at.
 * $tickets = baris tiket (minimal id, status, resolved_at). Hanya tiket berstatus Selesai yang diisi.
 */
function getTicketDoneAtMap(PDO $db, array $tickets): array
{
    $done = [];
    foreach ($tickets as $t) {
        if (($t['status'] ?? '') === 'Selesai' && !empty($t['resolved_at'])) $done[(int)$t['id']] = (string)$t['resolved_at'];
    }
    if (!$done) return [];
    $ids = array_keys($done);
    $firstDone = [];
    foreach (array_chunk($ids, 500) as $chunk) {
        $stmt = $db->prepare("SELECT ticket_id, status, changed_at FROM ticket_logs
                              WHERE ticket_id IN (" . implode(',', array_fill(0, count($chunk), '?')) . ") ORDER BY id");
        $stmt->execute($chunk);
        foreach ($stmt->fetchAll() as $l) {
            $tid = (int)$l['ticket_id'];
            if ($l['status'] !== 'Selesai') { unset($firstDone[$tid]); }          // dibuka lagi -> hitung ulang
            elseif (!isset($firstDone[$tid])) { $firstDone[$tid] = (string)$l['changed_at']; }
        }
    }
    foreach ($firstDone as $tid => $at) { $done[$tid] = $at; }
    return $done;
}

/**
 * Riwayat update status untuk banyak tiket sekaligus: [id tiket => [[status, changed_at, note, changer], ...]]
 * berurutan dari yang paling lama. Dibaca dari ticket_logs (tabel yang sudah ada, tidak diubah).
 */
function getTicketLogsMap(PDO $db, array $ticketIds): array
{
    $map = [];
    $ids = array_values(array_unique(array_filter(array_map('intval', $ticketIds))));
    foreach (array_chunk($ids, 500) as $chunk) {
        $stmt = $db->prepare("SELECT l.ticket_id, l.status, l.note, l.changed_at, u.full_name AS changer
                              FROM ticket_logs l LEFT JOIN users u ON u.id = l.changed_by
                              WHERE l.ticket_id IN (" . implode(',', array_fill(0, count($chunk), '?')) . ") ORDER BY l.id");
        $stmt->execute($chunk);
        foreach ($stmt->fetchAll() as $l) { $map[(int)$l['ticket_id']][] = $l; }
    }
    return $map;
}

/** Lama pengerjaan dalam kalimat pendek, mis. "1 hari 2 jam" / "45 menit". */
function ticketDurationLabel(string $from, string $to): string
{
    $sec = max(0, strtotime($to) - strtotime($from));
    $d = intdiv($sec, 86400); $h = intdiv($sec % 86400, 3600); $m = intdiv($sec % 3600, 60);
    if ($d > 0) return $d . ' ' . t('dur_day') . ($h > 0 ? ' ' . $h . ' ' . t('dur_hour') : '');
    if ($h > 0) return $h . ' ' . t('dur_hour') . ($m > 0 ? ' ' . $m . ' ' . t('dur_minute') : '');
    return max(1, $m) . ' ' . t('dur_minute');
}

/** Label & warna status tiket (termasuk Dibatalkan). */
function ticketStatusLabels(): array
{
    return [
        'Menunggu'   => t('ticket_status_waiting'),
        'Proses'     => t('ticket_status_process'),
        'Selesai'    => t('ticket_status_done'),
        'Dibatalkan' => t('ticket_status_cancelled'),
    ];
}
function ticketStatusBadges(): array
{
    return [
        'Menunggu'   => 'bg-slate-100 text-slate-600',
        'Proses'     => 'bg-amber-100 text-amber-700',
        'Selesai'    => 'bg-green-100 text-green-700',
        'Dibatalkan' => 'bg-red-50 text-red-600 line-through decoration-red-300',
    ];
}
