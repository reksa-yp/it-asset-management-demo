<?php
/**
 * Nametag Tamu (khusus admin): nametag meja 15 x 19,99 cm (dilipat dua di tengah),
 * 2 nametag per lembar F4 / Legal landscape. Tidak menyimpan data ke database
 * (daftar tamu terakhir hanya diingat di sesi admin).
 * Gambar dibuat dengan GD + font Montserrat (OFL); logo di pita putih memakai logo aplikasi (Pengaturan Sistem).
 */
require_once __DIR__ . '/nametag.php';   // ntL()

const NG_W_MM = 150.0;
const NG_H_MM = 199.9;
const NG_MAX  = 100;   // maks. nama per cetak
const NG_NAME_PT  = 40;   // ukuran nama (diperkecil otomatis bila terlalu panjang)
const NG_TITLE_PT = 22;   // ukuran jabatan (terlalu panjang -> baris baru, maks. 3 baris)

function ngPapers(): array
{
    // ukuran landscape (mm) dan ukuran kertas Dompdf (poin)
    return [
        'f4'    => ['name' => 'F4 / Folio', 'short' => 'F4',    'w' => 330, 'h' => 215, 'pt' => [0, 0, 935.43, 609.45], 'size' => '21,5 × 33 cm'],
        'legal' => ['name' => 'Legal',      'short' => 'Legal', 'w' => 356, 'h' => 216, 'pt' => [0, 0, 1008, 612],       'size' => '21,6 × 35,6 cm'],
    ];
}

/** Rapikan daftar tamu dari form: [['name'=>, 'title'=>], ...] */
function ngCleanRows(array $names, array $titles): array
{
    $out = [];
    foreach ($names as $i => $n) {
        $n = trim(preg_replace('/\s+/u', ' ', (string)$n));
        if ($n === '') continue;
        $out[] = ['name' => mb_substr($n, 0, 80), 'title' => mb_substr(trim(preg_replace('/\s+/u', ' ', (string)($titles[$i] ?? ''))), 0, 120)];
        if (count($out) >= NG_MAX) break;
    }
    return $out;
}

/** Satu nametag tamu sebagai PNG. */
function ngRenderPng(string $name, string $title, int $dpi = 300): string
{
    $k = $dpi / 25.4;                                   // px per mm
    $W = (int)round(NG_W_MM * $k); $H = (int)round(NG_H_MM * $k); $HH = (int)ceil($H / 2);
    $M = fn($mm) => (int)round($mm * $k);
    $img = fn($f) => @imagecreatefrompng(__DIR__ . '/../assets/img/' . $f);
    $fontB = ntFont('bold');
    $fontL = ntFont('light');

    $half = imagecreatetruecolor($W, $HH);
    imagealphablending($half, true);
    $navy = imagecolorallocate($half, 0x22, 0x2e, 0x47);
    $white = imagecolorallocate($half, 255, 255, 255);
    imagefilledrectangle($half, 0, 0, $W, $HH, $navy);
    imagefilledrectangle($half, 0, $M(83.4), $W, $HH, $white);         // pita putih di ujung
    $put = function ($file, $x, $y, $w, $h) use ($half, $img, $M) {
        if (!($src = $img($file))) return;
        imagecopyresampled($half, $src, $M($x), $M($y), 0, 0, $M($w), $M($h), imagesx($src), imagesy($src));
        imagedestroy($src);
    };
    // Logo di pita putih: logo aplikasi yang diunggah admin (Pengaturan Sistem). Tanpa logo, pita dibiarkan polos.
    $logoFile = function_exists('appLogoPath') ? appLogoPath() : '';
    if ($logoFile !== '' && ($src = @imagecreatefromstring((string)file_get_contents($logoFile)))) {
        $bw = $M(34.8); $bh = $M(8.3); $sw = imagesx($src); $sh = imagesy($src);
        $sc = min($bw / max(1, $sw), $bh / max(1, $sh));
        $dw = max(1, (int)round($sw * $sc)); $dh = max(1, (int)round($sh * $sc));
        imagecopyresampled($half, $src, $M(4.6), $M(86.8) + (int)(($bh - $dh) / 2), 0, 0, $dw, $dh, $sw, $sh);
        imagedestroy($src);
    }

    $text = function ($str, $font, $sizeMm, $x, $baseline, $maxMm) use ($half, $white, $M) {
        if ($str === '' || !$font) return;
        $pt = $M($sizeMm) * 0.75;
        for ($i = 0; $i < 60; $i++) {
            $bb = imagettfbbox($pt, 0, $font, $str);
            if (($bb[2] - $bb[0]) <= $M($maxMm)) break;
            $pt *= 0.96;
        }
        $bb = imagettfbbox($pt, 0, $font, $str);
        imagettftext($half, $pt, 0, $M($x) - $bb[0], $M($baseline), $white, $font, $str);
    };
    $text($name, $fontB, NG_NAME_PT * 25.4 / 72, 12.2, 41.0, NG_W_MM - 12.2 - 6);
    // Jabatan: 22 pt; bila terlalu panjang pindah ke baris baru (maks. 3 baris, baru diperkecil bila masih tidak muat).
    if ($title !== '' && $fontL) {
        $maxW = $M(NG_W_MM - 12.4 - 6);
        $mm = NG_TITLE_PT * 25.4 / 72;
        for ($try = 0; $try < 40; $try++) {
            $pt = $M($mm) * 0.75;
            $lines = []; $cur = '';
            foreach (preg_split('/\s+/u', $title) as $w) {
                $test = $cur === '' ? $w : $cur . ' ' . $w;
                $bb = imagettfbbox($pt, 0, $fontL, $test);
                if ($cur !== '' && ($bb[2] - $bb[0]) > $maxW) { $lines[] = $cur; $cur = $w; } else $cur = $test;
            }
            $lines[] = $cur;
            $widest = 0;
            foreach ($lines as $l) { $bb = imagettfbbox($pt, 0, $fontL, $l); $widest = max($widest, $bb[2] - $bb[0]); }
            if (count($lines) <= 3 && $widest <= $maxW) break;
            $mm *= 0.95;
        }
        foreach ($lines as $i => $l) {
            $bb = imagettfbbox($pt, 0, $fontL, $l);
            imagettftext($half, $pt, 0, $M(12.4) - $bb[0], $M(56.8 + $i * $mm * 1.2), $white, $fontL, $l);
        }
    }

    $out = imagecreatetruecolor($W, $H);
    imagecopy($out, $half, 0, $H - $HH, 0, 0, $W, $HH);
    $top = imagerotate($half, 180, 0);
    imagecopy($out, $top, 0, 0, 0, 0, $W, $HH);
    imagedestroy($top); imagedestroy($half);
    $fold = imagecolorallocate($out, 0x3a, 0x4a, 0x6e);
    imagesetthickness($out, max(1, $M(0.2)));
    imageline($out, 0, (int)($H / 2), $W, (int)($H / 2), $fold);
    ob_start();
    imagepng($out, null, 6);
    imagedestroy($out);
    return (string)ob_get_clean();
}

/**
 * Halaman-halaman cetak: 2 nametag berdampingan per lembar landscape + garis bantu potong.
 * $srcs = daftar src gambar (data URI). Return HTML semua lembar.
 */
function ngSheetsHtml(array $srcs, string $paper, bool $forPdf): string
{
    $p = ngPapers()[$paper] ?? ngPapers()['f4'];
    $tw = NG_W_MM; $th = NG_H_MM; $gap = 0;   // 2 nametag menempel (garis potong bersama) supaya tepi kertas longgar (F4: 15 mm, Legal: 28 mm)
    $x1 = ($p['w'] - ($tw * 2 + $gap)) / 2; $x2 = $x1 + $tw + $gap; $y = ($p['h'] - $th) / 2;
    $abs = fn($l, $t, $css) => '<div style="position:absolute;left:' . round($l, 2) . 'mm;top:' . round($t, 2) . 'mm;' . $css . '"></div>';
    $guides = function ($x) use ($y, $tw, $th, $abs) {
        $g = $abs($x, $y, 'width:' . $tw . 'mm;height:' . $th . 'mm;border:0.3mm dashed #e11d48;box-sizing:border-box');
        foreach ([[$x, $y], [$x + $tw, $y], [$x, $y + $th], [$x + $tw, $y + $th]] as $i => [$cx, $cy]) {
            $sx = $i % 2 === 0 ? -1 : 1; $sy = $i < 2 ? -1 : 1;
            $g .= $abs($sx < 0 ? $cx - 6.5 : $cx + 1.5, $cy - 0.12, 'width:5mm;height:0;border-top:0.25mm solid #000');
            $g .= $abs($cx - 0.12, $sy < 0 ? $cy - 6.5 : $cy + 1.5, 'width:0;height:5mm;border-left:0.25mm solid #000');
        }
        $fy = $y + $th / 2;
        $g .= $abs($x - 6.5, $fy - 0.12, 'width:5mm;height:0;border-top:0.25mm dashed #000');
        $g .= $abs($x + $tw + 1.5, $fy - 0.12, 'width:5mm;height:0;border-top:0.25mm dashed #000');
        $g .= '<div style="position:absolute;left:' . round($x + 2, 2) . 'mm;top:' . round($y - 4.2, 2) . 'mm;font:6.5pt Arial,sans-serif;color:#e11d48">'
            . '&#9986; potong di garis putus-putus · 15 × 19,99 cm · lipat di tanda tengah</div>';
        return $g;
    };
    $html = '';
    $pages = array_chunk($srcs, 2);
    foreach ($pages as $pi => $pair) {
        $last = $pi === count($pages) - 1;
        $html .= '<div class="sheet" style="position:relative;width:' . $p['w'] . 'mm;height:' . $p['h'] . 'mm;overflow:hidden;'
               . ($last ? '' : 'page-break-after:always;') . '">';
        foreach ($pair as $j => $src) {
            $x = $j === 0 ? $x1 : $x2;
            $html .= '<img src="' . $src . '" style="position:absolute;left:' . round($x, 2) . 'mm;top:' . round($y, 2) . 'mm;width:' . $tw . 'mm;height:' . $th . 'mm">' . $guides($x);
        }
        $html .= '</div>';
    }
    return $html;
}
