<?php
/**
 * Fitur "Ganti Password PC" (khusus admin): membantu pergantian Password PC semua
 * Desktop PC / Laptop.
 *
 * Alur: buat password baru (otomatis / diketik sendiri) -> export Excel sebagai daftar
 * kerja -> setelah password di PC diganti, "Terapkan ke sistem".
 *
 * SETIAP ASET punya password sendiri (tidak ada yang sama, walau penggunanya sama).
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA: tidak ALTER / DROP tabel lama.
 * - Hanya MEMBUAT 1 tabel BARU jika belum ada: asset_pc_passwords (password PC per aset).
 *   Password di tabel ini yang dipakai aset tersebut; includes/asset_user_sync.php
 *   menyalinnya ke kolom assets.pc_password yang sudah ada, jadi daftar aset, export,
 *   dan cetak tetap bekerja seperti biasa. Aset yang belum punya baris di tabel ini
 *   tetap memakai Password PC dari menu User seperti sebelumnya.
 * - Password baru yang BELUM diterapkan disimpan di file
 *   includes/data/pc_password_draft_assets.json (folder itu ditutup dari akses browser
 *   oleh .htaccess). Format: { "<id aset>": { "new": "...", "at": "YYYY-MM-DD HH:MM:SS" } }
 *
 * Dipakai oleh: pc_password.php
 */

const PCPW_DRAFT_FILE = __DIR__ . '/data/pc_password_draft_assets.json';
const PCPW_MIN_LEN    = 6;
const PCPW_DEFAULT_LEN = 7;   // contoh: kMa249$
const PCPW_LENGTHS    = [6, 7, 8, 10, 12];
const PCPW_MAX_LEN    = 50;
const PCPW_SETS       = ['ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghijkmnpqrstuvwxyz', '23456789', '!@#$%&*?'];

/**
 * Password acak dengan pola tetap: 3 HURUF (campuran besar & kecil) + ANGKA + 1 SIMBOL di akhir.
 * Contoh panjang 7: kMa249$  (panjang 6 = 3 huruf + 2 angka + 1 simbol, dst).
 * Karakter yang mirip (O/0, l/1/I) tidak dipakai supaya tidak salah baca saat diketik ulang.
 */
function pcpwGenerate(int $len = PCPW_DEFAULT_LEN): string
{
    $len = max(PCPW_MIN_LEN, min(PCPW_MAX_LEN, $len));
    [$upper, $lower, $digits, $symbols] = PCPW_SETS;
    $pick = fn(string $set) => $set[random_int(0, strlen($set) - 1)];

    // 3 huruf: selalu ada minimal 1 huruf besar dan 1 huruf kecil, posisinya diacak.
    $letters = [$pick($upper), $pick($lower), $pick($upper . $lower)];
    for ($i = 2; $i > 0; $i--) {
        $j = random_int(0, $i);
        [$letters[$i], $letters[$j]] = [$letters[$j], $letters[$i]];
    }
    $out = implode('', $letters);
    for ($i = 0; $i < $len - 4; $i++) { $out .= $pick($digits); }   // angka di tengah
    return $out . $pick($symbols);                                   // simbol paling akhir
}

/** Buat tabel password per aset jika belum ada (CREATE TABLE IF NOT EXISTS — tidak menyentuh tabel lain). */
function ensurePcpwTable(PDO $db): void
{
    if (assetPcPasswordTableExists($db)) return;
    $db->exec("
        CREATE TABLE IF NOT EXISTS asset_pc_passwords (
            asset_id     INT UNSIGNED NOT NULL PRIMARY KEY,   -- assets.id (tanpa foreign key)
            pc_password  VARCHAR(100) NOT NULL,
            updated_by   INT UNSIGNED DEFAULT NULL,           -- users.id admin yang menerapkan
            updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    assetPcPasswordTableExists($db, true);
}

/** Semua password yang sedang dipakai aset + yang ada di draft (untuk memastikan tidak ada yang sama). */
function pcpwUsedPasswords(PDO $db, array $draft): array
{
    $used = [];
    foreach ($db->query("SELECT pc_password FROM assets WHERE pc_password IS NOT NULL AND pc_password <> ''")->fetchAll(PDO::FETCH_COLUMN) as $p) {
        $used[(string)$p] = true;
    }
    foreach ($draft as $d) { $used[(string)$d['new']] = true; }
    return $used;
}

/** Password acak yang belum dipakai aset mana pun; langsung dicatat ke $used. */
function pcpwGenerateUnique(int $len, array &$used): string
{
    do { $p = pcpwGenerate($len); } while (isset($used[$p]));
    $used[$p] = true;
    return $p;
}

function pcpwMeetsRule(string $p): bool
{
    return strlen($p) >= PCPW_MIN_LEN && preg_match('/[A-Z]/', $p) && preg_match('/[a-z]/', $p)
        && preg_match('/[0-9]/', $p) && preg_match('/[^A-Za-z0-9\s]/', $p);
}

/** Baca draft password baru: [id aset => ['new' => .., 'at' => ..]]. */
function pcpwReadDraft(): array
{
    if (!is_file(PCPW_DRAFT_FILE)) return [];
    $data = json_decode((string)file_get_contents(PCPW_DRAFT_FILE), true);
    if (!is_array($data)) return [];
    $out = [];
    foreach ($data as $uid => $row) {
        if ((int)$uid > 0 && is_array($row) && isset($row['new']) && (string)$row['new'] !== '') {
            $out[(int)$uid] = ['new' => (string)$row['new'], 'at' => (string)($row['at'] ?? '')];
        }
    }
    return $out;
}

function pcpwWriteDraft(array $draft): bool
{
    $dir = dirname(PCPW_DRAFT_FILE);
    if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
    return file_put_contents(PCPW_DRAFT_FILE, json_encode($draft, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX) !== false;
}

/** Jenis aset yang ada di data + departement user. */
function pcpwFilterOptions(PDO $db): array
{
    return [
        'category'   => $db->query("SELECT DISTINCT category FROM assets WHERE category IS NOT NULL AND category <> '' ORDER BY category")->fetchAll(PDO::FETCH_COLUMN),
        'department' => $db->query("SELECT DISTINCT department FROM users WHERE department IS NOT NULL AND department <> '' ORDER BY department")->fetchAll(PDO::FETCH_COLUMN),
    ];
}

/** Jenis aset bawaan saat menu baru dibuka: yang namanya mengandung Desktop / Laptop / PC / Notebook. */
function pcpwDefaultCategories(array $allCategories): array
{
    return array_values(array_filter($allCategories, fn($c) => (bool)preg_match('/desktop|laptop|notebook|\bpc\b/i', (string)$c)));
}

/**
 * Baca saringan dari request ($src = $_GET atau $_POST).
 * Parameter "f" menandai saringan sudah pernah dikirim (kosong = semua); tanpa "f" dipakai bawaan.
 */
function pcpwFilters(array $src, array $options): array
{
    $list = fn(string $k) => array_values(array_unique(array_filter(array_map('trim', (array)($src[$k] ?? [])), fn($v) => $v !== '')));
    $sent = isset($src['f']);
    return [
        'category'   => $sent ? array_values(array_intersect($list('category'), $options['category'])) : pcpwDefaultCategories($options['category']),
        'department' => $sent ? $list('department') : [],
        'cols'       => $sent ? $list('cols') : [],
    ];
}

/** Query string saringan aktif (untuk redirect setelah aksi). */
function pcpwFilterQuery(array $f): string
{
    return http_build_query(['f' => 1, 'category' => $f['category'], 'department' => $f['department'], 'cols' => $f['cols']]);
}

/** Kolom yang bisa dipilih: [key => [label, dicentang bawaan?]]. */
function pcpwColumns(): array
{
    return [
        'category'     => [t('field_category'), true],
        'asset_number' => [t('xls_hdr_asset_id'), true],
        'device_name'  => [t('xls_hdr_device_name'), false],
        'full_name'    => [t('pcpw_col_user'), true],
        'department'   => [t('xls_hdr_department'), true],
        'ip_address'   => [t('xls_hdr_ip'), true],
        'location'     => [t('xls_hdr_location'), true],
        'pc_username'  => [t('xls_hdr_pc_username'), true],
        'old_password' => [t('pcpw_col_old'), true],
        'new_password' => [t('pcpw_col_new'), true],
        'done'         => [t('pcpw_col_done'), false],   // kolom kosong di Excel untuk diparaf / dicentang manual
    ];
}

/**
 * Daftar aset (1 baris = 1 aset = 1 password) + pengguna login PC-nya (user pertama urut nama,
 * sama dengan aturan includes/asset_user_sync.php; aset tanpa pengguna tetap tampil).
 * Baris diurutkan per pengguna supaya aset milik orang yang sama berdekatan.
 */
function pcpwRows(PDO $db, array $f): array
{
    $where = []; $params = [];
    if ($f['category']) {
        $where[] = 'a.category IN (' . implode(',', array_fill(0, count($f['category']), '?')) . ')';
        array_push($params, ...$f['category']);
    }
    $stmt = $db->prepare("SELECT a.id, a.asset_number, a.category, a.device_name, a.department, a.ip_address, a.location,
                                 a.pc_username, a.pc_password
                          FROM assets a" . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . "
                          ORDER BY a.category, a.asset_number");
    $stmt->execute($params);
    $assets = $stmt->fetchAll();
    if (!$assets) return [];

    // User pertama tiap aset (urut nama lalu id).
    $first = [];
    if (assetOwnersTableExists($db)) {
        $ids = array_map('intval', array_column($assets, 'id'));
        $own = $db->prepare("SELECT ao.asset_id, u.id AS user_id, u.full_name, u.department, u.pc_username
                             FROM asset_owners ao JOIN users u ON u.id = ao.user_id
                             WHERE ao.asset_id IN (" . implode(',', array_fill(0, count($ids), '?')) . ")
                             ORDER BY u.full_name, u.id");
        $own->execute($ids);
        foreach ($own->fetchAll() as $o) {
            if (!isset($first[(int)$o['asset_id']])) $first[(int)$o['asset_id']] = $o;
        }
    }

    $rows = [];
    foreach ($assets as $a) {
        $o = $first[(int)$a['id']] ?? null;
        $department = trim((string)($o['department'] ?? '')) !== '' ? trim((string)$o['department']) : trim((string)$a['department']);
        if ($f['department'] && !in_array($department, $f['department'], true)) continue;
        $rows[] = [
            'asset_id'     => (int)$a['id'],
            'user_id'      => $o ? (int)$o['user_id'] : 0,
            'category'     => (string)$a['category'],
            'asset_number' => (string)$a['asset_number'],
            'device_name'  => (string)$a['device_name'],
            'full_name'    => $o ? (string)$o['full_name'] : '',
            'department'   => $department,
            'ip_address'   => (string)$a['ip_address'],
            'location'     => (string)$a['location'],
            'pc_username'  => $o ? (string)$o['pc_username'] : (string)$a['pc_username'],
            'old_password' => (string)$a['pc_password'],
        ];
    }
    // Aset dengan pengguna dulu (urut nama), aset tanpa pengguna di akhir.
    usort($rows, fn($x, $y) => [$x['full_name'] === '' ? 1 : 0, mb_strtolower($x['full_name']), $x['user_id'], $x['category'], $x['asset_number']]
                           <=> [$y['full_name'] === '' ? 1 : 0, mb_strtolower($y['full_name']), $y['user_id'], $y['category'], $y['asset_number']]);
    return $rows;
}

/**
 * Terapkan password baru (dari draft) ke sistem untuk aset-aset tertentu.
 * Menyimpan ke tabel asset_pc_passwords dan kolom assets.pc_password. Return: jumlah aset yang diubah.
 * Panggil ensurePcpwTable() lebih dulu (di luar transaksi).
 */
function pcpwApply(PDO $db, array $assetIds, ?int $adminId = null): int
{
    $draft = pcpwReadDraft();
    $assetIds = array_values(array_unique(array_filter(array_map('intval', $assetIds), fn($id) => isset($draft[$id]))));
    if (!$assetIds) return 0;

    $db->beginTransaction();
    try {
        $del = $db->prepare("DELETE FROM asset_pc_passwords WHERE asset_id = ?");
        $ins = $db->prepare("INSERT INTO asset_pc_passwords (asset_id, pc_password, updated_by) VALUES (?, ?, ?)");
        $upd = $db->prepare("UPDATE assets SET pc_password = ? WHERE id = ?");
        foreach ($assetIds as $aid) {
            $del->execute([$aid]);
            $ins->execute([$aid, $draft[$aid]['new'], $adminId]);
            $upd->execute([$draft[$aid]['new'], $aid]);
        }
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        throw $e;
    }
    foreach ($assetIds as $aid) { unset($draft[$aid]); }
    pcpwWriteDraft($draft); // draft dihapus hanya setelah database berhasil diubah
    return count($assetIds);
}
