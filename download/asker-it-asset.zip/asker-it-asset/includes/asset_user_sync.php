<?php
/**
 * Data User -> Aset (diisi SEKALI di menu User).
 *
 * Departement, Email Pengguna, Username PC & Password PC hanya diisi di form User.
 * Di form Asset cukup mencentang user; nilai ke-4 data itu disalin otomatis dari
 * USER PERTAMA (urut abjad nama, sama dengan urutan daftar centang) ke kolom aset
 * yang SUDAH ADA (assets.department, owner_email, pc_username, pc_password).
 * Struktur database TIDAK diubah; daftar, export Excel & cetak tetap membaca kolom aset.
 *
 * Penyelarasan terjadi saat: aset disimpan, user disimpan/diimport/dihapus,
 * atau lewat halaman sync_asset_user_data.php (sekali untuk data lama).
 * Aset tanpa user (mis. Stok) -> ke-4 kolom dikosongkan.
 */

/** Selaraskan 1 aset dengan data user pertamanya. */
function syncAssetUserData(PDO $db, int $assetId): void
{
    $first = null;
    if (assetOwnersTableExists($db)) {
        $stmt = $db->prepare("
            SELECT u.department, u.email, u.pc_username, u.pc_password
            FROM asset_owners ao JOIN users u ON u.id = ao.user_id
            WHERE ao.asset_id = ? ORDER BY u.full_name, u.id LIMIT 1
        ");
        $stmt->execute([$assetId]);
        $first = $stmt->fetch() ?: null;
    }
    $val = fn($k) => ($first && trim((string)$first[$k]) !== '') ? trim((string)$first[$k]) : null;
    // Password PC per aset (menu Ganti Password PC) didahulukan dari Password PC milik user.
    $pcPassword = assetPcPasswordOverride($db, $assetId) ?? $val('pc_password');
    $db->prepare("UPDATE assets SET department = ?, owner_email = ?, pc_username = ?, pc_password = ? WHERE id = ?")
       ->execute([$val('department'), $val('email'), $val('pc_username'), $pcPassword, $assetId]);
}

/** Tabel asset_pc_passwords (password PC per aset, dibuat oleh menu Ganti Password PC) sudah ada? */
function assetPcPasswordTableExists(PDO $db, bool $refresh = false): bool
{
    static $exists = null;
    if ($exists === null || $refresh) {
        $exists = (bool)$db->query("SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_pc_passwords'")->fetchColumn();
    }
    return $exists;
}

/** Password PC khusus 1 aset, atau null jika aset itu belum punya (maka dipakai password dari user). */
function assetPcPasswordOverride(PDO $db, int $assetId): ?string
{
    if (!assetPcPasswordTableExists($db)) return null;
    $stmt = $db->prepare("SELECT pc_password FROM asset_pc_passwords WHERE asset_id = ?");
    $stmt->execute([$assetId]);
    $p = $stmt->fetchColumn();
    return ($p !== false && (string)$p !== '') ? (string)$p : null;
}

/** Id aset yang dipakai oleh user-user tertentu. */
function assetIdsOfUsers(PDO $db, array $userIds): array
{
    $userIds = array_values(array_filter(array_map('intval', $userIds)));
    if (!$userIds || !assetOwnersTableExists($db)) return [];
    $ph = implode(',', array_fill(0, count($userIds), '?'));
    $stmt = $db->prepare("SELECT DISTINCT asset_id FROM asset_owners WHERE user_id IN ($ph)");
    $stmt->execute($userIds);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

/** Selaraskan banyak aset sekaligus. */
function syncAssetsUserData(PDO $db, array $assetIds): int
{
    $n = 0;
    foreach (array_unique(array_map('intval', $assetIds)) as $aid) {
        if ($aid > 0) { syncAssetUserData($db, $aid); $n++; }
    }
    return $n;
}
