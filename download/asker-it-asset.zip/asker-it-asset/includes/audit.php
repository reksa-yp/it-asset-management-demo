<?php
/**
 * Export Audit (khusus admin): admin memilih sumber data, lalu mencentang sendiri
 * kolom apa saja yang ikut diekspor ke Excel (mis. Jenis Aset, Pengguna, Departement,
 * IP, Lokasi, Password PC).
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA: hanya MEMBACA (SELECT). Tidak membuat / mengubah
 * tabel apa pun. Tabel fitur tambahan (stok, mutasi, aset rusak, dll) yang belum ada di
 * server otomatis dilewati.
 *
 * Password LOGIN aplikasi (users.password) tidak pernah ikut diekspor. Yang bisa dipilih
 * hanya Username/Password PC (data referensi IT), dan kolom itu tidak dicentang otomatis.
 *
 * Dipakai oleh: audit_export.php
 */

require_once __DIR__ . '/stock.php';
require_once __DIR__ . '/mutation.php';
require_once __DIR__ . '/damage.php';

function auditTableExists(PDO $db, string $table): bool
{
    static $cache = [];
    if (!isset($cache[$table])) {
        $st = $db->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
        $st->execute([$table]);
        $cache[$table] = (bool)$st->fetchColumn();
    }
    return $cache[$table];
}

function auditDate($v, string $fmt = 'Y-m-d'): string
{
    if ($v === null || $v === '' || strpos((string)$v, '0000-00-00') === 0) return '';
    $ts = strtotime((string)$v);
    return $ts ? date($fmt, $ts) : '';
}

/**
 * Definisi semua sumber data + kolomnya.
 * Tiap kolom: [label, fungsi pengambil nilai, dicentang bawaan?, sensitif?]
 */
function auditDatasets(): array
{
    $assetStatus = ['Digunakan' => t('status_used'), 'Stok' => t('status_stock'), 'Tidak Digunakan' => t('status_unused')];
    $col = fn(string $label, callable $get, bool $default = true, bool $sensitive = false)
        => ['label' => $label, 'get' => $get, 'default' => $default, 'sensitive' => $sensitive];
    $f = fn(string $k) => fn(array $r) => (string)($r[$k] ?? '');

    return [
        'assets' => [
            'label'   => t('audit_ds_assets'),
            'filters' => ['category', 'department', 'status'],
            'columns' => [
                'asset_number'  => $col(t('xls_hdr_asset_id'), $f('asset_number')),
                'category'      => $col(t('field_category'), $f('category')),
                'device_name'   => $col(t('xls_hdr_device_name'), $f('device_name')),
                'owners'        => $col(t('audit_col_owner'), $f('owner_names')),
                'owner_positions' => $col(t('xls_hdr_position'), $f('owner_positions')),
                'department'    => $col(t('xls_hdr_department'), $f('department')),
                'owner_email'   => $col(t('xls_hdr_user_email'), $f('owner_email'), false),
                'ip_address'    => $col(t('xls_hdr_ip'), $f('ip_address')),
                'hostname'      => $col(t('xls_hdr_hostname'), $f('hostname'), false),
                'location'      => $col(t('xls_hdr_location'), $f('location')),
                'status'        => $col(t('xls_hdr_status'), fn($r) => $assetStatus[$r['status'] ?? ''] ?? (string)($r['status'] ?? '')),
                'serial_number' => $col(t('xls_hdr_serial'), $f('serial_number'), false),
                'motherboard_brand' => $col(t('xls_hdr_motherboard'), $f('motherboard_brand'), false),
                'processor'     => $col(t('xls_hdr_processor'), $f('processor'), false),
                'ram'           => $col(t('xls_hdr_ram'), $f('ram'), false),
                'storage'       => $col(t('xls_hdr_storage'), $f('storage'), false),
                'os_name'       => $col(t('xls_hdr_os'), $f('os_name'), false),
                'os_status'     => $col(t('xls_hdr_os_status'), $f('os_status'), false),
                'software'      => $col(t('xls_hdr_software'), $f('software_names'), false),
                'software_status' => $col(t('xls_hdr_software_status'), $f('software_statuses'), false),
                'printer_info'  => $col(t('xls_hdr_printer'), $f('printer_info'), false),
                'monitor_info'  => $col(t('xls_hdr_monitor'), $f('monitor_info'), false),
                'accessories'   => $col(t('xls_hdr_accessories'), $f('accessories'), false),
                'purchase_date' => $col(t('xls_hdr_purchase_date'), fn($r) => auditDate($r['purchase_date'] ?? null), false),
                'tablet_id'     => $col(t('tablet_lbl_id'), $f('tablet_id'), false),
                'tablet_condition' => $col(t('xls_hdr_tablet_condition'), $f('tablet_condition'), false),
                'pc_username'   => $col(t('xls_hdr_pc_username'), $f('pc_username'), false, true),
                'pc_password'   => $col(t('xls_hdr_pc_password'), $f('pc_password'), false, true),
                'created_at'    => $col(t('xls_hdr_input_date'), fn($r) => auditDate($r['created_at'] ?? null), false),
                'updated_at'    => $col(t('xls_hdr_updated_at'), fn($r) => auditDate($r['updated_at'] ?? null, 'Y-m-d H:i'), false),
            ],
        ],
        'users' => [
            'label'   => t('audit_ds_users'),
            'filters' => ['department', 'role'],
            'columns' => [
                'full_name'   => $col(t('audit_col_full_name'), $f('full_name')),
                'username'    => $col(t('audit_col_username'), $f('username')),
                'email'       => $col(t('audit_col_email'), $f('email')),
                'department'  => $col(t('xls_hdr_department'), $f('department')),
                'position'    => $col(t('xls_hdr_position'), $f('position')),
                'role'        => $col(t('audit_col_role'), fn($r) => ($r['role'] ?? '') === 'admin' ? t('role_admin') : t('role_user')),
                'is_active'   => $col(t('audit_col_active'), fn($r) => !empty($r['is_active']) ? t('audit_yes') : t('audit_no')),
                'asset_count' => $col(t('audit_col_asset_count'), fn($r) => (string)(int)($r['asset_count'] ?? 0)),
                'asset_list'  => $col(t('audit_col_asset_list'), $f('asset_list')),
                'pc_username' => $col(t('xls_hdr_pc_username'), $f('pc_username'), false, true),
                'pc_password' => $col(t('xls_hdr_pc_password'), $f('pc_password'), false, true),
                'created_at'  => $col(t('audit_col_registered'), fn($r) => auditDate($r['created_at'] ?? null), false),
            ],
        ],
        'tickets' => [
            'label'   => t('audit_ds_tickets'),
            'filters' => ['date'],
            'columns' => [
                'ticket_number'  => $col(t('xls_hdr_ticket_no'), $f('ticket_number')),
                'created_at'     => $col(t('xls_hdr_created_at'), fn($r) => auditDate($r['created_at'] ?? null, 'Y-m-d H:i')),
                'pelapor'        => $col(t('xls_hdr_reporter'), $f('pelapor')),
                'department'     => $col(t('xls_hdr_department'), $f('pelapor_department')),
                'location'       => $col(t('xls_hdr_location'), $f('pelapor_location')),
                'asset_number'   => $col(t('xls_hdr_related_asset'), $f('asset_number')),
                'problem_detail' => $col(t('xls_hdr_problem_detail'), $f('problem_detail')),
                'status'         => $col(t('xls_hdr_status'), fn($r) => ticketStatusLabels()[$r['status'] ?? ''] ?? (string)($r['status'] ?? '')),
                'handler'        => $col(t('xls_hdr_handled_by'), $f('handler')),
                'work_detail'    => $col(t('xls_hdr_work_detail'), $f('work_detail'), false),
                'asset_check'    => $col(t('xls_hdr_asset_check'), $f('asset_check'), false),
                'resolved_at'    => $col(t('xls_hdr_resolved_at'), fn($r) => auditDate($r['resolved_at'] ?? null, 'Y-m-d H:i'), false),
            ],
        ],
        'mutations' => [
            'label'   => t('audit_ds_mutations'),
            'filters' => ['date'],
            'columns' => [
                'mutation_number' => $col(t('audit_col_mut_number'), $f('mutation_number')),
                'mutation_date'   => $col(t('audit_col_date'), fn($r) => auditDate($r['mutation_date'] ?? null)),
                'asset_number'    => $col(t('xls_hdr_asset_id'), $f('asset_number')),
                'asset_category'  => $col(t('field_category'), $f('asset_category')),
                'asset_name'      => $col(t('xls_hdr_device_name'), $f('asset_name')),
                'from_user'       => $col(t('audit_col_from_user'), fn($r) => mutationPartyLabel($r['from_user_names'] ?? '')),
                'from_department' => $col(t('audit_col_from_dept'), $f('from_department')),
                'from_location'   => $col(t('audit_col_from_loc'), $f('from_location'), false),
                'to_user'         => $col(t('audit_col_to_user'), fn($r) => mutationPartyLabel($r['to_user_names'] ?? '')),
                'to_department'   => $col(t('audit_col_to_dept'), $f('to_department')),
                'to_location'     => $col(t('audit_col_to_loc'), $f('to_location'), false),
                'reason'          => $col(t('audit_col_reason'), fn($r) => mutationReasonLabel((string)($r['reason'] ?? ''))),
                'asset_condition' => $col(t('audit_col_condition'), fn($r) => mutationConditionLabel((string)($r['asset_condition'] ?? '')), false),
                'note'            => $col(t('audit_col_note'), $f('note'), false),
                'created_by_name' => $col(t('audit_col_recorded_by'), $f('created_by_name'), false),
            ],
        ],
        'damages' => [
            'label'   => t('audit_ds_damages'),
            'filters' => ['date'],
            'columns' => [
                'asset_number'     => $col(t('xls_hdr_asset_id'), $f('asset_number')),
                'asset_category'   => $col(t('field_category'), $f('asset_category')),
                'asset_name'       => $col(t('xls_hdr_device_name'), $f('asset_name')),
                'damage_date'      => $col(t('audit_col_damage_date'), fn($r) => auditDate($r['damage_date'] ?? null)),
                'issue'            => $col(t('audit_col_issue'), $f('issue')),
                'storage_location' => $col(t('audit_col_storage'), $f('storage_location')),
                'last_user_names'  => $col(t('audit_col_last_user'), $f('last_user_names')),
                'last_department'  => $col(t('audit_col_last_dept'), $f('last_department')),
                'state'            => $col(t('xls_hdr_status'), fn($r) => damageStateLabel((string)($r['state'] ?? ''))),
                'closed_date'      => $col(t('audit_col_closed_date'), fn($r) => auditDate($r['closed_date'] ?? null), false),
                'note'             => $col(t('audit_col_note'), $f('note'), false),
                'created_by_name'  => $col(t('audit_col_recorded_by'), $f('created_by_name'), false),
            ],
        ],
        'stock' => [
            'label'   => t('audit_ds_stock'),
            'filters' => ['date'],
            'columns' => [
                'trx_date'      => $col(t('audit_col_date'), fn($r) => auditDate($r['trx_date'] ?? null)),
                'type'          => $col(t('audit_col_trx_type'), fn($r) => ($r['type'] ?? '') === 'in' ? t('stock_type_in') : t('stock_type_out')),
                'category_name' => $col(t('audit_col_item_category'), $f('category_name')),
                'item_name'     => $col(t('audit_col_item_name'), $f('item_name')),
                'qty'           => $col(t('audit_col_qty'), fn($r) => (string)(int)($r['qty'] ?? 0)),
                'unit'          => $col(t('audit_col_unit'), $f('unit')),
                'recipient_name' => $col(t('audit_col_recipient'), $f('recipient_name')),
                'recipient_department' => $col(t('audit_col_recipient_dept'), $f('recipient_department')),
                'note'          => $col(t('audit_col_note'), $f('note'), false),
            ],
        ],
    ];
}

/** Baca filter dari $_GET. */
function auditFilters(): array
{
    $list = fn(string $k) => array_values(array_unique(array_filter(array_map('trim', (array)($_GET[$k] ?? [])), fn($v) => $v !== '')));
    $date = fn(string $k) => preg_match('/^\d{4}-\d{2}-\d{2}$/', trim((string)($_GET[$k] ?? ''))) ? trim((string)$_GET[$k]) : '';
    return [
        'category'   => $list('category'),
        'department' => $list('department'),
        'status'     => in_array($_GET['status'] ?? '', ['Digunakan', 'Stok', 'Tidak Digunakan'], true) ? $_GET['status'] : '',
        'role'       => in_array($_GET['role'] ?? '', ['admin', 'user'], true) ? $_GET['role'] : '',
        'from'       => $date('from'),
        'to'         => $date('to'),
    ];
}

/** Pilihan isi filter (jenis aset & departement yang ada di data). */
function auditFilterOptions(PDO $db): array
{
    $cats = $db->query("SELECT DISTINCT category FROM assets WHERE category IS NOT NULL AND category <> '' ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
    $deps = $db->query("
        SELECT department FROM assets WHERE department IS NOT NULL AND department <> ''
        UNION
        SELECT department FROM users WHERE department IS NOT NULL AND department <> ''
        ORDER BY department
    ")->fetchAll(PDO::FETCH_COLUMN);
    return ['category' => $cats, 'department' => $deps];
}

function auditIn(string $column, array $values, array &$where, array &$params): void
{
    if (!$values) return;
    $where[] = "$column IN (" . implode(',', array_fill(0, count($values), '?')) . ")";
    array_push($params, ...$values);
}

function auditDateRange(string $column, array $f, array &$where, array &$params): void
{
    if ($f['from'] !== '') { $where[] = "$column >= ?"; $params[] = $f['from'] . ' 00:00:00'; }
    if ($f['to'] !== '')   { $where[] = "$column <= ?"; $params[] = $f['to'] . ' 23:59:59'; }
}

/** Ambil baris data 1 sumber data sesuai filter. Return: ['rows' => [...], 'missing' => bool]. */
function auditFetch(PDO $db, string $dataset, array $f): array
{
    $where = []; $params = [];
    $run = function (string $sql) use ($db, &$where, &$params): array {
        $st = $db->prepare(str_replace('{WHERE}', $where ? ' WHERE ' . implode(' AND ', $where) : '', $sql));
        $st->execute($params);
        return $st->fetchAll();
    };

    switch ($dataset) {
        case 'assets':
            auditIn('a.category', $f['category'], $where, $params);
            auditIn('a.department', $f['department'], $where, $params);
            if ($f['status'] !== '') { $where[] = 'a.status = ?'; $params[] = $f['status']; }
            $rows = $run("SELECT a.* FROM assets a{WHERE} ORDER BY a.category, a.asset_number");
            $ids = array_column($rows, 'id');
            $owners   = getAssetOwnersMap($db, $ids);
            $software = getAssetSoftwareMap($db, $ids);
            $tablets  = getTabletDetailsMap($db, $ids);
            $positions = getUserPositionMap($db);
            foreach ($rows as &$r) {
                $id = (int)$r['id'];
                $r['owner_names']       = ownerNamesLabel($owners[$id] ?? []);
                $r['owner_positions']   = ownerPositionsLabel($owners[$id] ?? [], $positions);
                $r['software_names']    = implode(', ', array_column($software[$id] ?? [], 'software_name'));
                $r['software_statuses'] = implode(', ', array_map(fn($s) => $s['software_name'] . ': ' . $s['status'], $software[$id] ?? []));
                $r['tablet_id']         = $tablets[$id]['tablet_id'] ?? '';
                $cond = $tablets[$id]['tablet_condition'] ?? '';
                $r['tablet_condition']  = $cond === '' ? '' : ($cond === 'Rusak' ? t('tablet_cond_bad') : t('tablet_cond_good'));
            }
            unset($r);
            return ['rows' => $rows, 'missing' => false];

        case 'users':
            auditIn('u.department', $f['department'], $where, $params);
            if ($f['role'] !== '') { $where[] = 'u.role = ?'; $params[] = $f['role']; }
            $rows = $run("SELECT u.* FROM users u{WHERE} ORDER BY u.full_name");
            $assetsByUser = [];
            $userPositions = getUserPositionMap($db);
            if (assetOwnersTableExists($db)) {
                foreach ($db->query("SELECT ao.user_id, a.asset_number FROM asset_owners ao JOIN assets a ON a.id = ao.asset_id ORDER BY a.asset_number") as $x) {
                    $assetsByUser[(int)$x['user_id']][] = $x['asset_number'];
                }
            }
            foreach ($rows as &$r) {
                unset($r['password']); // password login aplikasi tidak pernah ikut diekspor
                $r['position'] = $userPositions[(int)$r['id']] ?? '';
                $list = $assetsByUser[(int)$r['id']] ?? [];
                $r['asset_count'] = count($list);
                $r['asset_list']  = implode(', ', $list);
            }
            unset($r);
            return ['rows' => $rows, 'missing' => false];

        case 'tickets':
            auditDateRange('t.created_at', $f, $where, $params);
            $hasWd = auditTableExists($db, 'ticket_work_details');
            $rows = $run("
                SELECT t.*, u.full_name AS pelapor, u.department AS user_department,
                       a.asset_number, a.department AS asset_department, a.location AS asset_location,
                       h.full_name AS handler" . ($hasWd ? ", wd.work_detail, wd.asset_check" : "") . "
                FROM tickets t
                JOIN users u ON u.id = t.reported_by
                LEFT JOIN assets a ON a.id = t.asset_id
                LEFT JOIN users h ON h.id = t.handled_by" . ($hasWd ? "
                LEFT JOIN ticket_work_details wd ON wd.ticket_id = t.id" : "") . "{WHERE}
                ORDER BY t.created_at DESC");
            $rows = applyTicketCancellations($db, $rows);
            foreach ($rows as &$r) {
                $info = ticketReporterDeptLocation($db, $r);
                $r['pelapor_department'] = $info['department'];
                $r['pelapor_location']   = $info['location'];
            }
            unset($r);
            return ['rows' => $rows, 'missing' => false];

        case 'mutations':
            if (!mutationTableExists($db)) return ['rows' => [], 'missing' => true];
            auditDateRange('m.mutation_date', $f, $where, $params);
            return ['rows' => $run("SELECT m.* FROM asset_mutations m{WHERE} ORDER BY m.mutation_date DESC, m.id DESC"), 'missing' => false];

        case 'damages':
            if (!damageTableExists($db)) return ['rows' => [], 'missing' => true];
            auditDateRange('d.damage_date', $f, $where, $params);
            return ['rows' => $run("SELECT d.* FROM asset_damages d{WHERE} ORDER BY d.damage_date DESC, d.id DESC"), 'missing' => false];

        case 'stock':
            if (!stockTablesExist($db)) return ['rows' => [], 'missing' => true];
            auditDateRange('t.trx_date', $f, $where, $params);
            return ['rows' => $run("
                SELECT t.*, c.name AS category_name, c.unit
                FROM stock_transactions t JOIN stock_categories c ON c.id = t.category_id{WHERE}
                ORDER BY t.trx_date DESC, t.id DESC"), 'missing' => false];
    }
    return ['rows' => [], 'missing' => true];
}

/** Ubah baris data menjadi tabel sesuai kolom yang dipilih: [header[], rows[][]]. */
function auditBuildTable(array $datasetDef, array $columnKeys, array $rows): array
{
    $cols = [];
    foreach (array_keys($datasetDef['columns']) as $k) {          // urutan mengikuti definisi
        if (in_array($k, $columnKeys, true)) $cols[$k] = $datasetDef['columns'][$k];
    }
    $headers = array_values(array_map(fn($c) => $c['label'], $cols));
    $out = [];
    foreach ($rows as $r) {
        $line = [];
        foreach ($cols as $c) { $line[] = (string)($c['get'])($r); }
        $out[] = $line;
    }
    return [$headers, $out];
}

/** Ringkasan filter aktif, ditulis di bagian atas file Excel. */
function auditFilterSummary(array $datasetDef, array $f): string
{
    $parts = [];
    $has = fn(string $k) => in_array($k, $datasetDef['filters'], true);
    if ($has('category') && $f['category'])     $parts[] = t('field_category') . ': ' . implode(', ', $f['category']);
    if ($has('department') && $f['department']) $parts[] = t('xls_hdr_department') . ': ' . implode(', ', $f['department']);
    if ($has('status') && $f['status'] !== '')  $parts[] = t('xls_hdr_status') . ': ' . $f['status'];
    if ($has('role') && $f['role'] !== '')      $parts[] = t('audit_col_role') . ': ' . ($f['role'] === 'admin' ? t('role_admin') : t('role_user'));
    if ($has('date') && ($f['from'] !== '' || $f['to'] !== '')) {
        $parts[] = t('audit_period') . ': ' . ($f['from'] !== '' ? $f['from'] : '…') . ' – ' . ($f['to'] !== '' ? $f['to'] : '…');
    }
    return $parts ? implode(' | ', $parts) : t('audit_filter_none');
}
