<?php
/** Tab "Nametag tamu" di nametag.php (khusus admin). Variabel dari nametag.php: $h, $msg. */
require_once __DIR__ . '/nametag_guest.php';
$ng = $_SESSION['nt_guest'] ?? ['paper' => 'f4', 'rows' => []];
$ngRows = $ng['rows'] ?: [['name' => '', 'title' => '']];
$ngPapers = ngPapers();
$ngLogo = function_exists('appLogoDataUri') ? appLogoDataUri() : '';   // logo aplikasi (Pengaturan Sistem), kosong = pita polos
?>
<div class="max-w-6xl mx-auto">
<div class="mb-3">
    <h1 class="text-xl font-semibold text-slate-800"><?= $h(ntL('Nametag Tamu', 'Guest Name Tags')) ?></h1>
    <p class="text-sm text-slate-500"><?= $h(ntL('Nametag meja untuk tamu, 15 × 19,99 cm (dilipat dua). Isi banyak nama sekaligus, cetak 2 nametag per lembar F4 / Legal.', 'Desk name tags for guests, 15 × 19.99 cm (folded). Enter many names, print 2 per F4 / Legal sheet.')) ?></p>
</div>
<?php if ($msg): ?>
<div class="mb-3 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['msg']) ?></div>
<?php endif; ?>

<form method="post" action="nametag_guest_print.php" id="ngForm" class="grid gap-4 lg:grid-cols-[minmax(0,27rem)_minmax(0,1fr)] items-start">
    <input type="hidden" name="csrf_token" value="<?= $h(csrfToken()) ?>">
    <section class="bg-white rounded-xl shadow-sm p-4 flex flex-col gap-4 text-sm min-w-0">
        <div>
            <span class="block text-xs font-semibold text-slate-500 mb-1.5"><?= $h(ntL('Ukuran kertas', 'Paper size')) ?></span>
            <div class="grid grid-cols-2 gap-2">
                <?php foreach ($ngPapers as $k => $p): ?>
                <label class="flex gap-2 items-start border rounded-lg px-3 py-2 cursor-pointer has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50">
                    <input type="radio" name="paper" value="<?= $k ?>" <?= $ng['paper'] === $k ? 'checked' : '' ?> class="mt-1">
                    <span><b class="block text-slate-800"><?= $h($p['name']) ?></b><span class="text-xs text-slate-500"><?= $h($p['size']) ?></span></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        <div>
            <div class="flex items-end justify-between mb-1.5">
                <span class="text-xs font-semibold text-slate-500"><?= $h(ntL('Daftar tamu', 'Guest list')) ?> <span id="ngCount"></span></span>
                <button type="button" id="ngAdd" class="border border-slate-300 rounded-lg px-2.5 py-1 text-xs font-medium hover:bg-slate-50">+ <?= $h(ntL('Tambah baris', 'Add row')) ?></button>
            </div>
            <div class="grid grid-cols-[1.4rem_minmax(0,1fr)_minmax(0,1fr)_2rem] gap-1.5 text-xs text-slate-400 mb-1"><span></span><span><?= $h(ntL('Nama', 'Name')) ?></span><span><?= $h(ntL('Jabatan / perusahaan', 'Title / company')) ?></span><span></span></div>
            <div id="ngRows" class="flex flex-col gap-1.5 max-h-[22rem] overflow-y-auto pr-1">
                <?php foreach ($ngRows as $r): ?>
                <div class="ng-row grid grid-cols-[1.4rem_minmax(0,1fr)_minmax(0,1fr)_2rem] gap-1.5 items-center">
                    <span class="ng-no text-xs text-slate-400 text-right tabular-nums"></span>
                    <input name="names[]" value="<?= $h($r['name']) ?>" maxlength="80" placeholder="<?= $h(ntL('Nama tamu', 'Guest name')) ?>" class="border border-slate-300 rounded-lg px-2.5 py-1.5 w-full">
                    <input name="titles[]" value="<?= $h($r['title']) ?>" maxlength="120" placeholder="<?= $h(ntL('Jabatan - Perusahaan', 'Title - Company')) ?>" class="border border-slate-300 rounded-lg px-2.5 py-1.5 w-full">
                    <button type="button" class="ng-del text-red-600 text-lg leading-none rounded hover:bg-red-50 h-8" title="<?= $h(ntL('Hapus baris', 'Remove row')) ?>">&times;</button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <details class="border-t pt-3">
            <summary class="cursor-pointer font-medium text-slate-700"><?= $h(ntL('Tempel banyak nama sekaligus', 'Paste many names')) ?></summary>
            <div class="flex flex-col gap-2 mt-2">
                <textarea id="ngBulk" rows="4" class="border border-slate-300 rounded-lg px-2.5 py-2 w-full" placeholder="<?= $h(ntL("Satu tamu per baris: Nama ; Jabatan\nDo Younghak ; MP Team - TP Group", "One guest per line: Name ; Title")) ?>"></textarea>
                <span class="text-xs text-slate-400"><?= $h(ntL('Pisahkan nama dan jabatan dengan titik koma ( ; ) atau Tab. Bisa ditempel langsung dari Excel (2 kolom).', 'Separate name and title with ; or Tab. You can paste two Excel columns.')) ?></span>
                <div><button type="button" id="ngBulkAdd" class="border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-medium hover:bg-slate-50"><?= $h(ntL('Tambahkan ke daftar', 'Add to list')) ?></button></div>
            </div>
        </details>
        <p class="text-xs text-slate-400"><?= $h(ntL('Maks. ' . NG_MAX . ' nama sekali cetak. Daftar terakhir diingat selama Anda login.', 'Up to ' . NG_MAX . ' names per print. The last list is kept while you are logged in.')) ?></p>
    </section>

    <section class="bg-white rounded-xl shadow-sm p-4 min-w-0">
        <div class="flex flex-wrap justify-between gap-2 text-sm mb-3">
            <span><b id="ngTags" class="tabular-nums">0</b> nametag · <b id="ngPages" class="tabular-nums">0</b> <?= $h(ntL('lembar', 'sheets')) ?> <span id="ngPaperName"></span></span>
            <span class="text-xs text-slate-500"><?= $h(ntL('2 nametag per lembar, landscape', '2 per sheet, landscape')) ?></span>
        </div>
        <div id="ngPreview" class="flex flex-col gap-4 bg-slate-200 rounded-xl p-4 max-h-[44rem] overflow-y-auto"></div>
        <div class="mt-4 rounded-xl border border-amber-300 bg-amber-50 text-amber-800 px-4 py-3 text-sm flex gap-3 leading-relaxed">
            <span aria-hidden="true">⚠️</span><span id="ngWarn"></span>
        </div>
        <div class="flex flex-wrap gap-2 mt-4">
            <button type="submit" name="go" value="print" class="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2 font-medium"><?= icon('printer', 'w-4 h-4') ?> <?= $h(ntL('Cetak semua', 'Print all')) ?></button>
            <button type="submit" name="go" value="pdf" class="inline-flex items-center gap-2 border border-slate-300 hover:bg-slate-50 rounded-lg px-4 py-2 font-medium"><?= icon('download', 'w-4 h-4') ?> <?= $h(ntL('Simpan PDF', 'Save PDF')) ?></button>
        </div>
    </section>
</form>
</div>
<script>
(function () {
    var IMG = <?= json_encode(['logo' => $ngLogo]) ?>;
    var PAPERS = <?= json_encode(array_map(fn($p) => ['w' => $p['w'], 'h' => $p['h'], 'name' => $p['name'], 'short' => $p['short'], 'size' => $p['size']], $ngPapers)) ?>;
    var MAX = <?= NG_MAX ?>, TW = 150, TH = 199.9, HF = TH / 2;
    var rowsBox = document.getElementById('ngRows'), form = document.getElementById('ngForm');
    function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
    function rows() {
        return Array.prototype.map.call(rowsBox.querySelectorAll('.ng-row'), function (r) {
            var i = r.querySelectorAll('input'); return {n: i[0].value.trim(), j: i[1].value.trim()};
        }).filter(function (r) { return r.n; });
    }
    function half(r) {
        return '<rect width="150" height="83.4" fill="#222e47"/><rect y="83.4" width="150" height="16.55" fill="#fff"/>'
            + '<text class="nm" x="12.2" y="41" fill="#fff" font-family="NtTagB, Arial, sans-serif" font-size="<?= round(NG_NAME_PT * 25.4 / 72, 3) ?>">' + esc(r.n) + '</text>'
            + '<text class="jb" x="12.4" y="56.8" fill="#fff" font-family="NtTagL, Arial, sans-serif" font-size="<?= round(NG_TITLE_PT * 25.4 / 72, 3) ?>" data-t="' + esc(r.j) + '"></text>'
            + (IMG.logo ? '<image href="' + IMG.logo + '" x="4.6" y="86.8" width="34.8" height="8.3" preserveAspectRatio="xMinYMid meet"/>' : '');
    }
    function tag(r, x, y) {
        return '<g transform="translate(' + x + ',' + y + ')"><g transform="translate(0,' + HF + ')">' + half(r) + '</g>'
            + '<g transform="rotate(180 75 ' + (HF / 2) + ')">' + half(r) + '</g>'
            + '<line x1="0" y1="' + HF + '" x2="150" y2="' + HF + '" stroke="#3a4a6e" stroke-width="0.2"/></g>';
    }
    function guides(x, y) {
        var o = '<rect x="' + x + '" y="' + y + '" width="' + TW + '" height="' + TH + '" fill="none" stroke="#e11d48" stroke-width="0.3" stroke-dasharray="2.2 1.4"/>'
            + '<text x="' + (x + 2) + '" y="' + (y - 1.6) + '" font-size="2.6" fill="#e11d48" font-family="Segoe UI,Arial">✂ potong di garis putus-putus · 15 × 19,99 cm</text>'
            + '<line x1="' + (x - 6.5) + '" y1="' + (y + HF) + '" x2="' + (x - 1.5) + '" y2="' + (y + HF) + '" stroke="#111" stroke-width="0.25" stroke-dasharray="1 0.8"/>'
            + '<line x1="' + (x + TW + 1.5) + '" y1="' + (y + HF) + '" x2="' + (x + TW + 6.5) + '" y2="' + (y + HF) + '" stroke="#111" stroke-width="0.25" stroke-dasharray="1 0.8"/>';
        [[x, y], [x + TW, y], [x, y + TH], [x + TW, y + TH]].forEach(function (p, i) {
            var sx = i % 2 === 0 ? -1 : 1, sy = i < 2 ? -1 : 1;
            o += '<line x1="' + (p[0] + sx * 1.5) + '" y1="' + p[1] + '" x2="' + (p[0] + sx * 6.5) + '" y2="' + p[1] + '" stroke="#111" stroke-width="0.25"/>'
               + '<line x1="' + p[0] + '" y1="' + (p[1] + sy * 1.5) + '" x2="' + p[0] + '" y2="' + (p[1] + sy * 6.5) + '" stroke="#111" stroke-width="0.25"/>';
        });
        return o;
    }
    function render() {
        var key = (form.querySelector('input[name="paper"]:checked') || {}).value || 'f4', P = PAPERS[key], list = rows();
        var x1 = (P.w - TW * 2) / 2, x2 = x1 + TW, y = (P.h - TH) / 2, html = '';
        for (var i = 0; i < Math.max(1, list.length); i += 2) {
            var a = list[i], b = list[i + 1];
            html += '<div class="bg-white shadow mx-auto w-full"><svg viewBox="0 0 ' + P.w + ' ' + P.h + '" class="block w-full h-auto" xmlns="http://www.w3.org/2000/svg">'
                + (a ? tag(a, x1, y) + guides(x1, y) : '<text x="' + (x1 + 75) + '" y="' + (P.h / 2) + '" text-anchor="middle" font-size="6" fill="#94a3b8">Belum ada nama</text>')
                + (b ? tag(b, x2, y) + guides(x2, y) : '') + '</svg></div>'
                + '<div class="text-center text-xs text-slate-500 -mt-2">Lembar ' + (i / 2 + 1) + ' · ' + P.short + ' landscape</div>';
        }
        var box = document.getElementById('ngPreview');
        box.innerHTML = html;
        box.querySelectorAll('text.nm').forEach(function (t) {
            var max = 150 - 12.2 - 6, fs = +t.getAttribute('font-size'), n = 0;
            while (t.getComputedTextLength() > max && fs > 2 && n++ < 60) { fs *= 0.96; t.setAttribute('font-size', fs); }
        });
        // Jabatan: terlalu panjang -> baris baru (maks. 3 baris, baru diperkecil bila masih tidak muat).
        box.querySelectorAll('text.jb').forEach(function (t) {
            var words = (t.getAttribute('data-t') || '').split(/\s+/).filter(Boolean), max = 150 - 12.4 - 6, fs = +t.getAttribute('font-size');
            if (!words.length) return;
            var NS = 'http://www.w3.org/2000/svg';
            function layout() {
                while (t.firstChild) t.removeChild(t.firstChild);
                t.setAttribute('font-size', fs);
                var lines = [], cur = '', probe = document.createElementNS(NS, 'tspan');
                t.appendChild(probe);
                words.forEach(function (w) {
                    var test = cur ? cur + ' ' + w : w; probe.textContent = test;
                    if (cur && probe.getComputedTextLength() > max) { lines.push(cur); cur = w; } else cur = test;
                });
                lines.push(cur); t.removeChild(probe);
                var widest = 0;
                lines.forEach(function (l, i) {
                    var s = document.createElementNS(NS, 'tspan');
                    s.setAttribute('x', '12.4'); if (i) s.setAttribute('dy', fs * 1.2); s.textContent = l; t.appendChild(s);
                    widest = Math.max(widest, s.getComputedTextLength());
                });
                return lines.length <= 3 && widest <= max;
            }
            for (var k = 0; k < 40 && !layout(); k++) fs *= 0.95;
        });
        document.getElementById('ngTags').textContent = list.length;
        document.getElementById('ngPages').textContent = Math.ceil(list.length / 2);
        document.getElementById('ngPaperName').textContent = P.short;
        document.getElementById('ngCount').textContent = '(' + list.length + ')';
        document.getElementById('ngWarn').innerHTML = '<b class="block">Gunakan kertas ' + esc(P.name) + ' (' + esc(P.size) + ')</b>Di dialog cetak pilih ukuran kertas <b>' + esc(P.short)
            + '</b>, orientasi <b>Landscape</b>, skala <b>100% (Actual size)</b>, margin <b>None</b>. Potong mengikuti garis putus-putus merah (15 × 19,99 cm), lalu lipat di garis tengah. Jangan pakai A4 (terlalu pendek untuk 2 nametag).';
        Array.prototype.forEach.call(rowsBox.querySelectorAll('.ng-no'), function (s, i) { s.textContent = i + 1; });
    }
    function addRow(n, j) {
        if (rowsBox.querySelectorAll('.ng-row').length >= MAX) { alert('Maksimal ' + MAX + ' nama sekali cetak.'); return null; }
        var tpl = rowsBox.querySelector('.ng-row').cloneNode(true), ins = tpl.querySelectorAll('input');
        ins[0].value = n || ''; ins[1].value = j || '';
        rowsBox.appendChild(tpl); return tpl;
    }
    rowsBox.addEventListener('input', render);
    rowsBox.addEventListener('click', function (e) {
        var d = e.target.closest('.ng-del'); if (!d) return;
        var all = rowsBox.querySelectorAll('.ng-row');
        if (all.length > 1) d.closest('.ng-row').remove(); else d.closest('.ng-row').querySelectorAll('input').forEach(function (i) { i.value = ''; });
        render();
    });
    document.getElementById('ngAdd').addEventListener('click', function () { var r = addRow(); if (r) { r.querySelector('input').focus(); render(); } });
    document.getElementById('ngBulkAdd').addEventListener('click', function () {
        var ta = document.getElementById('ngBulk'), lines = ta.value.split(/\r?\n/), added = 0;
        // Baris kosong pertama diisi dulu.
        lines.forEach(function (l) {
            var p = l.split(/\t|;/), n = (p[0] || '').trim(), j = p.slice(1).join(' ').trim();
            if (!n) return;
            var empty = Array.prototype.filter.call(rowsBox.querySelectorAll('.ng-row'), function (r) { return !r.querySelector('input').value.trim(); })[0];
            if (empty) { var i = empty.querySelectorAll('input'); i[0].value = n; i[1].value = j; added++; }
            else if (addRow(n, j)) added++;
        });
        ta.value = ''; render();
    });
    form.querySelectorAll('input[name="paper"]').forEach(function (r) { r.addEventListener('change', render); });
    form.addEventListener('submit', function (e) { if (!rows().length) { e.preventDefault(); alert('Isi minimal satu nama tamu.'); } });
    render();
    if (document.fonts && document.fonts.load) Promise.all([document.fonts.load('20px NtTagB'), document.fonts.load('20px NtTagL')]).then(render, render);
})();
</script>
