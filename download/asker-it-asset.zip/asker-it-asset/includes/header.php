<?php
// $pageTitle harus di-set di halaman pemanggil sebelum include file ini.
$pageTitle = $pageTitle ?? t('app_name');
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?> — <?= htmlspecialchars(t('app_name')) ?></title>
<?= appFaviconTag() ?>
<script src="https://cdn.tailwindcss.com"></script>
<script>
  tailwind.config = {
    theme: {
      extend: {
        colors: {
          brand: {
            50:'#eef4ff',100:'#dbe7fe',200:'#bfd6fe',300:'#93b9fd',
            400:'#6094fa',500:'#3b6ff2',600:'#274fe6',700:'#1f3dd1',
            800:'#2033a8',900:'#1f2f85'
          }
        }
      }
    }
  }
</script>
<?php
    // Cache-busting: versi file CSS diambil dari waktu terakhir file diubah,
    // supaya browser otomatis ambil versi terbaru setiap kali style.css di-update,
    // tanpa perlu hard refresh manual.
    $styleCssPath = __DIR__ . '/../assets/css/style.css';
    $styleCssVer  = is_file($styleCssPath) ? filemtime($styleCssPath) : time();
?>
<link rel="stylesheet" href="assets/css/style.css?v=<?= $styleCssVer ?>">
</head>
<body class="bg-slate-100 text-slate-800 antialiased">
<div class="flex h-screen overflow-hidden app-shell">
