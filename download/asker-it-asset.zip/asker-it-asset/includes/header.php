<?php
// $pageTitle harus di-set di halaman pemanggil sebelum include file ini.
$pageTitle = $pageTitle ?? t('app_name');
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?> — <?= htmlspecialchars(t('app_name')) ?></title>
<?= appFaviconTag() ?>
<?php $twCss = __DIR__ . '/../assets/css/tailwind.css'; ?>
<link rel="stylesheet" href="assets/css/tailwind.css?v=<?= is_file($twCss) ? filemtime($twCss) : 0 ?>"><?php /* Tailwind lokal: tampilan tetap utuh tanpa internet (scripts/tailwind) */ ?>
<?php
    // Cache-busting: versi file CSS diambil dari waktu terakhir file diubah,
    // supaya browser otomatis ambil versi terbaru setiap kali style.css di-update,
    // tanpa perlu hard refresh manual.
    $styleCssPath = __DIR__ . '/../assets/css/style.css';
    $styleCssVer  = is_file($styleCssPath) ? filemtime($styleCssPath) : time();
?>
<link rel="stylesheet" href="assets/css/style.css?v=<?= $styleCssVer ?>">
</head>
<body class="bg-slate-100 text-slate-800 antialiased">
<div class="flex h-screen overflow-hidden app-shell">
