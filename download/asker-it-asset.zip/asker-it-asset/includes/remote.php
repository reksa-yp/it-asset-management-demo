<?php
/**
 * Tombol "Remote VNC" di daftar aset: membuka TightVNC Viewer di PC admin langsung ke IP aset.
 *
 * Link-nya memakai protokol khusus tmnnvnc://<IP>, yang harus didaftarkan sekali di tiap PC
 * admin lewat paket "pasang_tombol_vnc" (lihat PANDUAN di paket itu). Password VNC TIDAK
 * dikirim lewat link; tetap diketik di TightVNC Viewer.
 * Hanya membaca kolom assets.ip_address yang sudah ada.
 */

/** IP aset jika berupa IPv4 yang valid (mis. bukan "DHCP Wi-Fi"), selain itu string kosong. */
function remoteAssetIp(?string $ip): string
{
    $ip = trim((string)$ip);
    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ? $ip : '';
}

/** Tombol kecil Remote VNC untuk 1 aset; string kosong jika aset tidak punya IP valid atau dibuka dari aplikasi Android. */
function remoteVncButton(?string $ip): string
{
    $ip = remoteAssetIp($ip);
    if ($ip === '' || strpos((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 'TMNNApp/') !== false) return '';
    return ' <a href="tmnnvnc://' . $ip . '" title="' . htmlspecialchars(t('remote_vnc_title', $ip)) . '"'
         . ' class="inline-flex items-center gap-1 align-middle ml-1 px-1.5 py-0.5 rounded border border-emerald-300 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 text-xs font-medium">'
         . icon('monitor', 'w-3.5 h-3.5') . 'VNC</a>';
}
