<?php
/**
 * Translation provider configuration.
 * MyMemory is used by default so the feature can work without a LibreTranslate API key.
 * Set APP_TRANSLATE_PROVIDER=libretranslate and APP_TRANSLATE_API_KEY when using a managed LibreTranslate service.
 */
return [
    'provider' => getenv('APP_TRANSLATE_PROVIDER') ?: 'mymemory',
    'api_url' => getenv('APP_TRANSLATE_API_URL') ?: 'https://api.mymemory.translated.net',
    'api_key' => getenv('APP_TRANSLATE_API_KEY') ?: '',
    'source_language' => getenv('APP_TRANSLATE_SOURCE') ?: 'id',
    'timeout_seconds' => 20,
];
