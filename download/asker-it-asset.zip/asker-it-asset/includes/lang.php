<?php
/**
 * Sistem multi-bahasa (i18n) sederhana.
 * Default bahasa: Indonesia ('id'). User bisa pilih English ('en') dari
 * tombol EN/ID yang ada di halaman login, sebelum masuk ke dashboard.
 * Pilihan bahasa disimpan di session sehingga tetap berlaku selama login.
 */

const APP_SUPPORTED_LANGS = ['id', 'en'];

/** Pastikan $_SESSION['lang'] selalu terisi salah satu dari bahasa yang didukung. */
function initLang(): void
{
    if (empty($_SESSION['lang']) || !in_array($_SESSION['lang'], APP_SUPPORTED_LANGS, true)) {
        $_SESSION['lang'] = 'id'; // Bahasa utama/default: Indonesia
    }
}

function currentLang(): string
{
    initLang();
    return $_SESSION['lang'];
}

/** Ambil array kamus untuk bahasa aktif (dengan cache statis per-request). */
function loadDictionary(): array
{
    static $dict = null;
    if ($dict === null) {
        $lang = currentLang();
        $file = __DIR__ . '/../lang/' . $lang . '.php';
        $dict = is_file($file) ? require $file : [];
    }
    return $dict;
}

/** Ganti {PREFIX} di teks dengan awalan Nomor Aset yang diatur di Pengaturan Sistem. */
function applyPrefixPlaceholder(string $text): string
{
    if (strpos($text, '{PREFIX}') === false) return $text;
    return str_replace('{PREFIX}', function_exists('assetPrefix') ? assetPrefix() : 'AST', $text);
}

/**
 * Terjemahkan sebuah key. Kalau key tidak ditemukan, kembalikan key itu
 * sendiri supaya tidak fatal error dan mudah terlihat saat debugging.
 * Mendukung placeholder ala sprintf, mis: t('confirm_delete_asset', $namaAset).
 */
function t(string $key, ...$args): string
{
    if ($key === 'app_name' && function_exists('customAppName') && customAppName() !== '') {
        return customAppName(); // nama sistem yang diatur admin di menu Pengaturan Sistem
    }
    $dict = loadDictionary();
    $text = $dict[$key] ?? $key;
    $text = $args ? vsprintf($text, $args) : $text;
    return applyPrefixPlaceholder($text);
}

/** Ambil string mentah tanpa diproses vsprintf (dipakai untuk template yang formatnya diisi di sisi JavaScript). */
function tRaw(string $key): string
{
    if ($key === 'app_name' && function_exists('customAppName') && customAppName() !== '') {
        return customAppName();
    }
    $dict = loadDictionary();
    return applyPrefixPlaceholder($dict[$key] ?? $key);
}

/** Set bahasa aktif secara eksplisit (dipanggil dari set_lang.php). */
function setLang(string $lang): void
{
    if (in_array($lang, APP_SUPPORTED_LANGS, true)) {
        $_SESSION['lang'] = $lang;
    }
}
