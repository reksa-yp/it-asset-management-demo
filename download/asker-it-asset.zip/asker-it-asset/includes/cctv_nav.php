<?php
/** Tab navigasi menu CCTV. Set $cctvTab sebelum include: monitor | checklist | log | report | settings. */
$cctvTabs = isAdmin()
    ? [
        'monitor'   => ['cctv.php', cL('Monitoring', 'Monitoring'), 'monitor'],
        'checklist' => ['cctv_checklist.php', cL('Checklist', 'Checklist'), 'check-circle'],
        'lapor'     => ['cctv_lapor.php', cL('Laporan petugas', 'Officer reports'), 'alert'],
        'log'       => ['cctv_log.php', cL('Log CCTV mati', 'Downtime log'), 'clock'],
        'report'    => ['cctv_report.php', cL('Cetak & laporan', 'Print & reports'), 'printer'],
        'listview'  => ['cctv_listview.php', 'List View', 'camera'],
        'settings'  => ['cctv_settings.php', cL('Pengaturan', 'Settings'), 'settings'],
    ]
    : [
        'checklist' => ['cctv_checklist.php', cL('Checklist', 'Checklist'), 'check-circle'],
        'lapor'     => ['cctv_lapor.php', cL('Lapor CCTV mati', 'Report CCTV'), 'alert'],
        'report'    => ['cctv_report.php', cL('Cetak checklist', 'Print checklist'), 'printer'],
    ];
?>
<nav class="flex gap-1 overflow-x-auto border-b border-slate-200 mb-4 print:hidden">
    <?php foreach ($cctvTabs as $key => [$file, $label, $ic]): $on = ($cctvTab ?? '') === $key; ?>
        <a href="<?= $file ?>" class="inline-flex items-center gap-2 px-4 py-2.5 text-sm whitespace-nowrap border-b-2 -mb-px <?= $on ? 'border-blue-600 text-blue-700 font-semibold' : 'border-transparent text-slate-500 hover:text-slate-700' ?>">
            <?= icon($ic, 'w-4 h-4') ?> <?= htmlspecialchars($label) ?>
        </a>
    <?php endforeach; ?>
</nav>
