<?php
/**
 * Snapshot tampilan kamera untuk List View CCTV (laporan bulanan).
 * Gambar diambil lewat NVR (tanpa perlu password tiap kamera):
 *   Hikvision : /ISAPI/Streaming/channels/{ch}01/picture  (cadangan: ?snapShotImageType=JPEG, StreamingProxy, PSIA untuk firmware lama)
 *   Snapshot diambil server lewat HTTP, jadi tidak bergantung pada browser (Chrome / IE) maupun plugin web NVR.
 *   Dahua     : /cgi-bin/snapshot.cgi?channel={ch}
 * Disimpan 1 gambar per kamera per bulan (yang terbaru) di assets/uploads/cctv/snap/YYYY-MM/{asset_id}.jpg
 * dan dicatat di tabel baru cctv_snapshots. Kamera tanpa NVR memakai foto checklist bulan itu (jika ada).
 */
require_once __DIR__ . '/cctv.php';

/** Daftar URL snapshot untuk 1 channel NVR (urutan dicoba satu per satu). Alamat manual didahulukan. */
function cctvSnapshotUrls(array $nvr, int $ch): array
{
    $brand = strtolower((string)$nvr['brand']);
    $tpl   = cctvNvrConn($nvr)['snap_tpl'];
    $base  = cctvNvrBase($nvr);
    if ($tpl !== '') {
        $u = cctvFillTemplate($tpl, $nvr, $ch, (int)$nvr['port'] ?: 80);
        return [preg_match('#^https?://#i', $u) ? $u : $base . '/' . ltrim($u, '/')];
    }
    if ($brand === 'dahua') return [$base . '/cgi-bin/snapshot.cgi?channel=' . $ch];
    if ($brand === 'hikvision') return [
        $base . '/ISAPI/Streaming/channels/' . $ch . '01/picture',
        $base . '/ISAPI/Streaming/channels/' . $ch . '01/picture?snapShotImageType=JPEG',
        $base . '/ISAPI/ContentMgmt/StreamingProxy/channels/' . $ch . '01/picture',
        $base . '/PSIA/Streaming/channels/' . $ch . '01/picture',                    // firmware lama (yang web-nya hanya jalan di IE)
    ];
    return [];
}

/**
 * Ambil 1 gambar JPEG dari NVR. Return bytes atau '' jika gagal; $code = kode HTTP terakhir (0 = NVR tidak terjangkau,
 * -1 = menunggu Agen Kantor). $first = indeks URL yang dicoba lebih dulu (URL yang terakhir berhasil untuk NVR itu);
 * $okIdx = indeks URL yang berhasil. $maxAge & $wait hanya berlaku untuk NVR lewat Agen Kantor.
 */
function cctvSnapshotFetch(array $nvr, int $ch, ?int &$code = null, int $timeout = 8, int $first = 0, ?int &$okIdx = null, float $maxAge = 600, int $wait = 0): string
{
    $code = 0; $okIdx = null;
    if ($ch < 1 || cctvNvrUnreachable($nvr)) return '';
    $urls = cctvSnapshotUrls($nvr, $ch);
    $order = array_keys($urls);
    if ($first > 0 && isset($urls[$first])) $order = array_merge([$first], array_values(array_diff($order, [$first])));
    foreach ($order as $i) {
        [$code, $body] = cctvNvrHttp($nvr, $urls[$i], $timeout, $maxAge, $wait);
        if ($code <= 0) return '';                                    // NVR tidak terjangkau / menunggu agen: tidak perlu coba URL lain
        if ($code >= 500 || $code === 401) return '';                 // NVR sibuk / login ditolak: jangan dibebani dengan URL lain
        if ($code === 200 && strncmp($body, "\xFF\xD8", 2) === 0) { $okIdx = $i; return $body; }
    }
    return '';
}

/**
 * NVR lewat Agen Kantor: minta agen mengambil snapshot semua kamera lebih dulu (sekali jalan, paralel di agen).
 * $wait > 0: tunggu sampai semua gambar masuk (maks. $wait detik). Return true bila semua gambar sudah tersedia.
 */
function cctvAgentPrefetchSnapshots(PDO $db, ?int $nvrKey = null, int $wait = 0): bool
{
    $nvrs = cctvNvrList($db);
    $want = [];
    foreach (cctvCameras($db) as $c) {
        $nid = (int)($c['nvr_id'] ?? 0);
        if ($nvrKey !== null && $nid !== $nvrKey) continue;
        $nvr = $nvrs[$nid] ?? null;
        if (!$nvr || (int)($c['channel'] ?? 0) < 1 || cctvNvrConn($nvr)['mode'] !== 'agen' || !cctvSnapAllowed($nvr)) continue;
        $urls = cctvSnapshotUrls($nvr, (int)$c['channel']);
        if ($urls) $want[] = [$nvr, $urls[0]];
    }
    if (!$want || !agentEnabled()) return true;
    $end = microtime(true) + $wait;
    do {
        $missing = 0;
        foreach ($want as [$nvr, $url]) { [$code] = cctvNvrHttp($nvr, $url, 8, 900, 0); if ($code === -1) $missing++; }
        if (!$missing) return true;
        if ($wait > 0) { agentTouchHot(120); usleep(1500000); }
    } while (microtime(true) < $end);
    return false;
}

/** Perkecil gambar (maks. 640x360) agar file Excel tetap ringan. Tanpa ekstensi GD -> apa adanya. */
function cctvSnapshotResize(string $jpg, int $maxW = 640, int $maxH = 360): string
{
    if (!function_exists('imagecreatefromstring')) return $jpg;
    $im = @imagecreatefromstring($jpg);
    if (!$im) return $jpg;
    $w = imagesx($im); $h = imagesy($im);
    $r = min($maxW / $w, $maxH / $h, 1);
    $nw = max(1, (int)round($w * $r)); $nh = max(1, (int)round($h * $r));
    $dst = imagecreatetruecolor($nw, $nh);
    imagecopyresampled($dst, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
    ob_start();
    imagejpeg($dst, null, 78);
    $out = (string)ob_get_clean();
    imagedestroy($im); imagedestroy($dst);
    return $out !== '' ? $out : $jpg;
}

/**
 * Ambil snapshot semua kamera (atau 1 NVR). Return ['ok' => n, 'fail' => [lokasi...], 'skip' => n (tanpa NVR/channel)].
 */
function cctvTakeSnapshots(PDO $db, ?int $nvrKey = null): array
{
    ensureCctvTables($db);
    @set_time_limit(0);
    $nvrs = cctvNvrList($db);
    $ym   = date('Y-m');
    $dir  = CCTV_PHOTO_DIR . '/snap/' . $ym;
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $up = $db->prepare("DELETE FROM cctv_snapshots WHERE asset_id = ? AND ym = ?");
    $ins = $db->prepare("INSERT INTO cctv_snapshots (asset_id, ym, path, state, taken_at) VALUES (?, ?, ?, ?, ?)");
    $res = ['ok' => 0, 'fail' => [], 'skip' => 0];
    $down = [];
    // NVR lewat Agen Kantor: agen mengambil semua gambar lebih dulu (maks. 45 detik), lalu dipakai dari situ.
    if (!defined('CCTV_AGENT_CONTEXT')) cctvAgentPrefetchSnapshots($db, $nvrKey, 45);
    foreach (cctvCameras($db) as $c) {
        $nid = (int)($c['nvr_id'] ?? 0);
        if ($nvrKey !== null && $nid !== $nvrKey) continue;
        $nvr = $nvrs[$nid] ?? null;
        if (!$nvr || (int)($c['channel'] ?? 0) < 1) { $res['skip']++; continue; }
        // NVR yang 2x tidak terjangkau dilewati (agar tidak menunggu timeout untuk setiap kamera).
        if (($down[$nid] ?? 0) >= 2) { $res['fail'][] = $c['location'] ?: $c['number']; continue; }
        $jpg = cctvSnapshotFetch($nvr, (int)$c['channel'], $code);
        if ($jpg === '') {
            if ($code === 0) $down[$nid] = ($down[$nid] ?? 0) + 1;
            $res['fail'][] = $c['location'] ?: $c['number'];
            continue;
        }
        $file = $dir . '/' . (int)$c['id'] . '.jpg';
        if (@file_put_contents($file, cctvSnapshotResize($jpg)) === false) { $res['fail'][] = $c['location'] ?: $c['number']; continue; }
        $up->execute([(int)$c['id'], $ym]);
        $ins->execute([(int)$c['id'], $ym, CCTV_PHOTO_URL . '/snap/' . $ym . '/' . (int)$c['id'] . '.jpg', (string)($c['state'] ?? ''), date('Y-m-d H:i:s')]);
        $res['ok']++;
    }
    return $res;
}

/**
 * Gambar per kamera untuk bulan $ym: [asset_id => ['path' => relatif, 'file' => absolut, 'taken_at', 'state', 'source' => snapshot|checklist]].
 * Snapshot otomatis didahulukan; jika tidak ada, foto checklist terbaru bulan itu.
 */
function cctvSnapshotMap(PDO $db, string $ym): array
{
    ensureCctvTables($db);
    $root = dirname(__DIR__) . '/';
    $out = [];
    $st = $db->prepare("SELECT r.asset_id, r.photo, c.check_date, c.created_at FROM cctv_checklist_results r
                        JOIN cctv_checklists c ON c.id = r.checklist_id
                        WHERE c.check_date BETWEEN ? AND ? AND r.photo IS NOT NULL AND r.photo <> '' ORDER BY c.check_date, c.id");
    $st->execute([$ym . '-01', date('Y-m-t', strtotime($ym . '-01'))]);
    foreach ($st->fetchAll() as $r) {
        $file = CCTV_PHOTO_DIR . '/' . ltrim((string)$r['photo'], '/');          // foto checklist: path relatif ke folder cctv
        if (is_file($file) && preg_match('/\.(jpe?g|png)$/i', $file)) $out[(int)$r['asset_id']] = ['path' => CCTV_PHOTO_URL . '/' . ltrim((string)$r['photo'], '/'), 'file' => $file, 'taken_at' => (string)$r['created_at'], 'state' => '', 'source' => 'checklist'];
    }
    $st = $db->prepare("SELECT * FROM cctv_snapshots WHERE ym = ?");
    $st->execute([$ym]);
    foreach ($st->fetchAll() as $r) {
        $file = $root . ltrim((string)$r['path'], '/');
        if (is_file($file)) $out[(int)$r['asset_id']] = ['path' => (string)$r['path'], 'file' => $file, 'taken_at' => (string)$r['taken_at'], 'state' => (string)$r['state'], 'source' => 'snapshot'];
    }
    return $out;
}

/** Tanggal Senin pertama pada bulan $ym (Y-m-d). */
function cctvFirstMonday(string $ym): string
{
    $t = strtotime($ym . '-01');
    while ((int)date('N', $t) !== 1) $t = strtotime('+1 day', $t);
    return date('Y-m-d', $t);
}

/** Jadwal snapshot otomatis berikutnya (Y-m-d), atau '' jika nonaktif. */
function cctvNextSnapshotDate(array $set): string
{
    $today = date('Y-m-d');
    if ($set['snapshot_schedule'] === 'daily') return $set['snapshot_last'] === $today ? date('Y-m-d', strtotime('+1 day')) : $today;
    if ($set['snapshot_schedule'] !== 'first_monday') return '';
    $fm = cctvFirstMonday(date('Y-m'));
    if ($set['snapshot_last'] !== '' && $set['snapshot_last'] >= $fm) return cctvFirstMonday(date('Y-m', strtotime(date('Y-m-01') . ' +1 month')));
    return max($fm, $today);
}

/**
 * Dipanggil oleh cctv_check.php (Task Scheduler) setiap pengecekan; snapshot diambil jika sudah jadwalnya:
 *  - first_monday: Senin pertama tiap bulan mulai jam snapshot_hour. Jika hari itu server mati / terlewat,
 *    diambil pada pengecekan berikutnya (hari setelahnya) selama bulan itu belum ada snapshot otomatis.
 *  - daily: setiap hari mulai jam snapshot_hour.
 */
function cctvAutoSnapshotDaily(PDO $db): ?array
{
    $set = cctvSettings(true);
    $today = date('Y-m-d');
    if ((int)date('G') < (int)$set['snapshot_hour']) return null;
    if ($set['snapshot_schedule'] === 'daily') {
        if ($set['snapshot_last'] === $today) return null;
    } elseif ($set['snapshot_schedule'] === 'first_monday') {
        $fm = cctvFirstMonday(date('Y-m'));
        if ($today < $fm || ($set['snapshot_last'] !== '' && $set['snapshot_last'] >= $fm)) return null;
    } else {
        return null;
    }
    // NVR lewat Agen Kantor: tunggu sampai agen sudah mengirim semua gambar (dicoba lagi pada cek berikutnya).
    if (!cctvAgentPrefetchSnapshots($db)) return null;
    saveCctvSettings(['snapshot_last' => $today]);       // tandai dulu agar tidak dobel walau gagal di tengah
    return cctvTakeSnapshots($db);
}

/* ================================================================== Cover checklist (VIEW NVR) */

/**
 * Gambar gabungan (tampilan multi-view seperti layar NVR) dari snapshot kamera 1 NVR, disusun urut channel.
 * Kamera tanpa gambar ditampilkan kotak gelap "NO IMAGE". Return path file JPG sementara, atau '' jika GD tidak ada.
 */
function cctvNvrGridImage(array $cams, array $snaps): string
{
    if (!function_exists('imagecreatetruecolor') || !$cams) return '';
    $n = count($cams);
    $cols = max(1, (int)ceil(sqrt($n)));
    $rows = (int)ceil($n / $cols);
    $tw = 240; $th = 135; $gap = 2;
    $img = imagecreatetruecolor($cols * ($tw + $gap) + $gap, $rows * ($th + $gap) + $gap);
    $black = imagecolorallocate($img, 0, 0, 0);
    $dark  = imagecolorallocate($img, 38, 38, 46);
    $white = imagecolorallocate($img, 255, 255, 255);
    $grey  = imagecolorallocate($img, 150, 150, 160);
    $band  = imagecolorallocatealpha($img, 0, 0, 0, 50);
    imagefill($img, 0, 0, $black);
    foreach (array_values($cams) as $i => $c) {
        $x = $gap + ($i % $cols) * ($tw + $gap);
        $y = $gap + intdiv($i, $cols) * ($th + $gap);
        $src = null;
        if (!empty($snaps[$c['id']]['file']) && is_file($snaps[$c['id']]['file'])) $src = @imagecreatefromstring((string)file_get_contents($snaps[$c['id']]['file']));
        if ($src) {
            imagecopyresampled($img, $src, $x, $y, 0, 0, $tw, $th, imagesx($src), imagesy($src));
            imagedestroy($src);
        } else {
            imagefilledrectangle($img, $x, $y, $x + $tw - 1, $y + $th - 1, $dark);
            imagestring($img, 3, $x + (int)(($tw - 8 * 8) / 2), $y + (int)($th / 2) - 6, 'NO IMAGE', $grey);
        }
        $label = ((int)($c['channel'] ?? 0) > 0 ? 'D' . (int)$c['channel'] . ' ' : '') . strtoupper((string)($c['name'] ?: $c['location']));
        $label = substr(preg_replace('/[^\x20-\x7E]/', '', $label), 0, 38);
        imagefilledrectangle($img, $x, $y + $th - 15, $x + $tw - 1, $y + $th - 1, $band);
        imagestring($img, 2, $x + 4, $y + $th - 14, $label, $white);
    }
    $tmp = tempnam(sys_get_temp_dir(), 'nvrgrid_');
    $file = $tmp . '.jpg';
    @unlink($tmp);
    imagejpeg($img, $file, 82);
    imagedestroy($img);
    return is_file($file) ? $file : '';
}

/**
 * Tambahkan sheet cover "VIEW_<NVR>" di depan workbook laporan bulanan (1 sheet per NVR):
 * judul "NVR 1 (64CH)", gambar multi-view dari snapshot bulan itu, IP NVR (lokal & publik),
 * lalu tabel 2 kolom: NO | NAMA CCTV | LOKASI | CHANNEL | IP ADDRESS | DEVICE TYPE.
 * Return daftar file sementara (hapus setelah file Excel disimpan).
 */
function cctvAddCoverSheets(\PhpOffice\PhpSpreadsheet\Spreadsheet $ss, PDO $db, string $ym, array $groups, ?array $snaps = null): array
{
    $snaps = $snaps ?? cctvSnapshotMap($db, $ym);
    $nvrs  = cctvNvrList($db);
    $pub   = (array)(cctvSettings()['nvr_public_ip'] ?? []);
    $ids   = [];
    foreach ($groups as $g) foreach ($g['cams'] as $c) $ids[] = (int)$c['id'];
    $info  = cctvInfoMap($db, $ids);
    $tmpFiles = [];
    $thin = ['borders' => ['allBorders' => ['borderStyle' => 'thin', 'color' => ['rgb' => '64748B']]]];
    $used = [];
    $pos = 0;
    foreach ($groups as $gk => $g) {
        $cams = array_values($g['cams']);
        $n = count($cams);
        $title = 'VIEW_' . mb_substr(trim(preg_replace('/[\\\\\/\?\*\[\]:]+/', ' ', $g['name'])), 0, 24);
        $t = $title; $k = 2;
        while (isset($used[mb_strtolower($t)]) || $ss->sheetNameExists($t)) $t = mb_substr($title, 0, 28) . ' ' . $k++;
        $used[mb_strtolower($t)] = true;
        $sh = new \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet($ss, $t);
        $ss->addSheet($sh, $pos++);

        foreach (['A' => 5.5, 'B' => 26, 'C' => 20, 'D' => 9, 'E' => 15, 'F' => 17, 'G' => 2.5, 'H' => 5.5, 'I' => 26, 'J' => 20, 'K' => 9, 'L' => 15, 'M' => 17] as $col => $w) {
            $sh->getColumnDimension($col)->setWidth($w);
        }
        $sh->setCellValue('A1', mb_strtoupper($g['name']) . ' (' . $n . 'CH)');
        $sh->mergeCells('A1:M1');
        $sh->getStyle('A1')->getFont()->setBold(true)->setSize(16);
        $sh->getRowDimension(1)->setRowHeight(24);
        $sh->setCellValue('A2', cL('Checklist CCTV ', 'CCTV checklist ') . cctvMonthTitle($ym));
        $sh->getStyle('A2')->getFont()->setItalic(true)->getColor()->setRGB('475569');

        // Gambar multi-view
        $r = 4;
        $grid = cctvNvrGridImage($cams, $snaps);
        if ($grid !== '') {
            $tmpFiles[] = $grid;
            [$gw, $gh] = getimagesize($grid);
            $colPx = 0;                                              // lebar gambar = lebar tabel A..M
            foreach (range('A', 'M') as $col) $colPx += $sh->getColumnDimension($col)->getWidth() * 7 + 5;
            $w = (int)round($colPx * 0.93);
            $hPx = (int)round($w * $gh / max(1, $gw));
            $d = new \PhpOffice\PhpSpreadsheet\Worksheet\Drawing();
            $d->setPath($grid);
            $d->setWidth($w);
            $d->setCoordinates('A3');
            $d->setOffsetX(2);
            $d->setOffsetY(2);
            $d->setWorksheet($sh);
            $r = 3 + (int)ceil(($hPx + 8) / 20) + 2;               // baris area gambar dibuat 15pt (= 20px)
            for ($i = 3; $i < $r - 1; $i++) $sh->getRowDimension($i)->setRowHeight(15);
        } else {
            $sh->setCellValue('A3', cL('Gambar belum tersedia (ambil snapshot di menu CCTV > List View).', 'No images yet.'));
        }
        $taken = array_filter(array_map(fn($c) => $snaps[$c['id']]['taken_at'] ?? null, $cams));
        if ($taken) {
            $sh->setCellValue('A' . ($r - 1), cL('Snapshot diambil: ', 'Snapshots taken: ') . date('d/m/Y H:i', strtotime(max($taken))) . '  ·  ' . count($taken) . '/' . $n . cL(' kamera', ' cameras'));
            $sh->getStyle('A' . ($r - 1))->getFont()->setSize(8)->getColor()->setRGB('64748B');
        }

        // IP NVR
        $nv = $nvrs[$gk] ?? null;
        $sh->setCellValue('A' . $r, 'IP NVR :');
        $sh->getStyle('A' . $r)->getFont()->setBold(true);
        $r++;
        $sh->setCellValue('A' . $r, 'LOKAL IP : ' . ($nv ? trim((string)$nv['ip_address']) : '-'));
        $r++;
        $sh->setCellValue('A' . $r, 'PUBLIC IP : ' . (trim((string)($pub[(string)$gk] ?? '')) ?: '-'));
        $r++;

        // Tabel 2 kolom
        $hr = $r;
        foreach ([['A', 'B', 'C', 'D', 'E', 'F'], ['H', 'I', 'J', 'K', 'L', 'M']] as $side) {
            foreach (['NO', 'NAMA CCTV', 'LOKASI', 'CHANNEL', 'IP ADDRESS', 'DEVICE TYPE'] as $j => $label) $sh->setCellValue($side[$j] . $hr, $label);
            $sh->getStyle($side[0] . $hr . ':' . $side[5] . $hr)->getFont()->setBold(true);
            $sh->getStyle($side[0] . $hr . ':' . $side[5] . $hr)->getFill()->setFillType('solid')->getStartColor()->setRGB('D9E1F2');
        }
        $half = (int)ceil($n / 2);
        foreach ($cams as $i => $c) {
            $side = $i < $half ? ['A', 'B', 'C', 'D', 'E', 'F'] : ['H', 'I', 'J', 'K', 'L', 'M'];
            $row = $hr + 1 + ($i < $half ? $i : $i - $half);
            $vals = [$i + 1, $c['name'] ?: $c['location'], $c['location'] ?: '-', (int)($c['channel'] ?? 0) > 0 ? 'D' . (int)$c['channel'] : '-', $c['ip'] ?: '-', $info[$c['id']]['model'] ?? ''];
            foreach ($vals as $j => $v) $sh->setCellValueExplicit($side[$j] . $row, (string)$v, \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
        }
        $last = $hr + max(1, $half);
        $sh->getStyle("A{$hr}:F{$last}")->applyFromArray($thin);
        if ($n > 1) $sh->getStyle("H{$hr}:M" . ($hr + ($n - $half)))->applyFromArray($thin);
        foreach (['A', 'D', 'H', 'K'] as $col) $sh->getStyle("{$col}{$hr}:{$col}{$last}")->getAlignment()->setHorizontal('center');
        foreach (['B', 'I'] as $col) $sh->getStyle("{$col}" . ($hr + 1) . ":{$col}{$last}")->getFont()->setBold(true);

        $ps = $sh->getPageSetup();
        $ps->setOrientation('landscape')->setPaperSize(\PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4)
           ->setFitToWidth(1)->setFitToHeight(1)->setPrintArea("A1:M{$last}");
        $sh->getPageMargins()->setTop(0.3)->setBottom(0.3)->setLeft(0.3)->setRight(0.3);
        $sh->setShowGridlines(false);
    }
    return $tmpFiles;
}
