<?php
/**
 * Pekerjaan CCTV (khusus admin): penambahan / ganti hardisk NVR, tambah titik CCTV, pindah posisi,
 * ganti kamera, perbaikan kabel, dll. Dicatat per tanggal & shift dari halaman Checklist CCTV,
 * riwayatnya di tab CCTV > Pekerjaan, ikut tercetak di checklist shift & laporan bulanan.
 *
 * - Barang bisa diambil dari Stok Barang: dicatat sebagai Barang Keluar (stok berkurang otomatis).
 * - Tambah titik CCTV: kamera berstatus Stok di menu Aset bisa dipakai (jadi Digunakan + NVR/channel),
 *   atau dibuatkan aset CCTV baru (nomor aset otomatis).
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA:
 * - Hanya MEMBUAT 3 tabel BARU jika belum ada: cctv_job_types, cctv_jobs, cctv_job_assets.
 * - Tidak ALTER / DROP tabel lama. Yang berubah di tabel lama hanya isinya (stok keluar, status aset kamera).
 *
 * Dipakai oleh: cctv_checklist.php, cctv_jobs.php, cctv_job_save.php, cctv_report.php.
 */
require_once __DIR__ . '/cctv.php';

const CCTV_JOB_PHOTO_MAX = 4;

function cctvJobsEnsure(PDO $db): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    foreach ([
        "CREATE TABLE IF NOT EXISTS cctv_job_types (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            name        VARCHAR(100) NOT NULL,
            kind        VARCHAR(10)  NOT NULL DEFAULT 'other',   -- hdd | add | cam | other
            stock_hint  VARCHAR(60)  NOT NULL DEFAULT '',        -- kata kunci barang stok yang diusulkan
            sort_order  INT          NOT NULL DEFAULT 0,
            is_active   TINYINT(1)   NOT NULL DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS cctv_jobs (
            id              INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            job_date        DATE         NOT NULL,
            shift           VARCHAR(20)  NOT NULL DEFAULT '',
            type_id         INT UNSIGNED NULL,
            type_name       VARCHAR(100) NOT NULL,
            kind            VARCHAR(10)  NOT NULL DEFAULT 'other',
            nvr_id          INT UNSIGNED NULL,
            camera_id       INT UNSIGNED NULL,                    -- assets.id kamera terkait (tanpa foreign key)
            detail          TEXT NULL,                            -- JSON rincian per jenis
            status          VARCHAR(10)  NOT NULL DEFAULT 'ok',   -- ok | pr | wt
            officers        VARCHAR(150) NOT NULL DEFAULT '',
            note            TEXT NULL,
            photos          TEXT NULL,                            -- JSON daftar path foto
            stock_trx_id    INT UNSIGNED NULL,                    -- stock_transactions.id (Barang Keluar)
            stock_text      VARCHAR(150) NULL,
            created_by      INT UNSIGNED NULL,
            created_by_name VARCHAR(150) NULL,
            created_at      DATETIME NULL,
            updated_at      DATETIME NULL,
            INDEX idx_cctv_jobs_date (job_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS cctv_job_assets (
            job_id      INT UNSIGNED NOT NULL,
            asset_id    INT UNSIGNED NOT NULL,
            mode        VARCHAR(10)  NOT NULL DEFAULT 'stock',    -- stock | new
            PRIMARY KEY (job_id, asset_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    ] as $q) {
        try { $db->exec($q); } catch (Throwable $e) { }
    }
    try {
        if ((int)$db->query("SELECT COUNT(*) FROM cctv_job_types")->fetchColumn() === 0) {
            $ins = $db->prepare("INSERT INTO cctv_job_types (name, kind, stock_hint, sort_order, is_active) VALUES (?,?,?,?,1)");
            foreach ([
                ['Penambahan / ganti hardisk NVR', 'hdd', 'hardisk', 1],
                ['Tambah titik CCTV', 'add', 'kamera', 2],
                ['Pindah posisi kamera', 'cam', '', 3],
                ['Ganti kamera', 'cam', 'kamera', 4],
                ['Perbaikan kabel / konektor', 'cam', 'konektor', 5],
                ['Ganti adaptor / power', 'cam', 'adaptor', 6],
                ['Lainnya', 'other', '', 7],
            ] as $r) $ins->execute($r);
        }
    } catch (Throwable $e) { }
}

function cctvJobKinds(): array
{
    return [
        'hdd'   => cL('Hardisk NVR (isian kapasitas)', 'NVR hard disk (capacity fields)'),
        'add'   => cL('Tambah titik (isian titik & aset kamera)', 'New camera points (points & camera assets)'),
        'cam'   => cL('Pekerjaan pada 1 kamera', 'Work on one camera'),
        'other' => cL('Lainnya (keterangan bebas)', 'Other (free text)'),
    ];
}

function cctvJobStatuses(): array
{
    return ['ok' => cL('Selesai', 'Done'), 'pr' => cL('Dalam proses', 'In progress'), 'wt' => cL('Menunggu barang', 'Waiting for parts')];
}

function cctvJobStatusBadge(string $s): string
{
    $c = ['ok' => 'bg-green-100 text-green-700', 'pr' => 'bg-amber-100 text-amber-800', 'wt' => 'bg-cyan-100 text-cyan-800'][$s] ?? 'bg-slate-100 text-slate-600';
    return '<span class="inline-block whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-semibold ' . $c . '">' . htmlspecialchars(cctvJobStatuses()[$s] ?? $s) . '</span>';
}

function cctvJobTypes(PDO $db, bool $activeOnly = true): array
{
    cctvJobsEnsure($db);
    $rows = $db->query("SELECT * FROM cctv_job_types ORDER BY sort_order, id")->fetchAll();
    if ($activeOnly) $rows = array_values(array_filter($rows, fn($r) => (int)$r['is_active'] === 1));
    return $rows;
}

/** Simpan daftar jenis pekerjaan dari form (baris baru id=0; dicentang hapus = nonaktif bila sudah dipakai). */
function cctvJobTypesSave(PDO $db, array $p): void
{
    cctvJobsEnsure($db);
    $order = 0;
    foreach ((array)($p['jt_id'] ?? []) as $i => $id) {
        $id = (int)$id;
        $name = mb_substr(trim((string)($p['jt_name'][$i] ?? '')), 0, 100);
        $kind = (string)($p['jt_kind'][$i] ?? 'other');
        if (!isset(cctvJobKinds()[$kind])) $kind = 'other';
        $hint = mb_substr(trim((string)($p['jt_hint'][$i] ?? '')), 0, 60);
        $del = !empty($p['jt_del'][$i]);
        if ($id > 0 && ($del || $name === '')) {
            $used = $db->prepare("SELECT COUNT(*) FROM cctv_jobs WHERE type_id = ?");
            $used->execute([$id]);
            if ((int)$used->fetchColumn() > 0) $db->prepare("UPDATE cctv_job_types SET is_active = 0 WHERE id = ?")->execute([$id]);
            else $db->prepare("DELETE FROM cctv_job_types WHERE id = ?")->execute([$id]);
            continue;
        }
        if ($name === '' || $del) continue;
        $order++;
        if ($id > 0) $db->prepare("UPDATE cctv_job_types SET name=?, kind=?, stock_hint=?, sort_order=?, is_active=1 WHERE id=?")->execute([$name, $kind, $hint, $order, $id]);
        else $db->prepare("INSERT INTO cctv_job_types (name, kind, stock_hint, sort_order, is_active) VALUES (?,?,?,?,1)")->execute([$name, $kind, $hint, $order]);
    }
}

/** Barang Stok Barang yang masih ada stoknya: [['key'=>'cat|item','cat'=>..,'item'=>..,'cat_name'=>..,'unit'=>..,'s'=>..]] */
function cctvJobStockOptions(PDO $db): array
{
    if (!is_file(__DIR__ . '/stock.php')) return [];
    require_once __DIR__ . '/stock.php';
    try {
        if (function_exists('stockTablesExist') && !stockTablesExist($db)) return [];
        $cats = [];
        foreach (getStockCategories($db) as $c) $cats[(int)$c['id']] = $c;
        $out = [];
        foreach (getStockItems($db) as $it) {
            $c = $cats[$it['cat']] ?? null;
            if (!$c) continue;
            $out[] = ['key' => $it['cat'] . '|' . $it['item'], 'cat' => $it['cat'], 'item' => $it['item'], 'cat_name' => (string)$c['name'],
                      'unit' => (string)($c['unit'] ?: 'pcs'), 's' => (int)$it['s']];
        }
        usort($out, fn($a, $b) => strnatcasecmp($a['cat_name'] . ' ' . $a['item'], $b['cat_name'] . ' ' . $b['item']));
        return $out;
    } catch (Throwable $e) { return []; }
}

/** Kamera CCTV berstatus Stok di menu Aset (bisa dipakai saat tambah titik). */
function cctvJobStockCameras(PDO $db, int $includeJobId = 0): array
{
    $rows = $db->query("SELECT id, asset_number, category, device_name, motherboard_brand, status FROM assets ORDER BY asset_number")->fetchAll();
    $rows = array_values(array_filter($rows, fn($a) => isCctvCategory((string)$a['category']) && !isTabletCategory((string)$a['category']) && (string)$a['status'] === 'Stok'));
    return $rows;
}

function cctvJobDecode(array $j): array
{
    $j['detail'] = json_decode((string)($j['detail'] ?? ''), true) ?: [];
    $j['photos'] = json_decode((string)($j['photos'] ?? ''), true) ?: [];
    return $j;
}

/** Daftar pekerjaan. $f: date, shift, from, to, type_id, nvr_id, status. */
function cctvJobsList(PDO $db, array $f = []): array
{
    cctvJobsEnsure($db);
    $w = []; $a = [];
    if (!empty($f['date']))    { $w[] = 'job_date = ?'; $a[] = $f['date']; }
    if (!empty($f['shift']))   { $w[] = 'shift = ?'; $a[] = $f['shift']; }
    if (!empty($f['from']))    { $w[] = 'job_date >= ?'; $a[] = $f['from']; }
    if (!empty($f['to']))      { $w[] = 'job_date <= ?'; $a[] = $f['to']; }
    if (!empty($f['type_id'])) { $w[] = 'type_id = ?'; $a[] = (int)$f['type_id']; }
    if (!empty($f['nvr_id']))  { $w[] = 'nvr_id = ?'; $a[] = (int)$f['nvr_id']; }
    if (!empty($f['status']))  { $w[] = 'status = ?'; $a[] = $f['status']; }
    $st = $db->prepare("SELECT * FROM cctv_jobs" . ($w ? ' WHERE ' . implode(' AND ', $w) : '') . " ORDER BY job_date DESC, id DESC");
    $st->execute($a);
    $rows = array_map('cctvJobDecode', $st->fetchAll());
    if (!$rows) return [];
    // aset kamera yang terkait (tambah titik)
    $ids = array_map(fn($r) => (int)$r['id'], $rows);
    $links = [];
    $q = $db->prepare("SELECT l.job_id, l.mode, a.id, a.asset_number, a.device_name FROM cctv_job_assets l JOIN assets a ON a.id = l.asset_id
                       WHERE l.job_id IN (" . implode(',', array_fill(0, count($ids), '?')) . ") ORDER BY a.asset_number");
    $q->execute($ids);
    foreach ($q->fetchAll() as $l) $links[(int)$l['job_id']][] = $l;
    $nvrs = cctvNvrList($db);
    $camIds = array_values(array_filter(array_map(fn($r) => (int)$r['camera_id'], $rows)));
    $cams = [];
    if ($camIds) {
        $q = $db->prepare("SELECT id, asset_number, device_name, location FROM assets WHERE id IN (" . implode(',', array_fill(0, count($camIds), '?')) . ")");
        $q->execute($camIds);
        foreach ($q->fetchAll() as $c) $cams[(int)$c['id']] = $c;
    }
    foreach ($rows as &$r) {
        $r['assets'] = $links[(int)$r['id']] ?? [];
        $r['nvr_name'] = $r['nvr_id'] && isset($nvrs[(int)$r['nvr_id']]) ? (string)$nvrs[(int)$r['nvr_id']]['name'] : '';
        $c = $r['camera_id'] ? ($cams[(int)$r['camera_id']] ?? null) : null;
        $r['camera_label'] = $c ? trim($c['asset_number'] . ' · ' . ($c['device_name'] ?: $c['location']), ' ·') : '';
    }
    return $rows;
}

/** Baris rincian (teks) 1 pekerjaan, dipakai di halaman, cetak, dan Excel. */
function cctvJobDetailLines(array $j): array
{
    $d = $j['detail']; $out = [];
    $num = fn($v) => rtrim(rtrim(number_format((float)$v, 1, '.', ''), '0'), '.');
    if ($j['kind'] === 'hdd') {
        if (!empty($d['qty']) || !empty($d['cap'])) $out[] = cL('Tambah ', 'Added ') . ((int)($d['qty'] ?? 1)) . ' × ' . $num($d['cap'] ?? 0) . ' TB' . (!empty($d['brand']) ? ' (' . $d['brand'] . ')' : '');
        if (($d['before'] ?? '') !== '' || ($d['after'] ?? '') !== '') $out[] = cL('Kapasitas NVR: ', 'NVR capacity: ') . (($d['before'] ?? '') !== '' ? $num($d['before']) : '?') . ' TB → ' . (($d['after'] ?? '') !== '' ? $num($d['after']) : '?') . ' TB';
        if (!empty($d['days'])) $out[] = cL('Perkiraan lama rekaman: ', 'Estimated recording: ') . $d['days'];
    } elseif ($j['kind'] === 'add') {
        $out[] = '+' . (int)($d['qty'] ?? 1) . cL(' titik kamera', ' camera point(s)') . (!empty($d['ch']) ? ' · ch ' . $d['ch'] . ((int)($d['qty'] ?? 1) > 1 ? '–' . ((int)$d['ch'] + (int)$d['qty'] - 1) : '') : '');
        if (!empty($d['loc'])) $out[] = cL('Lokasi: ', 'Location: ') . $d['loc'];
        if (!empty($d['model'])) $out[] = cL('Kamera: ', 'Camera: ') . $d['model'];
    } else {
        if (!empty($d['what'])) $out[] = $d['what'];
    }
    if (!empty($j['assets'])) {
        $out[] = cL('Aset kamera: ', 'Camera assets: ') . implode(', ', array_map(fn($l) => $l['asset_number'] . ($l['mode'] === 'new' ? cL(' (baru)', ' (new)') : cL(' (dari stok)', ' (from stock)')), $j['assets']));
    }
    if (!empty($j['stock_text'])) $out[] = cL('Dari Stok Barang: ', 'From stock: ') . $j['stock_text'];
    return $out;
}

function cctvJobSavePhoto(array $file, string $date): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) return '';
    if ($file['size'] > 8 * 1024 * 1024) return '';
    $mime = (@getimagesize($file['tmp_name']))['mime'] ?? '';
    $ext  = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? '';
    if ($ext === '') return '';
    $sub = 'pekerjaan/' . date('Y/m', strtotime($date));
    $dir = CCTV_PHOTO_DIR . '/' . $sub;
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return '';
    $name = 'job_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3)) . '.' . $ext;
    return move_uploaded_file($file['tmp_name'], $dir . '/' . $name) ? $sub . '/' . $name : '';
}

/**
 * Simpan (tambah / ubah) 1 pekerjaan dari form. Return ['ok'=>bool,'msg'=>string].
 */
function cctvJobSave(PDO $db, array $p, array $files, array $me): array
{
    cctvJobsEnsure($db);
    $id = (int)($p['job_id'] ?? 0);
    $old = null;
    if ($id) {
        $st = $db->prepare("SELECT * FROM cctv_jobs WHERE id = ?");
        $st->execute([$id]);
        $old = $st->fetch();
        if (!$old) return ['ok' => false, 'msg' => cL('Pekerjaan tidak ditemukan.', 'Job not found.')];
        $old = cctvJobDecode($old);
    }
    $date = (string)($p['job_date'] ?? date('Y-m-d'));
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');
    $shift = mb_substr(trim((string)($p['shift'] ?? '')), 0, 20);
    $types = array_column(cctvJobTypes($db, false), null, 'id');
    $type = $types[(int)($p['type_id'] ?? 0)] ?? null;
    if (!$type) return ['ok' => false, 'msg' => cL('Pilih jenis pekerjaan.', 'Choose a job type.')];
    $kind = (string)$type['kind'];
    $nvrId = (int)($p['nvr_id'] ?? 0);
    $nvrs = cctvNvrList($db);
    if ($nvrId && !isset($nvrs[$nvrId])) $nvrId = 0;
    $camId = in_array($kind, ['cam', 'other'], true) ? (int)($p['camera_id'] ?? 0) : 0;
    $status = isset(cctvJobStatuses()[$p['status'] ?? '']) ? (string)$p['status'] : 'ok';
    $officers = mb_substr(trim((string)($p['officers'] ?? '')), 0, 150);
    $note = mb_substr(trim((string)($p['note'] ?? '')), 0, 2000);
    $s = fn($k, $n = 100) => mb_substr(trim((string)($p[$k] ?? '')), 0, $n);
    $numOrEmpty = fn($k) => trim((string)($p[$k] ?? '')) === '' ? '' : max(0, (float)str_replace(',', '.', (string)$p[$k]));
    if ($kind === 'hdd') {
        $detail = ['qty' => max(1, (int)($p['d_qty'] ?? 1)), 'cap' => $numOrEmpty('d_cap'), 'brand' => $s('d_brand'),
                   'before' => $numOrEmpty('d_before'), 'after' => $numOrEmpty('d_after'), 'days' => $s('d_days', 40)];
    } elseif ($kind === 'add') {
        $detail = ['qty' => max(1, min(64, (int)($p['d_qty'] ?? 1))), 'ch' => (int)($p['d_ch'] ?? 0) ?: '', 'loc' => $s('d_loc', 150), 'model' => $s('d_model')];
    } else {
        $detail = ['what' => $s('d_what', 250)];
    }

    // ---- Stok Barang ----
    $useStock = !empty($p['use_stock']) && is_file(__DIR__ . '/stock.php');
    $stockCat = 0; $stockItem = ''; $stockQty = 0; $stockText = null;
    if ($useStock) {
        require_once __DIR__ . '/stock.php';
        [$stockCat, $stockItem] = array_pad(explode('|', (string)($p['stock_key'] ?? ''), 2), 2, '');
        $stockCat = (int)$stockCat; $stockQty = max(1, (int)($p['stock_qty'] ?? 1));
        if (!$stockCat || $stockItem === '') return ['ok' => false, 'msg' => cL('Pilih barang dari stok.', 'Choose an item from stock.')];
        $avail = stockItemAvailable($db, $stockCat, $stockItem, (int)($old['stock_trx_id'] ?? 0));
        if ($avail < $stockQty) return ['ok' => false, 'msg' => cL('Stok ', 'Stock of ') . $stockItem . cL(' tidak cukup (sisa ', ' is not enough (left ') . max(0, $avail) . ').'];
        $catRow = $db->prepare("SELECT name, unit FROM stock_categories WHERE id = ?");
        $catRow->execute([$stockCat]);
        $cr = $catRow->fetch() ?: ['name' => '', 'unit' => 'pcs'];
        $stockText = $stockQty . ' ' . ($cr['unit'] ?: 'pcs') . ' ' . $stockItem;
    }

    // ---- Foto ----
    $photos = $old['photos'] ?? [];
    foreach ((array)($p['remove_photo'] ?? []) as $rp) $photos = array_values(array_filter($photos, fn($x) => $x !== $rp));
    if (!empty($files['photos']['name']) && is_array($files['photos']['name'])) {
        foreach ($files['photos']['name'] as $k => $nm) {
            if (count($photos) >= CCTV_JOB_PHOTO_MAX) break;
            $saved = cctvJobSavePhoto(['name' => $nm, 'tmp_name' => $files['photos']['tmp_name'][$k], 'error' => $files['photos']['error'][$k], 'size' => $files['photos']['size'][$k]], $date);
            if ($saved !== '') $photos[] = $saved;
        }
    }

    $now = date('Y-m-d H:i:s');
    $typeName = (string)$type['name'];
    $msgExtra = [];
    $db->beginTransaction();
    try {
        // Barang Keluar di Stok Barang
        $trxId = (int)($old['stock_trx_id'] ?? 0);
        $stockNote = mb_substr(cL('Pekerjaan CCTV: ', 'CCTV job: ') . $typeName . ($nvrId ? ' — ' . $nvrs[$nvrId]['name'] : ''), 0, 255);
        if ($useStock) {
            if ($trxId) {
                $db->prepare("UPDATE stock_transactions SET category_id=?, type='out', trx_date=?, qty=?, item_name=?, recipient_name=?, recipient_department=?, note=? WHERE id=?")
                   ->execute([$stockCat, $date, $stockQty, $stockItem, 'CCTV', 'IT', $stockNote, $trxId]);
            } else {
                $db->prepare("INSERT INTO stock_transactions (category_id, type, trx_date, qty, item_name, user_id, recipient_name, recipient_department, note, created_by)
                              VALUES (?, 'out', ?, ?, ?, NULL, ?, ?, ?, ?)")
                   ->execute([$stockCat, $date, $stockQty, $stockItem, 'CCTV', 'IT', $stockNote, (int)$me['id']]);
                $trxId = (int)$db->lastInsertId();
            }
            $msgExtra[] = cL('diambil dari Stok Barang: ', 'taken from stock: ') . $stockText;
        } elseif ($trxId) {
            $db->prepare("DELETE FROM stock_transactions WHERE id = ?")->execute([$trxId]);
            $trxId = 0;
        }

        $vals = [$date, $shift, (int)$type['id'], $typeName, $kind, $nvrId ?: null, $camId ?: null, json_encode($detail, JSON_UNESCAPED_UNICODE),
                 $status, $officers, $note !== '' ? $note : null, json_encode($photos), $trxId ?: null, $stockText];
        if ($id) {
            $db->prepare("UPDATE cctv_jobs SET job_date=?, shift=?, type_id=?, type_name=?, kind=?, nvr_id=?, camera_id=?, detail=?, status=?, officers=?, note=?, photos=?, stock_trx_id=?, stock_text=?, updated_at=? WHERE id=?")
               ->execute(array_merge($vals, [$now, $id]));
        } else {
            $db->prepare("INSERT INTO cctv_jobs (job_date, shift, type_id, type_name, kind, nvr_id, camera_id, detail, status, officers, note, photos, stock_trx_id, stock_text, created_by, created_by_name, created_at, updated_at)
                          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
               ->execute(array_merge($vals, [(int)$me['id'], (string)$me['full_name'], $now, $now]));
            $id = (int)$db->lastInsertId();
        }

        // Tambah titik: aset kamera (hanya sekali, saat belum ada aset terkait)
        if ($kind === 'add') {
            $hasLinks = $db->prepare("SELECT COUNT(*) FROM cctv_job_assets WHERE job_id = ?");
            $hasLinks->execute([$id]);
            $mode = (string)($p['asset_mode'] ?? 'none');
            if ((int)$hasLinks->fetchColumn() === 0 && in_array($mode, ['stock', 'new'], true)) {
                $ch = (int)$detail['ch'];
                $link = $db->prepare("INSERT INTO cctv_job_assets (job_id, asset_id, mode) VALUES (?,?,?)");
                if ($mode === 'stock') {
                    $pick = array_values(array_unique(array_filter(array_map('intval', (array)($p['stock_cams'] ?? [])))));
                    $okIds = array_column(cctvJobStockCameras($db), 'id');
                    $n = 0;
                    foreach ($pick as $aid) {
                        if (!in_array($aid, array_map('intval', $okIds), true)) continue;
                        $db->prepare("UPDATE assets SET status = 'Digunakan'" . ($detail['loc'] !== '' ? ", location = ?" : "") . " WHERE id = ?")
                           ->execute($detail['loc'] !== '' ? [$detail['loc'], $aid] : [$aid]);
                        saveCameraNvr($db, $aid, $nvrId, $ch ? $ch + $n : 0);
                        $link->execute([$id, $aid, 'stock']);
                        $n++;
                    }
                    if ($n) $msgExtra[] = $n . cL(' kamera stok jadi Digunakan', ' stock camera(s) set to In use');
                } else {
                    require_once __DIR__ . '/cctv_import.php';
                    require_once __DIR__ . '/asset_number.php';
                    $cat = cctvImpCategories($db)['cctv'][0] ?? '';
                    if ($cat === '') throw new RuntimeException(cL('Kategori aset CCTV belum ada di Kategori Aset.', 'No CCTV asset category found.'));
                    $res = ['numbers' => []];
                    for ($k = 0; $k < $detail['qty']; $k++) {
                        $aid = cctvImpSaveAsset($db, 0, $cat, '', [
                            'device_name' => mb_substr('CCTV ' . ($detail['loc'] !== '' ? $detail['loc'] : ($nvrId ? $nvrs[$nvrId]['name'] : '')) . ($detail['qty'] > 1 ? ' ' . ($k + 1) : ''), 0, 100),
                            'location' => $detail['loc'], 'motherboard_brand' => $detail['model'], 'status' => 'Digunakan',
                        ], $res);
                        saveCctvInfo($db, $aid, '', $detail['model']);
                        saveCameraNvr($db, $aid, $nvrId, $ch ? $ch + $k : 0);
                        $link->execute([$id, $aid, 'new']);
                    }
                    $msgExtra[] = count($res['numbers']) . cL(' aset CCTV baru: ', ' new CCTV asset(s): ') . implode(', ', $res['numbers']);
                }
            }
        }
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        return ['ok' => false, 'msg' => cL('Gagal menyimpan pekerjaan: ', 'Failed to save job: ') . $e->getMessage()];
    }
    return ['ok' => true, 'msg' => cL('Pekerjaan CCTV disimpan.', 'CCTV job saved.') . ($msgExtra ? ' ' . ucfirst(implode('; ', $msgExtra)) . '.' : '')];
}

/** Hapus 1 pekerjaan + Barang Keluar-nya (aset kamera yang sudah dibuat / dipakai tetap ada). */
function cctvJobDelete(PDO $db, int $id): array
{
    cctvJobsEnsure($db);
    $st = $db->prepare("SELECT * FROM cctv_jobs WHERE id = ?");
    $st->execute([$id]);
    $j = $st->fetch();
    if (!$j) return ['ok' => false, 'msg' => cL('Pekerjaan tidak ditemukan.', 'Job not found.')];
    $db->beginTransaction();
    try {
        if ((int)$j['stock_trx_id']) $db->prepare("DELETE FROM stock_transactions WHERE id = ?")->execute([(int)$j['stock_trx_id']]);
        $db->prepare("DELETE FROM cctv_job_assets WHERE job_id = ?")->execute([$id]);
        $db->prepare("DELETE FROM cctv_jobs WHERE id = ?")->execute([$id]);
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        return ['ok' => false, 'msg' => $e->getMessage()];
    }
    foreach (json_decode((string)$j['photos'], true) ?: [] as $ph) @unlink(CCTV_PHOTO_DIR . '/' . $ph);
    return ['ok' => true, 'msg' => cL('Pekerjaan dihapus', 'Job deleted') . ((int)$j['stock_trx_id'] ? cL(', barang dikembalikan ke stok.', ', items returned to stock.') : '.')];
}

/** Tabel pekerjaan untuk dokumen cetak / PDF (checklist shift & laporan bulanan). */
function cctvJobsDocHtml(array $jobs, bool $withDate): string
{
    $h = fn($v) => htmlspecialchars((string)$v);
    if (!$jobs) return '<p class="legend">' . $h(cL('Tidak ada pekerjaan CCTV.', 'No CCTV jobs.')) . '</p>';
    $o = '<table class="g"><thead><tr>' . ($withDate ? '<th>' . $h(cL('Tanggal', 'Date')) . '</th>' : '') . '<th>' . $h(cL('Pekerjaan', 'Job')) . '</th><th>NVR / ' . $h(cL('Kamera', 'Camera')) . '</th><th>'
       . $h(cL('Rincian', 'Details')) . '</th><th>' . $h(cL('Petugas', 'Officer')) . '</th><th>Status</th></tr></thead><tbody>';
    foreach ($jobs as $j) {
        $lines = cctvJobDetailLines($j);
        if (!empty($j['note'])) $lines[] = $j['note'];
        $o .= '<tr>' . ($withDate ? '<td class="c">' . $h(date('d/m/Y', strtotime($j['job_date']))) . ($j['shift'] !== '' ? '<br>' . $h($j['shift']) : '') . '</td>' : '')
            . '<td>' . $h($j['type_name']) . '</td><td>' . $h(trim($j['nvr_name'] . ($j['camera_label'] !== '' ? ' · ' . $j['camera_label'] : ''), ' ·') ?: '-') . '</td>'
            . '<td>' . implode('<br>', array_map($h, $lines)) . '</td><td>' . $h($j['officers'] ?: $j['created_by_name']) . '</td>'
            . '<td class="c' . ($j['status'] === 'ok' ? '' : ' x') . '">' . $h(cctvJobStatuses()[$j['status']] ?? $j['status']) . '</td></tr>';
    }
    return $o . '</tbody></table>';
}
