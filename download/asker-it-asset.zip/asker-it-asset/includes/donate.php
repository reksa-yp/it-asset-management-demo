<?php
/**
 * Ajakan donasi (khusus admin). Popup tampil setiap aplikasi dibuka, sampai admin memasukkan KODE DONATUR.
 *
 * Cara kerja kode: kode ditandatangani dengan kunci privat milik pembuat aplikasi (Ed25519) dan diperiksa di sini
 * memakai kunci publik di bawah, jadi kode tidak bisa dibuat sembarang orang. Pemeriksaan berjalan offline di server,
 * tanpa koneksi internet. Setelah kode benar, popup hilang untuk semua admin di server ini.
 *
 * Catatan: aplikasi ini open source, jadi popup tetap bisa dihapus dari kode oleh pemilik server. Ini ajakan, bukan kunci.
 */
const DONATE_PUBLIC_KEY_HEX = '1093aac75492ba1747cbab486cd300163601282a5c3f565a94569d75b854a824';
const DONATE_SAWERIA_URL    = 'https://saweria.co/reksayp';
// Kontak pengembang untuk meminta kode donatur setelah donasi. Kosongkan yang tidak dipakai.
const DONATE_CONTACT_WA    = '6285176968472';   // nomor WhatsApp format internasional tanpa +, mis. 6281234567890
const DONATE_CONTACT_EMAIL = 'reksayp@gmail.com';   // mis. nama@domain.com

function donateFile(): string { return __DIR__ . '/data/donor.json'; }

function donateB64d(string $s): string
{
    return (string)base64_decode(strtr($s, '-_', '+/') . str_repeat('=', (4 - strlen($s) % 4) % 4), true);
}

/** Memeriksa kode "DNR1.<nama>.<tanda tangan>". Mengembalikan nama donatur bila sah, atau null. */
function donateVerifyCode(string $code): ?string
{
    if (!function_exists('sodium_crypto_sign_verify_detached')) return null;
    $parts = explode('.', trim($code));
    if (count($parts) !== 3 || $parts[0] !== 'DNR1') return null;
    $name = donateB64d($parts[1]);
    $sig  = donateB64d($parts[2]);
    if ($name === '' || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) return null;
    try {
        $ok = sodium_crypto_sign_verify_detached($sig, 'asker-donor-v1|' . $name, sodium_hex2bin(DONATE_PUBLIC_KEY_HEX));
    } catch (Throwable $e) { return null; }
    return $ok ? $name : null;
}

/** Sudah ada kode donatur yang sah tersimpan? */
function donateIsDonor(): bool
{
    static $cache = null;
    if ($cache !== null) return $cache;
    $f = donateFile();
    if (!is_file($f)) return $cache = false;
    $d = json_decode((string)file_get_contents($f), true);
    return $cache = (is_array($d) && !empty($d['code']) && donateVerifyCode((string)$d['code']) !== null);
}

function donateSave(string $code, string $name): bool
{
    $dir = dirname(donateFile());
    if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) return false;
    return file_put_contents(donateFile(), json_encode(['code' => $code, 'name' => $name, 'at' => date('c')]), LOCK_EX) !== false;
}
