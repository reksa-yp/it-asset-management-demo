<?php
/**
 * Foto permasalahan tiket IT (dilampirkan user saat membuat tiket).
 *
 * Tanpa mengubah tabel lama: foto disimpan di tabel baru ticket_photos (dibuat otomatis,
 * CREATE TABLE IF NOT EXISTS) dan file-nya di assets/uploads/tickets/TAHUN/BULAN/.
 * Foto dikecilkan dulu di HP/PC sebelum dikirim (maks. 1600 px), jadi rata-rata ±200–400 KB.
 */

const TICKET_PHOTO_DIR = __DIR__ . '/../assets/uploads/tickets';
const TICKET_PHOTO_URL = 'assets/uploads/tickets';
const TICKET_PHOTO_MAX = 3;                 // maks. foto per tiket
const TICKET_PHOTO_MAX_BYTES = 8388608;     // 8 MB per file (setelah dikecilkan biasanya < 500 KB)

function tpL(string $id, string $en): string
{
    return (function_exists('currentLang') && currentLang() === 'en') ? $en : $id;
}

function ensureTicketPhotoTable(PDO $db): void
{
    static $done = false;
    if ($done) return;
    try {
    $db->exec("CREATE TABLE IF NOT EXISTS ticket_photos (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        ticket_id INT UNSIGNED NOT NULL,
        file_path VARCHAR(255) NOT NULL,
        uploaded_by INT UNSIGNED NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_ticket (ticket_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) { /* tabel sudah ada / dibuat manual */ }
    $done = true;
}

/** Simpan foto dari input name="photos[]". Return jumlah foto yang tersimpan. */
function ticketSavePhotos(PDO $db, int $ticketId, $files, int $userId): int
{
    if (!is_array($files) || !isset($files['name']) || !is_array($files['name'])) return 0;
    ensureTicketPhotoTable($db);
    $sub = date('Y/m');
    $dir = TICKET_PHOTO_DIR . '/' . $sub;
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return 0;
    $ins = $db->prepare("INSERT INTO ticket_photos (ticket_id, file_path, uploaded_by, created_at) VALUES (?, ?, ?, ?)");
    $saved = 0;
    foreach (array_keys($files['name']) as $i) {
        if ($saved >= TICKET_PHOTO_MAX) break;
        if (($files['error'][$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;
        $tmp = (string)$files['tmp_name'][$i];
        if (!is_uploaded_file($tmp) || (int)$files['size'][$i] > TICKET_PHOTO_MAX_BYTES) continue;
        $mime = (@getimagesize($tmp))['mime'] ?? '';
        $ext  = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? '';
        if ($ext === '') continue;
        $name = 'tiket_' . $ticketId . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        if (!move_uploaded_file($tmp, $dir . '/' . $name)) continue;
        $ins->execute([$ticketId, $sub . '/' . $name, $userId ?: null, date('Y-m-d H:i:s')]);
        $saved++;
    }
    return $saved;
}

/** [ticket_id => [url, url, ...]] untuk daftar tiket. */
function ticketPhotosMap(PDO $db, array $ticketIds): array
{
    $ticketIds = array_values(array_unique(array_filter(array_map('intval', $ticketIds))));
    if (!$ticketIds) return [];
    try {
        ensureTicketPhotoTable($db);
        $st = $db->prepare("SELECT ticket_id, file_path FROM ticket_photos WHERE ticket_id IN (" . implode(',', array_fill(0, count($ticketIds), '?')) . ") ORDER BY id");
        $st->execute($ticketIds);
    } catch (Throwable $e) {
        return [];
    }
    $out = [];
    foreach ($st->fetchAll() as $r) $out[(int)$r['ticket_id']][] = TICKET_PHOTO_URL . '/' . $r['file_path'];
    return $out;
}

/** Hapus foto (file + baris) milik tiket yang dihapus. */
function ticketDeletePhotos(PDO $db, array $ticketIds): void
{
    $ticketIds = array_values(array_unique(array_filter(array_map('intval', $ticketIds))));
    if (!$ticketIds) return;
    try {
        ensureTicketPhotoTable($db);
        $in = implode(',', array_fill(0, count($ticketIds), '?'));
        $st = $db->prepare("SELECT file_path FROM ticket_photos WHERE ticket_id IN ($in)");
        $st->execute($ticketIds);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $p) {
            $f = TICKET_PHOTO_DIR . '/' . $p;
            if (strpos($p, '..') === false && is_file($f)) @unlink($f);
        }
        $db->prepare("DELETE FROM ticket_photos WHERE ticket_id IN ($in)")->execute($ticketIds);
    } catch (Throwable $e) {
        // foto hanya pelengkap: penghapusan tiket tetap berjalan
    }
}

/** Deretan thumbnail foto tiket (klik = perbesar). */
function ticketPhotoThumbs(array $urls): string
{
    if (!$urls) return '';
    $h = '<div class="flex flex-wrap gap-1.5 mt-1.5">';
    foreach ($urls as $i => $u) {
        $e = htmlspecialchars($u, ENT_QUOTES);
        $h .= '<button type="button" class="ticket-photo block w-16 h-16 rounded-lg overflow-hidden border border-slate-200 hover:ring-2 hover:ring-blue-400" data-src="' . $e . '" title="'
            . htmlspecialchars(tpL('Foto ', 'Photo ') . ($i + 1), ENT_QUOTES) . '"><img src="' . $e . '" alt="" loading="lazy" class="w-full h-full object-cover"></button>';
    }
    return $h . '</div>';
}
