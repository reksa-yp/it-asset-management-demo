<?php
/**
 * Fitur Upgrade Aset: mencatat komponen yang di-upgrade (RAM, Storage, OS, dll.),
 * langsung memperbarui data aset, dan menyimpan riwayatnya.
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA:
 * - Hanya MEMBUAT 2 tabel BARU jika belum ada: asset_upgrade_logs & asset_upgrade_log_items.
 * - Tidak ALTER / DROP tabel lama. Tanpa foreign key ke tabel lama.
 * - Yang berubah di tabel lama hanya ISI kolom aset yang di-upgrade (mis. assets.ram),
 *   sama seperti saat aset diedit lewat menu Aset.
 *
 * Dipakai oleh: asset_upgrade.php (form), dashboard.php (tombol Proses Upgrade),
 * my_asset.php (tab History), includes/asset_detail_template.php (print & PDF).
 */

const UPGRADE_FIELD_OTHER    = '__other';
const UPGRADE_FIELD_SOFTWARE = '__software';

function upgradeLogTablesExist(PDO $db, bool $refresh = false): bool
{
    static $exists = null;
    if ($exists === null || $refresh) {
        $exists = (int)$db->query("SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('asset_upgrade_logs','asset_upgrade_log_items')")->fetchColumn() === 2;
    }
    return $exists;
}

/** Buat tabel riwayat upgrade jika belum ada (CREATE TABLE IF NOT EXISTS — tidak menyentuh tabel lain). */
function ensureUpgradeLogTables(PDO $db): void
{
    if (upgradeLogTablesExist($db)) return;
    $db->exec("
        CREATE TABLE IF NOT EXISTS asset_upgrade_logs (
            id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            asset_id      INT NOT NULL,
            ticket_id     INT NULL,
            upgrade_date  DATE NOT NULL,
            notes         TEXT NULL,
            created_by    VARCHAR(150) NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_asset (asset_id),
            KEY idx_ticket (ticket_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $db->exec("
        CREATE TABLE IF NOT EXISTS asset_upgrade_log_items (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            log_id      INT UNSIGNED NOT NULL,
            field_name  VARCHAR(60)  NOT NULL,
            label       VARCHAR(150) NOT NULL,
            old_value   TEXT NULL,
            new_value   TEXT NULL,
            KEY idx_log (log_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    upgradeLogTablesExist($db, true);
}

/**
 * Komponen yang bisa di-upgrade. Key = nama kolom di tabel assets
 * (kecuali __software & __other yang hanya dicatat di riwayat / tabel software).
 */
function upgradeFieldDefs(): array
{
    return [
        'ram'               => ['label' => t('lbl_ram')],
        'storage'           => ['label' => t('lbl_storage')],
        'processor'         => ['label' => t('lbl_processor')],
        'motherboard_brand' => ['label' => t('lbl_motherboard')],
        'monitor_info'      => ['label' => t('lbl_monitor')],
        'printer_info'      => ['label' => t('lbl_printer')],
        'accessories'       => ['label' => t('lbl_accessories')],
        'os_name'           => ['label' => t('lbl_os')],
        'os_status'         => ['label' => t('lbl_os_license_status'), 'options' => [
            'Original' => t('os_original'), 'Belum Original' => t('os_not_original'),
        ]],
        UPGRADE_FIELD_SOFTWARE => ['label' => t('upg_field_software')],
        UPGRADE_FIELD_OTHER    => ['label' => t('upg_field_other')],
    ];
}

/** Label tampilan 1 item riwayat (pakai bahasa aktif; item "Lainnya" pakai nama yang diketik admin). */
function upgradeItemLabel(array $item): string
{
    $defs = upgradeFieldDefs();
    if ($item['field_name'] === UPGRADE_FIELD_OTHER || !isset($defs[$item['field_name']])) return (string)$item['label'];
    if ($item['field_name'] === UPGRADE_FIELD_SOFTWARE) return t('upg_label_software');
    return $defs[$item['field_name']]['label'];
}

/** Nilai tampilan (status OS diterjemahkan). */
function upgradeItemValue(array $item, string $which): string
{
    $v = (string)($item[$which] ?? '');
    if ($item['field_name'] === 'os_status' && $v !== '') {
        return $v === 'Original' ? t('os_original') : t('os_not_original');
    }
    return $v;
}

/**
 * Saran isian dari catatan tiket, mis. "RAM 4 GB sudah tidak cukup, harus upgrade ke 8 GB."
 * -> [['key' => 'ram', 'after' => '8 GB']]. Admin tetap bisa mengubahnya di form.
 */
function suggestUpgradeRows(string $text): array
{
    $t = ' ' . mb_strtolower($text) . ' ';
    $after = preg_match('/\bke\s+([^.,;\n]+)/iu', $text, $m) ? trim($m[1]) : '';
    $rows = [];
    if (preg_match('/\bram\b|memori/u', $t)) {
        $v = preg_match('/(\d+)\s*gb/i', $after, $mm) ? $mm[1] . ' GB' : $after;
        $rows[] = ['key' => 'ram', 'after' => $v];
    }
    if (preg_match('/\bssd\b|\bhdd\b|storage|hardisk|hard disk|nvme/u', $t)) {
        $v = $after;
        if ($v !== '' && !preg_match('/ssd|hdd|nvme/i', $v) && strpos($t, 'ssd') !== false) $v = 'SSD ' . $v;
        $v = preg_replace(['/\s*gb\b/i', '/\s*tb\b/i', '/\bssd\b/i', '/\bhdd\b/i'], [' GB', ' TB', 'SSD', 'HDD'], $v);
        $rows[] = ['key' => 'storage', 'after' => trim($v)];
    }
    if (preg_match('/windows|lisensi|\bos\b/u', $t)) {
        if (preg_match('/windows[^.,;\n]*/i', $after, $mm)) $rows[] = ['key' => 'os_name', 'after' => trim($mm[0])];
        if (preg_match('/original|lisensi/u', $t)) $rows[] = ['key' => 'os_status', 'after' => 'Original'];
    }
    if (preg_match('/processor|prosesor|\bcpu\b/u', $t) && !preg_match('/suhu cpu/u', $t)) $rows[] = ['key' => 'processor', 'after' => $after];
    if (preg_match('/\bpsu\b|power supply/u', $t)) $rows[] = ['key' => UPGRADE_FIELD_OTHER, 'label' => 'PSU', 'after' => ''];
    if (preg_match('/monitor/u', $t)) $rows[] = ['key' => 'monitor_info', 'after' => $after];
    return $rows;
}

/**
 * Simpan 1 upgrade: catat riwayat + perbarui data aset (dalam 1 transaksi).
 * $items: [['key'=>..,'label'=>..,'before'=>..,'after'=>..,'sw_status'=>..], ...] (sudah divalidasi).
 * Return ID log upgrade.
 */
function saveAssetUpgrade(PDO $db, int $assetId, ?int $ticketId, string $date, string $notes, array $items, string $byName): int
{
    ensureUpgradeLogTables($db);
    $db->beginTransaction();
    try {
        $db->prepare("INSERT INTO asset_upgrade_logs (asset_id, ticket_id, upgrade_date, notes, created_by, created_at)
                      VALUES (?, ?, ?, ?, ?, NOW())")
           ->execute([$assetId, $ticketId ?: null, $date, $notes !== '' ? $notes : null, $byName]);
        $logId = (int)$db->lastInsertId();

        $insItem = $db->prepare("INSERT INTO asset_upgrade_log_items (log_id, field_name, label, old_value, new_value) VALUES (?, ?, ?, ?, ?)");
        $defs = upgradeFieldDefs();
        $set = [];
        $params = [];
        foreach ($items as $it) {
            $insItem->execute([$logId, $it['key'], $it['label'], $it['before'] !== '' ? $it['before'] : null, $it['after']]);
            if ($it['key'] === UPGRADE_FIELD_SOFTWARE) {
                // Tambahkan ke daftar software aset (tabel asset_software), tanpa menghapus yang lama.
                if (function_exists('assetSoftwareTableExists') && assetSoftwareTableExists($db)) {
                    $next = (int)$db->query("SELECT COALESCE(MAX(sort_order), -1) + 1 FROM asset_software WHERE asset_id = " . (int)$assetId)->fetchColumn();
                    $db->prepare("INSERT INTO asset_software (asset_id, software_name, serial_number, status, sort_order) VALUES (?, ?, NULL, ?, ?)")
                       ->execute([$assetId, $it['after'], $it['sw_status'] === 'Original' ? 'Original' : 'Belum Original', $next]);
                }
            } elseif ($it['key'] !== UPGRADE_FIELD_OTHER && isset($defs[$it['key']])) {
                $set[] = "`{$it['key']}` = ?";           // key berasal dari daftar tetap upgradeFieldDefs()
                $params[] = $it['after'];
            }
        }
        if ($set) {
            $params[] = $assetId;
            $db->prepare("UPDATE assets SET " . implode(', ', $set) . " WHERE id = ?")->execute($params);
        }
        $db->commit();
        return $logId;
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        throw $e;
    }
}

/** Riwayat upgrade 1 aset (terbaru dulu), lengkap dengan item & nomor tiket. */
function getAssetUpgradeHistory(PDO $db, int $assetId): array
{
    if (!upgradeLogTablesExist($db)) return [];
    $st = $db->prepare("
        SELECT l.*, t.ticket_number
        FROM asset_upgrade_logs l
        LEFT JOIN tickets t ON t.id = l.ticket_id
        WHERE l.asset_id = ?
        ORDER BY l.upgrade_date DESC, l.id DESC
    ");
    $st->execute([$assetId]);
    $logs = $st->fetchAll();
    if (!$logs) return [];
    $ids = array_column($logs, 'id');
    $in = implode(',', array_fill(0, count($ids), '?'));
    $st = $db->prepare("SELECT * FROM asset_upgrade_log_items WHERE log_id IN ($in) ORDER BY id");
    $st->execute($ids);
    $byLog = [];
    foreach ($st->fetchAll() as $it) $byLog[$it['log_id']][] = $it;
    foreach ($logs as &$l) $l['items'] = $byLog[$l['id']] ?? [];
    return $logs;
}

/** Tanggal upgrade terakhir per kolom: ['ram' => '2026-09-29', ...] */
function getLastUpgradedFields(PDO $db, int $assetId): array
{
    if (!upgradeLogTablesExist($db)) return [];
    $st = $db->prepare("SELECT i.field_name, MAX(l.upgrade_date) AS d
        FROM asset_upgrade_log_items i JOIN asset_upgrade_logs l ON l.id = i.log_id
        WHERE l.asset_id = ? GROUP BY i.field_name");
    $st->execute([$assetId]);
    return array_column($st->fetchAll(), 'd', 'field_name');
}

/** Kartu riwayat upgrade untuk tampilan layar (Tailwind), dipakai asset_upgrade.php & my_asset.php. */
function renderUpgradeHistoryCards(array $logs, ?int $highlightId = null): string
{
    $h = fn($v) => htmlspecialchars((string)$v);
    if (!$logs) return '<p class="text-sm text-slate-400 text-center py-4">' . $h(t('upg_history_empty')) . '</p>';
    $out = '<div class="space-y-3">';
    foreach ($logs as $l) {
        $ring = ($highlightId && (int)$l['id'] === $highlightId) ? ' ring-2 ring-brand-300' : '';
        $out .= '<div class="rounded-xl border border-brand-200 bg-brand-50/60 p-3' . $ring . '">'
             . '<div class="flex items-center justify-between gap-2 mb-1 flex-wrap">'
             . '<span class="inline-flex items-center gap-1.5 text-sm font-semibold text-brand-700">' . icon('arrow-up', 'w-4 h-4') . ' ' . $h(t('upg_badge')) . '</span>'
             . '<span class="text-xs text-slate-500">' . date('d M Y', strtotime($l['upgrade_date'])) . '</span></div>'
             . '<ul class="text-xs text-slate-700 space-y-0.5 my-2">';
        foreach ($l['items'] as $it) {
            $before = upgradeItemValue($it, 'old_value');
            $out .= '<li><b>' . $h(upgradeItemLabel($it)) . ':</b> '
                  . ($before !== '' ? '<span class="text-slate-400 line-through">' . $h($before) . '</span> &rarr; ' : '')
                  . '<span class="font-semibold text-slate-800">' . $h(upgradeItemValue($it, 'new_value')) . '</span></li>';
        }
        $out .= '</ul>'
             . ($l['notes'] ? '<p class="text-xs text-slate-600"><b>' . $h(t('upg_notes')) . ':</b> ' . nl2br($h($l['notes'])) . '</p>' : '')
             . '<p class="text-xs text-slate-400 mt-1">' . $h(t('upg_by')) . ' ' . $h($l['created_by'] ?: t('dash'))
             . ($l['ticket_number'] ? ' &middot; ' . $h(t('upg_from_ticket')) . ' ' . $h($l['ticket_number']) : ' &middot; ' . $h(t('upg_no_ticket')))
             . '</p></div>';
    }
    return $out . '</div>';
}
