<?php
/**
 * Fitur Stok Barang (barang habis pakai / sparepart IT).
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA:
 * - Hanya MEMBUAT 2 tabel BARU jika belum ada: stock_categories & stock_transactions.
 * - Tidak ALTER / DROP / mengubah tabel lama (users, assets, tickets, dll).
 * - Tidak memakai foreign key ke tabel users, jadi tidak ada constraint yang ditempel
 *   ke tabel lama. Nama & departement penerima disimpan sebagai salinan (snapshot),
 *   sehingga riwayat tetap utuh walau user nanti diubah/dihapus.
 *
 * Tabel dibuat otomatis saat halaman Stok Barang pertama kali dibuka oleh admin
 * (lihat ensureStockTables). Bisa juga dibuat manual lewat sql/stock_tables.sql.
 */

function stockTablesExist(PDO $db): bool
{
    static $exists = null;
    if ($exists === null) {
        $stmt = $db->query("
            SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('stock_categories','stock_transactions')
        ");
        $exists = ((int)$stmt->fetchColumn() === 2);
    }
    return $exists;
}

/** Buat tabel stok jika belum ada (CREATE TABLE IF NOT EXISTS — tidak menyentuh tabel lain). */
function ensureStockTables(PDO $db): void
{
    if (stockTablesExist($db)) return;

    $db->exec("
        CREATE TABLE IF NOT EXISTS stock_categories (
            id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name        VARCHAR(60)  NOT NULL UNIQUE,
            unit        VARCHAR(20)  NOT NULL DEFAULT 'pcs',
            min_stock   INT UNSIGNED NOT NULL DEFAULT 0,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $db->exec("
        CREATE TABLE IF NOT EXISTS stock_transactions (
            id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            category_id           INT UNSIGNED NOT NULL,
            type                  ENUM('in','out') NOT NULL,
            trx_date              DATE NOT NULL,
            qty                   INT UNSIGNED NOT NULL,
            item_name             VARCHAR(100) DEFAULT NULL,
            user_id               INT UNSIGNED DEFAULT NULL,
            recipient_name        VARCHAR(100) DEFAULT NULL,
            recipient_department  VARCHAR(100) DEFAULT NULL,
            note                  VARCHAR(255) DEFAULT NULL,
            created_by            INT UNSIGNED DEFAULT NULL,
            created_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_stock_cat_date (category_id, trx_date),
            INDEX idx_stock_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // Isi beberapa kategori awal hanya jika tabel kategori masih kosong.
    if ((int)$db->query("SELECT COUNT(*) FROM stock_categories")->fetchColumn() === 0) {
        $ins = $db->prepare("INSERT INTO stock_categories (name, unit, min_stock) VALUES (?,?,?)");
        foreach ([['Mouse','pcs',5], ['Keyboard','pcs',3], ['Toner Printer','pcs',3], ['Kabel LAN','roll',1], ['Flashdisk','pcs',3]] as $c) {
            $ins->execute($c);
        }
    }
}

function getStockCategories(PDO $db): array
{
    return $db->query("SELECT * FROM stock_categories ORDER BY name")->fetchAll();
}

/** Stok tersedia sekarang untuk 1 kategori (semua waktu), opsional mengabaikan 1 transaksi (saat edit). */
function stockAvailable(PDO $db, int $categoryId, int $exceptId = 0): int
{
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(CASE WHEN type='in' THEN qty ELSE -qty END),0)
        FROM stock_transactions WHERE category_id = ? AND id <> ?
    ");
    $stmt->execute([$categoryId, $exceptId]);
    return (int)$stmt->fetchColumn();
}

/**
 * Stok tersedia per barang (kategori + nama barang) dari transaksi Barang Masuk dikurangi Barang Keluar.
 * Nama barang dibandingkan tanpa beda huruf besar/kecil & spasi di ujung. Opsional abaikan 1 transaksi (saat edit/hapus).
 */
function stockItemAvailable(PDO $db, int $categoryId, string $itemName, int $exceptId = 0): int
{
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(CASE WHEN type='in' THEN qty ELSE -qty END),0)
        FROM stock_transactions
        WHERE category_id = ? AND LOWER(TRIM(COALESCE(item_name,''))) = LOWER(TRIM(?)) AND id <> ?
    ");
    $stmt->execute([$categoryId, $itemName, $exceptId]);
    return (int)$stmt->fetchColumn();
}

/**
 * Daftar barang yang pernah dicatat lewat Barang Masuk, per kategori, dengan stok tersedianya.
 * Dipakai form Barang Keluar supaya barang dipilih dari stok, bukan diketik manual.
 * Return: [['cat' => id, 'item' => 'Nama', 's' => stok], ...]
 */
function getStockItems(PDO $db): array
{
    $rows = $db->query("
        SELECT category_id, LOWER(TRIM(COALESCE(item_name,''))) AS item_key,
               MAX(CASE WHEN type='in' THEN item_name END) AS item_label,
               SUM(CASE WHEN type='in' THEN qty ELSE -qty END) AS s,
               SUM(CASE WHEN type='in' THEN 1 ELSE 0 END) AS n_in
        FROM stock_transactions
        GROUP BY category_id, LOWER(TRIM(COALESCE(item_name,'')))
        ORDER BY item_key
    ")->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        if ((int)$r['n_in'] === 0) continue;   // hanya barang yang pernah masuk
        $out[] = ['cat' => (int)$r['category_id'], 'item' => trim((string)($r['item_label'] ?? $r['item_key'])), 's' => (int)$r['s']];
    }
    return $out;
}

/** Baca filter dari $_GET (dipakai halaman, export Excel, dan print supaya hasilnya sama). */
function stockFilters(): array
{
    $isDate = fn($d) => (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $d);
    $from = trim($_GET['from'] ?? '');
    $to   = trim($_GET['to'] ?? '');
    if (!isset($_GET['from']) && !isset($_GET['to'])) {   // default: bulan berjalan
        $from = date('Y-m-01');
        $to   = date('Y-m-t');
    }
    $type = $_GET['type'] ?? '';
    return [
        'from' => $isDate($from) ? $from : '',
        'to'   => $isDate($to) ? $to : '',
        'cat'  => max(0, (int)($_GET['cat'] ?? 0)),
        'type' => in_array($type, ['in','out'], true) ? $type : '',
        'q'    => trim($_GET['q'] ?? ''),
    ];
}

/** Query string filter aktif, untuk link Export/Print. */
function stockFilterQuery(array $f): string
{
    return http_build_query(array_filter([
        'from' => $f['from'], 'to' => $f['to'], 'cat' => $f['cat'] ?: '', 'type' => $f['type'], 'q' => $f['q'],
    ], fn($v) => $v !== '' && $v !== null)) ?: 'from=&to=';
}

function stockPeriodLabel(array $f): string
{
    $fmt = fn($d) => date('d M Y', strtotime($d));
    return ($f['from'] ? $fmt($f['from']) : t('stock_period_start')) . ' – ' . ($f['to'] ? $fmt($f['to']) : t('stock_period_now'));
}

/** Daftar transaksi sesuai filter (terbaru dulu, atau terlama dulu untuk laporan). */
function getStockTransactions(PDO $db, array $f, bool $oldestFirst = false): array
{
    $where = []; $p = [];
    if ($f['from']) { $where[] = 't.trx_date >= ?'; $p[] = $f['from']; }
    if ($f['to'])   { $where[] = 't.trx_date <= ?'; $p[] = $f['to']; }
    if ($f['cat'])  { $where[] = 't.category_id = ?'; $p[] = $f['cat']; }
    if ($f['type']) { $where[] = 't.type = ?'; $p[] = $f['type']; }
    if ($f['q'] !== '') {
        $like = '%' . $f['q'] . '%';
        if (stockAssetLinksExist($db)) {
            // Bisa juga dicari pakai Nomor/ID Aset hasil Barang Masuk / yang diserahkan lewat Barang Keluar.
            $where[] = '(c.name LIKE ? OR t.item_name LIKE ? OR t.recipient_name LIKE ? OR t.recipient_department LIKE ? OR t.note LIKE ?
                        OR t.id IN (SELECT l.stock_trx_id FROM stock_asset_links l JOIN assets a ON a.id = l.asset_id WHERE a.asset_number LIKE ?))';
            array_push($p, $like, $like, $like, $like, $like, $like);
        } else {
            $where[] = '(c.name LIKE ? OR t.item_name LIKE ? OR t.recipient_name LIKE ? OR t.recipient_department LIKE ? OR t.note LIKE ?)';
            array_push($p, $like, $like, $like, $like, $like);
        }
    }
    $order = $oldestFirst ? 't.trx_date ASC, t.id ASC' : 't.trx_date DESC, t.id DESC';
    $sql = "SELECT t.*, c.name AS category_name, c.unit
            FROM stock_transactions t JOIN stock_categories c ON c.id = t.category_id"
         . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . " ORDER BY $order";
    $stmt = $db->prepare($sql);
    $stmt->execute($p);
    return $stmt->fetchAll();
}

/** Rekap per kategori untuk periode filter: stok awal, masuk, keluar, sisa, status. */
function getStockRecap(PDO $db, array $f): array
{
    $from = $f['from'] ?: '0000-01-01';
    $to   = $f['to']   ?: '9999-12-31';
    $sql = "
        SELECT c.id, c.name, c.unit, c.min_stock,
            COALESCE(SUM(CASE WHEN t.trx_date < ? THEN (CASE WHEN t.type='in' THEN t.qty ELSE -t.qty END) ELSE 0 END),0) AS opening,
            COALESCE(SUM(CASE WHEN t.type='in'  AND t.trx_date BETWEEN ? AND ? THEN t.qty ELSE 0 END),0) AS qty_in,
            COALESCE(SUM(CASE WHEN t.type='out' AND t.trx_date BETWEEN ? AND ? THEN t.qty ELSE 0 END),0) AS qty_out,
            COALESCE(SUM(CASE WHEN t.trx_date <= ? THEN (CASE WHEN t.type='in' THEN t.qty ELSE -t.qty END) ELSE 0 END),0) AS closing
        FROM stock_categories c
        LEFT JOIN stock_transactions t ON t.category_id = c.id
        " . ($f['cat'] ? 'WHERE c.id = ?' : '') . "
        GROUP BY c.id, c.name, c.unit, c.min_stock
        ORDER BY c.name";
    $p = [$from, $from, $to, $from, $to, $to];
    if ($f['cat']) $p[] = $f['cat'];
    $stmt = $db->prepare($sql);
    $stmt->execute($p);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        foreach (['opening','qty_in','qty_out','closing','min_stock'] as $k) $r[$k] = (int)$r[$k];
        $r['status'] = $r['closing'] <= 0 ? 'empty' : ($r['closing'] <= $r['min_stock'] ? 'low' : 'ok');
    }
    return $rows;
}

/** Rekap barang keluar per user penerima (mengikuti filter). */
function getStockRecapByUser(array $transactions): array
{
    $map = [];
    foreach ($transactions as $t) {
        if ($t['type'] !== 'out') continue;
        $key = $t['user_id'] ? 'u' . $t['user_id'] : 'n' . strtolower((string)$t['recipient_name']);
        if (!isset($map[$key])) {
            $map[$key] = ['name' => $t['recipient_name'] ?: '-', 'department' => $t['recipient_department'] ?: '-',
                          'total' => 0, 'items' => [], 'last' => $t['trx_date']];
        }
        $map[$key]['total'] += (int)$t['qty'];
        $map[$key]['items'][$t['category_name']] = ($map[$key]['items'][$t['category_name']] ?? 0) + (int)$t['qty'];
        if ($t['trx_date'] > $map[$key]['last']) $map[$key]['last'] = $t['trx_date'];
    }
    usort($map, fn($a, $b) => $b['total'] <=> $a['total']);
    return array_values($map);
}

/** Kategori yang stoknya menipis/habis saat ini (untuk Dashboard). */
function getLowStockCategories(PDO $db): array
{
    if (!stockTablesExist($db)) return [];
    $rows = $db->query("
        SELECT c.name, c.unit, c.min_stock,
               COALESCE(SUM(CASE WHEN t.type='in' THEN t.qty ELSE -t.qty END),0) AS stock
        FROM stock_categories c LEFT JOIN stock_transactions t ON t.category_id = c.id
        GROUP BY c.id, c.name, c.unit, c.min_stock
        HAVING stock <= c.min_stock
        ORDER BY stock ASC, c.name
    ")->fetchAll();
    return $rows;
}

function stockStatusLabel(string $s): string
{
    return ['ok' => t('stock_status_ok'), 'low' => t('stock_status_low'), 'empty' => t('stock_status_empty')][$s] ?? $s;
}

/* =====================================================================
 * STOK ASET IT (otomatis dari menu Aset)
 *
 * Semua aset di menu Aset yang berstatus "Stok" (Desktop PC, Laptop, Printer,
 * Monitor, Aksesoris, Tablet, dan kategori lain) otomatis dihitung sebagai stok.
 * HANYA MEMBACA tabel assets yang sudah ada — tidak ada tabel/kolom baru dan
 * tidak ada transaksi yang dicatat ganda, jadi angkanya selalu sinkron:
 *   - aset baru berstatus Stok        -> stok bertambah
 *   - aset diserahkan / status diubah -> stok berkurang
 * ===================================================================== */

/** Rekap per jenis aset: [['name', 'stok', 'used', 'unused', 'total'], ...] */
function getAssetStockSummary(PDO $db): array
{
    $counts = [];
    foreach ($db->query("SELECT category, status, COUNT(*) n FROM assets GROUP BY category, status") as $r) {
        $counts[$r['category']][$r['status']] = (int)$r['n'];
    }
    // Urutan mengikuti menu Kategori Aset; kategori lama yang tidak terdaftar ikut ditampilkan di akhir.
    $names = [];
    $hasCatTable = (bool)$db->query("SELECT COUNT(*) FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_categories'")->fetchColumn();
    if ($hasCatTable) {
        foreach ($db->query("SELECT name FROM asset_categories ORDER BY sort_order, name") as $r) $names[] = $r['name'];
    }
    foreach (array_keys($counts) as $n) if (!in_array($n, $names, true)) $names[] = $n;

    $rows = [];
    foreach ($names as $n) {
        $c = $counts[$n] ?? [];
        $rows[] = [
            'name'   => $n,
            'stok'   => $c['Stok'] ?? 0,
            'used'   => $c['Digunakan'] ?? 0,
            'unused' => $c['Tidak Digunakan'] ?? 0,
            'total'  => array_sum($c),
        ];
    }
    return $rows;
}

/** Daftar unit aset berstatus Stok (opsional difilter per jenis). */
function getAssetStockItems(PDO $db, string $category = ''): array
{
    // SELECT * supaya tetap aman di server yang belum punya kolom purchase_date.
    $sql = "SELECT * FROM assets WHERE status = 'Stok'";
    $params = [];
    if ($category !== '') { $sql .= " AND category = ?"; $params[] = $category; }
    $sql .= " ORDER BY category, asset_number";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/* =====================================================================
 * STOK BER-ID ASET
 * Barang Masuk bisa langsung dibuatkan ID Aset (masuk ke tabel assets
 * berstatus Stok). Hubungan transaksi stok <-> aset disimpan di 1 tabel
 * BARU: stock_asset_links. Tabel lama (assets, stock_transactions, dll)
 * TIDAK diubah strukturnya.
 *   - baris dengan trx type 'in'  = aset dibuat dari Barang Masuk tsb
 *   - baris dengan trx type 'out' = aset diserahkan lewat Barang Keluar tsb
 * ===================================================================== */

const STOCK_ASSET_MAX_UNITS = 50;   // batas unit per Barang Masuk yang dibuatkan ID sekaligus

function stockAssetLinksExist(PDO $db, bool $refresh = false): bool
{
    static $exists = null;
    if ($exists === null || $refresh) {
        $exists = (bool)$db->query("SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'stock_asset_links'")->fetchColumn();
    }
    return $exists;
}

/** Buat tabel penghubung jika belum ada. Panggil SEBELUM beginTransaction (DDL = auto-commit). */
function ensureStockAssetLinkTable(PDO $db): void
{
    if (stockAssetLinksExist($db)) return;
    $db->exec("
        CREATE TABLE IF NOT EXISTS stock_asset_links (
            id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            stock_trx_id  INT UNSIGNED NOT NULL,     -- stock_transactions.id (tanpa foreign key)
            asset_id      INT UNSIGNED NOT NULL,     -- assets.id (tanpa foreign key)
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_sal_trx_asset (stock_trx_id, asset_id),
            INDEX idx_sal_asset (asset_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    stockAssetLinksExist($db, true);
}

function stockLinkAssets(PDO $db, int $trxId, array $assetIds): void
{
    $ins = $db->prepare("INSERT IGNORE INTO stock_asset_links (stock_trx_id, asset_id) VALUES (?, ?)");
    foreach (array_unique(array_map('intval', $assetIds)) as $aid) {
        if ($aid > 0) $ins->execute([$trxId, $aid]);
    }
}

/** Aset yang terhubung ke transaksi-transaksi stok: [trx_id => [['id','asset_number','status'], ...]] */
function getStockTrxAssets(PDO $db, array $trxIds): array
{
    $trxIds = array_values(array_filter(array_map('intval', $trxIds)));
    if (!$trxIds || !stockAssetLinksExist($db)) return [];
    $ph = implode(',', array_fill(0, count($trxIds), '?'));
    $stmt = $db->prepare("SELECT l.stock_trx_id, a.id, a.asset_number, a.status
                          FROM stock_asset_links l JOIN assets a ON a.id = l.asset_id
                          WHERE l.stock_trx_id IN ($ph) ORDER BY a.asset_number");
    $stmt->execute($trxIds);
    $out = [];
    foreach ($stmt->fetchAll() as $r) {
        $out[(int)$r['stock_trx_id']][] = ['id' => (int)$r['id'], 'asset_number' => $r['asset_number'], 'status' => $r['status']];
    }
    return $out;
}

/**
 * Unit ber-ID yang masih berstatus Stok, hasil Barang Masuk (untuk dipilih di Barang Keluar).
 * Return: [['cat' => kategori stok, 'key' => nama barang (lower/trim), 'id' => asset id, 'no' => nomor aset], ...]
 */
function getStockItemUnits(PDO $db): array
{
    if (!stockAssetLinksExist($db)) return [];
    $rows = $db->query("
        SELECT t.category_id, LOWER(TRIM(COALESCE(t.item_name,''))) AS item_key, a.id, a.asset_number
        FROM stock_asset_links l
        JOIN stock_transactions t ON t.id = l.stock_trx_id AND t.type = 'in'
        JOIN assets a ON a.id = l.asset_id AND a.status = 'Stok'
        ORDER BY a.asset_number
    ")->fetchAll();
    return array_map(fn($r) => ['cat' => (int)$r['category_id'], 'key' => $r['item_key'], 'id' => (int)$r['id'], 'no' => $r['asset_number']], $rows);
}

/** Transaksi Barang Masuk asal sebuah aset (null jika aset tidak dibuat dari stok). */
function assetStockSourceTrx(PDO $db, int $assetId): ?array
{
    if (!stockAssetLinksExist($db)) return null;
    $stmt = $db->prepare("SELECT t.* FROM stock_asset_links l JOIN stock_transactions t ON t.id = l.stock_trx_id
                          WHERE l.asset_id = ? AND t.type = 'in' ORDER BY t.id LIMIT 1");
    $stmt->execute([$assetId]);
    return $stmt->fetch() ?: null;
}

/** Riwayat stok 1 aset (masuk & keluar), terlama dulu — dipakai di detail / print / PDF aset. */
function getAssetStockLog(PDO $db, int $assetId): array
{
    if (!stockTablesExist($db) || !stockAssetLinksExist($db)) return [];
    $stmt = $db->prepare("SELECT t.id, t.type, t.trx_date, t.item_name, t.recipient_name, t.recipient_department, t.note,
                                 c.name AS category_name
                          FROM stock_asset_links l
                          JOIN stock_transactions t ON t.id = l.stock_trx_id
                          LEFT JOIN stock_categories c ON c.id = t.category_id
                          WHERE l.asset_id = ? ORDER BY t.trx_date, t.id");
    $stmt->execute([$assetId]);
    return $stmt->fetchAll();
}

/** Jenis aset (asset_categories) untuk pilihan "Daftarkan sebagai aset", plus perkiraan nomor urut berikutnya. */
function getStockAssetCategoryOptions(PDO $db): array
{
    require_once __DIR__ . '/asset_number.php';
    try {
        $rows = $db->query("SELECT name, abbr FROM asset_categories ORDER BY sort_order, name")->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
    $out = [];
    foreach ($rows as $r) {
        $abbr = strtoupper(trim((string)$r['abbr']));
        if ($abbr === '') continue;
        $out[] = ['name' => $r['name'], 'abbr' => $abbr, 'next' => findMaxAssetSeq($db, $abbr) + 1];
    }
    return $out;
}

/** Apakah tabel assets punya kolom tertentu (server lama bisa belum punya purchase_date). */
function assetsHasColumn(PDO $db, string $col): bool
{
    static $cache = [];
    if (!array_key_exists($col, $cache)) {
        $stmt = $db->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS
                              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'assets' AND COLUMN_NAME = ?");
        $stmt->execute([$col]);
        $cache[$col] = (bool)$stmt->fetchColumn();
    }
    return $cache[$col];
}

/**
 * Buat $qty aset berstatus Stok dari 1 transaksi Barang Masuk. Dipanggil DI DALAM transaksi DB.
 * Nomor aset: <Awalan>/STOK/<singkatan jenis>/<urut>. Return: daftar nomor aset yang dibuat.
 */
function createAssetsFromStockIn(PDO $db, int $trxId, string $assetCategory, string $abbr, string $itemName, string $date, int $qty): array
{
    require_once __DIR__ . '/asset_number.php';
    $hasPurchase = assetsHasColumn($db, 'purchase_date');
    $sql = $hasPurchase
        ? "INSERT INTO assets (asset_number, category, device_name, status, purchase_date) VALUES (?, ?, ?, 'Stok', ?)"
        : "INSERT INTO assets (asset_number, category, device_name, status) VALUES (?, ?, ?, 'Stok')";
    $ins = $db->prepare($sql);
    $numbers = [];
    $ids = [];
    for ($i = 0; $i < $qty; $i++) {
        $no = nextAssetNumber($db, $abbr, 'STOK');   // baca nomor tertinggi terbaru tiap unit
        $params = [$no, $assetCategory, mb_substr($itemName, 0, 100)];
        if ($hasPurchase) $params[] = $date;
        $ins->execute($params);
        $ids[] = (int)$db->lastInsertId();
        $numbers[] = $no;
    }
    stockLinkAssets($db, $trxId, $ids);
    return $numbers;
}
