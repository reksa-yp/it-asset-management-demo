<?php
/**
 * Kop surat perusahaan untuk SEMUA dokumen cetak, PDF, dan Excel — bisa diatur admin
 * lewat menu "Kop Surat" (letterhead_settings.php).
 *
 *   Atas  : logo perusahaan (kiri) + ornamen (kanan, opsional)
 *   Bawah : logo kecil (kiri, opsional) + nama & alamat perusahaan (kanan)
 * Kop tampil di SETIAP halaman dokumen.
 *
 * Pengaturan disimpan di includes/data/letterhead.json dan gambarnya di assets/uploads/letterhead/
 * (tanpa database). Selama belum diatur: bagian atas memakai logo aplikasi dari Pengaturan Sistem
 * (kalau ada), bagian bawah kosong.
 *
 * Halaman cetak (browser):
 *     <style><?= letterheadCss() ?></style>
 *     <body> <?= letterheadOpen() ?> ...isi dokumen... <?= letterheadClose() ?> </body>
 * PDF (Dompdf):
 *     '<style>' . letterheadPdfCss() . '</style>' di <head>, lalu letterheadPdfHtml() tepat setelah <body>.
 */

const LETTERHEAD_FILE     = __DIR__ . '/data/letterhead.json';
const LETTERHEAD_DIR      = __DIR__ . '/../assets/uploads/letterhead';
const LETTERHEAD_URL_DIR  = 'assets/uploads/letterhead';
const LETTERHEAD_MAX_SIZE = 2 * 1024 * 1024;                                  // 2 MB per gambar
const LETTERHEAD_TYPES    = ['image/png' => 'png', 'image/jpeg' => 'jpg'];    // format yang aman untuk cetak, PDF & Excel
const LETTERHEAD_SLOTS    = ['logo', 'ornament', 'footer_logo'];
const LETTERHEAD_TIMEZONES = ['Asia/Jakarta' => 'WIB', 'Asia/Makassar' => 'WITA', 'Asia/Jayapura' => 'WIT'];

/** Baca pengaturan kop (cache per-request). */
function letterheadSettings(bool $refresh = false): array
{
    static $cache = null;
    if ($cache === null || $refresh) {
        $cache = ['enabled' => true, 'company_name' => '', 'short_name' => '', 'address' => '',
                  'logo' => '', 'ornament' => '', 'footer_logo' => '', 'timezone' => 'Asia/Jakarta'];
        if (is_file(LETTERHEAD_FILE)) {
            $data = json_decode((string)file_get_contents(LETTERHEAD_FILE), true);
            if (is_array($data)) {
                $cache['enabled']      = !isset($data['enabled']) || (bool)$data['enabled'];
                $cache['company_name'] = trim((string)($data['company_name'] ?? ''));
                $cache['short_name']   = trim((string)($data['short_name'] ?? ''));
                $cache['address']      = trim((string)($data['address'] ?? ''));
                foreach (LETTERHEAD_SLOTS as $slot) $cache[$slot] = basename((string)($data[$slot] ?? ''));
                if (isset(LETTERHEAD_TIMEZONES[$data['timezone'] ?? ''])) $cache['timezone'] = $data['timezone'];
            }
        }
    }
    return $cache;
}

/** Simpan pengaturan kop ke file JSON. */
function saveLetterheadSettings(array $s): bool
{
    $dir = dirname(LETTERHEAD_FILE);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $cut  = fn(string $v, int $n) => function_exists('mb_substr') ? mb_substr($v, 0, $n) : substr($v, 0, $n);
    $data = [
        'enabled'      => !empty($s['enabled']),
        'company_name' => $cut(trim((string)($s['company_name'] ?? '')), 100),
        'short_name'   => $cut(trim((string)($s['short_name'] ?? '')), 30),
        'address'      => $cut(trim(str_replace("\r", '', (string)($s['address'] ?? ''))), 500),
        'timezone'     => isset(LETTERHEAD_TIMEZONES[$s['timezone'] ?? '']) ? $s['timezone'] : 'Asia/Jakarta',
        'updated_at'   => date('Y-m-d H:i:s'),
    ];
    foreach (LETTERHEAD_SLOTS as $slot) $data[$slot] = basename((string)($s[$slot] ?? ''));
    $ok = file_put_contents(LETTERHEAD_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
    letterheadSettings(true);
    return $ok;
}

/** Proses upload 1 gambar kop. ['ok'=>true,'file'=>nama baru atau ''] / ['ok'=>false,'error'=>kunci pesan]. */
function handleLetterheadUpload(string $field, string $slot): array
{
    $f = $_FILES[$field] ?? null;
    if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return ['ok' => true, 'file' => ''];
    if ($f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) return ['ok' => false, 'error' => 'lh_err_upload'];
    if ($f['size'] > LETTERHEAD_MAX_SIZE) return ['ok' => false, 'error' => 'lh_err_too_big'];
    $mime = (@getimagesize($f['tmp_name']))['mime'] ?? '';
    if (!isset(LETTERHEAD_TYPES[$mime])) return ['ok' => false, 'error' => 'lh_err_type'];
    if (!is_dir(LETTERHEAD_DIR) && !@mkdir(LETTERHEAD_DIR, 0775, true)) return ['ok' => false, 'error' => 'lh_err_upload'];
    $name = $slot . '_' . date('Ymd_His') . '.' . LETTERHEAD_TYPES[$mime];
    if (!move_uploaded_file($f['tmp_name'], LETTERHEAD_DIR . '/' . $name)) return ['ok' => false, 'error' => 'lh_err_upload'];
    return ['ok' => true, 'file' => $name];
}

function deleteLetterheadFile(string $file): void
{
    $file = basename($file);
    if ($file !== '' && is_file(LETTERHEAD_DIR . '/' . $file)) @unlink(LETTERHEAD_DIR . '/' . $file);
}

/** Path file gambar kop di server ('' jika tidak ada). Slot 'logo' jatuh ke logo aplikasi bila belum diunggah. */
function letterheadImagePath(string $slot): string
{
    $s = letterheadSettings();
    if (!$s['enabled']) return '';
    $file = $s[$slot] ?? '';
    if ($file !== '' && is_file(LETTERHEAD_DIR . '/' . $file)) return LETTERHEAD_DIR . '/' . $file;
    if ($slot === 'logo' && function_exists('appLogoPath')) return appLogoPath();
    return '';
}

/** URL gambar kop untuk ditampilkan di halaman pengaturan ('' jika tidak ada). */
function letterheadImageUrl(string $slot): string
{
    $file = letterheadSettings()[$slot] ?? '';
    if ($file === '' || !is_file(LETTERHEAD_DIR . '/' . $file)) return '';
    return LETTERHEAD_URL_DIR . '/' . rawurlencode($file) . '?v=' . filemtime(LETTERHEAD_DIR . '/' . $file);
}

/** Gambar kop sebagai data URI (aman untuk print browser maupun Dompdf). */
function letterheadImage(string $slot): string
{
    static $cache = [];
    if (!isset($cache[$slot])) {
        $path = letterheadImagePath($slot);
        $mime = $path !== '' ? ((@getimagesize($path))['mime'] ?? 'image/png') : '';
        $cache[$slot] = $path !== '' ? 'data:' . $mime . ';base64,' . base64_encode((string)file_get_contents($path)) : '';
    }
    return $cache[$slot];
}

/** Nama perusahaan + baris alamat untuk kop bawah (baris pertama dicetak tebal). Kosong = tanpa kop bawah. */
function letterheadAddress(): array
{
    $s = letterheadSettings();
    if (!$s['enabled']) return [];
    $lines = array_values(array_filter(array_map('trim', explode("\n", $s['address'])), fn($l) => $l !== ''));
    if ($s['company_name'] === '' && !$lines) return [];
    return array_merge([$s['company_name']], $lines);
}

/** Ada isi kop atas / bawah? */
function letterheadHas(string $part): bool
{
    if ($part === 'header') return letterheadImagePath('logo') !== '' || letterheadImagePath('ornament') !== '';
    return letterheadImagePath('footer_logo') !== '' || (bool)letterheadAddress();
}

/** Isi kop atas / bawah. Memakai tabel + style inline supaya tampil sama di browser dan Dompdf. */
function letterheadPart(string $part): string
{
    if (!letterheadHas($part)) return '';
    $td = 'border:0;padding:0;background:none;';
    if ($part === 'header') {
        $logo = letterheadImage('logo');
        $orn  = letterheadImage('ornament');
        return '<table style="width:100%;border-collapse:collapse;border:0;"><tr>'
             . '<td style="' . $td . 'text-align:left;vertical-align:middle;">' . ($logo ? '<img src="' . $logo . '" alt="" style="height:18mm;">' : '') . '</td>'
             . '<td style="' . $td . 'text-align:right;vertical-align:middle;">' . ($orn ? '<img src="' . $orn . '" alt="" style="height:18mm;">' : '') . '</td>'
             . '</tr></table>';
    }
    $mark = letterheadImage('footer_logo');
    $addr = letterheadAddress();
    $text = '';
    if ($addr) {
        $first = (string)array_shift($addr);
        if ($first !== '') $text .= '<div style="font-weight:bold;color:#111;">' . htmlspecialchars($first) . '</div>';
        foreach ($addr as $line) $text .= '<div>' . htmlspecialchars($line) . '</div>';
    }
    return '<table style="width:100%;border-collapse:collapse;border:0;"><tr>'
         . '<td style="' . $td . 'text-align:left;vertical-align:bottom;">' . ($mark ? '<img src="' . $mark . '" alt="" style="height:9mm;">' : '') . '</td>'
         . '<td style="' . $td . 'text-align:right;vertical-align:bottom;font-family:Arial,sans-serif;font-size:8.5pt;line-height:1.45;color:#333;">' . $text . '</td>'
         . '</tr></table>';
}

/**
 * Keterangan waktu dokumen dibuat: "Dibuat pada: Rabu, 7 Oktober 2026 09:04" (jam 24 jam),
 * memakai zona waktu yang dipilih di menu Kop Surat (WIB/WITA/WIT), bukan zona waktu PHP server.
 */
function documentCreatedAt(): string
{
    $now = new DateTime('now', new DateTimeZone(letterheadSettings()['timezone']));
    $id  = function_exists('currentLang') ? currentLang() === 'id' : true;
    $days = $id ? ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']
                : ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    $months = $id ? ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
                  : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return ($id ? 'Dibuat pada' : 'Created on') . ': ' . $days[(int)$now->format('w')] . ', ' . $now->format('j') . ' '
         . $months[(int)$now->format('n') - 1] . ' ' . $now->format('Y') . ' ' . $now->format('H:i');
}

/* ------------------------------------------------------------------ Halaman cetak (browser) */

/** CSS kop untuk halaman cetak browser. Letakkan di dalam <style> SETELAH CSS halaman. */
function letterheadCss(): string
{
    $top    = letterheadHas('header') ? 37 : 12;   // ruang atas tiap halaman (mm), termasuk tepi kertas
    $bottom = letterheadHas('footer') ? 39 : 12;
    return '
    /* ===== Kop surat (includes/letterhead.php) ===== */
    .lh-header { height: 19mm; margin-bottom: 6mm; }
    .lh-footer { height: 21mm; margin-top: 8mm; }
    .lh-header:empty, .lh-footer:empty { display: none; }
    table.lh-wrap { width: 100%; border-collapse: collapse; border: 0; }
    table.lh-wrap > thead > tr > td, table.lh-wrap > tbody > tr > td, table.lh-wrap > tfoot > tr > td {
        border: 0; padding: 0; background: none; font-weight: normal;
    }
    table.lh-wrap > tbody > tr { page-break-inside: auto; break-inside: auto; }
    .lh-space-top, .lh-space-bottom { display: none; }
    /* Margin halaman 0: browser tidak punya ruang untuk mencetak tanggal, judul, alamat & nomor halaman
       bawaannya. Jarak tepi kertas diatur di sini (atas 12mm, bawah 10mm, kiri-kanan 14mm). */
    @page { margin: 0; }
    @media print {
        /* Kop menempel di atas & bawah SETIAP halaman; ruang untuknya disediakan thead/tfoot tabel pembungkus. */
        .lh-header { position: fixed; top: 12mm; left: 14mm; right: 14mm; margin: 0; }
        .lh-footer { position: fixed; bottom: 10mm; left: 14mm; right: 14mm; margin: 0; }
        table.lh-wrap > tbody > tr > td { padding: 0 14mm; }
        .lh-space-top { display: block; height: ' . $top . 'mm; }
        .lh-space-bottom { display: block; height: ' . $bottom . 'mm; }
    }
    ';
}

/** Buka pembungkus kop: taruh tepat setelah <body>. */
function letterheadOpen(): string
{
    return '<div class="lh-header">' . letterheadPart('header') . '</div>'
         . '<table class="lh-wrap"><thead><tr><td><div class="lh-space-top"></div></td></tr></thead>'
         . '<tfoot><tr><td><div class="lh-space-bottom"></div></td></tr></tfoot>'
         . '<tbody><tr><td>';
}

/** Tutup pembungkus kop: taruh setelah isi dokumen (sebelum tombol cetak). */
function letterheadClose(): string
{
    return '</td></tr></tbody></table>'
         . '<div class="lh-footer">' . letterheadPart('footer') . '</div>';
}

/* ------------------------------------------------------------------ PDF (Dompdf) */

/** CSS kop untuk Dompdf: margin halaman memberi ruang kop, kop diposisikan tetap di tiap halaman. */
function letterheadPdfCss(): string
{
    $top    = letterheadHas('header') ? 38 : 14;
    $bottom = letterheadHas('footer') ? 36 : 14;
    return '
    @page { margin: ' . $top . 'mm 14mm ' . $bottom . 'mm 14mm; }
    body { margin: 0; }
    .lh-header { position: fixed; top: -27mm; left: 0; right: 0; height: 19mm; }
    .lh-footer { position: fixed; bottom: -28mm; left: 0; right: 0; height: 21mm; }
    ';
}

/** Elemen kop untuk Dompdf: taruh tepat setelah <body> (sebelum isi) supaya muncul di semua halaman. */
function letterheadPdfHtml(): string
{
    $h = letterheadPart('header');
    $f = letterheadPart('footer');
    return ($h !== '' ? '<div class="lh-header">' . $h . '</div>' : '')
         . ($f !== '' ? '<div class="lh-footer">' . $f . '</div>' : '');
}
