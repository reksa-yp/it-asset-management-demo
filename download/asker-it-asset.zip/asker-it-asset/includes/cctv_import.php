<?php
/**
 * Import aset CCTV & NVR dari Excel (template_cctv.xlsx).
 *
 * File berisi 2 sheet data:
 *   - "NVR"  : Nomor Aset | Nama NVR | Lokasi | IP Address | Port HTTP | Brand | Type | Serial Number |
 *              Tanggal Pembelian | Username NVR | Password NVR | Status
 *   - "CCTV" : Nomor Aset | Nama CCTV | Lokasi | IP Address | Brand | Type | NVR | Channel | Status
 * Sheet NVR diproses lebih dulu, jadi kolom NVR di sheet CCTV boleh menyebut NVR yang baru ditambahkan di file yang sama.
 *
 * Aturan:
 *   - Nomor Aset kosong -> aset baru (nomor dibuat otomatis seperti form: IT/STOK/CCTV/001), kecuali IP / nama
 *     sudah dipakai aset CCTV / NVR yang ada -> data itu diperbarui.
 *   - Saat memperbarui, sel kosong = data lama tetap; isi "-" untuk mengosongkan.
 *   - Baris error dilewati, baris lain tetap disimpan. Semua dicek dulu di halaman preview (cctv_import.php).
 * Tidak ada tabel lama yang diubah strukturnya; data masuk ke assets + tabel CCTV yang sudah ada.
 */
require_once __DIR__ . '/categories.php';
require_once __DIR__ . '/cctv.php';
require_once __DIR__ . '/asset_number.php';
require_once __DIR__ . '/xls_number.php';
require_once __DIR__ . '/tablet_excel.php';   // tabletParseDate()

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\DataValidation;

const CCTV_IMP_STATUSES = ['Digunakan', 'Stok', 'Tidak Digunakan'];

/** Kolom tiap sheet: kunci => [judul ID, judul EN, lebar, alias lain (huruf kecil)]. */
function cctvImpColumns(string $kind): array
{
    if ($kind === 'nvr') {
        return [
            'number'   => ['Nomor Aset', 'Asset Number', 22, ['no aset', 'no. aset', 'id aset', 'asset id']],
            'name'     => ['Nama NVR', 'NVR Name', 26, ['nvr name', 'nama']],
            'location' => ['Lokasi', 'Location', 22, ['location']],
            'ip'       => ['IP Address', 'IP Address', 16, ['ip', 'ip nvr', 'alamat ip']],
            'port'     => ['Port HTTP', 'HTTP Port', 10, ['port', 'port http nvr']],
            'brand'    => ['Brand', 'Brand', 14, ['merk', 'merek']],
            'type'     => ['Type', 'Type', 20, ['tipe', 'model']],
            'serial'   => ['Serial Number', 'Serial Number', 20, ['sn', 'serial']],
            'date'     => ['Tanggal Pembelian', 'Purchase Date', 16, ['purchase date', 'tgl pembelian']],
            'user'     => ['Username NVR', 'NVR Username', 16, ['username', 'user nvr']],
            'pass'     => ['Password NVR', 'NVR Password', 16, ['password', 'pass nvr']],
            'status'   => ['Status', 'Status', 14, []],
        ];
    }
    return [
        'number'   => ['Nomor Aset', 'Asset Number', 22, ['no aset', 'no. aset', 'id aset', 'asset id']],
        'name'     => ['Nama CCTV', 'Camera Name', 26, ['camera name', 'nama kamera', 'nama']],
        'location' => ['Lokasi', 'Location', 24, ['location']],
        'ip'       => ['IP Address', 'IP Address', 16, ['ip', 'ip kamera', 'alamat ip']],
        'brand'    => ['Brand', 'Brand', 14, ['merk', 'merek']],
        'type'     => ['Type', 'Type', 22, ['tipe', 'model']],
        'nvr'      => ['NVR', 'NVR', 24, ['masuk ke nvr', 'nama nvr']],
        'channel'  => ['Channel', 'Channel', 10, ['channel nvr', 'ch']],
        'status'   => ['Status', 'Status', 14, []],
    ];
}

/** Baris judul kolom + peta [kunci => huruf kolom] sebuah sheet; null bila bukan sheet CCTV/NVR. */
function cctvImpHeader(Worksheet $ws): ?array
{
    $maxRow = min(20, $ws->getHighestDataRow());
    for ($r = 1; $r <= $maxRow; $r++) {
        $cells = $ws->rangeToArray('A' . $r . ':' . $ws->getHighestDataColumn($r) . $r, null, true, false, true)[$r] ?? [];
        $norm = [];
        foreach ($cells as $col => $v) $norm[$col] = mb_strtolower(trim(preg_replace('/\s+/', ' ', (string)$v)));
        $kind = in_array('nama cctv', $norm, true) || in_array('camera name', $norm, true) ? 'cctv'
              : (in_array('nama nvr', $norm, true) || in_array('nvr name', $norm, true) ? 'nvr' : null);
        if (!$kind) continue;
        $map = [];
        foreach (cctvImpColumns($kind) as $key => [$id, $en, , $alias]) {
            $want = array_merge([mb_strtolower($id), mb_strtolower($en)], $alias);
            foreach ($norm as $col => $text) {
                if ($text !== '' && in_array(rtrim($text, ' *'), $want, true) && !in_array($col, $map, true)) { $map[$key] = $col; break; }
            }
        }
        return ['kind' => $kind, 'row' => $r, 'map' => $map];
    }
    return null;
}

/** File berisi sheet CCTV / NVR? (dipakai import_process.php untuk mengarahkan ke halaman ini) */
function isCctvImportSpreadsheet(Spreadsheet $ss): bool
{
    foreach ($ss->getWorksheetIterator() as $ws) if (cctvImpHeader($ws)) return true;
    return false;
}

function cctvImpCell(Worksheet $ws, ?string $col, int $row): string
{
    if (!$col) return '';
    $v = $ws->getCell($col . $row)->getFormattedValue();
    return trim(preg_replace('/\s+/u', ' ', (string)$v));
}

/** Kategori CCTV & NVR yang ada di Kategori Aset. */
function cctvImpCategories(PDO $db): array
{
    $names = array_column(getAssetCategories($db), 'name');
    $cctv  = array_values(array_filter($names, fn($n) => isCctvCategory($n) && !isTabletCategory($n)));
    $nvr   = array_values(array_filter($names, fn($n) => isNvrCategory($n)));
    return ['cctv' => $cctv, 'nvr' => $nvr];
}

/**
 * Baca & periksa file. Tidak menulis apa pun ke database.
 * Hasil: ['nvr' => rows, 'cctv' => rows, 'notes' => pesan umum, 'cats' => kategori]
 * Tiap row: excel_row, d (data), action new|update|error, asset_id, asset_number, errors[], warnings[].
 */
function cctvImportPlan(PDO $db, Spreadsheet $ss): array
{
    ensureCctvTables($db);
    $cats  = cctvImpCategories($db);
    $notes = [];
    $sheets = ['nvr' => null, 'cctv' => null];
    foreach ($ss->getWorksheetIterator() as $ws) {
        $hd = cctvImpHeader($ws);
        if ($hd && !$sheets[$hd['kind']]) $sheets[$hd['kind']] = [$ws, $hd];
    }

    // ----- Data yang sudah ada -----
    $allCats = array_merge($cats['cctv'], $cats['nvr']);
    $existing = [];
    if ($allCats) {
        $st = $db->prepare("SELECT id, asset_number, category, device_name, location, ip_address, status, serial_number
                            FROM assets WHERE category IN (" . implode(',', array_fill(0, count($allCats), '?')) . ")");
        $st->execute($allCats);
        $existing = $st->fetchAll();
    }
    $cctvByIp = $cctvByName = $nvrByName = $nvrByIp = [];
    foreach ($existing as $a) {
        $isNvr = in_array($a['category'], $cats['nvr'], true);
        if ($isNvr) {
            if (trim((string)$a['device_name']) !== '') $nvrByName[mb_strtolower(trim($a['device_name']))] = $a;
            if (trim((string)$a['ip_address']) !== '')  $nvrByIp[trim($a['ip_address'])] = $a;
        } else {
            if (trim((string)$a['ip_address']) !== '') $cctvByIp[trim($a['ip_address'])] = $a;
            $cctvByName[mb_strtolower(trim((string)$a['device_name']) . '|' . trim((string)$a['location']))] = $a;
        }
    }
    $numSt = $db->prepare("SELECT id, category FROM assets WHERE asset_number = ? LIMIT 1");
    $findNumber = function (string $no) use ($numSt) { $numSt->execute([$no]); return $numSt->fetch() ?: null; };

    $nvrList   = cctvNvrList($db);                 // id => row (menu CCTV)
    $nvrAsset  = cctvNvrToAsset($db);              // nvr_id => asset_id
    $assetNvr  = array_flip($nvrAsset);            // asset_id => nvr_id
    $nvrByKey  = [];                               // nama NVR (huruf kecil) => ['id' => nvr_id] / ['file' => idx]
    foreach ($nvrList as $id => $n) $nvrByKey[mb_strtolower(trim((string)$n['name']))] = ['id' => (int)$id];
    foreach ($existing as $a) {                    // nomor aset NVR juga boleh dipakai di kolom NVR
        if (isset($assetNvr[(int)$a['id']])) $nvrByKey[mb_strtolower(trim((string)$a['asset_number']))] = ['id' => $assetNvr[(int)$a['id']]];
    }

    $clean = fn(string $v) => $v === '-' ? '' : $v;
    $validIp = fn(string $ip) => $ip === '' || $ip === '-' || filter_var($ip, FILTER_VALIDATE_IP) !== false;

    // ----- Sheet NVR -----
    $nvrRows = [];
    if ($sheets['nvr']) {
        [$ws, $hd] = $sheets['nvr'];
        if (!$cats['nvr']) $notes[] = cL('Sheet NVR dilewati: buat dulu kategori "NVR" di menu Kategori Aset.', 'NVR sheet skipped: create an "NVR" asset category first.');
        $seenName = $seenIp = [];
        for ($r = $hd['row'] + 1, $last = $ws->getHighestDataRow(); $r <= $last && $cats['nvr']; $r++) {
            $d = [];
            foreach (array_keys(cctvImpColumns('nvr')) as $k) $d[$k] = cctvImpCell($ws, $hd['map'][$k] ?? null, $r);
            if (implode('', $d) === '') continue;
            $row = ['excel_row' => $r, 'd' => $d, 'action' => 'new', 'asset_id' => 0, 'asset_number' => '', 'errors' => [], 'warnings' => []];
            if ($d['name'] === '' && $d['number'] === '') $row['errors'][] = cL('Nama NVR wajib diisi', 'NVR name is required');
            if (!$validIp($d['ip'])) $row['errors'][] = cL('IP Address tidak valid', 'Invalid IP address') . ": {$d['ip']}";
            if ($d['port'] !== '' && $d['port'] !== '-' && (!ctype_digit($d['port']) || (int)$d['port'] < 1 || (int)$d['port'] > 65535)) $row['errors'][] = cL('Port harus angka 1-65535', 'Port must be 1-65535');
            if ($d['status'] !== '' && !in_array(cctvImpStatus($d['status']), CCTV_IMP_STATUSES, true)) $row['errors'][] = cL('Status harus Digunakan / Stok / Tidak Digunakan', 'Status must be Digunakan / Stok / Tidak Digunakan');
            if ($d['date'] !== '' && $d['date'] !== '-') {
                $pd = tabletParseDate($ws->getCell(($hd['map']['date'] ?? 'A') . $r)->getValue());
                if ($pd === false || $pd === null) $row['errors'][] = cL('Tanggal Pembelian tidak dikenali (pakai format 2025-01-31)', 'Purchase date not recognised (use 2025-01-31)');
                else $row['d']['date'] = $pd;
            }
            $key = mb_strtolower($d['name']);
            if ($d['name'] !== '' && isset($seenName[$key])) $row['errors'][] = cL('Nama NVR dobel dengan baris ', 'Duplicate NVR name with row ') . $seenName[$key];
            if ($d['ip'] !== '' && $d['ip'] !== '-' && isset($seenIp[$d['ip'] . ':' . $d['port']])) $row['errors'][] = cL('IP dobel dengan baris ', 'Duplicate IP with row ') . $seenIp[$d['ip'] . ':' . $d['port']];

            // Cocokkan dengan aset NVR yang sudah ada.
            $match = null;
            if ($d['number'] !== '') {
                $found = $findNumber($d['number']);
                if ($found && !in_array($found['category'], $cats['nvr'], true)) $row['errors'][] = cL('Nomor Aset sudah dipakai aset ', 'Asset number already used by a ') . $found['category'];
                elseif ($found) $match = (int)$found['id'];
            } elseif (isset($nvrByName[$key])) {
                $match = (int)$nvrByName[$key]['id'];
            } elseif ($d['ip'] !== '' && isset($nvrByIp[$d['ip']])) {
                $match = (int)$nvrByIp[$d['ip']]['id'];
            }
            if ($match) {
                $row['action'] = 'update';
                $row['asset_id'] = $match;
                foreach ($existing as $a) if ((int)$a['id'] === $match) $row['asset_number'] = (string)$a['asset_number'];
            } else {
                $row['asset_number'] = $d['number'];
                if ($d['ip'] === '' || $d['ip'] === '-') $row['warnings'][] = cL('IP kosong: NVR belum bisa dipantau', 'No IP: NVR cannot be monitored yet');
                if ($d['user'] === '' || $d['pass'] === '') $row['warnings'][] = cL('Username/password NVR kosong: status channel tidak terbaca', 'NVR username/password empty: channel status unreadable');
            }
            if ($row['errors']) $row['action'] = 'error';
            if ($d['name'] !== '') $seenName[$key] = $r;
            if ($d['ip'] !== '' && $d['ip'] !== '-') $seenIp[$d['ip'] . ':' . $d['port']] = $r;
            if ($row['action'] !== 'error') {
                $nvrByKey[$key] = ['file' => count($nvrRows)];
                if ($row['asset_number'] !== '') $nvrByKey[mb_strtolower($row['asset_number'])] = ['file' => count($nvrRows)];
            }
            $nvrRows[] = $row;
        }
    }

    // ----- Sheet CCTV -----
    $camRows = [];
    if ($sheets['cctv']) {
        [$ws, $hd] = $sheets['cctv'];
        if (!$cats['cctv']) $notes[] = cL('Sheet CCTV dilewati: buat dulu kategori "CCTV" di menu Kategori Aset.', 'CCTV sheet skipped: create a "CCTV" asset category first.');
        $camMap = cctvCameraMap($db, array_column($existing, 'id'));
        $usedCh = [];                                   // "nvr:channel" => asset_id (data lama)
        foreach ($camMap as $aid => $m) if ($m['nvr_id'] && $m['channel'] !== '') $usedCh[$m['nvr_id'] . ':' . $m['channel']] = $aid;
        $seenIp = $seenCh = [];
        for ($r = $hd['row'] + 1, $last = $ws->getHighestDataRow(); $r <= $last && $cats['cctv']; $r++) {
            $d = [];
            foreach (array_keys(cctvImpColumns('cctv')) as $k) $d[$k] = cctvImpCell($ws, $hd['map'][$k] ?? null, $r);
            if (implode('', $d) === '') continue;
            $row = ['excel_row' => $r, 'd' => $d, 'action' => 'new', 'asset_id' => 0, 'asset_number' => '', 'errors' => [], 'warnings' => [], 'nvr' => null];
            if (!$validIp($d['ip'])) $row['errors'][] = cL('IP Address tidak valid', 'Invalid IP address') . ": {$d['ip']}";
            if ($d['status'] !== '' && !in_array(cctvImpStatus($d['status']), CCTV_IMP_STATUSES, true)) $row['errors'][] = cL('Status harus Digunakan / Stok / Tidak Digunakan', 'Status must be Digunakan / Stok / Tidak Digunakan');
            $dupIp = ($d['ip'] !== '' && $d['ip'] !== '-') ? ($seenIp[$d['ip']] ?? 0) : 0;

            // NVR & channel
            if ($d['nvr'] !== '' && $d['nvr'] !== '-') {
                $ref = $nvrByKey[mb_strtolower($d['nvr'])] ?? null;
                if (!$ref) $row['errors'][] = cL('NVR tidak ditemukan', 'NVR not found') . ": {$d['nvr']}";
                elseif (isset($ref['file']) && $nvrRows[$ref['file']]['action'] === 'error') $row['errors'][] = cL('NVR di sheet NVR masih error', 'NVR row in NVR sheet has errors') . ": {$d['nvr']}";
                else $row['nvr'] = $ref;
                if ($d['channel'] === '') $row['warnings'][] = cL('Channel kosong: status kamera dari NVR tidak terbaca', 'No channel: camera status from NVR unreadable');
            }
            if ($d['channel'] !== '' && $d['channel'] !== '-') {
                $ch = preg_replace('/^[dD]/', '', $d['channel']);            // "D3" -> 3
                if (!ctype_digit($ch) || (int)$ch < 1 || (int)$ch > 512) $row['errors'][] = cL('Channel harus angka (mis. 1 atau D1)', 'Channel must be a number (e.g. 1 or D1)');
                else $row['d']['channel'] = (string)(int)$ch;
                if (($d['nvr'] === '' || $d['nvr'] === '-') && !$row['errors']) $row['warnings'][] = cL('Channel diabaikan karena NVR kosong', 'Channel ignored because NVR is empty');
            }

            // Cocokkan dengan aset CCTV yang sudah ada.
            $match = null;
            if ($d['number'] !== '') {
                $found = $findNumber($d['number']);
                if ($found && !in_array($found['category'], $cats['cctv'], true)) $row['errors'][] = cL('Nomor Aset sudah dipakai aset ', 'Asset number already used by a ') . $found['category'];
                elseif ($found) $match = (int)$found['id'];
            } elseif ($d['ip'] !== '' && $d['ip'] !== '-' && isset($cctvByIp[$d['ip']])) {
                $match = (int)$cctvByIp[$d['ip']]['id'];
            } elseif (($d['ip'] === '' || $d['ip'] === '-') && isset($cctvByName[mb_strtolower($d['name'] . '|' . $d['location'])])) {
                $match = (int)$cctvByName[mb_strtolower($d['name'] . '|' . $d['location'])]['id'];   // kamera tanpa IP: cocokkan nama + lokasi
            }
            if ($match) {
                $row['action'] = 'update';
                $row['asset_id'] = $match;
                foreach ($existing as $a) if ((int)$a['id'] === $match) $row['asset_number'] = (string)$a['asset_number'];
            } else {
                $row['asset_number'] = $d['number'];
                // Aset baru: nama & lokasi wajib (saat update, kosong = data lama tetap).
                if ($d['name'] === '' || $d['name'] === '-') $row['errors'][] = cL('Nama CCTV wajib diisi', 'Camera name is required');
                if ($d['location'] === '' || $d['location'] === '-') $row['errors'][] = cL('Lokasi wajib diisi', 'Location is required');
            }

            // IP sama di 2 baris: aset baru = error; aset lama (nomor aset diisi) = peringatan saja.
            if ($dupIp) {
                if ($match && $d['number'] !== '') $row['warnings'][] = cL('IP sama dengan baris ', 'Same IP as row ') . $dupIp;
                else $row['errors'][] = cL('IP dobel dengan baris ', 'Duplicate IP with row ') . $dupIp;
            }

            // Channel bentrok dengan kamera lain (di file / data lama)
            if ($row['nvr'] && $row['d']['channel'] !== '' && $row['d']['channel'] !== '-' && !$row['errors']) {
                $ck = (isset($row['nvr']['id']) ? 'n' . $row['nvr']['id'] : 'f' . $row['nvr']['file']) . ':' . $row['d']['channel'];
                if (isset($seenCh[$ck])) $row['errors'][] = cL('NVR + channel dobel dengan baris ', 'Duplicate NVR + channel with row ') . $seenCh[$ck];
                $old = isset($row['nvr']['id']) ? ($usedCh[$row['nvr']['id'] . ':' . $row['d']['channel']] ?? 0) : 0;
                if ($old && $old !== (int)$row['asset_id']) $row['warnings'][] = cL('Channel ini sudah dipakai kamera lain di NVR yang sama', 'This channel is already used by another camera on the same NVR');
                $seenCh[$ck] = $r;
            }
            if ($row['errors']) $row['action'] = 'error';
            if ($d['ip'] !== '' && $d['ip'] !== '-') $seenIp[$d['ip']] = $r;
            $camRows[] = $row;
        }
    }
    if (!$sheets['nvr'] && !$sheets['cctv']) $notes[] = cL('Sheet CCTV / NVR tidak ditemukan. Pakai template import CCTV.', 'No CCTV / NVR sheet found. Use the CCTV import template.');
    return ['nvr' => $nvrRows, 'cctv' => $camRows, 'notes' => $notes, 'cats' => $cats];
}

/** "stok", "STOCK", "dipakai" -> nilai status sistem. */
function cctvImpStatus(string $s): string
{
    $k = mb_strtolower(trim($s));
    if ($k === '' ) return 'Digunakan';
    if (in_array($k, ['digunakan', 'dipakai', 'used', 'in use', 'aktif'], true)) return 'Digunakan';
    if (in_array($k, ['stok', 'stock', 'cadangan'], true)) return 'Stok';
    if (in_array($k, ['tidak digunakan', 'tidak dipakai', 'unused', 'not used', 'rusak'], true)) return 'Tidak Digunakan';
    return $s;
}

/**
 * Simpan hasil cctvImportPlan(). Baris error dilewati.
 * @return array ['nvr_new','nvr_upd','cam_new','cam_upd','skipped','numbers' => nomor aset baru]
 */
function cctvImportApply(PDO $db, array $plan): array
{
    ensureCctvTables($db);
    $hasDate = (bool)$db->query("SELECT COUNT(*) FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'assets' AND COLUMN_NAME = 'purchase_date'")->fetchColumn();
    $res = ['nvr_new' => 0, 'nvr_upd' => 0, 'cam_new' => 0, 'cam_upd' => 0, 'skipped' => 0, 'numbers' => []];
    $val = fn(string $new, $old) => $new === '' ? (string)$old : ($new === '-' ? '' : $new);   // kosong = tetap, "-" = kosongkan
    $now = date('Y-m-d H:i:s');

    $db->beginTransaction();
    try {
        $fileNvrId = [];   // index baris sheet NVR => nvr_id
        foreach ($plan['nvr'] as $i => $row) {
            if ($row['action'] === 'error') { $res['skipped']++; continue; }
            $d = $row['d'];
            $cat = $plan['cats']['nvr'][0];
            $old = $row['asset_id'] ? cctvImpAssetRow($db, $row['asset_id']) : [];
            $info = $row['asset_id'] ? (cctvInfoMap($db, [$row['asset_id']])[$row['asset_id']] ?? []) : [];
            $link = $row['asset_id'] ? (cctvNvrAssetMap($db, [$row['asset_id']])[$row['asset_id']] ?? []) : [];
            $brand  = $val($d['brand'], $info['brand'] ?? '');
            $type   = $val($d['type'], $info['model'] ?? '');
            $status = $d['status'] !== '' ? cctvImpStatus($d['status']) : ($old['status'] ?? 'Digunakan');
            $fields = [
                'device_name'       => $val($d['name'], $old['device_name'] ?? ''),
                'location'          => $val($d['location'], $old['location'] ?? ''),
                'ip_address'        => $val($d['ip'], $old['ip_address'] ?? ''),
                'serial_number'     => $val($d['serial'], $old['serial_number'] ?? ''),
                'motherboard_brand' => trim($brand . ' ' . $type),
                'status'            => $status,
            ];
            if ($hasDate) {
                $pd = $d['date'] === '-' ? null : ($d['date'] === '' ? ($old['purchase_date'] ?? null) : $d['date']);
                $fields['purchase_date'] = $pd;
            }
            $assetId = cctvImpSaveAsset($db, (int)$row['asset_id'], $cat, $row['asset_number'], $fields, $res);
            // NVR yang dulu didaftarkan manual di Pengaturan (nama sama) dipakai lagi, tidak dibuat dobel.
            if (!$link) {
                $st = $db->prepare("SELECT n.id FROM cctv_nvr n LEFT JOIN cctv_nvr_assets l ON l.nvr_id = n.id
                                    WHERE l.asset_id IS NULL AND LOWER(n.name) = LOWER(?) LIMIT 1");
                $st->execute([$fields['device_name']]);
                if ($nid = (int)$st->fetchColumn()) {
                    $db->prepare("DELETE FROM cctv_nvr_assets WHERE asset_id = ?")->execute([$assetId]);
                    $db->prepare("INSERT INTO cctv_nvr_assets (asset_id, nvr_id, updated_at) VALUES (?, ?, ?)")->execute([$assetId, $nid, $now]);
                    $link = ['port' => $db->query("SELECT port FROM cctv_nvr WHERE id = " . $nid)->fetchColumn(),
                             'username' => $db->query("SELECT username FROM cctv_nvr WHERE id = " . $nid)->fetchColumn()];
                }
            }
            saveCctvInfo($db, $assetId, $brand, $type);
            $fileNvrId[$i] = saveNvrFromAsset($db, $assetId, [
                'name'     => $fields['device_name'],
                'ip'       => $fields['ip_address'],
                'port'     => (int)$val($d['port'], $link['port'] ?? 80) ?: 80,
                'brand'    => $brand,
                'username' => $val($d['user'], $link['username'] ?? ''),
                'password' => $d['pass'] === '-' ? '' : $d['pass'],
            ]);
            $res[$row['asset_id'] ? 'nvr_upd' : 'nvr_new']++;
        }

        foreach ($plan['cctv'] as $row) {
            if ($row['action'] === 'error') { $res['skipped']++; continue; }
            $d = $row['d'];
            $cat = $plan['cats']['cctv'][0];
            $old = $row['asset_id'] ? cctvImpAssetRow($db, $row['asset_id']) : [];
            if ($row['asset_id']) $cat = $old['category'] ?? $cat;
            $info = $row['asset_id'] ? (cctvInfoMap($db, [$row['asset_id']])[$row['asset_id']] ?? []) : [];
            $brand = $val($d['brand'], $info['brand'] ?? '');
            $type  = $val($d['type'], $info['model'] ?? '');
            $assetId = cctvImpSaveAsset($db, (int)$row['asset_id'], $cat, $row['asset_number'], [
                'device_name'       => $val($d['name'], $old['device_name'] ?? ''),
                'location'          => $val($d['location'], $old['location'] ?? ''),
                'ip_address'        => $val($d['ip'], $old['ip_address'] ?? ''),
                'motherboard_brand' => trim($brand . ' ' . $type),
                'status'            => $d['status'] !== '' ? cctvImpStatus($d['status']) : ($old['status'] ?? 'Digunakan'),
            ], $res);
            saveCctvInfo($db, $assetId, $brand, $type);
            // NVR: kosong saat update = tetap; "-" = lepas dari NVR.
            $map = $row['asset_id'] ? (cctvCameraMap($db, [$assetId])[$assetId] ?? null) : null;
            if ($row['nvr']) {
                $nvrId = isset($row['nvr']['id']) ? (int)$row['nvr']['id'] : (int)($fileNvrId[$row['nvr']['file']] ?? 0);
                $ch = $d['channel'] === '' ? (int)($map['channel'] ?? 0) : ($d['channel'] === '-' ? 0 : (int)$d['channel']);
                saveCameraNvr($db, $assetId, $nvrId, $ch);
            } elseif ($d['nvr'] === '-' || !$map) {
                saveCameraNvr($db, $assetId, 0, 0);
            }
            $res[$row['asset_id'] ? 'cam_upd' : 'cam_new']++;
        }
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        throw $e;
    }
    return $res;
}

function cctvImpAssetRow(PDO $db, int $id): array
{
    $st = $db->prepare("SELECT * FROM assets WHERE id = ?");
    $st->execute([$id]);
    return $st->fetch() ?: [];
}

/** Tambah / perbarui 1 baris assets (kolom lain diisi kosong seperti form Tambah Aset). */
function cctvImpSaveAsset(PDO $db, int $id, string $category, string $number, array $f, array &$res): int
{
    if ($id) {
        $sets = [];
        $args = [];
        foreach ($f as $col => $v) { $sets[] = "$col = ?"; $args[] = $v; }
        $args[] = $id;
        $db->prepare("UPDATE assets SET " . implode(', ', $sets) . " WHERE id = ?")->execute($args);
        return $id;
    }
    if ($number === '') {
        $sug = suggestAssetNumber($db, $category, '', (string)($f['location'] ?? ''), null, (string)$f['status']);
        if (!$sug['ok']) throw new RuntimeException($sug['message']);
        $number = $sug['asset_number'];
    }
    $row = array_merge([
        'asset_number' => $number, 'category' => $category, 'device_name' => '', 'department' => '', 'owner_email' => '',
        'ip_address' => '', 'hostname' => '', 'location' => '', 'processor' => '', 'ram' => '', 'storage' => '',
        'printer_info' => '', 'monitor_info' => '', 'accessories' => '', 'os_name' => '', 'os_status' => 'Belum Original',
        'serial_number' => '', 'motherboard_brand' => '', 'status' => 'Digunakan',
    ], $f);
    $db->prepare("INSERT INTO assets (" . implode(', ', array_keys($row)) . ") VALUES (" . implode(',', array_fill(0, count($row), '?')) . ")")
       ->execute(array_values($row));
    $res['numbers'][] = $number;
    return (int)$db->lastInsertId();
}

/**
 * Template Excel. $withData = isi dengan data CCTV & NVR yang sudah ada (untuk edit massal lalu import lagi).
 */
function writeCctvImportTemplate(PDO $db, Spreadsheet $ss, bool $withData = false, ?array $onlyIds = null): void
{
    // $onlyIds: dipakai Export Excel (menu Asset) -> hanya aset terpilih, format sama dengan template import.
    $idFilter = '';
    if ($onlyIds !== null) { $onlyIds = array_values(array_filter(array_map('intval', $onlyIds))); $idFilter = $onlyIds ? ' AND id IN (' . implode(',', $onlyIds) . ')' : ' AND 1=0'; }
    ensureCctvTables($db);
    $cats = cctvImpCategories($db);
    $nvrList = cctvNvrList($db);
    $en = function_exists('currentLang') && currentLang() === 'en';

    $rowsNvr = $rowsCam = [];
    if ($withData) {
        $nvrAssets = cctvNvrAssetMap($db);
        if ($cats['nvr']) {
            $st = $db->prepare("SELECT * FROM assets WHERE category IN (" . implode(',', array_fill(0, count($cats['nvr']), '?')) . ")$idFilter ORDER BY asset_number");
            $st->execute($cats['nvr']);
            $list = $st->fetchAll();
            $info = cctvInfoMap($db, array_column($list, 'id'));
            foreach ($list as $a) {
                $n = $nvrAssets[(int)$a['id']] ?? [];
                $rowsNvr[] = [$a['asset_number'], $a['device_name'], $a['location'], $a['ip_address'], $n['port'] ?? '',
                    $info[(int)$a['id']]['brand'] ?? '', $info[(int)$a['id']]['model'] ?? '', $a['serial_number'],
                    $a['purchase_date'] ?? '', $n['username'] ?? '', '', $a['status']];
            }
        }
        if ($cats['cctv']) {
            $st = $db->prepare("SELECT * FROM assets WHERE category IN (" . implode(',', array_fill(0, count($cats['cctv']), '?')) . ")$idFilter ORDER BY asset_number");
            $st->execute($cats['cctv']);
            $list = $st->fetchAll();
            $ids = array_column($list, 'id');
            $info = cctvInfoMap($db, $ids);
            $map = cctvCameraMap($db, $ids);
            foreach ($list as $a) {
                $m = $map[(int)$a['id']] ?? null;
                $rowsCam[] = [$a['asset_number'], $a['device_name'], $a['location'], $a['ip_address'],
                    $info[(int)$a['id']]['brand'] ?? '', $info[(int)$a['id']]['model'] ?? '',
                    $m && $m['nvr_id'] ? ($nvrList[$m['nvr_id']]['name'] ?? '') : '', $m['channel'] ?? '', $a['status']];
            }
        }
    }

    $title = fn($id, $e) => $en ? $e : $id;
    $build = function (Worksheet $ws, string $kind, array $rows, string $sheetTitle, string $docTitle) use ($en) {
        $ws->setTitle($sheetTitle);
        $cols = cctvImpColumns($kind);
        $c = 1;
        foreach ($cols as [$id, $e, $w]) {
            $L = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($c++);
            $ws->setCellValue($L . '1', $en ? $e : $id);
            $ws->getColumnDimension($L)->setWidth($w);
        }
        $lastCol = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex(count($cols));
        foreach ($rows as $i => $vals) {
            foreach (array_values($vals) as $j => $v) {
                $ws->setCellValueExplicit(\PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($j + 1) . ($i + 2), (string)$v, DataType::TYPE_STRING);
            }
        }
        $ws->getStyle("A1:{$lastCol}1")->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
        $ws->getStyle("A1:{$lastCol}1")->getFill()->setFillType('solid')->getStartColor()->setRGB($kind === 'nvr' ? '0F766E' : '1D4ED8');
        $ws->freezePane('A2');
        xlsAddTitleBlock($ws, 1, $docTitle, xlsTemplateLines());
        // Seluruh area isian berformat teks supaya IP / nomor tidak diubah Excel.
        $ws->getStyle("A9:{$lastCol}1000")->getNumberFormat()->setFormatCode('@');
        $ws->getStyle("A8:{$lastCol}" . max(8, 8 + count($rows)))->getBorders()->getAllBorders()->setBorderStyle('thin')->getColor()->setRGB('CBD5E1');
        return $lastCol;
    };

    // Sheet CCTV (pertama, paling sering dipakai)
    $wsCam = $ss->getActiveSheet();
    $exp = $onlyIds !== null;
    $build($wsCam, 'cctv', $rowsCam, 'CCTV', ($exp ? $title('Data Aset CCTV ', 'CCTV Asset Data ') : $title('Import Aset CCTV ', 'CCTV Asset Import ')) . xlsCompanyName());
    $wsNvr = $ss->createSheet();
    $build($wsNvr, 'nvr', $rowsNvr, 'NVR', ($exp ? $title('Data Aset NVR ', 'NVR Asset Data ') : $title('Import Aset NVR ', 'NVR Asset Import ')) . xlsCompanyName());

    // Daftar pilihan (sheet tersembunyi): status + nama NVR yang ada + nama NVR di sheet NVR.
    $ls = $ss->createSheet();
    $ls->setTitle('Daftar');
    foreach (CCTV_IMP_STATUSES as $i => $s) $ls->setCellValue('A' . ($i + 1), $s);
    $names = array_values(array_unique(array_map(fn($n) => (string)$n['name'], $nvrList)));
    foreach ($names as $i => $n) $ls->setCellValueExplicit('B' . ($i + 1), $n, DataType::TYPE_STRING);
    $start = count($names) + 1;
    $prev = count($names) ? '$B$1:$B$' . count($names) : null;
    for ($i = 0; $i < 200; $i++) {
        $src = "NVR!B" . (9 + $i);
        $dupe = $prev ? "COUNTIF({$prev},{$src})>0" : 'FALSE';
        $ls->setCellValue('B' . ($start + $i), "=IF(OR({$src}=\"\",{$dupe}),\"\",{$src})");
    }
    $ls->setSheetState(Worksheet::SHEETSTATE_HIDDEN);

    $dv = function (Worksheet $ws, string $range, string $formula, bool $strict) {
        $v = new DataValidation();
        $v->setType(DataValidation::TYPE_LIST)->setFormula1($formula)->setShowDropDown(true)->setAllowBlank(true)
          ->setShowErrorMessage($strict)->setErrorStyle($strict ? DataValidation::STYLE_STOP : DataValidation::STYLE_INFORMATION)
          ->setErrorTitle('Status')->setError('Digunakan / Stok / Tidak Digunakan');
        $ws->setDataValidation($range, $v);
    };
    $dv($wsCam, 'I9:I1000', 'Daftar!$A$1:$A$3', true);
    $dv($wsCam, 'G9:G1000', 'Daftar!$B$1:$B$' . ($start + 199), false);
    $dv($wsNvr, 'L9:L1000', 'Daftar!$A$1:$A$3', true);

    // Petunjuk
    $help = $ss->createSheet();
    $help->setTitle($en ? 'Guide' : 'Petunjuk');
    $lines = $en ? [
        'CCTV & NVR import guide', '',
        '1. Create the asset categories "CCTV" and "NVR" first (menu Asset Categories).',
        '2. Sheet NVR (optional): one row per NVR. NVR name is required. Saved NVRs appear automatically in CCTV > Settings > NVR.',
        '3. Sheet CCTV: one row per camera. Camera name and Location are required. Location is the name shown in monitoring, checklist and reports.',
        '4. Column NVR: choose from the list (existing NVRs + NVRs in sheet NVR) or type the NVR name / NVR asset number. Empty = camera checked via its own IP.',
        '5. Column Channel: camera number on the NVR (D1 = 1, D2 = 2). "D3" is also accepted.',
        '6. Asset Number empty = new asset, numbered automatically (e.g. IT/STOK/CCTV/001). If the IP (CCTV) or name/IP (NVR) already exists, that asset is updated instead.',
        '7. When updating: an empty cell keeps the old value; type "-" to clear it. Password NVR empty = unchanged.',
        '8. Status: Digunakan / Stok / Tidak Digunakan (empty = Digunakan).',
        '9. After uploading, a preview shows new / updated / error rows. Nothing is saved until you click Save.',
    ] : [
        'Petunjuk import CCTV & NVR', '',
        '1. Buat dulu kategori aset "CCTV" dan "NVR" (menu Kategori Aset).',
        '2. Sheet NVR (opsional): 1 baris = 1 NVR. Nama NVR wajib. NVR yang tersimpan otomatis muncul di CCTV > Pengaturan > NVR.',
        '3. Sheet CCTV: 1 baris = 1 kamera. Nama CCTV dan Lokasi wajib. Lokasi = nama yang tampil di monitoring, checklist & laporan.',
        '4. Kolom NVR: pilih dari daftar (NVR yang sudah ada + NVR di sheet NVR) atau ketik nama / nomor aset NVR. Kosong = kamera dicek lewat IP-nya sendiri.',
        '5. Kolom Channel: nomor kamera di NVR (D1 = 1, D2 = 2). Boleh juga ditulis "D3".',
        '6. Nomor Aset kosong = aset baru, nomor dibuat otomatis (mis. IT/STOK/CCTV/001). Jika IP (CCTV) atau nama/IP (NVR) sudah ada, aset itu yang diperbarui.',
        '7. Saat memperbarui: sel kosong = data lama tetap; ketik "-" untuk mengosongkan. Password NVR kosong = tidak diubah.',
        '8. Status: Digunakan / Stok / Tidak Digunakan (kosong = Digunakan).',
        '9. Setelah upload, muncul preview baris baru / diperbarui / error. Data baru tersimpan setelah klik Simpan.',
    ];
    $lines[] = '';
    $lines[] = $en ? 'Example CCTV row:' : 'Contoh baris CCTV:';
    $lines[] = '(Nomor Aset kosong) | CCTV Gerbang Depan | Gerbang Depan | 192.168.131.121 | Hikvision | DS-2CD1043G0-I | NVR-01 Produksi | 1 | Digunakan';
    foreach ($lines as $i => $l) $help->setCellValue('A' . ($i + 1), $l);
    $help->getStyle('A1')->getFont()->setBold(true)->setSize(13);
    $help->getColumnDimension('A')->setWidth(140);
    $ss->setActiveSheetIndex(0);
}
