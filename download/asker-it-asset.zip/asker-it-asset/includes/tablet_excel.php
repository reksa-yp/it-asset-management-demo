<?php
/**
 * Export & Import Excel KHUSUS kategori Tablet.
 *
 * Format file (14 kolom, urutan sama dengan hasil export):
 *   ID Aset | Kategori | Nama Perangkat | Pengguna | Departement | Lokasi | Serial Number | IP Address |
 *   Received Date | ID Tablet | Brand Type | Aksesoris | Status Kondisi | Tanggal Input
 *   (Aksesoris: "Nama (Brand/Type)" dipisah koma, lihat includes/asset_accessories.php)
 *
 * Dipakai oleh: export_excel.php, download_template.php?type=tablet,
 *               import_process.php, tablet_import_preview.php.
 *
 * AMAN UNTUK DATABASE YANG SUDAH ADA: tidak ada ALTER / tabel baru. Import hanya menulis
 * ke kolom aset yang dipakai form Tablet (lihat includes/tablet.php), asset_owners, dan
 * asset_tablet_details. Kolom aset lain (Hostname, OS, dll) TIDAK disentuh.
 */

require_once __DIR__ . '/categories.php';
require_once __DIR__ . '/asset_accessories.php';

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Shared\Date as XlsDate;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

/** Kunci kolom tablet sesuai urutan di file Excel. */
const TABLET_XLS_FIELDS = [
    'asset_number', 'category', 'device_name', 'users', 'department', 'location', 'serial',
    'ip', 'received', 'tablet_id', 'brand', 'accessories', 'condition', 'input_date',
];

/** Judul kolom mengikuti bahasa aktif (ID: persis sama dengan file contoh). */
function tabletXlsHeaders(): array
{
    return [
        t('xls_hdr_asset_id'), t('xls_hdr_category'), t('xls_hdr_device_name'), t('xls_hdr_users'), t('xls_hdr_department'),
        t('xls_hdr_location'), t('xls_hdr_serial'), t('xls_hdr_ip'), t('tablet_lbl_received'),
        t('tablet_lbl_id'), t('tablet_lbl_brand'), t('xls_hdr_accessories'), t('xls_hdr_tablet_condition'), t('xls_hdr_input_date'),
    ];
}

/**
 * Judul kolom yang dikenali saat import (bahasa Indonesia, Inggris, dan format tablet lama).
 * Dicocokkan tanpa beda huruf besar/kecil.
 */
function tabletXlsHeaderAliases(): array
{
    return [
        'id aset' => 'asset_number', 'asset id' => 'asset_number', 'assets no' => 'asset_number', 'nomor aset' => 'asset_number',
        'kategori' => 'category', 'category' => 'category', 'jenis aset' => 'category',
        'nama perangkat' => 'device_name', 'device name' => 'device_name', 'nama tablet' => 'device_name',
        'pengguna' => 'users', 'users' => 'users', 'user' => 'users',
        'departement' => 'department', 'department' => 'department', 'departemen' => 'department',
        'lokasi' => 'location', 'location' => 'location',
        'serial number' => 'serial',
        'ip address' => 'ip', 'ip' => 'ip',
        'received date' => 'received', 'tanggal pembelian' => 'received', 'purchase date' => 'received', 'tanggal terima' => 'received',
        'id tablet' => 'tablet_id', 'tablet id' => 'tablet_id',
        'brand type' => 'brand', 'motherboard/brand type' => 'brand',
        'aksesoris' => 'accessories', 'accessories' => 'accessories', 'accessory' => 'accessories',
        'status kondisi' => 'condition', 'status condition' => 'condition', 'condition status' => 'condition', 'kondisi' => 'condition', 'condition' => 'condition',
        'tanggal input' => 'input_date', 'date added' => 'input_date',
    ];
}

/**
 * Sheet dianggap format Tablet jika punya kolom khas tablet
 * (ID Tablet / Status Kondisi / Received Date / "Brand Type" persis).
 * Format umum aset memakai "Motherboard/Brand Type", jadi tidak ikut terdeteksi.
 */
function isTabletXlsHeader(array $headerRow): bool
{
    foreach ($headerRow as $title) {
        $k = mb_strtolower(trim((string)$title));
        if (in_array($k, ['id tablet', 'tablet id', 'status kondisi', 'status condition', 'condition status', 'received date', 'brand type'], true)) {
            return true;
        }
    }
    return false;
}

/** Tulis sheet tablet (dipakai export & template). $tabletMap = hasil getTabletDetailsMap(). */
function writeTabletSheet(Worksheet $sheet, array $tabletAssets, array $ownersMap, array $tabletMap, string $title): void
{
    $headers = tabletXlsHeaders();
    // Export berisi data: sisipkan kolom Jabatan setelah Pengguna (template kosong & import tidak berubah).
    $withPosition = (bool)$tabletAssets && function_exists('getUserPositionMap');
    $positionMap = $withPosition ? getUserPositionMap(getDB()) : [];
    if ($withPosition) array_splice($headers, 4, 0, [t('xls_hdr_position')]);
    $rows = [];
    foreach ($tabletAssets as $a) {
        $cond = $tabletMap[$a['id']]['tablet_condition'] ?? 'Bagus';
        $rows[] = [
            $a['asset_number'],
            $a['category'],
            $a['device_name'] ?? '',
            ownerNamesLabel($ownersMap[$a['id']] ?? []),
            $a['department'],
            $a['location'],
            $a['serial_number'],
            $a['ip_address'],
            !empty($a['purchase_date'] ?? null) ? date('Y-m-d', strtotime($a['purchase_date'])) : '',
            $tabletMap[$a['id']]['tablet_id'] ?? '',
            $a['motherboard_brand'] ?? '',
            $a['accessories'] ?? '',
            $cond === 'Rusak' ? t('tablet_cond_bad') : t('tablet_cond_good'),
            !empty($a['created_at']) ? date('Y-m-d', strtotime($a['created_at'])) : '',
        ];
        if ($withPosition) array_splice($rows[count($rows) - 1], 4, 0, [ownerPositionsLabel($ownersMap[$a['id']] ?? [], $positionMap)]);
    }

    $sheet->setTitle($title);
    $sheet->fromArray($headers, null, 'A1');
    // Semua isi ditulis sebagai TEKS supaya Serial Number / ID Tablet angka panjang tidak berubah
    // jadi 1.23E+14 dan tanggal tetap berformat YYYY-MM-DD.
    foreach ($rows as $r => $row) {
        foreach ($row as $c => $val) {
            $sheet->setCellValueExplicit(Coordinate::stringFromColumnIndex($c + 1) . ($r + 2), (string)$val,
                \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
        }
    }

    $lastCol = Coordinate::stringFromColumnIndex(count($headers));
    $lastRow = max(1, 1 + count($rows));
    $sheet->getStyle("A1:{$lastCol}1")->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
    $sheet->getStyle("A1:{$lastCol}1")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
    $sheet->getStyle("A1:{$lastCol}1")->getAlignment()->setHorizontal('center');
    $sheet->getStyle("A1:{$lastCol}{$lastRow}")->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
    $widths = [22, 11, 22, 24, 16, 11, 20, 16, 15, 14, 16, 34, 15, 14];
    if ($withPosition) array_splice($widths, 4, 0, [18]);
    foreach ($widths as $i => $w) {
        $sheet->getColumnDimension(Coordinate::stringFromColumnIndex($i + 1))->setWidth($w);
    }
    $sheet->freezePane('A2');
}

/** Baca header (baris 1) sebuah sheet: [huruf kolom => judul]. */
function readSheetHeader(Worksheet $sheet): array
{
    $highestCol = $sheet->getHighestDataColumn(1);
    $row = $sheet->rangeToArray("A1:{$highestCol}1", null, true, true, true);
    return $row[1] ?? [];
}

/** Ubah isi sel tanggal (angka Excel / DateTime / teks) jadi 'Y-m-d'. null = kosong, false = tidak valid. */
function tabletParseDate($raw)
{
    if ($raw === null) return null;
    if ($raw instanceof DateTimeInterface) return $raw->format('Y-m-d');
    if (is_int($raw) || is_float($raw) || (is_string($raw) && preg_match('/^\d{5}(\.\d+)?$/', trim($raw)))) {
        $n = (float)$raw;
        if ($n >= 1 && $n < 2958466) return XlsDate::excelToDateTimeObject($n)->format('Y-m-d');
        return false;
    }
    $s = trim((string)$raw);
    if ($s === '' || $s === '-') return null;
    $s = preg_replace('/\s+\d{1,2}:\d{2}(:\d{2})?$/', '', $s); // buang jam, mis. "2024-02-26 00:00:00"
    foreach (['Y-m-d', 'Y/m/d', 'd/m/Y', 'd-m-Y', 'd.m.Y', 'j/n/Y', 'j-n-Y'] as $fmt) {
        $d = DateTime::createFromFormat('!' . $fmt, $s);
        if ($d && $d->format($fmt) === $s) return $d->format('Y-m-d');
    }
    $d = DateTime::createFromFormat('!d/m/Y', $s) ?: DateTime::createFromFormat('!d-m-Y', $s);
    if ($d) return $d->format('Y-m-d');
    $ts = strtotime($s);
    return $ts ? date('Y-m-d', $ts) : false;
}

/** Nilai kondisi dari file -> 'Bagus' / 'Rusak'. null = kosong, false = tidak dikenali. */
function tabletParseCondition(string $v)
{
    $v = mb_strtolower(trim($v));
    if ($v === '' || $v === '-') return null;
    if (in_array($v, ['bagus', 'baik', 'good', 'ok', 'normal'], true)) return 'Bagus';
    if (in_array($v, ['rusak', 'damaged', 'bad', 'broken'], true)) return 'Rusak';
    return false;
}

/**
 * Baca semua baris data sheet tablet -> list baris [field => nilai string], + 'row' = no. baris Excel.
 * Received Date dibaca dari nilai asli sel (bisa angka tanggal Excel atau teks).
 */
function readTabletSheetRows(Worksheet $sheet): array
{
    $aliases = tabletXlsHeaderAliases();
    $colMap = [];
    foreach (readSheetHeader($sheet) as $letter => $title) {
        $k = $aliases[mb_strtolower(trim((string)$title))] ?? null;
        if ($k && !isset($colMap[$k])) $colMap[$k] = $letter;
    }
    $rows = [];
    $highestRow = $sheet->getHighestDataRow();
    for ($r = 2; $r <= $highestRow; $r++) {
        $item = ['row' => $r];
        $empty = true;
        foreach (TABLET_XLS_FIELDS as $f) {
            if (!isset($colMap[$f])) continue;
            $cell = $sheet->getCell($colMap[$f] . $r);
            if ($f === 'received') {
                $v = $cell->getValue();
                if ($v instanceof \PhpOffice\PhpSpreadsheet\RichText\RichText) $v = $v->getPlainText();
                if (is_string($v)) $v = trim($v);
                $item[$f] = $v;
                if ($v !== null && $v !== '') $empty = false;
            } else {
                $v = trim((string)$cell->getFormattedValue());
                $item[$f] = $v;
                if ($v !== '') $empty = false;
            }
        }
        if (!$empty) $rows[] = $item;
    }
    return ['columns' => array_keys($colMap), 'rows' => $rows];
}

/**
 * Proses baris-baris tablet. Menulis ke database; pemanggil yang menentukan
 * commit (Simpan) atau rollBack (Preview) lewat transaksi.
 *
 * Aturan:
 * - ID Aset sudah ada (kategori tablet)  -> UPDATE kolom tablet saja.
 * - ID Aset belum ada                    -> INSERT aset Tablet baru.
 * - ID Aset kosong + Lokasi terisi       -> nomor dibuat otomatis (<Awalan>/Dept/Line/urut).
 * - ID Aset dipakai aset NON-tablet      -> baris ditolak (tidak menimpa laptop/PC).
 * - Kolom tidak ada / sel kosong        -> nilai lama tidak diubah (kecuali Pengguna, lihat bawah).
 * - Pengguna kosong                      -> tablet dilepas dari pengguna (status jadi Stok).
 * - Pengguna dicocokkan ke master User (Nama Lengkap). Nama yang tidak terdaftar -> peringatan.
 * - Departement: isi dari file; kalau kosong ambil dari user pertama.
 * - Status pemakaian otomatis: Digunakan jika ada pengguna, Stok jika tidak (sama seperti form).
 * - Tanggal Input diabaikan (diisi otomatis oleh sistem).
 *
 * Return: ['rows' => [...hasil per baris], 'inserted'=>n, 'updated'=>n, 'errors'=>n, 'warnings'=>n]
 */
function processTabletRows(PDO $db, array $parsed): array
{
    $cols = array_flip($parsed['columns']);
    $has = fn(string $f) => isset($cols[$f]);

    // Kategori tablet yang terdaftar di menu Kategori Aset.
    $tabletCats = array_values(array_filter(array_column(getAssetCategories($db), 'name'), 'isTabletCategory'));
    $defaultCat = $tabletCats[0] ?? 'Tablet';

    $hasPurchaseDateCol = (bool)$db->query("SELECT COUNT(*) FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'assets' AND COLUMN_NAME = 'purchase_date'")->fetchColumn();

    $findAsset = $db->prepare("SELECT * FROM assets WHERE asset_number = ? LIMIT 1");
    $findUser  = $db->prepare("SELECT id, full_name, department, email FROM users WHERE LOWER(TRIM(full_name)) = LOWER(?) LIMIT 1");
    $findDetail = $db->prepare("SELECT tablet_id, tablet_condition FROM asset_tablet_details WHERE asset_id = ?");

    $out = ['rows' => [], 'inserted' => 0, 'updated' => 0, 'errors' => 0, 'warnings' => 0];
    $seenNumbers = [];

    foreach ($parsed['rows'] as $in) {
        $res = ['row' => $in['row'], 'action' => '', 'asset_number' => $in['asset_number'] ?? '',
                'data' => $in, 'errors' => [], 'warnings' => []];
        $get = fn(string $f) => trim((string)($in[$f] ?? ''));

        // ----- Kategori -----
        $category = $defaultCat;
        if ($has('category') && $get('category') !== '') {
            $c = $get('category');
            if (!isTabletCategory($c)) {
                $res['errors'][] = t('tablet_imp_err_category', $c);
            } else {
                $match = array_values(array_filter($tabletCats, fn($tc) => strcasecmp($tc, $c) === 0));
                $category = $match[0] ?? $defaultCat;
            }
        }

        // ----- Tanggal & kondisi -----
        $received = $has('received') ? tabletParseDate($in['received']) : null;
        if ($received === false) {
            $res['errors'][] = t('tablet_imp_err_date', (string)$in['received']);
            $received = null;
        }
        if ($received && $received > date('Y-m-d')) {
            $res['warnings'][] = t('tablet_imp_warn_future_date', $received);
        }
        $condition = $has('condition') ? tabletParseCondition($get('condition')) : null;
        if ($condition === false) {
            $res['errors'][] = t('tablet_imp_err_condition', $get('condition'));
            $condition = null;
        }

        // ----- Pengguna -> master User -----
        $ownerIds = []; $firstUser = null; $namesGiven = false;
        if ($has('users')) {
            $names = array_filter(array_map('trim', preg_split('/[,;]/', $get('users'))), fn($v) => $v !== '');
            $namesGiven = (bool)$names;
            foreach ($names as $n) {
                $findUser->execute([$n]);
                $u = $findUser->fetch();
                if ($u) { $ownerIds[] = (int)$u['id']; $firstUser = $firstUser ?? $u; }
                else { $res['warnings'][] = t('tablet_imp_warn_user', $n); }
            }
        }

        // ----- IP (peringatan saja) -----
        if ($has('ip') && $get('ip') !== '' && !filter_var($get('ip'), FILTER_VALIDATE_IP)) {
            $res['warnings'][] = t('tablet_imp_warn_ip', $get('ip'));
        }

        // ----- ID Aset -----
        $assetNumber = $get('asset_number');
        $department  = $has('department') ? $get('department') : '';
        if ($department === '' && $firstUser && trim((string)$firstUser['department']) !== '') {
            $department = trim((string)$firstUser['department']);
        }
        $existing = null;
        if ($assetNumber !== '') {
            if (mb_strlen($assetNumber) > ASSET_NUMBER_MAX_LEN) $res['errors'][] = t('tablet_imp_err_number_long', $assetNumber);
            $findAsset->execute([$assetNumber]);
            $existing = $findAsset->fetch() ?: null;
            if ($existing && !isTabletCategory($existing['category'])) {
                $res['errors'][] = t('tablet_imp_err_not_tablet', $assetNumber, $existing['category']);
            }
        }
        if (isset($seenNumbers[mb_strtolower($assetNumber)]) && $assetNumber !== '') {
            $res['errors'][] = t('tablet_imp_err_dup_number', $assetNumber, $seenNumbers[mb_strtolower($assetNumber)]);
        }

        // ----- ID Tablet -----
        // ID Tablet = akun login tablet, jadi BOLEH sama di beberapa tablet (tidak dicek unik).
        $tabletId = $has('tablet_id') ? mb_substr($get('tablet_id'), 0, 50) : null;

        if ($res['errors']) {
            $res['action'] = 'error';
            $out['errors']++;
            $out['rows'][] = $res;
            continue;
        }

        // Setiap baris punya SAVEPOINT sendiri: kalau database menolak 1 baris (mis. data terlalu
        // panjang / dobel), hanya baris itu yang dibatalkan & ditandai Error, baris lain tetap jalan.
        $db->exec('SAVEPOINT tablet_row');
        try {
            // Nomor otomatis untuk baris baru tanpa ID Aset.
            if ($assetNumber === '') {
                $location = $has('location') ? $get('location') : '';
                $auto = nextTabletAssetNumber($db, $department, $location);
                if ($auto === null) {
                    $db->exec('RELEASE SAVEPOINT tablet_row');
                    $res['errors'][] = t('tablet_imp_err_no_number');
                    $res['action'] = 'error';
                    $out['errors']++;
                    $out['rows'][] = $res;
                    continue;
                }
                if (mb_strlen($auto) > ASSET_NUMBER_MAX_LEN) {
                    throw new PDOException(t('tablet_imp_err_number_long', $auto));
                }
                $assetNumber = $auto;
                $res['asset_number'] = $auto;
                $res['warnings'][] = t('tablet_imp_info_auto_number', $auto);
            }
            $seenNumbers[mb_strtolower($assetNumber)] = $in['row'];

            // Pengguna: nama diisi tapi TIDAK ADA yang terdaftar -> pengguna lama dipertahankan.
            $keepOwners = $existing && $namesGiven && !$ownerIds;
            if (!$has('users')) $keepOwners = (bool)$existing;

            // ----- Susun nilai (kolom tidak ada di file = nilai lama) -----
            // Kolom tidak ada di file ATAU sel kosong -> nilai lama tetap (untuk tablet yang sudah ada).
            $val = function (string $field, string $col, $new) use ($existing, $has) {
                if (!$has($field) || $new === '') return $existing ? $existing[$col] : null;
                return $new;
            };
            $fields = [
                'category'          => $category,
                'department'        => $department !== '' ? $department : ($existing['department'] ?? null),
                'device_name'       => $val('device_name', 'device_name', mb_substr($get('device_name'), 0, 100)),
                'location'          => $val('location', 'location', $get('location')),
                'serial_number'     => $val('serial', 'serial_number', $get('serial')),
                'ip_address'        => $val('ip', 'ip_address', $get('ip')),
                'motherboard_brand' => $val('brand', 'motherboard_brand', $get('brand')),
            ];
            if ($hasPurchaseDateCol) {
                $fields['purchase_date'] = $received ?? ($existing['purchase_date'] ?? null);
            }
            if ($firstUser) {
                $fields['owner_email'] = trim((string)$firstUser['email']) !== '' ? $firstUser['email'] : null;
            } elseif ($has('users') && !$namesGiven) {
                $fields['owner_email'] = null; // Pengguna dikosongkan -> email pengguna ikut kosong
            }

            if ($existing) {
                $assetId = (int)$existing['id'];
                $set = implode(', ', array_map(fn($k) => "$k = ?", array_keys($fields)));
                $db->prepare("UPDATE assets SET $set WHERE id = ?")->execute([...array_values($fields), $assetId]);
                $res['action'] = 'update';
                $out['updated']++;
            } else {
                $fields = ['asset_number' => $assetNumber] + $fields;
                $colsSql = implode(', ', array_keys($fields));
                $ph = implode(',', array_fill(0, count($fields), '?'));
                $db->prepare("INSERT INTO assets ($colsSql) VALUES ($ph)")->execute(array_values($fields));
                $assetId = (int)$db->lastInsertId();
                $res['action'] = 'insert';
                $out['inserted']++;
            }

            if (!$keepOwners) {
                setAssetOwners($db, $assetId, $ownerIds);
            }
            // Aksesoris: "Nama (Brand/Type)" dipisah koma. Kolom tidak ada / sel kosong -> aksesoris lama tidak diubah.
            if ($has('accessories') && $get('accessories') !== '') {
                setAssetAccessories($db, $assetId, parseAccessoriesText($get('accessories')));
            }
            // Status pemakaian otomatis (sama dengan form Tablet): ada pengguna -> Digunakan, tidak -> Stok.
            $ownerCount = assetOwnersTableExists($db)
                ? (int)$db->query("SELECT COUNT(*) FROM asset_owners WHERE asset_id = " . $assetId)->fetchColumn()
                : count($ownerIds);
            $db->prepare("UPDATE assets SET status = ? WHERE id = ?")->execute([$ownerCount > 0 ? 'Digunakan' : 'Stok', $assetId]);

            // ID Tablet & Status Kondisi (kolom tidak ada / kosong -> pakai nilai lama, kondisi default Bagus).
            // (Tidak memakai saveTabletDetails() karena fungsi itu bisa menjalankan CREATE TABLE,
            //  yang di MySQL otomatis meng-commit transaksi dan merusak mode Preview.)
            $findDetail->execute([$assetId]);
            $old = $findDetail->fetch() ?: ['tablet_id' => null, 'tablet_condition' => 'Bagus'];
            $finalTabletId = ($tabletId !== null && $tabletId !== '') ? $tabletId : (string)($old['tablet_id'] ?? '');
            $finalCond     = $condition ?? ($old['tablet_condition'] ?: 'Bagus');
            $db->prepare("INSERT INTO asset_tablet_details (asset_id, tablet_id, tablet_condition) VALUES (?,?,?)
                          ON DUPLICATE KEY UPDATE tablet_id = VALUES(tablet_id), tablet_condition = VALUES(tablet_condition)")
               ->execute([$assetId, $finalTabletId !== '' ? $finalTabletId : null, $finalCond]);
            $db->exec('RELEASE SAVEPOINT tablet_row');
        } catch (PDOException $e) {
            $db->exec('ROLLBACK TO SAVEPOINT tablet_row');
            if ($res['action'] === 'insert') $out['inserted']--;
            if ($res['action'] === 'update') $out['updated']--;
            $res['action'] = 'error';
            $res['errors'][] = t('tablet_imp_err_db', $e->getMessage());
            $out['errors']++;
            $out['rows'][] = $res;
            continue;
        }

        if ($res['warnings']) $out['warnings']++;
        $out['rows'][] = $res;
    }
    return $out;
}

/** Hapus file import tablet yang masih menunggu konfirmasi (file sementara + session). */
function tabletImportDiscardPending(): void
{
    $p = $_SESSION['tablet_import']['file'] ?? null;
    if ($p && is_file($p)) @unlink($p);
    unset($_SESSION['tablet_import']);
}

/** Header sheet umum aset punya kolom wajib ID Aset & Kategori? */
function isGenericAssetXlsHeader(array $headerRow): bool
{
    $titles = array_map(fn($v) => trim((string)$v), $headerRow);
    return (in_array('ID Aset', $titles, true) || in_array('Asset ID', $titles, true))
        && (in_array('Kategori', $titles, true) || in_array('Category', $titles, true));
}

/**
 * Jalankan import untuk seluruh file dalam SATU transaksi.
 * $commit = false -> mode Preview: semua dijalankan lalu dibatalkan (rollBack), hasilnya
 *                    persis sama dengan saat disimpan (termasuk nomor aset otomatis).
 * $commit = true  -> Simpan.
 * Sheet format Tablet diproses dengan aturan tablet; sheet aktif berformat umum
 * (mis. sheet "Inventory" pada file campuran) diproses dengan import biasa.
 */
function runAssetSpreadsheetImport(PDO $db, \PhpOffice\PhpSpreadsheet\Spreadsheet $ss, bool $commit): array
{
    require_once __DIR__ . '/asset_import.php';
    $result = ['tablet' => [], 'generic' => null];
    // Catat sheet aktif SEBELUM membaca sheet lain (membaca sel bisa memindahkan sheet aktif).
    $active = $ss->getActiveSheet();
    $db->beginTransaction();
    try {
        foreach ($ss->getWorksheetIterator() as $ws) {
            if (isTabletXlsHeader(readSheetHeader($ws))) {
                $result['tablet'][$ws->getTitle()] = processTabletRows($db, readTabletSheetRows($ws));
            }
        }
        $activeHeader = readSheetHeader($active);
        if (!isTabletXlsHeader($activeHeader) && isGenericAssetXlsHeader($activeHeader)) {
            $result['generic'] = ['sheet' => $active->getTitle(), 'counts' => importGenericAssetSheet($db, $active)];
        }
        $commit ? $db->commit() : $db->rollBack();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        throw $e;
    }
    return $result;
}
