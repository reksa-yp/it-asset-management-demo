<?php
/**
 * Fragment HTML detail aset, dirender ulang oleh:
 *  - asset_detail_print.php (dibuka di tab baru + window.print())
 *  - asset_detail_pdf.php   (dirender jadi PDF lewat Dompdf)
 *
 * Sengaja pakai HTML/CSS sederhana (table, inline style) tanpa flexbox/grid,
 * supaya tampil sama persis baik di browser maupun di Dompdf (rendering engine
 * PDF tidak mendukung CSS modern).
 *
 * Variabel yang harus sudah tersedia sebelum include file ini: $asset, $history.
 */
$osStatusLabel = $asset['os_status'] === 'Original' ? t('os_original') : t('os_not_original');
$softwareItems = $asset['software_items'] ?? [];
$categoryLabels = [
    'Desktop PC' => t('cat_desktop'), 'Laptop' => t('cat_laptop'), 'Printer' => t('cat_printer'),
    'Monitor' => t('cat_monitor'), 'Aksesoris' => t('cat_accessory'),
];
$statusLabels = [
    'Digunakan' => t('status_used'), 'Stok' => t('status_stock'), 'Tidak Digunakan' => t('status_unused'),
];
$categoryLabel = $categoryLabels[$asset['category']] ?? $asset['category'];
$statusLabel   = $statusLabels[$asset['status']] ?? $asset['status'];
?>
<div style="font-family: Arial, sans-serif; color:#222; font-size:12px; max-width:720px; margin:0 auto;">

    <table width="100%" style="border-bottom:2px solid #1F3DD1; margin-bottom:14px;">
        <tr>
            <td style="padding-bottom:8px;">
                <?php $printLogo = function_exists('appLogoDataUri') ? appLogoDataUri() : ''; ?>
                <?php if ($printLogo): ?>
                    <img src="<?= $printLogo ?>" alt="" style="height:36px; width:auto; float:left; margin-right:10px;">
                <?php endif; ?>
                <div style="font-size:17px; font-weight:bold; color:#1F3DD1;"><?= htmlspecialchars(t('app_name')) ?></div>
                <div style="font-size:11px; color:#666;"><?= htmlspecialchars(t('print_subtitle')) ?></div>
            </td>
            <td style="text-align:right; padding-bottom:8px; font-size:11px; color:#666;">
                <?= htmlspecialchars(t('printed_at')) ?>: <?= date('d M Y H:i') ?>
            </td>
        </tr>
    </table>

    <h2 style="margin:0 0 4px; font-size:15px;"><?= htmlspecialchars($asset['asset_number']) ?> — <?= htmlspecialchars($asset['device_name'] ?: $asset['category']) ?></h2>
    <p style="margin:0 0 14px; color:#666; font-size:11px;"><?= htmlspecialchars($categoryLabel) ?> &bull; <?= htmlspecialchars(t('th_status')) ?>: <?= htmlspecialchars($statusLabel) ?></p>

    <table width="100%" cellpadding="5" style="border-collapse:collapse; margin-bottom:10px;">
        <tr>
            <td width="50%" style="vertical-align:top; padding-right:10px;">
                <table width="100%" style="border:1px solid #ccc; border-collapse:collapse;">
                    <tr style="background:#f1f3f9;"><td colspan="2" style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc;"><?= htmlspecialchars(t('info_general')) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; width:45%; color:#555;"><?= htmlspecialchars(t('lbl_asset_number')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['asset_number']) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_asset_type')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($categoryLabel) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_device_name')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['device_name'] ?: t('dash')) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_user')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['owner_name'] ?? t('dash')) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_department')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['department'] ?: t('dash')) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('field_position')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars(assetOwnerPositions(getDB(), (int)$asset['id']) ?: t('dash')) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_user_email')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['owner_email'] ?: t('dash')) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_location')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['location'] ?: t('dash')) ?></td></tr>
                    <tr><td style="padding:4px 8px; color:#555;"><?= htmlspecialchars(t('lbl_purchase_date')) ?></td><td style="padding:4px 8px;"><?= !empty($asset['purchase_date'] ?? null) ? date('d M Y', strtotime($asset['purchase_date'])) : t('dash') ?></td></tr>
                </table>
            </td>
            <td width="50%" style="vertical-align:top;">
                <table width="100%" style="border:1px solid #ccc; border-collapse:collapse;">
                    <tr style="background:#f1f3f9;"><td colspan="2" style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc;"><?= htmlspecialchars(t('info_network_system')) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; width:45%; color:#555;"><?= htmlspecialchars(t('lbl_ip_address')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['ip_address'] ?: t('dash')) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_hostname')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['hostname'] ?: t('dash')) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_os')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['os_name'] ?: t('dash')) ?></td></tr>
                    <tr><td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_serial_number')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['serial_number'] ?: t('dash')) ?></td></tr>
                    <tr><td style="padding:4px 8px; color:#555;"><?= htmlspecialchars(t('field_os_status')) ?></td><td style="padding:4px 8px;"><?= htmlspecialchars($osStatusLabel) ?></td></tr>
                </table>
            </td>
        </tr>
    </table>

    <?php if (function_exists('isTabletCategory') && isTabletCategory($asset['category'])):
        $tabletInfo = getTabletDetailsMap(getDB(), [(int)$asset['id']])[(int)$asset['id']] ?? [];
        $tabletCond = ($tabletInfo['tablet_condition'] ?? 'Bagus') === 'Rusak' ? t('tablet_cond_bad') : t('tablet_cond_good'); ?>
    <table width="100%" style="border:1px solid #ccc; border-collapse:collapse; margin-bottom:10px;">
        <tr style="background:#f1f3f9;"><td colspan="6" style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc;"><?= htmlspecialchars(t('tablet_info_title')) ?></td></tr>
        <tr>
            <td style="padding:4px 8px; color:#555; width:14%;"><?= htmlspecialchars(t('tablet_lbl_id')) ?></td><td style="padding:4px 8px; width:19%; font-weight:bold;"><?= htmlspecialchars(($tabletInfo['tablet_id'] ?? '') ?: t('dash')) ?></td>
            <td style="padding:4px 8px; color:#555; width:16%;"><?= htmlspecialchars(t('tablet_lbl_condition')) ?></td><td style="padding:4px 8px; width:14%;"><?= htmlspecialchars($tabletCond) ?></td>
            <td style="padding:4px 8px; color:#555; width:14%;"><?= htmlspecialchars(t('tablet_lbl_brand')) ?></td><td style="padding:4px 8px;"><?= htmlspecialchars(($asset['motherboard_brand'] ?? '') ?: t('dash')) ?></td>
        </tr>
    </table>
    <?php endif; ?>

    <table width="100%" style="border:1px solid #ccc; border-collapse:collapse; margin-bottom:10px;">
        <tr style="background:#f1f3f9;">
            <td style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc; width:40%;"><?= htmlspecialchars(t('lbl_installed_software')) ?></td>
            <td style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc; width:30%;"><?= htmlspecialchars(t('lbl_software_serial_number')) ?></td>
            <td style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc;"><?= htmlspecialchars(t('field_status')) ?></td>
        </tr>
        <?php if (!$softwareItems): ?>
        <tr>
            <td style="padding:6px 8px; vertical-align:top;" colspan="3"><?= htmlspecialchars(t('dash')) ?></td>
        </tr>
        <?php else: foreach ($softwareItems as $si): ?>
        <tr>
            <td style="padding:6px 8px; border-bottom:1px solid #eee; vertical-align:top;"><?= htmlspecialchars($si['software_name']) ?></td>
            <td style="padding:6px 8px; border-bottom:1px solid #eee; vertical-align:top;"><?= htmlspecialchars($si['serial_number'] ?: t('dash')) ?></td>
            <td style="padding:6px 8px; border-bottom:1px solid #eee; vertical-align:top;"><?= htmlspecialchars($si['status'] === 'Original' ? t('os_original') : t('os_not_original')) ?></td>
        </tr>
        <?php endforeach; endif; ?>
    </table>

    <table width="100%" style="border:1px solid #ccc; border-collapse:collapse; margin-bottom:14px;">
        <tr style="background:#f1f3f9;"><td colspan="4" style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc;"><?= htmlspecialchars(t('info_hardware_specs')) ?></td></tr>
        <tr>
            <td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555; width:20%;"><?= htmlspecialchars(t('lbl_processor')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee; width:30%;"><?= htmlspecialchars($asset['processor'] ?: t('dash')) ?></td>
            <td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555; width:20%;"><?= htmlspecialchars(t('lbl_ram')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['ram'] ?: t('dash')) ?></td>
        </tr>
        <tr>
            <td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_storage')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['storage'] ?: t('dash')) ?></td>
            <td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_monitor')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['monitor_info'] ?: t('dash')) ?></td>
        </tr>
        <tr>
            <td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_motherboard')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['motherboard_brand'] ?? '' ?: t('dash')) ?></td>
            <td style="padding:4px 8px; border-bottom:1px solid #eee; color:#555;"><?= htmlspecialchars(t('lbl_printer')) ?></td><td style="padding:4px 8px; border-bottom:1px solid #eee;"><?= htmlspecialchars($asset['printer_info'] ?: t('dash')) ?></td>
        </tr>
        <tr>
            <td style="padding:4px 8px; color:#555;"><?= htmlspecialchars(t('lbl_accessories')) ?></td><td style="padding:4px 8px;" colspan="3"><?= htmlspecialchars($asset['accessories'] ?: t('dash')) ?></td>
        </tr>
    </table>

    <?php
    // Riwayat Upgrade Aset (komponen yang di-upgrade), dari tabel asset_upgrade_logs.
    require_once __DIR__ . '/asset_upgrade.php';
    $upgHistory = getAssetUpgradeHistory(getDB(), (int)$asset['id']);
    ?>
    <table width="100%" style="border:1px solid #ccc; border-collapse:collapse; margin-bottom:10px;">
        <tr style="background:#f1f3f9;"><td colspan="3" style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc;"><?= htmlspecialchars(t('upg_history_title')) ?></td></tr>
        <?php if (!$upgHistory): ?>
            <tr><td colspan="3" style="padding:8px; color:#999; text-align:center;"><?= htmlspecialchars(t('upg_history_empty')) ?></td></tr>
        <?php else: foreach ($upgHistory as $uh): ?>
            <tr>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:20%; vertical-align:top;"><?= date('d/m/Y', strtotime($uh['upgrade_date'])) ?><?= $uh['ticket_number'] ? '<br><span style="color:#888; font-size:10px;">' . htmlspecialchars($uh['ticket_number']) . '</span>' : '' ?></td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:55%; vertical-align:top;">
                    <?php foreach ($uh['items'] as $ui): $uBefore = upgradeItemValue($ui, 'old_value'); ?>
                        <div><?= htmlspecialchars(upgradeItemLabel($ui)) ?>: <?= $uBefore !== '' ? htmlspecialchars($uBefore) . ' &rarr; ' : '' ?><b><?= htmlspecialchars(upgradeItemValue($ui, 'new_value')) ?></b></div>
                    <?php endforeach; ?>
                    <?php if (!empty($uh['notes'])): ?>
                        <div style="margin-top:3px; color:#555; font-size:10.5px;"><?= nl2br(htmlspecialchars($uh['notes'])) ?></div>
                    <?php endif; ?>
                </td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:25%; vertical-align:top;"><?= htmlspecialchars($uh['created_by'] ?: t('dash')) ?></td>
            </tr>
        <?php endforeach; endif; ?>
    </table>

    <?php
    // Riwayat Kerusakan (menu Aset Rusak), dari tabel asset_damages.
    require_once __DIR__ . '/damage.php';
    $dmgHistory = getAssetDamageHistory(getDB(), (int)$asset['id']);
    ?>
    <?php if ($dmgHistory): ?>
    <table width="100%" style="border:1px solid #ccc; border-collapse:collapse; margin-bottom:10px;">
        <tr style="background:#fdecec;"><td colspan="4" style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc;"><?= htmlspecialchars(t('dmg_history_title')) ?></td></tr>
        <?php foreach ($dmgHistory as $dh): ?>
            <tr>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:20%; vertical-align:top;"><?= date('d/m/Y', strtotime($dh['damage_date'])) ?></td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:40%; vertical-align:top;"><?= htmlspecialchars($dh['issue']) ?><?= $dh['note'] ? '<br><span style="color:#888; font-size:10px;">' . nl2br(htmlspecialchars($dh['note'])) . '</span>' : '' ?></td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:20%; vertical-align:top;"><?= htmlspecialchars($dh['storage_location']) ?></td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; vertical-align:top;"><b><?= htmlspecialchars(damageStateLabel($dh['state'])) ?></b><?= $dh['closed_date'] ? '<br><span style="color:#888; font-size:10px;">' . date('d/m/Y', strtotime($dh['closed_date'])) . '</span>' : '' ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <?php endif; ?>

    <?php
    // Riwayat Stok (aset dibuat dari Barang Masuk / diserahkan lewat Barang Keluar), dari stock_asset_links.
    require_once __DIR__ . '/stock.php';
    $stockLog = getAssetStockLog(getDB(), (int)$asset['id']);
    ?>
    <?php if ($stockLog): ?>
    <table width="100%" style="border:1px solid #ccc; border-collapse:collapse; margin-bottom:10px;">
        <tr style="background:#f1f3f9;"><td colspan="3" style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc;"><?= htmlspecialchars(t('stock_history_asset_title')) ?></td></tr>
        <?php foreach ($stockLog as $sl): $slIn = $sl['type'] === 'in'; ?>
            <tr>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:20%; vertical-align:top;"><?= date('d/m/Y', strtotime($sl['trx_date'])) ?></td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:55%; vertical-align:top;">
                    <b><?= htmlspecialchars($slIn ? t('stock_type_in') : t('stock_type_out')) ?></b> — <?= htmlspecialchars(trim(($sl['category_name'] ?? '') . ($sl['item_name'] ? ' / ' . $sl['item_name'] : ''))) ?>
                    <?= $sl['note'] ? '<br><span style="color:#888; font-size:10px;">' . htmlspecialchars($sl['note']) . '</span>' : '' ?>
                </td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; vertical-align:top;"><?= $slIn ? htmlspecialchars(t('stock_history_asset_in')) : '&rarr; ' . htmlspecialchars(trim(($sl['recipient_name'] ?? '') . ($sl['recipient_department'] ? ' (' . $sl['recipient_department'] . ')' : ''))) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <?php endif; ?>

    <?php
    // Riwayat Mutasi Aset (pemindahan kepemilikan), dari tabel asset_mutations.
    require_once __DIR__ . '/mutation.php';
    $mutHistory = getAssetMutationHistory(getDB(), (int)$asset['id']);
    ?>
    <table width="100%" style="border:1px solid #ccc; border-collapse:collapse; margin-bottom:10px;">
        <tr style="background:#f1f3f9;"><td colspan="4" style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc;"><?= htmlspecialchars(t('mut_history_title')) ?></td></tr>
        <?php if (!$mutHistory): ?>
            <tr><td colspan="4" style="padding:8px; color:#999; text-align:center;"><?= htmlspecialchars(t('mut_history_empty')) ?></td></tr>
        <?php else: foreach ($mutHistory as $mh): ?>
            <tr>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:20%; vertical-align:top;"><?= date('d/m/Y', strtotime($mh['mutation_date'])) ?><br><span style="color:#888; font-size:10px;"><?= htmlspecialchars($mh['mutation_number']) ?></span></td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:30%; vertical-align:top;"><?= htmlspecialchars(mutationPartyLabel($mh['from_user_names'])) ?><?= $mh['from_department'] ? '<br><span style="color:#888; font-size:10px;">' . htmlspecialchars($mh['from_department']) . '</span>' : '' ?></td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:30%; vertical-align:top;">&rarr; <b><?= htmlspecialchars(mutationPartyLabel($mh['to_user_names'])) ?></b><?= $mh['to_department'] ? '<br><span style="color:#888; font-size:10px;">' . htmlspecialchars($mh['to_department']) . '</span>' : '' ?></td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; vertical-align:top;"><?= htmlspecialchars(mutationReasonLabel($mh['reason'])) ?></td>
            </tr>
        <?php endforeach; endif; ?>
    </table>

    <table width="100%" style="border:1px solid #ccc; border-collapse:collapse;">
        <tr style="background:#f1f3f9;"><td colspan="3" style="padding:5px 8px; font-weight:bold; border-bottom:1px solid #ccc;"><?= htmlspecialchars(t('info_ticket_history')) ?></td></tr>
        <?php if (!$history): ?>
            <tr><td colspan="3" style="padding:8px; color:#999; text-align:center;"><?= htmlspecialchars(t('no_history_yet')) ?></td></tr>
        <?php else: foreach ($history as $h): ?>
            <tr>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:20%; vertical-align:top;"><?= date('d/m/Y H:i', strtotime($h['created_at'])) ?></td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:55%; vertical-align:top;">
                    <?= htmlspecialchars($h['ticket_number']) ?> — <?= htmlspecialchars(mb_strimwidth($h['problem_detail'], 0, 60, '...')) ?>
                    <?php if (!empty($h['work_detail']) || !empty($h['asset_check'])): ?>
                        <div style="margin-top:4px; padding:5px 7px; background:#f7f8fb; border:1px solid #e5e7eb; border-radius:4px; font-size:10.5px; color:#444;">
                            <?php if (!empty($h['work_detail'])): ?>
                                <div><b><?= htmlspecialchars(t('lbl_work_detail_short')) ?>:</b> <?= nl2br(htmlspecialchars($h['work_detail'])) ?></div>
                            <?php endif; ?>
                            <?php if (!empty($h['asset_check'])): ?>
                                <div style="margin-top:2px;"><b><?= htmlspecialchars(t('lbl_asset_check_short')) ?>:</b> <?= nl2br(htmlspecialchars($h['asset_check'])) ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </td>
                <td style="padding:4px 8px; border-bottom:1px solid #eee; width:25%; vertical-align:top;"><?= htmlspecialchars($statusLabels[$h['status']] ?? $h['status']) ?></td>
            </tr>
        <?php endforeach; endif; ?>
    </table>

    <p style="margin-top:18px; font-size:10px; color:#999; text-align:center;">
        <?= htmlspecialchars(t('footer_note')) ?>
    </p>
</div>
