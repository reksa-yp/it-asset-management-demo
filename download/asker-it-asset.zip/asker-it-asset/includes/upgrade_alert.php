<?php
/**
 * Logika bersama untuk fitur "Aset Perlu Di-Upgrade" di Dashboard: menandai
 * aset berdasarkan histori Ticketing IT (Rincian Masalah / Hasil Pengecekan
 * dan Kesimpulan) yang mengandung kata kunci "harus upgrade".
 *
 * Dipakai bersama oleh dashboard.php, upgrade_list_print.php, dan
 * upgrade_list_pdf.php supaya query & aturan dedup-nya konsisten di satu
 * tempat saja.
 *
 * Sejak fitur "Tandai Selesai" ditambahkan: begitu tiket yang cocok kata
 * kunci ditandai selesai (dicatat di tabel asset_upgrade_ack, lihat
 * maintenance.php migrasi 'upgrade_ack'), tiket itu tidak dihitung lagi.
 * Kalau nanti ada tiket BARU pada aset yang sama yang juga mengandung kata
 * kunci "harus upgrade", aset tersebut otomatis muncul lagi di daftar
 * (karena tiket baru itu punya ID berbeda dan belum ditandai selesai).
 */

const UPGRADE_ALERT_KEYWORD = 'harus upgrade';

/**
 * Ambil daftar aset yang perlu di-upgrade (1 baris per aset, kemunculan
 * TERBARU saja kalau satu aset muncul di beberapa tiket yang cocok, dan
 * tiket yang sudah ditandai selesai lewat "Tandai Selesai" tidak dihitung).
 */
function getUpgradeAssets(PDO $db, string $keyword = UPGRADE_ALERT_KEYWORD): array
{
    // Tabel asset_upgrade_ack baru ada setelah migrasi "Tandai Selesai" (menu
    // Upgrade Sistem) dijalankan. Sebelum itu, fitur "Tandai Selesai" belum
    // aktif tapi daftar tetap tampil normal (tanpa filter ack).
    $ackTableExists = (bool)$db->query("
        SELECT COUNT(*) FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_upgrade_ack'
    ")->fetchColumn();

    $ackJoin  = $ackTableExists ? "LEFT JOIN asset_upgrade_ack ack ON ack.asset_id = a.id AND ack.ticket_id = t.id" : '';
    $ackWhere = $ackTableExists ? "AND ack.id IS NULL" : '';

    $stmt = $db->prepare("
        SELECT a.id AS asset_id, a.asset_number, a.device_name, a.department, a.category,
               t.id AS ticket_id, t.ticket_number, t.created_at AS ticket_date,
               COALESCE(wd.asset_check, wd.work_detail, t.problem_detail) AS matched_text
        FROM tickets t
        JOIN assets a ON a.id = t.asset_id
        LEFT JOIN ticket_work_details wd ON wd.ticket_id = t.id
        {$ackJoin}
        WHERE (t.problem_detail LIKE CONCAT('%', ?, '%')
           OR wd.work_detail    LIKE CONCAT('%', ?, '%')
           OR wd.asset_check    LIKE CONCAT('%', ?, '%'))
          {$ackWhere}
          " . sqlNotCancelled($db, 't') . "
        ORDER BY t.created_at DESC
    ");
    $stmt->execute([$keyword, $keyword, $keyword]);
    $rows = $stmt->fetchAll();

    $byAsset = [];
    foreach ($rows as $r) {
        if (!isset($byAsset[$r['asset_id']])) {
            $byAsset[$r['asset_id']] = $r;
        }
    }
    return array_values($byAsset);
}

/**
 * Tandai satu kemunculan (asset_id + ticket_id) sebagai sudah selesai
 * di-upgrade, supaya hilang dari daftar "Aset Perlu Di-Upgrade".
 * Aman dipanggil berkali-kali (upsert lewat ON DUPLICATE KEY).
 */
function acknowledgeUpgrade(PDO $db, int $assetId, int $ticketId, ?int $userId): void
{
    $stmt = $db->prepare("
        INSERT INTO asset_upgrade_ack (asset_id, ticket_id, acknowledged_by, acknowledged_at)
        VALUES (?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE acknowledged_by = VALUES(acknowledged_by), acknowledged_at = NOW()
    ");
    $stmt->execute([$assetId, $ticketId, $userId]);
}
