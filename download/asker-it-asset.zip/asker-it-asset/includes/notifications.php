<?php
/**
 * Pusat Notifikasi: semua notifikasi per user tersimpan di tabel BARU app_notifications
 * (CREATE TABLE IF NOT EXISTS, tabel lama tidak diubah). Dipakai lonceng di header,
 * halaman notifications.php, dan aplikasi Android (notif_api.php).
 *
 * Kategori: ticket | cctv | chat | system. Disimpan 90 hari lalu dihapus otomatis.
 * Isi pesan chat TIDAK disalin ke sini (chat tersimpan terenkripsi); notifikasi chat
 * hanya berisi nama grup, pengirim, dan jumlah pesan.
 */

const NOTIF_KEEP_DAYS = 90;

function notifEnsure(PDO $db): bool
{
    static $ok = null;
    if ($ok !== null) return $ok;
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS app_notifications (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            category VARCHAR(20) NOT NULL,
            type VARCHAR(30) NOT NULL,
            title VARCHAR(200) NOT NULL,
            body VARCHAR(300) NULL,
            url VARCHAR(255) NULL,
            ref_id INT NULL,
            alert_key VARCHAR(40) NULL,
            cnt INT NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            read_at DATETIME NULL,
            INDEX idx_user (user_id, read_at, id),
            INDEX idx_ref (type, ref_id, user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $ok = true;
    } catch (Throwable $e) {
        // Sudah ada / database lain: cek apakah tabel bisa dipakai.
        try { $db->query("SELECT 1 FROM app_notifications LIMIT 1"); $ok = true; } catch (Throwable $e2) { $ok = false; }
    }
    return $ok;
}

function notifL(string $id, string $en): string
{
    return function_exists('currentLang') && currentLang() === 'en' ? $en : $id;
}

function notifCats(): array
{
    return [
        'ticket' => ['label' => notifL('Tiket', 'Tickets'), 'icon' => 'ticket', 'cls' => 'bg-amber-100 text-amber-700'],
        'cctv'   => ['label' => 'CCTV',                     'icon' => 'camera', 'cls' => 'bg-red-100 text-red-700'],
        'chat'   => ['label' => 'Chat',                     'icon' => 'chat',   'cls' => 'bg-blue-100 text-blue-700'],
        'system' => ['label' => notifL('Sistem', 'System'), 'icon' => 'settings', 'cls' => 'bg-slate-100 text-slate-600'],
    ];
}

/** Id semua admin aktif. */
function notifAdminIds(PDO $db): array
{
    try {
        return array_map('intval', $db->query("SELECT id FROM users WHERE role = 'admin' AND is_active = 1")->fetchAll(PDO::FETCH_COLUMN));
    } catch (Throwable $e) {
        try { return array_map('intval', $db->query("SELECT id FROM users WHERE role = 'admin'")->fetchAll(PDO::FETCH_COLUMN)); }
        catch (Throwable $e2) { return []; }
    }
}

/**
 * Tambah notifikasi untuk beberapa user. $exclude = user yang memicu (tidak diberi notifikasi sendiri).
 * $alertKey = kunci anti-dobel aplikasi Android (mis. "t:15" tiket, "c:8" CCTV); kosong = "n:<id notifikasi>".
 * Tidak pernah melempar error: notifikasi hanya pelengkap.
 */
function notifAdd(PDO $db, array $userIds, string $cat, string $type, string $title, string $body = '', string $url = '', ?int $refId = null, string $alertKey = '', int $exclude = 0): int
{
    try {
        if (!notifEnsure($db)) return 0;
        $userIds = array_values(array_unique(array_filter(array_map('intval', $userIds), fn($u) => $u > 0 && $u !== $exclude)));
        if (!$userIds) return 0;
        $now = date('Y-m-d H:i:s');
        $st = $db->prepare("INSERT INTO app_notifications (user_id, category, type, title, body, url, ref_id, alert_key, cnt, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)");
        foreach ($userIds as $u) {
            $st->execute([$u, $cat, $type, mb_substr($title, 0, 200), $body !== '' ? mb_substr($body, 0, 300) : null, $url !== '' ? mb_substr($url, 0, 255) : null, $refId, $alertKey !== '' ? $alertKey : null, $now]);
        }
        notifCleanup($db);
        return count($userIds);
    } catch (Throwable $e) {
        return 0;
    }
}

function notifToAdmins(PDO $db, string $cat, string $type, string $title, string $body = '', string $url = '', ?int $refId = null, string $alertKey = '', int $exclude = 0): int
{
    return notifAdd($db, notifAdminIds($db), $cat, $type, $title, $body, $url, $refId, $alertKey, $exclude);
}

/** Hapus notifikasi lebih dari 90 hari (sesekali saja). */
function notifCleanup(PDO $db, bool $force = false): void
{
    if (!$force && random_int(1, 100) !== 1) return;
    try { $db->prepare("DELETE FROM app_notifications WHERE created_at < ?")->execute([date('Y-m-d H:i:s', time() - NOTIF_KEEP_DAYS * 86400)]); } catch (Throwable $e) {}
}

/**
 * Pesan chat baru: 1 notifikasi "n pesan baru di grup X" per user per grup (digabung selama belum dibaca),
 * plus notifikasi terpisah untuk user yang disebut (@nama).
 */
function notifChatMessage(PDO $db, array $group, array $memberIds, int $senderId, string $senderName, array $mentionIds, int $msgId): void
{
    try {
        if (!notifEnsure($db)) return;
        $gid = (int)$group['id'];
        $gname = (string)$group['name'];
        $url = 'chat.php?g=' . $gid;
        $now = date('Y-m-d H:i:s');
        $mentionIds = array_map('intval', $mentionIds);
        foreach ($mentionIds as $u) {
            if ($u === $senderId) continue;
            notifAdd($db, [$u], 'chat', 'chat_mention', notifL('Anda disebut di grup ', 'You were mentioned in ') . $gname,
                $senderName . notifL(' menyebut Anda', ' mentioned you'), $url . '&m=' . $msgId, $gid, 'm:' . $msgId);
        }
        $targets = array_values(array_diff(array_map('intval', $memberIds), [$senderId], $mentionIds));
        if (!$targets) return;
        $announce = (int)($group['is_announce'] ?? 0) === 1;
        $type = $announce ? 'chat_announce' : 'chat_msg';
        foreach (array_chunk($targets, 300) as $chunk) {
            $in = implode(',', $chunk);
            $have = [];
            $st = $db->prepare("SELECT id, user_id, cnt FROM app_notifications WHERE type = ? AND ref_id = ? AND read_at IS NULL AND user_id IN ($in)");
            $st->execute([$type, $gid]);
            foreach ($st->fetchAll() as $r) $have[(int)$r['user_id']] = $r;
            $upd = $db->prepare("UPDATE app_notifications SET cnt = cnt + 1, title = ?, body = ?, url = ?, alert_key = ?, created_at = ? WHERE id = ?");
            foreach ($have as $u => $r) {
                $n = (int)$r['cnt'] + 1;
                $upd->execute([mb_substr(($announce ? notifL('Pengumuman · ', 'Announcement · ') : '') . $n . notifL(' pesan baru di grup ', ' new messages in ') . $gname, 0, 200),
                    notifL('Terakhir dari ', 'Latest from ') . $senderName, $url, 'm:' . $msgId, $now, (int)$r['id']]);
            }
            $new = array_values(array_diff($chunk, array_keys($have)));
            if ($new) notifAdd($db, $new, 'chat', $type,
                ($announce ? notifL('Pengumuman di grup ', 'Announcement in ') : notifL('Pesan baru di grup ', 'New message in ')) . $gname,
                notifL('Dari ', 'From ') . $senderName, $url, $gid, 'm:' . $msgId);
        }
    } catch (Throwable $e) {}
}

/** Tandai notifikasi tertentu (mis. semua notifikasi chat grup X) sebagai dibaca. */
function notifMarkReadRef(PDO $db, int $uid, array $types, int $refId): void
{
    try {
        if (!notifEnsure($db) || !$types) return;
        $in = implode(',', array_fill(0, count($types), '?'));
        $db->prepare("UPDATE app_notifications SET read_at = ? WHERE user_id = ? AND ref_id = ? AND read_at IS NULL AND type IN ($in)")
           ->execute(array_merge([date('Y-m-d H:i:s'), $uid, $refId], $types));
    } catch (Throwable $e) {}
}

function notifUnreadCounts(PDO $db, int $uid): array
{
    $out = ['total' => 0, 'by_cat' => [], 'max_id' => 0];
    try {
        if (!notifEnsure($db)) return $out;
        $st = $db->prepare("SELECT category, COUNT(*) AS n FROM app_notifications WHERE user_id = ? AND read_at IS NULL GROUP BY category");
        $st->execute([$uid]);
        foreach ($st->fetchAll() as $r) { $out['by_cat'][$r['category']] = (int)$r['n']; $out['total'] += (int)$r['n']; }
        $mx = $db->prepare("SELECT MAX(id) FROM app_notifications WHERE user_id = ?");
        $mx->execute([$uid]);
        $out['max_id'] = (int)$mx->fetchColumn();
    } catch (Throwable $e) {}
    return $out;
}

/** Daftar notifikasi. $tab = unread|all, $cat = '' atau kategori. */
function notifList(PDO $db, int $uid, string $tab = 'all', string $cat = '', int $limit = 20, int $offset = 0, int $sinceId = 0): array
{
    try {
        if (!notifEnsure($db)) return [];
        $w = "user_id = ?";
        $p = [$uid];
        if ($tab === 'unread') $w .= " AND read_at IS NULL";
        if ($cat !== '' && isset(notifCats()[$cat])) { $w .= " AND category = ?"; $p[] = $cat; }
        if ($sinceId > 0) { $w .= " AND id > ?"; $p[] = $sinceId; }
        $limit = max(1, min(200, $limit));
        $offset = max(0, $offset);
        $st = $db->prepare("SELECT * FROM app_notifications WHERE $w ORDER BY created_at DESC, id DESC LIMIT $limit OFFSET $offset");
        $st->execute($p);
        return $st->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
}

function notifCount(PDO $db, int $uid, string $tab = 'all', string $cat = ''): int
{
    try {
        $w = "user_id = ?"; $p = [$uid];
        if ($tab === 'unread') $w .= " AND read_at IS NULL";
        if ($cat !== '' && isset(notifCats()[$cat])) { $w .= " AND category = ?"; $p[] = $cat; }
        $st = $db->prepare("SELECT COUNT(*) FROM app_notifications WHERE $w");
        $st->execute($p);
        return (int)$st->fetchColumn();
    } catch (Throwable $e) { return 0; }
}

/** $ids kosong + $all = true -> semua milik user. */
function notifMarkRead(PDO $db, int $uid, array $ids, bool $all = false): int
{
    try {
        if (!notifEnsure($db)) return 0;
        $now = date('Y-m-d H:i:s');
        if ($all) {
            $st = $db->prepare("UPDATE app_notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL");
            $st->execute([$now, $uid]);
            return $st->rowCount();
        }
        $ids = array_values(array_filter(array_map('intval', $ids)));
        if (!$ids) return 0;
        $in = implode(',', $ids);
        $st = $db->prepare("UPDATE app_notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL AND id IN ($in)");
        $st->execute([$now, $uid]);
        return $st->rowCount();
    } catch (Throwable $e) { return 0; }
}

function notifDelete(PDO $db, int $uid, array $ids): int
{
    try {
        $ids = array_values(array_filter(array_map('intval', $ids)));
        if (!$ids || !notifEnsure($db)) return 0;
        $in = implode(',', $ids);
        $st = $db->prepare("DELETE FROM app_notifications WHERE user_id = ? AND id IN ($in)");
        $st->execute([$uid]);
        return $st->rowCount();
    } catch (Throwable $e) { return 0; }
}

function notifAgo(string $dt): string
{
    $s = max(0, time() - strtotime($dt));
    if ($s < 60) return notifL('baru saja', 'just now');
    if ($s < 3600) return floor($s / 60) . notifL(' mnt lalu', ' min ago');
    if ($s < 86400) return floor($s / 3600) . notifL(' jam lalu', ' h ago');
    $d = (int)floor($s / 86400);
    if ($d === 1) return notifL('kemarin', 'yesterday');
    if ($d < 7) return $d . notifL(' hari lalu', ' days ago');
    return date('d M Y H:i', strtotime($dt));
}

/** Bentuk JSON satu notifikasi (untuk lonceng & aplikasi Android). */
function notifOut(array $r): array
{
    $cats = notifCats();
    $cat = $cats[$r['category']] ?? $cats['system'];
    return [
        'id'    => (int)$r['id'],
        'cat'   => (string)$r['category'],
        'cat_label' => $cat['label'],
        'type'  => (string)$r['type'],
        'title' => (string)$r['title'],
        'body'  => (string)($r['body'] ?? ''),
        'ago'   => notifAgo((string)$r['created_at']),
        'time'  => date('d M Y H:i', strtotime((string)$r['created_at'])),
        'read'  => !empty($r['read_at']),
        'open'  => 'notif_api.php?a=open&id=' . (int)$r['id'],
        'key'   => (string)($r['alert_key'] ?: 'n:' . (int)$r['id']),
    ];
}
