<?php
/**
 * Jabatan user (Staff, Supervisor, Manager, ...).
 * Disimpan di tabel BARU user_positions supaya struktur tabel users tidak diubah.
 * Tabel dibuat otomatis saat pertama kali dipakai.
 */

function userPositionTableExists(PDO $db, bool $refresh = false): bool
{
    static $exists = null;
    if ($exists === null || $refresh) {
        $exists = (bool)$db->query("
            SELECT COUNT(*) FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'user_positions'
        ")->fetchColumn();
    }
    return $exists;
}

function ensureUserPositionTable(PDO $db): void
{
    if (userPositionTableExists($db)) return;
    $db->exec("
        CREATE TABLE IF NOT EXISTS user_positions (
            user_id     INT UNSIGNED NOT NULL PRIMARY KEY,   -- users.id (tanpa foreign key)
            position    VARCHAR(100) NOT NULL,
            updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    userPositionTableExists($db, true);
}

/** [id user => jabatan] untuk semua user (atau hanya id yang diminta). */
function getUserPositionMap(PDO $db, ?array $userIds = null): array
{
    if (!userPositionTableExists($db)) return [];
    if ($userIds === null) {
        $rows = $db->query("SELECT user_id, position FROM user_positions")->fetchAll();
    } else {
        $ids = array_values(array_unique(array_filter(array_map('intval', $userIds))));
        if (!$ids) return [];
        $rows = [];
        foreach (array_chunk($ids, 500) as $chunk) {
            $st = $db->prepare("SELECT user_id, position FROM user_positions WHERE user_id IN (" . implode(',', array_fill(0, count($chunk), '?')) . ")");
            $st->execute($chunk);
            $rows = array_merge($rows, $st->fetchAll());
        }
    }
    $map = [];
    foreach ($rows as $r) { $map[(int)$r['user_id']] = (string)$r['position']; }
    return $map;
}

function getUserPosition(PDO $db, int $userId): string
{
    return getUserPositionMap($db, [$userId])[$userId] ?? '';
}

/** Simpan jabatan user; jabatan kosong = hapus. */
function saveUserPosition(PDO $db, int $userId, string $position): void
{
    $position = mb_substr(trim($position), 0, 100);
    if ($userId <= 0) return;
    if ($position === '' && !userPositionTableExists($db)) return;
    ensureUserPositionTable($db);
    $db->prepare("DELETE FROM user_positions WHERE user_id = ?")->execute([$userId]);
    if ($position !== '') {
        $db->prepare("INSERT INTO user_positions (user_id, position) VALUES (?, ?)")->execute([$userId, $position]);
    }
}

/** Hapus jabatan milik user yang dihapus. */
function deleteUserPositions(PDO $db, array $userIds): void
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $userIds))));
    if (!$ids || !userPositionTableExists($db)) return;
    $db->prepare("DELETE FROM user_positions WHERE user_id IN (" . implode(',', array_fill(0, count($ids), '?')) . ")")->execute($ids);
}

/** Daftar jabatan yang sudah pernah dipakai (untuk saran saat mengetik). */
function userPositionOptions(PDO $db): array
{
    if (!userPositionTableExists($db)) return [];
    return $db->query("SELECT DISTINCT position FROM user_positions ORDER BY position")->fetchAll(PDO::FETCH_COLUMN);
}

/** Jabatan para pengguna aset, berurutan sesuai urutan nama pengguna: "Staff, Supervisor". */
function ownerPositionsLabel(array $owners, array $positionMap): string
{
    if (!$owners) return '';
    $list = array_map(fn($o) => ($positionMap[(int)$o['id']] ?? '') !== '' ? $positionMap[(int)$o['id']] : '-', $owners);
    return array_filter($list, fn($v) => $v !== '-') ? implode(', ', $list) : '';
}

/** Jabatan para pengguna SATU aset (dipakai di detail aset, Aset Saya, cetak/PDF). */
function assetOwnerPositions(PDO $db, int $assetId): string
{
    $owners = getOwnersForAsset($db, $assetId);
    return $owners ? ownerPositionsLabel($owners, getUserPositionMap($db, array_column($owners, 'id'))) : '';
}

/** Samakan penulisan jabatan untuk dibandingkan: "Asst. Manager GA" = "Asisten Manager GA" = "assistant manager ga". */
function normalizePositionTitle(string $title): string
{
    $s = mb_strtolower(trim($title));
    $s = preg_replace('/\b(assistant|asisten|assisten|asst|ass)\b\.?/u', 'asisten', $s);
    $s = preg_replace('/\b(mgr|manajer)\b\.?/u', 'manager', $s);
    return preg_replace('/[^a-z0-9]+/u', '', $s);
}

/**
 * Nama user pemegang suatu jabatan (dipakai kolom tanda tangan berita acara).
 * Dicocokkan dengan Jabatan di menu User. Kosong kalau belum ada user dengan jabatan itu.
 * Kalau lebih dari satu user punya jabatan yang sama, diambil yang pertama menurut abjad.
 */
function findUserNameByPosition(PDO $db, string $title): string
{
    static $cache = null;
    try {
        if ($cache === null) {
            $cache = [];
            if (userPositionTableExists($db)) {
                $rows = $db->query("SELECT u.full_name, p.position FROM user_positions p JOIN users u ON u.id = p.user_id ORDER BY u.full_name")->fetchAll();
                foreach ($rows as $r) {
                    $k = normalizePositionTitle((string)$r['position']);
                    if ($k !== '' && !isset($cache[$k])) $cache[$k] = (string)$r['full_name'];
                }
            }
        }
    } catch (Throwable $e) { $cache = []; }
    return $cache[normalizePositionTitle($title)] ?? '';
}
