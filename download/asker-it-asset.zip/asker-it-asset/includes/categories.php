<?php
/**
 * Helper untuk fitur Kategori Aset yang bisa dikustomisasi admin.
 * Data kategori disimpan di tabel asset_categories (dibuat lewat
 * upgrade_asset_categories.php). Kolom assets.category tetap berupa teks
 * biasa (bukan foreign key) supaya data aset lama tidak perlu diubah.
 */

/** Ambil semua kategori aset, terurut sesuai urutan tampil. */
function getAssetCategories(PDO $db): array
{
    return $db->query("SELECT id, name, abbr, sort_order FROM asset_categories ORDER BY sort_order, name")->fetchAll();
}

/** Ambil singkatan (abbr) satu kategori berdasarkan nama. Null kalau tidak ditemukan. */
function getCategoryAbbr(PDO $db, string $categoryName): ?string
{
    $stmt = $db->prepare("SELECT abbr FROM asset_categories WHERE name = ? LIMIT 1");
    $stmt->execute([$categoryName]);
    $abbr = $stmt->fetchColumn();
    return $abbr !== false ? $abbr : null;
}
