<?php
/**
 * Menu "Ganti Password PC" (khusus admin). Lihat includes/pc_password.php.
 * Saring jenis aset / departement, buat password baru (otomatis atau diketik sendiri),
 * export Excel sebagai daftar kerja, lalu terapkan ke sistem setelah password di PC diganti.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/pc_password.php';

$db      = getDB();
ensurePcpwTable($db); // tabel BARU asset_pc_passwords (password PC per aset), dibuat jika belum ada
$options = pcpwFilterOptions($db);
$columns = pcpwColumns();
$isPost  = $_SERVER['REQUEST_METHOD'] === 'POST';
$f       = pcpwFilters($isPost ? $_POST : $_GET, $options);
$f['cols'] = array_values(array_intersect(array_keys($columns), $f['cols']));
if (!$f['cols']) $f['cols'] = array_keys(array_filter($columns, fn($c) => $c[1])); // bawaan
$rows    = pcpwRows($db, $f);
$visibleAssets = array_column($rows, 'asset_id');

// ===================== AKSI (POST) =====================
if ($isPost) {
    csrfCheck();
    $action = (string)($_POST['action'] ?? 'save');
    $draft  = pcpwReadDraft();
    $now    = date('Y-m-d H:i:s');

    // 1) Simpan dulu password yang diketik / diubah sendiri di kotak "Password Baru".
    foreach ((array)($_POST['new'] ?? []) as $aid => $val) {
        $aid = (int)$aid;
        if (!in_array($aid, $visibleAssets, true)) continue;
        $val = mb_substr(trim((string)$val), 0, PCPW_MAX_LEN);
        if ($val === '') { unset($draft[$aid]); }
        elseif (($draft[$aid]['new'] ?? null) !== $val) { $draft[$aid] = ['new' => $val, 'at' => $now]; }
    }

    // 2) Sasaran aksi: baris yang dicentang; kalau tidak ada yang dicentang = semua yang tampil.
    $picked  = array_values(array_intersect(array_map('intval', (array)($_POST['rows'] ?? [])), $visibleAssets));
    $targets = $picked ?: $visibleAssets;
    $msg     = ['ok' => true, 'text' => t('pcpw_msg_saved')];

    if ($action === 'generate') {
        $len = max(PCPW_MIN_LEN, min(PCPW_MAX_LEN, (int)($_POST['length'] ?? PCPW_DEFAULT_LEN)));
        // Tiap aset mendapat password berbeda: tidak sama dengan aset lain, baik yang sedang dipakai maupun yang baru dibuat.
        foreach ($targets as $aid) { unset($draft[$aid]); }
        $used = pcpwUsedPasswords($db, $draft);
        foreach ($targets as $aid) { $draft[$aid] = ['new' => pcpwGenerateUnique($len, $used), 'at' => $now]; }
        $msg['text'] = t('pcpw_msg_generated', count($targets));
    } elseif ($action === 'clear') {
        foreach ($targets as $aid) { unset($draft[$aid]); }
        $msg['text'] = t('pcpw_msg_cleared', count($targets));
    }

    if (!pcpwWriteDraft($draft)) {
        $msg = ['ok' => false, 'text' => t('pcpw_err_write')];
    } elseif ($action === 'apply') {
        try {
            $n = pcpwApply($db, $targets, (int)($_SESSION['user_id'] ?? 0) ?: null);
            $msg = $n > 0 ? ['ok' => true, 'text' => t('pcpw_msg_applied', $n)] : ['ok' => false, 'text' => t('pcpw_err_nothing')];
        } catch (Throwable $e) {
            $msg = ['ok' => false, 'text' => t('pcpw_err_apply') . ' ' . $e->getMessage()];
        }
    }

    // ---------- Export Excel (daftar kerja) ----------
    if ($action === 'export' && $msg['ok']) {
        require_once __DIR__ . '/vendor/autoload.php';
        $exportRows = $picked ? array_values(array_filter($rows, fn($r) => in_array($r['asset_id'], $picked, true))) : $rows;
        $cols = $f['cols'];

        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Ganti Password PC');
        $coord = fn(int $c) => \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($c);
        $text  = \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING;
        $lastCol = $coord(count($cols) + 1);

        $info = [
            t('app_name') . ' — ' . t('pcpw_xls_title'),
            t('field_category') . ': ' . ($f['category'] ? implode(', ', $f['category']) : t('pcpw_all'))
                . '   |   ' . t('xls_hdr_department') . ': ' . ($f['department'] ? implode(', ', $f['department']) : t('pcpw_all')),
            t('pcpw_xls_printed') . ': ' . date('d M Y H:i') . '   |   ' . t('pcpw_xls_by') . ': ' . (currentUser()['full_name'] ?? '-')
                . '   |   ' . t('pcpw_xls_total') . ': ' . count($exportRows),
        ];
        foreach ($info as $i => $line) {
            $sheet->setCellValueExplicit('A' . ($i + 1), $line, $text);
            $sheet->mergeCells('A' . ($i + 1) . ':' . $lastCol . ($i + 1));
        }
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(13);

        $headRow = 5;
        $sheet->setCellValueExplicit('A' . $headRow, 'No', $text);
        foreach ($cols as $c => $key) { $sheet->setCellValueExplicit($coord($c + 2) . $headRow, $columns[$key][0], $text); }
        $widths = array_map(fn($key) => mb_strlen($columns[$key][0]), $cols);
        foreach ($exportRows as $r => $row) {
            $excelRow = $headRow + 1 + $r;
            $sheet->setCellValue('A' . $excelRow, $r + 1);
            foreach ($cols as $c => $key) {
                $val = $key === 'new_password' ? ($draft[$row['asset_id']]['new'] ?? '') : ($key === 'done' ? '' : (string)($row[$key] ?? ''));
                // Semua ditulis sebagai TEKS supaya password / IP tidak diubah formatnya oleh Excel.
                $sheet->setCellValueExplicit($coord($c + 2) . $excelRow, $val, $text);
                $widths[$c] = max($widths[$c], mb_strlen($val));
            }
        }
        $lastRow = $headRow + max(1, count($exportRows));
        $head = "A{$headRow}:{$lastCol}{$headRow}";
        $sheet->getStyle($head)->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
        $sheet->getStyle($head)->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
        $sheet->getStyle($head)->getAlignment()->setHorizontal('center')->setVertical('center');
        $sheet->getStyle("A{$headRow}:{$lastCol}{$lastRow}")->getBorders()->getAllBorders()
              ->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
        $sheet->getColumnDimension('A')->setWidth(6);
        foreach ($cols as $c => $key) {
            $sheet->getColumnDimension($coord($c + 2))->setWidth(min(45, max(12, $widths[$c] + 3)));
            if (in_array($key, ['old_password', 'new_password', 'pc_username'], true)) {
                $sheet->getStyle($coord($c + 2) . ($headRow + 1) . ':' . $coord($c + 2) . $lastRow)->getFont()->setName('Consolas');
            }
        }
        $sheet->freezePane('A' . ($headRow + 1));
        $sheet->setAutoFilter($head);
        $sheet->getPageSetup()->setOrientation(\PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_LANDSCAPE)
              ->setFitToWidth(1)->setFitToHeight(0);

        // Kop + judul + tanggal dibuat + jumlah aset, judul kolom di baris 8.
        require_once __DIR__ . '/includes/xls_number.php';
        require_once __DIR__ . '/includes/letterhead.php';
        xlsAddTitleBlock($sheet, $headRow, t('pcpw_xls_title') . ' ' . xlsCompanyName(), [
            documentCreatedAt() . '   |   ' . t('pcpw_xls_by') . ': ' . (currentUser()['full_name'] ?? '-'),
            xlsCountLine('Jumlah aset', 'Total assets', count($exportRows), [
                t('field_category') . ': ' . ($f['category'] ? implode(', ', $f['category']) : t('pcpw_all')),
                t('xls_hdr_department') . ': ' . ($f['department'] ? implode(', ', $f['department']) : t('pcpw_all')),
            ]),
        ]);

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="ganti_password_pc_' . date('Ymd_His') . '.xlsx"');
        header('Cache-Control: max-age=0');
        (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet))->save('php://output');
        exit;
    }

    $_SESSION['pcpw_msg'] = $msg;
    header('Location: pc_password.php?' . pcpwFilterQuery($f));
    exit;
}

// ===================== HALAMAN =====================
$draft   = pcpwReadDraft();
$flash   = $_SESSION['pcpw_msg'] ?? null;
unset($_SESSION['pcpw_msg']);
$pendingVisible = count(array_filter($visibleAssets, fn($id) => isset($draft[$id])));
$pendingAll     = count($draft);
// Password baru yang sama dengan aset lain (hanya mungkin terjadi bila diketik sendiri) ditandai.
$dupCount = [];
foreach ($draft as $d) { $dupCount[$d['new']] = ($dupCount[$d['new']] ?? 0) + 1; }
foreach ($db->query("SELECT pc_password, COUNT(*) c FROM assets WHERE pc_password IS NOT NULL AND pc_password <> '' GROUP BY pc_password")->fetchAll() as $x) {
    if (isset($dupCount[(string)$x['pc_password']])) $dupCount[(string)$x['pc_password']] += (int)$x['c'];
}

$pageTitle = t('page_title_pcpw');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
$h = fn($s) => htmlspecialchars((string)$s);
$showCols = $f['cols'];
?>

<p class="text-sm text-slate-500 mb-3 max-w-3xl"><?= t('pcpw_intro') ?></p>
<ol class="grid sm:grid-cols-3 gap-2 mb-4 text-sm">
    <?php foreach ([t('pcpw_step_1'), t('pcpw_step_2'), t('pcpw_step_3')] as $i => $step): ?>
        <li class="bg-white rounded-lg shadow-sm px-3 py-2 text-slate-600"><span class="font-bold text-brand-600"><?= $i + 1 ?>.</span> <?= $step ?></li>
    <?php endforeach; ?>
</ol>

<?php if ($flash): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $flash['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($flash['text']) ?></div>
<?php endif; ?>

<!-- Saringan + pilihan kolom -->
<form method="get" class="bg-white rounded-xl shadow-sm p-5 mb-4 text-sm space-y-4">
    <input type="hidden" name="f" value="1">
    <div class="flex flex-wrap items-start gap-6">
        <?php foreach (['category' => t('field_category'), 'department' => t('xls_hdr_department')] as $key => $label): ?>
            <fieldset class="min-w-[200px]">
                <legend class="text-xs text-slate-500 mb-1"><?= $label ?> <span class="text-slate-400">(<?= t('audit_none_means_all') ?>)</span></legend>
                <div class="border border-slate-200 rounded-lg p-2 max-h-40 overflow-y-auto space-y-0.5">
                    <?php foreach ($options[$key] as $o): ?>
                        <label class="flex items-center gap-2 px-1.5 py-1 rounded hover:bg-slate-50 cursor-pointer">
                            <input type="checkbox" name="<?= $key ?>[]" value="<?= $h($o) ?>" class="rounded border-slate-300" <?= in_array($o, $f[$key], true) ? 'checked' : '' ?>>
                            <span><?= $h($o) ?></span>
                        </label>
                    <?php endforeach; ?>
                    <?php if (!$options[$key]): ?><p class="px-1.5 py-1 text-slate-400"><?= t('dash') ?></p><?php endif; ?>
                </div>
            </fieldset>
        <?php endforeach; ?>
        <fieldset class="flex-1 min-w-[240px]">
            <legend class="text-xs text-slate-500 mb-1"><?= t('pcpw_columns') ?></legend>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-3 gap-y-0.5">
                <?php foreach ($columns as $key => $c): ?>
                    <label class="flex items-center gap-2 px-1.5 py-1 rounded hover:bg-slate-50 cursor-pointer">
                        <input type="checkbox" name="cols[]" value="<?= $h($key) ?>" class="rounded border-slate-300" <?= in_array($key, $showCols, true) ? 'checked' : '' ?>>
                        <span><?= $h($c[0]) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
        </fieldset>
    </div>
    <div class="flex flex-wrap items-center gap-2">
        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium"><?= t('pcpw_btn_filter') ?></button>
        <a href="pc_password.php" class="px-3 py-2 text-slate-500 hover:text-slate-700"><?= t('audit_reset') ?></a>
    </div>
</form>

<!-- Daftar + aksi -->
<form method="post" id="pcpwForm" class="bg-white rounded-xl shadow-sm overflow-hidden" autocomplete="off">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
    <input type="hidden" name="f" value="1">
    <?php foreach (['category', 'department', 'cols'] as $key): foreach ($f[$key] as $v): ?>
        <input type="hidden" name="<?= $key ?>[]" value="<?= $h($v) ?>">
    <?php endforeach; endforeach; ?>

    <div id="pcpwToolbar" class="list-toolbar-sticky px-5 py-3 border-b flex flex-wrap items-center justify-between gap-3">
        <div>
            <h2 class="font-semibold text-slate-800"><?= t('pcpw_list_title') ?>
                <span class="ml-1 text-xs font-normal text-slate-400"><?= $h(sprintf(t('pcpw_list_count'), count($rows))) ?></span></h2>
            <p class="text-xs text-slate-400"><?= t('pcpw_target_hint') ?></p>
        </div>
        <div class="flex flex-wrap items-center gap-2 text-sm">
            <label class="flex items-center gap-1.5 text-xs text-slate-500"><?= t('pc_pass_gen_length') ?>
                <select name="length" class="border rounded-lg px-2 py-1.5 text-sm text-slate-700">
                    <?php foreach (PCPW_LENGTHS as $len): ?><option value="<?= $len ?>" <?= $len === PCPW_DEFAULT_LEN ? 'selected' : '' ?>><?= $len ?></option><?php endforeach; ?>
                </select>
            </label>
            <button type="submit" name="action" value="generate" class="rounded-lg border border-blue-200 bg-blue-50 hover:bg-blue-100 text-brand-700 px-3 py-2 font-medium"><?= t('pcpw_btn_generate') ?></button>
            <button type="submit" name="action" value="save" class="rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 px-3 py-2 font-medium"><?= t('pcpw_btn_save') ?></button>
            <button type="submit" name="action" value="export" class="inline-flex items-center gap-2 rounded-lg bg-green-600 hover:bg-green-700 text-white px-3 py-2 font-medium"><?= icon('sheet') ?> <?= t('btn_export_excel') ?></button>
            <button type="submit" name="action" value="apply" onclick="return confirm(<?= $h(json_encode(t('pcpw_confirm_apply'))) ?>)"
                    class="inline-flex items-center gap-2 rounded-lg bg-brand-600 hover:bg-brand-700 text-white px-3 py-2 font-medium"><?= icon('check') ?> <?= t('pcpw_btn_apply') ?></button>
            <button type="submit" name="action" value="clear" onclick="return confirm(<?= $h(json_encode(t('pcpw_confirm_clear'))) ?>)"
                    class="rounded-lg px-2 py-2 text-slate-500 hover:text-red-600" <?= $pendingVisible ? '' : 'disabled' ?>><?= t('pcpw_btn_clear') ?></button>
        </div>
    </div>

    <?php if ($pendingAll): ?>
        <p class="px-5 py-2 text-xs bg-amber-50 text-amber-800 border-b"><?= $h(sprintf(t('pcpw_pending_note'), $pendingAll)) ?></p>
    <?php endif; ?>

    <?php if (!$rows): ?>
        <p class="p-8 text-center text-sm text-slate-400"><?= t('pcpw_no_rows') ?></p>
    <?php else: ?>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-slate-50 text-left text-xs text-slate-500">
            <tr>
                <th class="py-2 px-3 w-8"><input type="checkbox" id="pcpwCheckAll" aria-label="<?= $h(t('audit_select_all')) ?>"></th>
                <?php // data-priority: kolom mana yang dipertahankan saat layar sempit (angka kecil = lebih penting)
                $colPriority = ['full_name' => 1, 'asset_number' => 2, 'old_password' => 3, 'new_password' => 3, 'ip_address' => 4, 'category' => 5,
                                'department' => 6, 'location' => 7, 'pc_username' => 8, 'device_name' => 9]; ?>
                <?php foreach ($showCols as $key): if ($key === 'done') continue; ?><th class="py-2 px-3" data-priority="<?= $colPriority[$key] ?? 9 ?>"><?= $h($columns[$key][0]) ?></th><?php endforeach; ?>
                <th class="py-2 px-3" data-priority="10"><?= t('xls_hdr_status') ?></th>
            </tr>
            </thead>
            <tbody class="divide-y">
            <?php foreach ($rows as $r): $aid = $r['asset_id']; $new = $draft[$aid]['new'] ?? '';
                  $weak = $new !== '' && !pcpwMeetsRule($new);
                  $dup  = $new !== '' && (($dupCount[$new] ?? 0) > 1 || ($new === $r['old_password'])); ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-2 px-3"><input type="checkbox" name="rows[]" value="<?= $aid ?>" class="pcpw-row rounded border-slate-300" aria-label="<?= $h($r['asset_number']) ?>"></td>
                    <?php foreach ($showCols as $key): if ($key === 'done') continue; ?>
                        <?php if ($key === 'new_password'): ?>
                            <td class="py-2 px-3">
                                <input type="text" name="new[<?= $aid ?>]" value="<?= $h($new) ?>" maxlength="<?= PCPW_MAX_LEN ?>" spellcheck="false" autocomplete="off"
                                       placeholder="<?= $h(t('pcpw_new_placeholder')) ?>"
                                       class="pcpw-new w-28 sm:w-36 border rounded-lg px-2 py-1 font-mono <?= ($weak || $dup) ? 'border-amber-400' : 'border-slate-300' ?>">
                                <?php if ($dup): ?><div class="text-[11px] text-amber-600 mt-0.5"><?= t('pcpw_dup') ?></div>
                                <?php elseif ($weak): ?><div class="text-[11px] text-amber-600 mt-0.5"><?= t('pcpw_weak') ?></div><?php endif; ?>
                            </td>
                        <?php elseif ($key === 'old_password' || $key === 'pc_username'): ?>
                            <td class="py-2 px-3 font-mono whitespace-nowrap"><?= $r[$key] !== '' ? $h($r[$key]) : t('dash') ?></td>
                        <?php else: ?>
                            <td class="py-2 px-3 whitespace-nowrap <?= $key === 'full_name' ? 'font-medium text-slate-800' : '' ?>"><?= $r[$key] !== '' ? $h($r[$key]) : t('dash') ?></td>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <td class="py-2 px-3 whitespace-nowrap">
                        <?php if ($new !== ''): ?>
                            <span class="px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-700"><?= t('pcpw_status_pending') ?></span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-500"><?= t('pcpw_status_none') ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <div class="px-5 py-3 border-t text-xs text-slate-400 space-y-0.5">
        <p><?= t('pcpw_note_per_asset') ?></p>
    </div>
</form>

<?php
$extraScripts = ($extraScripts ?? '') . <<<'HTML'
<script>
(function () {
    // Bar tombol (Buat password, Simpan, Export, Terapkan) menempel di atas saat daftar di-scroll;
    // tinggi bar dicatat supaya judul kolom tabel menempel tepat di bawahnya.
    var bar = document.getElementById('pcpwToolbar'), form = document.getElementById('pcpwForm');
    function setBarHeight() { if (bar && form) form.style.setProperty('--rt-top', bar.offsetHeight + 'px'); }
    setBarHeight();
    window.addEventListener('resize', setBarHeight);
    window.addEventListener('load', setBarHeight);
    [300, 1200].forEach(function (ms) { setTimeout(setBarHeight, ms); });
    var all = document.getElementById('pcpwCheckAll');
    var boxes = document.querySelectorAll('.pcpw-row');
    if (all) all.addEventListener('change', function () { boxes.forEach(function (b) { b.checked = all.checked; }); });
    // Enter di kotak password = simpan perubahan (bukan "Buat password baru").
    document.querySelectorAll('.pcpw-new').forEach(function (i) {
        i.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') { e.preventDefault(); document.querySelector('#pcpwForm button[value="save"]').click(); }
        });
    });
})();
</script>
HTML;
require_once __DIR__ . '/includes/footer.php';
