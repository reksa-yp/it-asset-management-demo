<?php
/**
 * Cetak Nametag Tamu (khusus admin). Dipanggil dari nametag.php?tab=tamu (POST).
 *   go=print -> halaman cetak (dialog cetak otomatis)
 *   go=pdf   -> unduh PDF (F4 / Legal landscape, 2 nametag per lembar)
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();
requireAdmin();
require_once __DIR__ . '/includes/nametag_guest.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: nametag.php?tab=tamu'); exit; }
csrfCheck();

$paper = isset(ngPapers()[$_POST['paper'] ?? '']) ? (string)$_POST['paper'] : 'f4';
$rows  = ngCleanRows((array)($_POST['names'] ?? []), (array)($_POST['titles'] ?? []));
$_SESSION['nt_guest'] = ['paper' => $paper, 'rows' => $rows];      // diingat saat kembali ke halaman
if (!$rows) {
    $_SESSION['nt_msg'] = ['ok' => false, 'msg' => ntL('Isi minimal satu nama tamu.', 'Enter at least one guest name.')];
    header('Location: nametag.php?tab=tamu');
    exit;
}

@set_time_limit(180);
@ini_set('memory_limit', '512M');
$srcs = [];
foreach ($rows as $r) $srcs[] = 'data:image/png;base64,' . base64_encode(ngRenderPng($r['name'], $r['title'], 300));
$p = ngPapers()[$paper];
$fileBase = 'Nametag_Tamu_' . count($rows) . '_' . date('Ymd_His');

if (($_POST['go'] ?? '') === 'pdf') {
    require_once __DIR__ . '/vendor/autoload.php';
    $options = new Dompdf\Options();
    $options->set('isRemoteEnabled', false);
    $options->set('dpi', 300);
    $dompdf = new Dompdf\Dompdf($options);
    $dompdf->setPaper($p['pt']);
    $dompdf->loadHtml('<html><head><meta charset="UTF-8"><style>@page{margin:0}body{margin:0}</style></head><body>' . ngSheetsHtml($srcs, $paper, true) . '</body></html>');
    $dompdf->render();
    $dompdf->stream($fileBase . '_' . $p['short'] . '.pdf', ['Attachment' => true]);
    exit;
}
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES);
?><!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $h($fileBase) ?></title>
<style>
@page { size: <?= $p['w'] ?>mm <?= $p['h'] ?>mm; margin: 0; }
html, body { margin: 0; background: #e2e8f0; font-family: "Segoe UI", Arial, sans-serif; }
.bar { position: sticky; top: 0; background: #fff; border-bottom: 1px solid #cbd5e1; padding: 10px 16px; display: flex; flex-wrap: wrap; gap: 10px; align-items: center; z-index: 2; }
.bar button, .bar a { font: 600 14px inherit; padding: 8px 14px; border-radius: 8px; border: 1px solid #cbd5e1; background: #fff; color: #0f172a; text-decoration: none; cursor: pointer; }
.bar .pri { background: #2563eb; border-color: #2563eb; color: #fff; }
.warn { background: #fef3c7; color: #92400e; border: 1px solid #fcd34d; border-radius: 8px; padding: 8px 12px; font-size: 13px; flex: 1 1 320px; line-height: 1.4; }
.scroll { overflow-x: auto; padding: 16px; }
.sheet { margin: 0 auto 16px; background: #fff; box-shadow: 0 8px 24px rgba(15,23,42,.25); }
@media print {
  html, body { background: #fff; }
  .bar { display: none; }
  .scroll { padding: 0; overflow: visible; }
  .sheet { margin: 0; box-shadow: none; }
}
</style></head>
<body>
<div class="bar">
  <button class="pri" onclick="doPrint()">🖨️ Cetak (<?= count($rows) ?> nametag, <?= (int)ceil(count($rows) / 2) ?> lembar)</button>
  <a href="nametag.php?tab=tamu">← Kembali</a>
  <div class="warn"><b>Gunakan kertas <?= $h($p['name']) ?> (<?= $h($p['size']) ?>).</b> Di dialog cetak pilih ukuran kertas <b><?= $h($p['short']) ?></b>, orientasi <b>Landscape</b>, skala <b>100% / Actual size</b>, margin <b>None</b>. Potong di garis putus-putus merah, lipat di tanda tengah.</div>
</div>
<div class="scroll"><?= ngSheetsHtml($srcs, $paper, false) ?></div>
<script>
function doPrint() {
    if (window.TMNNApp && TMNNApp.print) TMNNApp.print(<?= json_encode($fileBase) ?>); else window.print();
}
window.addEventListener('load', function () { setTimeout(doPrint, 500); });
</script>
</body></html>
