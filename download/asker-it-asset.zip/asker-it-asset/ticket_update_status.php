<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tickets.php');
    exit;
}
csrfCheck();

$id     = $_POST['id'] ?? null;
$status = $_POST['status'] ?? 'Menunggu';
$valid  = ['Menunggu','Proses','Selesai'];
if (!$id || !in_array($status, $valid, true)) {
    header('Location: tickets.php');
    exit;
}

$db = getDB();
// Tiket yang sudah dibatalkan user tidak bisa diubah statusnya lagi.
if (getTicketCancelMap($db, [(int)$id])) {
    $_SESSION['ticket_bulk_msg'] = ['ok' => false, 'text' => t('ticket_cancel_locked')];
    header('Location: tickets.php');
    exit;
}
// Waktu selesai memakai jam server database (NOW()), sama dengan Tanggal Dibuat tiket, supaya
// "selesai hari ini" di Dashboard tidak meleset karena beda zona waktu PHP dan database.
// Tiket yang SUDAH Selesai lalu disimpan ulang tidak mengubah waktu selesainya.
$cur = $db->prepare("SELECT status, resolved_at FROM tickets WHERE id = ?");
$cur->execute([(int)$id]);
$current = $cur->fetch() ?: ['status' => '', 'resolved_at' => null];

if ($status !== 'Selesai') {
    $db->prepare("UPDATE tickets SET status = ?, handled_by = ?, resolved_at = NULL WHERE id = ?")
       ->execute([$status, $_SESSION['user_id'], $id]);
} elseif ($current['status'] === 'Selesai' && !empty($current['resolved_at'])) {
    $db->prepare("UPDATE tickets SET handled_by = ? WHERE id = ?")->execute([$_SESSION['user_id'], $id]);
} else {
    $db->prepare("UPDATE tickets SET status = 'Selesai', handled_by = ?, resolved_at = NOW() WHERE id = ?")
       ->execute([$_SESSION['user_id'], $id]);
}

$db->prepare("INSERT INTO ticket_logs (ticket_id, status, note, changed_by) VALUES (?, ?, 'Status diperbarui oleh admin', ?)")
   ->execute([$id, $status, $_SESSION['user_id']]);

// Pusat Notifikasi: beri tahu pelapor bila status tiketnya berubah.
if ($current['status'] !== $status) {
    try {
        require_once __DIR__ . '/includes/notifications.php';
        $nt = $db->prepare("SELECT t.ticket_number, t.reported_by, wd.work_detail FROM tickets t LEFT JOIN ticket_work_details wd ON wd.ticket_id = t.id WHERE t.id = ?");
        $nt->execute([(int)$id]);
        if ($tk = $nt->fetch()) {
            $who = (string)($_SESSION['full_name'] ?? 'Admin IT');
            $num = (string)$tk['ticket_number'];
            if ($status === 'Proses') {
                $title = notifL('Tiket ', 'Ticket ') . $num . notifL(' sedang diproses', ' is in progress');
                $body  = notifL('Ditangani oleh ', 'Handled by ') . $who;
            } elseif ($status === 'Selesai') {
                $title = notifL('Tiket ', 'Ticket ') . $num . notifL(' selesai', ' resolved');
                $body  = (!empty($tk['work_detail']) ? mb_strimwidth((string)$tk['work_detail'], 0, 140, '...') . ' · ' : '') . notifL('oleh ', 'by ') . $who;
            } else {
                $title = notifL('Tiket ', 'Ticket ') . $num . notifL(' kembali ke antrian', ' is back in the queue');
                $body  = notifL('Diubah oleh ', 'Changed by ') . $who;
            }
            notifAdd($db, [(int)$tk['reported_by']], 'ticket', 'ticket_status', $title, $body, 'tickets.php?q=' . urlencode($num), (int)$id, '', (int)$_SESSION['user_id']);
        }
    } catch (Throwable $e) {}
}

header('Location: tickets.php');
exit;
