<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tickets.php');
    exit;
}
csrfCheck();

$id     = $_POST['id'] ?? null;
$status = $_POST['status'] ?? 'Menunggu';
$valid  = ['Menunggu','Proses','Selesai'];
if (!$id || !in_array($status, $valid, true)) {
    header('Location: tickets.php');
    exit;
}

$db = getDB();
// Tiket yang sudah dibatalkan user tidak bisa diubah statusnya lagi.
if (getTicketCancelMap($db, [(int)$id])) {
    $_SESSION['ticket_bulk_msg'] = ['ok' => false, 'text' => t('ticket_cancel_locked')];
    header('Location: tickets.php');
    exit;
}
// Waktu selesai memakai jam server database (NOW()), sama dengan Tanggal Dibuat tiket, supaya
// "selesai hari ini" di Dashboard tidak meleset karena beda zona waktu PHP dan database.
// Tiket yang SUDAH Selesai lalu disimpan ulang tidak mengubah waktu selesainya.
$cur = $db->prepare("SELECT status, resolved_at FROM tickets WHERE id = ?");
$cur->execute([(int)$id]);
$current = $cur->fetch() ?: ['status' => '', 'resolved_at' => null];

if ($status !== 'Selesai') {
    $db->prepare("UPDATE tickets SET status = ?, handled_by = ?, resolved_at = NULL WHERE id = ?")
       ->execute([$status, $_SESSION['user_id'], $id]);
} elseif ($current['status'] === 'Selesai' && !empty($current['resolved_at'])) {
    $db->prepare("UPDATE tickets SET handled_by = ? WHERE id = ?")->execute([$_SESSION['user_id'], $id]);
} else {
    $db->prepare("UPDATE tickets SET status = 'Selesai', handled_by = ?, resolved_at = NOW() WHERE id = ?")
       ->execute([$_SESSION['user_id'], $id]);
}

$db->prepare("INSERT INTO ticket_logs (ticket_id, status, note, changed_by) VALUES (?, ?, 'Status diperbarui oleh admin', ?)")
   ->execute([$id, $status, $_SESSION['user_id']]);

header('Location: tickets.php');
exit;
