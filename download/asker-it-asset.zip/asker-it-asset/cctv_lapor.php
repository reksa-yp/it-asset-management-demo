<?php
/**
 * Menu CCTV > Lapor CCTV / Laporan petugas.
 *   User "Akses Checklist CCTV" (mis. Security): melaporkan kamera mati / rusak + foto, melihat laporannya sendiri
 *   dan status kamera saat ini (hanya lihat).
 *   Admin: melihat semua laporan, menandai selesai + keterangan perbaikan.
 * Setiap laporan baru langsung muncul sebagai pop-up di web admin dan dikirim ke email notifikasi (jika aktif).
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cctv.php';
requireAdminOrCctv();

$db = getDB();
ensureCctvTables($db);
$h = fn($v) => htmlspecialchars((string)$v);
$admin = isAdmin();
$me = currentUser();
$cams = cctvCameras($db);
$camById = [];
foreach ($cams as $c) $camById[$c['id']] = $c;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $act = (string)($_POST['action'] ?? '');
    if ($act === 'report') {
        $aid   = (int)($_POST['asset_id'] ?? 0);
        $issue = (string)($_POST['issue'] ?? '');
        $note  = mb_substr(trim((string)($_POST['note'] ?? '')), 0, 250);
        if (!isset($camById[$aid]) || !isset(CCTV_REPORT_ISSUES[$issue])) {
            $_SESSION['cctv_msg'] = ['ok' => false, 'text' => cL('Pilih kamera dan jenis masalah.', 'Choose a camera and a problem type.')];
        } elseif ($issue === 'lainnya' && $note === '') {
            $_SESSION['cctv_msg'] = ['ok' => false, 'text' => cL('Untuk "Lainnya", isi keterangan masalahnya.', 'For "Other", describe the problem.')];
        } else {
            $photo = !empty($_FILES['photo']) ? cctvSavePhoto($_FILES['photo'], $aid, date('Y-m-d')) : '';
            [$rid, $err] = cctvCreateReport($db, $camById[$aid], $issue, $note, $photo, $me);
            $_SESSION['cctv_msg'] = ['ok' => true, 'text' => cL('Laporan terkirim ke admin IT. Terima kasih!', 'Report sent to IT admin. Thank you!')
                . ($err !== '' && $admin ? ' ' . cL('(Email gagal: ', '(Email failed: ') . $err . ')' : '')];
        }
        header('Location: cctv_lapor.php');
        exit;
    }
    if ($act === 'done' && $admin) {
        $db->prepare("UPDATE cctv_reports SET status = 'done', handled_by = ?, handled_name = ?, handled_at = ?, admin_note = ? WHERE id = ?")
           ->execute([(int)$me['id'], (string)$me['full_name'], date('Y-m-d H:i:s'), mb_substr(trim((string)($_POST['admin_note'] ?? '')), 0, 250) ?: null, (int)($_POST['id'] ?? 0)]);
        $_SESSION['cctv_msg'] = ['ok' => true, 'text' => cL('Laporan ditandai selesai.', 'Report marked as done.')];
        header('Location: cctv_lapor.php?' . http_build_query(['st' => $_POST['st'] ?? 'open']));
        exit;
    }
    if ($act === 'reopen' && $admin) {
        $db->prepare("UPDATE cctv_reports SET status = 'open', handled_by = NULL, handled_name = NULL, handled_at = NULL WHERE id = ?")->execute([(int)($_POST['id'] ?? 0)]);
        header('Location: cctv_lapor.php?st=open');
        exit;
    }
}
$msg = $_SESSION['cctv_msg'] ?? null;
unset($_SESSION['cctv_msg']);

$st = (string)($_GET['st'] ?? 'open');
if (!in_array($st, ['open', 'done', 'all'], true)) $st = 'open';
$where = []; $args = [];
if (!$admin) { $where[] = 'reported_by = ?'; $args[] = (int)$me['id']; }
if ($st !== 'all') { $where[] = 'status = ?'; $args[] = $st; }
$q = $db->prepare("SELECT * FROM cctv_reports" . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . " ORDER BY reported_at DESC LIMIT 300");
$q->execute($args);
$reports = $q->fetchAll();
$openCount = (int)$db->query("SELECT COUNT(*) FROM cctv_reports WHERE status = 'open'")->fetchColumn();
$openReports = cctvOpenReports($db);
$preselect = (int)($_GET['asset'] ?? 0);

$pageTitle = $admin ? cL('Laporan petugas CCTV', 'CCTV officer reports') : cL('Lapor CCTV', 'Report CCTV');
$cctvTab = 'lapor';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="mb-3">
    <h1 class="text-xl font-semibold text-slate-800"><?= $h($admin ? cL('Laporan petugas CCTV', 'CCTV officer reports') : cL('Lapor CCTV mati / rusak', 'Report a dead / damaged CCTV')) ?></h1>
    <p class="text-sm text-slate-500"><?= $h($admin
        ? cL('Laporan dari petugas (mis. Security). Laporan baru juga muncul sebagai pop-up dan dikirim ke email notifikasi.', 'Reports from officers. New reports also pop up and are emailed.')
        : cL('Laporan langsung diterima admin IT (pop-up & email). Cek dulu status kamera di bawah: kamera yang sudah Offline sudah terdeteksi otomatis.', 'Reports go straight to IT admin. Cameras shown Offline below are already detected automatically.')) ?></p>
</div>

<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<?php if (!$cams): ?>
    <div class="bg-white rounded-xl shadow-sm p-6 text-sm text-slate-600"><?= $h(cL('Belum ada aset kategori CCTV.', 'No CCTV assets yet.')) ?></div>
<?php else: ?>
<div class="grid gap-5 lg:grid-cols-[minmax(0,24rem)_minmax(0,1fr)] items-start mb-6">
    <!-- Form lapor -->
    <form method="post" enctype="multipart/form-data" class="bg-white rounded-xl shadow-sm p-5 space-y-4 text-sm">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="report">
        <h2 class="font-semibold text-slate-800"><?= $h(cL('Buat laporan', 'New report')) ?></h2>
        <label class="flex flex-col gap-1"><span class="font-medium"><?= $h(cL('Kamera', 'Camera')) ?></span>
            <select name="asset_id" required class="border border-slate-300 rounded-lg px-3 py-2">
                <option value=""><?= $h(cL('— pilih kamera —', '— choose camera —')) ?></option>
                <?php foreach ($cams as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= $preselect === $c['id'] ? 'selected' : '' ?>><?= $h(($c['location'] ?: $c['name']) . ' · ' . $c['number']) ?></option>
                <?php endforeach; ?>
            </select></label>
        <fieldset class="space-y-1.5">
            <legend class="font-medium mb-1"><?= $h(cL('Masalah', 'Problem')) ?></legend>
            <?php foreach (array_keys(CCTV_REPORT_ISSUES) as $i => $code): ?>
                <label class="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 cursor-pointer hover:bg-slate-50 has-[:checked]:border-red-400 has-[:checked]:bg-red-50">
                    <input type="radio" name="issue" value="<?= $code ?>" <?= $i === 0 ? 'checked' : '' ?> class="w-4 h-4"> <?= $h(cctvIssueLabel($code)) ?>
                </label>
            <?php endforeach; ?>
        </fieldset>
        <label class="flex flex-col gap-1"><span class="font-medium"><?= $h(cL('Keterangan', 'Details')) ?></span>
            <textarea name="note" rows="3" maxlength="250" placeholder="<?= $h(cL('mis. layar monitor pos hitam sejak jam 08.00', 'e.g. black screen since 08:00')) ?>" class="border border-slate-300 rounded-lg px-3 py-2"></textarea></label>
        <label class="flex flex-col gap-1"><span class="font-medium"><?= $h(cL('Foto (opsional)', 'Photo (optional)')) ?></span>
            <input type="file" name="photo" accept="image/*" capture="environment" class="border border-slate-300 rounded-lg px-3 py-2 text-sm"></label>
        <button class="w-full bg-red-600 hover:bg-red-700 text-white rounded-lg px-4 py-2.5 font-semibold"><?= $h(cL('Kirim laporan', 'Send report')) ?></button>
    </form>

    <!-- Status kamera (hanya lihat) -->
    <div class="bg-white rounded-xl shadow-sm p-4 min-w-0">
        <h2 class="font-semibold text-slate-800 mb-3"><?= $h(cL('Status kamera saat ini', 'Current camera status')) ?></h2>
        <div class="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            <?php foreach ($cams as $c):
                $state = cctvCheckMethod($c) === '' ? 'unknown' : $c['state'];
                $rep = $openReports[$c['id']] ?? [];
                $tone = in_array($state, ['off', 'vl'], true) ? 'border-red-200 bg-red-50/60' : ($rep ? 'border-amber-200 bg-amber-50/60' : 'border-slate-200');
            ?>
                <a href="cctv_lapor.php?asset=<?= $c['id'] ?>" class="rounded-lg border <?= $tone ?> px-3 py-2 text-sm flex items-start justify-between gap-2 hover:shadow-sm min-w-0">
                    <span class="min-w-0"><span class="block font-medium text-slate-800 truncate"><?= $h($c['location'] ?: $c['name']) ?></span>
                        <span class="block text-xs text-slate-500 truncate"><?= $h($c['number']) ?><?= $rep ? ' · ' . $h(cL('sudah dilaporkan', 'already reported')) : '' ?></span></span>
                    <?= cctvStateBadge($state) ?>
                </a>
            <?php endforeach; ?>
        </div>
        <p class="text-xs text-slate-400 mt-3"><?= $h(cL('Klik kamera untuk langsung memilihnya di form laporan.', 'Click a camera to pick it in the form.')) ?></p>
    </div>
</div>
<?php endif; ?>

<!-- Daftar laporan -->
<div class="flex flex-wrap items-center justify-between gap-3 mb-2">
    <h2 class="font-semibold text-slate-800"><?= $h($admin ? cL('Semua laporan', 'All reports') : cL('Laporan saya', 'My reports')) ?></h2>
    <div class="flex gap-1 text-sm">
        <?php foreach (['open' => cL('Belum ditangani', 'Open') . ($admin ? ' (' . $openCount . ')' : ''), 'done' => cL('Selesai', 'Done'), 'all' => cL('Semua', 'All')] as $k => $label): ?>
            <a href="cctv_lapor.php?st=<?= $k ?>" class="px-3 py-1.5 rounded-lg border <?= $st === $k ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50' ?>"><?= $h($label) ?></a>
        <?php endforeach; ?>
    </div>
</div>
<div class="bg-white rounded-xl shadow-sm overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-slate-500 text-xs"><tr>
            <th class="text-left px-3 py-2"><?= $h(cL('Waktu lapor', 'Reported')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Kamera', 'Camera')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Masalah', 'Problem')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Keterangan', 'Details')) ?></th>
            <?php if ($admin): ?><th class="text-left px-3 py-2"><?= $h(cL('Pelapor', 'Reporter')) ?></th><?php endif; ?>
            <th class="text-left px-3 py-2">Status</th>
            <?php if ($admin): ?><th class="text-left px-3 py-2"><?= $h(cL('Tindak lanjut', 'Follow-up')) ?></th><?php endif; ?>
        </tr></thead>
        <tbody>
        <?php foreach ($reports as $r): $c = $camById[(int)$r['asset_id']] ?? null; ?>
            <tr class="border-t align-top">
                <td class="px-3 py-2 whitespace-nowrap tabular-nums"><?= $h(date('d M Y H:i', strtotime((string)$r['reported_at']))) ?></td>
                <td class="px-3 py-2"><div class="font-medium"><?= $h($c ? ($c['location'] ?: $c['name']) : '#' . $r['asset_id']) ?></div><div class="text-xs text-slate-500"><?= $h($c['number'] ?? '') ?></div></td>
                <td class="px-3 py-2"><?= $h(cctvIssueLabel((string)$r['issue'])) ?></td>
                <td class="px-3 py-2 text-slate-600"><?= $h($r['note'] ?? '') ?>
                    <?php if (!empty($r['photo'])): ?><a href="<?= $h(CCTV_PHOTO_URL . '/' . $r['photo']) ?>" target="_blank" class="ml-1 text-blue-600 hover:underline text-xs"><?= $h(cL('Lihat foto', 'Photo')) ?></a><?php endif; ?></td>
                <?php if ($admin): ?><td class="px-3 py-2 whitespace-nowrap"><?= $h($r['reporter_name'] ?? '') ?></td><?php endif; ?>
                <td class="px-3 py-2 whitespace-nowrap">
                    <?php if ($r['status'] === 'done'): ?>
                        <span class="px-2 py-0.5 rounded-full text-xs font-semibold bg-green-100 text-green-700"><?= $h(cL('Selesai', 'Done')) ?></span>
                        <div class="text-xs text-slate-500 mt-1"><?= $h(($r['handled_name'] ?? '') . ' · ' . date('d M Y H:i', strtotime((string)$r['handled_at']))) ?></div>
                        <?php if (!empty($r['admin_note'])): ?><div class="text-xs text-slate-600 mt-0.5 whitespace-normal"><?= $h($r['admin_note']) ?></div><?php endif; ?>
                    <?php else: ?>
                        <span class="px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-700"><?= $h(cL('Belum ditangani', 'Open')) ?></span>
                    <?php endif; ?>
                </td>
                <?php if ($admin): ?>
                <td class="px-3 py-2">
                    <?php if ($r['status'] !== 'done'): ?>
                        <form method="post" class="flex gap-1">
                            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="done">
                            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="st" value="<?= $h($st) ?>">
                            <input name="admin_note" maxlength="250" placeholder="<?= $h(cL('mis. lensa dibersihkan', 'e.g. lens cleaned')) ?>" class="border border-slate-300 rounded-lg px-2 py-1 text-sm w-48">
                            <button class="px-2 py-1 rounded-lg bg-green-600 hover:bg-green-700 text-white text-xs whitespace-nowrap"><?= $h(cL('Tandai selesai', 'Mark done')) ?></button>
                        </form>
                    <?php else: ?>
                        <form method="post"><input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="reopen"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                            <button class="text-xs text-slate-500 hover:text-slate-700 underline"><?= $h(cL('Buka lagi', 'Reopen')) ?></button></form>
                    <?php endif; ?>
                </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; ?>
        <?php if (!$reports): ?><tr><td colspan="<?= $admin ? 7 : 5 ?>" class="px-3 py-6 text-center text-slate-500"><?= $h(cL('Belum ada laporan.', 'No reports.')) ?></td></tr><?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
