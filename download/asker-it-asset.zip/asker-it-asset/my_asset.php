<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();

$db = getDB();
// 1 aset sekarang bisa dipakai beberapa pengguna sekaligus (lihat includes/asset_owners.php).
$myAssetIds = getAssetIdsForUser($db, (int)$_SESSION['user_id']);
$myAssets = [];
if ($myAssetIds) {
    $placeholders = implode(',', array_fill(0, count($myAssetIds), '?'));
    $stmt = $db->prepare("SELECT * FROM assets WHERE id IN ($placeholders) ORDER BY created_at DESC");
    $stmt->execute($myAssetIds);
    $myAssets = $stmt->fetchAll();
}

$selectedId = $_GET['id'] ?? ($myAssets[0]['id'] ?? null);
$asset = null;
foreach ($myAssets as $row) {
    if ($row['id'] == $selectedId) { $asset = $row; break; }
}
// Daftar software aset yang sedang dipilih (bisa lebih dari satu).
if ($asset) {
    $asset['software_items'] = getSoftwareForAsset($db, (int)$asset['id']);
}

// Riwayat tiket untuk aset yang dipilih
$history = [];
if ($asset) {
    $h = $db->prepare("
        SELECT t.*, wd.work_detail AS work_detail, wd.asset_check AS asset_check
        FROM tickets t
        LEFT JOIN ticket_work_details wd ON wd.ticket_id = t.id
        WHERE t.asset_id = ? ORDER BY t.created_at DESC
    ");
    $h->execute([$asset['id']]);
    $history = applyTicketCancellations($db, $h->fetchAll());
}

// Riwayat upgrade aset (tabel baru asset_upgrade_logs, kosong kalau belum pernah di-upgrade)
require_once __DIR__ . '/includes/asset_upgrade.php';
$upgradeHistory = $asset ? getAssetUpgradeHistory($db, (int)$asset['id']) : [];

$categoryLabels = [
    'Desktop PC' => t('cat_desktop'), 'Laptop' => t('cat_laptop'), 'Printer' => t('cat_printer'),
    'Monitor' => t('cat_monitor'), 'Aksesoris' => t('cat_accessory'),
];
$statusLabels = [
    'Digunakan' => t('status_used'), 'Stok' => t('status_stock'), 'Tidak Digunakan' => t('status_unused'),
];
$ticketStatusLabels = [
    'Menunggu' => t('ticket_status_waiting'), 'Proses' => t('ticket_status_process'), 'Selesai' => t('ticket_status_done'),
    'Dibatalkan' => t('ticket_status_cancelled'),
];

$pageTitle = t('page_title_my_asset');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<?php if (count($myAssets) > 1): ?>
<div class="mb-4 flex flex-wrap gap-2">
    <?php foreach ($myAssets as $row): ?>
        <a href="my_asset.php?id=<?= $row['id'] ?>"
           class="px-3 py-1.5 rounded-lg text-sm border transition <?= $row['id']==$selectedId ? 'bg-brand-600 text-white border-brand-600 shadow-sm' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50' ?>">
            <?= htmlspecialchars($row['device_name'] ?: $row['asset_number']) ?>
        </a>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if (!$asset): ?>
    <div class="bg-white rounded-xl shadow-sm p-8 text-center text-slate-400">
        <?= t('no_asset_registered') ?>
    </div>
<?php else: ?>

<?php
$assetStatusColors = [
    'Digunakan' => 'bg-green-100 text-green-700',
    'Stok' => 'bg-amber-100 text-amber-700',
    'Tidak Digunakan' => 'bg-slate-200 text-slate-600',
];
?>

<div class="max-w-3xl mx-auto">

    <div class="bg-white rounded-2xl shadow-sm overflow-hidden mb-4">
        <div class="bg-gradient-to-r from-brand-600 to-brand-700 px-5 py-5 text-white flex items-center justify-between gap-4 flex-wrap">
            <div class="flex items-center gap-3 min-w-0">
                <div class="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                    <?= categoryIcon((string)$asset['category'], 'w-6 h-6') ?>
                </div>
                <div class="min-w-0">
                    <h1 class="font-semibold text-lg truncate"><?= htmlspecialchars($asset['device_name'] ?: $asset['asset_number']) ?></h1>
                    <p class="text-brand-100 text-sm truncate"><?= htmlspecialchars($asset['asset_number']) ?></p>
                </div>
            </div>
            <span class="px-3 py-1 rounded-full text-xs font-semibold shrink-0 <?= $assetStatusColors[$asset['status']] ?? 'bg-white/20 text-white' ?>">
                <?= htmlspecialchars($statusLabels[$asset['status']] ?? $asset['status']) ?>
            </span>
        </div>

        <div class="flex justify-end gap-2 px-4 pt-3">
            <a href="asset_detail_print.php?id=<?= $asset['id'] ?>" target="_blank"
               class="inline-flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap">
                <?= icon('printer', 'w-3.5 h-3.5') ?> <?= t('btn_print') ?>
            </a>
            <a href="asset_detail_pdf.php?id=<?= $asset['id'] ?>"
               class="inline-flex items-center gap-1 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap">
                <?= icon('file-text', 'w-3.5 h-3.5') ?> <?= t('btn_download_pdf') ?>
            </a>
        </div>

        <div class="px-4 pt-3">
            <div class="flex flex-wrap gap-1 -mx-1 px-1">
                <button class="asset-tab-btn asset-tab-active" data-tab="tabGeneral" onclick="assetTabSwitch('tabGeneral', this)"><?= t('win_tab_general') ?></button>
                <button class="asset-tab-btn" data-tab="tabHardware" onclick="assetTabSwitch('tabHardware', this)"><?= t('win_tab_hardware') ?></button>
                <button class="asset-tab-btn" data-tab="tabNetwork" onclick="assetTabSwitch('tabNetwork', this)"><?= t('win_tab_network') ?></button>
                <button class="asset-tab-btn" data-tab="tabSystem" onclick="assetTabSwitch('tabSystem', this)"><?= t('win_tab_system') ?></button>
                <button class="asset-tab-btn" data-tab="tabHistory" onclick="assetTabSwitch('tabHistory', this)"><?= t('win_tab_history') ?></button>
            </div>
        </div>

        <div class="p-5">
            <div id="tabGeneral" class="asset-tab-panel">
                <dl class="divide-y divide-slate-100">
                    <div class="asset-field-row"><dt><?= t('lbl_asset_number') ?></dt><dd><?= htmlspecialchars($asset['asset_number']) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_asset_type') ?></dt><dd><?= htmlspecialchars($categoryLabels[$asset['category']] ?? $asset['category']) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_device_name') ?></dt><dd><?= htmlspecialchars($asset['device_name'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_location') ?></dt><dd><?= htmlspecialchars($asset['location'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_status') ?></dt><dd><?= htmlspecialchars($statusLabels[$asset['status']] ?? $asset['status']) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_department') ?></dt><dd><?= htmlspecialchars($asset['department'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('field_position') ?></dt><dd><?= htmlspecialchars(assetOwnerPositions($db, (int)$asset['id']) ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_user_email') ?></dt><dd><?= htmlspecialchars($asset['owner_email'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_serial_number') ?></dt><dd><?= htmlspecialchars($asset['serial_number'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_purchase_date') ?></dt><dd><?= !empty($asset['purchase_date'] ?? null) ? date('d M Y', strtotime($asset['purchase_date'])) : t('dash') ?></dd></div>
                </dl>
            </div>

            <div id="tabHardware" class="asset-tab-panel hidden">
                <dl class="divide-y divide-slate-100">
                    <div class="asset-field-row"><dt><?= t('lbl_processor') ?></dt><dd><?= htmlspecialchars($asset['processor'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_motherboard') ?></dt><dd><?= htmlspecialchars($asset['motherboard_brand'] ?? '' ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_ram') ?></dt><dd><?= htmlspecialchars($asset['ram'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_storage') ?></dt><dd><?= htmlspecialchars($asset['storage'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_monitor') ?></dt><dd><?= htmlspecialchars($asset['monitor_info'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_printer') ?></dt><dd><?= htmlspecialchars($asset['printer_info'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_accessories') ?></dt><dd><?= htmlspecialchars($asset['accessories'] ?: t('dash')) ?></dd></div>
                </dl>
            </div>

            <div id="tabNetwork" class="asset-tab-panel hidden">
                <dl class="divide-y divide-slate-100">
                    <div class="asset-field-row"><dt><?= t('lbl_ip_address') ?></dt><dd><?= htmlspecialchars($asset['ip_address'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_hostname') ?></dt><dd><?= htmlspecialchars($asset['hostname'] ?: t('dash')) ?></dd></div>
                </dl>
            </div>

            <div id="tabSystem" class="asset-tab-panel hidden">
                <dl class="divide-y divide-slate-100">
                    <div class="asset-field-row"><dt><?= t('lbl_os') ?></dt><dd><?= htmlspecialchars($asset['os_name'] ?: t('dash')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_os_license_status') ?></dt><dd><?= htmlspecialchars($asset['os_status'] === 'Original' ? t('os_original') : t('os_not_original')) ?></dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_installed_software') ?></dt><dd>
                        <?php if (!empty($asset['software_items'])): ?>
                            <div class="space-y-1">
                                <?php foreach ($asset['software_items'] as $si): ?>
                                    <div><?= htmlspecialchars($si['software_name']) ?><?= $si['serial_number'] ? ' (' . htmlspecialchars($si['serial_number']) . ')' : '' ?> — <?= htmlspecialchars($si['status'] === 'Original' ? t('os_original') : t('os_not_original')) ?></div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <?= t('dash') ?>
                        <?php endif; ?>
                    </dd></div>
                    <div class="asset-field-row"><dt><?= t('lbl_input_date') ?></dt><dd><?= date('d M Y', strtotime($asset['created_at'])) ?></dd></div>
                </dl>
            </div>

            <div id="tabHistory" class="asset-tab-panel hidden">
                <?php if ($upgradeHistory): ?>
                    <p class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2"><?= t('upg_history_title') ?></p>
                    <div class="mb-5"><?= renderUpgradeHistoryCards($upgradeHistory) ?></div>
                    <p class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2"><?= t('info_ticket_history') ?></p>
                <?php endif; ?>
                <?php if (!$history): ?>
                    <p class="text-sm text-slate-400 text-center py-6"><?= t('no_history_yet') ?></p>
                <?php else: ?>
                <div class="space-y-3">
                    <?php foreach ($history as $h): ?>
                    <div class="rounded-xl border border-slate-100 bg-slate-50 p-3">
                        <div class="flex items-center justify-between gap-2 mb-1">
                            <span class="text-sm font-medium text-slate-700"><?= htmlspecialchars($h['ticket_number']) ?></span>
                            <span class="text-xs px-2 py-0.5 rounded-full bg-white border border-slate-200 text-slate-600"><?= htmlspecialchars($ticketStatusLabels[$h['status']] ?? $h['status']) ?></span>
                        </div>
                        <p class="text-xs text-slate-400 mb-1"><?= date('d/m/Y H:i', strtotime($h['created_at'])) ?></p>
                        <?php if (!empty($h['work_detail']) || !empty($h['asset_check'])): ?>
                            <div class="text-xs text-slate-600 space-y-1 mt-1">
                                <?php if (!empty($h['work_detail'])): ?>
                                    <div><b><?= htmlspecialchars(t('lbl_work_detail_short')) ?>:</b> <?= nl2br(htmlspecialchars($h['work_detail'])) ?></div>
                                <?php endif; ?>
                                <?php if (!empty($h['asset_check'])): ?>
                                    <div><b><?= htmlspecialchars(t('lbl_asset_check_short')) ?>:</b> <?= nl2br(htmlspecialchars($h['asset_check'])) ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
