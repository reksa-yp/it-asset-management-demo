<?php
/**
 * Simpan / hapus Pekerjaan CCTV dan daftar jenis pekerjaan (khusus admin).
 * Dipanggil dari form di cctv_checklist.php dan cctv_jobs.php. Lihat includes/cctv_jobs.php.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv_jobs.php';
csrfCheck();

$db = getDB();
cctvJobsEnsure($db);
$back = (string)($_POST['back'] ?? 'cctv_jobs.php');
if (!preg_match('/^cctv_(checklist|jobs)\.php([?#][^\r\n]*)?$/', $back)) $back = 'cctv_jobs.php';

$act = (string)($_POST['act'] ?? 'save');
if ($act === 'delete') {
    $r = cctvJobDelete($db, (int)($_POST['job_id'] ?? 0));
} elseif ($act === 'types') {
    cctvJobTypesSave($db, $_POST);
    $r = ['ok' => true, 'msg' => cL('Jenis pekerjaan disimpan.', 'Job types saved.')];
} else {
    $r = cctvJobSave($db, $_POST, $_FILES, currentUser());
}
$_SESSION['cctv_job_msg'] = $r;
header('Location: ' . $back . (strpos($back, '#') === false ? '#pekerjaan' : ''));
exit;
