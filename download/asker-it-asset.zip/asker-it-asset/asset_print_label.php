<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/scan.php';

// Terima banyak ID (ids[]=1&ids[]=2...) atau tetap kompatibel dengan id= tunggal (link lama)
$ids = $_GET['ids'] ?? ($_GET['id'] ?? null);
if ($ids === null) { die(htmlspecialchars(t('no_assets_yet'))); }
if (!is_array($ids)) { $ids = [$ids]; }
$ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
if (empty($ids)) { die(htmlspecialchars(t('no_assets_yet'))); }

$db = getDB();
$placeholders = implode(',', array_fill(0, count($ids), '?'));
$stmt = $db->prepare("SELECT a.*, u.full_name AS legacy_owner_name FROM assets a
                      LEFT JOIN users u ON u.id = a.owner_user_id WHERE a.id IN ($placeholders)");
$stmt->execute($ids);
$assets = $stmt->fetchAll();
// Pengguna aset dibaca dari tabel asset_owners (sumber yang sama dengan daftar Aset, Mutasi &
// Barang Keluar stok). Kolom lama assets.owner_user_id hanya dipakai kalau migrasi Multi
// Pengguna belum dijalankan, supaya label tidak kosong / tidak mencetak pengguna lama.
$useOwnersTable = assetOwnersTableExists($db);
$ownersMap = $useOwnersTable ? getAssetOwnersMap($db, $ids) : [];
foreach ($assets as &$row) {
    $row['owner_name'] = $useOwnersTable
        ? ownerNamesLabel($ownersMap[(int)$row['id']] ?? [])
        : (string)($row['legacy_owner_name'] ?? '');
    // Lokasi kosong -> pakai Departement aset (ikut data user) supaya label tetap informatif.
    $row['label_location'] = trim((string)($row['location'] ?? '')) !== ''
        ? trim((string)$row['location']) : trim((string)($row['department'] ?? ''));
}
unset($row);

/** Kategori tanpa Hostname & IP di label (Ext Telepon, Printer, Monitor, Aksesoris): cukup ID, User, Lokasi. */
function labelIsSimpleCategory(?string $category): bool
{
    return (bool)preg_match('/tele?pon|telephone|phone|printer|monitor|aksesoris|accessor/i', (string)$category);
}
if (empty($assets)) { die(htmlspecialchars(t('no_assets_yet'))); }
// Urutkan sesuai urutan ID yang dipilih di halaman daftar
$byId = [];
foreach ($assets as $row) { $byId[$row['id']] = $row; }
$assets = array_values(array_filter(array_map(fn($id) => $byId[$id] ?? null, $ids)));
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars(t('link_print_label')) ?><?= count($assets) > 1 ? ' (' . count($assets) . ')' : ' - ' . htmlspecialchars($assets[0]['asset_number']) ?></title>
<style>
    /* Ukuran KERTAS/gap tetap 7,5cm x 4,5cm seperti semula. Di dalamnya sekarang
       ditempatkan 2 label yang masing-masing berukuran 7,5cm x 2,2cm, dengan
       jarak/gap 1mm di antara keduanya (2 x 22mm + 1mm gap = 45mm total). */
    @page { size: 75mm 45mm; margin: 0; }
    * { box-sizing: border-box; }
    body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
    .label-sheet {
        display: flex;
        flex-direction: column;
    }
    .label-page {
        display: flex;
        flex-direction: column;
        gap: 1mm;
        break-inside: avoid; page-break-inside: avoid;
    }
    /* Tiap halaman/kertas (75mm x 45mm) berisi 2 label (slot kedua dikosongkan kalau tidak ada aset lagi) */
    .label-page:not(:last-child) { page-break-after: always; break-after: page; }
    .label, .label-empty {
        width: 75mm; height: 22mm;
        border: 1.2pt solid #000; border-radius: 1mm;
        overflow: hidden;
        break-inside: avoid; page-break-inside: avoid;
    }
    .label-empty { /* slot kedua kosong, sengaja dibiarkan tanpa isi supaya lembar tetap utuh 2 label */ }
    .label {
        padding: 0.8mm 2mm;
        display: flex; flex-direction: column; justify-content: center; align-items: center;
    }
    .label .top-row { display: flex; gap: 1.5mm; align-items: center; justify-content: center; }
    .label .barcode-box {
        width: 15mm; height: 15mm; flex: none;
        display: flex; align-items: center; justify-content: center;
        overflow: hidden;
    }
    .label .barcode-box img { width: 100%; height: 100%; object-fit: contain; }
    .label .info { min-width: 0; overflow: hidden; flex: none; width: 44mm; }
    .label .info p {
        margin: 0.3mm 0; font-size: 8pt; color: #333; line-height: 1.15;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .label .asset-number {
        text-align: center; font-weight: 700; font-size: 8pt; letter-spacing: 0.15mm;
        line-height: 1.05; margin-top: -0.4mm;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .no-print { margin: 6mm; font-family: Arial, sans-serif; font-size: 12px; color: #444; }
    .no-print button { margin-top: 6px; }
    @media print {
        .no-print { display: none; }
    }
</style>
</head>
<body onload="window.print()">
    <div class="label-sheet">
    <?php foreach (array_chunk($assets, 2) as $pair): ?>
        <div class="label-page">
        <?php foreach ($pair as $a): ?>
            <?php // QR berisi alamat scan.php?no=<Nomor Aset>: di-scan kamera HP langsung membuka detail aset.
                  $barcodeUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&ecc=L&qzone=1&data=' . urlencode(scanAssetUrl($a['asset_number'])); ?>
            <div class="label">
                <div class="top-row">
                    <div class="barcode-box"><img src="<?= $barcodeUrl ?>" alt="QR Code"></div>
                    <div class="info">
                        <?php $simple = labelIsSimpleCategory($a['category'] ?? ''); ?>
                        <p><b><?= htmlspecialchars(t('pc_user_label')) ?></b> : <?= htmlspecialchars($a['owner_name'] !== '' ? $a['owner_name'] : t('dash')) ?></p>
                        <?php if (!$simple): ?>
                        <p><b><?= htmlspecialchars(t('th_hostname')) ?></b> : <?= htmlspecialchars($a['hostname'] ?: t('dash')) ?></p>
                        <?php endif; ?>
                        <p><b><?= htmlspecialchars(t('th_location')) ?></b> : <?= htmlspecialchars($a['label_location'] !== '' ? $a['label_location'] : t('dash')) ?></p>
                        <?php if (!$simple): ?>
                        <p><b><?= htmlspecialchars(t('lbl_ip_short')) ?></b> : <?= htmlspecialchars($a['ip_address'] ?: t('dash')) ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="asset-number"><?= htmlspecialchars($a['asset_number']) ?></div>
            </div>
        <?php endforeach; ?>
        <?php if (count($pair) < 2): ?>
            <div class="label-empty"></div>
        <?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div>
    <div class="no-print">
        Ukuran kertas/gap: 7,5cm x 4,5cm (tidak berubah) — berisi 2 label @ 7,5cm x 2,2cm disusun ke bawah.
        Saat dialog cetak muncul, pilih ukuran kertas custom <b>75mm x 45mm</b> dan margin <b>none/0</b>.<br>
        <?= htmlspecialchars(t('scan_label_note')) ?>: <b><?= htmlspecialchars(scanAssetUrl($assets[0]['asset_number'])) ?></b><br>
        <button onclick="window.print()"><?= t('btn_print_again') ?></button>
    </div>
</body>
</html>
