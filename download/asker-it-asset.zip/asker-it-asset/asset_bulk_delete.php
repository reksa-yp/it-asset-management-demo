<?php
/**
 * Hapus beberapa aset sekaligus, dipanggil dari form checkbox di assets.php.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdminOrQme();   // admin, atau user QME (khusus aset Tablet)

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: assets.php');
    exit;
}
csrfCheck();

$rawIds = $_POST['ids'] ?? [];
$ids = array_values(array_unique(array_filter(
    array_map('intval', (array)$rawIds),
    fn($v) => $v > 0
)));

if ($ids) {
    qmeAssertTabletAssets(getDB(), $ids);   // user QME: hanya tablet
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = getDB()->prepare("DELETE FROM assets WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    deleteTabletDetails(getDB(), $ids); // hapus juga detail tablet (jika ada)
    deleteExtNumbers(getDB(), $ids);    // hapus juga Nomor Ext (jika ada)
    deleteCctvAssetData(getDB(), $ids);
    deleteNvrAssets(getDB(), $ids);   // aset NVR -> NVR di menu CCTV ikut dihapus
    $_SESSION['asset_bulk_msg'] = ['ok' => true, 'text' => count($ids) . ' aset berhasil dihapus.'];
} else {
    $_SESSION['asset_bulk_msg'] = ['ok' => false, 'text' => 'Tidak ada aset yang dipilih untuk dihapus.'];
}

header('Location: assets.php');
exit;
