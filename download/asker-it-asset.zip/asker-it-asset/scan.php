<?php
/**
 * Halaman tujuan Scan QR aset: scan.php?no=<Nomor Aset> (isi QR label) atau scan.php?q=<teks hasil scan>.
 *  - Belum login  -> diarahkan ke login, setelah login kembali ke aset yang di-scan.
 *  - Admin        -> detail lengkap aset.
 *  - User biasa   -> hanya aset miliknya (dibuka di menu Aset Saya); aset lain ditolak.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/scan.php';

$number = scanExtractAssetNumber((string)($_GET['no'] ?? ($_GET['q'] ?? '')));

if (empty($_SESSION['user_id'])) {
    if ($number !== '') $_SESSION['after_login'] = 'scan.php?no=' . rawurlencode($number);
    header('Location: login.php');
    exit;
}

$db    = getDB();
$found = scanFindAsset($db, $number);
$asset = $found ? getAssetForCurrentUser((int)$found['id']) : null;

if ($asset && !isAdmin()) {
    header('Location: my_asset.php?id=' . (int)$asset['id']);
    exit;
}

$history = [];
if ($asset) {
    $h = $db->prepare("
        SELECT t.*, wd.work_detail AS work_detail, wd.asset_check AS asset_check
        FROM tickets t
        LEFT JOIN ticket_work_details wd ON wd.ticket_id = t.id
        WHERE t.asset_id = ? ORDER BY t.created_at DESC
    ");
    $h->execute([$asset['id']]);
    $history = $h->fetchAll();
} else {
    http_response_code(404);
}
$home = isAdmin() ? 'assets.php' : 'my_asset.php';
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars(t('scan_title')) ?><?= $asset ? ' ' . htmlspecialchars($asset['asset_number']) : '' ?></title>
<?= appFaviconTag() ?>
<style>
    body { margin: 0; background: #f1f5f9; font-family: Arial, sans-serif; color: #222; }
    .scan-bar { background: #1e293b; color: #fff; padding: 10px 14px; display: flex; flex-wrap: wrap; gap: 8px; align-items: center; justify-content: space-between; }
    .scan-bar b { font-size: 14px; }
    .scan-bar a { color: #fff; text-decoration: none; font-size: 13px; border: 1px solid rgba(255,255,255,.35); border-radius: 6px; padding: 6px 10px; display: inline-block; }
    .scan-bar a.primary { background: #2563eb; border-color: #2563eb; }
    .scan-card { background: #fff; margin: 12px auto; padding: 16px; max-width: 760px; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,.08); overflow-x: auto; }
    .scan-empty { text-align: center; padding: 40px 16px; }
    .scan-empty h2 { margin: 0 0 8px; font-size: 18px; }
    .scan-empty p { margin: 0 0 4px; color: #555; font-size: 14px; }
    .scan-empty code { background: #f1f5f9; padding: 2px 6px; border-radius: 4px; word-break: break-all; }
    @media (max-width: 800px) { .scan-card { margin: 8px; } }
</style>
</head>
<body>
    <div class="scan-bar">
        <b><?= htmlspecialchars(t('scan_title')) ?></b>
        <span>
            <?php if ($asset): ?>
                <a class="primary" href="assets.php?q=<?= urlencode($asset['asset_number']) ?>"><?= htmlspecialchars(t('scan_open_in_list')) ?></a>
                <a href="asset_detail_print.php?id=<?= (int)$asset['id'] ?>" target="_blank" rel="noopener"><?= htmlspecialchars(t('scan_print_detail')) ?></a>
            <?php endif; ?>
            <a href="<?= $home ?>"><?= htmlspecialchars(t('scan_back')) ?></a>
        </span>
    </div>
    <div class="scan-card">
    <?php if ($asset): ?>
        <?php require __DIR__ . '/includes/asset_detail_template.php'; ?>
    <?php else: ?>
        <div class="scan-empty">
            <h2><?= htmlspecialchars(t('scan_not_found_title')) ?></h2>
            <p><?= htmlspecialchars(t('access_denied_asset')) ?></p>
            <?php if ($number !== ''): ?><p><?= htmlspecialchars(t('scan_result_label')) ?>: <code><?= htmlspecialchars($number) ?></code></p><?php endif; ?>
        </div>
    <?php endif; ?>
    </div>
</body>
</html>
