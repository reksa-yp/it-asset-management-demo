<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
require_once __DIR__ . '/includes/request_feature.php';
function requestUi(string $id, string $en): string { return currentLang() === 'en' ? $en : $id; }

$db = getDB();
ensureRequestTable($db);
$admin = isAdmin();
$currentUserStmt = $db->prepare("SELECT id, full_name, department FROM users WHERE id=? LIMIT 1");
$currentUserStmt->execute([(int)$_SESSION['user_id']]);
$currentUser = $currentUserStmt->fetch(PDO::FETCH_ASSOC) ?: [];
if ($admin) {
    $users = $db->query("SELECT id, full_name, department, username FROM users WHERE is_active=1 ORDER BY full_name")->fetchAll();
    $stmt = $db->query("SELECT r.*, COALESCE(r.target_manual_name, u.full_name) AS full_name, COALESCE(r.target_manual_department, u.department) AS department, su.full_name AS submitter_name FROM user_requests r LEFT JOIN users u ON u.id=r.user_id LEFT JOIN users su ON su.id=r.submitted_by_user_id ORDER BY r.created_at DESC");
} else {
    $sameDept = $db->prepare("SELECT id, full_name, department FROM users WHERE is_active=1 AND (id=? OR (department IS NOT NULL AND department <> '' AND department=?)) ORDER BY full_name");
    $sameDept->execute([(int)$_SESSION['user_id'], $currentUser['department'] ?? null]);
    $users = $sameDept->fetchAll(PDO::FETCH_ASSOC);
    $stmt = $db->prepare("SELECT r.*, COALESCE(r.target_manual_name, u.full_name) AS full_name, COALESCE(r.target_manual_department, u.department) AS department, su.full_name AS submitter_name FROM user_requests r LEFT JOIN users u ON u.id=r.user_id LEFT JOIN users su ON su.id=r.submitted_by_user_id WHERE r.user_id=? OR r.submitted_by_user_id=? ORDER BY r.created_at DESC");
    $stmt->execute([(int)$_SESSION['user_id'], (int)$_SESSION['user_id']]);
}
$requests = $stmt->fetchAll();
if (function_exists("requestEnsureEnglish")) requestEnsureEnglish($db, $requests);
$view = (string)($_GET['view'] ?? ($admin ? 'all' : 'new'));
if (!in_array($view, ['new','all','pending','approved','rejected'], true)) $view = $admin ? 'all' : 'new';
if (!$admin && !in_array($view, ['new','all'], true)) $view = 'all';
$q = trim((string)($_GET['q'] ?? ''));
$fcat = (string)($_GET['cat'] ?? '');
if (!in_array($fcat, ['Aksesoris','Desktop PC','Laptop','Lainnya'], true)) $fcat = '';
$reqCounts = ['all' => count($requests),
    'pending'  => count(array_filter($requests, fn($r) => $r['status'] === 'Menunggu')),
    'approved' => count(array_filter($requests, fn($r) => in_array($r['status'], ['Disetujui','Selesai'], true))),
    'rejected' => count(array_filter($requests, fn($r) => $r['status'] === 'Ditolak'))];
if ($admin) {
    if ($view === 'pending') $requests = array_values(array_filter($requests, fn($r) => $r['status'] === 'Menunggu'));
    elseif ($view === 'approved') $requests = array_values(array_filter($requests, fn($r) => in_array($r['status'], ['Disetujui','Selesai'], true)));
    elseif ($view === 'rejected') $requests = array_values(array_filter($requests, fn($r) => $r['status'] === 'Ditolak'));
}
if ($q !== '' || $fcat !== '') {
    $needle = mb_strtolower($q);
    $requests = array_values(array_filter($requests, function ($r) use ($needle, $fcat) {
        if ($fcat !== '' && ($r['category'] ?? '') !== $fcat) return false;
        if ($needle === '') return true;
        $hay = mb_strtolower(implode(' ', [$r['request_number'] ?? '', $r['full_name'] ?? '', $r['department'] ?? '', $r['submitter_name'] ?? '', $r['category'] ?? '', $r['item_description'] ?? '', $r['item_description_en'] ?? '', $r['reason'] ?? '', $r['reason_en'] ?? '']));
        return strpos($hay, $needle) !== false;
    }));
}
$flash = $_SESSION['request_flash'] ?? null; unset($_SESSION['request_flash']);
$pageTitle = requestUi('Pengajuan Khusus', 'Special Requests');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5">
  <div><h1 class="text-2xl font-bold text-slate-800"><?= requestUi('Pengajuan Khusus','Special Requests') ?></h1><p class="text-sm text-slate-500 mt-1"><?= requestUi('Ajukan perangkat baru atau penggantian barang kepada tim IT.','Request new equipment or replacement items from the IT team.') ?></p></div>
  <span class="inline-flex items-center gap-2 rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm text-slate-600"><?= icon('file-text', 'w-4 h-4') ?> <?= count($requests) ?> <?= requestUi('pengajuan','requests') ?></span>
</div>
<nav class="flex gap-1 overflow-x-auto border-b border-slate-200 mb-5 print:hidden" aria-label="Pengajuan">
  <?php foreach ($admin ? [
      'new'      => [requestUi('Buat Pengajuan','New Request'), 'plus'],
      'all'      => [requestUi('Semua Pengajuan','All Requests'), 'file-text'],
      'pending'  => [requestUi('Menunggu','Pending'), 'clock'],
      'approved' => [requestUi('Pengajuan Disetujui','Approved Requests'), 'check-circle'],
      'rejected' => [requestUi('Pengajuan Ditolak','Rejected Requests'), 'x-circle'],
  ] : [
      'new'      => [requestUi('Buat Pengajuan','New Request'), 'plus'],
      'all'      => [requestUi('Riwayat Saya','My Requests'), 'file-text'],
  ] as $key => $tab): $on = $view === $key; ?>
    <a href="request.php?view=<?= urlencode($key) ?>" class="inline-flex items-center gap-2 px-4 py-2.5 text-sm whitespace-nowrap border-b-2 -mb-px <?= $on ? 'border-blue-600 text-blue-700 font-semibold' : 'border-transparent text-slate-500 hover:text-slate-700' ?>">
      <?= icon($tab[1], 'w-4 h-4') ?> <?= htmlspecialchars($tab[0]) ?>
      <?php if ($key !== 'new'): ?><span class="text-xs rounded-full px-1.5 py-0.5 <?= $on ? 'bg-blue-50 text-blue-700' : 'bg-slate-100 text-slate-500' ?>"><?= (int)$reqCounts[$key] ?></span><?php endif; ?>
    </a>
  <?php endforeach; ?>
</nav>
<?php if ($flash): ?>
<div class="rounded-lg border px-4 py-3 mb-4 text-sm <?= $flash['type']==='success' ? 'border-green-200 bg-green-50 text-green-700' : 'border-red-200 bg-red-50 text-red-700' ?>"><?= htmlspecialchars($flash['message']) ?></div>
<?php endif; ?>

<?php if ($view === 'new'): ?>
<section class="bg-white rounded-xl shadow-sm border border-slate-200 p-4 sm:p-6 mb-6">
  <div class="flex items-center gap-2 mb-4"><span class="flex items-center justify-center w-9 h-9 rounded-lg bg-brand-50 text-brand-600"><?= icon('plus', 'w-5 h-5') ?></span><div><h2 class="font-semibold text-slate-800"><?= requestUi('Buat Pengajuan','Create Request') ?></h2><p class="text-xs text-slate-500"><?= requestUi('Isi detail kebutuhan dan alasan pengajuan Anda.','Enter the requested item details and reason.') ?></p></div></div>
  <form method="post" action="request_save.php" enctype="multipart/form-data" id="requestForm" class="grid gap-4 text-sm">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken()) ?>">
    <input type="hidden" name="item_description_en" id="itemDescriptionEn">
    <input type="hidden" name="reason_en" id="requestReasonEn">
    <?php if ($admin || count($users) > 1): ?>
    <div><label for="requestUser" class="block mb-1.5 font-medium text-slate-700">Ajukan Untuk <span class="text-red-500">*</span></label>
      <select id="requestUser" name="target_user_id" required class="w-full border border-slate-300 rounded-lg px-3 py-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500">
        <option value="<?= (int)$_SESSION['user_id'] ?>"><?= requestUi('Saya sendiri — ','Myself — ') ?><?= htmlspecialchars($_SESSION['full_name'] ?? 'Admin') ?></option>
        <?php foreach ($users as $u): if ((int)$u['id'] === (int)$_SESSION['user_id']) continue; ?>
        <option value="<?= (int)$u['id'] ?>"><?= htmlspecialchars($u['full_name']) ?><?= !empty($u['department']) ? ' — '.htmlspecialchars($u['department']) : '' ?></option>
        <?php endforeach; ?>
        <option value="manual"><?= requestUi('Orang baru — belum memiliki akun','New person — no account yet') ?></option>
      </select><p class="text-xs text-slate-500 mt-1"><?= $admin ? requestUi('Admin dapat membuat pengajuan untuk dirinya sendiri atau user lain.','Admins can submit requests for themselves or other users.') : requestUi('Anda dapat mewakili user aktif dalam departemen yang sama. Pengajuan akan tercatat atas nama user yang dipilih dan juga muncul di riwayat Anda.','You can submit on behalf of an active user in the same department. The request will be recorded under the selected user and appear in your history.') ?></p>
    </div>
    <div id="manualTargetFields" class="hidden grid gap-4 md:grid-cols-2 rounded-lg border border-slate-200 bg-slate-50 p-4">
      <div><label for="manualTargetName" class="block mb-1.5 font-medium text-slate-700"><?= requestUi('Nama orang yang diajukan','Requested person name') ?> <span class="text-red-500">*</span></label><input id="manualTargetName" name="target_manual_name" maxlength="190" class="w-full border border-slate-300 rounded-lg px-3 py-2.5" placeholder="<?= htmlspecialchars(requestUi('Masukkan nama lengkap', 'Enter full name')) ?>"></div>
      <div><label for="manualTargetDepartment" class="block mb-1.5 font-medium text-slate-700"><?= requestUi('Departemen','Department') ?> <span class="text-red-500">*</span></label><input id="manualTargetDepartment" name="target_manual_department" maxlength="120" class="w-full border border-slate-300 rounded-lg px-3 py-2.5" placeholder="<?= htmlspecialchars(requestUi('Masukkan departemen', 'Enter department')) ?>"></div>
      <p class="md:col-span-2 text-xs text-slate-500"><?= requestUi('Untuk orang baru yang belum memiliki akun. Pengajuan tetap tercatat atas nama Anda sebagai pengaju.','For a new person who does not have an account yet. The request will still record you as the submitter.') ?></p>
    </div>
    <?php endif; ?>
    <div class="grid gap-4 md:grid-cols-2">
      <div><label for="requestType" class="block mb-1.5 font-medium text-slate-700"><?= requestUi('Jenis Pengajuan','Request Type') ?> <span class="text-red-500">*</span></label>
        <select id="requestType" name="request_type" required class="w-full border border-slate-300 rounded-lg px-3 py-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500">
          <option value="Baru"><?= requestUi('Pengajuan Baru','New Request') ?></option><option value="Penggantian"><?= requestUi('Penggantian Barang','Item Replacement') ?></option>
        </select>
      </div>
      <div><label for="requestCategory" class="block mb-1.5 font-medium text-slate-700"><?= requestUi('Kategori','Category') ?> <span class="text-red-500">*</span></label>
        <select id="requestCategory" name="category" required class="w-full border border-slate-300 rounded-lg px-3 py-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500">
          <option value="Aksesoris"><?= requestUi('Aksesoris','Accessories') ?></option><option value="Desktop PC">Desktop PC</option><option value="Laptop">Laptop</option><option value="Lainnya"><?= requestUi('Lainnya','Other') ?></option>
        </select>
      </div>
    </div>
    <div><label for="itemDescription" class="block mb-1.5 font-medium text-slate-700"><?= requestUi('Detail Pengajuan','Request Details') ?> <span class="text-red-500">*</span></label>
      <textarea id="itemDescription" name="item_description" rows="3" required maxlength="5000" class="w-full border border-slate-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500" placeholder="<?= htmlspecialchars(requestUi('Tuliskan barang/spesifikasi yang diajukan secara bebas, misalnya nama barang, tipe, jumlah, atau kebutuhan khusus.', 'Describe the requested item/specifications, such as item name, model, quantity, or special requirements.')) ?>"></textarea>
    </div>
    <div><label for="requestReason" class="block mb-1.5 font-medium text-slate-700"><?= requestUi('Alasan Pengajuan','Request Reason') ?> <span class="text-red-500">*</span></label>
      <textarea id="requestReason" name="reason" rows="3" required maxlength="5000" class="w-full border border-slate-300 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500" placeholder="<?= htmlspecialchars(requestUi('Jelaskan alasan dan kebutuhan pengajuan ini.', 'Explain the reason and need for this request.')) ?>"></textarea>
    </div>
    <div id="replacementImageSection" class="hidden rounded-lg border border-dashed border-slate-300 bg-slate-50 p-4">
      <label class="block mb-1.5 font-medium text-slate-700"><?= requestUi('Foto Barang yang Ingin Diganti','Photo of Item to Be Replaced') ?> <span class="text-red-500">*</span></label>
      <p class="text-xs text-slate-500 mb-3"><?= requestUi('Wajib untuk penggantian. Maksimal 8 MB; foto dapat diambil langsung, diunggah, atau ditempel dari screenshot yang sudah disalin.','Required for replacements. Maximum 8 MB; take a photo, upload an image, or paste a copied screenshot.') ?></p>
      <div class="flex flex-wrap gap-2 mb-3">
        <label class="inline-flex items-center gap-2 cursor-pointer rounded-lg border border-slate-300 bg-white px-3 py-2 hover:bg-slate-50 font-medium"><?= icon('camera','w-4 h-4') ?> <?= requestUi('Foto langsung','Take Photo') ?>
          <input id="cameraImage" type="file" accept="image/*" capture="environment" class="hidden">
        </label>
        <label class="inline-flex items-center gap-2 cursor-pointer rounded-lg border border-slate-300 bg-white px-3 py-2 hover:bg-slate-50 font-medium"><?= icon('file-text','w-4 h-4') ?> <?= requestUi('Unggah gambar','Upload Image') ?>
          <input id="requestImage" name="request_image" type="file" accept="image/*" class="hidden">
        </label>
      </div>
      <div id="pasteZone" tabindex="0" class="rounded-lg border border-slate-200 bg-white px-3 py-4 text-center text-sm text-slate-500 outline-none focus:ring-2 focus:ring-brand-500"><?= requestUi('Klik area ini lalu tekan','Click this area, then press') ?> <kbd class="rounded border px-1.5 py-0.5 bg-slate-50">Ctrl + V</kbd> <?= requestUi('untuk paste screenshot.','to paste a screenshot.') ?></div>
      <div id="imagePreviewWrap" class="hidden mt-3 flex items-start gap-3"><img id="imagePreview" alt="Pratinjau gambar penggantian" class="max-h-44 max-w-full rounded-lg border border-slate-200 object-contain"><div class="min-w-0"><p id="imageFileName" class="text-xs text-slate-600 break-all"></p><button type="button" id="removeImage" class="mt-2 text-xs font-medium text-red-600 hover:text-red-700"><?= requestUi('Hapus gambar','Remove image') ?></button></div></div>
    </div>
    <div class="flex flex-wrap items-center gap-2"><button type="button" id="translateRequestBtn" class="inline-flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 font-medium text-blue-700 hover:bg-blue-100"><?= icon('globe','w-4 h-4') ?> <?= requestUi('Translate to English','Translate to English') ?></button><span id="translateRequestStatus" class="text-xs text-slate-500"><?= requestUi('Terjemahkan detail dan alasan sebelum mengirim. Teks asli tetap tersimpan.','Translate details and reason before submitting. Original text will be preserved.') ?></span></div>
    <div class="flex justify-end pt-1" style="display:flex;justify-content:flex-end;padding-top:4px"><button type="submit" id="requestSubmitBtn" style="background:#1F3DD1;color:#fff;border:0;border-radius:8px;padding:10px 22px;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:8px;box-shadow:0 1px 2px rgba(0,0,0,.15)"><?= icon('arrow-right','w-4 h-4') ?> <?= requestUi('Kirim Pengajuan','Submit Request') ?></button></div>
  </form>
</section>
<?php else: ?>

<section class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
  <div class="px-4 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3"><div><h2 class="font-semibold text-slate-800"><?= $admin ? (['approved'=>requestUi('Pengajuan Disetujui','Approved Requests'),'rejected'=>requestUi('Detail Pengajuan Ditolak','Rejected Request Details'),'pending'=>requestUi('Pengajuan Menunggu','Pending Requests')][$view] ?? requestUi('Daftar Pengajuan User','User Request List')) : requestUi('Riwayat Pengajuan Saya','My Request History') ?></h2><p class="text-xs text-slate-500 mt-1"><?= $admin ? (['approved'=>requestUi('Pengajuan yang disetujui dan sedang/akan diproses untuk pembelian atau penggantian.','Approved requests being processed for purchase or replacement.'),'rejected'=>requestUi('Pengajuan ditolak. Status Ditolak menandakan pengajuan sudah ditutup dan tidak diproses lebih lanjut.','Rejected requests are closed and will not be processed further.'),'pending'=>requestUi('Pengajuan yang masih menunggu keputusan admin.','Requests awaiting an admin decision.')][$view] ?? requestUi('Seluruh pengajuan yang masuk dari pengguna.','All requests submitted by users.')) : requestUi('Pantau status pengajuan yang pernah Anda kirim.','Track the status of requests you have submitted.') ?></p></div><a href="request_print.php" target="_blank" class="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"> <?= icon('printer','w-4 h-4') ?> <?= requestUi('Cetak Riwayat','Print History') ?></a></div>
  <div class="px-4 py-3 border-b border-slate-200 flex flex-wrap items-center gap-2 print:hidden">
    <form method="get" action="request.php" class="flex flex-wrap items-center gap-2 flex-1 min-w-0">
      <input type="hidden" name="view" value="<?= htmlspecialchars($view) ?>">
      <input type="search" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="<?= htmlspecialchars(requestUi('Cari nomor, nama, departemen, detail, alasan...','Search number, name, department, details, reason...')) ?>" class="border border-slate-300 rounded-lg px-3 py-2 text-sm w-full sm:w-80">
      <select name="cat" class="border border-slate-300 rounded-lg px-3 py-2 text-sm bg-white">
        <option value=""><?= requestUi('Semua kategori','All categories') ?></option>
        <?php foreach (['Aksesoris','Desktop PC','Laptop','Lainnya'] as $c): ?><option value="<?= $c ?>" <?= $fcat === $c ? 'selected' : '' ?>><?= $c ?></option><?php endforeach; ?>
      </select>
      <button class="rounded-lg bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 text-sm font-medium"><?= requestUi('Cari','Search') ?></button>
      <?php if ($q !== '' || $fcat !== ''): ?><a href="request.php?view=<?= urlencode($view) ?>" class="text-sm text-slate-500 hover:text-slate-700"><?= requestUi('Reset','Reset') ?></a><?php endif; ?>
      <span class="text-xs text-slate-500"><?= count($requests) ?> <?= requestUi('pengajuan','requests') ?></span>
    </form>
  </div>
  <?php if ($admin): ?>
  <form id="bulkForm" method="post" action="request_bulk.php" class="hidden">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken()) ?>">
    <input type="hidden" name="action" id="bulkAction" value="">
    <input type="hidden" name="status" id="bulkStatusVal" value="">
    <input type="hidden" name="return_view" value="<?= htmlspecialchars($view) ?>">
    <input type="hidden" name="return_q" value="<?= htmlspecialchars($q) ?>">
    <input type="hidden" name="return_cat" value="<?= htmlspecialchars($fcat) ?>">
  </form>
  <div id="bulkBar" class="hidden flex-wrap items-center gap-2 px-4 py-2 border-b border-blue-200 bg-blue-50 text-sm print:hidden">
    <span><b id="bulkCount">0</b> <?= requestUi('terpilih','selected') ?></span>
    <select id="bulkStatus" class="border border-slate-300 rounded-lg px-2 py-1.5 text-sm bg-white"><option value=""><?= requestUi('Ubah status…','Change status…') ?></option><?php foreach (['Menunggu'=>requestUi('Menunggu','Pending'),'Disetujui'=>requestUi('Disetujui','Approved'),'Ditolak'=>requestUi('Ditolak','Rejected'),'Selesai'=>requestUi('Selesai','Completed')] as $k=>$l): ?><option value="<?= $k ?>"><?= $l ?></option><?php endforeach; ?></select>
    <button type="button" onclick="bulkApply()" class="rounded-lg bg-blue-600 text-white px-3 py-1.5 font-medium"><?= requestUi('Terapkan','Apply') ?></button>
    <button type="button" onclick="bulkDelete()" class="rounded-lg border border-red-200 bg-white text-red-600 px-3 py-1.5 font-medium hover:bg-red-50"><?= requestUi('Hapus terpilih','Delete selected') ?></button>
    <button type="button" onclick="bulkClear()" class="text-slate-500 hover:text-slate-700"><?= requestUi('Batal pilih','Clear') ?></button>
  </div>
  <?php endif; ?>
  <?php if (!$requests): ?><div class="p-8 text-center text-sm text-slate-500"><?= ($q !== '' || $fcat !== '') ? requestUi('Tidak ada pengajuan yang cocok dengan pencarian.','No requests match your search.') : requestUi('Belum ada pengajuan.','No requests yet.') ?></div>
  <?php else: ?>
  <div class="overflow-x-auto"><table class="w-full text-sm text-left"><thead class="bg-slate-50 text-slate-500 text-xs uppercase"><tr><?php if($admin): ?><th class="px-4 py-3 w-8"><input type="checkbox" id="selAll" title="<?= htmlspecialchars(requestUi('Pilih semua','Select all')) ?>"></th><?php endif; ?><th class="px-4 py-3"><?= requestUi('Nomor / Tanggal','Number / Date') ?></th><?php if($admin): ?><th class="px-4 py-3"><?= requestUi('Pengguna','User') ?></th><?php endif; ?><th class="px-4 py-3"><?= requestUi('Jenis / Kategori','Type / Category') ?></th><th class="px-4 py-3"><?= requestUi('Detail & Alasan','Details & Reason') ?></th><th class="px-4 py-3"><?= requestUi('Lampiran','Attachment') ?></th><th class="px-4 py-3"><?= requestUi('Status','Status') ?></th></tr></thead><tbody class="divide-y divide-slate-100">
  <?php foreach($requests as $r): $statusClass = $r['status']==='Disetujui' || $r['status']==='Selesai' ? 'bg-green-100 text-green-700' : ($r['status']==='Ditolak' ? 'bg-red-100 text-red-700' : ($r['status']==='Dibatalkan' ? 'bg-slate-100 text-slate-600' : 'bg-amber-100 text-amber-700')); ?>
  <tr class="hover:bg-slate-50 align-top"><?php if($admin): ?><td class="px-4 py-3"><input type="checkbox" class="row-chk" name="ids[]" value="<?= (int)$r['id'] ?>" form="bulkForm"></td><?php endif; ?><td class="px-4 py-3 whitespace-nowrap"><div class="font-semibold text-slate-800"><?= htmlspecialchars($r['request_number']) ?></div><div class="text-xs text-slate-500 mt-1"><?= htmlspecialchars(date('d M Y H:i', strtotime($r['created_at']))) ?></div></td>
  <?php if($admin): ?><td class="px-4 py-3"><div class="font-medium"><?= htmlspecialchars($r['full_name']) ?></div><div class="text-xs text-slate-500"><?= htmlspecialchars($r['department'] ?? '') ?></div><?php if(!empty($r['submitter_name']) && $r['submitter_name'] !== $r['full_name']): ?><div class="text-xs text-brand-600 mt-1"><?= requestUi('Diajukan oleh','Submitted by') ?> <?= htmlspecialchars($r['submitter_name']) ?></div><?php endif; ?></td><?php endif; ?>
  <td class="px-4 py-3"><div class="font-medium"><?= htmlspecialchars(requestUi($r['request_type'], ['Baru'=>'New','Penggantian'=>'Replacement'][$r['request_type']] ?? $r['request_type'])) ?></div><div class="text-slate-500"><?= htmlspecialchars(requestUi($r['category'], ['Aksesoris'=>'Accessories','Lainnya'=>'Other'][$r['category']] ?? $r['category'])) ?></div></td>
  <td class="px-4 py-3 min-w-56 max-w-md"><div class="font-medium whitespace-pre-wrap break-words" data-auto-translate><?= htmlspecialchars(currentLang()==='en' && !empty($r['item_description_en']) ? $r['item_description_en'] : $r['item_description']) ?></div><div class="mt-2 text-xs text-slate-500"><?= requestUi('Alasan:','Reason:') ?> <span class="whitespace-pre-wrap" data-auto-translate><?= htmlspecialchars(currentLang()==='en' && !empty($r['reason_en']) ? $r['reason_en'] : $r['reason']) ?></span></div></td>
  <td class="px-4 py-3"><?php if($r['image_path']): ?><a class="inline-flex items-center gap-1 text-brand-600 hover:underline" target="_blank" rel="noopener" href="<?= htmlspecialchars($r['image_path']) ?>"><?= icon('file-text','w-4 h-4') ?> <?= requestUi('Lihat foto','View photo') ?></a><?php else: ?><span class="text-slate-400">—</span><?php endif; ?></td>
  <td class="px-4 py-3"><span class="inline-flex rounded-full px-2.5 py-1 text-xs font-semibold <?= $statusClass ?>"><?= htmlspecialchars(requestUi($r['status'], ['Menunggu'=>'Pending','Disetujui'=>'Approved','Ditolak'=>'Rejected','Selesai'=>'Completed','Dibatalkan'=>'Cancelled'][$r['status']] ?? $r['status'])) ?></span><?php if(!empty($r['admin_note'])): ?><p class="text-xs text-slate-500 mt-2" data-auto-translate><?= htmlspecialchars(currentLang()==='en' && !empty($r['admin_note_en']) ? $r['admin_note_en'] : $r['admin_note']) ?></p><?php endif; ?>
  <?php if($admin): ?><form method="post" action="request_update.php" class="mt-3 grid gap-2 min-w-40"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken()) ?>"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="return_view" value="<?= htmlspecialchars($view) ?>"><select name="status" class="w-full border border-slate-300 rounded-md px-2 py-1.5 text-xs"><option <?= $r['status']==='Menunggu'?'selected':'' ?>><?= requestUi('Menunggu','Pending') ?></option><option <?= $r['status']==='Disetujui'?'selected':'' ?>><?= requestUi('Disetujui','Approved') ?></option><option <?= $r['status']==='Ditolak'?'selected':'' ?>><?= requestUi('Ditolak','Rejected') ?></option><option <?= $r['status']==='Selesai'?'selected':'' ?>><?= requestUi('Selesai','Completed') ?></option></select><textarea name="admin_note" rows="2" maxlength="3000" placeholder="<?= htmlspecialchars(requestUi('Catatan admin (opsional)', 'Admin note (optional)')) ?>" class="w-full border border-slate-300 rounded-md px-2 py-1.5 text-xs"><?= htmlspecialchars(currentLang()==='en' && !empty($r['admin_note_en']) ? $r['admin_note_en'] : ($r['admin_note'] ?? '')) ?></textarea><button class="rounded-md bg-brand-600 text-white px-2 py-1.5 text-xs font-semibold hover:bg-brand-700"><?= requestUi('Simpan Status','Save Status') ?></button></form><?php endif; ?>
  <?php if($r['status']==='Menunggu'): ?><form method="post" action="request_cancel.php" class="mt-2" onsubmit="return confirm(<?= json_encode(requestUi('Batalkan pengajuan ini? Tindakan ini tidak dapat dibatalkan.','Cancel this request? This action cannot be undone.')) ?>);"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken()) ?>"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button type="submit" class="inline-flex items-center gap-1 rounded-md border border-red-200 px-2 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50"><?= icon('x-circle','w-3.5 h-3.5') ?> Batalkan pengajuan</button></form><?php endif; ?>
  <a href="request_print.php?id=<?= (int)$r['id'] ?>" target="_blank" class="mt-2 inline-flex items-center gap-1 text-xs font-medium text-brand-600 hover:underline"><?= icon('printer','w-3.5 h-3.5') ?> <?= requestUi('Cetak detail','Print details') ?></a><?php if($admin): ?><form method="post" action="request_bulk.php" class="mt-2" onsubmit="return confirm(<?= json_encode(requestUi('Hapus pengajuan ini secara permanen?','Permanently delete this request?')) ?>);"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="ids[]" value="<?= (int)$r['id'] ?>"><input type="hidden" name="return_view" value="<?= htmlspecialchars($view) ?>"><input type="hidden" name="return_q" value="<?= htmlspecialchars($q) ?>"><input type="hidden" name="return_cat" value="<?= htmlspecialchars($fcat) ?>"><button type="submit" class="inline-flex items-center gap-1 rounded-md border border-red-200 px-2 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50"><?= icon('trash','w-3.5 h-3.5') ?> <?= requestUi('Hapus','Delete') ?></button></form><?php endif; ?></td></tr>
  <?php endforeach; ?>
  </tbody></table></div>
  <?php endif; ?>
</section>
<?php endif; ?>
<script>
(() => {
 const targetSelect = document.getElementById('requestUser');
 const manualFields = document.getElementById('manualTargetFields');
 const manualName = document.getElementById('manualTargetName');
 const manualDept = document.getElementById('manualTargetDepartment');
 function updateManualTarget() {
   if (!targetSelect || !manualFields) return;
   const manual = targetSelect.value === 'manual';
   manualFields.classList.toggle('hidden', !manual);
   manualName.required = manual;
   manualDept.required = manual;
 }
 if (targetSelect) { targetSelect.addEventListener('change', updateManualTarget); updateManualTarget(); }
 const type = document.getElementById('requestType');
 const hasForm = !!type;
 const section = document.getElementById('replacementImageSection');
 const file = document.getElementById('requestImage');
 const camera = document.getElementById('cameraImage');
 const zone = document.getElementById('pasteZone');
 const previewWrap = document.getElementById('imagePreviewWrap');
 const preview = document.getElementById('imagePreview');
 const fileName = document.getElementById('imageFileName');
 const form = document.getElementById('requestForm');
 async function translateText(text) {
   const res = await fetch('request_translate.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'}, body:new URLSearchParams({csrf_token:<?= json_encode(csrfToken()) ?>, text:text})});
   const data = await res.json(); if (!res.ok || !data.ok) throw new Error(data.error || 'Translation failed'); return data.translatedText;
 }
 const langIsEnglish = document.documentElement.lang === 'en';
 const originalForm = document.getElementById('requestForm');
 if (originalForm && langIsEnglish) originalForm.addEventListener('submit', async e => {
   if (originalForm.dataset.translated === '1') return;
   e.preventDefault();
   const desc = document.getElementById('itemDescription').value.trim(); const reason = document.getElementById('requestReason').value.trim();
   if (!desc || !reason) { originalForm.reportValidity(); return; }
   const submitButton = originalForm.querySelector('button[type="submit"]'); if (submitButton) { submitButton.disabled = true; submitButton.dataset.oldText = submitButton.textContent; submitButton.textContent = 'Translating…'; }
   try { document.getElementById('itemDescriptionEn').value = await translateText(desc); document.getElementById('requestReasonEn').value = await translateText(reason); originalForm.dataset.translated = '1'; originalForm.requestSubmit(); }
   catch(err) { alert('Automatic translation failed. Your original text is preserved. Please check translation settings and try again.'); if (submitButton) { submitButton.disabled = false; submitButton.textContent = submitButton.dataset.oldText || 'Submit'; } }
 });
 if (langIsEnglish) {
   const nodes=[...document.querySelectorAll('[data-auto-translate]')];
   nodes.forEach(el=>{el.dataset.originalText=el.textContent||'';});
   const queue=[]; let running=false;
   async function drain(){ if(running)return; running=true; while(queue.length){const el=queue.shift(); if(!el||!el.isConnected||el.dataset.translated==='1')continue; const source=(el.dataset.originalText||el.textContent||'').trim(); if(!source||/^[\d\W_]+$/.test(source)){el.dataset.translated='1';continue;} try{const translated=await translateText(source);el.textContent=translated;el.dataset.translated='1';el.title='Automatically translated to English';}catch(e){el.title='Translation unavailable; original text is shown. '+(e.message||'');} await new Promise(resolve=>setTimeout(resolve,180));} running=false;}
   if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){observer.unobserve(entry.target);queue.push(entry.target);}});drain();},{rootMargin:'160px 0px'});nodes.forEach(el=>observer.observe(el));}else{queue.push(...nodes.slice(0,12));drain();}
 }
 document.querySelectorAll('.admin-note-source').forEach(source => source.addEventListener('input', () => { const hidden=source.closest('form').querySelector('.admin-note-en'); if(hidden) hidden.value=''; }));
 document.querySelectorAll('.translate-note-btn').forEach(btn => btn.addEventListener('click', async () => { const form=btn.closest('form'); const source=form.querySelector('.admin-note-source'); const hidden=form.querySelector('.admin-note-en'); if(!source.value.trim()){alert(<?= json_encode(requestUi('Isi catatan terlebih dahulu.','Enter a note first.')) ?>);return;} btn.disabled=true; try{hidden.value=await translateText(source.value.trim()); alert(<?= json_encode(requestUi('Terjemahan catatan siap disimpan.','Note translation is ready to save.')) ?>);}catch(e){alert(e.message);}finally{btn.disabled=false;} }));
 if (hasForm) {
 let currentFile = null;
 function updateSection() { const replacement = type.value === 'Penggantian'; section.classList.toggle('hidden', !replacement); file.required = replacement && !currentFile; }
 function setFile(f) {
   if (!f || !f.type || !f.type.startsWith('image/')) return;
   if (f.size > 8*1024*1024) { alert(<?= json_encode(requestUi('Ukuran gambar maksimal 8 MB.','Maximum image size is 8 MB.')) ?>); return; }
   currentFile = new File([f], f.name || ('screenshot-' + Date.now() + '.png'), {type:f.type});
   const dt = new DataTransfer(); dt.items.add(currentFile); file.files = dt.files;
   preview.src = URL.createObjectURL(currentFile); fileName.textContent = currentFile.name + ' · ' + Math.round(currentFile.size/1024) + ' KB';
   previewWrap.classList.remove('hidden'); file.required = false;
 }
 type.addEventListener('change', updateSection);
 file.addEventListener('change', () => { if (file.files && file.files[0]) setFile(file.files[0]); });
 camera.addEventListener('change', () => { if (camera.files && camera.files[0]) setFile(camera.files[0]); camera.value=''; });
 zone.addEventListener('click', () => zone.focus());
 zone.addEventListener('paste', e => { const items = e.clipboardData && e.clipboardData.items; if (!items) return; for (const item of items) { if (item.type.startsWith('image/')) { e.preventDefault(); setFile(item.getAsFile()); return; } } });
 document.addEventListener('paste', e => { if (type.value !== 'Penggantian') return; const items=e.clipboardData && e.clipboardData.items; if(!items)return; for(const item of items){if(item.type.startsWith('image/')){setFile(item.getAsFile());break;}} });
 document.getElementById('removeImage').addEventListener('click', () => { currentFile=null; file.value=''; preview.removeAttribute('src'); previewWrap.classList.add('hidden'); updateSection(); });
 form.addEventListener('submit', e => { if(type.value==='Penggantian' && !currentFile && !(file.files && file.files[0])) { e.preventDefault(); alert(<?= json_encode(requestUi('Foto barang wajib dilampirkan untuk pengajuan penggantian.','A photo of the item is required for replacement requests.')) ?>); } });
 updateSection();
 }
})();
</script>
<script>
function bulkRows() { return Array.prototype.slice.call(document.querySelectorAll('.row-chk')); }
function bulkUpdate() {
  var rows = bulkRows(), n = rows.filter(function (x) { return x.checked; }).length;
  var bar = document.getElementById('bulkBar'); if (!bar) return;
  bar.classList.toggle('hidden', n === 0); bar.classList.toggle('flex', n > 0);
  document.getElementById('bulkCount').textContent = n;
  var all = document.getElementById('selAll'); if (all) { all.checked = rows.length > 0 && n === rows.length; all.indeterminate = n > 0 && n < rows.length; }
}
function bulkClear() { bulkRows().forEach(function (x) { x.checked = false; }); bulkUpdate(); }
function bulkSubmit(a, st) { document.getElementById('bulkAction').value = a; document.getElementById('bulkStatusVal').value = st || ''; document.getElementById('bulkForm').submit(); }
function bulkDelete() { var n = bulkRows().filter(function (x) { return x.checked; }).length; if (n && confirm(<?= json_encode(requestUi('Hapus pengajuan terpilih secara permanen?','Permanently delete the selected requests?')) ?>)) bulkSubmit('delete'); }
function bulkApply() { var v = document.getElementById('bulkStatus').value; if (!v) { alert(<?= json_encode(requestUi('Pilih status terlebih dahulu.','Choose a status first.')) ?>); return; } bulkSubmit('status', v); }
document.addEventListener('change', function (e) {
  if (e.target.id === 'selAll') { bulkRows().forEach(function (x) { x.checked = e.target.checked; }); bulkUpdate(); }
  else if (e.target.classList && e.target.classList.contains('row-chk')) bulkUpdate();
});
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
