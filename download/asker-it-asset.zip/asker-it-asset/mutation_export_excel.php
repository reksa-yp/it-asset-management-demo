<?php
/** Export Excel riwayat Mutasi Aset, mengikuti filter aktif di halaman Mutasi Aset. */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/mutation.php';
require_once __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;

$db = getDB();
ensureMutationTable($db);
$f    = mutationFilters();
$rows = getMutations($db, $f);

$headers = [
    t('mut_col_number'), t('th_date'), t('xls_hdr_asset_id'), t('xls_hdr_category'), t('xls_hdr_device_name'),
    t('mut_xls_from_user'), t('mut_xls_from_dept'), t('mut_xls_from_loc'),
    t('mut_xls_to_user'), t('mut_xls_to_dept'), t('mut_xls_to_loc'),
    t('mut_col_reason'), t('mut_col_condition'), t('stock_note'), t('mut_col_by'), t('mut_xls_source'),
];
$srcLabel = ['menu' => t('mut_source_menu'), 'stock' => t('mut_source_stock'), 'asset_form' => t('mut_source_asset_form'), 'damage' => t('mut_source_damage')];

$book  = new Spreadsheet();
$sheet = $book->getActiveSheet();
$sheet->setTitle(mb_substr(str_replace(['[', ']', ':', '*', '?', '/', '\\'], ' ', t('page_title_mutations')), 0, 31));
$lastCol = Coordinate::stringFromColumnIndex(count($headers));
$sheet->setCellValue('A1', t('app_name') . ' — ' . t('mut_report_title'));
$sheet->setCellValue('A2', t('stock_period') . ': ' . ($f['from'] ?: '…') . ' s/d ' . ($f['to'] ?: '…') . '   •   ' . t('printed_at') . ': ' . date('d M Y H:i'));
$sheet->mergeCells("A1:{$lastCol}1");
$sheet->mergeCells("A2:{$lastCol}2");
$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(13);
$sheet->getStyle('A2')->getFont()->setItalic(true)->getColor()->setRGB('64748B');
$sheet->fromArray($headers, null, 'A4');

$r = 5;
foreach ($rows as $m) {
    $vals = [
        $m['mutation_number'], date('Y-m-d', strtotime($m['mutation_date'])), $m['asset_number'], $m['asset_category'], $m['asset_name'],
        mutationPartyLabel($m['from_user_names']), $m['from_department'], $m['from_location'],
        mutationPartyLabel($m['to_user_names']), $m['to_department'], $m['to_location'],
        mutationReasonLabel($m['reason']), mutationConditionLabel($m['asset_condition']), $m['note'], $m['created_by_name'],
        $srcLabel[$m['source']] ?? $m['source'],
    ];
    foreach ($vals as $c => $v) {
        $sheet->setCellValueExplicit(Coordinate::stringFromColumnIndex($c + 1) . $r, (string)$v, DataType::TYPE_STRING);
    }
    $r++;
}
$last = max(4, $r - 1);
$sheet->getStyle("A4:{$lastCol}4")->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
$sheet->getStyle("A4:{$lastCol}4")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
$sheet->getStyle("A4:{$lastCol}{$last}")->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
for ($c = 1; $c <= count($headers); $c++) $sheet->getColumnDimension(Coordinate::stringFromColumnIndex($c))->setAutoSize(true);
$sheet->freezePane('A5');

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="mutasi_aset_' . date('Ymd_His') . '.xlsx"');
header('Cache-Control: max-age=0');
(new Xlsx($book))->save('php://output');
exit;
