<?php
/**
 * Menu CCTV > Checklist: pemeriksaan kamera per shift / per hari (pengganti form kertas).
 * Bisa diisi admin dan user yang diberi "Akses Checklist CCTV" di Management User. Bisa dari HP.
 * Status online/offline terisi otomatis dari monitoring; petugas mencentang item, memberi keterangan & foto.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cctv.php';
requireAdminOrCctv();

$db = getDB();
ensureCctvTables($db);
$h = fn($v) => htmlspecialchars((string)$v);

$shifts = cctvShiftOptions();
$date   = (string)($_REQUEST['date'] ?? date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || $date > date('Y-m-d')) $date = date('Y-m-d');
$shift  = (string)($_REQUEST['shift'] ?? '');
if (!in_array($shift, $shifts, true)) {
    // Tebak shift dari jam sekarang (Pagi sebelum 12:00, Sore sesudahnya; lihat cctvShiftIndexNow).
    $shift = $shifts[max(0, cctvShiftIndexNow($shifts))] ?? $shifts[0];
    // Shift tebakan tidak boleh diisi user ini -> pilih shift pertama yang boleh diisinya.
    if (!cctvCanFillShift($shift)) {
        foreach ($shifts as $sh) if (cctvCanFillShift($sh)) { $shift = $sh; break; }
    }
}
$canFill = cctvCanFillShift($shift);
$offLabel = cctvOffDays($db, $date, $date)[$date] ?? null;   // hari libur: checklist tidak wajib (tetap boleh diisi)

$items = cctvCheckItems($db);
$codes = array_column($items, 'code');
$allCams = cctvCameras($db);
$groups  = cctvNvrGroups($allCams);
// Pilihan NVR yang dicek: default NVR pertama (jika ada lebih dari satu kelompok), atau semua kamera.
$nvrSel = (string)($_REQUEST['nvr'] ?? '');
if ($nvrSel === '' || ($nvrSel !== 'all' && (!ctype_digit($nvrSel) || !isset($groups[(int)$nvrSel])))) $nvrSel = count($groups) > 1 ? (string)array_key_first($groups) : 'all';
$scopeGroups = $nvrSel === 'all' ? $groups : [(int)$nvrSel => $groups[(int)$nvrSel]];
$cams = [];
foreach ($scopeGroups as $g) foreach ($g['cams'] as $c) $cams[] = $c;
$existing = cctvGetChecklist($db, $date, $shift);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    if (!$canFill) {
        $_SESSION['cctv_msg'] = ['ok' => false, 'text' => cL('Checklist shift ', 'Checklist for shift ') . $shift . cL(' diisi oleh: ', ' is filled by: ') . cctvShiftRoleLabel(cctvShiftRole($shift)) . '.'];
        header('Location: cctv_checklist.php?date=' . urlencode($date) . '&shift=' . urlencode($shift));
        exit;
    }
    $marks = (array)($_POST['m'] ?? []);
    $notes = (array)($_POST['note'] ?? []);
    $rows = [];
    $unchecked = [];
    $needNote = [];
    foreach ($cams as $c) {
        $aid = $c['id'];
        $state = cctvCheckMethod($c) === '' ? 'unknown' : $c['state'];
        $m = [];
        foreach ($codes as $code) {
            $v = (int)($marks[$aid][$code] ?? 0);
            if ($v === 1 || $v === 2) $m[$code] = $v;
        }
        $note = mb_substr(trim((string)($notes[$aid] ?? '')), 0, 250);
        if (count($m) < count($codes)) $unchecked[] = $c['name'] ?: ($c['location'] ?: $c['number']);
        if ((in_array(2, $m, true) || in_array($state, ['off', 'vl'], true)) && $note === '') $needNote[] = $c['name'] ?: ($c['location'] ?: $c['number']);
        $rows[$aid] = ['state' => $state, 'marks' => $m, 'note' => $note];
    }
    if ($unchecked) $errors[] = cL('Belum semua item dicek pada: ', 'Not all items checked for: ') . implode(', ', array_slice($unchecked, 0, 8)) . (count($unchecked) > 8 ? ', ...' : '');
    if ($needNote) $errors[] = cL('Isi keterangan untuk kamera bermasalah: ', 'Add a note for cameras with problems: ') . implode(', ', array_slice($needNote, 0, 8)) . (count($needNote) > 8 ? ', ...' : '');

    if (!$errors) {
        $me = currentUser();
        $now = date('Y-m-d H:i:s');
        $db->beginTransaction();
        try {
            if ($existing) {
                $clId = (int)$existing['id'];
                $db->prepare("UPDATE cctv_checklists SET user_id = ?, user_name = ?, updated_at = ? WHERE id = ?")
                   ->execute([(int)$me['id'], (string)$me['full_name'], $now, $clId]);
            } else {
                $db->prepare("INSERT INTO cctv_checklists (check_date, shift, user_id, user_name, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)")
                   ->execute([$date, $shift, (int)$me['id'], (string)$me['full_name'], $now, $now]);
                $clId = (int)$db->lastInsertId();
            }
            // Hanya kamera NVR yang dipilih yang diganti; hasil NVR lain di shift yang sama tetap.
            if ($rows) {
                $ids = array_keys($rows);
                $db->prepare("DELETE FROM cctv_checklist_results WHERE checklist_id = ? AND asset_id IN (" . implode(',', array_fill(0, count($ids), '?')) . ")")
                   ->execute(array_merge([$clId], $ids));
            }
            foreach (array_keys($scopeGroups) as $gk) {
                $db->prepare("DELETE FROM cctv_checklist_nvr WHERE checklist_id = ? AND nvr_key = ?")->execute([$clId, $gk]);
                $db->prepare("INSERT INTO cctv_checklist_nvr (checklist_id, nvr_key, user_id, user_name, updated_at) VALUES (?, ?, ?, ?, ?)")
                   ->execute([$clId, $gk, (int)$me['id'], (string)$me['full_name'], $now]);
            }
            $ins = $db->prepare("INSERT INTO cctv_checklist_results (checklist_id, asset_id, status_snapshot, results, note, photo) VALUES (?, ?, ?, ?, ?, ?)");
            $photos = [];
            foreach ($rows as $aid => $r) {
                $old = $existing['results'][$aid] ?? null;
                // Status yang disimpan = status saat pertama kali dicek (tidak berubah saat checklist diedit).
                $snap = $old['status_snapshot'] ?? $r['state'];
                $photo = (string)($old['photo'] ?? '');
                if (!empty($_POST['remove_photo'][$aid])) $photo = '';
                if (isset($_FILES['photo']['name'][$aid]) && $_FILES['photo']['error'][$aid] === UPLOAD_ERR_OK) {
                    $f = ['name' => $_FILES['photo']['name'][$aid], 'tmp_name' => $_FILES['photo']['tmp_name'][$aid],
                          'error' => $_FILES['photo']['error'][$aid], 'size' => $_FILES['photo']['size'][$aid]];
                    $saved = cctvSavePhoto($f, $aid, $date);
                    if ($saved !== '') $photo = $saved;
                }
                $ins->execute([$clId, $aid, $snap, json_encode($r['marks']), $r['note'] !== '' ? $r['note'] : null, $photo !== '' ? $photo : null]);
                $photos[$aid] = $photo;
            }
            // Temuan (item ✗) otomatis masuk Laporan petugas -> harus ditangani admin.
            $camById = [];
            foreach ($cams as $c) $camById[$c['id']] = $c;
            [$repNew, $repUpd] = cctvChecklistFindingsToReports($db, $date, $shift, $rows, $photos, $camById, $items, $me);
            $db->commit();
            // Temuan baru ikut dikirim ke Chat Grup (bila admin sudah memilih grupnya). Gagal di sini tidak membatalkan checklist.
            if (!empty($GLOBALS['cctv_chat_findings']) && is_file(__DIR__ . '/includes/chat.php')) {
                require_once __DIR__ . '/includes/chat.php';
                chatPostCctvFindings($db, $GLOBALS['cctv_chat_findings'], (string)$me['full_name'], $shift, $date);
            }
            $bad = count(array_filter($rows, fn($r) => in_array(2, $r['marks'], true) || in_array($r['state'], ['off', 'vl'], true)));
            $_SESSION['cctv_msg'] = ['ok' => true, 'text' => cL('Checklist ', 'Checklist ') . ($nvrSel === 'all' ? '' : $groups[(int)$nvrSel]['name'] . ' · ') . $shift . ' ' . date('d/m/Y', strtotime($date)) . cL(' tersimpan. ', ' saved. ')
                . ($bad ? $bad . cL(' kamera bermasalah tercatat di laporan.', ' camera(s) with problems recorded.') : cL('Semua kamera OK.', 'All cameras OK.'))
                . ($repNew + $repUpd ? ' ' . ($repNew + $repUpd) . cL(' temuan masuk ke Laporan petugas (harus ditangani).', ' finding(s) added to Officer reports (to be handled).') : '')];
            header('Location: cctv_checklist.php?date=' . urlencode($date) . '&shift=' . urlencode($shift) . '&nvr=' . urlencode($nvrSel));
            exit;
        } catch (Throwable $e) {
            $db->rollBack();
            $errors[] = cL('Gagal menyimpan: ', 'Failed to save: ') . $e->getMessage();
        }
    }
}
$msg = $_SESSION['cctv_msg'] ?? null;
unset($_SESSION['cctv_msg']);

// Nilai form: dari POST (jika gagal validasi), dari checklist tersimpan, atau kosong.
$val = function (int $aid, string $code) use ($existing) {
    if (isset($_POST['m'])) return (int)($_POST['m'][$aid][$code] ?? 0);
    return (int)($existing['results'][$aid]['marks'][$code] ?? 0);
};
$noteVal = function (int $aid) use ($existing) {
    if (isset($_POST['note'])) return (string)($_POST['note'][$aid] ?? '');
    return (string)($existing['results'][$aid]['note'] ?? '');
};

$pageTitle = cL('Checklist CCTV', 'CCTV Checklist');
$cctvTab = 'checklist';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<style>
    .ck-btn { width: 2.1rem; height: 2rem; border-radius: .4rem; border: 1px solid #cbd5e1; background: #fff; color: #94a3b8; font-weight: 700; }
    .ck-btn[data-v="1"] { background: #dcfce7; border-color: #16a34a; color: #15803d; }
    .ck-btn[data-v="2"] { background: #fee2e2; border-color: #dc2626; color: #b91c1c; }
    /* Judul kolom (No, Nama CCTV, Status, G P R J M F, Keterangan, Foto) tetap terlihat saat digulir ke bawah. */
    .ck-table > thead > tr > th { position: -webkit-sticky; position: sticky; top: calc(-1 * var(--main-pad, 0px)); z-index: 15; background: #f8fafc; box-shadow: inset 0 -1px 0 #e2e8f0, 0 1px 2px rgba(15, 23, 42, .06); }
    .ck-wrap.ck-scroll { max-height: calc(100dvh - 9rem); overflow: auto; }   /* tabel lebih lebar dari layar: kotak tabel punya scroll sendiri */
    .ck-wrap.ck-scroll .ck-table > thead > tr > th { top: 0; }
    @media print { .ck-table > thead > tr > th { position: static; box-shadow: none; } .ck-wrap.ck-scroll { max-height: none; overflow: visible; } }
    .ck-readonly .ck-btn, .ck-readonly #btnAllOk, .ck-readonly .ck-photocell label { pointer-events: none; opacity: .75; }
    /* HP: tiap kamera tampil sebagai kartu, tombol item berjajar di bawah nama kamera. */
    @media (max-width: 640px) {
        .ck-table thead { display: none; }
        .ck-table tr.ck-group { display: block; }
        .ck-table tr.ck-group td { display: block; }
        .ck-table, .ck-table tbody { display: block; }
        .ck-table tr.ck-row { display: grid; grid-template-columns: repeat(var(--n), minmax(0, 1fr)); gap: .5rem .25rem; padding: .75rem; }
        .ck-table tr.ck-row > td { padding: 0 !important; border: 0; }
        .ck-table td.ck-no { display: none; }
        .ck-table td.ck-cam { grid-column: 1 / -1; }
        .ck-table td.ck-st { grid-column: 1 / -1; }
        .ck-table td.ck-item { text-align: center; }
        .ck-table td.ck-item::before { content: attr(data-code); display: block; font-size: .7rem; font-weight: 600; color: #64748b; }
        .ck-table td.ck-notecell, .ck-table td.ck-photocell { grid-column: 1 / -1; }
        .ck-table td.ck-notecell input { width: 100%; }
        .ck-btn { width: 100%; max-width: 3rem; height: 2.4rem; }
    }
</style>
<div class="mb-3">
    <h1 class="text-xl font-semibold text-slate-800"><?= $h(cL('Checklist CCTV', 'CCTV Checklist')) ?></h1>
    <p class="text-sm text-slate-500"><?= $h(cL('Klik sekali = OK (✓), klik lagi = bermasalah (✗), klik lagi = kosong. Kamera bermasalah wajib diberi keterangan; foto opsional (di HP langsung membuka kamera).', 'Click once = OK (✓), again = problem (✗), again = empty. Cameras with problems need a note; photo optional.')) ?></p>
</div>

<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>
<?php foreach ($errors as $e): ?>
    <div class="mb-3 text-sm rounded-lg px-3 py-2 bg-red-50 text-red-700"><?= $h($e) ?></div>
<?php endforeach; ?>

<form method="get" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Tanggal', 'Date')) ?></span>
        <input type="date" name="date" value="<?= $h($date) ?>" max="<?= date('Y-m-d') ?>" class="border border-slate-300 rounded-lg px-2 py-1.5" onchange="this.form.submit()"></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">Shift</span>
        <select name="shift" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[140px]" onchange="this.form.submit()">
            <?php foreach ($shifts as $s): $role = cctvShiftRole($s); ?><option value="<?= $h($s) ?>" <?= $s === $shift ? 'selected' : '' ?>><?= $h($s . ($role === 'cctv' ? ' · ' . cL('petugas CCTV', 'CCTV officer') : ($role === 'admin' ? ' · ' . cL('admin IT', 'IT admin') : ''))) ?></option><?php endforeach; ?>
        </select></label>
    <?php if (count($groups) > 1): ?>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('NVR yang dicek', 'NVR to check')) ?></span>
        <select name="nvr" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[180px] font-medium" onchange="this.form.submit()">
            <?php foreach ($groups as $gk => $g): ?><option value="<?= $gk ?>" <?= $nvrSel === (string)$gk ? 'selected' : '' ?>><?= $h($g['name'] . ' (' . count($g['cams']) . ' ' . cL('kamera', 'cameras') . ')') ?></option><?php endforeach; ?>
            <option value="all" <?= $nvrSel === 'all' ? 'selected' : '' ?>><?= $h(cL('Semua NVR', 'All NVRs') . ' (' . count($allCams) . ')') ?></option>
        </select></label>
    <?php endif; ?>
    <div class="text-xs text-slate-500 pb-1.5 flex flex-col gap-1">
        <?php foreach ($scopeGroups as $gk => $g):
            $done = $existing && array_filter($g['cams'], fn($c) => isset($existing['results'][$c['id']]));
            $off = cctvChecklistOfficer($existing, $gk); ?>
            <div>
                <?php if (count($scopeGroups) > 1 || count($groups) > 1): ?><b class="text-slate-700"><?= $h($g['name']) ?>:</b><?php endif; ?>
                <?php if ($done): ?>
                    <span class="inline-block px-2 py-0.5 rounded-full bg-green-100 text-green-700 font-semibold"><?= $h(cL('Sudah diisi', 'Filled')) ?></span>
                    <?= $h(cL('oleh', 'by')) ?> <?= $h($off['name']) ?>, <?= $h(date('d M Y H:i', strtotime((string)$off['at']))) ?>
                <?php else: ?>
                    <span class="inline-block px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 font-semibold"><?= $h(cL('Belum diisi', 'Not filled yet')) ?></span>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</form>

<?php if ($offLabel !== null): ?>
    <div class="mb-3 text-sm rounded-lg px-3 py-2 bg-sky-50 border border-sky-200 text-sky-800">
        <b><?= $h(cL('Hari libur', 'Day off')) ?>: <?= $h($offLabel) ?>.</b> <?= $h(cL('Checklist tidak wajib dan tidak dihitung terlewat di rekap bulanan. Tetap bisa diisi jika ada pengecekan.', 'Checklist not required and not counted as missed. You can still fill it in if a check was done.')) ?>
    </div>
<?php endif; ?>
<?php if (!$canFill): ?>
    <div class="mb-4 text-sm rounded-lg px-4 py-3 bg-amber-50 border border-amber-200 text-amber-800">
        <b><?= $h(cL('Shift ', 'Shift ') . $shift . cL(' diisi oleh: ', ' is filled by: ') . cctvShiftRoleLabel(cctvShiftRole($shift))) ?>.</b>
        <?= $h(isAdmin() ? cL('Admin hanya bisa melihat hasilnya dan mencetak.', 'Admins can only view and print it.') : cL('Pilih shift yang menjadi tugas Anda.', 'Choose the shift assigned to you.')) ?>
    </div>
<?php endif; ?>
<?php if (!$cams): ?>
    <div class="bg-white rounded-xl shadow-sm p-6 text-sm text-slate-600"><?= $h(cL('Belum ada aset kategori CCTV.', 'No CCTV assets yet.')) ?></div>
<?php else: ?>
<form method="post" enctype="multipart/form-data" id="ckForm" class="<?= $canFill ? '' : 'ck-readonly' ?>">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
    <input type="hidden" name="date" value="<?= $h($date) ?>">
    <input type="hidden" name="shift" value="<?= $h($shift) ?>">
    <input type="hidden" name="nvr" value="<?= $h($nvrSel) ?>">

    <div class="flex flex-wrap items-center gap-3 mb-3 text-sm">
        <button type="button" id="btnAllOk" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50"><?= $h(cL('Tandai semua kamera online OK', 'Mark all online cameras OK')) ?></button>
        <span id="ckProg" class="text-slate-500"></span>
        <div class="flex-1 min-w-[120px] h-2 rounded-full bg-slate-200 overflow-hidden"><div id="ckBar" class="h-full bg-blue-600" style="width:0"></div></div>
    </div>
    <div class="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500 mb-2">
        <?php foreach ($items as $it): ?><span><b class="text-slate-700"><?= $h($it['code']) ?></b> <?= $h($it['label']) ?></span><?php endforeach; ?>
    </div>

    <div class="bg-white rounded-xl shadow-sm overflow-x-auto ck-wrap" id="ckWrap">
        <table class="w-full text-sm ck-table" data-rt="off" style="--n: <?= max(1, count($items)) ?>">
            <thead class="bg-slate-50 text-slate-500 text-xs"><tr>
                <th class="text-left px-3 py-2">No</th>
                <th class="text-left px-3 py-2"><?= $h(cL('Nama CCTV', 'CCTV name')) ?></th>
                <th class="text-left px-3 py-2">Status</th>
                <?php foreach ($items as $it): ?><th class="px-1 py-2 text-center" title="<?= $h($it['label']) ?>"><?= $h($it['code']) ?></th><?php endforeach; ?>
                <th class="text-left px-3 py-2"><?= $h(cL('Keterangan', 'Note')) ?></th>
                <th class="text-left px-3 py-2"><?= $h(cL('Foto', 'Photo')) ?></th>
            </tr></thead>
            <tbody>
            <?php $prevGroup = null; foreach ($cams as $i => $c):
                $aid = $c['id'];
                $gk = (int)($c['nvr_id'] ?? 0);
                if (count($scopeGroups) > 1 && $gk !== $prevGroup): $prevGroup = $gk; ?>
                <tr class="ck-group bg-slate-100"><td colspan="<?= 5 + count($items) ?>" class="px-3 py-1.5 text-xs font-semibold text-slate-600 uppercase tracking-wide"><?= $h($groups[$gk]['name']) ?></td></tr>
            <?php endif;
                $state = $existing['results'][$aid]['status_snapshot'] ?? (cctvCheckMethod($c) === '' ? 'unknown' : $c['state']);
                $photo = (string)($existing['results'][$aid]['photo'] ?? '');
            ?>
                <tr class="border-t ck-row" data-state="<?= $h($state) ?>">
                    <td class="ck-no px-3 py-2 text-slate-400 tabular-nums"><?= $i + 1 ?></td>
                    <td class="ck-cam px-3 py-2 min-w-[160px]"><div class="font-medium text-slate-800"><?= $h($c['name'] ?: $c['location']) ?></div><div class="text-xs text-slate-500"><?= $h($c['number']) ?><?= $c['location'] !== '' ? ' · ' . $h($c['location']) : '' ?><?= $c['nvr_name'] ? ' · ch ' . (int)$c['channel'] : '' ?></div></td>
                    <td class="ck-st px-3 py-2"><?= cctvStateBadge($state) ?></td>
                    <?php foreach ($items as $it): $v = $val($aid, $it['code']); ?>
                        <td class="ck-item px-1 py-2 text-center" data-code="<?= $h($it['code']) ?>">
                            <input type="hidden" name="m[<?= $aid ?>][<?= $h($it['code']) ?>]" value="<?= $v ?>">
                            <button type="button" class="ck-btn" data-v="<?= $v ?>" aria-label="<?= $h($it['label'] . ' ' . $c['number']) ?>"><?= $v === 1 ? '✓' : ($v === 2 ? '✗' : '–') ?></button>
                        </td>
                    <?php endforeach; ?>
                    <td class="ck-notecell px-3 py-2"><input type="text" name="note[<?= $aid ?>]" maxlength="250" value="<?= $h($noteVal($aid)) ?>" class="ck-note border border-slate-300 rounded-lg px-2 py-1 text-sm w-full min-w-[7rem]" placeholder=""></td>
                    <td class="ck-photocell px-3 py-2 whitespace-nowrap text-xs">
                        <label class="inline-flex items-center gap-1 px-2 py-1 rounded-lg border border-slate-300 bg-white cursor-pointer hover:bg-slate-50">
                            <?= icon('camera') ?> <span class="ck-ph"><?= $h($photo ? cL('Ganti', 'Replace') : cL('Ambil', 'Take')) ?></span>
                            <input type="file" name="photo[<?= $aid ?>]" accept="image/*" capture="environment" class="hidden ck-file">
                        </label>
                        <?php if ($photo): ?>
                            <a href="<?= $h(CCTV_PHOTO_URL . '/' . $photo) ?>" target="_blank" class="text-blue-600 hover:underline ml-1"><?= $h(cL('Lihat', 'View')) ?></a>
                            <label class="ml-1 text-slate-500"><input type="checkbox" name="remove_photo[<?= $aid ?>]" value="1"> <?= $h(cL('hapus', 'remove')) ?></label>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="form-actions-sticky mt-4 flex flex-wrap items-center gap-3">
        <?php if ($canFill): ?><button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-5 py-2 text-sm font-medium"><?= $h(cL('Simpan checklist', 'Save checklist')) ?></button><?php endif; ?>
        <?php if ($existing): ?>
            <a href="cctv_report.php?mode=shift&date=<?= $h(urlencode($date)) ?>&shift=<?= $h(urlencode($shift)) ?>&nvr=<?= $h(urlencode($nvrSel)) ?>" class="text-sm text-blue-600 hover:underline"><?= $h(cL('Cetak checklist ini', 'Print this checklist')) ?> &rarr;</a>
        <?php endif; ?>
    </div>
</form>
<script>
(function () {
    var NEED = <?= json_encode(cL('Wajib diisi', 'Required')) ?>;
    var form = document.getElementById('ckForm');
    function rowBad(tr) {
        var st = tr.getAttribute('data-state');
        return st === 'off' || st === 'vl' || !!tr.querySelector('.ck-btn[data-v="2"]');
    }
    function refresh() {
        var rows = form.querySelectorAll('.ck-row'), done = 0;
        rows.forEach(function (tr) {
            var all = tr.querySelectorAll('.ck-btn'), filled = 0;
            all.forEach(function (b) { if (b.getAttribute('data-v') !== '0') filled++; });
            if (filled === all.length) done++;
            var note = tr.querySelector('.ck-note');
            note.placeholder = rowBad(tr) ? NEED : '';
            note.classList.toggle('border-red-400', rowBad(tr) && note.value.trim() === '');
        });
        document.getElementById('ckProg').textContent = done + ' / ' + rows.length + ' <?= $h(cL('kamera diperiksa', 'cameras checked')) ?>';
        document.getElementById('ckBar').style.width = (rows.length ? done / rows.length * 100 : 0) + '%';
    }
    function setBtn(b, v) {
        b.setAttribute('data-v', v);
        b.textContent = v === 1 ? '✓' : (v === 2 ? '✗' : '–');
        b.previousElementSibling.value = v;
    }
    var readOnly = <?= $canFill ? 'false' : 'true' ?>;
    if (readOnly) form.querySelectorAll('input[type=text]').forEach(function (i) { i.readOnly = true; });
    form.addEventListener('click', function (e) {
        if (readOnly) return;
        var b = e.target.closest('.ck-btn');
        if (!b) return;
        setBtn(b, (parseInt(b.getAttribute('data-v'), 10) + 1) % 3);
        refresh();
    });
    form.addEventListener('input', function (e) { if (e.target.classList.contains('ck-note')) refresh(); });
    form.addEventListener('change', function (e) {
        if (e.target.classList.contains('ck-file') && e.target.files.length) {
            e.target.parentNode.querySelector('.ck-ph').textContent = '1 <?= $h(cL('foto', 'photo')) ?> ✓';
        }
    });
    document.getElementById('btnAllOk').addEventListener('click', function () {
        form.querySelectorAll('.ck-row').forEach(function (tr) {
            if (tr.getAttribute('data-state') !== 'on' && tr.getAttribute('data-state') !== 'unknown') return;
            tr.querySelectorAll('.ck-btn').forEach(function (b) { if (b.getAttribute('data-v') === '0') setBtn(b, 1); });
        });
        refresh();
    });
    refresh();
    // Judul kolom mengambang: kotak tabel tidak boleh membuat area scroll sendiri, kecuali tabel lebih lebar
    // dari layar (geser ke samping) — saat itu kotak tabel diberi tinggi maksimal dan judul menempel di atasnya.
    var wrap = document.getElementById('ckWrap');
    function fitHead() {
        wrap.classList.remove('rt-unclip', 'ck-scroll');
        if (wrap.scrollWidth > wrap.clientWidth + 1) wrap.classList.add('ck-scroll'); else wrap.classList.add('rt-unclip');
    }
    fitHead();
    window.addEventListener('resize', fitHead);
})();
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
