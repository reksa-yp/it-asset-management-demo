<?php
/**
 * Handler "Tandai Selesai" untuk fitur Aset Perlu Di-Upgrade di Dashboard.
 * Menandai satu kemunculan (asset_id + ticket_id) sebagai sudah ditangani,
 * supaya hilang dari daftar sampai ada tiket baru dengan kata kunci yang sama.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/upgrade_alert.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dashboard.php');
    exit;
}

csrfCheck();

$db = getDB();
$assetId  = (int)($_POST['asset_id'] ?? 0);
$ticketId = (int)($_POST['ticket_id'] ?? 0);

$tableExists = (bool)$db->query("
    SELECT COUNT(*) FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'asset_upgrade_ack'
")->fetchColumn();

if ($assetId > 0 && $ticketId > 0 && $tableExists) {
    acknowledgeUpgrade($db, $assetId, $ticketId, currentUser()['id'] ?? null);
    header('Location: dashboard.php?upgrade_marked=1');
} elseif (!$tableExists) {
    header('Location: dashboard.php?upgrade_marked=need_migration');
} else {
    header('Location: dashboard.php');
}
exit;
