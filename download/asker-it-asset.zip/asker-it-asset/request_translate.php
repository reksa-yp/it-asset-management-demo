<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false,'error'=>'Method not allowed']); exit; }
$csrf = (string)($_POST['csrf_token'] ?? '');
if (!$csrf || !hash_equals((string)($_SESSION['csrf_token'] ?? ''), $csrf)) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'Invalid security token. Refresh the page and try again.']); exit; }
$text = trim((string)($_POST['text'] ?? ''));
if ($text === '' || mb_strlen($text) > 5000) { http_response_code(422); echo json_encode(['ok'=>false,'error'=>'Text must contain 1–5000 characters.']); exit; }
$configPath = __DIR__ . '/includes/translation_config.php';
$config = is_file($configPath) ? require $configPath : [];
$provider = strtolower((string)($config['provider'] ?? 'mymemory'));
$baseUrl = rtrim((string)($config['api_url'] ?? 'https://api.mymemory.translated.net'), '/');
$apiKey = (string)($config['api_key'] ?? '');
$timeout = max(3, min(30, (int)($config['timeout_seconds'] ?? 20)));
$source = (string)($config['source_language'] ?? 'id');

function app_http_get_json(string $url, int $timeout, int &$status): ?array {
    $status = 0; $response = false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_CONNECTTIMEOUT=>5, CURLOPT_TIMEOUT=>$timeout, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_HTTPHEADER=>['Accept: application/json','User-Agent: IT-Asset-Management/1.0']]);
        $response = curl_exec($ch); $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    } else {
        $ctx = stream_context_create(['http'=>['method'=>'GET','header'=>"Accept: application/json\r\nUser-Agent: IT-Asset-Management/1.0\r\n",'timeout'=>$timeout,'ignore_errors'=>true]]);
        $response = @file_get_contents($url, false, $ctx);
        foreach (($http_response_header ?? []) as $header) if (preg_match('#^HTTP/\S+\s+(\d+)#', $header, $m)) $status=(int)$m[1];
    }
    if (!is_string($response) || $response === '') return null;
    $decoded = json_decode($response, true);
    return is_array($decoded) ? $decoded : null;
}
function app_http_post_json(string $url, array $payload, int $timeout, int &$status): ?array {
    $status = 0; $response = false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($payload),CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>$timeout,CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded','Accept: application/json']]);
        $response = curl_exec($ch); $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    } else {
        $ctx = stream_context_create(['http'=>['method'=>'POST','header'=>"Content-Type: application/x-www-form-urlencoded\r\nAccept: application/json\r\n",'content'=>http_build_query($payload),'timeout'=>$timeout,'ignore_errors'=>true]]);
        $response = @file_get_contents($url, false, $ctx);
        foreach (($http_response_header ?? []) as $header) if (preg_match('#^HTTP/\S+\s+(\d+)#', $header, $m)) $status=(int)$m[1];
    }
    if (!is_string($response) || $response === '') return null;
    $decoded = json_decode($response, true);
    return is_array($decoded) ? $decoded : null;
}

// MyMemory limits individual q values; split longer input into paragraph/sentence-sized chunks.
if ($provider === 'mymemory') {
    $parts = preg_split('/(?<=\n)|(?<=[.!?])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);
    $chunks = []; $buffer = '';
    foreach ($parts ?: [$text] as $part) {
        $part = trim($part); if ($part === '') continue;
        $pieces = (strlen($part) > 430) ? str_split($part, 430) : [$part];
        foreach ($pieces as $piece) {
            if ($buffer !== '' && strlen($buffer.' '.$piece) > 430) { $chunks[]=$buffer; $buffer=''; }
            $buffer = $buffer === '' ? $piece : $buffer.' '.$piece;
        }
    }
    if ($buffer !== '') $chunks[]=$buffer;
    $translated = [];
    foreach ($chunks as $chunk) {
        $params = ['q'=>$chunk,'langpair'=>$source.'|en'];
        if ($apiKey !== '') $params['key'] = $apiKey;
        $status = 0; $data = app_http_get_json($baseUrl.'/get?'.http_build_query($params), $timeout, $status);
        if ($status < 200 || $status >= 300 || !is_array($data) || (int)($data['responseStatus'] ?? 0) !== 200 || !isset($data['responseData']['translatedText'])) {
            http_response_code($status === 429 ? 429 : 502);
            echo json_encode(['ok'=>false,'error'=>$status===429 ? 'Translation limit reached. Please wait and try again.' : 'Translation service is unavailable or has reached its usage limit. Original text is preserved.'], JSON_UNESCAPED_UNICODE); exit;
        }
        $translated[] = html_entity_decode((string)$data['responseData']['translatedText'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    echo json_encode(['ok'=>true,'translatedText'=>implode(' ', $translated)], JSON_UNESCAPED_UNICODE); exit;
}

// LibreTranslate-compatible provider, for users with a configured endpoint/API key.
$payload = ['q'=>$text, 'source'=>$source === 'id' ? 'id' : $source, 'target'=>'en', 'format'=>'text'];
if ($apiKey !== '') $payload['api_key'] = $apiKey;
$status = 0; $data = app_http_post_json($baseUrl.'/translate', $payload, $timeout, $status);
if ($status < 200 || $status >= 300 || !is_array($data) || !isset($data['translatedText']) || !is_string($data['translatedText'])) {
    http_response_code($status === 429 ? 429 : 502);
    $detail = is_array($data) ? (string)($data['error'] ?? '') : '';
    echo json_encode(['ok'=>false,'error'=>$status===429 ? 'Translation limit reached. Please wait and try again.' : ($detail !== '' ? 'Translation service: '.$detail : 'Translation service is unavailable. Original text is preserved.')], JSON_UNESCAPED_UNICODE); exit;
}
echo json_encode(['ok'=>true,'translatedText'=>$data['translatedText']], JSON_UNESCAPED_UNICODE);
