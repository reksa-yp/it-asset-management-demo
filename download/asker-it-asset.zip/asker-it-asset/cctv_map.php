<?php
/**
 * Menu CCTV > Map CCTV (khusus admin): layout PDF/gambar + titik kamera yang bisa digeser & diwarnai,
 * tooltip detail (nama, IP, tgl pemasangan), koneksi ke switch PoE (sinkron dengan topologi Jaringan),
 * keterangan otomatis, serta cetak / unduh PDF ukuran A4 atau A3.
 * Data disimpan di tabel baru (includes/cctv_map.php); perubahan tersimpan lewat cctv_map_api.php.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv_map.php';

$db = getDB();
ensureCctvTables($db);
ensureCctvMapTables($db);
$data = cctvMapData($db);

$pageTitle = 'Map CCTV';
$cctvTab = 'map';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="mb-3">
    <h1 class="text-xl font-semibold text-slate-800">Map CCTV</h1>
    <p class="text-sm text-slate-500"><?= htmlspecialchars(cL('Upload layout PDF, atur posisi titik CCTV, warna per NVR, dan hubungan ke switch PoE (ikut topologi Jaringan).', 'Upload a PDF layout, place CCTV points, colour by NVR and link to PoE switches (follows the network topology).')) ?></p>
</div>
<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<style>
#cm{--line:#e2e8f0;--mut:#64748b;--pri:#2563eb;--pri-d:#1d4ed8;--bad:#dc2626;--warn:#d97706;--ok:#16a34a;display:flex;flex-direction:column;height:calc(100vh - 235px);min-height:600px;background:#fff;border:1px solid var(--line);border-radius:12px;overflow:hidden;font-size:14px;color:#0f172a}
#cm *{box-sizing:border-box}
#cm button,#cm select,#cm input,#cm textarea{font:inherit;color:inherit}
#cm .bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:8px 10px;border-bottom:1px solid var(--line)}
#cm .sep{width:1px;height:22px;background:var(--line)}
#cm .btn{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line);background:#fff;border-radius:8px;padding:6px 10px;cursor:pointer;white-space:nowrap}
#cm .btn:hover{background:#f8fafc}
#cm .btn.pri{background:var(--pri);border-color:var(--pri);color:#fff}
#cm .btn.pri:hover{background:var(--pri-d)}
#cm .btn.on{background:#dbeafe;border-color:#93c5fd;color:var(--pri-d)}
#cm .btn.dng{color:var(--bad)}
#cm .btn svg,#cm .ic{width:16px;height:16px;flex:none}
#cm .btn[disabled]{opacity:.5;cursor:default}
#cm .seg{display:inline-flex;border:1px solid var(--line);border-radius:8px;overflow:hidden}
#cm .seg button{border:0;background:#fff;padding:6px 12px;cursor:pointer;display:inline-flex;gap:6px;align-items:center}
#cm .seg button.on{background:var(--pri);color:#fff}
#cm .bar select,#cm .bar input[type=search],#cm .bar input[type=number]{border:1px solid var(--line);border-radius:8px;padding:6px 8px;background:#fff;max-width:170px}
#cm #fColor{max-width:230px}
#cm .chk{display:inline-flex;gap:5px;align-items:center;cursor:pointer;color:var(--mut);font-size:13px}
#cm .body{flex:1;min-height:0;display:flex}
#cm #stage{flex:1;min-width:0;position:relative;background:#e5e7eb;overflow:hidden;touch-action:none}
#cm #svg{width:100%;height:100%;display:block;cursor:grab;user-select:none}
#cm #svg.adding{cursor:crosshair}
#cm #svg.pan{cursor:grabbing}
#cm .mk{cursor:pointer}
#cm .edit .mk{cursor:move}
@keyframes cmpulse{0%{r:13;opacity:.9}100%{r:24;opacity:0}}
#cm .pulse{animation:cmpulse 1.4s infinite}
#cm #tip{position:absolute;pointer-events:none;background:#0f172a;color:#fff;border-radius:10px;padding:9px 11px;font-size:12.5px;box-shadow:0 6px 20px rgba(0,0,0,.3);display:none;z-index:5;max-width:280px}
#cm #tip b{display:block;font-size:13.5px;margin-bottom:3px}
#cm #tip div{display:flex;gap:8px;justify-content:space-between}
#cm #tip div span:first-child{color:#94a3b8}
#cm .hint{position:absolute;left:12px;top:12px;background:rgba(255,255,255,.94);border:1px solid var(--line);border-radius:10px;padding:7px 11px;font-size:12.5px;color:#334155;max-width:min(520px,70%);z-index:3}
#cm .hint.add{background:#dbeafe;border-color:#93c5fd;color:#1e3a8a;font-weight:600}
#cm .zoom{position:absolute;right:12px;top:12px;display:flex;flex-direction:column;gap:6px;z-index:3}
#cm .zoom .btn{padding:7px}
#cm .legend{position:absolute;left:12px;bottom:12px;background:rgba(255,255,255,.96);border:1px solid var(--line);border-radius:10px;padding:9px 12px;font-size:12.5px;z-index:3;min-width:230px;max-width:290px;max-height:62%;overflow:auto}
#cm .legend h4{margin:0 0 5px;font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:var(--mut)}
#cm .legend p{margin:3px 0}
#cm .legend .lg{display:flex;align-items:center;gap:8px}
#cm .legend .lgc{width:22px;display:flex;justify-content:center}
#cm .legend .lgl{flex:1}
#cm .legend .lg.tot{border-top:1px solid var(--line);padding-top:4px;margin-top:5px;font-weight:700}
#cm .legend input[type=color]{width:22px;height:22px;padding:0;border:0;background:none;cursor:pointer}
#cm .dot{width:12px;height:12px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 0 1px #94a3b8;flex:none;display:inline-block}
#cm aside{width:380px;max-width:44%;border-left:1px solid var(--line);display:flex;flex-direction:column;min-height:0}
#cm .stabs{display:flex;border-bottom:1px solid var(--line)}
#cm .stabs button{flex:1;border:0;background:none;padding:10px 6px;cursor:pointer;color:var(--mut);border-bottom:2px solid transparent;display:inline-flex;gap:6px;justify-content:center;align-items:center}
#cm .stabs button.on{color:var(--pri-d);border-color:var(--pri);font-weight:600}
#cm #sbody{flex:1;overflow:auto;padding:14px}
#cm .stats{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:12px}
#cm .stat{border:1px solid var(--line);border-radius:10px;padding:6px 8px;text-align:center}
#cm .stat b{display:block;font-size:17px}
#cm .stat span{font-size:11px;color:var(--mut)}
#cm h3{margin:0 0 8px;font-size:15px;font-weight:600;display:flex;align-items:center;gap:8px}
#cm .badge{display:inline-block;font-size:11px;font-weight:600;padding:1px 8px;border-radius:99px;background:#e2e8f0;color:#334155}
#cm .badge.on{background:#dcfce7;color:#166534}#cm .badge.off{background:#fee2e2;color:#991b1b}#cm .badge.unknown{background:#f1f5f9;color:#475569}
#cm .badge.baru{background:#ffe4e6;color:#9f1239}#cm .badge.lama{background:#fef3c7;color:#92400e}#cm .badge.dummy{background:#e2e8f0;color:#334155}
#cm dl{margin:10px 0;display:grid;grid-template-columns:110px 1fr;gap:7px 10px}
#cm dt{color:var(--mut)}#cm dd{margin:0;word-break:break-word}
#cm label.f{display:block;margin-bottom:10px;font-size:12px;color:var(--mut)}
#cm label.f input,#cm label.f select,#cm label.f textarea{display:block;width:100%;margin-top:3px;border:1px solid var(--line);border-radius:8px;padding:7px 9px;background:#fff;font-size:14px;color:#0f172a}
#cm label.f input[type=range]{padding:0}
#cm .row2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
#cm .sw{display:flex;gap:6px;flex-wrap:wrap;margin:4px 0 12px;align-items:center}
#cm .sw i{width:24px;height:24px;border-radius:50%;cursor:pointer;border:2px solid #fff;box-shadow:0 0 0 1px #cbd5e1;display:inline-block}
#cm .sw i.on{box-shadow:0 0 0 2px var(--pri)}
#cm .list .it{display:flex;gap:9px;align-items:center;padding:8px;border:1px solid var(--line);border-radius:10px;margin-bottom:6px;cursor:pointer}
#cm .list .it:hover{background:#f8fafc}
#cm .list .it small{color:var(--mut);display:block}
#cm .tree{list-style:none;margin:0;padding-left:16px;border-left:2px solid #e2e8f0}
#cm .tree.root{padding-left:0;border:0}
#cm .node{padding:6px 8px;border:1px solid var(--line);border-radius:10px;margin:6px 0;background:#fff}
#cm .node.click{cursor:pointer}#cm .node.click:hover{background:#f8fafc}
#cm .node.sel{border-color:var(--pri);background:#eff6ff}
#cm .ports{font-size:12.5px;margin:6px 0 2px}
#cm .ports div{display:flex;gap:6px;padding:2px 0;color:#334155;align-items:center}
#cm .ports code{background:#f1f5f9;border-radius:5px;padding:0 5px;color:#0f172a}
#cm .warn{background:#fffbeb;border:1px solid #fde68a;color:#92400e;border-radius:10px;padding:8px 10px;font-size:12.5px;margin:8px 0}
#cm .note{color:var(--mut);font-size:12.5px}
#cm a{color:var(--pri-d);text-decoration:underline}
#cm .empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;text-align:center;padding:24px;color:#475569;z-index:2}
#cm .empty div{background:#fff;border:2px dashed #cbd5e1;border-radius:14px;padding:26px 30px;max-width:420px}
#cmToast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);background:#0f172a;color:#fff;padding:9px 16px;border-radius:99px;font-size:13px;opacity:0;pointer-events:none;transition:.25s;z-index:80}
#cmToast.show{opacity:1}
.cm-modal{position:fixed;inset:0;background:rgba(15,23,42,.5);display:flex;align-items:center;justify-content:center;z-index:70;padding:16px;font-size:14px}
.cm-modal .box{background:#fff;border-radius:14px;padding:18px;max-width:460px;width:100%;max-height:90vh;overflow:auto}
.cm-modal h3{font-size:16px;font-weight:600;margin:0 0 8px}
.cm-modal .acts{display:flex;gap:8px;justify-content:flex-end;margin-top:14px;flex-wrap:wrap}
.cm-modal label.f{display:block;margin-bottom:10px;font-size:12px;color:#64748b}
.cm-modal label.f input,.cm-modal label.f select{display:block;width:100%;margin-top:3px;border:1px solid #e2e8f0;border-radius:8px;padding:7px 9px;font-size:14px;color:#0f172a;background:#fff}
.cm-modal .btn{display:inline-flex;align-items:center;gap:6px;border:1px solid #e2e8f0;background:#fff;border-radius:8px;padding:6px 12px;cursor:pointer}
.cm-modal .btn.pri{background:#2563eb;border-color:#2563eb;color:#fff}
.cm-modal .note{color:#64748b;font-size:12.5px}
.cm-modal .rad{display:flex;gap:8px;align-items:flex-start;margin:6px 0;font-size:13.5px}
@media(max-width:900px){#cm{height:auto}#cm .body{flex-direction:column}#cm aside{width:100%;max-width:none;height:46vh;border-left:0;border-top:1px solid var(--line)}#cm #stage{min-height:420px}#cm .legend{max-height:40%}}
</style>

<div id="cm">
    <div class="bar" id="bar"></div>
    <div class="body">
        <div id="stage">
            <svg id="svg" xmlns="http://www.w3.org/2000/svg"><g id="world"><image id="mapimg" x="0" y="0" width="0" height="0"/><g id="under"></g></g><g id="over"></g></svg>
            <div class="hint" id="hint"></div>
            <div class="zoom" id="zoom"></div>
            <div class="legend" id="legend"></div>
            <div id="tip"></div>
            <div class="empty" id="empty" style="display:none"><div><b style="font-size:16px">Belum ada peta</b><p class="note" style="margin:8px 0 14px">Upload layout CCTV dalam bentuk PDF (atau gambar JPG/PNG). Setelah itu titik kamera bisa ditambahkan dan digeser di atas layout.</p><button class="btn pri" id="emptyUp"></button></div></div>
        </div>
        <aside><div class="stabs" id="stabs"></div><div id="sbody"></div></aside>
    </div>
</div>
<div id="cmToast"></div>
<input type="file" id="cmFile" accept=".pdf,application/pdf,image/png,image/jpeg" hidden>

<script>
const CM = <?= json_encode($data, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_INVALID_UTF8_SUBSTITUTE) ?>;
const CSRF = <?= json_encode(csrfToken()) ?>;
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const PATHS = {
 upload:'<path d="M12 16V4m0 0l-4 4m4-4l4 4M4 16v3a1 1 0 001 1h14a1 1 0 001-1v-3"/>',
 eye:'<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
 edit:'<path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 trash:'<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
 net:'<rect x="3" y="14" width="18" height="6" rx="1.5"/><path d="M7 17h.01M11 17h.01M12 14V9M12 9H6V5M12 9h6V5"/>',
 zin:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5M8 11h6M11 8v6"/>',
 zout:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5M8 11h6"/>',
 fit:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
 dl:'<path d="M12 4v12m0 0l-4-4m4 4l4-4M4 20h16"/>',
 print:'<path d="M7 9V3h10v6M7 17H5a1 1 0 01-1-1v-5a1 1 0 011-1h14a1 1 0 011 1v5a1 1 0 01-1 1h-2"/><rect x="7" y="14" width="10" height="7"/>',
 list:'<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
 pin:'<path d="M12 21s7-6.2 7-11a7 7 0 10-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
 file:'<path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8l-5-5z"/><path d="M14 3v5h5"/>'
};
const ic = (n, c='ic') => `<svg class="${c}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${PATHS[n]||''}</svg>`;

/* ---------- Data & state ---------- */
const D = CM;
D.links = Array.isArray(D.links) ? {} : D.links;
D.used = Array.isArray(D.used) ? {} : D.used;
const SWPAL = ['#2563eb','#16a34a','#9333ea','#ea580c','#0891b2','#db2777','#65a30d','#475569'];
const PRESET = ['#e11d48','#f59e0b','#16a34a','#2563eb','#9333ea','#0891b2','#64748b','#111827'];
const PLC = '#7c3aed';
const U = {showPlan:true, msize:(() => { try { const v = +localStorage.getItem('cm_msize'); return v >= .3 && v <= 1.6 ? v : .65; } catch (e) { return .65; } })(), mode:'view', colorBy:'auto', cone:true, links:false, labels:true, sel:null, tab:'detail', fCat:'', fSw:'', q:'', adding:null, mapId:null, paper:'A4'};
try { const s = +localStorage.getItem('cm_map'); if (s && D.maps.some(m => m.id === s)) U.mapId = s; } catch (e) {}
if (!U.mapId && D.maps.length) U.mapId = D.maps[0].id;
const V = {s:1, tx:0, ty:0};
let IW = 1000, IH = 700;
function toast(t){const e=$('#cmToast');e.textContent=t;e.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('show'),2600)}

async function api(a, data = {}, files = {}) {
 const fd = new FormData(); fd.append('a', a); fd.append('csrf_token', CSRF);
 for (const k in data) if (data[k] !== null && data[k] !== undefined) fd.append(k, data[k]);
 for (const k in files) fd.append(k, files[k][0], files[k][1]);
 const r = await fetch('cctv_map_api.php', {method:'POST', body:fd, credentials:'same-origin'});
 const ct = r.headers.get('content-type') || ''; if (ct.includes('pdf')) return r.blob(); if (ct.includes('text/html')) return r.text();
 let j; try { j = await r.json(); } catch (e) { throw new Error('Respons server tidak valid (HTTP ' + r.status + ')'); }
 if (!j.ok) throw new Error(j.error || 'Gagal');
 return j;
}
const curMap = () => D.maps.find(m => m.id === U.mapId) || null;
const mpts = () => D.pts.filter(p => p.map === U.mapId);
const camPts = () => mpts().filter(p => p.kind === 'cam');
const swPts = () => mpts().filter(p => p.kind === 'sw');
const planPts = () => mpts().filter(p => p.kind === 'plan');
const ptById = id => D.pts.find(p => p.id === id);
const info = p => p.kind === 'cam' ? D.cams[p.asset] : D.nets[p.asset];
const pname = p => p.asset ? (info(p) ? info(p).name : '(aset dihapus)') : (p.name || 'Dummy');
const linkOf = p => (p.asset && D.links[p.asset]) || null;
const swOfCam = p => { const l = linkOf(p); return l ? D.nets[l.parent] : null; };
function pst(p){ const i = info(p); if (!i || p.kind !== 'cam') return 'unknown'; return (i.state === 'off' || i.state === 'vl') ? 'off' : (i.state === 'on' ? 'on' : 'unknown'); }
const fmtDate = d => { if (!d) return '-'; const x = new Date(d + 'T00:00:00'); return isNaN(x) ? d : x.toLocaleDateString('id-ID', {day:'2-digit', month:'short', year:'numeric'}); };
const nvrById = id => D.nvrs.find(n => n.id === id);
const swIdx = id => Object.keys(D.nets).map(Number).sort((a, b) => a - b).indexOf(+id);
const swColor = id => { const i = swIdx(id); return i < 0 ? '#94a3b8' : SWPAL[i % SWPAL.length]; };
const ageDays = p => { const d = new Date(p.date + 'T00:00:00'); if (!p.date || isNaN(d)) return 9999; const t = new Date(); t.setHours(0,0,0,0); return Math.round((t - d) / 864e5); };
/* Kelompok warna otomatis: baru (< N hari) | dummy | id NVR | nonvr */
function grp(p){
 if (p.cat === 'dummy' || !p.asset) return 'dummy';
 if (p.cat === 'baru' && ageDays(p) < D.cfg.days) return 'baru';
 const i = info(p); return i && i.nvr && nvrById(i.nvr) ? i.nvr : 'nonvr';
}
const GCOL = k => k === 'baru' ? D.cfg.baru_color : k === 'dummy' ? D.cfg.dummy_color : k === 'nonvr' ? '#94a3b8' : nvrById(k).color;
function catLabel(p){
 const g = grp(p);
 if (g === 'dummy') return 'Dummy (palsu)';
 if (g === 'baru') return `CCTV Baru · ikut warna NVR dalam ${Math.max(1, D.cfg.days - ageDays(p))} hari`;
 if (p.cat === 'baru') return g === 'nonvr' ? 'CCTV Baru · NVR belum diisi' : `CCTV Baru (sudah ${ageDays(p)} hari) · ikut warna NVR`;
 return g === 'nonvr' ? 'CCTV · NVR belum diisi' : 'CCTV Existing';
}
function camColor(p){
 if (U.colorBy === 'status') return p.cat === 'dummy' || !p.asset ? '#94a3b8' : ({off:'#dc2626', on:'#16a34a', unknown:'#94a3b8'})[pst(p)];
 if (U.colorBy === 'switch') { const l = linkOf(p); return l ? swColor(l.parent) : '#94a3b8'; }
 return p.color || GCOL(grp(p));
}
function visible(p){
 if (p.kind !== 'cam') return true;
 if (U.fCat === 'dummy' && grp(p) !== 'dummy') return false;
 if (U.fCat === 'baru' && grp(p) !== 'baru') return false;
 if (U.fCat.startsWith('n') && String(grp(p)) !== U.fCat.slice(1)) return false;
 const l = linkOf(p);
 if (U.fSw === '-' && l) return false;
 if (U.fSw && U.fSw !== '-' && !(l && String(l.parent) === U.fSw)) return false;
 if (U.q){ const i = info(p) || {}; const t = (pname(p) + ' ' + (i.ip||'') + ' ' + (i.loc||'') + ' ' + p.label).toLowerCase(); if (!t.includes(U.q.toLowerCase())) return false; }
 return true;
}
function usedPorts(dev, exceptAsset){
 const m = Object.assign({}, D.used[dev] || {});
 const l = D.links[exceptAsset];
 if (l && +l.parent === +dev && l.port) delete m[String(l.port).toLowerCase()];
 return m;
}
const nextLabel = () => String(Math.max(0, ...mpts().map(p => parseInt(p.label) || 0)) + 1);
const portNum = s => parseInt(String(s || '').replace(/\D/g, '')) || 999;

/* ---------- Pemuat peta ---------- */
function loadMapImage(){
 const m = curMap();
 $('#empty').style.display = m ? 'none' : 'flex';
 if (!m){ $('#mapimg').setAttribute('width', 0); $('#mapimg').setAttribute('height', 0); renderAll(); return; }
 IW = m.w || 1000; IH = m.h || 700;
 const el = $('#mapimg'); el.setAttribute('href', m.url); el.setAttribute('width', IW); el.setAttribute('height', IH);
 try { localStorage.setItem('cm_map', m.id); } catch (e) {}
 fit(); renderAll(); autoLegend().then(autoImport);
}

/* ---------- Toolbar ---------- */
function renderBar(){
 const opt = (v, l, cur) => `<option value="${v}" ${String(cur) === String(v) ? 'selected' : ''}>${esc(l)}</option>`;
 const m = curMap(), edit = U.mode === 'edit';
 $('#bar').innerHTML = `
  <select id="fMap" title="Pilih peta">${D.maps.map(x => opt(x.id, x.name, U.mapId)).join('') || '<option>(belum ada peta)</option>'}</select>
  <button class="btn pri" id="bUp">${ic('upload')} Upload layout PDF</button>
  <div class="seg"><button data-m="view" class="${!edit?'on':''}">${ic('eye')} Lihat</button><button data-m="edit" class="${edit?'on':''}" ${m?'':'disabled'}>${ic('edit')} Edit posisi</button></div>
  ${edit ? `<button class="btn ${U.adding&&U.adding.kind==='cam'?'on':''}" id="bAddC">${ic('plus')} Titik CCTV</button><button class="btn ${U.adding&&U.adding.kind==='sw'?'on':''}" id="bAddS">${ic('plus')} Titik Switch</button><button class="btn ${U.adding&&U.adding.kind==='plan'?'on':''}" id="bAddP" title="Tandai rencana pemasangan CCTV baru">${ic('plus')} Titik Rencana</button><button class="btn" id="bMapEd" title="Ganti nama / hapus peta ini">${ic('file')} Peta ini</button><button class="btn" id="bImp" title="Taruh titik CCTV otomatis dari nomor 1..N yang tertulis di layout PDF">${ic('upload')} Impor titik dari PDF</button>` : ''}
  <span class="sep"></span>
  <select id="fColor" title="Warna titik berdasarkan">${opt('auto','Warna: Otomatis (NVR / Baru)',U.colorBy)}${opt('status','Warna: Status online',U.colorBy)}${opt('switch','Warna: Switch PoE',U.colorBy)}</select>
  <label class="chk" title="CCTV Baru berwarna khusus, lalu otomatis ikut warna NVR-nya setelah sekian hari dari tanggal pemasangan">Baru &rarr; warna NVR setelah <input type="number" id="fDays" min="1" max="90" value="${D.cfg.days}" style="width:58px"> hari</label>
  <select id="fCat"><option value="">Semua kelompok</option>${D.nvrs.map(n => opt('n' + n.id, n.name, U.fCat)).join('')}${opt('baru','CCTV Baru',U.fCat)}${opt('dummy','Dummy',U.fCat)}</select>
  <select id="fSw"><option value="">Semua switch</option>${opt('-','Belum dihubungkan',U.fSw)}${Object.values(D.nets).sort((a,b)=>a.name.localeCompare(b.name)).map(s => opt(s.id, s.name, U.fSw)).join('')}</select>
  <input type="search" id="fQ" placeholder="Cari nama / IP" value="${esc(U.q)}">
  <span class="sep"></span>
  <label class="chk"><input type="checkbox" id="cCone" ${U.cone?'checked':''}> Area pandang</label>
  <label class="chk"><input type="checkbox" id="cLink" ${U.links?'checked':''}> Garis ke switch</label>
  <label class="chk"><input type="checkbox" id="cLab" ${U.labels?'checked':''}> Nomor</label>
  <label class="chk" title="Tampilkan / sembunyikan titik rencana pemasangan"><input type="checkbox" id="cPlan" ${U.showPlan?'checked':''}> Rencana</label>
  <label class="chk" title="Ukuran titik CCTV di peta (juga untuk cetak / PDF)">Titik <input type="range" id="fSize" min="30" max="140" step="5" value="${Math.round(U.msize * 100)}" style="width:90px"></label>
  <span style="margin-left:auto;display:flex;gap:6px;align-items:center">
   <select id="pPaper" title="Ukuran kertas cetak / PDF"><option value="A4" ${U.paper==='A4'?'selected':''}>Kertas A4</option><option value="A3" ${U.paper==='A3'?'selected':''}>Kertas A3</option></select>
   <button class="btn" id="bPrint" ${m?'':'disabled'}>${ic('print')} Cetak</button><button class="btn" id="bPdf" ${m?'':'disabled'}>${ic('dl')} PDF</button><button class="btn" id="bPng" ${m?'':'disabled'}>${ic('dl')} PNG</button>
  </span>`;
 $('#bUp').onclick = openUpload;
 $('#fMap').onchange = e => { U.mapId = +e.target.value; U.sel = null; loadMapImage(); };
 document.querySelectorAll('#cm .seg button').forEach(b => b.onclick = () => { U.mode = b.dataset.m; U.adding = null; renderAll(); });
 if ($('#bAddC')) $('#bAddC').onclick = () => { U.adding = U.adding && U.adding.kind === 'cam' && !U.adding.asset ? null : {kind:'cam'}; renderAll(); };
 if ($('#bAddS')) $('#bAddS').onclick = () => { U.adding = U.adding && U.adding.kind === 'sw' && !U.adding.asset ? null : {kind:'sw'}; renderAll(); };
 if ($('#bMapEd')) $('#bMapEd').onclick = openMapEdit;
 if ($('#bImp')) $('#bImp').onclick = importFromPdf;
 $('#fColor').onchange = e => { U.colorBy = e.target.value; renderMap(); renderLegend(); renderSide(); };
 let dt; $('#fDays').oninput = e => { D.cfg.days = Math.max(1, Math.min(90, +e.target.value || 7)); renderMap(); renderLegend(); renderSide(); clearTimeout(dt); dt = setTimeout(() => api('cfg', {k:'days', v:D.cfg.days}).catch(er => toast(er.message)), 500); };
 $('#fCat').onchange = e => { U.fCat = e.target.value; renderMap(); renderSide(); };
 $('#fSw').onchange = e => { U.fSw = e.target.value; renderMap(); renderSide(); };
 $('#fQ').oninput = e => { U.q = e.target.value; renderMap(); if (U.tab === 'list') renderSide(); };
 $('#cCone').onchange = e => { U.cone = e.target.checked; renderMap(); };
 $('#cLink').onchange = e => { U.links = e.target.checked; renderMap(); };
 $('#cLab').onchange = e => { U.labels = e.target.checked; renderMap(); };
 $('#cPlan').onchange = e => { U.showPlan = e.target.checked; renderMap(); renderLegend(); };
 if ($('#bAddP')) $('#bAddP').onclick = () => { U.adding = U.adding && U.adding.kind === 'plan' ? null : {kind:'plan'}; renderAll(); };
 $('#fSize').oninput = e => { U.msize = +e.target.value / 100; try { localStorage.setItem('cm_msize', U.msize); } catch (x) {} renderMap(); };
 $('#pPaper').onchange = e => { U.paper = e.target.value; };
 $('#bPng').onclick = exportPng; $('#bPrint').onclick = printMap; $('#bPdf').onclick = exportPdf;
}
function renderZoom(){
 $('#zoom').innerHTML = `<button class="btn" id="zI">${ic('zin')}</button><button class="btn" id="zO">${ic('zout')}</button><button class="btn" id="zF">${ic('fit')}</button>`;
 $('#zI').onclick = () => zoomAt(1.4); $('#zO').onclick = () => zoomAt(1/1.4); $('#zF').onclick = fit;
 $('#emptyUp').innerHTML = ic('upload') + ' Upload layout PDF'; $('#emptyUp').onclick = openUpload;
}

/* ---------- Peta ---------- */
const svg = $('#svg');
function stageSize(){ const r = $('#stage').getBoundingClientRect(); return [r.width, r.height]; }
function fit(){ const [w, h] = stageSize(); V.s = Math.min(w / IW, h / IH) * .98; V.tx = (w - IW * V.s) / 2; V.ty = (h - IH * V.s) / 2; renderMap(); }
function zoomAt(f, cx, cy){
 const [w, h] = stageSize(); cx = cx ?? w / 2; cy = cy ?? h / 2;
 const min = Math.min(w / IW, h / IH) * .6, ns = Math.max(min, Math.min(V.s * f, Math.min(w / IW, h / IH) * 14));
 const k = ns / V.s; V.tx = cx - (cx - V.tx) * k; V.ty = cy - (cy - V.ty) * k; V.s = ns; renderMap();
}
function focusOn(x, y){ const [w, h] = stageSize(); const s = Math.max(V.s, Math.min(w / IW, h / IH) * 3.2); V.s = s; V.tx = w / 2 - x * IW * s; V.ty = h / 2 - y * IH * s; renderMap(); }
function conePath(p, W, H){
 const cx = p.x * W, cy = p.y * H, r = p.rng * W, a1 = (p.ang - p.fov / 2) * Math.PI / 180, a2 = (p.ang + p.fov / 2) * Math.PI / 180;
 if (p.fov >= 360) return `M${cx - r} ${cy}A${r} ${r} 0 1 1 ${cx + r} ${cy}A${r} ${r} 0 1 1 ${cx - r} ${cy}Z`;
 const q = a => [cx + r * Math.sin(a), cy - r * Math.cos(a)]; const [x1, y1] = q(a1), [x2, y2] = q(a2);
 return `M${cx} ${cy}L${x1} ${y1}A${r} ${r} 0 ${p.fov > 180 ? 1 : 0} 1 ${x2} ${y2}Z`;
}
function swPointOf(devId){ return swPts().find(s => +s.asset === +devId) || null; }
function underSvg(W, H, forceLinks){
 let o = '';
 const vis = camPts().filter(visible);
 if (U.cone) vis.forEach(p => { const col = camColor(p); o += `<path d="${conePath(p, W, H)}" fill="${col}" fill-opacity="${p.id === U.sel ? .35 : .2}" stroke="${col}" stroke-opacity=".6" stroke-width="1" vector-effect="non-scaling-stroke"/>`; });
 if (U.cone && U.showPlan) planPts().forEach(p => { o += `<path d="${conePath(p, W, H)}" fill="${PLC}" fill-opacity="${p.id === U.sel ? .26 : .13}" stroke="${PLC}" stroke-opacity=".75" stroke-width="1.2" stroke-dasharray="6 4" vector-effect="non-scaling-stroke"/>`; });
 camPts().forEach(p => {
  const l = linkOf(p); if (!l) return; const s = swPointOf(l.parent); if (!s) return;
  const hot = U.sel === p.id || U.sel === s.id;
  if (!(U.links || forceLinks || hot)) return;
  if (!hot && !visible(p)) return;
  o += `<line x1="${s.x * W}" y1="${s.y * H}" x2="${p.x * W}" y2="${p.y * H}" stroke="${swColor(l.parent)}" stroke-width="${hot ? 3 : 1.6}" stroke-dasharray="${hot ? '' : '6 4'}" stroke-opacity="${hot ? .95 : .65}" vector-effect="non-scaling-stroke"/>`;
 });
 return o;
}
function markersSvg(P, k, showSel){
 k = k * U.msize;   // ukuran titik (atur lewat slider "Titik")
 let o = '';
 swPts().forEach(s => {
  const [x, y] = P(s.x, s.y); const col = swColor(s.asset);
  const dim = (U.fSw && U.fSw !== String(s.asset) && U.fSw !== '-') ? .35 : 1;
  o += `<g class="mk" data-id="${s.id}" transform="translate(${x} ${y}) scale(${k})" opacity="${dim}">
   ${showSel && U.sel === s.id ? '<rect x="-18" y="-14" width="36" height="28" rx="7" fill="none" stroke="#2563eb" stroke-width="2.5"/>' : ''}
   <rect x="-14" y="-9" width="28" height="18" rx="4" fill="#0f172a" stroke="${col}" stroke-width="2.5"/>
   <path d="M-9 -1h2v4h-2zM-5 -1h2v4h-2zM-1 -1h2v4h-2zM3 -1h2v4h-2zM7 -1h2v4h-2z" fill="${col}"/>
   <text y="22" text-anchor="middle" font-size="10" font-weight="700" fill="#0f172a" stroke="#fff" stroke-width="3" paint-order="stroke">${esc(pname(s))}</text></g>`;
 });
 camPts().forEach(p => {
  const [x, y] = P(p.x, p.y); const col = camColor(p); const sel = showSel && U.sel === p.id; const off = pst(p) === 'off';
  const op = visible(p) ? 1 : .18; const lab = String(p.label || '');
  o += `<g class="mk" data-id="${p.id}" transform="translate(${x} ${y}) scale(${k})" opacity="${op}">
   ${off ? '<circle class="pulse" r="13" fill="none" stroke="#dc2626" stroke-width="2.5"/>' : ''}
   ${sel ? '<circle r="16" fill="none" stroke="#2563eb" stroke-width="3"/>' : ''}
   <circle r="11" fill="${col}" stroke="#fff" stroke-width="2.2"/>
   ${grp(p) === 'dummy' ? '<path d="M-6 -6L6 6M6 -6L-6 6" stroke="#fff" stroke-width="1.6" opacity=".8"/>' : ''}
   ${U.labels && lab ? `<text y="3.5" text-anchor="middle" font-size="${lab.length > 2 ? 8 : 9.5}" font-weight="700" fill="#fff" stroke="rgba(0,0,0,.5)" stroke-width="2" paint-order="stroke">${esc(lab)}</text>` : ''}
   ${off ? '<circle cx="9" cy="-9" r="5" fill="#dc2626" stroke="#fff" stroke-width="1.5"/>' : ''}
  </g>`;
 });
 if (U.showPlan) planPts().forEach(p => {
  const [x, y] = P(p.x, p.y); const lab = String(p.label || '');
  o += `<g class="mk" data-id="${p.id}" transform="translate(${x} ${y}) scale(${k})">
   ${showSel && U.sel === p.id ? '<circle r="17" fill="none" stroke="#2563eb" stroke-width="3"/>' : ''}
   <circle r="11.5" fill="#fff" fill-opacity=".92" stroke="${PLC}" stroke-width="2.6" stroke-dasharray="4.5 3"/>
   <path d="M-5 0h10M0 -5v10" stroke="${PLC}" stroke-width="1.8" ${U.labels && lab ? 'opacity=".0"' : ''}/>
   ${U.labels && lab ? `<text y="3.5" text-anchor="middle" font-size="${lab.length > 2 ? 8 : 9}" font-weight="700" fill="${PLC}">${esc(lab)}</text>` : ''}
  </g>`;
 });
 if (showSel && U.mode === 'edit') {
  const c = ptById(U.sel);
  if (c && (c.kind === 'cam' || (c.kind === 'plan' && U.showPlan))) { const [x, y] = P(c.x, c.y), a = c.ang * Math.PI / 180, hx = x + Math.sin(a) * 34 * k, hy = y - Math.cos(a) * 34 * k;
   o += `<line x1="${x}" y1="${y}" x2="${hx}" y2="${hy}" stroke="#2563eb" stroke-width="2"/><circle data-k="rot" cx="${hx}" cy="${hy}" r="7" fill="#fff" stroke="#2563eb" stroke-width="2.5" style="cursor:alias"/>`; }
 }
 return o;
}
function renderMap(){
 $('#world').setAttribute('transform', `translate(${V.tx} ${V.ty}) scale(${V.s})`);
 if (!curMap()) { $('#under').innerHTML = ''; $('#over').innerHTML = ''; renderHint(); return; }
 $('#under').innerHTML = underSvg(IW, IH, false);
 $('#over').innerHTML = legBoxSvg() + markersSvg((x, y) => [x * IW * V.s + V.tx, y * IH * V.s + V.ty], 1, true);
 svg.classList.toggle('adding', !!U.adding);
 $('#stage').classList.toggle('edit', U.mode === 'edit');
 renderHint();
}
function renderHint(){
 const h = $('#hint'); h.className = 'hint';
 if (!curMap()) { h.style.display = 'none'; return; } h.style.display = '';
 if (U.adding) { h.classList.add('add'); h.textContent = U.adding.asset ? 'Klik di peta untuk menempatkan perangkat ini' : (U.adding.kind === 'plan' ? 'Klik di peta untuk menandai rencana titik CCTV baru' : U.adding.kind === 'cam' ? 'Klik di peta untuk meletakkan titik CCTV' : 'Klik di peta untuk meletakkan titik switch'); }
 else if (U.mode === 'edit') h.textContent = 'Mode edit: seret titik untuk memindah, tarik pegangan putih untuk mengatur arah kamera. Kotak hijau = letak keterangan saat cetak/PDF (seret / tarik sudutnya). Roda mouse = zoom.';
 else h.textContent = 'Arahkan kursor ke titik untuk melihat detail. Klik titik untuk membuka panel. Seret peta untuk menggeser.';
}

/* ---------- Keterangan otomatis ---------- */
function legendData(){
 const rows = [], cnt = {}, cams = camPts();
 cams.forEach(p => { const k = U.colorBy === 'auto' ? grp(p) : U.colorBy === 'status' ? (grp(p) === 'dummy' ? 'dummy' : pst(p)) : (linkOf(p) ? String(linkOf(p).parent) : 'none'); cnt[k] = (cnt[k] || 0) + 1; });
 if (U.colorBy === 'auto') {
  D.nvrs.forEach(n => rows.push({col:n.color, label:n.name, n:cnt[n.id] || 0, nvr:n}));
  rows.push({col:D.cfg.baru_color, label:'CCTV Baru (< ' + D.cfg.days + ' hari)', n:cnt.baru || 0, cfg:'baru_color'});
  rows.push({col:D.cfg.dummy_color, label:'Dummy / palsu', n:cnt.dummy || 0, cfg:'dummy_color'});
  if (cnt.nonvr) rows.push({col:'#94a3b8', label:'NVR belum diisi', n:cnt.nonvr});
 } else if (U.colorBy === 'status') {
  rows.push({col:'#16a34a', label:'Online', n:cnt.on || 0}, {col:'#dc2626', label:'Mati / offline', n:cnt.off || 0}, {col:'#94a3b8', label:'Belum dicek / dummy', n:(cnt.unknown || 0) + (cnt.dummy || 0)});
 } else {
  Object.values(D.nets).filter(s => cnt[s.id]).forEach(s => rows.push({col:swColor(s.id), label:s.name, n:cnt[s.id]}));
  rows.push({col:'#94a3b8', label:'Belum dihubungkan', n:cnt.none || 0});
 }
 const np = U.showPlan ? planPts().length : 0;
 if (np) rows.push({col:PLC, label:'Rencana pemasangan', n:np, dash:true});
 return {rows, total:cams.length};
}
function renderLegend(){
 const m = curMap(); $('#legend').style.display = m ? '' : 'none'; if (!m) return;
 const {rows, total} = legendData(), edit = U.mode === 'edit';
 let r = rows.map(x => `<p class="lg"><span class="lgc">${(x.nvr || x.cfg) && edit ? `<input type="color" ${x.nvr ? `data-nvr="${x.nvr.id}"` : `data-cfg="${x.cfg}"`} value="${x.col}" title="Ganti warna">` : x.dash ? `<i class="dot" style="background:#fff;box-shadow:0 0 0 2px ${x.col} inset;border:1px dashed ${x.col}"></i>` : `<i class="dot" style="background:${x.col}"></i>`}</span><span class="lgl">${esc(x.label)}</span><b>${x.n}</b></p>`).join('');
 r += `<p class="lg tot"><span class="lgc"></span><span class="lgl">TOTAL CCTV</span><b>${total}</b></p>`;
 if (U.colorBy === 'auto') {
  const soon = camPts().filter(p => grp(p) === 'baru' && info(p) && info(p).nvr).sort((a, b) => ageDays(b) - ageDays(a));
  if (soon.length) r += `<p class="note" style="margin-top:6px">Segera ikut warna NVR: ${soon.slice(0, 3).map(p => `${esc(p.label || pname(p))} (${Math.max(1, D.cfg.days - ageDays(p))} hr)`).join(', ')}${soon.length > 3 ? ' ...' : ''}</p>`;
  const mc = camPts().filter(p => p.color).length; if (mc) r += `<p class="note">${mc} titik memakai warna khusus (tetap dihitung sesuai NVR/kategorinya).</p>`;
  if (edit) r += `<p class="note" style="margin-top:6px">Klik kotak warna untuk mengganti warna NVR.</p>`;
 }
 r += '<p class="lg" style="margin-top:6px"><span class="lgc"><svg width="16" height="12" viewBox="0 0 16 12"><rect x="1" y="1" width="14" height="10" rx="2" fill="#0f172a"/></svg></span><span class="lgl">Switch</span></p><p class="lg"><span class="lgc"><i class="dot" style="background:#fff;box-shadow:0 0 0 2px #dc2626"></i></span><span class="lgl">Cincin merah = mati</span></p>';
 $('#legend').innerHTML = `<h4 id="legT" style="cursor:pointer" title="Klik untuk ciutkan / buka">Keterangan <span style="text-transform:none;font-weight:400">· otomatis dari peta</span> <span style="float:right">${U.legMin ? '[+]' : '[&minus;]'}</span></h4>${U.legMin ? '' : r}`;
 $('#legT').onclick = () => { U.legMin = !U.legMin; renderLegend(); };
 $('#legend').querySelectorAll('[data-nvr]').forEach(i => {
  i.oninput = () => { nvrById(+i.dataset.nvr).color = i.value; renderMap(); renderSide(); clearTimeout(i.t); i.t = setTimeout(() => api('nvr_color', {nvr_id:i.dataset.nvr, color:i.value}).catch(e => toast(e.message)), 400); };
 });
 $('#legend').querySelectorAll('[data-cfg]').forEach(i => {
  i.oninput = () => { D.cfg[i.dataset.cfg] = i.value; renderMap(); clearTimeout(i.t); i.t = setTimeout(() => api('cfg', {k:i.dataset.cfg, v:i.value}).catch(e => toast(e.message)), 400); };
 });
}

/* ---------- Interaksi peta ---------- */
let drag = null; const tip = $('#tip');
svg.addEventListener('pointerdown', e => {
 if (!curMap()) return;
 const r = svg.getBoundingClientRect(); const mx = e.clientX - r.left, my = e.clientY - r.top;
 const rot = e.target.closest('[data-k=rot]'), mk = e.target.closest('.mk');
 tip.style.display = 'none'; svg.setPointerCapture(e.pointerId);
 const lg = e.target.closest('[data-k=leg]'), lgr = e.target.closest('[data-k=legrs]');
 if ((lg || lgr) && U.mode === 'edit') { drag = {t:lgr ? 'legrs' : 'leg', sx:mx, sy:my, r0:Object.assign({}, legRect())}; return; }
 if (rot && U.mode === 'edit') { drag = {t:'rot', id:U.sel}; return; }
 if (mk && !U.adding) { const id = +mk.dataset.id, o = ptById(id);
  drag = {t:U.mode === 'edit' ? 'mk' : 'click', id, moved:false, sx:mx, sy:my, ox:o.x * IW * V.s + V.tx - mx, oy:o.y * IH * V.s + V.ty - my}; return; }
 drag = {t:'pan', sx:mx, sy:my, tx:V.tx, ty:V.ty, moved:false};
});
svg.addEventListener('pointermove', e => {
 const r = svg.getBoundingClientRect(); const mx = e.clientX - r.left, my = e.clientY - r.top;
 if (!drag) { hover(e, mx, my); return; }
 if (drag.t === 'pan') { if (Math.hypot(mx - drag.sx, my - drag.sy) > 3) { drag.moved = true; svg.classList.add('pan'); } V.tx = drag.tx + mx - drag.sx; V.ty = drag.ty + my - drag.sy; renderMap(); }
 else if (drag.t === 'mk') { if (Math.hypot(mx - drag.sx, my - drag.sy) > 3) drag.moved = true; if (!drag.moved) return;
  const o = ptById(drag.id); o.x = Math.max(0, Math.min(1, (mx + drag.ox - V.tx) / (IW * V.s))); o.y = Math.max(0, Math.min(1, (my + drag.oy - V.ty) / (IH * V.s))); renderMap(); }
 else if (drag.t === 'leg' || drag.t === 'legrs') { const dx = (mx - drag.sx) / (IW * V.s), dy = (my - drag.sy) / (IH * V.s), r = Object.assign({}, drag.r0);
  if (drag.t === 'leg') { r.x += dx; r.y += dy; } else { r.w += dx; r.h += dy; } drag.moved = true; setLegRect(r, false); renderMap(); }
 else if (drag.t === 'click') { if (Math.hypot(mx - drag.sx, my - drag.sy) > 3) drag.moved = true; }
 else if (drag.t === 'rot') { const c = ptById(drag.id); const cx = c.x * IW * V.s + V.tx, cy = c.y * IH * V.s + V.ty;
  let a = Math.atan2(mx - cx, -(my - cy)) * 180 / Math.PI; if (a < 0) a += 360; c.ang = Math.round(a); renderMap(); }
});
svg.addEventListener('pointerup', e => {
 const r = svg.getBoundingClientRect(); const mx = e.clientX - r.left, my = e.clientY - r.top;
 const d = drag; drag = null; svg.classList.remove('pan'); if (!d) return;
 if (d.t === 'pan' && !d.moved) {
  if (U.adding) placeAt((mx - V.tx) / (IW * V.s), (my - V.ty) / (IH * V.s));
  else { U.sel = null; renderMap(); renderSide(); }
 } else if (d.t === 'mk' || d.t === 'click') {
  if (!d.moved || d.t === 'click') { U.sel = d.id; U.tab = 'detail'; renderStabs(); renderMap(); renderSide(); }
  else { U.sel = d.id; savePoint(ptById(d.id)); renderMap(); renderSide(); }
 } else if (d.t === 'rot') { savePoint(ptById(d.id)); renderSide(); }
 else if (d.t === 'leg' || d.t === 'legrs') { if (d.moved) { setLegRect(legRect(), true); toast('Letak keterangan disimpan'); } }
});
svg.addEventListener('pointerleave', () => { tip.style.display = 'none'; });
svg.addEventListener('wheel', e => { if (!curMap()) return; e.preventDefault(); const r = svg.getBoundingClientRect(); zoomAt(e.deltaY < 0 ? 1.18 : 1 / 1.18, e.clientX - r.left, e.clientY - r.top); tip.style.display = 'none'; }, {passive:false});
function hover(e, mx, my){
 const mk = e.target.closest && e.target.closest('.mk');
 if (!mk) { tip.style.display = 'none'; return; }
 const p = ptById(+mk.dataset.id); if (!p) return; let h = '';
 if (p.kind === 'plan') {
  h = `<b>${esc(p.name || 'Rencana')} <span style="font-weight:400;color:#94a3b8">${esc(p.label || '')}</span></b><div><span>Status</span><span>Rencana pemasangan</span></div><div><span>Arah / sudut</span><span>${p.ang}° / ${p.fov}°</span></div><div><span>Jarak pandang</span><span>${Math.round(p.rng * 1000)}</span></div><div><span>Catatan</span><span>${esc(p.note || '-')}</span></div>`;
 } else if (p.kind === 'cam') {
  const i = info(p) || {}, s = swOfCam(p), l = linkOf(p), st = pst(p);
  h = `<b>${esc(pname(p))}${p.label ? ` <span style="font-weight:400;color:#94a3b8">#${esc(p.label)}</span>` : ''}</b>
   <div><span>IP</span><span>${esc(i.ip || '-')}</span></div>
   <div><span>Tgl pasang</span><span>${fmtDate(p.date)}</span></div>
   <div><span>Terhubung</span><span>${s ? esc(s.name) + ' · ' + esc(l.port || 'port ?') : 'Belum dihubungkan'}</span></div>
   <div><span>Status</span><span style="color:${st === 'off' ? '#fca5a5' : st === 'on' ? '#86efac' : '#cbd5e1'}">${st === 'off' ? 'Mati' : st === 'on' ? 'Online' : 'Belum dicek'}</span></div>
   <div><span>NVR</span><span>${esc(i.nvr_name || '-')}${i.ch ? ' · ch ' + i.ch : ''}</span></div>
   <div><span>Kategori</span><span style="text-align:right">${esc(catLabel(p))}</span></div>`;
 } else {
  const s = info(p) || {}; const n = Object.keys(D.links).filter(k => +D.links[k].parent === +p.asset && D.cams[k]).length;
  h = `<b>${esc(pname(p))}</b><div><span>Tipe</span><span>${esc(s.brand || '-')}</span></div><div><span>IP</span><span>${esc(s.ip || '-')}</span></div><div><span>Port</span><span>${s.nports || '-'}</span></div><div><span>Kamera</span><span>${n} terhubung</span></div>`;
 }
 tip.innerHTML = h; tip.style.display = 'block';
 const sw = $('#stage').clientWidth; let l = mx + 16, t = my + 16; if (l + 290 > sw) l = mx - 290; if (t + 190 > $('#stage').clientHeight) t = my - 190;
 tip.style.left = Math.max(4, l) + 'px'; tip.style.top = Math.max(4, t) + 'px';
}

/* ---------- Simpan titik ---------- */
const saveTimers = {};
function payload(p){ return {id:p.id, map:p.map, kind:p.kind, asset:p.asset || '', name:p.name, label:p.label, x:p.x, y:p.y, ang:p.ang, fov:p.fov, rng:p.rng, color:p.color, cat:p.cat, date:p.date, note:p.note}; }
function savePoint(p, quiet){
 clearTimeout(saveTimers[p.id]);
 saveTimers[p.id] = setTimeout(async () => {
  try { await api('point_save', payload(p)); if (!quiet) toast('Tersimpan'); }
  catch (e) { toast('Gagal menyimpan: ' + e.message); }
 }, 350);
}
function placeAt(x, y){
 x = Math.max(0, Math.min(1, x)); y = Math.max(0, Math.min(1, y));
 const a = U.adding;
 if (a.kind === 'plan') { const n = planPts().length + 1; U.showPlan = true; createPoint({kind:'plan', asset:null, x, y, cat:'lama', label:'R' + n, name:'Rencana ' + n}); return; }
 if (a.asset) { createPoint({kind:a.kind, asset:a.asset, x, y, cat:'lama', date:'', name:''}); }
 else openChooser(a.kind, x, y);
}
async function createPoint(o){
 const today = new Date().toISOString().slice(0, 10);
 const p = Object.assign({id:0, map:U.mapId, kind:'cam', asset:null, name:'', label:o.kind === 'sw' ? '' : nextLabel(), ang:0, fov:70, rng:.045, color:'', cat:'lama', date:o.cat === 'baru' ? today : '', note:''}, o);
 try { const j = await api('point_save', payload(p)); D.pts.push(j.point); U.sel = j.point.id; U.adding = null; U.tab = 'detail'; toast('Titik ditambahkan'); renderAll(); }
 catch (e) { toast(e.message); }
}
function openChooser(kind, x, y){
 const placed = new Set(mpts().filter(p => p.kind === kind && p.asset).map(p => +p.asset));
 const list = (kind === 'cam' ? Object.values(D.cams) : Object.values(D.nets)).filter(i => !placed.has(+i.id)).sort((a, b) => String(a.no).localeCompare(String(b.no)));
 const today = new Date().toISOString().slice(0, 10);
 const m = document.createElement('div'); m.className = 'cm-modal';
 m.innerHTML = `<div class="box"><h3>${kind === 'cam' ? 'Tambah titik CCTV' : 'Tambah titik switch'}</h3>
  ${kind === 'cam' ? `<label class="f"><span><input type="radio" name="src" value="a" checked> Dari data aset CCTV</span></label>` : ''}
  <label class="f">${kind === 'cam' ? 'Kamera' : 'Perangkat jaringan'}<input type="search" id="chQ" placeholder="Cari nama / IP / nomor aset"><select id="chSel" size="6" style="height:auto">${list.map(i => `<option value="${i.id}">${esc(i.name)} · ${esc(i.ip || 'tanpa IP')}${i.no ? ' · ' + esc(i.no) : ''}</option>`).join('')}</select></label>
  ${!list.length ? '<p class="note">Semua perangkat sudah ada di peta ini' + (kind === 'cam' ? ', atau belum ada aset berkategori CCTV.' : ', atau belum ada aset switch/router/hub/AP.') + '</p>' : ''}
  ${kind === 'cam' ? `<div class="rad"><input type="radio" name="src" value="d" id="rDum"><label for="rDum" style="flex:1">Dummy / palsu (tanpa aset)<input type="text" id="chName" placeholder="Nama dummy, mis. Dummy Lorong" style="display:block;width:100%;margin-top:3px;border:1px solid #e2e8f0;border-radius:8px;padding:7px 9px"></label></div>
  <div class="row2" style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><label class="f">Kategori<select id="chCat"><option value="lama">CCTV Existing</option><option value="baru">CCTV Baru</option></select></label><label class="f">Tgl pemasangan<input type="date" id="chDate" value=""></label></div>
  <p class="note">Pilih <b>CCTV Baru</b> + tanggal pemasangan agar berwarna khusus sampai ${D.cfg.days} hari, lalu otomatis ikut warna NVR.</p>` : ''}
  <div class="acts"><button class="btn" id="chNo">Batal</button><button class="btn pri" id="chOk">Tambahkan</button></div></div>`;
 document.body.appendChild(m);
 const sel = m.querySelector('#chSel'); const all = [...sel.options];
 m.querySelector('#chQ').oninput = e => { const q = e.target.value.toLowerCase(); all.forEach(o => o.hidden = !o.textContent.toLowerCase().includes(q)); };
 if (kind === 'cam') { const cat = m.querySelector('#chCat'), dt = m.querySelector('#chDate'); cat.onchange = () => { if (cat.value === 'baru' && !dt.value) dt.value = today; }; m.querySelector('#chName').onfocus = () => m.querySelector('#rDum').checked = true; sel.onfocus = () => m.querySelector('input[name=src][value=a]').checked = true; }
 m.querySelector('#chNo').onclick = () => { m.remove(); U.adding = null; renderAll(); };
 m.querySelector('#chOk').onclick = () => {
  if (kind === 'cam' && m.querySelector('#rDum').checked) {
   const nm = m.querySelector('#chName').value.trim() || 'Dummy'; m.remove(); createPoint({kind:'cam', asset:null, name:nm, x, y, cat:'dummy', date:''}); return;
  }
  const id = +sel.value; if (!id) { toast('Pilih perangkat dulu'); return; }
  const cat = kind === 'cam' ? m.querySelector('#chCat').value : 'lama', date = kind === 'cam' ? m.querySelector('#chDate').value : '';
  m.remove(); createPoint({kind, asset:id, x, y, cat, date});
 };
}

/* ---------- Panel samping ---------- */
function renderStabs(){
 $('#stabs').innerHTML = [['detail','info','Detail'],['list','list','Daftar'],['topo','net','Topologi']].map(([k, i, l]) => `<button data-t="${k}" class="${U.tab === k ? 'on' : ''}">${ic(i)} ${l}</button>`).join('');
 document.querySelectorAll('#stabs button').forEach(b => b.onclick = () => { U.tab = b.dataset.t; renderStabs(); renderSide(); });
}
function stats(){
 const c = camPts(), n = k => c.filter(p => grp(p) === k).length, off = c.filter(p => pst(p) === 'off').length;
 return `<div class="stats"><div class="stat"><b>${c.length}</b><span>Total</span></div>${D.nvrs.map(v => `<div class="stat"><b style="color:${v.color}">${n(v.id)}</b><span>${esc(v.name.split(' (')[0])}</span></div>`).join('')}<div class="stat"><b style="color:${D.cfg.baru_color}">${n('baru')}</b><span>Baru</span></div><div class="stat"><b>${n('dummy')}</b><span>Dummy</span></div><div class="stat"><b style="color:var(--bad)">${off}</b><span>Mati</span></div></div>`;
}
function renderSide(){
 const b = $('#sbody');
 if (!curMap()) { b.innerHTML = '<p class="note">Upload layout dulu untuk mulai menambahkan titik.</p>'; return; }
 if (U.tab === 'list') return listTab(b);
 if (U.tab === 'topo') return topoTab(b);
 const p = ptById(U.sel);
 if (p && p.map === U.mapId) return p.kind === 'plan' ? planDetail(b, p) : p.kind === 'cam' ? camDetail(b, p) : swDetail(b, p);
 b.innerHTML = stats() + `<p class="note">Pilih titik di peta untuk melihat detail. Di mode <b>Edit posisi</b> Anda bisa menambah titik CCTV (dari data aset), memindahkan, mengganti warna, dan menghubungkannya ke switch PoE.</p>`;
}
const dd = (k, v) => `<dt>${k}</dt><dd>${v}</dd>`;
function nvrText(i){ return esc((i && i.nvr_name) || '-') + (i && i.ch ? ' · ch ' + i.ch : ''); }
function camDetail(b, p){
 const i = info(p) || {}, s = swOfCam(p), l = linkOf(p), col = camColor(p), st = pst(p);
 if (U.mode !== 'edit') {
  b.innerHTML = `<h3><i class="dot" style="background:${col};width:16px;height:16px"></i>${esc(pname(p))}</h3>
  <span class="badge ${grp(p) === 'baru' ? 'baru' : p.cat}">${esc(catLabel(p))}</span> ${p.asset ? `<span class="badge ${st}">${st === 'off' ? 'Mati' : st === 'on' ? 'Online' : 'Belum dicek'}</span>` : ''}
  <dl>${dd('No. titik', esc(p.label ? '#' + p.label : '-'))}${dd('IP Address', esc(i.ip || '-'))}${dd('Tgl pemasangan', fmtDate(p.date))}${dd('Lokasi', esc(i.loc || '-'))}${dd('NVR / channel', nvrText(i))}
  ${dd('Terhubung ke', s ? `<a href="#" data-go="${s.id}">${esc(s.name)}</a> · <b>${esc(l.port || 'port belum dipilih')}</b>` : '<span style="color:var(--warn)">Belum dihubungkan</span>')}
  ${dd('Arah / sudut', p.ang + '° / ' + p.fov + '°')}${dd('Detail pemasangan', esc(p.note || '-'))}</dl>
  <p class="note">Status online/mati diambil dari menu Monitoring. Aktifkan <b>Edit posisi</b> untuk mengubah data titik.</p>`;
  bindGo(b); return;
 }
 const canLink = p.asset && D.linkable.includes(p.asset);
 const dev = s || null;
 const ports = dev ? dev.ports : [], used = dev ? usedPorts(dev.id, p.asset) : {};
 b.innerHTML = `<h3>Edit titik CCTV ${p.label ? '#' + esc(p.label) : ''}</h3>
 ${p.asset ? `<dl style="margin-top:0">${dd('Aset', esc(i.name || '-') + ' <span class="note">' + esc(i.no || '') + '</span>')}${dd('IP Address', esc(i.ip || '-'))}${dd('NVR / channel', nvrText(i))}</dl><p class="note" style="margin-top:-6px">IP dan NVR mengikuti data aset (ubah di menu Aset).</p>` : `<label class="f">Nama dummy<input data-f="name" value="${esc(p.name)}"></label>`}
 <div class="row2"><label class="f">Nomor di peta<input data-f="label" value="${esc(p.label)}" maxlength="12"></label>
 <label class="f">Tgl pemasangan<input type="date" data-f="date" value="${esc(p.date)}"></label></div>
 ${p.asset ? `<label class="f">Kategori<select data-f="cat" data-r="1"><option value="lama" ${p.cat !== 'baru' ? 'selected' : ''}>CCTV Existing</option><option value="baru" ${p.cat === 'baru' ? 'selected' : ''}>CCTV Baru (warna khusus ${D.cfg.days} hari)</option></select></label>` : ''}
 <div style="font-size:12px;color:var(--mut)">Warna titik: ${p.color ? 'khusus (manual)' : 'otomatis, ' + (grp(p) === 'baru' ? 'warna CCTV Baru sampai ' + D.cfg.days + ' hari dari tgl pasang, lalu ikut NVR' : 'ikut NVR')}</div>
 <div class="sw">${PRESET.map(c => `<i data-col="${c}" style="background:${c}" class="${p.color === c ? 'on' : ''}"></i>`).join('')}<input type="color" id="colPick" value="${p.color || GCOL(grp(p))}" style="width:28px;height:28px;padding:0;border:0;background:none"><button class="btn" id="colClr" style="padding:2px 8px">Ikut otomatis</button></div>
 ${p.asset ? (canLink ? `<label class="f">Terhubung ke switch<select id="lkSw"><option value="">- belum dihubungkan -</option>${Object.values(D.nets).sort((a, b) => a.name.localeCompare(b.name)).map(x => `<option value="${x.id}" ${s && s.id === x.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
 <label class="f">Port switch<select id="lkPort" ${dev ? '' : 'disabled'}><option value="">- pilih port -</option>${ports.map(pt => `<option value="${pt}" ${used[pt.toLowerCase()] ? 'disabled' : ''} ${l && l.port === pt ? 'selected' : ''}>${pt}${used[pt.toLowerCase()] ? ' (dipakai ' + esc(used[pt.toLowerCase()]) + ')' : ''}</option>`).join('')}</select></label>
 ${dev && !ports.length ? '<p class="note">Switch ini belum punya jumlah port. Isi di data asetnya agar pilihan port muncul.</p>' : ''}
 <p class="note" style="margin-top:-4px">Koneksi ini langsung tampil di topologi menu Jaringan.</p>` : '<div class="warn">Kamera ini belum punya IP Address di data aset, sehingga belum bisa dihubungkan ke switch. Isi IP-nya di menu Aset.</div>') : ''}
 <label class="f">Arah kamera: <span id="vAng">${p.ang}</span>°<input type="range" min="0" max="359" data-f="ang" data-n="1" value="${p.ang}"></label>
 <div class="row2"><label class="f">Sudut pandang: <span id="vFov">${p.fov}</span>°<input type="range" min="20" max="360" step="10" data-f="fov" data-n="1" value="${p.fov}"></label>
 <label class="f">Jarak pandang<input type="range" min="15" max="120" data-f="rng" data-n="1" data-k="1000" value="${Math.round(p.rng * 1000)}"></label></div>
 <label class="f">Detail pemasangan<textarea rows="3" data-f="note" placeholder="Mis. tiang tembok, panjang kabel, lensa, teknisi">${esc(p.note)}</textarea></label>
 <div style="display:flex;gap:8px"><button class="btn dng" id="del">${ic('trash')} Hapus titik</button><span class="note" style="align-self:center">Tersimpan otomatis</span></div>`;
 b.querySelectorAll('[data-f]').forEach(el => {
  const h = () => { let v = el.value; if (el.dataset.n) v = +v / (+el.dataset.k || 1); p[el.dataset.f] = v;
   if (el.dataset.f === 'cat' && v === 'baru' && !p.date) p.date = new Date().toISOString().slice(0, 10);
   savePoint(p, true); renderMap(); renderLegend();
   if (el.dataset.f === 'ang') $('#vAng').textContent = p.ang; if (el.dataset.f === 'fov') $('#vFov').textContent = p.fov;
   if (el.dataset.r || el.dataset.f === 'date') renderSide(); };
  el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', h);
 });
 b.querySelectorAll('[data-col]').forEach(x => x.onclick = () => { p.color = x.dataset.col; savePoint(p, true); renderAll(); });
 $('#colPick').oninput = e => { p.color = e.target.value; savePoint(p, true); renderMap(); renderLegend(); };
 $('#colClr').onclick = () => { p.color = ''; savePoint(p, true); renderAll(); };
 if ($('#lkSw')) {
  const doLink = async () => { try { const parent = $('#lkSw').value, port = $('#lkPort') ? $('#lkPort').value : ''; const j = await api('link_set', {asset:p.asset, parent, port}); D.links = Array.isArray(j.links) ? {} : (j.links || {}); D.used = Array.isArray(j.used) ? {} : (j.used || {}); renderAll(); toast(parent ? 'Koneksi disimpan (sinkron topologi)' : 'Koneksi dilepas'); } catch (e) { toast(e.message); renderSide(); } };
  $('#lkSw').onchange = async () => { if ($('#lkPort')) $('#lkPort').value = ''; await doLink(); };
  if ($('#lkPort')) $('#lkPort').onchange = doLink;
 }
 $('#del').onclick = async () => { if (await ask('Hapus titik ini?', esc(pname(p)) + ' dihapus dari peta (data aset dan koneksi jaringan tidak berubah).', ['Batal', 'Hapus']) === 1) { try { await api('point_delete', {id:p.id}); D.pts = D.pts.filter(x => x.id !== p.id); U.sel = null; renderAll(); toast('Titik dihapus'); } catch (e) { toast(e.message); } } };
}
function bindGo(b){ b.querySelectorAll('[data-go]').forEach(a => a.onclick = e => { e.preventDefault(); goDevice(+a.dataset.go); }); }
function goDevice(devId){
 const sp = swPointOf(devId);
 if (sp) { U.sel = sp.id; U.tab = 'detail'; renderStabs(); focusOn(sp.x, sp.y); renderMap(); renderSide(); }
 else toast('Perangkat ini belum ditempatkan di peta ini');
}
function swDetail(b, p){
 const s = info(p) || {}; const kids = Object.keys(D.links).filter(k => +D.links[k].parent === +p.asset && D.cams[k]).map(k => ({cam:D.cams[k], port:D.links[k].port})).sort((a, c) => portNum(a.port) - portNum(c.port));
 const par = s.parent ? D.nets[s.parent] : null;
 b.innerHTML = `<h3>${ic('net')} ${esc(pname(p))}</h3><span class="badge">Perangkat jaringan</span>
 <dl>${dd('Brand / type', esc(s.brand || '-'))}${dd('IP Address', esc(s.ip || '-'))}${dd('Jumlah port', s.nports || '-')}${dd('Uplink', par ? `<a href="#" data-go="${par.id}">${esc(par.name)}</a>${s.uplink ? ' · ' + esc(s.uplink) : ''}` : 'Internet / belum diatur')}</dl>
 <div class="note">Port terpakai kamera: ${kids.length}${s.nports ? ' dari ' + s.nports : ''}</div>
 <div class="ports">${kids.map(k => `<div><code>${esc(k.port || '?')}</code> <a href="#" data-cam="${k.cam.id}">${esc(k.cam.name)}</a> <span class="note">${esc(k.cam.ip)}</span></div>`).join('') || '<span class="note">Belum ada kamera.</span>'}</div>
 ${U.mode === 'edit' ? `<div style="margin-top:12px"><button class="btn dng" id="delsw">${ic('trash')} Hapus titik dari peta</button></div><p class="note">Data switch, IP dan port diatur di menu Aset / Jaringan.</p>` : ''}`;
 bindGo(b); bindCams(b);
 if ($('#delsw')) $('#delsw').onclick = async () => { try { await api('point_delete', {id:p.id}); D.pts = D.pts.filter(x => x.id !== p.id); U.sel = null; renderAll(); toast('Titik dihapus'); } catch (e) { toast(e.message); } };
}
function planDetail(b, p){
 const edit = U.mode === 'edit';
 b.innerHTML = `<h3>${esc(p.name || 'Rencana')}</h3><span class="badge" style="background:#ede9fe;color:#6d28d9">Rencana pemasangan</span>`
  + (edit ? `<label class="f">Nama rencana<input type="text" data-f="name" value="${esc(p.name)}" maxlength="100"></label><label class="f">Nomor di peta<input type="text" data-f="label" value="${esc(p.label)}" maxlength="12"></label><label class="f">Arah kamera: <span id="vAng">${p.ang}</span>°<input type="range" min="0" max="359" data-f="ang" data-n="1" value="${p.ang}"></label>
  <label class="f">Sudut pandang: <span id="vFov">${p.fov}</span>°<input type="range" min="20" max="360" step="10" data-f="fov" data-n="1" value="${p.fov}"></label>
  <label class="f">Jarak pandang<input type="range" min="15" max="120" data-f="rng" data-n="1" data-k="1000" value="${Math.round(p.rng * 1000)}"></label>
  <label class="f">Catatan (mis. alasan, kabel, tinggi pemasangan)<textarea data-f="note" rows="4">${esc(p.note)}</textarea></label>
  <div style="display:flex;gap:8px"><button class="btn dng" id="delp">${ic('trash')} Hapus rencana</button><span class="note" style="align-self:center">Tersimpan otomatis</span></div>`
  : `<dl>${dd('Nomor', esc(p.label || '-'))}${dd('Arah / sudut', p.ang + '° / ' + p.fov + '°')}${dd('Jarak pandang', Math.round(p.rng * 1000))}${dd('Catatan', esc(p.note || '-'))}</dl><p class="note">Titik ini baru rencana, belum dihitung sebagai CCTV. Area pandang ditampilkan ungu putus-putus. Untuk mengubah, buka mode Edit posisi.</p>`);
 b.querySelectorAll('[data-f]').forEach(el => el.addEventListener('input', () => { let v = el.value; if (el.dataset.n) v = +v / (+el.dataset.k || 1); p[el.dataset.f] = v; if (el.dataset.f === 'ang' && $('#vAng')) $('#vAng').textContent = p.ang; if (el.dataset.f === 'fov' && $('#vFov')) $('#vFov').textContent = p.fov; savePoint(p, true); renderMap(); renderLegend(); }));
 if ($('#delp')) $('#delp').onclick = async () => { try { await api('point_delete', {id:p.id}); D.pts = D.pts.filter(x => x.id !== p.id); U.sel = null; renderAll(); toast('Rencana dihapus'); } catch (e) { toast(e.message); } };
}
function bindCams(b){ b.querySelectorAll('[data-cam]').forEach(a => a.onclick = e => { e.preventDefault(); e.stopPropagation(); const cp = camPts().find(x => +x.asset === +a.dataset.cam); if (!cp) { toast('Kamera ini belum ditempatkan di peta ini'); return; } U.sel = cp.id; U.tab = 'detail'; renderStabs(); focusOn(cp.x, cp.y); renderMap(); renderSide(); }); }
function listTab(b){
 const arr = camPts().filter(visible).sort((a, c) => (parseInt(a.label) || 9999) - (parseInt(c.label) || 9999) || pname(a).localeCompare(pname(c)));
 b.innerHTML = stats() + `<div class="list">${arr.map(p => { const i = info(p) || {}; const s = swOfCam(p), l = linkOf(p); return `<div class="it" data-id="${p.id}"><i class="dot" style="background:${camColor(p)}"></i><div style="flex:1;min-width:0"><b>${p.label ? '#' + esc(p.label) + ' ' : ''}${esc(pname(p))}</b><small>${esc(i.ip || 'tanpa IP')} · ${fmtDate(p.date)}</small><small>${s ? esc(s.name) + ' · ' + esc(l.port || '?') : 'Belum dihubungkan'}</small></div>${pst(p) === 'off' ? '<span class="badge off">Mati</span>' : ''}</div>`; }).join('') || '<p class="note">Belum ada titik yang cocok dengan filter.</p>'}</div>`;
 b.querySelectorAll('.it').forEach(i => i.onclick = () => { const p = ptById(+i.dataset.id); U.sel = p.id; U.tab = 'detail'; renderStabs(); focusOn(p.x, p.y); renderMap(); renderSide(); });
}
const openTopo = {};
function topoTab(b){
 const nets = D.nets, kidsOf = id => Object.values(nets).filter(n => +n.parent === +id);
 const camsOf = id => Object.keys(D.links).filter(k => +D.links[k].parent === +id && D.cams[k]).map(k => ({cam:D.cams[k], port:D.links[k].port})).sort((a, c) => portNum(a.port) - portNum(c.port));
 const placedCam = aid => camPts().find(p => +p.asset === +aid);
 const node = (s, depth) => {
  if (depth > 12) return '';
  const cams = camsOf(s.id), sp = swPointOf(s.id), open = openTopo[s.id] ?? cams.some(c => { const cp = placedCam(c.cam.id); return cp && cp.id === U.sel; });
  let h = `<li><div class="node click ${sp && U.sel === sp.id ? 'sel' : ''}" data-sw="${s.id}"><b>${esc(s.name)}</b> ${cams.length ? `<span class="badge">${cams.length}${s.nports ? '/' + s.nports : ''} kamera</span>` : ''}${s.uplink ? ` <span class="note">via ${esc(s.uplink)}</span>` : ''}${sp ? '' : ' <span class="note">(belum di peta ini)</span>'}${!sp && U.mode === 'edit' ? ` <a href="#" data-place="${s.id}">Tempatkan</a>` : ''}</div>`;
  if (cams.length) h += `<details ${open ? 'open' : ''} data-d="${s.id}"><summary class="note" style="cursor:pointer;margin-left:6px">Kamera di perangkat ini</summary><div class="ports" style="margin-left:8px">${cams.map(c => { const cp = placedCam(c.cam.id); return `<div><code>${esc(c.port || '?')}</code><i class="dot" style="background:${cp ? camColor(cp) : '#cbd5e1'};width:10px;height:10px"></i>${cp ? `<a href="#" data-cam="${c.cam.id}">${esc(c.cam.name)}</a>` : `<span>${esc(c.cam.name)}</span> <span class="note">(belum di peta ini)</span>`}</div>`; }).join('')}</div></details>`;
  const k = kidsOf(s.id); if (k.length) h += `<ul class="tree">${k.map(x => node(x, depth + 1)).join('')}</ul>`;
  return h + '</li>';
 };
 const roots = Object.values(nets).filter(s => !s.parent || !nets[s.parent]);
 const noLink = camPts().filter(p => p.asset && !linkOf(p));
 b.innerHTML = `<p class="note" style="margin-top:0">Susunan ini sama dengan topologi di menu Jaringan: kamera yang Anda hubungkan ke switch dan port di peta langsung tampil di sini (dan sebaliknya).</p>
 <ul class="tree root"><li><div class="node"><b>Internet / ISP</b></div><ul class="tree">${roots.map(s => node(s, 0)).join('') || '<li class="note">Belum ada perangkat jaringan di data aset.</li>'}</ul></li></ul>
 ${noLink.length ? `<div class="warn"><b>${noLink.length} kamera di peta ini belum dihubungkan ke switch:</b><br>${noLink.map(p => `<a href="#" data-pt="${p.id}">${p.label ? '#' + esc(p.label) + ' ' : ''}${esc(pname(p))}</a>`).join(', ')}</div>` : '<div class="note">Semua kamera di peta ini sudah terhubung ke switch.</div>'}`;
 b.querySelectorAll('[data-sw]').forEach(n => n.onclick = e => { if (e.target.closest('a')) return; goDevice(+n.dataset.sw); });
 b.querySelectorAll('[data-place]').forEach(a => a.onclick = e => { e.preventDefault(); e.stopPropagation(); U.adding = {kind:'sw', asset:+a.dataset.place}; renderBar(); renderMap(); });
 bindCams(b);
 b.querySelectorAll('[data-pt]').forEach(a => a.onclick = e => { e.preventDefault(); const p = ptById(+a.dataset.pt); U.sel = p.id; U.tab = 'detail'; renderStabs(); focusOn(p.x, p.y); renderMap(); renderSide(); });
 b.querySelectorAll('details').forEach(d => d.addEventListener('toggle', () => { openTopo[d.dataset.d] = d.open; }));
}

/* ---------- Dialog ---------- */
function ask(title, body, btns){
 return new Promise(res => { const m = document.createElement('div'); m.className = 'cm-modal';
  m.innerHTML = `<div class="box"><h3>${title}</h3><div class="note" style="font-size:14px">${body}</div><div class="acts">${btns.map((t, i) => `<button class="btn ${i === btns.length - 1 ? 'pri' : ''}" data-i="${i}">${t}</button>`).join('')}</div></div>`;
  document.body.appendChild(m); m.querySelectorAll('button').forEach(b => b.onclick = () => { m.remove(); res(+b.dataset.i); }); });
}

/* ---------- Upload PDF / gambar ---------- */
function openUpload(){
 const m = document.createElement('div'); m.className = 'cm-modal'; const cur = curMap();
 m.innerHTML = `<div class="box"><h3>Upload layout CCTV</h3>
  <label class="f">File layout (PDF, JPG atau PNG)<input type="file" id="upF" accept=".pdf,application/pdf,image/png,image/jpeg"></label>
  <label class="f">Nama peta<input type="text" id="upName" placeholder="mis. Layout Pabrik Update 06 Nov 2026" value=""></label>
  ${cur ? `<div class="rad"><input type="radio" name="upMode" value="new" id="upM1" checked><label for="upM1">Buat peta baru</label></div>
  <div class="rad"><input type="radio" name="upMode" value="keep" id="upM2"><label for="upM2">Ganti layout peta <b>${esc(cur.name)}</b>, titik tetap di posisi yang sama <span class="note">(cocok untuk revisi layout)</span></label></div>
  <div class="rad"><input type="radio" name="upMode" value="clear" id="upM3"><label for="upM3">Ganti layout peta <b>${esc(cur.name)}</b> dan kosongkan semua titiknya</label></div>` : ''}
  <p class="note" id="upMsg">PDF dengan beberapa halaman: Anda bisa memilih halamannya. PDF dirender di browser, jadi tidak perlu aplikasi tambahan.</p>
  <div class="acts"><button class="btn" id="upNo">Batal</button><button class="btn pri" id="upOk">Upload</button></div></div>`;
 document.body.appendChild(m);
 m.querySelector('#upNo').onclick = () => m.remove();
 m.querySelector('#upOk').onclick = async () => {
  const f = m.querySelector('#upF').files[0]; if (!f) { toast('Pilih file dulu'); return; }
  const mode = cur ? (m.querySelector('input[name=upMode]:checked').value) : 'new';
  const name = m.querySelector('#upName').value.trim() || f.name.replace(/\.[^.]+$/, '');
  const ok = m.querySelector('#upOk'); ok.disabled = true; const msg = m.querySelector('#upMsg');
  try {
   msg.textContent = 'Membaca file...';
   const blob = await fileToImageBlob(f, m);
   msg.textContent = 'Mengunggah...';
   const files = {image:[blob, 'map.jpg']}; if (f.type === 'application/pdf' || /\.pdf$/i.test(f.name)) files.pdf = [f, f.name];
   const j = mode === 'new' ? await api('map_create', {name}, files) : await api('map_replace', {id:cur.id, keep:mode === 'keep' ? '1' : '0', name:m.querySelector('#upName').value.trim()}, files);
   location.href = 'cctv_map.php?m=' + j.id;
  } catch (e) { ok.disabled = false; msg.textContent = 'Gagal: ' + e.message; msg.style.color = '#dc2626'; }
 };
}
async function fileToImageBlob(f, host){
 const MAXS = 3600;
 if (f.type.startsWith('image/') && !/pdf/i.test(f.type)) {
  const url = URL.createObjectURL(f); const im = await new Promise((r, j) => { const i = new Image(); i.onload = () => r(i); i.onerror = () => j(new Error('Gambar tidak bisa dibaca')); i.src = url; });
  const sc = Math.min(1, MAXS / Math.max(im.naturalWidth, im.naturalHeight)); const cv = document.createElement('canvas'); cv.width = Math.round(im.naturalWidth * sc); cv.height = Math.round(im.naturalHeight * sc);
  const cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height); cx.drawImage(im, 0, 0, cv.width, cv.height); URL.revokeObjectURL(url);
  return await new Promise(r => cv.toBlob(r, 'image/jpeg', .9));
 }
 let pdfjs; try { pdfjs = await import('./assets/js/pdfjs/pdf.min.js'); } catch (e) { throw new Error('Pembaca PDF gagal dimuat (assets/js/pdfjs). Coba upload sebagai gambar JPG/PNG.'); }
 pdfjs.GlobalWorkerOptions.workerSrc = 'assets/js/pdfjs/pdf.worker.min.js';
 const pdf = await pdfjs.getDocument({data:await f.arrayBuffer()}).promise;
 let pg = 1;
 if (pdf.numPages > 1) {
  const m = document.createElement('div'); m.className = 'cm-modal';
  m.innerHTML = `<div class="box"><h3>PDF memiliki ${pdf.numPages} halaman</h3><label class="f">Pakai halaman ke<input type="number" id="pgn" min="1" max="${pdf.numPages}" value="1"></label><div class="acts"><button class="btn pri" id="pgok">Lanjut</button></div></div>`;
  document.body.appendChild(m);
  pg = await new Promise(r => m.querySelector('#pgok').onclick = () => { const v = Math.max(1, Math.min(pdf.numPages, +m.querySelector('#pgn').value || 1)); m.remove(); r(v); });
 }
 const page = await pdf.getPage(pg); const v0 = page.getViewport({scale:1}); const sc = Math.min(MAXS / v0.width, MAXS / v0.height); const vp = page.getViewport({scale:sc});
 const cv = document.createElement('canvas'); cv.width = Math.round(vp.width); cv.height = Math.round(vp.height);
 const cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height);
 await page.render({canvasContext:cx, viewport:vp}).promise;
 return await new Promise(r => cv.toBlob(r, 'image/jpeg', .9));
}

/* ---------- Impor titik dari nomor di PDF ---------- */
/* Pasang titik tepat di ikon kamera (lingkaran kuning berlogo kamera) yang berdekatan dengan lencana nomor, plus arah dari panah merah. */
function snapIcons(cv, labels){
 const W = cv.width, H = cv.height, d = cv.getContext('2d', {willReadFrequently:true}).getImageData(0, 0, W, H).data;
 const blobs = (test, minN) => {
  const seen = new Uint8Array(W * H), out = [], st = new Int32Array(W * H);
  for (let i = 0; i < W * H; i++) {
   if (seen[i]) continue; const o = i * 4; if (!test(d[o], d[o + 1], d[o + 2])) continue;
   let sp = 0, n = 0, x0 = W, x1 = 0, y0 = H, y1 = 0; st[sp++] = i; seen[i] = 1;
   while (sp) { const p = st[--sp], x = p % W, y = (p / W) | 0; n++; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
    for (let k = 0; k < 4; k++) { const nx = x + (k === 0) - (k === 1), ny = y + (k === 2) - (k === 3); if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; const q = ny * W + nx; if (seen[q]) continue; const oq = q * 4; if (test(d[oq], d[oq + 1], d[oq + 2])) { seen[q] = 1; st[sp++] = q; } } }
   if (n >= minN) out.push({n, x0, x1, y0, y1, cx:(x0 + x1) / 2, cy:(y0 + y1) / 2, w:x1 - x0 + 1, h:y1 - y0 + 1});
  }
  return out;
 };
 const yel = blobs((r, g, b) => r > 200 && g > 160 && b < 130 && r - b > 100, 60).filter(b => b.w >= 10 && b.w <= 90 && b.h >= 10 && b.h <= 90 && b.w / b.h > .65 && b.w / b.h < 1.55);
 const red = blobs((r, g, b) => r > 190 && g < 110 && b < 110, 12).filter(b => b.w < 70 && b.h < 70);
 const L = labels.map(l => ({n:l.n, px:l.x * W, py:l.y * H}));
 // lencana nomor = blob kuning yang memuat titik teks nomor (atau terdekat)
 const badge = {}; const isBadge = new Set();
 L.forEach(l => { let best = null, bd = Infinity; yel.forEach(b => { const inside = l.px >= b.x0 - 2 && l.px <= b.x1 + 2 && l.py >= b.y0 - 2 && l.py <= b.y1 + 2; const dd = Math.hypot(b.cx - l.px, b.cy - l.py) - (inside ? 1e6 : 0); if (dd < bd) { bd = dd; best = b; } }); if (best && Math.hypot(best.cx - l.px, best.cy - l.py) < best.w * .8) { badge[l.n] = best; isBadge.add(best); } });
 const icons = yel.filter(b => !isBadge.has(b));
 // cocokkan lencana -> ikon terdekat (satu ikon untuk satu lencana), paling dekat dulu
 const pairs = [];
 Object.keys(badge).forEach(n => icons.forEach(ic => { const b = badge[n], g = Math.hypot(ic.cx - b.cx, ic.cy - b.cy) - (b.w + ic.w) / 2; if (g < Math.max(b.w, ic.w) * 1.2) pairs.push({n:+n, ic, g}); }));
 pairs.sort((a, b) => a.g - b.g);
 const used = new Set(), done = {}, res = {};
 pairs.forEach(p => { if (done[p.n] || used.has(p.ic)) return; done[p.n] = p.ic; used.add(p.ic); });
 L.forEach(l => {
  const ic = done[l.n];
  if (!ic) { res[l.n] = {x:l.px / W, y:l.py / H, ok:false, ang:0}; return; }
  let ang = 0, bd = Infinity, ar = null;
  red.forEach(a => { const dd = Math.hypot(a.cx - ic.cx, a.cy - ic.cy); if (dd < ic.w * 3 && dd < bd) { bd = dd; ar = a; } });
  if (ar) { ang = Math.atan2(ar.cx - ic.cx, -(ar.cy - ic.cy)) * 180 / Math.PI; if (ang < 0) ang += 360; ang = Math.round(ang); }
  res[l.n] = {x:ic.cx / W, y:ic.cy / H, ok:true, ang, arrow:!!ar};
 });
 return res;
}

function findLegendRect(pdfjs, vp, tc){
 let legend = null;
 try {
  const all = tc.items.map(it => ({s:(it.str || '').trim(), tr:pdfjs.Util.transform(vp.transform, it.transform), w:it.width, h:Math.hypot(it.transform[2], it.transform[3]) || it.height})).filter(a => a.s);
  const hd = all.find(a => /QUANTITY/i.test(a.s));
  if (hd) { const hx = hd.tr[4] + hd.w / 2;
   const tot = all.filter(a => /^TOTAL/i.test(a.s) && a.tr[5] > hd.tr[5] && a.tr[5] - hd.tr[5] < 260 && Math.abs(a.tr[4] - hx) < 160).sort((a, b) => a.tr[5] - b.tr[5])[0];
   if (tot) { const inb = all.filter(a => a.tr[5] >= hd.tr[5] - 2 && a.tr[5] <= tot.tr[5] + 2 && a.tr[4] > hx - 85 && a.tr[4] < hx + 90);
    const x0 = Math.min(...inb.map(a => a.tr[4])), x1 = Math.max(...inb.map(a => a.tr[4] + a.w)), pad = 10;
    const x = Math.max(0, (x0 - pad) / vp.width), y = Math.max(0, (hd.tr[5] - hd.h - pad) / vp.height);
    legend = {x, y, w:Math.min(1 - x, (x1 - x0 + 2 * pad) / vp.width), h:Math.min(1 - y, (tot.tr[5] - hd.tr[5] + hd.h + 2 * pad + tot.h * .3) / vp.height)}; } }
 } catch (e) { legend = null; }
 return legend;
}
/* Letak kotak keterangan otomatis dari PDF peta yang tersimpan (tabel "CCTV QUANTITY"); dipakai bila belum pernah diatur. */
async function autoImport(){
 const m = curMap(); if (!m || !m.pdf || m._impAsked || mpts().length || !Object.values(D.cams).some(c => c.seq)) return; m._impAsked = true;
 try { if (localStorage.getItem('cm_imp_no_' + m.id)) return; } catch (e) {}
 try { const blob = await (await fetch(m.pdf)).blob(); if (curMap() && curMap().id === m.id && !mpts().length) await runImport(blob, true); } catch (e) {}
}
async function autoLegend(){
 const m = curMap(); if (!m || !m.pdf || D.cfg['leg_' + m.id] || m._legTried) return; m._legTried = true;
 try {
  const pdfjs = await import('./assets/js/pdfjs/pdf.min.js'); pdfjs.GlobalWorkerOptions.workerSrc = 'assets/js/pdfjs/pdf.worker.min.js';
  const pdf = await pdfjs.getDocument({data:await (await fetch(m.pdf)).arrayBuffer()}).promise;
  for (let n = 1; n <= Math.min(pdf.numPages, 5); n++) {
   const page = await pdf.getPage(n), vp = page.getViewport({scale:1});
   if (Math.abs(vp.width / vp.height / ((m.w || 1) / (m.h || 1)) - 1) > .03) continue;
   const r = findLegendRect(pdfjs, vp, await page.getTextContent());
   if (r) { setLegRect(r, true); renderMap(); return; }
  }
 } catch (e) {}
}
async function pdfNumbers(f){
 let pdfjs; try { pdfjs = await import('./assets/js/pdfjs/pdf.min.js'); } catch (e) { throw new Error('Pembaca PDF gagal dimuat (assets/js/pdfjs).'); }
 pdfjs.GlobalWorkerOptions.workerSrc = 'assets/js/pdfjs/pdf.worker.min.js';
 const pdf = await pdfjs.getDocument({data:await f.arrayBuffer()}).promise;
 let pg = 1;
 if (pdf.numPages > 1) {
  const m = document.createElement('div'); m.className = 'cm-modal';
  m.innerHTML = `<div class="box"><h3>PDF memiliki ${pdf.numPages} halaman</h3><label class="f">Ambil nomor dari halaman ke<input type="number" id="pgn" min="1" max="${pdf.numPages}" value="1"></label><div class="acts"><button class="btn pri" id="pgok">Lanjut</button></div></div>`;
  document.body.appendChild(m);
  pg = await new Promise(r => m.querySelector('#pgok').onclick = () => { const v = Math.max(1, Math.min(pdf.numPages, +m.querySelector('#pgn').value || 1)); m.remove(); r(v); });
 }
 const page = await pdf.getPage(pg); const vp = page.getViewport({scale:1}); const tc = await page.getTextContent(); const out = [];
 for (const it of tc.items) {
  const t = (it.str || '').trim(); if (!/^\d{1,3}$/.test(t)) continue;
  const h = Math.hypot(it.transform[2], it.transform[3]) || it.height; if (h < 3) continue;          // abaikan teks super kecil
  const tr = pdfjs.Util.transform(vp.transform, it.transform);
  out.push({n:parseInt(t, 10), x:(tr[4] + it.width / 2) / vp.width, y:(tr[5] - h / 2) / vp.height, h});
 }
 const legend = findLegendRect(pdfjs, vp, tc);   // tabel "CCTV QUANTITY" di PDF = tempat kotak keterangan
 const sc = Math.min(3, 3000 / vp.width), v2 = page.getViewport({scale:sc}); const cv = document.createElement('canvas'); cv.width = Math.round(v2.width); cv.height = Math.round(v2.height);
 const cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height); await page.render({canvasContext:cx, viewport:v2}).promise;
 return {items:out, aspect:vp.width / vp.height, canvas:cv, legend};
}
/* Satu nomor bisa muncul beberapa kali di PDF (legenda, tabel, nomor ruangan). Pilih yang paling dekat dengan nomor tetangganya
   (kamera bernomor berurutan biasanya berdekatan); nomor yang ragu ditandai "perlu dicek". */
function resolveNumbers(items, max){
 const all = items.filter(i => i.n >= 1 && i.n <= max);
 const by = {}; all.forEach(i => (by[i.n] = by[i.n] || []).push(i));
 const pos = {}, amb = [];
 Object.keys(by).forEach(k => { k = +k; if (by[k].length === 1) pos[k] = by[k][0]; else amb.push(k); });
 // Ukuran huruf label kamera (dari nomor yang hanya muncul sekali): teks yang lebih besar (tabel, judul) bukan label kamera.
 const sizes = [...new Set(Object.values(pos).map(p => Math.round(p.h * 10) / 10))];   // ukuran huruf yang dipakai label kamera
 amb.sort((a, b) => a - b);
 const check = new Set(amb);
 // Nomor ganda: pilih yang paling dekat dengan nomor tetangganya (kamera bernomor berurutan biasanya berdekatan).
 for (let pass = 0; pass < 3; pass++) amb.forEach(n => {
  const okh = by[n].filter(c => sizes.some(z => Math.abs(z - c.h) <= .2)), cand = okh.length ? okh : by[n];
  const nb = [n - 1, n + 1, n - 2, n + 2].map(k => pos[k]).filter(Boolean);
  let best = null, bs = Infinity;
  cand.forEach(c => { const d = nb.length ? nb.reduce((a, p) => a + Math.hypot(p.x - c.x, p.y - c.y), 0) / nb.length : 0; if (d < bs) { bs = d; best = c; } });
  pos[n] = best;
 });
 return {pos, check};
}
function importFromPdf(){
 if (!curMap()) return;
 const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.pdf,application/pdf';
 inp.onchange = () => { const f = inp.files[0]; if (f) runImport(f, false); };
 inp.click();
}
/* auto = dipicu otomatis dari PDF peta yang tersimpan (peta belum punya titik): diam bila tidak ada yang cocok, ingat bila ditolak. */
async function runImport(f, auto){
 const m0 = curMap(); if (!m0) return;
 {
  try {
   toast('Membaca nomor di PDF...');
   const r = await pdfNumbers(f);
   if (Math.abs(r.aspect / (m0.w / m0.h) - 1) > .03) { if (auto) return; } if (Math.abs(r.aspect / (m0.w / m0.h) - 1) > .03) throw new Error('Ukuran halaman PDF ini tidak sama dengan peta yang sedang dibuka. Pakai PDF yang sama dengan layout peta (atau upload PDF ini sebagai peta baru).');
   const cams = Object.values(D.cams).filter(c => c.seq); const bySeq = {}; cams.forEach(c => bySeq[c.seq] = c);
   const {pos, check} = resolveNumbers(r.items, cams.length);
   toast('Mencari ikon kamera & arahnya...');
   const snap = snapIcons(r.canvas, Object.keys(pos).map(n => ({n:+n, x:pos[n].x, y:pos[n].y})));
   const onMap = new Set(mpts().filter(p => p.kind === 'cam' && p.asset).map(p => p.asset));
   const todo = [], missing = [], exist = [];
   cams.sort((a, b) => a.seq - b.seq).forEach(c => {
    if (onMap.has(c.id)) { exist.push(c.seq); return; }
    const p = pos[c.seq]; if (!p) { missing.push(c.seq); return; }
    const sn = snap[c.seq] || {ok:false, x:p.x, y:p.y, ang:0};
    const notes = []; if (check.has(c.seq)) notes.push('nomor muncul lebih dari sekali di PDF'); if (!sn.ok) notes.push('ikon kamera tidak ditemukan, posisi dari teks nomor');
    todo.push({asset:c.id, label:String(c.seq), x:+sn.x.toFixed(5), y:+sn.y.toFixed(5), ang:sn.ang || 0, fov:70, rng:.045, note:notes.length ? 'Impor PDF: ' + notes.join('; ') + ', mohon cek posisi' : '', snapped:sn.ok, arrow:!!sn.arrow});
   });
   if (auto && !todo.length) return;
   const list = a => a.length ? a.join(', ') : '-';
   const chk = todo.filter(t => t.note).map(t => t.label), nSnap = todo.filter(t => t.snapped).length, nDir = todo.filter(t => t.arrow).length;
   const go = await ask('Impor titik dari PDF',
    `${auto ? '<p>PDF peta ini memiliki nomor kamera yang bisa dibaca, jadi titik CCTV bisa dibuat <b>otomatis mengikuti kamera di layout</b>.</p>' : ''}<p><b>${todo.length}</b> titik CCTV siap dibuat di peta <b>${esc(m0.name)}</b> (dari ${cams.length} CCTV di aplikasi).</p>
     <p style="margin-top:6px">Menempel ke ikon kamera: <b>${nSnap}</b> titik. Arah kamera terbaca dari panah merah: <b>${nDir}</b> titik.</p>
     <p style="margin-top:6px"><b>Perlu dicek setelah impor</b> (nomor ganda di PDF atau ikon kamera tidak ditemukan): ${esc(list(chk))}</p>
     <p style="margin-top:6px"><b>Tidak ditemukan di PDF</b> (tambahkan manual): ${esc(list(missing))}</p>
     ${exist.length ? `<p style="margin-top:6px"><b>Sudah ada di peta</b> (dilewati): ${esc(list(exist))}</p>` : ''}
     ${r.legend ? '<p style="margin-top:6px">Kotak <b>Keterangan</b> akan ditempatkan di tabel "CCTV QUANTITY" pada layout (menutup tabel lama), tidak di atas peta.</p>' : ''}
     <p class="note" style="margin-top:8px">Di area yang padat, ikon atau panah bisa tertukar: periksa hasilnya. Titik dan arah bisa diubah di mode Edit posisi.</p>`,
    [auto ? 'Nanti / tidak' : 'Batal', todo.length ? 'Impor ' + todo.length + ' titik' : 'Tutup']);
   if (auto && go !== 1) { try { localStorage.setItem('cm_imp_no_' + m0.id, '1'); } catch (e) {} }
   if (go !== 1 || !todo.length) return;
   toast('Membuat titik...');
   const j = await api('point_bulk', {map:m0.id, items:JSON.stringify(todo.map(({snapped, arrow, ...t}) => t))});
   if (r.legend) setLegRect(r.legend, true);
   D.pts.push(...j.points); U.sel = null; renderAll(); fit();
   toast(j.points.length + ' titik dibuat' + (j.skipped ? ', ' + j.skipped + ' dilewati' : ''));
  } catch (e) { if (!auto) toast('Gagal: ' + e.message); }
 }
}
function openMapEdit(){
 const cur = curMap(); if (!cur) return;
 const m = document.createElement('div'); m.className = 'cm-modal';
 m.innerHTML = `<div class="box"><h3>Peta ini</h3><label class="f">Nama peta<input type="text" id="meN" value="${esc(cur.name)}"></label><p class="note">Menghapus peta juga menghapus semua titiknya (data aset dan koneksi jaringan tidak ikut terhapus).</p><div class="acts"><button class="btn" id="meNo">Tutup</button><button class="btn" id="meDel" style="color:#dc2626">Hapus peta</button><button class="btn pri" id="meOk">Simpan nama</button></div></div>`;
 document.body.appendChild(m);
 m.querySelector('#meNo').onclick = () => m.remove();
 m.querySelector('#meOk').onclick = async () => { try { await api('map_rename', {id:cur.id, name:m.querySelector('#meN').value}); cur.name = m.querySelector('#meN').value.trim(); m.remove(); renderBar(); toast('Nama disimpan'); } catch (e) { toast(e.message); } };
 m.querySelector('#meDel').onclick = async () => { m.remove(); if (await ask('Hapus peta ini?', esc(cur.name) + ' dan semua titiknya akan dihapus permanen.', ['Batal', 'Hapus peta']) === 1) { try { await api('map_delete', {id:cur.id}); location.href = 'cctv_map.php'; } catch (e) { toast(e.message); } } };
}


/* Letak kotak keterangan di peta (disimpan per peta, pecahan ukuran gambar). Bawaan: pojok kiri bawah. */
function legRect(){ const m = curMap(); const v = m && D.cfg['leg_' + m.id]; if (v) { const a = String(v).split(',').map(Number); if (a.length === 4 && a.every(isFinite)) return {x:a[0], y:a[1], w:a[2], h:a[3]}; } return {x:.012, y:.69, w:.2, h:.3}; }
function setLegRect(r, save){
 const m = curMap(); r.w = Math.max(.05, Math.min(1, r.w)); r.h = Math.max(.05, Math.min(1, r.h)); r.x = Math.max(0, Math.min(1 - r.w, r.x)); r.y = Math.max(0, Math.min(1 - r.h, r.y));
 const v = [r.x, r.y, r.w, r.h].map(n => +n.toFixed(5)).join(','); D.cfg['leg_' + m.id] = v;
 if (save) api('cfg', {k:'leg_' + m.id, v}).catch(e => toast(e.message));
}
function legendSvg(){
 const R = legRect(), L = legendData(), x = R.x * IW, y = R.y * IH, w = R.w * IW, h = R.h * IH, n = L.rows.length + 2;
 const lh = Math.min(h / n, w / 7), maxLen = Math.max(...L.rows.map(r => r.label.length), 10), fs = Math.min(lh * .52, (w - lh * 2.3) / (maxLen * .56)), hd = '#1f3a5f', tx = '#0f172a', ff = 'font-family="Arial,Helvetica,sans-serif"';
 let g = `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#fff" stroke="#94a3b8" stroke-width="${lh * .04}"/><rect x="${x}" y="${y}" width="${w}" height="${lh}" fill="${hd}"/><text x="${x + w / 2}" y="${y + lh * .66}" text-anchor="middle" font-size="${fs * 1.15}" ${ff} font-weight="700" fill="#fff">KETERANGAN</text>`;
 L.rows.forEach((r, i) => { const cy = y + lh * (i + 1) + lh / 2;
  g += `<circle cx="${x + lh * .6}" cy="${cy}" r="${lh * .24}" fill="${r.dash ? '#fff' : r.col}" stroke="${r.dash ? r.col : '#475569'}" stroke-width="${lh * (r.dash ? .06 : .03)}" ${r.dash ? `stroke-dasharray="${lh * .1} ${lh * .07}"` : ''}/><text x="${x + lh * 1.05}" y="${cy + fs * .35}" font-size="${fs}" ${ff} fill="${tx}">${esc(r.label)}</text><text x="${x + w - lh * .45}" y="${cy + fs * .35}" text-anchor="end" font-size="${fs * 1.1}" ${ff} font-weight="700" fill="${tx}">${r.n}</text><line x1="${x + lh * .3}" x2="${x + w - lh * .3}" y1="${cy + lh / 2}" y2="${cy + lh / 2}" stroke="#e2e8f0" stroke-width="${lh * .02}"/>`; });
 const fy = y + lh * (L.rows.length + 1);
 g += `<rect x="${x}" y="${fy}" width="${w}" height="${lh}" fill="${hd}"/><text x="${x + w / 2}" y="${fy + lh * .66}" text-anchor="middle" font-size="${fs * 1.1}" ${ff} font-weight="700" fill="#fff">TOTAL CCTV : ${L.total}</text>`;
 return `<g>${g}</g>`;
}
/* Kotak hijau putus-putus di mode Edit: seret untuk memindah, tarik pegangan untuk mengubah ukuran. Dipakai saat cetak / PDF / PNG. */
function legBoxSvg(){
 if (U.mode !== 'edit' || !curMap()) return '';
 const R = legRect(), x = R.x * IW * V.s + V.tx, y = R.y * IH * V.s + V.ty, w = R.w * IW * V.s, h = R.h * IH * V.s;
 return `<g><rect data-k="leg" x="${x}" y="${y}" width="${w}" height="${h}" fill="#16a34a" fill-opacity=".14" stroke="#16a34a" stroke-width="2.5" stroke-dasharray="7 5" style="cursor:move"/><text x="${x + 8}" y="${y + 18}" font-size="12" font-weight="700" fill="#15803d" style="pointer-events:none">Letak keterangan (cetak / PDF / PNG)</text><rect data-k="legrs" x="${x + w - 14}" y="${y + h - 14}" width="14" height="14" fill="#16a34a" style="cursor:nwse-resize"/></g>`;
}
/* ---------- Ekspor: PNG / Cetak A4-A3 / PDF ---------- */
function overlaySvg(cw, ch){
 const k = IW / 1500, P = (x, y) => [x * IW, y * IH];
 const saved = U.sel; U.sel = null;
 const body = underSvg(IW, IH, true) + markersSvg(P, k, false); U.sel = saved;
 const date = new Date().toLocaleDateString('id-ID', {day:'2-digit', month:'long', year:'numeric'});
 const leg = legendSvg();
 return `<svg xmlns="http://www.w3.org/2000/svg" width="${cw}" height="${ch}" viewBox="0 0 ${IW} ${IH}">${body}${leg}</svg>`;
}
async function renderExportCanvas(maxSide){
 const m = curMap(); if (!m) throw new Error('Belum ada peta');
 await autoLegend();
 const base = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Gambar peta gagal dimuat')); i.src = m.url + '?x=' + Date.now(); });
 const sc = Math.min(1, maxSide / Math.max(IW, IH)); const cw = Math.round(IW * sc), ch = Math.round(IH * sc);
 const cv = document.createElement('canvas'); cv.width = cw; cv.height = ch; const cx = cv.getContext('2d');
 cx.fillStyle = '#fff'; cx.fillRect(0, 0, cw, ch); cx.drawImage(base, 0, 0, cw, ch);
 const ov = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Titik gagal digambar')); i.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(overlaySvg(cw, ch)); });
 cx.drawImage(ov, 0, 0, cw, ch);
 return cv;
}
const mapTitle = () => 'Map CCTV - ' + (curMap() ? curMap().name : '');
function docRows(){
 const cams = camPts().slice().sort((a, b) => (parseInt(a.label) || 9999) - (parseInt(b.label) || 9999) || a.id - b.id);
 return cams.map(p => { const i = info(p), l = linkOf(p), sw = l && D.nets[l.parent], g = grp(p), nv = i && i.nvr ? nvrById(i.nvr) : null;
  return {no:p.label || '', name:(i && i.name) || p.name || (p.asset ? '' : 'Dummy'), ip:(i && i.ip) || '-', nvr:nv ? nv.name : (g === 'dummy' ? 'Dummy' : '-'), ch:(i && i.ch) || '-',
   sw:sw ? sw.name + (l.port ? ' / ' + l.port : '') : '-', date:fmtDate(p.date), st:g === 'dummy' ? 'Dummy' : ({on:'Online', off:'Offline'}[pst(p)] || '-')}; });
}
function docSummary(){ const L = legendData(); return L.total + ' CCTV (' + L.rows.filter(r => r.n).map(r => r.label.replace(/ \(.*\)/, '') + ': ' + r.n).join(', ') + ')'; }
const docFields = (c, mime) => ({paper:U.paper, title:mapTitle(), rows:JSON.stringify(docRows()), summary:docSummary(), plans:JSON.stringify(U.showPlan ? planPts().slice().sort((a, b) => (parseInt(String(a.label).replace(/\D/g, '')) || 9999) - (parseInt(String(b.label).replace(/\D/g, '')) || 9999)).map(p => ({no:p.label || '', name:p.name || '', note:p.note || ''})) : [])});
async function exportPng(){ try { toast('Menyiapkan PNG...'); const c = await renderExportCanvas(4000); const a = document.createElement('a'); a.download = 'map-cctv.png'; a.href = c.toDataURL('image/png'); document.body.appendChild(a); a.click(); a.remove(); toast('PNG diunduh'); } catch (e) { toast(e.message); } }
async function exportPdf(){
 try { toast('Membuat PDF ' + U.paper + '...'); const c = await renderExportCanvas(U.paper === 'A3' ? 4200 : 3200);
  const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', .9));
  const res = await api('export_pdf', docFields(), {image:[blob, 'map.jpg']});
  const a = document.createElement('a'); a.href = URL.createObjectURL(res); a.download = 'Map-CCTV-' + (curMap().name.replace(/[^A-Za-z0-9_-]+/g, '-')) + '-' + U.paper + '.pdf'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); toast('PDF ' + U.paper + ' diunduh');
 } catch (e) { toast('Gagal membuat PDF: ' + e.message); }
}
async function printMap(){
 try { const win = window.open('', '_blank'); if (!win) { toast('Popup diblokir browser'); return; }
  const c = await renderExportCanvas(U.paper === 'A3' ? 4200 : 3200);
  const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', .92));
  const html = await api('export_pdf', Object.assign(docFields(), {mode:'html'}), {image:[blob, 'map.jpg']});
  win.document.open(); win.document.write(html); win.document.close();
 } catch (e) { toast(e.message); }
}

/* ---------- Mulai ---------- */
function renderAll(){ renderBar(); renderStabs(); renderMap(); renderLegend(); renderSide(); }
window.addEventListener('resize', () => renderMap());
(function(){
 const q = +new URLSearchParams(location.search).get('m'); if (q && D.maps.some(m => m.id === q)) U.mapId = q;
 renderZoom(); loadMapImage();
 setTimeout(fit, 120);
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
