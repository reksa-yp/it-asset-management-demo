<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/categories.php';
require_once __DIR__ . '/includes/damage.php';
require_once __DIR__ . '/includes/asset_accessories.php';
require_once __DIR__ . '/includes/asset_number.php';

$db = getDB();
ensureAssetAccessoriesTable($db); // tabel BARU asset_accessories (Nama + Brand/Type), dibuat jika belum ada
ensureTabletTable($db); // tabel BARU asset_tablet_details (ID Tablet & Status Condition), dibuat jika belum ada
$users = $db->query("SELECT id, full_name, email, department, pc_username, pc_password FROM users WHERE is_active = 1 ORDER BY full_name")->fetchAll();
// Jabatan user (tabel user_positions) ikut tampil di data aset, sama seperti Departement/Email.
$userPositionMap = getUserPositionMap($db);
foreach ($users as &$uPos) { $uPos['position'] = $userPositionMap[(int)$uPos['id']] ?? ''; }
unset($uPos);

// Hasil scan QR (alamat scan.php?no=... dari scanner USB) -> diambil nomor asetnya saja.
require_once __DIR__ . '/includes/scan.php';
require_once __DIR__ . '/includes/remote.php';   // tombol Remote VNC per aset
$search = scanExtractAssetNumber((string)($_GET['q'] ?? ''));

// ===== Filter Jenis & Departement =====
// Keduanya hanya membaca data yang sudah ada, tidak butuh kolom/tabel baru.
$filterCategory   = trim($_GET['category'] ?? '');
$filterDepartment = trim($_GET['department'] ?? '');
$filterLocation   = trim($_GET['location'] ?? '');
// Daftar lokasi diambil dari data aset yang ada (tanpa tabel master baru).
$locationOptions = $db->query(
    "SELECT DISTINCT TRIM(location) AS loc FROM assets WHERE location IS NOT NULL AND TRIM(location) <> '' ORDER BY loc"
)->fetchAll(PDO::FETCH_COLUMN);

// Daftar departement diambil dari data yang benar-benar ada (aset + user),
// jadi isinya otomatis mengikuti database, tanpa perlu tabel master baru.
$departmentOptions = $db->query(
    "SELECT DISTINCT department FROM (
        SELECT department FROM assets WHERE department IS NOT NULL AND department <> ''
        UNION
        SELECT department FROM users  WHERE department IS NOT NULL AND department <> ''
     ) d ORDER BY department"
)->fetchAll(PDO::FETCH_COLUMN);

// ===== Pagination =====
// Default tampilan: "Tampilkan Semua" (tanpa LIMIT). Admin tetap bisa memilih
// jumlah per halaman (10/50/100) lewat dropdown di bawah tabel.
$allowedPerPage = [10, 50, 100];
$perPageParam = $_GET['per_page'] ?? 'all';
if ($perPageParam === 'all') {
    $perPage = 'all';
} else {
    $perPage = (int)$perPageParam;
    if (!in_array($perPage, $allowedPerPage, true)) $perPage = 'all';
}
$page = max(1, (int)($_GET['page'] ?? 1));

$conditions = [];
$params = [];

if ($search !== '') {
    // Dibungkus kurung supaya tidak bentrok dengan filter AND di bawahnya.
    // Pencarian nama pengguna sekarang lewat tabel asset_owners (1 aset bisa
    // dipakai beberapa pengguna), pakai EXISTS supaya tetap 1 baris per aset.
    // Tabel asset_owners baru ada setelah migrasi "Multi Pengguna Aset" dijalankan
    // (menu Upgrade Sistem); sebelum itu pencarian nama pengguna dilewati saja.
    if (assetOwnersTableExists($db)) {
        $conditions[] = "(a.asset_number LIKE ? OR a.device_name LIKE ? OR a.hostname LIKE ?
            OR EXISTS (SELECT 1 FROM asset_owners ao JOIN users u2 ON u2.id = ao.user_id
                        WHERE ao.asset_id = a.id AND u2.full_name LIKE ?))";
        $like = "%$search%";
        array_push($params, $like, $like, $like, $like);
    } else {
        $conditions[] = "(a.asset_number LIKE ? OR a.device_name LIKE ? OR a.hostname LIKE ?)";
        $like = "%$search%";
        array_push($params, $like, $like, $like);
    }
}
// Pencarian juga mencakup ID Tablet (tabel asset_tablet_details).
if ($search !== '' && tabletTableExists($db)) {
    $lastSearchCond = array_pop($conditions);
    $conditions[] = '(' . $lastSearchCond . ' OR EXISTS (SELECT 1 FROM asset_tablet_details td WHERE td.asset_id = a.id AND td.tablet_id LIKE ?))';
    $params[] = "%$search%";
}
if ($filterCategory !== '') {
    $conditions[] = "a.category = ?";
    $params[] = $filterCategory;
}
if ($filterDepartment !== '') {
    $conditions[] = "a.department = ?";
    $params[] = $filterDepartment;
}
if ($filterLocation !== '') {
    $conditions[] = "TRIM(a.location) = ?";
    $params[] = $filterLocation;
}

$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';

// Hitung total data (dengan filter pencarian yang sama) untuk menentukan jumlah halaman
$countSql = "SELECT COUNT(*) FROM assets a" . $where;
$countStmt = $db->prepare($countSql);
$countStmt->execute($params);
$totalAssets = (int)$countStmt->fetchColumn();
if ($perPage === 'all') {
    $totalPages = 1;
    $page = 1;
    $offset = 0;
    $limitClause = '';
} else {
    $totalPages = max(1, (int)ceil($totalAssets / $perPage));
    if ($page > $totalPages) $page = $totalPages;
    $offset = ($page - 1) * $perPage;
    $limitClause = "LIMIT $perPage OFFSET $offset";
}

$sql = "SELECT a.* FROM assets a" . $where . "
        ORDER BY a.created_at DESC
        $limitClause";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$assetList = $stmt->fetchAll();

// Pengguna tiap aset (bisa lebih dari satu), diambil sekaligus untuk seluruh
// baris yang tampil supaya tidak query berulang per baris.
$ownersMap = getAssetOwnersMap($db, array_column($assetList, 'id'));
// Daftar software tiap aset (bisa lebih dari satu), diambil sekaligus juga.
$softwareMap = getAssetSoftwareMap($db, array_column($assetList, 'id'));
// Detail khusus tablet (ID Tablet & Status Condition), diambil sekaligus.
$tabletMap = getTabletDetailsMap($db, array_column($assetList, 'id'));
// Aset yang sedang tercatat rusak (menu Aset Rusak) -> badge "Rusak" di kolom Status.
$damageMap = getOpenDamageMap($db, array_column($assetList, 'id'));
// Aksesoris tiap aset (Nama + Brand/Type, bisa lebih dari satu).
$accessoryMap = getAccessoryItemsForAssets($db, $assetList);
foreach ($assetList as &$aRow) {
    $aRow['damage_state'] = $damageMap[$aRow['id']]['state'] ?? '';
    $aRow['tablet_id']        = $tabletMap[$aRow['id']]['tablet_id'] ?? '';
    $aRow['tablet_condition'] = $tabletMap[$aRow['id']]['tablet_condition'] ?? 'Bagus';
    $owners = $ownersMap[$aRow['id']] ?? [];
    $aRow['owner_names'] = ownerNamesLabel($owners);
    $aRow['owner_positions'] = ownerPositionsLabel($owners, $userPositionMap);
    $aRow['owner_ids']   = array_column($owners, 'id');
    $aRow['software_items'] = $softwareMap[$aRow['id']] ?? [];
    $aRow['accessory_items'] = $accessoryMap[(int)$aRow['id']] ?? [];
}
unset($aRow);

// Bangun URL halaman (mempertahankan q, filter, & per_page yang sedang aktif)
function assetPageUrl(string $search, $perPage, int $p, string $category = '', string $department = ''): string {
    global $filterLocation;
    $q = ['per_page' => $perPage, 'page' => $p];
    if (($filterLocation ?? '') !== '') $q['location'] = $filterLocation;
    if ($search !== '')     $q['q'] = $search;
    if ($category !== '')   $q['category'] = $category;
    if ($department !== '') $q['department'] = $department;
    return '?' . http_build_query($q);
}

// Filter Jenis = Tablet -> tabel memakai kolom khusus tablet.
$isTabletView = isTabletCategory($filterCategory);

$isFiltered = ($search !== '' || $filterCategory !== '' || $filterDepartment !== '' || $filterLocation !== '');

// Kategori aset sekarang bisa dikustomisasi admin lewat menu Kategori Aset
// (tabel asset_categories), bukan daftar tetap lagi. Kategori aset lama yang
// namanya sudah tidak ada di daftar tetap tampil apa adanya (fallback ke nilai asli).
$categoryRows   = getAssetCategories($db);
// Jumlah aset per Jenis x Departement (untuk jendela Export: pilih beberapa Jenis & Departement).
// Saat filter Lokasi aktif, export ikut dibatasi lokasi itu, jadi jumlahnya juga dihitung per lokasi tersebut.
$emStmt = $db->prepare("SELECT category, COALESCE(department,'') AS department, COUNT(*) AS total FROM assets"
    . ($filterLocation !== '' ? " WHERE TRIM(location) = ?" : "") . " GROUP BY category, COALESCE(department,'')");
$emStmt->execute($filterLocation !== '' ? [$filterLocation] : []);
$exportMatrix = $emStmt->fetchAll();
$categoryCounts = [];
$departmentCounts = [];
foreach ($exportMatrix as $em) {
    $categoryCounts[$em['category']] = ($categoryCounts[$em['category']] ?? 0) + (int)$em['total'];
    $departmentCounts[$em['department']] = ($departmentCounts[$em['department']] ?? 0) + (int)$em['total'];
}
// Departement yang punya aset (untuk pilihan export).
$exportDepartments = array_values(array_filter(array_keys($departmentCounts), fn($d) => $d !== ''));
sort($exportDepartments);
$categories     = array_column($categoryRows, 'name');
$categoryLabels = array_combine($categories, $categories);
$statuses   = ['Digunakan','Stok','Tidak Digunakan'];
$statusLabels = [
    'Digunakan'       => t('status_used'),
    'Stok'            => t('status_stock'),
    'Tidak Digunakan' => t('status_unused'),
];

$bulkMsg = $_SESSION['asset_bulk_msg'] ?? null;
unset($_SESSION['asset_bulk_msg']);

$importMsg = $_SESSION['import_msg'] ?? null;
unset($_SESSION['import_msg']);

$pageTitle = t('page_title_assets');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="bg-white rounded-xl shadow-sm px-3 py-3 mb-4">
<div class="flex flex-wrap items-center justify-between gap-3">
    <form method="get" class="flex flex-wrap items-center gap-2">
        <input type="hidden" name="per_page" value="<?= htmlspecialchars((string)$perPage) ?>">
        <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="<?= htmlspecialchars(t('search_placeholder')) ?>"
               class="border rounded-lg px-3 py-2 text-sm w-56">

        <select name="category" onchange="this.form.submit()" class="border rounded-lg px-3 py-2 text-sm">
            <option value=""><?= t('filter_all_types') ?></option>
            <?php foreach ($categories as $c): ?>
                <option value="<?= htmlspecialchars($c) ?>" <?= $filterCategory === $c ? 'selected' : '' ?>>
                    <?= htmlspecialchars($categoryLabels[$c] ?? $c) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <select name="department" onchange="this.form.submit()" class="border rounded-lg px-3 py-2 text-sm">
            <option value=""><?= t('filter_all_departments') ?></option>
            <?php foreach ($departmentOptions as $d): ?>
                <option value="<?= htmlspecialchars($d) ?>" <?= $filterDepartment === $d ? 'selected' : '' ?>>
                    <?= htmlspecialchars($d) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <select name="location" onchange="this.form.submit()" class="border rounded-lg px-3 py-2 text-sm max-w-[14rem]">
            <option value=""><?= t('filter_all_locations') ?></option>
            <?php foreach ($locationOptions as $loc): ?>
                <option value="<?= htmlspecialchars($loc) ?>" <?= $filterLocation === $loc ? 'selected' : '' ?>>
                    <?= htmlspecialchars($loc) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button class="bg-slate-200 hover:bg-slate-300 rounded-lg px-3 py-2 text-sm"><?= t('btn_search') ?></button>
        <?php if ($isFiltered): ?>
            <a href="assets.php" class="text-sm text-slate-500 hover:text-slate-700 underline px-1"><?= t('btn_reset_filter') ?></a>
        <?php endif; ?>
        <a href="categories.php" class="text-sm text-slate-500 hover:text-slate-700 underline px-1"><?= t('link_manage_categories') ?></a>
    </form>
    <div class="flex flex-wrap items-center gap-2">
        <button type="button" onclick="startScanQr()" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('scan_btn') ?></button>
        <span id="assetSelectedInfo" class="hidden text-xs text-slate-500 mr-1"><span id="assetSelectedCount">0</span> <?= t('assets_selected') ?></span>
        <button type="button" id="btnEditAsset" onclick="editSelectedAsset()" disabled
                class="asset-action-btn opacity-40 cursor-not-allowed bg-amber-500 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('btn_edit') ?></button>
        <button type="button" id="btnPrintLabelAsset" onclick="printSelectedLabel()" disabled
                class="asset-action-btn opacity-40 cursor-not-allowed bg-slate-600 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('link_print_label') ?></button>
        <button type="button" id="btnPrintDetailAsset" onclick="printSelectedDetail()" disabled
                class="asset-action-btn opacity-40 cursor-not-allowed bg-slate-500 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('link_print_detail') ?></button>
        <button type="button" id="btnPdfAsset" onclick="pdfSelectedAsset()" disabled
                class="asset-action-btn opacity-40 cursor-not-allowed bg-orange-600 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('link_pdf') ?></button>
        <button type="button" id="btnMutationAsset" onclick="mutateSelectedAsset()" disabled title="<?= htmlspecialchars(t('mut_btn_asset_hint')) ?>"
                class="asset-action-btn opacity-40 cursor-not-allowed bg-teal-600 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('mut_btn_asset') ?></button>
        <button type="button" id="btnDamageAsset" onclick="damageSelectedAsset()" disabled title="<?= htmlspecialchars(t('dmg_btn_asset_hint')) ?>"
                class="asset-action-btn opacity-40 cursor-not-allowed bg-red-700 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('dmg_btn_asset') ?></button>
        <button type="button" id="btnUpgradeAsset" onclick="upgradeSelectedAsset()" disabled title="<?= htmlspecialchars(t('upg_btn_asset_hint')) ?>"
                class="asset-action-btn opacity-40 cursor-not-allowed bg-brand-600 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('upg_btn_asset') ?></button>
        <button type="button" id="btnDeleteAsset" onclick="deleteSelectedAssets()" disabled
                class="asset-action-btn opacity-40 cursor-not-allowed bg-red-600 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('link_delete') ?></button>
        <button type="button" id="btnGenerateNumberAsset" onclick="generateNumberSelectedAssets()" disabled
                title="<?= htmlspecialchars(t('gen_number_bulk_hint')) ?>"
                class="asset-action-btn opacity-40 cursor-not-allowed bg-indigo-600 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('btn_generate_number_selected') ?></button>
        <button type="button" onclick="exportAssets()" title="<?= htmlspecialchars(t('export_excel_hint')) ?>"
                class="inline-flex items-center gap-1 bg-green-600 hover:bg-green-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= t('btn_export_excel') ?>
        </button>
        <button type="button" onclick="openAssetImportModal()" class="inline-flex items-center gap-1 bg-slate-600 hover:bg-slate-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('upload') ?> <?= t('btn_import_excel') ?>
        </button>
        <button onclick="openAssetModal()" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= t('btn_add_asset') ?>
        </button>
    </div>
</div>
</div>

<?php if ($bulkMsg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $bulkMsg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>">
        <?= htmlspecialchars($bulkMsg['text']) ?>
    </div>
<?php endif; ?>

<?php if ($importMsg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $importMsg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>">
        <?= htmlspecialchars($importMsg['text']) ?>
    </div>
<?php endif; ?>

<!-- Form tersembunyi untuk submit "Generate Nomor Otomatis" (diisi ids[] via JS sebelum submit) -->
<form id="assetGenerateNumberForm" method="post" action="asset_generate_number_bulk.php" class="hidden">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
    <div id="assetGenerateNumberIds"></div>
</form>

<form id="assetBulkForm" method="post" action="asset_bulk_delete.php"
      onsubmit="return confirmDelete(bulkDeleteConfirmText.replace('%d', selectedAssetCount()))">
<input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

<div class="bg-white rounded-xl shadow-sm asset-table-wrap">
<table class="w-full text-sm whitespace-nowrap">
    <?php if ($isTabletView): ?>
    <thead class="bg-slate-50 text-slate-500 text-left">
        <tr>
            <th class="py-2 px-3 w-8 asset-col-check">
                <input type="checkbox" id="checkAllAssets" onclick="toggleAllAssets(this)">
            </th>
            <th class="py-2 px-3"><?= t('field_device_name') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_user') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_department') ?></th>
            <th class="py-2 px-3"><?= t('th_position') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_location') ?></th>
            <th class="py-2 px-3 asset-col-no"><?= t('tablet_lbl_asset_no') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_serial') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_ip') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_received') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_id') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_condition') ?></th>
            <th class="py-2 px-3"><?= t('tablet_lbl_brand') ?></th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($assetList as $a): ?>
        <tr class="border-t hover:bg-slate-50">
            <td class="py-2 px-3 asset-col-check">
                <input type="checkbox" name="ids[]" value="<?= $a['id'] ?>" class="asset-check" onclick="updateAssetSelection()">
            </td>
            <td class="py-2 px-3"><?= htmlspecialchars(($a['device_name'] ?? '') !== '' ? $a['device_name'] : t('dash')) ?></td>
            <td class="py-2 px-3 font-medium"><?= htmlspecialchars($a['owner_names'] !== '' ? $a['owner_names'] : t('dash')) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['department'] ?: t('dash')) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['owner_positions'] !== '' ? $a['owner_positions'] : t('dash')) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['location'] ?: t('dash')) ?></td>
            <td class="py-2 px-3 font-medium asset-col-no"><?= htmlspecialchars($a['asset_number']) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['serial_number'] ?: t('dash')) ?></td>
            <td class="py-2 px-3 whitespace-nowrap"><?= htmlspecialchars($a['ip_address'] ?: t('dash')) ?><?= remoteVncButton($a['ip_address']) ?></td>
            <td class="py-2 px-3"><?= !empty($a['purchase_date'] ?? null) ? date('d M Y', strtotime($a['purchase_date'])) : t('dash') ?></td>
            <td class="py-2 px-3 font-semibold text-brand-700"><?= htmlspecialchars($a['tablet_id'] ?: t('dash')) ?></td>
            <td class="py-2 px-3">
                <span class="px-2 py-0.5 rounded-full text-xs font-semibold <?= $a['tablet_condition'] === 'Rusak' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700' ?>">
                    <?= htmlspecialchars($a['tablet_condition'] === 'Rusak' ? t('tablet_cond_bad') : t('tablet_cond_good')) ?>
                </span>
            </td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['motherboard_brand'] ?: t('dash')) ?></td>
        </tr>
    <?php endforeach; ?>
    <?php else: ?>
    <thead class="bg-slate-50 text-slate-500 text-left">
        <tr>
            <th class="py-2 px-3 w-8 asset-col-check">
                <input type="checkbox" id="checkAllAssets" onclick="toggleAllAssets(this)">
            </th>
            <th class="py-2 px-3 asset-col-no"><?= t('th_asset_no') ?></th>
            <th class="py-2 px-3" data-priority="1"><?= t('th_type') ?></th>
            <th class="py-2 px-3" data-priority="2"><?= t('th_owner') ?></th>
            <th class="py-2 px-3" data-priority="3"><?= t('th_department') ?></th>
            <th class="py-2 px-3" data-priority="6"><?= t('th_position') ?></th>
            <th class="py-2 px-3" data-priority="12"><?= t('th_user_email') ?></th>
            <th class="py-2 px-3" data-priority="5"><?= t('th_ip') ?></th>
            <th class="py-2 px-3" data-priority="9"><?= t('th_hostname') ?></th>
            <th class="py-2 px-3" data-priority="6"><?= t('th_location') ?></th>
            <th class="py-2 px-3" data-priority="10"><?= t('th_specs') ?></th>
            <th class="py-2 px-3" data-priority="11"><?= t('th_os') ?></th>
            <th class="py-2 px-3" data-priority="8"><?= t('th_serial') ?></th>
            <th class="py-2 px-3" data-priority="13"><?= t('th_software') ?></th>
            <th class="py-2 px-3" data-priority="7"><?= t('th_pc_login') ?></th>
            <th class="py-2 px-3" data-priority="4"><?= t('th_status') ?></th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($assetList as $a): ?>
        <tr class="border-t hover:bg-slate-50">
            <td class="py-2 px-3 asset-col-check">
                <input type="checkbox" name="ids[]" value="<?= $a['id'] ?>" class="asset-check" onclick="updateAssetSelection()">
            </td>
            <td class="py-2 px-3 font-medium asset-col-no"><?= htmlspecialchars($a['asset_number']) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($categoryLabels[$a['category']] ?? $a['category']) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['owner_names'] !== '' ? $a['owner_names'] : t('dash')) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['department'] ?: t('dash')) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['owner_positions'] !== '' ? $a['owner_positions'] : t('dash')) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['owner_email'] ?: t('dash')) ?></td>
            <td class="py-2 px-3 whitespace-nowrap"><?= htmlspecialchars($a['ip_address'] ?: t('dash')) ?><?= remoteVncButton($a['ip_address']) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['hostname'] ?: t('dash')) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['location'] ?: t('dash')) ?></td>
            <td class="py-2 px-3 text-xs text-slate-500">
                <?= htmlspecialchars($a['processor'] ?: t('dash')) ?> / <?= htmlspecialchars($a['ram'] ?: t('dash')) ?> / <?= htmlspecialchars($a['storage'] ?: t('dash')) ?>
                <?php if (!empty($a['motherboard_brand'])): ?>
                    <br><span class="text-slate-400"><?= htmlspecialchars(t('field_motherboard')) ?>: <?= htmlspecialchars($a['motherboard_brand']) ?></span>
                <?php endif; ?>
            </td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['os_name'] ?: t('dash')) ?> (<?= htmlspecialchars($a['os_status'] === 'Original' ? t('os_original') : t('os_not_original')) ?>)</td>
            <td class="py-2 px-3"><?= htmlspecialchars($a['serial_number'] ?: t('dash')) ?></td>
            <td class="py-2 px-3 text-xs text-slate-500 max-w-[260px] whitespace-normal">
                <?php if ($a['software_items']): ?>
                    <?php foreach ($a['software_items'] as $si): ?>
                        <div><?= htmlspecialchars($si['software_name']) ?><?= $si['serial_number'] ? ' (' . htmlspecialchars($si['serial_number']) . ')' : '' ?> — <?= htmlspecialchars($si['status'] === 'Original' ? t('os_original') : t('os_not_original')) ?></div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <span class="text-slate-400"><?= t('dash') ?></span>
                <?php endif; ?>
            </td>
            <td class="py-2 px-3 text-xs">
                <?php if ($a['pc_username'] || $a['pc_password']): ?>
                    <div class="text-slate-600"><?= t('pc_user_label') ?>: <span class="font-medium"><?= htmlspecialchars($a['pc_username'] ?: t('dash')) ?></span></div>
                    <div class="text-slate-400 flex items-center gap-1">
                        <?= t('pc_pass_label') ?>:
                        <span class="pc-pass-mask">••••••••</span>
                        <span class="pc-pass-real hidden font-medium text-slate-600"><?= htmlspecialchars($a['pc_password'] ?: t('dash')) ?></span>
                        <button type="button" onclick="togglePcPassword(this)" class="text-blue-600 hover:underline"><?= t('btn_view') ?></button>
                    </div>
                <?php else: ?>
                    <span class="text-slate-400"><?= t('dash') ?></span>
                <?php endif; ?>
            </td>
            <td class="py-2 px-3">
                <?php $sBadge = ['Digunakan'=>'bg-green-100 text-green-700','Stok'=>'bg-slate-100 text-slate-600','Tidak Digunakan'=>'bg-red-100 text-red-600']; ?>
                <span class="px-2 py-0.5 rounded-full text-xs font-medium <?= $sBadge[$a['status']] ?? 'bg-slate-100 text-slate-600' ?>"><?= htmlspecialchars($statusLabels[$a['status']] ?? $a['status']) ?></span>
                <?php if ($a['damage_state'] !== ''): ?>
                    <a href="damages.php?q=<?= urlencode($a['asset_number']) ?>&state=all" class="ml-1 px-2 py-0.5 rounded-full text-xs font-semibold <?= damageStateBadge($a['damage_state']) ?> hover:underline" title="<?= htmlspecialchars(t('dmg_badge_hint')) ?>"><?= htmlspecialchars(damageStateLabel($a['damage_state'])) ?></a>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
    <?php endif; ?>
    <?php if (!$assetList): ?>
        <tr><td colspan="15" class="py-6 text-center text-slate-400"><?= $isFiltered ? t('no_assets_filtered') : t('no_assets_yet') ?></td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>
</form>

<!-- ===== Pagination ===== -->
<div class="flex flex-wrap items-center justify-between gap-3 mt-4 text-sm text-slate-600">
    <form method="get" class="flex flex-wrap items-center gap-2">
        <?php if ($search !== ''): ?><input type="hidden" name="q" value="<?= htmlspecialchars($search) ?>"><?php endif; ?>
        <?php if ($filterCategory !== ''): ?><input type="hidden" name="category" value="<?= htmlspecialchars($filterCategory) ?>"><?php endif; ?>
        <?php if ($filterDepartment !== ''): ?><input type="hidden" name="department" value="<?= htmlspecialchars($filterDepartment) ?>"><?php endif; ?>
        <?php if ($filterLocation !== ''): ?><input type="hidden" name="location" value="<?= htmlspecialchars($filterLocation) ?>"><?php endif; ?>
        <input type="hidden" name="page" value="1">
        <span><?= t('pagination_show') ?></span>
        <select name="per_page" onchange="this.form.submit()" class="border rounded-lg px-2 py-1 text-sm">
            <option value="all" <?= $perPage === 'all' ? 'selected' : '' ?>><?= t('pagination_show_all') ?></option>
            <?php foreach ($allowedPerPage as $pp): ?>
                <option value="<?= $pp ?>" <?= $perPage === $pp ? 'selected' : '' ?>><?= $pp ?></option>
            <?php endforeach; ?>
        </select>
        <span><?= t('pagination_per_page') ?></span>
        <span class="text-slate-400">&bull; <?= t('pagination_total_assets') ?>: <?= $totalAssets ?></span>
        <span id="assetSelectedInfoBottom" class="hidden text-slate-400">&bull; <span id="assetSelectedCountBottom">0</span> <?= t('assets_selected') ?></span>
    </form>

    <?php if ($totalPages > 1): ?>
    <div class="flex items-center gap-1">
        <a href="<?= assetPageUrl($search, $perPage, max(1, $page - 1), $filterCategory, $filterDepartment) ?>"
           class="px-3 py-1.5 rounded-lg border <?= $page <= 1 ? 'opacity-40 pointer-events-none' : 'hover:bg-slate-100' ?>">&laquo;</a>

        <?php
        // Tampilkan maksimal 7 nomor halaman supaya tidak kepanjangan walau data sangat banyak
        $windowEnd   = min($totalPages, max($page + 3, 7));
        $windowStart = max(1, $windowEnd - 6);
        for ($p = $windowStart; $p <= $windowEnd; $p++):
        ?>
            <a href="<?= assetPageUrl($search, $perPage, $p, $filterCategory, $filterDepartment) ?>"
               class="px-3 py-1.5 rounded-lg border <?= $p === $page ? 'bg-blue-600 text-white border-blue-600' : 'hover:bg-slate-100' ?>"><?= $p ?></a>
        <?php endfor; ?>

        <a href="<?= assetPageUrl($search, $perPage, min($totalPages, $page + 1), $filterCategory, $filterDepartment) ?>"
           class="px-3 py-1.5 rounded-lg border <?= $page >= $totalPages ? 'opacity-40 pointer-events-none' : 'hover:bg-slate-100' ?>">&raquo;</a>
    </div>
    <?php endif; ?>
</div>

<!-- ===== Modal Form Tambah/Edit Aset ===== -->
<div id="assetModal" class="fixed inset-0 bg-black/40 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <form method="post" action="asset_save.php" class="p-5 space-y-3">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="id" id="f_id">
            <div class="flex items-start justify-between gap-3 sticky top-0 z-10 bg-white -mx-5 -mt-5 px-5 pt-5 pb-2">
                <h2 class="font-semibold text-lg" id="modalTitle"><?= t('modal_add_asset_title') ?></h2>
                <button type="button" onclick="closeAssetModal()" data-modal-close title="<?= htmlspecialchars(t('btn_close')) ?>" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="shrink-0 -mr-1 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><?= icon('x', 'w-5 h-5') ?></button>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm" id="assetFieldGrid">
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_asset_number') ?></label>
                    <!-- Nomor Aset: aset BARU -> dibuat otomatis saat disimpan (kotak terkunci);
                         EDIT -> boleh diubah manual / dibuat ulang lewat tombol (lihat openAssetModal & asset_save.php). -->
                    <div class="flex gap-2">
                        <input name="asset_number" id="f_asset_number" maxlength="<?= ASSET_NUMBER_MAX_LEN ?>" autocomplete="off"
                               placeholder="<?= htmlspecialchars(t('asset_number_auto_placeholder')) ?>"
                               class="w-full min-w-0 border rounded-lg px-3 py-2 font-medium">
                        <button type="button" id="btnGenAssetNumber" onclick="generateAssetNumber()"
                                class="hidden shrink-0 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg px-3 py-2 text-xs font-medium whitespace-nowrap"
                                title="<?= htmlspecialchars(t('gen_number_edit_hint')) ?>"><?= t('btn_generate_number') ?></button>
                    </div>
                    <p class="text-xs text-slate-400 mt-1" id="genNumberHintDefault"><?= t('gen_number_hint') ?></p>
                    <p class="text-xs text-brand-700 mt-1 hidden" id="genNumberHintTablet"></p>
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_category') ?></label>
                    <select name="category" id="f_category" required class="w-full border rounded-lg px-3 py-2">
                        <?php foreach ($categories as $c): ?><option value="<?= $c ?>"><?= htmlspecialchars($categoryLabels[$c]) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_device_name') ?></label>
                    <input name="device_name" id="f_device_name" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div class="sm:col-span-2">
                    <label class="block mb-1 font-medium"><?= t('field_owner_user') ?></label>
                    <p class="text-xs text-slate-400 mb-1"><?= t('owner_user_multi_hint') ?></p>
                    <?php if ($users): ?>
                        <input type="text" id="f_owner_user_search" oninput="filterOwnerUserList(this.value)"
                               placeholder="<?= htmlspecialchars(t('search_user_placeholder')) ?>"
                               class="w-full border rounded-lg px-3 py-1.5 text-sm mb-1.5">
                    <?php endif; ?>
                    <div class="border rounded-lg max-h-40 overflow-y-auto divide-y" id="f_owner_user_list">
                        <?php if (!$users): ?>
                            <p class="px-3 py-3 text-slate-400 text-xs"><?= t('no_users_yet') ?></p>
                        <?php endif; ?>
                        <?php foreach ($users as $u): ?>
                            <label class="flex items-center gap-2 px-3 py-2 text-sm cursor-pointer hover:bg-slate-50 owner-user-row"
                                   data-search="<?= htmlspecialchars(mb_strtolower($u['full_name'] . ' ' . $u['department'])) ?>">
                                <input type="checkbox" name="owner_user_id[]" value="<?= $u['id'] ?>" class="owner-user-check">
                                <span><?= htmlspecialchars($u['full_name']) ?><?= $u['department'] ? ' <span class="text-slate-400">(' . htmlspecialchars($u['department']) . ')</span>' : '' ?></span>
                            </label>
                        <?php endforeach; ?>
                        <p id="ownerUserNoMatch" class="px-3 py-3 text-slate-400 text-xs hidden"><?= t('no_users_matched') ?></p>
                    </div>
                    <!-- Data dari User (diisi sekali di menu User): Departement, Email, Username & Password PC -->
                    <div id="ownerDataBox" class="mt-2 rounded-lg border border-brand-100 bg-brand-50/60 px-3 py-2 text-xs text-slate-600"></div>
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_department') ?></label>
                    <!-- Hanya tampilan (tidak dikirim): nilai diambil dari User pertama saat disimpan -->
                    <input id="f_department" readonly tabindex="-1" class="w-full border rounded-lg px-3 py-2 bg-slate-50 text-slate-600 cursor-not-allowed" placeholder="<?= htmlspecialchars(t('owner_data_dept_placeholder')) ?>">
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_ip_address') ?></label>
                    <input name="ip_address" id="f_ip_address" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_hostname') ?></label>
                    <input name="hostname" id="f_hostname" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_location') ?></label>
                    <input name="location" id="f_location" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_processor') ?></label>
                    <input name="processor" id="f_processor" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_ram') ?></label>
                    <input name="ram" id="f_ram" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_storage') ?></label>
                    <input name="storage" id="f_storage" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_printer') ?></label>
                    <input name="printer_info" id="f_printer_info" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_monitor') ?></label>
                    <input name="monitor_info" id="f_monitor_info" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div class="sm:col-span-2">
                    <label class="block mb-1 font-medium"><?= t('field_accessories') ?></label>
                    <p class="text-xs text-slate-400 mb-1"><?= t('accessory_multi_hint') ?></p>
                    <div id="accessoryRows" class="space-y-2"></div>
                    <button type="button" onclick="addAccessoryRow()" class="mt-2 text-sm font-medium text-blue-600 hover:underline"><?= t('btn_add_accessory') ?></button>
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_os_name') ?></label>
                    <input name="os_name" id="f_os_name" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_serial_number') ?></label>
                    <input name="serial_number" id="f_serial_number" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div class="flex items-end pb-2">
                    <label class="inline-flex items-center gap-2 font-medium cursor-pointer select-none">
                        <input type="checkbox" name="os_status_original" id="f_os_status_original" class="w-4 h-4 rounded">
                        <?= t('field_os_status') ?> <?= t('os_original') ?>
                    </label>
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_purchase_date') ?></label>
                    <input type="date" name="purchase_date" id="f_purchase_date" class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block mb-1 font-medium"><?= t('field_motherboard') ?></label>
                    <input name="motherboard_brand" id="f_motherboard_brand" class="w-full border rounded-lg px-3 py-2">
                </div>
                <!-- Isian khusus Tablet (tabel baru asset_tablet_details). Hanya tampil jika Jenis Aset = Tablet. -->
                <div class="tablet-only hidden">
                    <label class="block mb-1 font-medium"><?= t('tablet_lbl_id') ?></label>
                    <input name="tablet_id" id="f_tablet_id" maxlength="50" class="w-full border rounded-lg px-3 py-2" placeholder="<?= htmlspecialchars(t('tablet_id_placeholder')) ?>">
                </div>
                <div class="tablet-only hidden">
                    <label class="block mb-1 font-medium"><?= t('tablet_lbl_condition') ?></label>
                    <select name="tablet_condition" id="f_tablet_condition" class="w-full border rounded-lg px-3 py-2">
                        <option value="Bagus"><?= t('tablet_cond_good') ?></option>
                        <option value="Rusak"><?= t('tablet_cond_bad') ?></option>
                    </select>
                </div>
                <div class="sm:col-span-2">
                    <label class="block mb-1 font-medium"><?= t('field_software') ?></label>
                    <p class="text-xs text-slate-400 mb-1"><?= t('software_multi_hint') ?></p>
                    <div id="softwareRows" class="space-y-2"></div>
                    <button type="button" onclick="addSoftwareRow()" class="mt-2 text-sm font-medium text-blue-600 hover:underline"><?= t('btn_add_software') ?></button>
                </div>
                <div class="sm:col-span-2">
                    <label class="block mb-1 font-medium"><?= t('field_status') ?></label>
                    <select name="status" id="f_status" class="w-full border rounded-lg px-3 py-2">
                        <?php foreach ($statuses as $s): ?><option value="<?= $s ?>"><?= htmlspecialchars($statusLabels[$s]) ?></option><?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t mt-3">
                <button type="button" onclick="closeAssetModal()" class="px-4 py-2 text-sm rounded-lg bg-slate-100 hover:bg-slate-200"><?= t('btn_cancel') ?></button>
                <button type="submit" class="px-4 py-2 text-sm rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium"><?= t('btn_save') ?></button>
            </div>
        </form>
    </div>
</div>

<!-- ===== Modal Import Excel Aset ===== -->
<div id="assetImportModal" class="fixed inset-0 bg-black/40 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-md">
        <form method="post" action="import_process.php" enctype="multipart/form-data" class="p-5 space-y-3 text-sm">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <div class="flex items-start justify-between gap-3">
                <h2 class="font-semibold text-lg"><?= t('import_asset_title') ?></h2>
                <button type="button" onclick="closeAssetImportModal()" data-modal-close title="<?= htmlspecialchars(t('btn_close')) ?>" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="shrink-0 -mr-1 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><?= icon('x', 'w-5 h-5') ?></button>
            </div>
            <p class="text-xs text-slate-500">
                <?= t('import_asset_instructions') ?>
            </p>
            <!-- Import gabungan Aset + User: sekali input untuk aset & penggunanya -->
            <div class="rounded-lg bg-teal-50 border border-teal-100 p-3 text-xs text-slate-600 space-y-2">
                <p class="font-semibold text-teal-800"><?= t('import_au_title') ?></p>
                <p><?= t('import_au_instructions') ?></p>
                <a href="download_template.php?type=asset_user" class="inline-flex items-center gap-1 rounded-lg bg-white border border-teal-200 hover:bg-teal-100 text-teal-800 px-3 py-1.5 font-medium">
                    <?= icon('download') ?> <?= t('btn_download_template_au') ?>
                </a>
            </div>
            <!-- Import khusus Tablet: file hasil Export Tablet / Template Tablet dikenali otomatis -->
            <div class="rounded-lg bg-blue-50 border border-blue-100 p-3 text-xs text-slate-600 space-y-2">
                <p class="font-semibold text-brand-700"><?= t('import_tablet_title') ?></p>
                <p><?= t('import_tablet_instructions') ?></p>
                <a href="download_template.php?type=tablet" class="inline-flex items-center gap-1 rounded-lg bg-white border border-blue-200 hover:bg-blue-100 text-brand-700 px-3 py-1.5 font-medium">
                    <?= icon('download') ?> <?= t('btn_download_template_tablet') ?>
                </a>
            </div>
            <input type="file" name="excel_file" accept=".xlsx,.xls" required
                   class="w-full border rounded-lg px-3 py-2 text-sm">
            <div class="flex justify-end gap-2 pt-3 border-t mt-3">
                <button type="button" onclick="closeAssetImportModal()" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200"><?= t('btn_cancel') ?></button>
                <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium"><?= t('btn_upload_import') ?></button>
            </div>
        </form>
    </div>
</div>

<!-- ===== Modal Export Excel per Kategori (bisa pilih beberapa sekaligus) ===== -->
<div id="exportCategoryModal" class="fixed inset-0 bg-black/40 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div class="p-5 space-y-3 text-sm">
            <div class="flex items-start justify-between gap-3 sticky top-0 z-10 bg-white -mx-5 -mt-5 px-5 pt-5 pb-2">
                <h2 class="font-semibold text-lg"><?= t('modal_export_category_title') ?></h2>
                <button type="button" onclick="closeExportCategoryModal()" data-modal-close title="<?= htmlspecialchars(t('btn_close')) ?>" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="shrink-0 -mr-1 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><?= icon('x', 'w-5 h-5') ?></button>
            </div>
            <p class="text-xs text-slate-500 mb-2"><?= t('modal_export_category_hint') ?></p>
            <!-- Muncul hanya jika ada baris yang dicentang di tabel -->
            <div id="exportScopeBox" class="hidden space-y-1.5 rounded-lg bg-slate-50 border p-3">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="exportScope" value="category" checked onchange="updateExportSummary()">
                    <span><?= t('export_scope_category') ?></span>
                </label>
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="exportScope" value="selected" onchange="updateExportSummary()">
                    <span id="exportScopeSelectedLabel"></span>
                </label>
            </div>
            <div class="max-h-64 overflow-y-auto border rounded-lg divide-y" id="exportCatList">
                <label class="flex items-center gap-2 px-3 py-2 bg-slate-50 cursor-pointer">
                    <input type="checkbox" id="exportCatAll" onclick="toggleAllExportCategories(this)">
                    <span class="font-medium"><?= t('option_select_all_categories') ?></span>
                </label>
                <?php foreach ($categories as $c): ?>
                <label class="flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-slate-50">
                    <input type="checkbox" class="export-cat-check" value="<?= htmlspecialchars($c) ?>" data-count="<?= (int)($categoryCounts[$c] ?? 0) ?>" onclick="updateExportCategoryAllState()">
                    <span class="flex-1"><?= htmlspecialchars($categoryLabels[$c] ?? $c) ?></span>
                    <span class="text-xs text-slate-400 tabular-nums"><?= (int)($categoryCounts[$c] ?? 0) ?> <?= t('export_assets_unit') ?></span>
                </label>
                <?php endforeach; ?>
                <?php if (!$categories): ?>
                    <p class="px-3 py-3 text-slate-400 text-xs"><?= t('no_categories_yet') ?></p>
                <?php endif; ?>
            </div>
            <p class="text-xs text-slate-400"><?= t('modal_export_category_empty_hint') ?></p>
            <?php if ($exportDepartments): ?>
            <p class="font-medium text-slate-700 pt-1" id="exportDeptTitle"><?= t('export_department_title') ?></p>
            <div class="max-h-48 overflow-y-auto border rounded-lg divide-y" id="exportDeptList">
                <label class="flex items-center gap-2 px-3 py-2 bg-slate-50 cursor-pointer">
                    <input type="checkbox" id="exportDeptAll" onclick="toggleAllExportDepartments(this)">
                    <span class="font-medium"><?= t('filter_all_departments') ?></span>
                </label>
                <?php foreach ($exportDepartments as $d): ?>
                <label class="flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-slate-50">
                    <input type="checkbox" class="export-dept-check" value="<?= htmlspecialchars($d) ?>" onclick="updateExportDeptAllState()">
                    <span class="flex-1"><?= htmlspecialchars($d) ?></span>
                    <span class="text-xs text-slate-400 tabular-nums"><?= (int)$departmentCounts[$d] ?> <?= t('export_assets_unit') ?></span>
                </label>
                <?php endforeach; ?>
            </div>
            <p class="text-xs text-slate-400"><?= t('export_department_empty_hint') ?></p>
            <?php endif; ?>
            <p id="exportSummary" class="text-sm font-medium text-slate-700 bg-green-50 border border-green-100 rounded-lg px-3 py-2"></p>
            <div class="flex justify-end gap-2 pt-3 border-t mt-3">
                <button type="button" onclick="closeExportCategoryModal()" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200"><?= t('btn_cancel') ?></button>
                <button type="button" onclick="submitExportCategory()" id="btnDoExport" class="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-700 text-white font-medium"><?= t('btn_export_excel') ?></button>
            </div>
        </div>
    </div>
</div>

<script>
var bulkDeleteConfirmText = <?= json_encode(tRaw('confirm_bulk_delete_asset')) ?>;
var singleDeleteConfirmText = <?= json_encode(tRaw('confirm_delete_asset')) ?>;
var modalAddAssetTitle = <?= json_encode(t('modal_add_asset_title')) ?>;
var modalEditAssetTitle = <?= json_encode(t('modal_edit_asset_title')) ?>;
var btnViewLabel = <?= json_encode(t('btn_view')) ?>;
var btnHideLabel = <?= json_encode(t('btn_hide')) ?>;
var genNumberSelectCategoryFirst = <?= json_encode(t('gen_number_select_category_first')) ?>;
var genNumberFailed = <?= json_encode(t('gen_number_failed')) ?>;
var genNumberBulkConfirmText = <?= json_encode(tRaw('gen_number_bulk_confirm')) ?>;
// Pencarian & filter Departement yang sedang aktif (dipertahankan saat export
// lewat modal pilih kategori di bawah). Filter Jenis Aset TIDAK dipakai lagi di
// sini karena kategori untuk export sekarang dipilih sendiri lewat modal
// (bisa lebih dari satu sekaligus), bukan cuma ikut 1 filter jenis yang aktif.
var currentAssetFilterSearch = <?= json_encode($search) ?>;
var currentAssetFilterDepartment = <?= json_encode($filterDepartment) ?>;
var currentAssetFilterLocation = <?= json_encode($filterLocation) ?>;
var currentAssetFilterCategory = <?= json_encode($filterCategory) ?>;
var assetDataMap = <?= json_encode(array_column($assetList, null, 'id'), JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var fieldSoftwareLabel = <?= json_encode(t('field_software')) ?>;
var assetNumberHintAdd = <?= json_encode(t('gen_number_hint')) ?>;
var assetNumberHintEdit = <?= json_encode(t('gen_number_edit_hint')) ?>;
var accessoryNameLabel = <?= json_encode(t('accessory_name_ph')) ?>;
var accessoryBrandLabel = <?= json_encode(t('accessory_brand_ph')) ?>;
var fieldSoftwareSerialLabel = <?= json_encode(t('field_software_serial_number')) ?>;
var osOriginalLabel = <?= json_encode(t('os_original')) ?>;
var btnRemoveLabel = <?= json_encode(t('btn_delete')) ?>;
// ===== Mode form khusus Tablet =====
// Urutan & label isian saat Jenis Aset = Tablet. Isian lain disembunyikan (nilainya tetap tersimpan).
var TABLET_LAYOUT = [
    ['f_category', null],
    ['f_device_name', null],
    ['f_owner_user_list', <?= json_encode(t('tablet_lbl_user')) ?>],
    ['f_department', <?= json_encode(t('tablet_lbl_department')) ?>],
    ['f_location', <?= json_encode(t('tablet_lbl_location')) ?>],
    ['f_asset_number', <?= json_encode(t('tablet_lbl_asset_no')) ?>],
    ['f_serial_number', <?= json_encode(t('tablet_lbl_serial')) ?>],
    ['f_ip_address', <?= json_encode(t('tablet_lbl_ip')) ?>],
    ['f_purchase_date', <?= json_encode(t('tablet_lbl_received')) ?>],
    ['f_tablet_id', null],
    ['f_tablet_condition', null],
    ['f_motherboard_brand', <?= json_encode(t('tablet_lbl_brand')) ?>],
    ['accessoryRows', null]
];
var tabletNumberHintText = <?= json_encode(tRaw('tablet_gen_hint')) ?>;
// Data User untuk ditampilkan di form Asset (diisi sekali di menu User).
var ownerUserData = <?= json_encode(array_combine(array_column($users, 'id'), array_map(fn($u) => [
    'name' => $u['full_name'], 'dept' => (string)$u['department'], 'pos' => (string)$u['position'], 'email' => (string)$u['email'],
    'pcu' => (string)$u['pc_username'], 'pcp' => (string)$u['pc_password'],
], $users)) ?: new stdClass(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var ownerDataT = <?= json_encode([
    'none' => t('owner_data_none'), 'from' => t('owner_data_from'), 'multi' => t('owner_data_multi'),
    'dept' => t('field_department'), 'pos' => t('field_position'), 'email' => t('field_owner_email'), 'pcu' => t('field_pc_username'),
    'pcp' => t('field_pc_password'), 'edit' => t('owner_data_edit_hint'), 'empty' => t('dash'),
]) ?>;
function escHtml(v) { return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
// Tampilkan Departement/Email/Login PC dari user pertama yang dicentang (urut daftar = urut abjad).
function refreshOwnerData() {
    const checked = Array.from(document.querySelectorAll('.owner-user-check:checked')).map(cb => ownerUserData[cb.value]).filter(Boolean);
    const first = checked[0];
    document.getElementById('f_department').value = first ? first.dept : '';
    const box = document.getElementById('ownerDataBox');
    if (!first) { box.innerHTML = escHtml(ownerDataT.none); return; }
    const v = x => x ? escHtml(x) : '<span class="text-slate-400">' + escHtml(ownerDataT.empty) + '</span>';
    box.innerHTML =
        '<div class="font-medium text-slate-700 mb-1">' + escHtml(ownerDataT.from.replace('%s', first.name)) + '</div>' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-0.5">' +
        '<div>' + escHtml(ownerDataT.dept) + ': <b>' + v(first.dept) + '</b></div>' +
        '<div>' + escHtml(ownerDataT.pos) + ': <b>' + v(first.pos) + '</b></div>' +
        '<div>' + escHtml(ownerDataT.email) + ': <b>' + v(first.email) + '</b></div>' +
        '<div>' + escHtml(ownerDataT.pcu) + ': <b>' + v(first.pcu) + '</b></div>' +
        '<div>' + escHtml(ownerDataT.pcp) + ': <b>' + (first.pcp ? '••••••••' : v('')) + '</b></div></div>' +
        (checked.length > 1 ? '<div class="mt-1 text-slate-500">' + escHtml(ownerDataT.multi) + '</div>' : '') +
        '<div class="mt-1 text-slate-400">' + ownerDataT.edit + '</div>';
    if (typeof updateTabletNumberHint === 'function') updateTabletNumberHint();
}
function isTabletCategoryName(v) { return /tablet/i.test(v || ''); }
function applyTabletMode() {
    const grid = document.getElementById('assetFieldGrid');
    const on = isTabletCategoryName(document.getElementById('f_category').value);
    const layout = new Map();
    TABLET_LAYOUT.forEach(([id, label], i) => {
        const el = document.getElementById(id);
        const box = el ? el.closest('#assetFieldGrid > div') : null;
        if (box) layout.set(box, [i + 1, label]);
    });
    Array.from(grid.children).forEach(box => {
        const info = layout.get(box);
        box.style.order = (on && info) ? info[0] : '';
        box.classList.toggle('hidden', on ? !info : box.classList.contains('tablet-only'));
        const lbl = box.querySelector('label');
        if (lbl && info && info[1]) {
            if (lbl.dataset.orig === undefined) lbl.dataset.orig = lbl.innerHTML;
            lbl.innerHTML = on ? info[1] : lbl.dataset.orig;
        }
    });
    document.getElementById('genNumberHintDefault').classList.toggle('hidden', on);
    document.getElementById('genNumberHintTablet').classList.toggle('hidden', !on);
    updateTabletNumberHint();
}
function updateTabletNumberHint() {
    const line = (document.getElementById('f_location').value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    document.getElementById('genNumberHintTablet').textContent = tabletNumberHintText.replace('%s', line || 'LINE');
}
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('f_category').addEventListener('change', applyTabletMode);
    document.getElementById('f_location').addEventListener('input', updateTabletNumberHint);
    // Departement & data login ikut user yang dicentang (diisi sekali di menu User).
    document.querySelectorAll('.owner-user-check').forEach(cb => cb.addEventListener('change', refreshOwnerData));
});

function openAssetModal(data) {
    document.getElementById('assetModal').classList.remove('hidden');
    document.getElementById('assetModal').classList.add('flex');
    const fields = ['id','asset_number','category','device_name','department','owner_email','ip_address',
                     'hostname','location','processor','ram','storage','printer_info','monitor_info','accessories',
                     'os_name','serial_number','motherboard_brand','status','pc_username','pc_password','purchase_date',
                     'tablet_id','tablet_condition'];
    fields.forEach(f => {
        const el = document.getElementById('f_' + f);
        if (el) el.value = data && data[f] !== null && data[f] !== undefined ? data[f] : '';
    });
    // Status OS sekarang checkbox (dicentang = Original).
    document.getElementById('f_os_status_original').checked = !!(data && data.os_status === 'Original');
    // Centang pengguna aset ini (bisa lebih dari satu). Kosongkan semua dulu,
    // baru centang sesuai owner_ids kalau sedang edit aset yang sudah ada.
    const ownerIds = (data && data.owner_ids) ? data.owner_ids.map(String) : [];
    document.querySelectorAll('.owner-user-check').forEach(cb => {
        cb.checked = ownerIds.includes(cb.value);
    });
    // Kosongkan kotak pencarian pengguna & tampilkan semua baris lagi tiap modal dibuka.
    const ownerSearchBox = document.getElementById('f_owner_user_search');
    if (ownerSearchBox) { ownerSearchBox.value = ''; }
    filterOwnerUserList('');
    // Daftar Software aset ini (bisa lebih dari satu). Kosongkan dulu baris
    // lama, lalu isi ulang sesuai data (atau 1 baris kosong kalau aset baru).
    document.getElementById('softwareRows').innerHTML = '';
    const softwareItems = (data && data.software_items) ? data.software_items : [];
    if (softwareItems.length) {
        softwareItems.forEach(item => addSoftwareRow(item));
    } else {
        addSoftwareRow();
    }
    // Daftar Aksesoris aset ini (Nama + Brand/Type), sama caranya dengan Software.
    document.getElementById('accessoryRows').innerHTML = '';
    const accessoryItems = (data && data.accessory_items) ? data.accessory_items : [];
    if (accessoryItems.length) {
        accessoryItems.forEach(item => addAccessoryRow(item));
    } else {
        addAccessoryRow();
    }
    document.getElementById('modalTitle').innerText = data ? modalEditAssetTitle : modalAddAssetTitle;
    // Nomor Aset: aset baru -> terkunci (dibuat otomatis saat disimpan); edit -> boleh diubah / dibuat ulang.
    (function () {
        const no = document.getElementById('f_asset_number'), gen = document.getElementById('btnGenAssetNumber');
        const hint = document.getElementById('genNumberHintDefault');
        const editing = !!data;
        no.readOnly = !editing;
        no.tabIndex = editing ? 0 : -1;
        no.classList.toggle('bg-slate-50', !editing);
        no.classList.toggle('text-slate-600', !editing);
        no.classList.toggle('cursor-not-allowed', !editing);
        gen.classList.toggle('hidden', !editing);
        if (hint) hint.textContent = editing ? assetNumberHintEdit : assetNumberHintAdd;
    })();
    // Tambah aset baru saat filter Tablet aktif -> Jenis Aset langsung Tablet.
    if (!data && isTabletCategoryName(currentAssetFilterCategory)) {
        document.getElementById('f_category').value = currentAssetFilterCategory;
    }
    if (!data || !data.tablet_condition) document.getElementById('f_tablet_condition').value = 'Bagus';
    refreshOwnerData();
    applyTabletMode();
}
var accessoryRowSeq = 0;
function addAccessoryRow(item) {
    const wrap = document.getElementById('accessoryRows');
    const rid = 'ac' + (accessoryRowSeq++);
    const row = document.createElement('div');
    row.className = 'flex flex-wrap sm:flex-nowrap items-center gap-2 border rounded-lg p-2';
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.name = 'accessory[' + rid + '][name]';
    nameInput.maxLength = 100;
    nameInput.placeholder = accessoryNameLabel;
    nameInput.className = 'flex-1 min-w-[140px] border rounded-lg px-2.5 py-1.5 text-sm';
    const brandInput = document.createElement('input');
    brandInput.type = 'text';
    brandInput.name = 'accessory[' + rid + '][brand]';
    brandInput.maxLength = 100;
    brandInput.placeholder = accessoryBrandLabel;
    brandInput.className = 'flex-1 min-w-[140px] border rounded-lg px-2.5 py-1.5 text-sm';
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'text-red-500 hover:text-red-700 px-1 text-lg leading-none';
    removeBtn.title = btnRemoveLabel;
    removeBtn.textContent = '×';
    // Baris terakhir tidak dihapus tapi dikosongkan, supaya form selalu mengirim daftar aksesoris.
    removeBtn.onclick = () => {
        if (wrap.children.length > 1) { row.remove(); } else { nameInput.value = ''; brandInput.value = ''; }
    };
    row.appendChild(nameInput);
    row.appendChild(brandInput);
    row.appendChild(removeBtn);
    wrap.appendChild(row);
    if (item) {
        nameInput.value = item.name || '';
        brandInput.value = item.brand || '';
    }
}
var softwareRowSeq = 0;
function addSoftwareRow(item) {
    const wrap = document.getElementById('softwareRows');
    const rid = 'sw' + (softwareRowSeq++);
    const row = document.createElement('div');
    row.className = 'flex flex-wrap sm:flex-nowrap items-center gap-2 border rounded-lg p-2';
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.name = 'software[' + rid + '][name]';
    nameInput.placeholder = fieldSoftwareLabel;
    nameInput.className = 'flex-1 min-w-[140px] border rounded-lg px-2.5 py-1.5 text-sm';
    const serialInput = document.createElement('input');
    serialInput.type = 'text';
    serialInput.name = 'software[' + rid + '][serial]';
    serialInput.placeholder = fieldSoftwareSerialLabel;
    serialInput.className = 'flex-1 min-w-[120px] border rounded-lg px-2.5 py-1.5 text-sm';
    const originalLabel = document.createElement('label');
    originalLabel.className = 'flex items-center gap-1.5 text-xs font-medium whitespace-nowrap cursor-pointer select-none';
    const originalCheck = document.createElement('input');
    originalCheck.type = 'checkbox';
    originalCheck.name = 'software[' + rid + '][original]';
    originalCheck.className = 'w-4 h-4 rounded';
    originalLabel.appendChild(originalCheck);
    originalLabel.appendChild(document.createTextNode(' ' + osOriginalLabel));
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'text-red-500 hover:text-red-700 px-1 text-lg leading-none';
    removeBtn.title = btnRemoveLabel;
    removeBtn.textContent = '×';
    removeBtn.onclick = () => row.remove();
    row.appendChild(nameInput);
    row.appendChild(serialInput);
    row.appendChild(originalLabel);
    row.appendChild(removeBtn);
    wrap.appendChild(row);
    if (item) {
        nameInput.value = item.software_name || '';
        serialInput.value = item.serial_number || '';
        originalCheck.checked = item.status === 'Original';
    }
}
function filterOwnerUserList(query) {
    const q = query.trim().toLowerCase();
    let anyVisible = false;
    document.querySelectorAll('.owner-user-row').forEach(row => {
        const match = q === '' || (row.dataset.search || '').includes(q);
        row.classList.toggle('hidden', !match);
        if (match) anyVisible = true;
    });
    const noMatch = document.getElementById('ownerUserNoMatch');
    if (noMatch) { noMatch.classList.toggle('hidden', anyVisible); }
}
function generateAssetNumber() {
    const category   = document.getElementById('f_category').value;
    const department = document.getElementById('f_department').value;
    if (!category) {
        alert(genNumberSelectCategoryFirst);
        return;
    }
    const editingId = document.getElementById('f_id').value;
    let qs = 'category=' + encodeURIComponent(category) + '&department=' + encodeURIComponent(department);
    // Pengguna yang dicentang: departement untuk nomor diambil dari user pertama (sama dengan saat disimpan).
    qs += '&owner_ids=' + encodeURIComponent(Array.from(document.querySelectorAll('.owner-user-check:checked')).map(cb => cb.value).join(','));
    if (editingId) qs += '&exclude_id=' + encodeURIComponent(editingId);
    qs += '&location=' + encodeURIComponent(document.getElementById('f_location').value); // dipakai untuk Tablet (Line)
    fetch('asset_generate_number.php?' + qs, { credentials: 'same-origin', cache: 'no-store' })
        .then(res => res.json())
        .then(data => {
            if (data.ok) {
                document.getElementById('f_asset_number').value = data.asset_number;
            } else {
                alert(data.message || genNumberFailed);
            }
        })
        .catch(() => alert(genNumberFailed));
}
function closeAssetModal() {
    document.getElementById('assetModal').classList.add('hidden');
    document.getElementById('assetModal').classList.remove('flex');
}
function openAssetImportModal() {
    document.getElementById('assetImportModal').classList.remove('hidden');
    document.getElementById('assetImportModal').classList.add('flex');
}
function closeAssetImportModal() {
    document.getElementById('assetImportModal').classList.add('hidden');
    document.getElementById('assetImportModal').classList.remove('flex');
}
function togglePcPassword(btn) {
    const wrap = btn.parentElement;
    const mask = wrap.querySelector('.pc-pass-mask');
    const real = wrap.querySelector('.pc-pass-real');
    const showing = !real.classList.contains('hidden');
    mask.classList.toggle('hidden', !showing);
    real.classList.toggle('hidden', showing);
    btn.innerText = showing ? btnViewLabel : btnHideLabel;
}

// ===== Pilih baris untuk aktifkan tombol aksi di atas =====
function getSelectedAssetIds() {
    return Array.from(document.querySelectorAll('.asset-check:checked')).map(cb => cb.value);
}
function selectedAssetCount() {
    return getSelectedAssetIds().length;
}
function setActionBtnEnabled(id, enabled) {
    const btn = document.getElementById(id);
    btn.disabled = !enabled;
    btn.classList.toggle('opacity-40', !enabled);
    btn.classList.toggle('cursor-not-allowed', !enabled);
}
function updateAssetSelection() {
    const all     = document.querySelectorAll('.asset-check');
    const ids     = getSelectedAssetIds();
    const single  = ids.length === 1;
    const any     = ids.length > 0;

    document.getElementById('assetSelectedCount').innerText = ids.length;
    document.getElementById('assetSelectedInfo').classList.toggle('hidden', ids.length === 0);
    document.getElementById('assetSelectedCountBottom').innerText = ids.length;
    document.getElementById('assetSelectedInfoBottom').classList.toggle('hidden', ids.length === 0);

    setActionBtnEnabled('btnEditAsset', single);
    setActionBtnEnabled('btnPrintLabelAsset', any);
    setActionBtnEnabled('btnPrintDetailAsset', any);
    setActionBtnEnabled('btnPdfAsset', any);
    setActionBtnEnabled('btnDeleteAsset', any);
    setActionBtnEnabled('btnMutationAsset', single);
    setActionBtnEnabled('btnUpgradeAsset', single);
    setActionBtnEnabled('btnDamageAsset', single);
    setActionBtnEnabled('btnGenerateNumberAsset', any);

    const master = document.getElementById('checkAllAssets');
    master.checked = all.length > 0 && ids.length === all.length;
    master.indeterminate = ids.length > 0 && ids.length < all.length;
}
function toggleAllAssets(master) {
    document.querySelectorAll('.asset-check').forEach(cb => cb.checked = master.checked);
    updateAssetSelection();
}
function clearAssetSelection() {
    document.querySelectorAll('.asset-check').forEach(cb => cb.checked = false);
    updateAssetSelection();
}

// ===== Aksi tombol di atas, berlaku untuk aset yang dicentang =====
function editSelectedAsset() {
    const ids = getSelectedAssetIds();
    if (ids.length !== 1) return;
    openAssetModal(assetDataMap[ids[0]]);
}
function mutateSelectedAsset() {
    const ids = getSelectedAssetIds();
    if (ids.length !== 1) return;
    window.location.href = 'mutations.php?asset_id=' + encodeURIComponent(ids[0]);
}
function damageSelectedAsset() {
    const ids = getSelectedAssetIds();
    if (ids.length !== 1) return;
    window.location.href = 'damages.php?asset_id=' + encodeURIComponent(ids[0]);
}
function upgradeSelectedAsset() {
    const ids = getSelectedAssetIds();
    if (ids.length !== 1) return;
    window.location.href = 'asset_upgrade.php?asset_id=' + encodeURIComponent(ids[0]);
}
function printSelectedLabel() {
    const ids = getSelectedAssetIds();
    if (ids.length === 0) return;
    const qs = ids.map(id => 'ids[]=' + encodeURIComponent(id)).join('&');
    window.open('asset_print_label.php?' + qs, '_blank');
}
function printSelectedDetail() {
    const ids = getSelectedAssetIds();
    if (ids.length === 0) return;
    const qs = ids.map(id => 'ids[]=' + encodeURIComponent(id)).join('&');
    window.open('asset_detail_print.php?' + qs, '_blank');
}
function pdfSelectedAsset() {
    const ids = getSelectedAssetIds();
    if (ids.length === 0) return;
    const qs = ids.map(id => 'ids[]=' + encodeURIComponent(id)).join('&');
    window.location.href = 'asset_detail_pdf.php?' + qs;
}
// Export ke Excel: kalau ada baris yang dicentang, export HANYA baris itu.
// Kalau tidak ada yang dicentang, buka modal untuk memilih satu/beberapa
// Jenis Aset sekaligus (pencarian & filter Departement yang sedang aktif
// tetap dipertahankan). Kalau tidak pilih kategori apa pun di modal, export
// seluruh data (mengikuti pencarian/Departement yang aktif).
var exportScopeSelectedText = <?= json_encode(tRaw('export_scope_selected')) ?>;
var exportSummaryCatsText   = <?= json_encode(tRaw('export_summary_categories')) ?>;
var exportSummaryAllText    = <?= json_encode(tRaw('export_summary_all')) ?>;
var exportSummarySelText    = <?= json_encode(tRaw('export_summary_selected')) ?>;
var exportSummaryDeptText   = <?= json_encode(tRaw('export_summary_departments')) ?>;
var exportMatrix = <?= json_encode(array_map(fn($r) => [$r['category'], $r['department'], (int)$r['total']], $exportMatrix)) ?>;
// Tombol "Export ke Excel" SELALU membuka jendela pilihan, supaya bisa memilih
// satu atau beberapa Jenis Aset sekaligus (mis. Desktop PC + Laptop).
// Jika ada baris yang dicentang, tersedia juga pilihan "hanya aset yang dicentang".
function exportAssets() {
    openExportCategoryModal();
}
function openExportCategoryModal() {
    // Pre-check kategori yang sedang aktif di filter halaman (kalau ada), sisanya kosong.
    document.querySelectorAll('.export-cat-check').forEach(cb => {
        cb.checked = currentAssetFilterCategory !== '' && cb.value === currentAssetFilterCategory;
    });
    // Pre-check Departement yang sedang aktif di filter halaman (kalau ada).
    document.querySelectorAll('.export-dept-check').forEach(cb => {
        cb.checked = currentAssetFilterDepartment !== '' && cb.value === currentAssetFilterDepartment;
    });
    updateExportDeptAllState();
    const selCount = getSelectedAssetIds().length;
    document.getElementById('exportScopeBox').classList.toggle('hidden', selCount === 0);
    document.getElementById('exportScopeSelectedLabel').textContent = exportScopeSelectedText.replace('%d', selCount);
    document.querySelector('input[name="exportScope"][value="category"]').checked = true;
    updateExportCategoryAllState();
    document.getElementById('exportCategoryModal').classList.remove('hidden');
    document.getElementById('exportCategoryModal').classList.add('flex');
}
function closeExportCategoryModal() {
    document.getElementById('exportCategoryModal').classList.add('hidden');
    document.getElementById('exportCategoryModal').classList.remove('flex');
}
function toggleAllExportDepartments(master) {
    document.querySelectorAll('.export-dept-check').forEach(cb => cb.checked = master.checked);
    updateExportSummary();
}
function updateExportDeptAllState() {
    const all = document.getElementById('exportDeptAll');
    if (!all) return;
    const boxes = document.querySelectorAll('.export-dept-check');
    all.checked = boxes.length > 0 && document.querySelectorAll('.export-dept-check:checked').length === boxes.length;
    updateExportSummary();
}
function toggleAllExportCategories(master) {
    document.querySelectorAll('.export-cat-check').forEach(cb => cb.checked = master.checked);
    updateExportSummary();
}
function updateExportCategoryAllState() {
    const boxes = document.querySelectorAll('.export-cat-check');
    const checked = document.querySelectorAll('.export-cat-check:checked');
    document.getElementById('exportCatAll').checked = boxes.length > 0 && checked.length === boxes.length;
    updateExportSummary();
}
function exportScopeIsSelected() {
    const r = document.querySelector('input[name="exportScope"]:checked');
    return r && r.value === 'selected' && getSelectedAssetIds().length > 0;
}
function updateExportSummary() {
    const bySel = exportScopeIsSelected();
    ['exportCatList', 'exportDeptList'].forEach(id => {
        const list = document.getElementById(id);
        if (!list) return;
        list.classList.toggle('opacity-40', bySel);
        list.querySelectorAll('input').forEach(i => i.disabled = bySel);
    });
    const box = document.getElementById('exportSummary');
    if (bySel) { box.textContent = exportSummarySelText.replace('%d', getSelectedAssetIds().length); return; }
    const cats  = Array.from(document.querySelectorAll('.export-cat-check:checked')).map(cb => cb.value);
    const depts = Array.from(document.querySelectorAll('.export-dept-check:checked')).map(cb => cb.value);
    // Jumlah aset = kombinasi Jenis x Departement yang dipilih (kosong = semua).
    const total = exportMatrix.reduce((n, [c, d, cnt]) =>
        n + ((cats.length === 0 || cats.includes(c)) && (depts.length === 0 || depts.includes(d)) ? cnt : 0), 0);
    let text = cats.length === 0
        ? exportSummaryAllText.replace(' (%d', '%DEPT (%d')
        : exportSummaryCatsText.replace('%s', cats.join(', ')).replace(' (%d', '%DEPT (%d');
    text = text.replace('%DEPT', depts.length ? exportSummaryDeptText.replace('%s', depts.join(', ')) : '').replace('%d', total);
    box.textContent = text;
    document.getElementById('btnDoExport').disabled = total === 0;
    document.getElementById('btnDoExport').classList.toggle('opacity-40', total === 0);
}
function submitExportCategory() {
    if (exportScopeIsSelected()) {
        const qsSel = getSelectedAssetIds().map(id => 'ids[]=' + encodeURIComponent(id)).join('&');
        window.location.href = 'export_excel.php?' + qsSel;
        closeExportCategoryModal();
        return;
    }
    const cats = Array.from(document.querySelectorAll('.export-cat-check:checked')).map(cb => cb.value);
    const qs = [];
    cats.forEach(c => qs.push('category[]=' + encodeURIComponent(c)));
    if (currentAssetFilterSearch) qs.push('q=' + encodeURIComponent(currentAssetFilterSearch));
    if (currentAssetFilterLocation) qs.push('location=' + encodeURIComponent(currentAssetFilterLocation)); // export ikut filter Lokasi yang aktif
    // Departement dipilih lewat centang di jendela export (bisa lebih dari satu).
    document.querySelectorAll('.export-dept-check:checked').forEach(cb => qs.push('department[]=' + encodeURIComponent(cb.value)));
    window.location.href = 'export_excel.php' + (qs.length ? '?' + qs.join('&') : '');
    closeExportCategoryModal();
}
function deleteSelectedAssets() {
    const ids = getSelectedAssetIds();
    if (ids.length === 0) return;
    if (ids.length === 1) {
        const asset = assetDataMap[ids[0]];
        const msg = singleDeleteConfirmText.replace('%s', asset ? asset.asset_number : '');
        if (confirmDelete(msg)) {
            window.location.href = 'asset_delete.php?id=' + ids[0];
        }
    } else {
        document.getElementById('assetBulkForm').requestSubmit();
    }
}
// Generate ulang Nomor Aset otomatis untuk aset yang dicentang di tabel
// (beda dengan tombol "Buatkan Otomatis" di dalam modal, yang cuma usulan
// untuk SATU aset yang sedang diisi). Tombol ini LANGSUNG menimpa Nomor Aset
// di database untuk semua baris yang dicentang, jadi selalu minta konfirmasi dulu.
function generateNumberSelectedAssets() {
    const ids = getSelectedAssetIds();
    if (ids.length === 0) return;
    if (!confirmDelete(genNumberBulkConfirmText.replace('%d', ids.length))) return;
    const container = document.getElementById('assetGenerateNumberIds');
    container.innerHTML = ids.map(id => '<input type="hidden" name="ids[]" value="' + id + '">').join('');
    document.getElementById('assetGenerateNumberForm').requestSubmit();
}
</script>

<?php require __DIR__ . '/includes/scan_modal.php'; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
