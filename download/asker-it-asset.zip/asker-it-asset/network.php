<?php
/**
 * Menu Jaringan (khusus admin).
 *   Tab Cek jaringan : cek manual aset ber-IP (ping + port TCP cadangan), per kelompok kecil dengan progress.
 *   Tab Topologi     : gambar otomatis dari kolom "Terhubung ke"; switch tanpa IP disimpulkan dari aset di bawahnya.
 *   Tab Scan         : ping seluruh subnet /24 + tabel ARP, tandai perangkat yang belum terdaftar di Aset.
 *   Tab Data koneksi : isi "Terhubung ke" & port per aset, termasuk isi massal per lokasi.
 *   Tab Pengaturan   : batas lambat, jumlah paket ping, daftar subnet.
 * Tidak ada pengecekan otomatis terjadwal: semua berjalan saat tombol ditekan.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/network.php';

$db = getDB();
ensureNetTables($db);
$h = fn($v) => htmlspecialchars((string)$v);
$json = function ($data) { header('Content-Type: application/json'); header('Cache-Control: no-store'); echo json_encode($data); exit; };
$me = currentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $act = (string)($_POST['action'] ?? '');

    // ---- AJAX: cek sekelompok aset
    if ($act === 'check') {
        session_write_close();
        $ids = array_slice(array_map('intval', (array)($_POST['ids'] ?? [])), 0, 30);
        $json(['ok' => true, 'results' => array_values(netCheckAssets($db, $ids))]);
    }
    if ($act === 'check_done') {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
        netLogCheck($db, $ids, (string)($me['full_name'] ?? ''));
        $json(['ok' => true, 'suspects' => netSuspects(netAssets($db))]);
    }
    // ---- AJAX: scan subnet per potongan
    if ($act === 'scan_chunk') {
        session_write_close();
        $sn = netParseSubnet((string)($_POST['subnet'] ?? ''));
        if (!$sn) $json(['ok' => false, 'error' => nL('Subnet tidak valid', 'Invalid subnet')]);
        $from = max(1, (int)($_POST['from'] ?? 1)); $to = min(254, (int)($_POST['to'] ?? 254));
        $ips = []; for ($i = $from; $i <= $to; $i++) $ips[] = $sn[0] . $i;
        $json(['ok' => true, 'found' => netScanChunk($ips)]);
    }
    if ($act === 'scan_finish') {
        session_write_close();
        $sn = netParseSubnet((string)($_POST['subnet'] ?? ''));
        if (!$sn) $json(['ok' => false, 'error' => nL('Subnet tidak valid', 'Invalid subnet')]);
        $found = json_decode((string)($_POST['found'] ?? '{}'), true) ?: [];
        $arp = netArpTable();
        $byIp = [];
        foreach (netAssets($db) as $a) {
            if ($a['ip'] !== '') $byIp[$a['ip']] = $a;
            foreach ($a['ips'] as $seg) { $sip = explode('/', $seg)[0]; if (!isset($byIp[$sip])) $byIp[$sip] = ['id' => $a['id'], 'name' => $a['name'], 'number' => $a['number']]; }   // IP segmen lain router
        }
        // Juga cocokkan aset yang IP-nya ada di kolom IP (mis. "192.168.1.5 / 192.168.1.6").
        foreach ($db->query("SELECT id, asset_number, device_name, ip_address FROM assets WHERE ip_address IS NOT NULL AND ip_address <> ''")->fetchAll() as $r) {
            if (preg_match_all('/\d{1,3}(?:\.\d{1,3}){3}/', (string)$r['ip_address'], $mm)) foreach ($mm[0] as $ip) if (!isset($byIp[$ip])) $byIp[$ip] = ['id' => (int)$r['id'], 'name' => (string)($r['device_name'] ?: $r['asset_number']), 'number' => (string)$r['asset_number']];
        }
        $rows = []; $t0 = microtime(true);
        uksort($found, fn($x, $y) => ip2long($x) <=> ip2long($y));
        foreach ($found as $ip => $ms) {
            $mac = $arp[$ip] ?? '';
            // Nama host (DNS/NetBIOS) dicari maks. ±8 detik total agar scan tidak lama.
            $host = microtime(true) - $t0 < 8 ? (string)@gethostbyaddr($ip) : '';
            if ($host === $ip) $host = '';
            $a = $byIp[$ip] ?? null;
            $rows[] = ['ip' => $ip, 'ms' => (int)$ms, 'mac' => $mac, 'vendor' => $mac ? netVendor($mac) : '', 'host' => $host,
                       'asset_id' => $a['id'] ?? null, 'asset_name' => $a['name'] ?? '', 'asset_no' => $a['number'] ?? ''];
        }
        $missing = [];
        foreach ($byIp as $ip => $a) if (strpos($ip, $sn[0]) === 0 && !isset($found[$ip]) && isset($a['type'])) $missing[] = $a['name'] . ' (' . $ip . ')';
        $data = ['subnet' => $sn[0] . '0/24', 'scanned_at' => date('Y-m-d H:i:s'), 'rows' => $rows, 'missing' => $missing];
        @file_put_contents(netScanFile($sn[0]), json_encode($data), LOCK_EX);
        $json(['ok' => true] + $data);
    }
    // ---- Form biasa
    $back = function (string $tab, string $msg, bool $ok = true) {
        $_SESSION['net_msg'] = ['ok' => $ok, 'text' => $msg];
        header('Location: network.php?tab=' . $tab);
        exit;
    };
    if ($act === 'links_save') {
        $par = (array)($_POST['parent'] ?? []); $prt = (array)($_POST['port'] ?? []); $own = (array)($_POST['own_port'] ?? []);
        $n = 0; $bad = 0;
        foreach ($par as $id => $p) {
            $p = (int)$p > 0 ? (int)$p : null;
            if (netSetLink($db, (int)$id, $p, trim((string)($prt[$id] ?? '')))) { $n++; netSaveOwnPort($db, (int)$id, $p ? (string)($own[$id] ?? '') : ''); } else $bad++;
        }
        $back('links', nL("Data koneksi disimpan ($n aset).", "Connections saved ($n assets).") . ($bad ? ' ' . nL("$bad baris dilewati karena membuat lingkaran (aset terhubung ke perangkat di bawahnya sendiri).", "$bad rows skipped (circular link).") : ''), !$bad);
    }
    if ($act === 'links_bulk_sel') {
        // Aset yang dicentang: hubungkan semuanya ke 1 perangkat, atau lepas koneksinya (to = 0).
        $ids = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['ids'] ?? [])))));
        $to = (int)($_POST['to'] ?? 0);
        $n = 0; $bad = 0;
        foreach ($ids as $id) {
            if ($to && $id === $to) { $bad++; continue; }
            $cur = netLinkOf($db, $id);
            $keepPort = $to && $cur['parent'] === $to;   // induk sama -> port lama tetap
            if (netSetLink($db, $id, $to ?: null, $keepPort ? $cur['port'] : '')) { $n++; if (!$to || !$keepPort) netSaveOwnPort($db, $id, ''); } else $bad++;
        }
        $msgTxt = $to ? nL("$n aset dihubungkan ke " . ($all0 = netAssets($db))[$to]['name'] . '.', "$n assets linked.") : nL("Koneksi $n aset dilepas.", "$n assets unlinked.");
        $back('links', $msgTxt . ($bad ? ' ' . nL("$bad dilewati (perangkat itu sendiri / sambungan melingkar).", "$bad skipped (self / circular).") : ''), !$bad);
    }
    if ($act === 'ports_eth') {
        $n = netNormalizePortNames($db, true);
        $back('links', nL("$n nama port diubah menjadi format eth.", "$n port names changed to eth."));
    }
    if ($act === 'extra_add') {
        $err = netAddExtraLink($db, (int)($_POST['a'] ?? 0), (int)($_POST['b'] ?? 0), (string)($_POST['port_a'] ?? ''), (string)($_POST['port_b'] ?? ''));
        $back('links', $err === '' ? nL('Koneksi tambahan disimpan.', 'Extra link saved.') : $err, $err === '');
    }
    if ($act === 'extra_del') {
        netDeleteExtraLink($db, (int)($_POST['id'] ?? 0));
        $back('links', nL('Koneksi tambahan dihapus.', 'Extra link removed.'));
    }
    if ($act === 'links_bulk') {
        $loc = (string)($_POST['loc'] ?? ''); $to = (int)($_POST['to'] ?? 0);
        $n = 0;
        foreach (netAssets($db) as $a) {
            if ($a['loc'] !== $loc || $a['id'] === $to || $a['is_net']) continue;   // switch/router diatur satu per satu
            $cur = $a['port'];
            if (netSetLink($db, $a['id'], $to ?: null, $cur)) $n++;
        }
        $back('links', nL("$n aset di lokasi $loc dihubungkan.", "$n assets in $loc linked."));
    }
    // ---- AJAX: posisi bebas topologi (mode Geser bebas)
    if ($act === 'topo_pos') {
        $map = json_decode((string)($_POST['pos'] ?? '{}'), true);
        netSaveTopoPos($db, is_array($map) ? $map : []);
        $json(['ok' => true]);
    }
    if ($act === 'topo_pos_reset') {
        netResetTopoPos($db);
        $json(['ok' => true]);
    }
    if ($act === 'settings_save') {
        $subs = [];
        foreach (preg_split('/[\s,;]+/', (string)($_POST['subnets'] ?? ''), -1, PREG_SPLIT_NO_EMPTY) as $s) if ($p = netParseSubnet($s)) $subs[] = $p[0] . '0/24';
        saveNetSettings([
            'warn_ms'    => max(10, min(5000, (int)($_POST['warn_ms'] ?? 100))),
            'warn_loss'  => max(1, min(100, (int)($_POST['warn_loss'] ?? 5))),
            'ping_count' => in_array((int)($_POST['ping_count'] ?? 4), [1, 2, 4], true) ? (int)$_POST['ping_count'] : 4,
            'subnets'    => array_values(array_unique($subs)),
        ]);
        $back('settings', nL('Pengaturan jaringan disimpan.', 'Network settings saved.'));
    }
}

$msg = $_SESSION['net_msg'] ?? null;
unset($_SESSION['net_msg']);
$tab = in_array($_GET['tab'] ?? 'check', ['check', 'topo', 'scan', 'links', 'settings'], true) ? $_GET['tab'] : 'check';
$set = netSettings();
$all = netAssets($db);
$suspects = netSuspects($all);
$withIp = array_filter($all, fn($a) => $a['ip'] !== '');
$cnt = ['ok' => 0, 'warn' => 0, 'err' => 0, 'na' => 0];
foreach ($withIp as $a) $cnt[$a['state'] && isset($cnt[$a['state']]) ? $a['state'] : 'na']++;
$lastCheck = $db->query("SELECT * FROM net_checks ORDER BY id DESC LIMIT 8")->fetchAll();
$parents = array_filter($all, fn($a) => $a['is_net']);
$extras = array_values(array_filter(netExtraLinks($db), fn($l) => isset($all[$l['a']], $all[$l['b']])));
$usedPorts = netUsedPorts($all, $extras);
/** Datalist pilihan port per perangkat jaringan (id "pl_<id>"); port terpakai diberi keterangan. */
$portLists = function () use ($parents, $usedPorts, $h) {
    $out = '';
    foreach ($parents as $p) {
        $out .= '<datalist id="pl_' . $p['id'] . '">';
        foreach (netPortNames($p) as $pn) {
            $u = netIsMultiDevice($p) ? '' : ($usedPorts[$p['id']][mb_strtolower($pn)] ?? '');   // switch FO: port boleh dipakai bersama
            $out .= '<option value="' . $h($pn) . '"' . ($u !== '' ? ' label="' . $h(nL('terpakai: ', 'used: ') . $u) . '"' : '') . '></option>';
        }
        $out .= '</datalist>';
    }
    return $out;
};
$locs = array_values(array_unique(array_filter(array_column($all, 'loc'))));
sort($locs);
$types = array_values(array_unique(array_column($withIp, 'type')));
sort($types);
// Subnet untuk scan: dari pengaturan, kalau kosong ditebak dari IP aset.
$subnets = $set['subnets'];
if (!$subnets) {
    $c = [];
    foreach ($withIp as $a) { $p = implode('.', array_slice(explode('.', $a['ip']), 0, 3)) . '.0/24'; $c[$p] = ($c[$p] ?? 0) + 1; }
    arsort($c); $subnets = array_keys(array_slice($c, 0, 6, true));
}
$savedScans = [];
foreach ($subnets as $sn) { $f = netScanFile(netParseSubnet($sn)[0] ?? ''); if (is_file($f) && ($d = json_decode((string)@file_get_contents($f), true))) $savedScans[$sn] = $d; }
$fmt = fn($d) => $d ? date('d M H:i', strtotime((string)$d)) : '-';
$stLabel = ['ok' => [nL('Normal', 'Normal'), 'bg-green-100 text-green-700'], 'warn' => [nL('Lambat', 'Slow'), 'bg-amber-100 text-amber-700'],
            'err' => [nL('Mati', 'Down'), 'bg-red-100 text-red-700'], 'na' => [nL('Belum dicek', 'Not checked'), 'bg-slate-100 text-slate-600']];
$badge = function (?string $s) use ($stLabel, $h) { [$l, $c] = $stLabel[$s && isset($stLabel[$s]) ? $s : 'na']; return '<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold whitespace-nowrap ' . $c . '"><span class="w-1.5 h-1.5 rounded-full bg-current"></span>' . $h($l) . '</span>'; };

$pageTitle = nL('Jaringan', 'Network');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="flex flex-wrap items-center justify-between gap-3 mb-3">
    <div>
        <h1 class="text-xl font-semibold text-slate-800"><?= $h(nL('Jaringan', 'Network')) ?></h1>
        <p class="text-sm text-slate-500"><?= $h(nL('Cek koneksi aset ber-IP saat dibutuhkan, lihat topologi, dan temukan perangkat yang belum terdaftar.', 'Check IP assets on demand, view the topology, and find unregistered devices.')) ?></p>
    </div>
</div>

<div class="flex gap-1 overflow-x-auto border-b border-slate-200 mb-4 text-sm">
    <?php foreach (['check' => nL('Cek jaringan', 'Check'), 'topo' => nL('Topologi', 'Topology'), 'scan' => nL('Scan jaringan', 'Scan'), 'links' => nL('Data koneksi', 'Connections'), 'settings' => nL('Pengaturan', 'Settings')] as $k => $label): ?>
        <a href="network.php?tab=<?= $k ?>" class="px-4 py-2.5 whitespace-nowrap border-b-2 <?= $tab === $k ? 'border-blue-600 text-blue-700 font-semibold' : 'border-transparent text-slate-500 hover:text-slate-700' ?>"><?= $h($label) ?></a>
    <?php endforeach; ?>
</div>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<div id="netSuspects">
<?php foreach ($suspects as $s): ?>
    <div class="mb-3 text-sm rounded-lg px-4 py-3 bg-red-50 border border-red-200 text-red-800 flex gap-2"><?= icon('alert') ?>
        <span><b><?= $h(nL('Kemungkinan ' . $s['name'] . ' mati atau kabel uplink-nya putus.', 'Possibly ' . $s['name'] . ' is down or its uplink is cut.')) ?></b>
        <?= $h(nL($s['down'] . ' dari ' . $s['total'] . ' aset di bawahnya tidak merespons', $s['down'] . ' of ' . $s['total'] . ' assets below it are not responding')) ?> (<?= $h(implode(', ', array_slice($s['names'], 0, 8)) . (count($s['names']) > 8 ? ', …' : '')) ?>).
        <?php if ($s['parent_name']): ?><?= $h(nL('Cek listrik/adaptor switch dan kabel ke ' . $s['parent_name'], 'Check its power and the cable to ' . $s['parent_name'])) ?><?= $s['port'] !== '' ? ' port ' . $h($s['port']) : '' ?>.<?php endif; ?></span></div>
<?php endforeach; ?>
</div>

<?php if ($tab === 'check'): ?>
<div class="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-4">
    <?php foreach ([[nL('Aset ber-IP', 'IP assets'), count($withIp), 'text-slate-800'], [nL('Normal', 'Normal'), $cnt['ok'], 'text-green-700'], [nL('Lambat', 'Slow'), $cnt['warn'], 'text-amber-600'], [nL('Mati', 'Down'), $cnt['err'], 'text-red-600'], [nL('Cek terakhir', 'Last check'), $lastCheck ? date('d M H:i', strtotime($lastCheck[0]['checked_at'])) : '-', 'text-slate-800']] as [$l, $v, $c]): ?>
        <div class="bg-white rounded-xl shadow-sm p-4"><p class="text-xs text-slate-500"><?= $h($l) ?></p><p class="text-2xl font-semibold tabular-nums <?= $c ?>"><?= $h($v) ?></p></div>
    <?php endforeach; ?>
</div>

<div class="bg-white rounded-xl shadow-sm p-3 mb-3 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Jenis', 'Type')) ?></span>
        <select id="fType" class="border border-slate-300 rounded-lg px-2 py-1.5"><option value=""><?= $h(nL('Semua', 'All')) ?></option><?php foreach ($types as $t): ?><option><?= $h($t) ?></option><?php endforeach; ?></select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Lokasi', 'Location')) ?></span>
        <select id="fLoc" class="border border-slate-300 rounded-lg px-2 py-1.5"><option value=""><?= $h(nL('Semua', 'All')) ?></option><?php foreach ($locs as $l): ?><option><?= $h($l) ?></option><?php endforeach; ?></select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Status', 'Status')) ?></span>
        <select id="fState" class="border border-slate-300 rounded-lg px-2 py-1.5"><option value=""><?= $h(nL('Semua', 'All')) ?></option><option value="err"><?= $h(nL('Mati', 'Down')) ?></option><option value="warn"><?= $h(nL('Lambat', 'Slow')) ?></option><option value="ok">Normal</option><option value="na"><?= $h(nL('Belum dicek', 'Not checked')) ?></option></select></label>
    <label class="flex flex-col gap-1 flex-1 min-w-[160px]"><span class="text-xs text-slate-500"><?= $h(nL('Cari', 'Search')) ?></span>
        <input id="fQ" type="search" placeholder="<?= $h(nL('Nama, no aset, IP', 'Name, asset no, IP')) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <button id="btnCheck" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium disabled:opacity-50"><?= icon('refresh') ?> <?= $h(nL('Cek sekarang', 'Check now')) ?></button>
    <label class="flex items-center gap-2 pb-2"><input type="checkbox" id="autoPage" class="w-4 h-4"> <?= $h(nL('Pantau selama halaman dibuka (tiap 1 menit)', 'Keep checking while this page is open (every minute)')) ?></label>
</div>
<div id="prog" class="hidden mb-3 flex items-center gap-3 text-sm text-slate-600"><span id="progTxt"></span><div class="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden"><div id="progBar" class="h-full bg-blue-600 transition-all" style="width:0"></div></div></div>

<div class="bg-white rounded-xl shadow-sm overflow-x-auto mb-4">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-slate-500 text-xs"><tr>
            <th class="px-3 py-2 w-8"><input type="checkbox" id="chkAll" class="w-4 h-4" title="<?= $h(nL('Pilih semua', 'Select all')) ?>"></th>
            <th class="text-left px-3 py-2"><?= $h(nL('Aset', 'Asset')) ?></th><th class="text-left px-3 py-2"><?= $h(nL('Jenis', 'Type')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(nL('Lokasi', 'Location')) ?></th><th class="text-left px-3 py-2">IP</th>
            <th class="text-left px-3 py-2"><?= $h(nL('Terhubung ke', 'Connected to')) ?></th><th class="text-left px-3 py-2">Status</th>
            <th class="text-right px-3 py-2">Ping</th><th class="text-right px-3 py-2"><?= $h(nL('Paket hilang', 'Loss')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(nL('Dicek', 'Checked')) ?></th><th class="px-3 py-2"></th>
        </tr></thead>
        <tbody id="netRows"></tbody>
    </table>
</div>
<p class="text-xs text-slate-500 mb-4"><?= $h(nL('Centang beberapa aset untuk mengecek sebagian saja; tanpa centang, semua aset yang tampil ikut dicek. Lambat = ping rata-rata ≥ ' . $set['warn_ms'] . ' ms atau paket hilang ≥ ' . $set['warn_loss'] . '%. Bila ping diblokir firewall, sistem mencoba port TCP (PC 445/3389, printer 9100, CCTV/NVR 80/554).', 'Tick assets to check only some. Slow = ping ≥ ' . $set['warn_ms'] . ' ms or loss ≥ ' . $set['warn_loss'] . '%. If ping is blocked, TCP ports are tried.')) ?></p>

<?php if ($lastCheck): ?>
<h2 class="font-semibold text-slate-800 mb-2"><?= $h(nL('Riwayat pengecekan', 'Check history')) ?></h2>
<div class="bg-white rounded-xl shadow-sm overflow-x-auto"><table class="w-full text-sm">
    <thead class="bg-slate-50 text-slate-500 text-xs"><tr><th class="text-left px-3 py-2"><?= $h(nL('Waktu', 'Time')) ?></th><th class="text-left px-3 py-2"><?= $h(nL('Oleh', 'By')) ?></th><th class="text-right px-3 py-2"><?= $h(nL('Dicek', 'Checked')) ?></th><th class="text-right px-3 py-2">Normal</th><th class="text-right px-3 py-2"><?= $h(nL('Lambat', 'Slow')) ?></th><th class="text-right px-3 py-2"><?= $h(nL('Mati', 'Down')) ?></th><th class="text-left px-3 py-2"><?= $h(nL('Bermasalah', 'Problems')) ?></th></tr></thead>
    <tbody><?php foreach ($lastCheck as $c): ?><tr class="border-t align-top">
        <td class="px-3 py-2 whitespace-nowrap tabular-nums"><?= $h(date('d M Y H:i', strtotime($c['checked_at']))) ?></td><td class="px-3 py-2"><?= $h($c['user_name']) ?></td>
        <td class="px-3 py-2 text-right tabular-nums"><?= (int)$c['total'] ?></td><td class="px-3 py-2 text-right tabular-nums text-green-700"><?= (int)$c['ok'] ?></td>
        <td class="px-3 py-2 text-right tabular-nums text-amber-600"><?= (int)$c['warn'] ?></td><td class="px-3 py-2 text-right tabular-nums text-red-600"><?= (int)$c['err'] ?></td>
        <td class="px-3 py-2 text-xs text-slate-600 whitespace-pre-line"><?= $h($c['summary'] ?? '-') ?></td></tr><?php endforeach; ?></tbody>
</table></div>
<?php endif; ?>

<?php elseif ($tab === 'topo'): ?>
<div class="bg-white rounded-xl shadow-sm p-3 mb-3 flex flex-wrap items-center gap-3 text-sm">
    <label class="flex items-center gap-2"><?= $h(nL('Lokasi', 'Location')) ?>
        <select id="tLoc" class="border border-slate-300 rounded-lg px-2 py-1.5"><option value=""><?= $h(nL('Semua', 'All')) ?></option><?php foreach ($locs as $l): ?><option><?= $h($l) ?></option><?php endforeach; ?></select></label>
    <label class="flex items-center gap-2 cursor-pointer"><input type="checkbox" id="tGroup" checked class="rounded"> <?= $h(nL('Kotak per lokasi', 'Box per location')) ?></label>
    <label class="flex items-center gap-2 cursor-pointer"><input type="checkbox" id="tCable" checked class="rounded"> <?= $h(nL('Warna kabel per switch / router', 'Cable color per switch / router')) ?></label>
    <button type="button" id="tArrange" class="inline-flex items-center gap-1 border border-slate-300 rounded-lg px-3 py-1.5 hover:bg-slate-50">&#10021; <?= $h(nL('Geser bebas', 'Free move')) ?></button>
    <label class="flex items-center gap-2"><input type="search" id="tQ" placeholder="<?= $h(nL('Cari perangkat / aset…', 'Find device / asset…')) ?>" class="border border-slate-300 rounded-lg px-3 py-1.5 w-56"><span id="tQn" class="text-xs text-slate-500"></span></label>
    <span class="flex flex-wrap gap-2 text-xs"><?= $badge('ok') ?><?= $badge('warn') ?><span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-700"><span class="w-1.5 h-1.5 rounded-full bg-current"></span><?= $h(nL('Mati / diduga mati', 'Down / suspected')) ?></span><span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600"><span class="w-1.5 h-1.5 rounded-full bg-current"></span><?= $h(nL('Tanpa IP / belum dicek', 'No IP / not checked')) ?></span><span class="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-semibold text-blue-700"><svg width="22" height="6"><line x1="0" y1="3" x2="22" y2="3" stroke="#2563eb" stroke-width="2" stroke-dasharray="5 3"/></svg><?= $h(nL('Koneksi tambahan', 'Extra link')) ?></span><span class="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-semibold text-slate-600"><svg width="18" height="12"><rect x="1" y="1" width="16" height="10" rx="3" fill="#fff" stroke="#64748b" stroke-width="1.2" stroke-dasharray="3 2"/></svg><?= $h(nL('Belum dihubungkan (ditaruh di kotak lokasinya)', 'Not linked (placed in its location box)')) ?></span></span>
    <a href="network.php?tab=links" class="ml-auto text-blue-600 hover:underline"><?= $h(nL('Ubah data koneksi', 'Edit connections')) ?> &rarr;</a>
</div>
<style>#topo.arr .node { cursor: grab !important; touch-action: none; user-select: none; } #topo .node.dragging > rect:first-child { stroke: #f59e0b !important; stroke-width: 3 !important; } #topo .node.dragging { filter: drop-shadow(0 6px 10px rgba(15,23,42,.3)); } #topo.arr svg { background-image: radial-gradient(#cbd5e1 1px, transparent 1px); background-size: 20px 20px; }</style>
<div id="tArrBar" style="top: calc(-1 * var(--main-pad, 0px));" class="hidden sticky z-20 bg-amber-50 border border-amber-300 rounded-xl shadow-md p-3 mb-3 flex flex-wrap items-center gap-2 text-sm">
    <span class="font-semibold text-amber-800">&#10021; <?= $h(nL('Mode geser bebas', 'Free move mode')) ?></span>
    <span class="text-amber-800"><?= $h(nL('Tahan klik pada kotak lalu geser ke mana saja; garis koneksi ikut menyesuaikan. Tahan Shift saat menggeser untuk ikut memindahkan seluruh cabang di bawahnya.', 'Hold and drag a box anywhere; lines follow. Hold Shift to move the whole branch below it.')) ?></span>
    <span id="tArrDirty" class="hidden text-xs font-semibold text-amber-700">&#9679; <?= $h(nL('Belum disimpan', 'Unsaved')) ?></span>
    <span class="ml-auto flex flex-wrap gap-2">
        <button type="button" id="tArrSave" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-semibold"><?= $h(nL('Simpan posisi', 'Save positions')) ?></button>
        <button type="button" id="tArrCancel" class="border border-slate-300 bg-white rounded-lg px-3 py-1.5"><?= $h(nL('Selesai / batal', 'Done / cancel')) ?></button>
        <button type="button" id="tArrReset" class="border border-red-300 text-red-700 bg-white rounded-lg px-3 py-1.5"><?= $h(nL('Kembali ke susunan otomatis', 'Back to automatic layout')) ?></button>
    </span>
</div>
<div class="bg-white rounded-xl shadow-sm p-3 mb-3 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Isi cetakan', 'Print content')) ?></span>
        <select id="pNet" class="border border-slate-300 rounded-lg px-2 py-1.5"><option value="0"><?= $h(nL('Semua aset ber-IP & perangkat jaringan', 'All IP assets & network devices')) ?></option><option value="1"><?= $h(nL('Perangkat jaringan saja (lebih ringkas)', 'Network devices only (compact)')) ?></option></select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Kertas', 'Paper')) ?></span>
        <select id="pOrient" class="border border-slate-300 rounded-lg px-2 py-1.5"><option value="portrait">A4 <?= $h(nL('tegak', 'portrait')) ?></option><option value="landscape">A4 <?= $h(nL('mendatar', 'landscape')) ?></option></select></label>
    <button type="button" id="btnTopoPrint" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium"><?= icon('printer') ?> <?= $h(nL('Cetak', 'Print')) ?></button>
    <button type="button" id="btnTopoPdf" class="inline-flex items-center gap-2 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 font-medium"><?= icon('download') ?> <?= $h(nL('Simpan PDF', 'Save PDF')) ?></button>
    <span class="text-xs text-slate-500 pb-2"><?= $h(nL('Memakai kop surat & filter lokasi di atas. Topologi panjang otomatis dipotong per halaman.', 'Uses the letterhead & location filter above. Long topologies are split across pages.')) ?></span>
</div>
<div id="topo" class="bg-slate-50 border border-slate-200 rounded-xl overflow-x-auto mb-3"></div>
<div id="nodeInfo" class="bg-white rounded-xl shadow-sm p-4 text-sm text-slate-600"><?= $h(nL('Klik kotak perangkat untuk melihat detailnya.', 'Click a device box for details.')) ?></div>
<p class="text-xs text-slate-500 mt-2"><?= $h(nL('Topologi disusun otomatis dari kolom "Terhubung ke" (tab Data koneksi). Aset yang belum dihubungkan tampil di bawah "Belum dihubungkan". Switch biasa (tanpa IP) berwarna merah bila semua aset di bawahnya mati pada pengecekan terakhir.', 'Built automatically from the "Connected to" data. Switches without IP turn red when every asset below them is down.')) ?></p>

<?php elseif ($tab === 'scan'): ?>
<div class="bg-white rounded-xl shadow-sm p-3 mb-3 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">Subnet</span>
        <select id="sNet" class="border border-slate-300 rounded-lg px-2 py-1.5 font-mono"><?php foreach ($subnets as $s): ?><option><?= $h($s) ?></option><?php endforeach; ?></select></label>
    <button id="btnScan" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium disabled:opacity-50"><?= icon('search') ?> <?= $h(nL('Mulai scan', 'Start scan')) ?></button>
    <span class="text-xs text-slate-500"><?= $h(nL('Ping 1 paket ke 254 alamat, lalu membaca tabel ARP server. Subnet lain bisa ditambah di tab Pengaturan.', 'Pings 254 addresses once, then reads the server ARP table. Add subnets in Settings.')) ?></span>
</div>
<div id="sProg" class="hidden mb-3 flex items-center gap-3 text-sm text-slate-600"><span id="sTxt"></span><div class="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden"><div id="sBar" class="h-full bg-blue-600 transition-all" style="width:0"></div></div></div>
<div id="sSum"></div>
<div class="bg-white rounded-xl shadow-sm overflow-x-auto"><table class="w-full text-sm">
    <thead class="bg-slate-50 text-slate-500 text-xs"><tr><th class="text-left px-3 py-2">IP</th><th class="text-left px-3 py-2">MAC</th><th class="text-left px-3 py-2"><?= $h(nL('Perkiraan merek', 'Vendor')) ?></th><th class="text-left px-3 py-2"><?= $h(nL('Nama host', 'Hostname')) ?></th><th class="text-right px-3 py-2">Ping</th><th class="text-left px-3 py-2"><?= $h(nL('Di menu Aset', 'In Assets')) ?></th></tr></thead>
    <tbody id="sRows"><tr><td colspan="6" class="px-3 py-6 text-center text-slate-500"><?= $h(nL('Pilih subnet lalu klik Mulai scan. Hasil scan terakhir tiap subnet disimpan.', 'Pick a subnet and start the scan.')) ?></td></tr></tbody>
</table></div>
<?php if (!netOuiAvailable()): ?>
<p class="text-xs text-slate-500 mt-2"><?= $h(nL('Kolom merek kosong karena daftar OUI belum ada. Unduh file oui.csv dari https://standards-oui.ieee.org/oui/oui.csv lalu simpan sebagai includes\data\oui.csv.', 'Vendor column is empty: download oui.csv from https://standards-oui.ieee.org/oui/oui.csv into includes/data/oui.csv.')) ?></p>
<?php endif; ?>
<p class="text-xs text-slate-500 mt-1"><?= $h(nL('MAC hanya terbaca untuk perangkat di subnet yang sama dengan server; subnet lain dilewati router sehingga MAC-nya tidak terlihat.', 'MAC is only visible for devices on the server subnet.')) ?></p>

<?php elseif ($tab === 'links'): ?>
<p class="text-sm text-slate-600 mb-3"><?= $h(nL('Isi aset terhubung ke switch / router mana. Switch biasa (tanpa IP) daftarkan dulu di menu Aset dengan kategori yang mengandung kata "Switch" (mis. "Switch"), tanpa IP. Router/Hub/Firewall juga dikenali dari nama kategorinya.', 'Set which switch/router each asset connects to. Register unmanaged switches as assets (category containing "Switch") without IP.')) ?></p>
<form method="post" class="bg-white rounded-xl shadow-sm p-3 mb-3 flex flex-wrap items-end gap-3 text-sm">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="links_bulk">
    <span class="text-slate-600 pb-2 font-medium"><?= $h(nL('Isi massal:', 'Bulk:')) ?></span>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Semua aset (selain switch/router) di lokasi', 'All assets (except switches/routers) in')) ?></span><select name="loc" class="border border-slate-300 rounded-lg px-2 py-1.5"><?php foreach ($locs as $l): ?><option><?= $h($l) ?></option><?php endforeach; ?></select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('terhubung ke', 'connect to')) ?></span><select name="to" class="border border-slate-300 rounded-lg px-2 py-1.5"><?php foreach ($parents as $p): ?><option value="<?= $p['id'] ?>"><?= $h($p['name']) ?></option><?php endforeach; ?></select></label>
    <button class="px-4 py-2 rounded-lg border border-slate-300 hover:bg-slate-50" <?= $parents ? '' : 'disabled' ?>><?= $h(nL('Terapkan', 'Apply')) ?></button>
    <?php if (!$parents): ?><span class="text-xs text-amber-700 pb-2"><?= $h(nL('Belum ada aset switch/router. Tambahkan dulu di menu Aset.', 'No switch/router assets yet.')) ?></span><?php endif; ?>
</form>
<?= $portLists() ?>
<?php $oldPortNames = netNormalizePortNames($db, false); if ($oldPortNames): ?>
<form method="post" class="mb-3 text-sm rounded-lg px-4 py-2.5 bg-amber-50 border border-amber-200 text-amber-900 flex flex-wrap items-center gap-3">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="ports_eth">
    <span><?= $h(nL("Ada $oldPortNames nama port format lama (ether… / port… / angka saja). Seragamkan menjadi eth… (mis. ether8 → eth8, 5 → eth5)?", "$oldPortNames port names use the old format (ether… / port…). Convert to eth…?")) ?></span>
    <button class="rounded-lg bg-amber-600 hover:bg-amber-700 text-white px-3 py-1.5 font-medium"><?= $h(nL('Ubah sekarang', 'Convert now')) ?></button>
</form>
<?php endif; ?>
<div class="bg-white rounded-xl shadow-sm p-4 mb-3 text-sm">
    <h2 class="font-semibold text-slate-800"><?= $h(nL('Koneksi tambahan', 'Extra links')) ?></h2>
    <p class="text-xs text-slate-500 mb-3"><?= $h(nL('Untuk perangkat yang tersambung ke lebih dari satu switch/router, mis. router dengan 2 uplink, jalur cadangan, atau NVR / server dengan 2 port LAN. "Terhubung ke" di tabel bawah tetap jalur utama (LAN 1); koneksi tambahan (LAN 2) digambar garis putus-putus biru di topologi. Switch FO / media converter (nama atau jenis mengandung FO, fiber, optik, converter) boleh dipakai banyak koneksi, termasuk port yang sama.', 'For devices connected to more than one switch/router, e.g. a router with 2 uplinks or an NVR / server with 2 LAN ports. "Connected to" below stays the main path; extra links are drawn as dashed blue lines.')) ?></p>
    <?php if ($extras): ?>
    <ul class="mb-3 divide-y border rounded-lg">
        <?php foreach ($extras as $l): ?>
        <li class="flex flex-wrap items-center gap-2 px-3 py-2">
            <span class="font-medium"><?= $h($all[$l['a']]['name']) ?></span><?php if ($l['port_a'] !== ''): ?><span class="text-xs font-mono bg-slate-100 rounded px-1.5"><?= $h($l['port_a']) ?></span><?php endif; ?>
            <span class="text-blue-600">&#8646;</span>
            <?php if ($l['port_b'] !== ''): ?><span class="text-xs font-mono bg-slate-100 rounded px-1.5"><?= $h($l['port_b']) ?></span><?php endif; ?><span class="font-medium"><?= $h($all[$l['b']]['name']) ?></span>
            <form method="post" class="ml-auto" onsubmit="return confirm('<?= $h(nL('Hapus koneksi tambahan ini?', 'Remove this extra link?')) ?>')">
                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="extra_del"><input type="hidden" name="id" value="<?= $l['id'] ?>">
                <button class="text-xs text-red-600 hover:underline"><?= $h(nL('Hapus', 'Remove')) ?></button>
            </form>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
    <form method="post" class="flex flex-wrap items-end gap-3">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="extra_add">
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Perangkat / aset (mis. NVR dengan 2 LAN)', 'Device / asset (e.g. NVR with 2 LAN)')) ?></span><select name="a" data-port="xa" data-combo class="port-src border border-slate-300 rounded-lg px-2 py-1.5 max-w-[260px]">
            <optgroup label="<?= $h(nL('Switch / router / AP', 'Switch / router / AP')) ?>"><?php foreach ($parents as $p): ?><option value="<?= $p['id'] ?>"><?= $h($p['name']) ?></option><?php endforeach; ?></optgroup>
            <optgroup label="<?= $h(nL('Aset lain (NVR, server, PC, …)', 'Other assets (NVR, server, PC, …)')) ?>"><?php $others = array_filter($all, fn($x) => !$x['is_net']); uasort($others, fn($x, $y) => strcasecmp($x['name'], $y['name'])); foreach ($others as $o): ?><option value="<?= $o['id'] ?>"><?= $h($o['name'] . ($o['type'] !== '' ? ' · ' . $o['type'] : '') . ($o['ip'] !== '' ? ' · ' . $o['ip'] : '')) ?></option><?php endforeach; ?></optgroup>
        </select></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Port di perangkat ini', 'Port on this device')) ?></span><input name="port_a" id="xa" maxlength="30" placeholder="eth2 / LAN2" autocomplete="off" class="border border-slate-300 rounded-lg px-2 py-1.5 w-28 font-mono"></label>
        <span class="pb-2 text-blue-600 font-semibold">&#8646;</span>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('juga terhubung ke', 'also connected to')) ?></span><select name="b" data-port="xb" data-combo class="port-src border border-slate-300 rounded-lg px-2 py-1.5"><?php foreach ($parents as $p): ?><option value="<?= $p['id'] ?>"><?= $h($p['name']) ?></option><?php endforeach; ?></select></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Port di perangkat tujuan', 'Port on the other device')) ?></span><input name="port_b" id="xb" maxlength="30" placeholder="eth16" autocomplete="off" class="border border-slate-300 rounded-lg px-2 py-1.5 w-28 font-mono"></label>
        <button class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium" <?= count($parents) > 1 ? '' : 'disabled' ?>><?= $h(nL('Tambah koneksi', 'Add link')) ?></button>
    </form>
</div>
<form method="post">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="links_save">
    <!-- Tombol simpan di atas tabel & tetap terlihat saat tabel di-scroll -->
    <style>
        /* Bar Simpan menempel di atas; judul kolom tabel menempel tepat di bawahnya (tidak saling tumpuk). */
        .links-save-bar { position: sticky; top: calc(-1 * var(--main-pad, 0px)); z-index: 25; }
        .links-table > thead > tr > th { top: calc(var(--lsb-h, 56px) - var(--main-pad, 0px)) !important; }
    </style>
    <div id="linksBar" class="links-save-bar -mx-1 px-1 py-2 mb-2 bg-slate-100 space-y-2">
        <div class="flex flex-wrap items-center gap-3">
            <button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium shadow-sm"><?= $h(nL('Simpan data koneksi', 'Save connections')) ?></button>
            <span id="linksDirty" class="hidden text-xs font-medium text-amber-700 bg-amber-50 border border-amber-200 rounded-full px-2.5 py-1"><?= $h(nL('Ada perubahan yang belum disimpan', 'Unsaved changes')) ?></span>
            <input type="search" id="lkQ" placeholder="<?= $h(nL('Cari aset / perangkat: nama, no aset, IP, terhubung ke…', 'Search asset / device: name, asset no, IP, connected to…')) ?>" class="flex-1 min-w-[220px] border border-slate-300 rounded-lg px-3 py-2 text-sm bg-white">
            <select id="lkType" class="border border-slate-300 rounded-lg px-2 py-2 text-sm bg-white"><option value=""><?= $h(nL('Semua jenis', 'All types')) ?></option><?php foreach (array_values(array_unique(array_column($all, 'type'))) as $tp): ?><option><?= $h($tp) ?></option><?php endforeach; ?></select>
            <select id="lkLoc" class="border border-slate-300 rounded-lg px-2 py-2 text-sm bg-white"><option value=""><?= $h(nL('Semua lokasi', 'All locations')) ?></option><?php foreach ($locs as $l): ?><option><?= $h($l) ?></option><?php endforeach; ?></select>
            <span id="lkCount" class="text-xs text-slate-500"></span>
        </div>
        <div id="lkBulk" class="hidden flex flex-wrap items-center gap-2 text-sm bg-blue-50 border border-blue-200 rounded-lg px-3 py-2">
            <b class="text-blue-800"><span id="lkSelN">0</span> <?= $h(nL('aset dicentang', 'selected')) ?></b>
            <span class="text-slate-600"><?= $h(nL('— hubungkan semuanya ke', '— link all to')) ?></span>
            <select id="lkTo" data-combo class="border border-slate-300 rounded-lg px-2 py-1.5 bg-white"><?php foreach ($parents as $p): ?><option value="<?= $p['id'] ?>"><?= $h($p['name'] . ($p['loc'] ? ' · ' . $p['loc'] : '')) ?></option><?php endforeach; ?></select>
            <button type="button" id="lkApply" class="rounded-lg bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 font-medium"><?= $h(nL('Terapkan', 'Apply')) ?></button>
            <button type="button" id="lkUnlink" class="rounded-lg border border-red-300 text-red-700 hover:bg-red-50 px-3 py-1.5 font-medium"><?= $h(nL('Lepas koneksi', 'Unlink')) ?></button>
            <button type="button" id="lkClear" class="ml-auto text-xs text-slate-500 hover:underline"><?= $h(nL('Batal pilih', 'Clear selection')) ?></button>
        </div>
    </div>
    <div class="bg-white rounded-xl shadow-sm overflow-x-auto mb-3"><table class="links-table w-full text-sm">
        <thead class="bg-slate-50 text-slate-500 text-xs"><tr><th class="px-3 py-2 w-8"><input type="checkbox" id="lkAll" class="w-4 h-4" title="<?= $h(nL('Pilih semua yang tampil', 'Select all shown')) ?>"></th><th class="text-left px-3 py-2"><?= $h(nL('Aset', 'Asset')) ?></th><th class="text-left px-3 py-2"><?= $h(nL('Jenis', 'Type')) ?></th><th class="text-left px-3 py-2"><?= $h(nL('Lokasi', 'Location')) ?></th><th class="text-left px-3 py-2">IP</th><th class="text-left px-3 py-2"><?= $h(nL('Terhubung ke', 'Connected to')) ?></th><th class="text-left px-3 py-2 whitespace-nowrap"><?= $h(nL('Port di perangkat atas', 'Port on upstream')) ?></th><th class="px-1"></th><th class="text-left px-3 py-2 whitespace-nowrap"><?= $h(nL('Port di aset ini', 'Port on this asset')) ?></th></tr></thead>
        <tbody>
        <?php $sorted = $all; uasort($sorted, fn($x, $y) => ($y['is_net'] <=> $x['is_net']) ?: strcmp($x['loc'], $y['loc']) ?: strcmp($x['name'], $y['name']));
        foreach ($sorted as $a): $desc = array_column(netDescendants($all, $a['id']), 'id'); ?>
            <tr class="border-t lk-row" data-type="<?= $h($a['type']) ?>" data-loc="<?= $h($a['loc']) ?>" data-q="<?= $h(mb_strtolower($a['name'] . ' ' . $a['number'] . ' ' . $a['type'] . ' ' . $a['loc'] . ' ' . $a['ip'] . ' ' . implode(' ', $a['ips']) . ' ' . ($a['parent'] ? ($all[$a['parent']]['name'] ?? '') : '') . ' ' . $a['brand'])) ?>">
                <td class="px-3 py-1.5"><input type="checkbox" class="lk-pick w-4 h-4" value="<?= $a['id'] ?>"></td>
                <td class="px-3 py-1.5"><div class="font-medium"><?= $h($a['name']) ?></div><div class="text-xs text-slate-500"><?= $h($a['number']) ?></div></td>
                <td class="px-3 py-1.5"><?= $h($a['type']) ?></td><td class="px-3 py-1.5"><?= $h($a['loc']) ?></td>
                <td class="px-3 py-1.5 font-mono text-xs"><?= $a['ip'] !== '' ? $h($a['ip']) : '<span class="text-slate-400">' . $h(nL('tanpa IP', 'no IP')) . '</span>' ?></td>
                <td class="px-3 py-1.5"><select name="parent[<?= $a['id'] ?>]" data-port="up_<?= $a['id'] ?>" class="port-src border border-slate-300 rounded-lg px-2 py-1 text-sm max-w-[220px]">
                    <option value="0">— <?= $h(nL('belum dihubungkan', 'not linked')) ?> —</option>
                    <?php foreach ($parents as $p): if ($p['id'] === $a['id'] || in_array($p['id'], $desc, true)) continue; ?>
                        <option value="<?= $p['id'] ?>" <?= $a['parent'] === $p['id'] ? 'selected' : '' ?>><?= $h($p['name'] . ($p['loc'] ? ' · ' . $p['loc'] : '')) ?></option>
                    <?php endforeach; ?></select></td>
                <td class="px-3 py-1.5"><input name="port[<?= $a['id'] ?>]" id="up_<?= $a['id'] ?>" value="<?= $h($a['port']) ?>" maxlength="30" placeholder="-" autocomplete="off" class="border border-slate-300 rounded-lg px-2 py-1 text-sm w-24 font-mono"></td>
                <td class="px-1 text-slate-400">&#8646;</td>
                <td class="px-3 py-1.5"><input name="own_port[<?= $a['id'] ?>]" value="<?= $h($a['own_port']) ?>" maxlength="30" placeholder="<?= $a['is_net'] ? '-' : 'LAN' ?>" autocomplete="off" <?= $a['is_net'] ? 'list="pl_' . $a['id'] . '"' : '' ?> class="border border-slate-300 rounded-lg px-2 py-1 text-sm w-24 font-mono"></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$all): ?><tr><td colspan="9" class="px-3 py-6 text-center text-slate-500"><?= $h(nL('Belum ada aset ber-IP atau switch/router.', 'No IP assets or switches yet.')) ?></td></tr><?php endif; ?>
        </tbody>
    </table></div>
</form>
<form method="post" id="lkBulkForm" class="hidden">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="links_bulk_sel"><input type="hidden" name="to" id="lkBulkTo">
</form>

<?php else: ?>
<form method="post" class="bg-white rounded-xl shadow-sm p-5 grid sm:grid-cols-2 gap-4 text-sm max-w-3xl">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="settings_save">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Lambat jika ping rata-rata ≥ (ms)', 'Slow if average ping ≥ (ms)')) ?></span><input type="number" name="warn_ms" min="10" max="5000" value="<?= (int)$set['warn_ms'] ?>" class="border border-slate-300 rounded-lg px-3 py-2"></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Lambat jika paket hilang ≥ (%)', 'Slow if packet loss ≥ (%)')) ?></span><input type="number" name="warn_loss" min="1" max="100" value="<?= (int)$set['warn_loss'] ?>" class="border border-slate-300 rounded-lg px-3 py-2"></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(nL('Paket ping per aset', 'Ping packets per asset')) ?></span>
        <select name="ping_count" class="border border-slate-300 rounded-lg px-3 py-2"><?php foreach ([1 => nL('1 (paling cepat)', '1 (fastest)'), 2 => '2', 4 => nL('4 (paling akurat)', '4 (most accurate)')] as $k => $v): ?><option value="<?= $k ?>" <?= (int)$set['ping_count'] === $k ? 'selected' : '' ?>><?= $h($v) ?></option><?php endforeach; ?></select></label>
    <label class="flex flex-col gap-1 sm:col-span-2"><span class="text-xs text-slate-500"><?= $h(nL('Subnet untuk scan (satu per baris, format 192.168.1.0/24). Kosong = ditebak dari IP aset.', 'Subnets to scan (one per line). Empty = guessed from asset IPs.')) ?></span>
        <textarea name="subnets" rows="4" class="border border-slate-300 rounded-lg px-3 py-2 font-mono"><?= $h(implode("\n", $set['subnets'])) ?></textarea></label>
    <div class="sm:col-span-2 text-xs text-slate-500 space-y-1">
        <p><?= $h(nL('Pengecekan hanya berjalan saat tombol ditekan, jadi tidak membebani jaringan di luar itu. 1 kali cek 300 aset dengan 4 paket ping ≈ 180 KB lalu lintas LAN.', 'Checks only run when you press the button.')) ?></p>
        <p><?= $h(nL('Server butuh izin menjalankan ping.exe & arp.exe dari PHP (proc_open aktif — sudah dipakai fitur live preview CCTV).', 'PHP needs proc_open to run ping/arp.')) ?></p>
    </div>
    <div class="sm:col-span-2"><button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium"><?= $h(nL('Simpan', 'Save')) ?></button></div>
</form>
<?php endif; ?>

<div id="netToast" class="fixed right-4 bottom-4 z-50 flex flex-col gap-2 max-w-sm"></div>
<script>
(function () {
    var ASSETS = <?= json_encode(array_values($all), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
    var EXTRA = <?= json_encode($extras, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
    var TOPO_POS = <?= json_encode((object)netTopoPosMap($db)) ?>;
    var CSRF = <?= json_encode(csrfToken()) ?>;
    var SAVED = <?= json_encode((object)$savedScans, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
    var T = <?= json_encode([
        'ok' => nL('Normal', 'Normal'), 'warn' => nL('Lambat', 'Slow'), 'err' => nL('Mati', 'Down'), 'na' => nL('Belum dicek', 'Not checked'),
        'recheck' => nL('Cek ulang', 'Recheck'), 'checking' => nL('Mengecek…', 'Checking…'), 'of' => nL('dari', 'of'), 'assets' => nL('aset', 'assets'),
        'done' => nL('Selesai', 'Done'), 'none' => nL('Tidak ada aset yang cocok.', 'No matching assets.'), 'notLinked' => nL('Belum dihubungkan', 'Not linked'), 'dev' => nL('perangkat', 'devices'),
        'orderSaved' => nL('Posisi topologi disimpan.', 'Topology positions saved.'), 'orderReset' => nL('Topologi kembali ke susunan otomatis.', 'Topology reset to automatic layout.'),
        'orderResetQ' => nL('Hapus semua posisi yang diatur manual dan kembali ke susunan otomatis?', 'Remove all manual positions and go back to automatic layout?'),
        'orderDiscard' => nL('Perubahan posisi belum disimpan. Batalkan perubahan?', 'Position changes are not saved. Discard them?'),
        'noIp' => nL('tanpa IP', 'no IP'), 'suspect' => nL('diduga mati', 'suspected down'), 'inferred' => nL('disimpulkan', 'inferred'),
        'below' => nL('Di bawahnya', 'Below'), 'extra' => nL('Koneksi tambahan', 'Extra links'), 'connected' => nL('Terhubung ke', 'Connected to'), 'result' => nL('Hasil cek', 'Result'), 'loss' => nL('paket hilang', 'loss'),
        'scanning' => nL('Memeriksa', 'Scanning'), 'reading' => nL('Membaca tabel ARP & nama host…', 'Reading ARP & hostnames…'), 'registered' => nL('Terdaftar', 'Registered'),
        'unregistered' => nL('Tidak terdaftar', 'Not registered'), 'active' => nL('perangkat aktif', 'active devices'), 'notReg' => nL('tidak terdaftar di menu Aset', 'not in Assets'),
        'missing' => nL('Aset terdaftar yang tidak ditemukan', 'Registered assets not found'), 'register' => nL('Daftarkan', 'Register'), 'lastScan' => nL('Hasil scan terakhir', 'Last scan'), 'failed' => nL('Gagal', 'Failed'),
    ], JSON_UNESCAPED_UNICODE) ?>;
    var byId = {}; ASSETS.forEach(function (a) { byId[a.id] = a; });
    // ---- Pilihan dengan kotak cari (selalu membuka ke BAWAH), menggantikan <select data-combo> yang panjang ----
    [].forEach.call(document.querySelectorAll('select[data-combo]'), function (sel) {
        var wrap = document.createElement('div'); wrap.className = 'relative'; wrap.style.minWidth = '220px';
        var inp = document.createElement('input'); inp.type = 'text'; inp.autocomplete = 'off';
        inp.className = 'w-full border border-slate-300 rounded-lg px-2 py-1.5 bg-white text-sm pr-7';
        inp.placeholder = '<?= $h(nL('Ketik untuk mencari…', 'Type to search…')) ?>';
        var caret = document.createElement('span'); caret.className = 'absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs'; caret.textContent = '▼';
        var list = document.createElement('div');
        list.className = 'hidden absolute left-0 top-full mt-1 z-50 w-full min-w-[280px] max-h-72 overflow-y-auto bg-white border border-slate-300 rounded-lg shadow-lg text-sm';
        sel.parentNode.insertBefore(wrap, sel); wrap.appendChild(inp); wrap.appendChild(caret); wrap.appendChild(list); wrap.appendChild(sel);
        sel.style.display = 'none';
        var items = [], active = -1;
        [].forEach.call(sel.children, function (ch) {
            var opts = ch.tagName === 'OPTGROUP' ? [].slice.call(ch.children) : [ch];
            if (ch.tagName === 'OPTGROUP') items.push({group: ch.label});
            opts.forEach(function (o) { items.push({value: o.value, text: o.textContent, q: o.textContent.toLowerCase()}); });
        });
        var label = function () { var o = sel.options[sel.selectedIndex]; return o ? o.textContent : ''; };
        inp.value = label();
        var render = function (q) {
            var w = (q || '').toLowerCase().trim().split(/\s+/).filter(Boolean), html = '', pend = null, n = 0;
            items.forEach(function (it, i) {
                if (it.group !== undefined) { pend = it.group; return; }
                if (!w.every(function (x) { return it.q.indexOf(x) >= 0; })) return;
                if (pend !== null) { html += '<div class="px-3 pt-2 pb-1 text-xs font-semibold text-slate-500 bg-slate-50 sticky top-0">' + esc(pend) + '</div>'; pend = null; }
                html += '<div class="cb-opt px-3 py-1.5 cursor-pointer hover:bg-blue-50' + (it.value === sel.value ? ' font-semibold text-blue-700' : '') + '" data-i="' + i + '">' + esc(it.text) + '</div>'; n++;
            });
            list.innerHTML = html || '<div class="px-3 py-2 text-slate-400"><?= $h(nL('Tidak ditemukan', 'Not found')) ?></div>';
            active = -1;
        };
        var open = function () { render(inp.value === label() ? '' : inp.value); list.classList.remove('hidden'); };
        var close = function () { list.classList.add('hidden'); inp.value = label(); };
        var choose = function (i) { sel.value = items[i].value; sel.dispatchEvent(new Event('change', {bubbles: true})); close(); };
        inp.addEventListener('focus', function () { inp.select(); open(); });
        inp.addEventListener('input', function () { render(inp.value); list.classList.remove('hidden'); });
        inp.addEventListener('keydown', function (e) {
            var opts = list.querySelectorAll('.cb-opt');
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault(); if (list.classList.contains('hidden')) open();
                active = Math.max(0, Math.min(opts.length - 1, active + (e.key === 'ArrowDown' ? 1 : -1)));
                [].forEach.call(opts, function (o, k) { o.classList.toggle('bg-blue-100', k === active); });
                if (opts[active]) opts[active].scrollIntoView({block: 'nearest'});
            } else if (e.key === 'Enter') { e.preventDefault(); var t = opts[active >= 0 ? active : 0]; if (t) choose(+t.dataset.i); }
            else if (e.key === 'Escape') { close(); inp.blur(); }
        });
        list.addEventListener('mousedown', function (e) { var t = e.target.closest('.cb-opt'); if (t) { e.preventDefault(); choose(+t.dataset.i); } });
        inp.addEventListener('blur', function () { setTimeout(close, 120); });
    });
    function plabel(up, own) { up = (up || '').trim(); own = (own || '').trim(); return up && own ? up + ' ⇄ ' + own : (up || (own ? '⇄ ' + own : '')); }
    // Pilihan port mengikuti perangkat yang dipilih (datalist "pl_<id>").
    [].forEach.call(document.querySelectorAll('select.port-src'), function (sel) {
        var inp = document.getElementById(sel.dataset.port); if (!inp) return;
        var sync = function () { if (sel.value && sel.value !== '0') inp.setAttribute('list', 'pl_' + sel.value); else inp.removeAttribute('list'); };
        sel.addEventListener('change', sync); sync();
    });
    // ---- Data koneksi: cari, filter, pilih beberapa / semua, aksi massal ----
    (function () {
        var bar = document.getElementById('linksBar'); if (!bar) return;
        var rowsL = [].slice.call(document.querySelectorAll('tr.lk-row')), q = document.getElementById('lkQ'), ft = document.getElementById('lkType'), fl = document.getElementById('lkLoc');
        var all = document.getElementById('lkAll'), bulk = document.getElementById('lkBulk'), selN = document.getElementById('lkSelN'), cnt = document.getElementById('lkCount');
        var setH = function () { document.documentElement.style.setProperty('--lsb-h', bar.offsetHeight + 'px'); };
        var picked = function () { return rowsL.filter(function (r) { return r.querySelector('.lk-pick').checked; }); };
        var sync = function () { var n = picked().length; selN.textContent = n; bulk.classList.toggle('hidden', !n); setH(); };
        var filter = function () {
            var t = (q.value || '').toLowerCase().trim().split(/\s+/).filter(Boolean), shown = 0;
            rowsL.forEach(function (r) {
                var ok = (!ft.value || r.dataset.type === ft.value) && (!fl.value || r.dataset.loc === fl.value) && t.every(function (w) { return r.dataset.q.indexOf(w) >= 0; });
                r.classList.toggle('hidden', !ok); if (ok) shown++;
            });
            cnt.textContent = shown + ' / ' + rowsL.length + ' <?= $h(nL('aset', 'assets')) ?>';
            all.checked = false;
        };
        [q, ft, fl].forEach(function (el) { el.addEventListener('input', filter); el.addEventListener('change', filter); });
        q.addEventListener('keydown', function (e) { if (e.key === 'Enter') e.preventDefault(); });   // Enter tidak menyimpan form
        all.addEventListener('change', function () { rowsL.forEach(function (r) { if (!r.classList.contains('hidden')) r.querySelector('.lk-pick').checked = all.checked; }); sync(); });
        rowsL.forEach(function (r) { r.querySelector('.lk-pick').addEventListener('change', sync); });
        document.getElementById('lkClear').onclick = function () { rowsL.forEach(function (r) { r.querySelector('.lk-pick').checked = false; }); all.checked = false; sync(); };
        var send = function (to) {
            var ids = picked().map(function (r) { return r.querySelector('.lk-pick').value; }); if (!ids.length) return;
            var f = document.getElementById('lkBulkForm'); document.getElementById('lkBulkTo').value = to;
            [].forEach.call(f.querySelectorAll('input[name="ids[]"]'), function (x) { x.remove(); });
            ids.forEach(function (id) { var i = document.createElement('input'); i.type = 'hidden'; i.name = 'ids[]'; i.value = id; f.appendChild(i); });
            f.submit();
        };
        document.getElementById('lkApply').onclick = function () { var sel = document.getElementById('lkTo'); if (confirm('<?= $h(nL('Hubungkan aset yang dicentang ke ', 'Link selected assets to ')) ?>' + sel.options[sel.selectedIndex].text + '?')) send(sel.value); };
        document.getElementById('lkUnlink').onclick = function () { if (confirm('<?= $h(nL('Lepas koneksi aset yang dicentang?', 'Unlink selected assets?')) ?>')) send(0); };
        // Checkbox centang tidak dihitung sebagai "perubahan belum disimpan".
        filter(); setH(); window.addEventListener('resize', setH);
    })();
    (function () {
        var f = document.querySelector('input[name="action"][value="links_save"]'), dirty = document.getElementById('linksDirty');
        if (!f || !dirty) return;
        var isEdit = function (e) { var t = e.target; return t && (t.name || '').match(/^(parent|port|own_port)\[/); };
        f.form.addEventListener('input', function (e) { if (isEdit(e)) { dirty.classList.remove('hidden'); document.documentElement.style.setProperty('--lsb-h', document.getElementById('linksBar').offsetHeight + 'px'); } });
        f.form.addEventListener('change', function (e) { if (isEdit(e)) dirty.classList.remove('hidden'); });
    })();
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]; }); }
    function badge(s) { var c = {ok: 'bg-green-100 text-green-700', warn: 'bg-amber-100 text-amber-700', err: 'bg-red-100 text-red-700', na: 'bg-slate-100 text-slate-600'}[s || 'na'];
        return '<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold whitespace-nowrap ' + c + '"><span class="w-1.5 h-1.5 rounded-full bg-current"></span>' + esc(T[s || 'na']) + '</span>'; }
    function hm(d) { if (!d) return '-'; var x = new Date(String(d).replace(' ', 'T')); return ('0' + x.getHours()).slice(-2) + ':' + ('0' + x.getMinutes()).slice(-2); }
    function post(data) {
        var fd = new FormData(); fd.append('csrf_token', CSRF);
        Object.keys(data).forEach(function (k) { [].concat(data[k]).forEach(function (v) { fd.append(Array.isArray(data[k]) ? k + '[]' : k, v); }); });
        return fetch('network.php', {method: 'POST', body: fd, credentials: 'same-origin'}).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); });
    }
    function toast(msg, bad) { var box = document.getElementById('netToast'); if (!box) return; var d = document.createElement('div');
        d.className = 'bg-white border-l-4 ' + (bad ? 'border-red-500' : 'border-green-500') + ' shadow-lg rounded-lg px-4 py-3 text-sm text-slate-700'; d.textContent = msg; box.prepend(d); setTimeout(function () { d.remove(); }, 7000); }
    function descendants(id) { var out = [], st = [id]; while (st.length) { var c = st.pop(); ASSETS.forEach(function (a) { if (a.parent === c) { out.push(a); st.push(a.id); } }); } return out; }
    function stateOf(a) { if (a.ip) return a.state || 'na';
        var kids = descendants(a.id).filter(function (k) { return k.ip && k.state; });
        return kids.length >= 2 && kids.every(function (k) { return k.state === 'err'; }) ? 'err' : 'na'; }

    /* ---------- Cek jaringan ---------- */
    var rows = document.getElementById('netRows');
    function shown() {
        var ft = val('fType'), fl = val('fLoc'), fs = val('fState'), q = val('fQ').toLowerCase();
        return ASSETS.filter(function (a) { return a.ip && (!ft || a.type === ft) && (!fl || a.loc === fl) && (!fs || (a.state || 'na') === fs) && (!q || (a.name + ' ' + a.number + ' ' + a.ip).toLowerCase().indexOf(q) >= 0); });
    }
    function val(id) { var e = document.getElementById(id); return e ? e.value : ''; }
    function renderRows() {
        if (!rows) return;
        var order = {err: 0, warn: 1, ok: 2, na: 3};
        var list = shown().sort(function (x, y) { return order[x.state || 'na'] - order[y.state || 'na'] || x.name.localeCompare(y.name); });
        rows.innerHTML = list.map(function (a) { var p = byId[a.parent], s = a.state || 'na';
            return '<tr class="border-t ' + (s === 'err' ? 'bg-red-50/60' : s === 'warn' ? 'bg-amber-50/60' : '') + '"><td class="px-3 py-2"><input type="checkbox" class="pick w-4 h-4" value="' + a.id + '"></td>'
                + '<td class="px-3 py-2"><div class="font-medium text-slate-800">' + esc(a.name) + '</div><div class="text-xs text-slate-500">' + esc(a.number) + '</div></td>'
                + '<td class="px-3 py-2">' + esc(a.type) + '</td><td class="px-3 py-2">' + esc(a.loc) + '</td><td class="px-3 py-2 font-mono text-xs">' + esc(a.ip) + '</td>'
                + '<td class="px-3 py-2 text-xs">' + (p ? esc(p.name) + (plabel(a.port, a.own_port) ? ' <span class="text-slate-400">' + esc(plabel(a.port, a.own_port)) + '</span>' : '') : '<span class="text-slate-400">-</span>') + '</td>'
                + '<td class="px-3 py-2">' + badge(s) + (a.detail && s !== 'ok' ? '<div class="text-xs text-slate-500 mt-0.5">' + esc(a.detail) + '</div>' : '') + '</td>'
                + '<td class="px-3 py-2 text-right tabular-nums ' + (a.ms >= <?= (int)$set['warn_ms'] ?> ? 'text-amber-600 font-semibold' : '') + '">' + (a.ms == null ? '-' : a.ms + ' ms') + (a.method && a.method.indexOf('tcp ') === 0 ? '<div class="text-[10px] text-slate-400">' + esc(a.method) + '</div>' : '') + '</td>'
                + '<td class="px-3 py-2 text-right tabular-nums ' + (s === 'err' ? 'text-red-600 font-semibold' : a.loss >= <?= (int)$set['warn_loss'] ?> ? 'text-amber-600 font-semibold' : '') + '">' + (a.loss == null ? '-' : a.loss + '%') + '</td>'
                + '<td class="px-3 py-2 text-xs text-slate-500 tabular-nums">' + hm(a.checked_at) + '</td>'
                + '<td class="px-3 py-2"><button type="button" class="recheck text-xs px-2 py-1 rounded-lg border border-slate-300 hover:bg-slate-50 text-blue-600 whitespace-nowrap" data-id="' + a.id + '">' + esc(T.recheck) + '</button></td></tr>';
        }).join('') || '<tr><td colspan="11" class="px-3 py-6 text-center text-slate-500">' + esc(T.none) + '</td></tr>';
        [].forEach.call(rows.querySelectorAll('.recheck'), function (b) { b.onclick = function () { b.disabled = true; b.textContent = T.checking; run([+b.dataset.id]); }; });
        var all = document.getElementById('chkAll'); if (all) all.checked = false;
    }
    var busy = false;
    function run(ids) {
        if (busy || !ids.length) return; busy = true;
        var btn = document.getElementById('btnCheck'), prog = document.getElementById('prog'); if (btn) btn.disabled = true; if (prog) prog.classList.remove('hidden');
        var i = 0, CH = 8, okAll = true;
        (function next() {
            if (i >= ids.length) {
                post({action: 'check_done', ids: ids}).then(function () { location.reload(); }).catch(function () { location.reload(); });
                return;
            }
            var part = ids.slice(i, i + CH);
            document.getElementById('progTxt').textContent = T.checking + ' ' + Math.min(ids.length, i + part.length) + ' ' + T.of + ' ' + ids.length + ' ' + T.assets;
            post({action: 'check', ids: part}).then(function (d) {
                (d.results || []).forEach(function (r) { var a = byId[r.id]; if (a) { a.state = r.state; a.ms = r.ms; a.loss = r.loss; a.method = r.method; a.detail = r.detail; a.checked_at = r.checked_at; } });
            }).catch(function (e) { okAll = false; toast(T.failed + ': ' + e.message, true); }).then(function () {
                i += part.length; document.getElementById('progBar').style.width = (i / ids.length * 100) + '%'; renderRows(); next();
            });
        })();
    }
    if (rows) {
        ['fType', 'fLoc', 'fState'].forEach(function (id) { document.getElementById(id).onchange = renderRows; });
        document.getElementById('fQ').oninput = renderRows;
        document.getElementById('chkAll').onchange = function (e) { [].forEach.call(rows.querySelectorAll('.pick'), function (c) { c.checked = e.target.checked; }); };
        document.getElementById('btnCheck').onclick = function () {
            var picked = [].map.call(rows.querySelectorAll('.pick:checked'), function (c) { return +c.value; });
            run(picked.length ? picked : shown().map(function (a) { return a.id; }));
        };
        var KEY = 'netAutoPage', ap = document.getElementById('autoPage'), timer = null;
        function setAuto(on) { clearInterval(timer); timer = null; if (on) timer = setInterval(function () { if (!document.hidden) run(shown().map(function (a) { return a.id; })); }, 60000); }
        try { ap.checked = sessionStorage.getItem(KEY) === '1'; } catch (e) {}
        ap.onchange = function () { try { sessionStorage.setItem(KEY, ap.checked ? '1' : '0'); } catch (e) {} setAuto(ap.checked); };
        setAuto(ap.checked);
        renderRows();
    }

    /* ---------- Topologi ---------- */
    var topo = document.getElementById('topo');
    // ---- Geser bebas (seperti Visio): posisi X/Y tiap kotak disimpan; tanpa posisi = susunan otomatis ----
    var XY = {}, XY0 = {}, EDIT = false, DIRTY = false, NW_ = 190, POSG = {}, LISTG = [];
    Object.keys(TOPO_POS).forEach(function (k) { XY[k] = {x: TOPO_POS[k][0], y: TOPO_POS[k][1]}; XY0[k] = {x: TOPO_POS[k][0], y: TOPO_POS[k][1]}; });
    function setDirty(on) { DIRTY = on; document.getElementById('tArrDirty').classList.toggle('hidden', !on); }
    // Tahan klik & geser kotak ke mana saja (snap 10 px). Shift = ikut memindahkan seluruh cabang di bawahnya.
    function startDrag(e, id) {
        if (e.button > 0) return;
        e.preventDefault();
        var svg = topo.querySelector('svg'), r0 = svg.getBoundingClientRect(), sc = svg.viewBox.baseVal.width / r0.width;
        // Area yang di-scroll: <main> aplikasi (bila bisa di-scroll), selain itu jendela browser.
        var SC = topo.closest('main'); if (SC && SC.scrollHeight <= SC.clientHeight + 2 && getComputedStyle(SC).overflowY === 'visible') SC = null;
        var gy = function () { return SC ? SC.scrollTop : window.scrollY; }, sby = function (d) { if (SC) SC.scrollTop += d; else window.scrollBy(0, d); };
        var sx = e.clientX, sy = e.clientY, sl = topo.scrollLeft, wy = gy(), moved = false, raf = 0, last = e;
        var ids = [id];
        if (e.shiftKey && id > 0) descendants(id).forEach(function (k) { if (POSG[k.id]) ids.push(k.id); });
        var start = {}; ids.forEach(function (k) { start[k] = {x: POSG[k].x, y: POSG[k].y}; });
        function apply() {
            raf = 0;
            var dx = (last.clientX - sx + topo.scrollLeft - sl) * sc, dy = (last.clientY - sy + gy() - wy) * sc;
            if (!moved && Math.abs(dx) + Math.abs(dy) < 4) return;
            moved = true;
            var minX = Math.min.apply(null, ids.map(function (k) { return start[k].x; })), minY = Math.min.apply(null, ids.map(function (k) { return start[k].y; }));
            dx = Math.max(dx, 4 - minX); dy = Math.max(dy, 4 - minY);   // tidak keluar dari kiri / atas
            ids.forEach(function (k) { XY[k] = {x: Math.round((start[k].x + dx) / 10) * 10, y: Math.round((start[k].y + dy) / 10) * 10}; });
            renderTopo();
            var n = topo.querySelector('.node[data-id="' + id + '"]'); if (n) n.classList.add('dragging');
        }
        function mv(ev) { last = ev; if (!raf) raf = requestAnimationFrame(apply); }
        var tick = setInterval(function () {   // gulir otomatis di tepi layar / tepi diagram
            var tr = topo.getBoundingClientRect(), s = 0;
            var top = SC ? SC.getBoundingClientRect().top : 0, bot = SC ? SC.getBoundingClientRect().bottom : window.innerHeight;
            if (last.clientY < top + 60) { sby(-16); s = 1; } else if (last.clientY > bot - 40) { sby(16); s = 1; }
            if (last.clientX > tr.right - 40) { topo.scrollLeft += 16; s = 1; } else if (last.clientX < tr.left + 40) { topo.scrollLeft -= 16; s = 1; }
            if (s && moved && !raf) raf = requestAnimationFrame(apply);
        }, 30);
        function up() {
            clearInterval(tick); window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); window.removeEventListener('pointercancel', up);
            if (raf) { cancelAnimationFrame(raf); apply(); }
            if (moved) {
                // Simpan juga posisi semua kotak lain yang tampil, supaya susunan tidak bergeser bila data berubah.
                LISTG.forEach(function (k) { if (!XY[k] && POSG[k]) XY[k] = {x: POSG[k].x, y: POSG[k].y}; });
                setDirty(true);
            }
            renderTopo(); topoSearch(false);
        }
        window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up); window.addEventListener('pointercancel', up);
    }
    function setArrange(on) {
        EDIT = on; document.getElementById('tArrBar').classList.toggle('hidden', !on);
        document.getElementById('tArrange').classList.toggle('bg-amber-100', on);
        renderTopo(); topoSearch(false);
    }
    function renderTopo() {
        // Kotak per lokasi aktif: anak yang lokasinya sama dengan induknya didahulukan, lalu dikelompokkan per lokasi.
        function GRP_ON() { return !!(document.getElementById('tGroup') || {}).checked; }
        // Lokasi dibandingkan tanpa beda huruf besar/kecil & spasi ("Ruang Server" = "RUANG SERVER").
        // Label kotak memakai penulisan yang paling banyak dipakai.
        function LK(s) { return (s || '').trim().replace(/\s+/g, ' ').toLowerCase(); }
        var LCNT = {}, LNAME = {};
        ASSETS.forEach(function (a) { var k = LK(a.loc), t = (a.loc || '').trim().replace(/\s+/g, ' '); if (!k) return; LCNT[k] = LCNT[k] || {}; LCNT[k][t] = (LCNT[k][t] || 0) + 1; });
        Object.keys(LCNT).forEach(function (k) { LNAME[k] = Object.keys(LCNT[k]).sort(function (x, y) { return LCNT[k][y] - LCNT[k][x] || x.localeCompare(y); })[0]; });
        // Cabang yang seluruh isinya 1 lokasi didahulukan, supaya aset satu lokasi tidak terpotong cabang lokasi lain.
        function pure(k) { var L = LK(k.loc); return descendants(k.id).every(function (d) { return LK(d.loc) === L; }) ? 0 : 1; }
        var fl = val('tLoc'), list = [], VIRT_NET = {id: -1, name: 'Internet / Router ISP', type: '', ip: '', virtual: true}, VIRT_NL = {id: -2, name: T.notLinked, type: '', ip: '', virtual: true};
        function keep(a) { if (!fl) return true; if (a.loc === fl) return true; return descendants(a.id).some(function (k) { return k.loc === fl; }); }
        var roots = ASSETS.filter(function (a) { return !a.parent; });
        var netRoots = roots.filter(function (a) { return a.is_net || descendants(a.id).length; }), loose = roots.filter(function (a) { return netRoots.indexOf(a) < 0; });
        function walk(a, d, pid) { if (!keep(a)) return; list.push({a: a, d: d, pid: pid}); ASSETS.filter(function (k) { return k.parent === a.id; }).sort(function (x, y) { return (GRP_ON() ? (LK(x.loc) === LK(a.loc) ? 0 : 1) - (LK(y.loc) === LK(a.loc) ? 0 : 1) || LK(x.loc).localeCompare(LK(y.loc)) || pure(x) - pure(y) : 0) || (y.is_net - x.is_net) || x.name.localeCompare(y.name); }).forEach(function (k) { walk(k, d + 1, a.id); }); }
        // Urutan perangkat paling atas sama dengan versi cetak; dengan kotak per lokasi, yang lokasinya sama dibuat
        // berdampingan (urutan lokasi mengikuti kemunculan pertama) dan yang tanpa cabang lokasi lain didahulukan.
        netRoots.sort(function (x, y) { return (y.is_net - x.is_net) || x.name.localeCompare(y.name); });
        if (GRP_ON()) {
            var rk = [], rg = {};
            netRoots.forEach(function (a, i) { var k = LK(a.loc); if (!rg[k]) { rg[k] = []; rk.push(k); } rg[k].push([a, i]); });
            netRoots = [];
            rk.forEach(function (k) { rg[k].sort(function (x, y) { return (k ? pure(x[0]) - pure(y[0]) : 0) || x[1] - y[1]; }).forEach(function (x) { netRoots.push(x[0]); }); });
        }
        if (netRoots.length) { list.push({a: VIRT_NET, d: 0}); netRoots.forEach(function (a) { walk(a, 1, -1); }); }
        var looseKept = loose.filter(keep);
        if (GRP_ON()) looseKept.sort(function (x, y) { return LK(x.loc).localeCompare(LK(y.loc)) || x.name.localeCompare(y.name); });
        // Kotak per lokasi: aset yang belum dihubungkan ikut ditaruh di kotak lokasinya (di bawah perangkat pertama
        // berlokasi sama), digambar bergaris putus-putus tanpa garis koneksi. Sisanya tetap di "Belum dihubungkan".
        if (GRP_ON() && looseKept.length) {
            var anchor = {}, ins = {};
            // Utamakan switch/router berlokasi sama yang punya cabang, lalu perangkat jaringan, lalu baris pertama.
            var rank = {};
            list.forEach(function (r, i) {
                var k = r.a.virtual ? '' : LK(r.a.loc); if (!k) return;
                var sc = r.a.is_net ? ((list[i + 1] && list[i + 1].d > r.d) ? 2 : 1) : 0;
                if (anchor[k] === undefined || sc > rank[k]) { anchor[k] = i; rank[k] = sc; }
            });
            looseKept = looseKept.filter(function (a) { var i = anchor[LK(a.loc)]; if (i === undefined) return true; (ins[i] = ins[i] || []).push(a); return false; });
            Object.keys(ins).map(Number).sort(function (x, y) { return y - x; }).forEach(function (i) {
                var d = list[i].d + 1;
                list.splice.apply(list, [i + 1, 0].concat(ins[i].map(function (a) { return {a: a, d: d, float: true, pid: null}; })));
            });
        }
        if (looseKept.length) { list.push({a: VIRT_NL, d: 0}); looseKept.forEach(function (a) { list.push({a: a, d: 1, pid: -2}); }); }
        if (!list.length) { topo.innerHTML = '<p class="p-6 text-sm text-slate-500">' + esc(T.none) + '</p>'; return; }
        var NW = 190, NH = 40, GX = 150, GY = 50, P = 14, maxD = Math.max.apply(null, list.map(function (r) { return r.d; }));
        // Router/switch/hub/AP yang punya Brand/Type: kotak lebih tinggi (baris ke-3 = brand type).
        var GAP = GY - NH, yy = P, pos = {};
        // Semua IP terdaftar tampil 1 per baris (IP utama paling atas); kotak bertambah tinggi 14px per IP tambahan.
        function ipLines(a) {
            if (a.virtual) return [];
            var l = (a.ips || []).slice();
            if (!l.length) return a.ip ? [a.ip] : [];
            var k = -1; l.forEach(function (x, i) { if (k < 0 && x.split('/')[0] === a.ip) k = i; });
            if (k > 0) l.unshift(l.splice(k, 1)[0]);
            return l;
        }
        // Kotak lokasi: baris berurutan dengan lokasi sama dibungkus 1 kotak berwarna + label lokasi di atasnya.
        var GRP = !!(document.getElementById('tGroup') || {}).checked, LBL = 24, prevLoc = null;
        function locOf(a) { return a.virtual ? '' : LK(a.loc); }
        list.forEach(function (r) { var L = locOf(r.a); if (GRP && L && L !== prevLoc) yy += LBL; prevLoc = L; var nIp = Math.max(1, ipLines(r.a).length), h = r.a.virtual ? NH : NH + (nIp - 1) * 14 + ((r.a.is_net && (r.a.brand || '').trim()) ? 14 : 0); pos[r.a.id] = {x: P + r.d * GX, y: yy, h: h, d: r.d, ips: ipLines(r.a)}; yy += h + GAP; });
        var W = P * 2 + maxD * GX + NW + (EXTRA.length ? 70 + EXTRA.length * 14 : 0), H = yy - GAP + P;
        // Warna kabel: tiap switch / router yang punya perangkat di bawahnya mendapat 1 warna; semua garis koneksi
        // utama dari perangkat itu memakai warnanya, dan kotaknya diberi strip warna yang sama. Merah tetap = putus.
        var CAB_ON = !!(document.getElementById('tCable') || {}).checked, CAB = {}, nCab = 0;
        var CAB_PAL = ['#0d9488', '#7c3aed', '#ea580c', '#92400e', '#65a30d', '#db2777', '#ca8a04', '#475569', '#059669', '#9333ea', '#c2410c', '#0f766e', '#a16207', '#be185d', '#15803d', '#6d28d9'];
        if (CAB_ON) list.forEach(function (r) { if (r.pid > 0 && !r.float && CAB[r.pid] === undefined) CAB[r.pid] = CAB_PAL[nCab++ % CAB_PAL.length]; });
        function cab(r) { return (CAB_ON && r.pid > 0 && CAB[r.pid]) || '#94a3b8'; }
        // Geser bebas: kotak yang punya posisi tersimpan dipindah ke posisinya; garis digambar ulang (siku).
        var FREE = EDIT || Object.keys(XY).length > 0;
        if (FREE) {
            list.forEach(function (r) { var q = XY[r.a.id]; if (q) { pos[r.a.id].x = q.x; pos[r.a.id].y = q.y; } });
            list.forEach(function (r) { var p = pos[r.a.id]; W = Math.max(W, p.x + NW + 60); H = Math.max(H, p.y + p.h + 40); });
            if (EDIT) { W += 300; H += 200; }   // ruang kosong untuk menggeser
        }
        // Garis siku antar 2 kotak (gaya Visio): atas-bawah bila berjauhan vertikal, kiri-kanan bila sejajar.
        function elbow(A, B, off, tree) {
            off = off || 0;
            var acx = A.x + NW / 2, bcx = B.x + NW / 2, bmy = B.y + Math.min(B.h, NH) / 2 + off;
            // Induk -> anak di kanan-bawah / kiri-bawah: garis "L" seperti tampilan pohon (turun dari tepi induk, belok ke anak).
            if (tree && B.y >= A.y + A.h - 4 && (B.x >= A.x + 40 || B.x + NW <= A.x + NW - 40)) {
                var rgt = B.x >= A.x + 40, tx = (rgt ? A.x + 18 : A.x + NW - 18) + off, ex = rgt ? B.x : B.x + NW;
                return {d: 'M' + tx + ',' + (A.y + A.h) + ' V' + bmy + ' H' + ex, lx: rgt ? tx + 6 : ex + 6, ly: bmy - 4, ax: tx + 4, ay: A.y + A.h + 12};
            }
            if (B.y >= A.y + A.h + 16 || A.y >= B.y + B.h + 16) {
                var down = B.y > A.y, y1 = down ? A.y + A.h : A.y, y2 = down ? B.y : B.y + B.h, my = Math.round((y1 + y2) / 2) + off;
                var ax = acx + off, bx = bcx + off;
                return {d: 'M' + ax + ',' + y1 + ' V' + my + ' H' + bx + ' V' + y2, lx: bx + 4, ly: down ? y2 - 4 : y2 + 12, ax: ax + 4, ay: down ? y1 + 12 : y1 - 4};
            }
            var right = B.x > A.x, x1 = right ? A.x + NW : A.x, x2 = right ? B.x : B.x + NW, mx = Math.round((x1 + x2) / 2) + off;
            var ay = A.y + Math.min(A.h, 40) / 2 + off, by = B.y + Math.min(B.h, 40) / 2 + off;
            if (Math.abs(x2 - x1) < 20) { mx = Math.max(A.x, B.x) + NW + 30 + off; x1 = A.x + NW; x2 = B.x + NW; }   // bertumpuk: lewat sisi kanan
            return {d: 'M' + x1 + ',' + ay + ' H' + mx + ' V' + by + ' H' + x2, lx: x2 + (x2 > mx ? -60 : 4), ly: by - 4, ax: x1 + (x1 < mx ? 4 : -60), ay: ay - 4};
        }
        var COL = {ok: ['#ecfdf3', '#15803d'], warn: ['#fffbeb', '#b45309'], err: ['#fef2f2', '#b91c1c'], na: ['#ffffff', '#cbd5e1']};
        var lines = '', nodes = '', boxes = '';
        if (GRP) {
            var PAL = [['#eff6ff', '#3b82f6', '#1d4ed8'], ['#f0fdf4', '#22c55e', '#15803d'], ['#fff7ed', '#f97316', '#c2410c'], ['#faf5ff', '#a855f7', '#7e22ce'], ['#ecfeff', '#06b6d4', '#0e7490'], ['#fdf2f8', '#ec4899', '#be185d'], ['#fefce8', '#eab308', '#a16207']];
            var locIdx = {}, nLoc = 0, runs = [], cur = null;
            if (FREE) {   // satu kotak per lokasi = batas luar semua perangkat di lokasi itu
                var byL = {};
                list.forEach(function (r) {
                    var L = locOf(r.a), p = pos[r.a.id]; if (!L) return;
                    if (locIdx[L] === undefined) locIdx[L] = nLoc++;
                    var g = byL[L]; if (!g) { g = byL[L] = {loc: L, x1: p.x, x2: p.x + NW, y1: p.y, y2: p.y + p.h, n: 0}; runs.push(g); }
                    g.x1 = Math.min(g.x1, p.x); g.x2 = Math.max(g.x2, p.x + NW); g.y1 = Math.min(g.y1, p.y); g.y2 = Math.max(g.y2, p.y + p.h); g.n++;
                });
            } else list.forEach(function (r) {
                var L = locOf(r.a), p = pos[r.a.id];
                if (!L) { cur = null; return; }
                if (cur && cur.loc === L) { cur.x1 = Math.min(cur.x1, p.x); cur.x2 = Math.max(cur.x2, p.x + NW); cur.y2 = p.y + p.h; cur.n++; }
                else { if (locIdx[L] === undefined) locIdx[L] = nLoc++; cur = {loc: L, x1: p.x, x2: p.x + NW, y1: p.y, y2: p.y + p.h, n: 1}; runs.push(cur); }
            });
            runs.forEach(function (g) {
                var c = PAL[locIdx[g.loc] % PAL.length], x = g.x1 - 8, y = g.y1 - LBL + 4, w = g.x2 - g.x1 + 16, hh = g.y2 - y + 6;
                var lbl = (LNAME[g.loc] || g.loc) + ' · ' + g.n + ' ' + T.dev, lw = Math.min(w - 4, lbl.length * 7 + 16);
                boxes += '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + hh + '" rx="10" fill="' + c[0] + '" fill-opacity=".75" stroke="' + c[1] + '" stroke-width="1.2" stroke-dasharray="6 3"/>'
                    + '<rect x="' + (x + 8) + '" y="' + (y - 8) + '" width="' + lw + '" height="17" rx="8.5" fill="' + c[1] + '"/>'
                    + '<text x="' + (x + 16) + '" y="' + (y + 4) + '" font-size="10.5" font-weight="600" fill="#fff">' + esc(lbl) + '</text>';
            });
        }
        list.forEach(function (r, i) {
            var a = r.a, p = pos[a.id], st = a.virtual ? 'na' : stateOf(a), pp = null;
            if (FREE) {
                pp = (r.pid !== null && r.pid !== undefined) ? pos[r.pid] : null;
                if (pp) { var el = elbow(pp, p, 0, true);
                    lines += '<path d="' + el.d + '" fill="none" stroke="' + (st === 'err' ? '#b91c1c' : cab(r)) + '" stroke-width="' + (st === 'err' ? 2 : (CAB_ON && r.pid > 0 ? 1.8 : 1.2)) + '"' + (st === 'err' ? ' stroke-dasharray="5 4"' : '') + '/>';
                    if (plabel(a.port, a.own_port)) lines += '<text x="' + el.lx + '" y="' + el.ly + '" font-size="10" fill="' + (CAB_ON && r.pid > 0 ? cab(r) : '#64748b') + '" font-family="monospace">' + esc(plabel(a.port, a.own_port)) + '</text>'; }
                pp = null;
            } else if (r.d > 0 && !r.float) { for (var j = i - 1; j >= 0; j--) if (list[j].d === r.d - 1) { pp = pos[list[j].a.id]; break; } }
            if (pp) { var x1 = pp.x + 18, y1 = pp.y + pp.h, y2 = p.y + NH / 2; lines += '<path d="M' + x1 + ',' + y1 + ' V' + y2 + ' H' + p.x + '" fill="none" stroke="' + (st === 'err' ? '#b91c1c' : cab(r)) + '" stroke-width="' + (st === 'err' ? 2 : (CAB_ON && r.pid > 0 ? 1.8 : 1.2)) + '"' + (st === 'err' ? ' stroke-dasharray="5 4"' : '') + '/>';
                if (plabel(a.port, a.own_port)) lines += '<text x="' + (x1 + 6) + '" y="' + (y2 - 4) + '" font-size="10" fill="' + (CAB_ON && r.pid > 0 ? cab(r) : '#64748b') + '" font-family="monospace">' + esc(plabel(a.port, a.own_port)) + '</text>'; }
            var c = COL[st], subs = a.virtual ? [] : (p.ips.length ? p.ips : [T.noIp + ' · ' + (st === 'err' ? T.suspect : T.inferred)]), sub = subs.length, nm = a.name.length > 22 ? a.name.slice(0, 21) + '…' : a.name;
            var bt = (!a.virtual && a.is_net) ? (a.brand || '').trim() : ''; if (bt.length > 30) bt = bt.slice(0, 29) + '…';
            nodes += '<g class="node" data-id="' + a.id + '" tabindex="0" role="button" style="cursor:' + (a.virtual ? 'default' : 'pointer') + '"><rect x="' + p.x + '" y="' + p.y + '" width="' + NW + '" height="' + p.h + '" rx="8" fill="' + c[0] + '" stroke="' + c[1] + '" stroke-width="1.5"' + (a.virtual || r.float ? ' stroke-dasharray="4 3"' : '') + '/>'
                + (CAB[a.id] ? '<rect x="' + (p.x + 3) + '" y="' + (p.y + 6) + '" width="4" height="' + (p.h - 12) + '" rx="2" fill="' + CAB[a.id] + '"/>' : '')
                + '<text x="' + (p.x + 10) + '" y="' + (p.y + (sub ? 17 : 25)) + '" font-size="12" font-weight="600" fill="#1e293b">' + esc(nm) + '</text>'
                + subs.map(function (t, n) { return '<text x="' + (p.x + 10) + '" y="' + (p.y + 32 + n * 14) + '" font-size="10.5" fill="#64748b" font-family="monospace">' + esc(t.length > 28 ? t.slice(0, 27) + '…' : t) + '</text>'; }).join('')
                + (bt ? '<text x="' + (p.x + 10) + '" y="' + (p.y + 33 + Math.max(1, subs.length) * 14) + '" font-size="10.5" fill="#4338ca" font-weight="500">' + esc(bt) + '</text>' : '') + '</g>';
        });
        // Koneksi tambahan: lengkung putus-putus biru di sisi kanan kedua kotak.
        var pairSeen = {};
        EXTRA.forEach(function (l, k) {
            var A = pos[l.a], B = pos[l.b]; if (!A || !B) return;
            var pk = Math.min(l.a, l.b) + '-' + Math.max(l.a, l.b), pi = pairSeen[pk] = (pairSeen[pk] === undefined ? 0 : pairSeen[pk] + 1);   // kabel ke-2, ke-3 antar perangkat yang sama digeser
            if (FREE) {
                // Lengkung putus-putus seperti tampilan awal: bila bertumpuk, melengkung di sisi kanan;
                // bila berjauhan ke samping, lengkung S dari sisi yang saling berhadapan.
                var o2 = pi * 10 - (pi ? 4 : 0), ay2 = A.y + Math.min(A.h, NH) / 2 + o2, by2 = B.y + Math.min(B.h, NH) / 2 + o2, x1, x2, d;
                if (B.x >= A.x + NW + 20 || A.x >= B.x + NW + 20) {
                    var r2 = B.x > A.x; x1 = r2 ? A.x + NW : A.x; x2 = r2 ? B.x : B.x + NW;
                    var mx2 = (x1 + x2) / 2;
                    d = 'M' + x1 + ',' + ay2 + ' C' + mx2 + ',' + ay2 + ' ' + mx2 + ',' + by2 + ' ' + x2 + ',' + by2;
                } else {
                    x1 = A.x + NW; x2 = B.x + NW;
                    var X2 = Math.max(A.x, B.x) + NW + 40 + (k % 12) * 14;
                    d = 'M' + x1 + ',' + ay2 + ' C' + X2 + ',' + ay2 + ' ' + X2 + ',' + by2 + ' ' + x2 + ',' + by2;
                }
                lines += '<path d="' + d + '" fill="none" stroke="#2563eb" stroke-width="1.6" stroke-dasharray="6 4"/>';
                // label port di luar kotak, di sisi tempat garis keluar (kiri kotak = ditulis ke kiri)
                var ax2 = x1 === A.x ? x1 - 4 - String(l.port_a || '').length * 6 : x1 + 4, bx2 = x2 === B.x ? x2 - 4 - String(l.port_b || '').length * 6 : x2 + 4;
                if (l.port_a) lines += '<text x="' + ax2 + '" y="' + (ay2 - 4) + '" font-size="10" fill="#2563eb" font-family="monospace">' + esc(l.port_a) + '</text>';
                if (l.port_b) lines += '<text x="' + bx2 + '" y="' + (by2 - 4) + '" font-size="10" fill="#2563eb" font-family="monospace">' + esc(l.port_b) + '</text>';
                return;
            }
            var off = pi * 10 - (pi ? 4 : 0), ay = A.y + A.h / 2 + off, by = B.y + B.h / 2 + off, X = Math.max(A.x, B.x) + NW + 40 + k * 14;
            lines += '<path d="M' + (A.x + NW) + ',' + ay + ' C' + X + ',' + ay + ' ' + X + ',' + by + ' ' + (B.x + NW) + ',' + by + '" fill="none" stroke="#2563eb" stroke-width="1.6" stroke-dasharray="6 4"/>';
            if (l.port_a) lines += '<text x="' + (A.x + NW + 4) + '" y="' + (ay - 4) + '" font-size="10" fill="#2563eb" font-family="monospace">' + esc(l.port_a) + '</text>';
            if (l.port_b) lines += '<text x="' + (B.x + NW + 4) + '" y="' + (by - 4) + '" font-size="10" fill="#2563eb" font-family="monospace">' + esc(l.port_b) + '</text>';
        });
        POSG = pos; LISTG = list.map(function (r) { return r.a.id; }); topo.classList.toggle('arr', EDIT);
        topo.innerHTML = '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" role="img">' + boxes + lines + nodes + '</svg>';
        [].forEach.call(topo.querySelectorAll('.node'), function (n) { if (EDIT) { n.style.cursor = 'grab'; n.onpointerdown = function (e) { startDrag(e, +n.dataset.id); }; } var a = byId[n.dataset.id]; if (!a) return; var go = function () { info(a); }; n.onclick = function () { if (!EDIT) go(); }; n.onkeydown = function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } }; });
    }
    function info(a) {
        var kids = descendants(a.id), p = byId[a.parent], st = stateOf(a);
        document.getElementById('nodeInfo').innerHTML = '<div class="flex flex-wrap items-center gap-2 mb-2"><b class="text-slate-800">' + esc(a.name) + '</b>' + badge(st) + '</div>'
            + '<dl class="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1"><dt class="text-slate-500">No. aset</dt><dd>' + esc(a.number) + '</dd><dt class="text-slate-500">Jenis</dt><dd>' + esc(a.type) + '</dd>' + (a.is_net && (a.brand || '').trim() ? '<dt class="text-slate-500">Brand / Type</dt><dd>' + esc(a.brand) + '</dd>' : '') + '<dt class="text-slate-500">Lokasi</dt><dd>' + esc(a.loc || '-') + '</dd><dt class="text-slate-500">IP</dt><dd class="font-mono text-xs">' + esc(a.ip || '-') + (a.ips && a.ips.length > 1 ? '<div class="text-slate-500">' + esc(a.ips.join(', ')) + '</div>' : '') + '</dd>'
            + '<dt class="text-slate-500">' + esc(T.connected) + '</dt><dd>' + (p ? esc(p.name) + (plabel(a.port, a.own_port) ? ' (' + esc(plabel(a.port, a.own_port)) + ')' : '') : '-') + '</dd>'
            + (a.ip ? '<dt class="text-slate-500">' + esc(T.result) + '</dt><dd>' + (a.state ? (a.state === 'err' ? esc(a.detail || T.err) : a.ms + ' ms, ' + esc(T.loss) + ' ' + a.loss + '%') + ' · ' + hm(a.checked_at) : '-') + '</dd>' : '')
            + (function () { var ex = EXTRA.filter(function (l) { return l.a === a.id || l.b === a.id; }).map(function (l) { var o = byId[l.a === a.id ? l.b : l.a]; var mine = l.a === a.id, lb = plabel(mine ? l.port_b : l.port_a, mine ? l.port_a : l.port_b); return o ? esc(o.name) + (lb ? ' <span class="text-slate-400">(' + esc(lb) + ')</span>' : '') : ''; }).filter(Boolean);
                return ex.length ? '<dt class="text-slate-500">' + esc(T.extra) + '</dt><dd class="text-blue-700">' + ex.join('; ') + '</dd>' : ''; })()
            + '<dt class="text-slate-500">' + esc(T.below) + '</dt><dd>' + (kids.length ? kids.length + ' (' + kids.filter(function (k) { return k.state === 'err'; }).length + ' ' + esc(T.err.toLowerCase()) + ')' : '-') + '</dd></dl>';
    }
    // Cari di topologi: kotak yang cocok diberi bingkai biru tebal, yang lain diredupkan, lalu digulir ke hasil pertama.
    function topoSearch(scroll) {
        var q = (val('tQ') || '').toLowerCase().trim(), n = 0, first = null;
        [].forEach.call(topo.querySelectorAll('g.node'), function (g) {
            var a = byId[g.dataset.id], r = g.querySelector('rect');
            if (!r.dataset.st) { r.dataset.st = r.getAttribute('stroke'); r.dataset.sw = r.getAttribute('stroke-width'); }
            var hit = !!(q && a && (a.name + ' ' + a.number + ' ' + a.ip + ' ' + (a.ips || []).join(' ') + ' ' + a.type + ' ' + a.loc + ' ' + (a.brand || '')).toLowerCase().indexOf(q) >= 0);
            r.setAttribute('stroke', hit ? '#2563eb' : r.dataset.st); r.setAttribute('stroke-width', hit ? '3.5' : r.dataset.sw);
            g.style.opacity = q && !hit ? '0.35' : '';
            if (hit) { n++; if (!first) first = g; }
        });
        document.getElementById('tQn').textContent = q ? (n ? n + ' <?= $h(nL('ditemukan', 'found')) ?>' : '<?= $h(nL('tidak ditemukan', 'not found')) ?>') : '';
        if (first && scroll) { first.scrollIntoView({block: 'center', inline: 'center', behavior: 'smooth'}); info(byId[first.dataset.id]); }
    }
    if (topo) {
        document.getElementById('tLoc').onchange = function () { renderTopo(); topoSearch(false); };
        document.getElementById('tGroup').onchange = function () { renderTopo(); topoSearch(false); };
        document.getElementById('tCable').onchange = function () { renderTopo(); topoSearch(false); };
        document.getElementById('tArrange').onclick = function () { setArrange(!EDIT); };
        document.getElementById('tArrSave').onclick = function () {
            if (!DIRTY) { toast(T.orderSaved); return; }
            var out = {}; Object.keys(XY).forEach(function (k) { out[k] = [XY[k].x, XY[k].y]; });
            post({action: 'topo_pos', pos: JSON.stringify(out)}).then(function () {
                XY0 = {}; Object.keys(XY).forEach(function (k) { XY0[k] = {x: XY[k].x, y: XY[k].y}; });
                setDirty(false); toast(T.orderSaved);
            }).catch(function (e) { toast(e.message, true); });
        };
        document.getElementById('tArrCancel').onclick = function () {
            if (DIRTY && !confirm(T.orderDiscard)) return;
            XY = {}; Object.keys(XY0).forEach(function (k) { XY[k] = {x: XY0[k].x, y: XY0[k].y}; });
            setDirty(false); setArrange(false);
        };
        document.getElementById('tArrReset').onclick = function () {
            if (!confirm(T.orderResetQ)) return;
            post({action: 'topo_pos_reset'}).then(function () {
                XY = {}; XY0 = {}; setDirty(false);
                renderTopo(); topoSearch(false); toast(T.orderReset);
            }).catch(function (e) { toast(e.message, true); });
        };
        window.addEventListener('beforeunload', function (e) { if (DIRTY) { e.preventDefault(); e.returnValue = ''; } });
        var tq = document.getElementById('tQ'), tqT = null;
        tq.addEventListener('input', function () { clearTimeout(tqT); tqT = setTimeout(function () { topoSearch(true); }, 250); });
        tq.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); topoSearch(true); } });
        renderTopo();
        var topoUrl = function (pdf) { return 'network_topo_print.php?' + new URLSearchParams({loc: val('tLoc'), net: val('pNet'), orient: val('pOrient'), grp: document.getElementById('tGroup').checked ? '1' : '', cable: document.getElementById('tCable').checked ? '1' : ''}).toString() + (pdf ? '&out=pdf' : ''); };
        document.getElementById('btnTopoPrint').onclick = function () { window.open(topoUrl(false), '_blank'); };
        document.getElementById('btnTopoPdf').onclick = function () { location.href = topoUrl(true); };
    }

    /* ---------- Scan ---------- */
    var sBtn = document.getElementById('btnScan');
    if (sBtn) sBtn.onclick = function () {
        var net = val('sNet'), pre = net.split('.').slice(0, 3).join('.') + '.', found = {}, from = 1, CH = 32;
        sBtn.disabled = true; document.getElementById('sProg').classList.remove('hidden'); document.getElementById('sSum').innerHTML = '';
        (function next() {
            if (from > 254) {
                document.getElementById('sTxt').textContent = T.reading;
                post({action: 'scan_finish', subnet: net, found: JSON.stringify(found)}).then(showScan).catch(function (e) { toast(T.failed + ': ' + e.message, true); }).then(function () { sBtn.disabled = false; });
                return;
            }
            var to = Math.min(254, from + CH - 1);
            document.getElementById('sTxt').textContent = T.scanning + ' ' + pre + from + '–' + to;
            post({action: 'scan_chunk', subnet: net, from: from, to: to}).then(function (d) { if (d.found) Object.keys(d.found).forEach(function (ip) { found[ip] = d.found[ip]; }); })
                .catch(function (e) { toast(T.failed + ': ' + e.message, true); }).then(function () { document.getElementById('sBar').style.width = (to / 254 * 100) + '%'; from = to + 1; next(); });
        })();
    };
    function showScan(d, old) {
        if (!d || (!old && !d.ok)) { toast((d && d.error) || T.failed, true); return; }
        var un = d.rows.filter(function (r) { return !r.asset_id; });
        if (!old) document.getElementById('sTxt').textContent = T.done + ': ' + d.rows.length + ' ' + T.active + ' · ' + d.subnet;
        document.getElementById('sSum').innerHTML = '<div class="mb-3 text-sm rounded-lg px-4 py-3 ' + (un.length ? 'bg-amber-50 border border-amber-200 text-amber-900' : 'bg-blue-50 border border-blue-100 text-slate-700') + '">' + (old ? esc(T.lastScan) + ' (' + esc(d.scanned_at) + '): ' : '') + '<b>' + d.rows.length + ' ' + esc(T.active) + ', ' + un.length + ' ' + esc(T.notReg) + '.</b>'
            + (d.missing && d.missing.length ? ' ' + esc(T.missing) + ': ' + esc(d.missing.join(', ')) + '.' : '') + '</div>';
        document.getElementById('sRows').innerHTML = d.rows.map(function (r) {
            return '<tr class="border-t ' + (r.asset_id ? '' : 'bg-amber-50/60') + '"><td class="px-3 py-2 font-mono text-xs">' + esc(r.ip) + '</td><td class="px-3 py-2 font-mono text-xs">' + esc(r.mac || '-') + '</td><td class="px-3 py-2">' + esc(r.vendor || '-') + '</td><td class="px-3 py-2 text-xs">' + esc(r.host || '-') + '</td><td class="px-3 py-2 text-right tabular-nums">' + r.ms + ' ms</td>'
                + '<td class="px-3 py-2">' + (r.asset_id ? '<span class="text-xs font-semibold text-green-700">' + esc(T.registered) + '</span> ' + esc(r.asset_name) : '<span class="text-xs font-semibold text-amber-700">' + esc(T.unregistered) + '</span> <a class="ml-2 text-xs text-blue-600 hover:underline" href="assets.php">' + esc(T.register) + ' &rarr;</a>') + '</td></tr>';
        }).join('') || '<tr><td colspan="6" class="px-3 py-6 text-center text-slate-500">-</td></tr>';
    }
    var sNet = document.getElementById('sNet');
    if (sNet) { var showSaved = function () { if (SAVED[sNet.value]) showScan(SAVED[sNet.value], true); }; sNet.onchange = function () { document.getElementById('sSum').innerHTML = ''; document.getElementById('sRows').innerHTML = ''; showSaved(); }; showSaved(); }
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
