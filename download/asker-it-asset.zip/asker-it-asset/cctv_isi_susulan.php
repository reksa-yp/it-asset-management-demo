<?php
/**
 * Checklist susulan (khusus admin): mengisi checklist hari-hari yang lalu sekaligus dengan hasil "semua OK".
 * - Hari libur (Sabtu/Minggu & libur di Pengaturan > 6) dilewati.
 * - Tanggal + shift yang sudah punya checklist tidak diubah.
 * - Nama petugas bisa diberi tanda "(susulan)" agar laporan jujur bahwa data diisi belakangan.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv.php';

$db = getDB();
ensureCctvTables($db);
$h = fn($v) => htmlspecialchars((string)$v);
$me = currentUser();

$from = (string)($_REQUEST['from'] ?? date('Y') . '-01-01');
$to   = (string)($_REQUEST['to'] ?? date('Y-m-d', strtotime('-1 day')));
$okDate = fn($d) => preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && strtotime($d);
if (!$okDate($from)) $from = date('Y') . '-01-01';
if (!$okDate($to) || $to >= date('Y-m-d')) $to = date('Y-m-d', strtotime('-1 day'));
$officer = mb_substr(trim((string)($_REQUEST['officer'] ?? ($me['full_name'] ?? 'Admin IT'))), 0, 80) ?: 'Admin IT';
$markLate = $_SERVER['REQUEST_METHOD'] === 'POST' ? !empty($_POST['mark_late']) : true;

$shifts = cctvShiftOptions();
$cams   = cctvCameras($db);
$groups = cctvNvrGroups($cams);
$codes  = array_column(cctvCheckItems($db), 'code');
$shiftTime = fn(int $i) => [0 => '08:00:00', 1 => '16:00:00', 2 => '23:30:00'][$i] ?? '12:00:00';

/** Rencana: daftar [tanggal, shift] yang akan diisi. */
function cctvSusulanPlan(PDO $db, string $from, string $to, array $shifts): array
{
    $off = $from <= $to ? cctvOffDays($db, $from, $to) : [];
    $st = $db->prepare("SELECT check_date, shift FROM cctv_checklists WHERE check_date BETWEEN ? AND ?");
    $st->execute([$from, $to]);
    $have = [];
    foreach ($st->fetchAll() as $r) $have[substr((string)$r['check_date'], 0, 10) . '|' . $r['shift']] = true;
    $plan = []; $skipOff = 0; $skipHave = 0;
    for ($t = strtotime($from); $from <= $to && $t <= strtotime($to); $t = strtotime('+1 day', $t)) {
        $d = date('Y-m-d', $t);
        if (isset($off[$d])) { $skipOff++; continue; }
        foreach ($shifts as $i => $sh) {
            if (isset($have[$d . '|' . $sh])) { $skipHave++; continue; }
            $plan[] = [$d, $sh, $i];
        }
    }
    return ['plan' => $plan, 'off_days' => $skipOff, 'existing' => $skipHave];
}

$msg = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'run') {
    csrfCheck();
    $res = cctvBackfillChecklists($db, $from, $to, (int)$me['id'], $officer . ($markLate ? ' (susulan)' : ''));
    $n = $res['n'];
    $msg = $res['error'] === ''
        ? ['ok' => true, 'text' => cL("$n checklist susulan tersimpan (semua kamera OK). Cek di Cetak & laporan > Rekap bulanan.", "$n back-filled checklists saved (all cameras OK).")]
        : ['ok' => false, 'text' => cL("Berhenti setelah $n checklist (bulan yang sudah selesai tetap tersimpan; klik Buat lagi untuk melanjutkan): ", "Stopped after $n checklists: ") . $res['error']];
}

$p = cctvSusulanPlan($db, $from, $to, $shifts);
$camCount = count($cams);
$pageTitle = cL('Checklist susulan', 'Back-fill checklists');
$cctvTab = 'checklist';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
$input = 'border border-slate-300 rounded-lg px-2 py-1.5 text-sm';
?>
<div class="mb-3">
    <h1 class="text-xl font-semibold text-slate-800"><?= $h($pageTitle) ?></h1>
    <p class="text-sm text-slate-500"><?= $h(cL('Mengisi checklist hari-hari yang lalu sekaligus dengan hasil semua kamera OK.', 'Fill past checklists at once with all cameras OK.')) ?></p>
</div>
<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<form method="post" class="bg-white rounded-xl shadow-sm p-5 text-sm space-y-4 max-w-3xl">
    <div class="grid sm:grid-cols-3 gap-3">
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Dari tanggal', 'From')) ?></span><input type="date" name="from" value="<?= $h($from) ?>" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Sampai tanggal', 'To')) ?></span><input type="date" name="to" value="<?= $h($to) ?>" max="<?= $h(date('Y-m-d', strtotime('-1 day'))) ?>" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Nama petugas', 'Officer')) ?></span><input name="officer" value="<?= $h($officer) ?>" maxlength="80" class="<?= $input ?>"></label>
    </div>
    <label class="inline-flex items-start gap-2"><input type="checkbox" name="mark_late" value="1" <?= $markLate ? 'checked' : '' ?> class="w-4 h-4 mt-0.5">
        <span><?= $h(cL('Tandai sebagai data susulan: nama petugas di checklist & laporan ditulis "', 'Mark as back-filled: officer shown as "') . $officer . ' (susulan)"') ?></span></label>

    <div class="rounded-lg bg-slate-50 border border-slate-200 p-3 space-y-1">
        <p><b><?= count($p['plan']) ?></b> <?= $h(cL('checklist akan dibuat', 'checklists will be created')) ?> (<?= $h(implode(', ', $shifts)) ?>; <?= count($groups) ?> NVR; <?= $camCount ?> <?= $h(cL('kamera', 'cameras')) ?>, <?= $h(cL('semua item ✓ OK', 'all items ✓ OK')) ?>).</p>
        <p class="text-slate-500"><?= $h(cL('Dilewati', 'Skipped')) ?>: <?= (int)$p['off_days'] ?> <?= $h(cL('hari libur (Sabtu/Minggu & libur di Pengaturan > 6)', 'days off')) ?>, <?= (int)$p['existing'] ?> <?= $h(cL('shift yang sudah punya checklist (tidak diubah)', 'shifts already filled (unchanged)')) ?>.</p>
        <p class="text-slate-500"><?= $h(cL('Jam cek dicatat: Pagi 08:00, Sore 16:00. Libur nasional / cuti bersama sebaiknya diisi dulu di Pengaturan > 6 agar ikut dilewati.', 'Check times recorded: 08:00 and 16:00. Enter holidays in Settings > 6 first so they are skipped.')) ?></p>
    </div>
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
    <div class="flex flex-wrap gap-2">
        <button name="action" value="preview" class="rounded-lg border border-slate-300 bg-white hover:bg-slate-50 px-4 py-2"><?= $h(cL('Hitung ulang', 'Recalculate')) ?></button>
        <?php if ($p['plan']): ?>
        <button name="action" value="run" onclick="return confirm('<?= $h(cL('Buat ' . count($p['plan']) . ' checklist susulan?', 'Create ' . count($p['plan']) . ' checklists?')) ?>')" class="rounded-lg bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 font-medium"><?= $h(cL('Buat ' . count($p['plan']) . ' checklist', 'Create ' . count($p['plan']) . ' checklists')) ?></button>
        <?php endif; ?>
    </div>
</form>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
