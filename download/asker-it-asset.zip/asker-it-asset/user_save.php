<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: users.php');
    exit;
}
csrfCheck();

$id         = $_POST['id'] ?: null;
$fullName   = trim($_POST['full_name'] ?? '');
$username   = trim($_POST['username'] ?? '');
$email      = trim($_POST['email'] ?? '');
$department = trim($_POST['department'] ?? '');
$password   = $_POST['password'] ?? '';
$pcUsername = trim($_POST['pc_username'] ?? '');
$pcPassword = trim($_POST['pc_password'] ?? '');
$role       = $_POST['role'] === 'admin' ? 'admin' : 'user';
$isActive   = $_POST['is_active'] ?? 1;

$pcUsername = $pcUsername !== '' ? $pcUsername : null;
$pcPassword = $pcPassword !== '' ? $pcPassword : null;

if ($fullName === '' || $username === '') {
    die('Nama dan username wajib diisi.');
}

$db = getDB();

// Pastikan username unik (selain dirinya sendiri saat edit)
$check = $db->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
$check->execute([$username, $id ?: 0]);
if ($check->fetch()) {
    die('Username sudah digunakan oleh user lain.');
}

if ($id) {
    if ($password !== '') {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $db->prepare("UPDATE users SET full_name=?, username=?, email=?, department=?, password=?, pc_username=?, pc_password=?, role=?, is_active=? WHERE id=?");
        $stmt->execute([$fullName, $username, $email, $department, $hash, $pcUsername, $pcPassword, $role, $isActive, $id]);
    } else {
        $stmt = $db->prepare("UPDATE users SET full_name=?, username=?, email=?, department=?, pc_username=?, pc_password=?, role=?, is_active=? WHERE id=?");
        $stmt->execute([$fullName, $username, $email, $department, $pcUsername, $pcPassword, $role, $isActive, $id]);
    }
} else {
    if ($password === '') { die('Password wajib diisi untuk user baru.'); }
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $db->prepare("INSERT INTO users (full_name, username, email, department, password, pc_username, pc_password, role, is_active) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$fullName, $username, $email, $department, $hash, $pcUsername, $pcPassword, $role, $isActive]);
    $id = (int)$db->lastInsertId();
}

// Jabatan disimpan di tabel terpisah (user_positions), tabel users tidak diubah.
saveUserPosition($db, (int)$id, (string)($_POST['position'] ?? ''));

// Departement, Email, Username & Password PC user ini otomatis ikut ke semua aset yang dipakainya
// (lihat includes/asset_user_sync.php). Data ini hanya diisi di menu User.
syncAssetsUserData($db, assetIdsOfUsers($db, [(int)$id]));

header('Location: users.php');
exit;
