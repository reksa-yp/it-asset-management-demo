# Nametag

Menu **Nametag** (admin & user): nametag meja yang dilipat dua, ukuran **29,1 × 13,5 cm**.

- Nama lengkap, departemen, dan jabatan terisi otomatis dari data user, bisa diubah khusus untuk nametag.
- Nama panggilan tampil di sebelah nama lengkap, dipisah ` / ` (contoh: `BUDI SANTOSO / BUDI`). Kosongkan bila tidak perlu.
- Foto diunggah sendiri (Ambil foto / Pilih file), lalu atur dengan slider Perbesar & Geser.
- **Simpan & Cetak**: membuka halaman cetak dan dialog cetak otomatis. **Simpan PDF (F4)**: mengunduh PDF ukuran F4.
- User biasa hanya bisa membuat nametag miliknya; admin bisa memilih user mana saja.

## Wajib kertas F4

Satu lembar F4 (21,5 × 33 cm, landscape) = satu nametag. Di dialog cetak pilih ukuran kertas **F4 / Folio**,
orientasi **Landscape**, skala **100% (Actual size)**, margin **None**. Jangan pakai A4: tepinya hanya tersisa 3 mm sehingga nametag bisa terpotong printer.
Disarankan kertas tebal (art carton 210–260 gsm). Potong di tanda sudut, lipat di garis tengah.

## Teknis

- Tabel baru `nametags` (otomatis, tabel lama tidak diubah); foto di `assets/uploads/nametag/`.
- Gambar cetak dibuat di server (GD, 300 dpi) dengan font Montserrat (`assets/fonts`, lisensi SIL OFL).
- Logo nametag: taruh logo perusahaan Anda di `assets/img/nametag_logo.png` (PNG putih transparan, ±379 × 156 px). Tanpa file ini nametag dicetak tanpa logo.
- File: `nametag.php`, `nametag_print.php`, `includes/nametag.php`.

## Nametag Tamu (khusus admin)

Menu **Nametag → tab "Nametag tamu"** (hanya terlihat oleh admin).

- Nametag meja untuk tamu, ukuran **15 × 19,99 cm** (dilipat dua).
- Nama 40 pt (diperkecil otomatis bila terlalu panjang), jabatan 22 pt (terlalu panjang pindah ke baris baru, maks. 3 baris).
- Isi **banyak nama & jabatan/perusahaan** sekaligus: per baris, atau tempel dari Excel (2 kolom) / teks `Nama ; Jabatan`.
- **2 nametag per lembar** kertas **F4 / Folio** atau **Legal** (landscape). Maks. 100 nama sekali cetak.
- Garis bantu: garis putus-putus merah = garis potong (15 × 19,99 cm), tanda sudut, dan tanda lipat di kiri-kanan.
- **Cetak semua** (dialog cetak otomatis) atau **Simpan PDF** (satu file berisi semua lembar).
- Daftar tamu tidak disimpan di database; daftar terakhir diingat selama admin masih login.
- Logo di pita putih memakai **logo aplikasi** (Pengaturan Sistem). Tanpa logo, pita dibiarkan polos.
- File: `nametag_guest_print.php`, `includes/nametag_guest.php`, `includes/nametag_guest_view.php`.
