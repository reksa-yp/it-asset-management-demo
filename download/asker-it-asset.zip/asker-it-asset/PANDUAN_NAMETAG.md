# Nametag

Menu **Nametag** (admin & user): nametag meja yang dilipat dua, ukuran **30 × 13,6 cm**.

- Nama lengkap, departemen, dan jabatan terisi otomatis dari data user, bisa diubah khusus untuk nametag.
- Nama panggilan tampil di sebelah nama lengkap, dipisah ` / ` (contoh: `BUDI SANTOSO / BUDI`). Kosongkan bila tidak perlu.
- Foto diunggah sendiri (Ambil foto / Pilih file), lalu atur dengan slider Perbesar & Geser.
- **Simpan & Cetak**: membuka halaman cetak dan dialog cetak otomatis. **Simpan PDF (F4)**: mengunduh PDF ukuran F4.
- User biasa hanya bisa membuat nametag miliknya; admin bisa memilih user mana saja.

## Wajib kertas F4

Satu lembar F4 (21,5 × 33 cm, landscape) = satu nametag. Di dialog cetak pilih ukuran kertas **F4 / Folio**,
orientasi **Landscape**, skala **100% (Actual size)**, margin **None**. Kertas A4 terlalu pendek (29,7 cm).
Disarankan kertas tebal (art carton 210–260 gsm). Potong di tanda sudut, lipat di garis tengah.

## Teknis

- Tabel baru `nametags` (otomatis, tabel lama tidak diubah); foto di `assets/uploads/nametag/`.
- Gambar cetak dibuat di server (GD, 300 dpi) dengan font Montserrat (`assets/fonts`, lisensi SIL OFL).
- Logo nametag: taruh logo perusahaan Anda di `assets/img/nametag_logo.png` (PNG putih transparan, ±379 × 156 px). Tanpa file ini nametag dicetak tanpa logo.
- File: `nametag.php`, `nametag_print.php`, `includes/nametag.php`.
