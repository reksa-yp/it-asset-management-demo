<?php
/**
 * Menu Export Audit (khusus admin).
 * Admin memilih sumber data + kolom yang diinginkan, melihat pratinjau, lalu export ke Excel.
 * Hanya membaca data (SELECT) — tidak mengubah database. Lihat includes/audit.php.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/audit.php';

$db       = getDB();
$datasets = auditDatasets();
$dsKey    = isset($datasets[$_GET['data'] ?? '']) ? $_GET['data'] : 'assets';
$ds       = $datasets[$dsKey];
$f        = auditFilters();
$submitted = isset($_GET['action']);

// Kolom terpilih: dari form; saat halaman baru dibuka pakai kolom bawaan.
$allCols = array_keys($ds['columns']);
if ($submitted) {
    $selected = array_values(array_intersect($allCols, (array)($_GET['cols'] ?? [])));
} else {
    $selected = array_values(array_filter($allCols, fn($k) => $ds['columns'][$k]['default']));
}
$hasSensitive = (bool)array_filter($selected, fn($k) => $ds['columns'][$k]['sensitive']);

$action  = $_GET['action'] ?? '';
$error   = ($submitted && !$selected) ? t('audit_err_no_columns') : '';
$result  = null;
if ($submitted && !$error) {
    $result = auditFetch($db, $dsKey, $f);
    [$headers, $tableRows] = auditBuildTable($ds, $selected, $result['rows']);
}

// ===================== EXPORT EXCEL =====================
if ($action === 'export' && !$error && $result && !$result['missing']) {
    require_once __DIR__ . '/vendor/autoload.php';

    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('Audit');
    $colCount = count($headers) + 1; // + kolom No
    $lastCol  = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($colCount);
    $text     = \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING;

    // Bagian judul
    $info = [
        t('app_name') . ' — ' . t('audit_xls_title') . ': ' . $ds['label'],
        t('audit_xls_filter') . ': ' . auditFilterSummary($ds, $f),
        t('audit_xls_printed') . ': ' . date('d M Y H:i') . '   |   ' . t('audit_xls_by') . ': ' . (currentUser()['full_name'] ?? '-')
            . '   |   ' . t('audit_xls_total') . ': ' . count($tableRows),
    ];
    foreach ($info as $i => $line) {
        $sheet->setCellValueExplicit('A' . ($i + 1), $line, $text);
        $sheet->mergeCells('A' . ($i + 1) . ':' . $lastCol . ($i + 1));
    }
    $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(13);

    // Header tabel (baris 5)
    $headRow = 5;
    $sheet->setCellValueExplicit('A' . $headRow, t('audit_col_no'), $text);
    foreach ($headers as $c => $hText) {
        $sheet->setCellValueExplicit(\PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($c + 2) . $headRow, $hText, $text);
    }
    // Isi: semuanya ditulis sebagai TEKS supaya serial number / IP / angka panjang tidak berubah format.
    foreach ($tableRows as $r => $row) {
        $excelRow = $headRow + 1 + $r;
        $sheet->setCellValue('A' . $excelRow, $r + 1);
        foreach ($row as $c => $val) {
            $sheet->setCellValueExplicit(\PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($c + 2) . $excelRow, $val, $text);
        }
    }
    $lastRow = $headRow + max(1, count($tableRows));
    $head = "A{$headRow}:{$lastCol}{$headRow}";
    $sheet->getStyle($head)->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
    $sheet->getStyle($head)->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
    $sheet->getStyle($head)->getAlignment()->setHorizontal('center')->setVertical('center')->setWrapText(true);
    $sheet->getStyle("A{$headRow}:{$lastCol}{$lastRow}")->getBorders()->getAllBorders()
          ->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
    $sheet->getStyle('A' . ($headRow + 1) . ":{$lastCol}{$lastRow}")->getAlignment()->setVertical('top')->setWrapText(true);
    $sheet->getColumnDimension('A')->setWidth(6);
    // Lebar kolom mengikuti isi terpanjang (dibatasi 12–50 karakter).
    foreach ($headers as $c => $hText) {
        $max = mb_strlen($hText);
        foreach ($tableRows as $row) { $max = max($max, mb_strlen($row[$c])); }
        $sheet->getColumnDimension(\PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($c + 2))->setWidth(min(50, max(12, $max + 2)));
    }
    $sheet->freezePane('A' . ($headRow + 1));
    $sheet->setAutoFilter($head);
    $sheet->getPageSetup()->setOrientation(\PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_LANDSCAPE)
          ->setFitToWidth(1)->setFitToHeight(0);

    // Kop + judul otomatis (mengikuti Jenis aset yang dipilih) + tanggal dibuat + jumlah data, judul kolom di baris 8.
    require_once __DIR__ . '/includes/xls_number.php';
    require_once __DIR__ . '/includes/letterhead.php';
    $auditCats  = (in_array('category', $ds['filters'], true) && !empty($f['category'])) ? (array)$f['category'] : [];
    $auditTitle = $auditCats ? xlsAssetExportTitle($auditCats) : 'Data ' . $ds['label'] . ' ' . xlsCompanyName();
    xlsAddTitleBlock($sheet, $headRow, $auditTitle, [
        documentCreatedAt() . '   |   ' . t('audit_xls_by') . ': ' . (currentUser()['full_name'] ?? '-'),
        xlsCountLine('Jumlah data', 'Total rows', count($tableRows), [t('audit_xls_filter') . ': ' . auditFilterSummary($ds, $f)]),
    ]);

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="audit_' . $dsKey . '_' . date('Ymd_His') . '.xlsx"');
    header('Cache-Control: max-age=0');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet))->save('php://output');
    exit;
}

// ===================== HALAMAN =====================
$options   = auditFilterOptions($db);
$pageTitle = t('page_title_audit');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
$h = fn($s) => htmlspecialchars((string)$s);
$PREVIEW_LIMIT = 25;
?>

<p class="text-sm text-slate-500 mb-4 max-w-3xl"><?= t('audit_intro') ?></p>

<!-- Pilih sumber data -->
<div class="flex flex-wrap gap-2 mb-4">
    <?php foreach ($datasets as $k => $d): ?>
        <a href="audit_export.php?data=<?= $h($k) ?>"
           class="px-4 py-2 rounded-lg text-sm font-medium border <?= $k === $dsKey ? 'bg-brand-600 border-brand-600 text-white' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50' ?>">
            <?= $h($d['label']) ?>
        </a>
    <?php endforeach; ?>
</div>

<?php if ($error): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 bg-red-50 text-red-700"><?= $h($error) ?></div>
<?php endif; ?>

<form method="get" id="auditForm" class="space-y-4">
    <input type="hidden" name="data" value="<?= $h($dsKey) ?>">

    <!-- Kolom -->
    <div class="bg-white rounded-xl shadow-sm p-5">
        <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
            <h2 class="font-semibold text-slate-800"><?= t('audit_step_columns') ?>
                <span class="ml-1 text-xs font-normal text-slate-400">(<span id="auditColCount">0</span> / <?= count($allCols) ?>)</span></h2>
            <div class="flex gap-2 text-xs">
                <button type="button" onclick="auditCheckAll(true)" class="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"><?= t('audit_select_all') ?></button>
                <button type="button" onclick="auditCheckAll(false)" class="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"><?= t('audit_select_none') ?></button>
            </div>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-2 text-sm">
            <?php foreach ($ds['columns'] as $k => $c): ?>
                <label class="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-slate-50 cursor-pointer">
                    <input type="checkbox" name="cols[]" value="<?= $h($k) ?>" class="audit-col rounded border-slate-300"
                           <?= $c['sensitive'] ? 'data-sensitive="1"' : '' ?> <?= in_array($k, $selected, true) ? 'checked' : '' ?>>
                    <span><?= $h($c['label']) ?></span>
                    <?php if ($c['sensitive']): ?><span class="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-700"><?= t('audit_sensitive') ?></span><?php endif; ?>
                </label>
            <?php endforeach; ?>
        </div>
        <p id="auditSensitiveNote" class="<?= $hasSensitive ? '' : 'hidden' ?> mt-3 text-xs rounded-lg px-3 py-2 bg-amber-50 text-amber-800"><?= t('audit_sensitive_note') ?></p>
    </div>

    <!-- Filter -->
    <div class="bg-white rounded-xl shadow-sm p-5">
        <h2 class="font-semibold text-slate-800 mb-1"><?= t('audit_step_filter') ?></h2>
        <p class="text-xs text-slate-400 mb-3"><?= t('audit_filter_hint') ?></p>
        <div class="flex flex-wrap items-start gap-4 text-sm">
            <?php if (in_array('category', $ds['filters'], true)): ?>
                <fieldset class="flex flex-col gap-1 min-w-[200px]">
                    <legend class="text-xs text-slate-500 mb-1"><?= t('field_category') ?>
                        <span class="text-slate-400">(<?= t('audit_none_means_all') ?>)</span></legend>
                    <div class="border border-slate-200 rounded-lg p-2 max-h-44 overflow-y-auto space-y-0.5">
                        <?php foreach ($options['category'] as $o): ?>
                            <label class="flex items-center gap-2 px-1.5 py-1 rounded hover:bg-slate-50 cursor-pointer">
                                <input type="checkbox" name="category[]" value="<?= $h($o) ?>" class="audit-filter rounded border-slate-300" data-group="category"
                                       <?= in_array($o, $f['category'], true) ? 'checked' : '' ?>>
                                <span><?= $h($o) ?></span>
                            </label>
                        <?php endforeach; ?>
                        <?php if (!$options['category']): ?><p class="px-1.5 py-1 text-slate-400"><?= t('dash') ?></p><?php endif; ?>
                    </div>
                </fieldset>
            <?php endif; ?>
            <?php if (in_array('department', $ds['filters'], true)): ?>
                <fieldset class="flex flex-col gap-1 min-w-[200px]">
                    <legend class="text-xs text-slate-500 mb-1"><?= t('xls_hdr_department') ?>
                        <span class="text-slate-400">(<?= t('audit_none_means_all') ?>)</span></legend>
                    <div class="border border-slate-200 rounded-lg p-2 max-h-44 overflow-y-auto space-y-0.5">
                        <?php foreach ($options['department'] as $o): ?>
                            <label class="flex items-center gap-2 px-1.5 py-1 rounded hover:bg-slate-50 cursor-pointer">
                                <input type="checkbox" name="department[]" value="<?= $h($o) ?>" class="audit-filter rounded border-slate-300" data-group="department"
                                       <?= in_array($o, $f['department'], true) ? 'checked' : '' ?>>
                                <span><?= $h($o) ?></span>
                            </label>
                        <?php endforeach; ?>
                        <?php if (!$options['department']): ?><p class="px-1.5 py-1 text-slate-400"><?= t('dash') ?></p><?php endif; ?>
                    </div>
                </fieldset>
            <?php endif; ?>
            <?php if (in_array('status', $ds['filters'], true)): ?>
                <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('xls_hdr_status') ?></span>
                    <select name="status" class="border border-slate-300 rounded-lg px-2 py-1.5">
                        <option value=""><?= t('audit_all') ?></option>
                        <?php foreach (['Digunakan' => t('status_used'), 'Stok' => t('status_stock'), 'Tidak Digunakan' => t('status_unused')] as $v => $lbl): ?>
                            <option value="<?= $h($v) ?>" <?= $f['status'] === $v ? 'selected' : '' ?>><?= $h($lbl) ?></option>
                        <?php endforeach; ?>
                    </select></label>
            <?php endif; ?>
            <?php if (in_array('role', $ds['filters'], true)): ?>
                <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('audit_col_role') ?></span>
                    <select name="role" class="border border-slate-300 rounded-lg px-2 py-1.5">
                        <option value=""><?= t('audit_all') ?></option>
                        <option value="admin" <?= $f['role'] === 'admin' ? 'selected' : '' ?>><?= t('role_admin') ?></option>
                        <option value="user" <?= $f['role'] === 'user' ? 'selected' : '' ?>><?= t('role_user') ?></option>
                    </select></label>
            <?php endif; ?>
            <?php if (in_array('date', $ds['filters'], true)): ?>
                <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('audit_from') ?></span>
                    <input type="date" name="from" value="<?= $h($f['from']) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
                <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('audit_to') ?></span>
                    <input type="date" name="to" value="<?= $h($f['to']) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
            <?php endif; ?>
        </div>
    </div>

    <div class="flex flex-wrap gap-2">
        <button type="submit" name="action" value="preview" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('file-text') ?> <?= t('audit_btn_preview') ?>
        </button>
        <button type="submit" name="action" value="export" onclick="return auditConfirmExport()" class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('sheet') ?> <?= t('btn_export_excel') ?>
        </button>
        <a href="audit_export.php?data=<?= $h($dsKey) ?>" onclick="try{localStorage.removeItem(auditKey)}catch(e){}" class="px-3 py-2 text-sm text-slate-500 hover:text-slate-700"><?= t('audit_reset') ?></a>
    </div>
</form>

<?php if ($result): ?>
<div class="bg-white rounded-xl shadow-sm mt-5 overflow-hidden">
    <div class="px-5 py-3 border-b flex flex-wrap items-center justify-between gap-2">
        <h2 class="font-semibold text-slate-800"><?= t('audit_preview_title') ?></h2>
        <span class="text-xs text-slate-500">
            <?= $result['missing'] ? '' : $h(sprintf(t('audit_preview_count'), min($PREVIEW_LIMIT, count($tableRows)), count($tableRows))) ?>
        </span>
    </div>
    <?php if ($result['missing']): ?>
        <p class="p-8 text-center text-sm text-slate-400"><?= t('audit_missing_table') ?></p>
    <?php elseif (!$tableRows): ?>
        <p class="p-8 text-center text-sm text-slate-400"><?= t('audit_no_rows') ?></p>
    <?php else: ?>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-slate-50 text-left text-xs text-slate-500">
            <tr>
                <th class="py-2 px-3 w-10"><?= t('audit_col_no') ?></th>
                <?php foreach ($headers as $hd): ?><th class="py-2 px-3 whitespace-nowrap"><?= $h($hd) ?></th><?php endforeach; ?>
            </tr>
            </thead>
            <tbody class="divide-y">
            <?php foreach (array_slice($tableRows, 0, $PREVIEW_LIMIT) as $i => $row): ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-2 px-3 text-slate-400 tabular-nums"><?= $i + 1 ?></td>
                    <?php foreach ($row as $val): ?><td class="py-2 px-3 align-top"><?= $val !== '' ? $h($val) : '<span class="text-slate-300">-</span>' ?></td><?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php
$auditConfirmText = json_encode(t('audit_sensitive_confirm'));
$auditDsJson      = json_encode($dsKey);
$auditFreshJson   = json_encode(!$submitted && !array_intersect_key($_GET, array_flip(['category', 'department', 'cols'])));
$extraScripts = <<<HTML
<script>
function auditUpdate() {
    var boxes = document.querySelectorAll('.audit-col');
    var n = 0, sens = false;
    boxes.forEach(function (b) { if (b.checked) { n++; if (b.dataset.sensitive) sens = true; } });
    document.getElementById('auditColCount').textContent = n;
    document.getElementById('auditSensitiveNote').classList.toggle('hidden', !sens);
    return sens;
}
// "Pilih semua" sengaja TIDAK mencentang kolom sensitif (Password PC) — harus dicentang sendiri.
function auditCheckAll(on) {
    document.querySelectorAll('.audit-col').forEach(function (b) { b.checked = on && !b.dataset.sensitive; });
    auditUpdate();
}
function auditConfirmExport() {
    return auditUpdate() ? confirm({$auditConfirmText}) : true;
}
// Ingat pilihan terakhir (kolom + jenis aset + departement) per sumber data di browser ini,
// supaya tidak perlu mencentang ulang setiap kali. Kolom sensitif tidak pernah dipulihkan otomatis.
var auditKey = 'auditExport:' + {$auditDsJson};
function auditSave() {
    try {
        var data = { cols: [], category: [], department: [] };
        document.querySelectorAll('.audit-col:checked').forEach(function (b) { if (!b.dataset.sensitive) data.cols.push(b.value); });
        document.querySelectorAll('.audit-filter:checked').forEach(function (b) { data[b.dataset.group].push(b.value); });
        localStorage.setItem(auditKey, JSON.stringify(data));
    } catch (e) {}
}
function auditRestore() {
    try {
        var data = JSON.parse(localStorage.getItem(auditKey) || 'null');
        if (!data) return;
        if (data.cols && data.cols.length) {
            document.querySelectorAll('.audit-col').forEach(function (b) { b.checked = !b.dataset.sensitive && data.cols.indexOf(b.value) !== -1; });
        }
        document.querySelectorAll('.audit-filter').forEach(function (b) { b.checked = (data[b.dataset.group] || []).indexOf(b.value) !== -1; });
    } catch (e) {}
}
if ({$auditFreshJson}) auditRestore();   // halaman baru dibuka (belum klik Pratinjau/Export)
document.getElementById('auditForm').addEventListener('submit', auditSave);
document.querySelectorAll('.audit-col').forEach(function (b) { b.addEventListener('change', auditUpdate); });
auditUpdate();
</script>
HTML;
require_once __DIR__ . '/includes/footer.php';
