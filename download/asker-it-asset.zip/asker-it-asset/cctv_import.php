<?php
/**
 * Import aset CCTV & NVR dari Excel (khusus admin).
 *   ?template=1         unduh template kosong
 *   ?template=1&data=1  unduh template berisi data CCTV & NVR yang sudah ada (edit massal lalu import lagi)
 * Alur: upload -> preview (baru / diperbarui / error) -> Simpan. Lihat includes/cctv_import.php.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/includes/cctv_import.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$db = getDB();
$h  = fn($v) => htmlspecialchars((string)$v);
$cats = cctvImpCategories($db);
$backUrl = 'assets.php?category=' . urlencode($cats['cctv'][0] ?? 'CCTV');

function cctvImportDiscard(): void
{
    $p = $_SESSION['cctv_import'] ?? null;
    if ($p && !empty($p['file']) && is_file($p['file'])) @unlink($p['file']);
    unset($_SESSION['cctv_import']);
}

// ===== Unduh template =====
if (!empty($_GET['template'])) {
    $ss = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $withData = !empty($_GET['data']);
    writeCctvImportTemplate($db, $ss, $withData);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . ($withData ? 'data_cctv_nvr_' . date('Ymd') : 'template_import_cctv') . '.xlsx"');
    header('Cache-Control: max-age=0');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($ss))->save('php://output');
    exit;
}

// ===== Upload / Simpan / Batal =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $act = (string)($_POST['action'] ?? '');
    if ($act === 'upload') {
        cctvImportDiscard();
        try {
            if (empty($_FILES['excel_file']['tmp_name']) || !is_uploaded_file($_FILES['excel_file']['tmp_name'])) throw new Exception(cL('Pilih file Excel dulu.', 'Choose an Excel file first.'));
            $ss = IOFactory::load($_FILES['excel_file']['tmp_name']);
            if (!isCctvImportSpreadsheet($ss)) throw new Exception(cL('File bukan format import CCTV (kolom "Nama CCTV" / "Nama NVR" tidak ditemukan). Unduh template import CCTV dulu.', 'Not a CCTV import file ("Nama CCTV" / "Nama NVR" column not found). Download the CCTV import template first.'));
            $tmp = tempnam(sys_get_temp_dir(), 'cctvimp_');
            if (!$tmp || !move_uploaded_file($_FILES['excel_file']['tmp_name'], $tmp)) throw new Exception(cL('File tidak bisa disimpan sementara di server.', 'Could not store the file temporarily.'));
            $_SESSION['cctv_import'] = ['file' => $tmp, 'name' => basename((string)$_FILES['excel_file']['name']), 'time' => time()];
        } catch (Throwable $e) {
            $_SESSION['cctv_imp_msg'] = ['ok' => false, 'text' => cL('Import gagal: ', 'Import failed: ') . $e->getMessage()];
        }
        header('Location: cctv_import.php');
        exit;
    }
    $pending = $_SESSION['cctv_import'] ?? null;
    if ($act === 'save' && $pending && is_file($pending['file'])) {
        try {
            $plan = cctvImportPlan($db, IOFactory::load($pending['file']));
            $r = cctvImportApply($db, $plan);
            $text = cL("Import CCTV selesai: {$r['cam_new']} CCTV baru, {$r['cam_upd']} CCTV diperbarui, {$r['nvr_new']} NVR baru, {$r['nvr_upd']} NVR diperbarui",
                       "CCTV import done: {$r['cam_new']} new cameras, {$r['cam_upd']} updated, {$r['nvr_new']} new NVRs, {$r['nvr_upd']} updated");
            if ($r['skipped']) $text .= cL(", {$r['skipped']} baris error dilewati", ", {$r['skipped']} error rows skipped");
            $_SESSION['asset_bulk_msg'] = ['ok' => true, 'text' => $text . '.'];
            cctvImportDiscard();
            header('Location: ' . $backUrl);
            exit;
        } catch (Throwable $e) {
            $_SESSION['cctv_imp_msg'] = ['ok' => false, 'text' => cL('Gagal menyimpan, tidak ada data yang berubah: ', 'Save failed, nothing was changed: ') . $e->getMessage()];
            header('Location: cctv_import.php');
            exit;
        }
    }
    cctvImportDiscard();
    $_SESSION['cctv_imp_msg'] = ['ok' => false, 'text' => cL('Import dibatalkan.', 'Import cancelled.')];
    header('Location: cctv_import.php');
    exit;
}

$msg = $_SESSION['cctv_imp_msg'] ?? null;
unset($_SESSION['cctv_imp_msg']);
$pending = $_SESSION['cctv_import'] ?? null;
if ($pending && (time() - (int)$pending['time'] > 3600 || !is_file($pending['file']))) { cctvImportDiscard(); $pending = null; }

$plan = null;
if ($pending) {
    try { $plan = cctvImportPlan($db, IOFactory::load($pending['file'])); }
    catch (Throwable $e) { cctvImportDiscard(); $pending = null; $msg = ['ok' => false, 'text' => cL('File tidak bisa dibaca: ', 'Could not read file: ') . $e->getMessage()]; }
}
$count = function (array $rows, string $act) { return count(array_filter($rows, fn($r) => $r['action'] === $act)); };

$pageTitle = cL('Import CCTV dari Excel', 'Import CCTV from Excel');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
$badge = [
    'new'    => ['bg-green-100 text-green-700', cL('Baru', 'New')],
    'update' => ['bg-blue-100 text-blue-700', cL('Diperbarui', 'Update')],
    'error'  => ['bg-red-100 text-red-700', 'Error'],
];
?>
<div class="flex flex-wrap items-center justify-between gap-3 mb-4">
    <div>
        <h1 class="text-xl font-semibold text-slate-800"><?= $h($pageTitle) ?></h1>
        <p class="text-sm text-slate-500"><?= $h(cL('Input banyak kamera & NVR sekaligus. Data langsung masuk ke Asset dan menu CCTV (monitoring, checklist, laporan).', 'Add many cameras & NVRs at once. Data goes straight into Assets and the CCTV menu.')) ?></p>
    </div>
    <a href="<?= $h($backUrl) ?>" class="text-sm text-brand-700 hover:underline">&larr; <?= $h(cL('Kembali ke Asset CCTV', 'Back to CCTV assets')) ?></a>
</div>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<?php if (!$cats['cctv'] || !$cats['nvr']): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 bg-amber-50 border border-amber-200 text-amber-800">
        <?= $h(cL('Kategori aset belum lengkap: ', 'Missing asset categories: ') . implode(', ', array_filter([!$cats['cctv'] ? 'CCTV' : '', !$cats['nvr'] ? 'NVR' : '']))) ?>.
        <?= $h(cL('Tambahkan di menu Kategori Aset agar sheet tersebut bisa diimport.', 'Add them in Asset Categories so those sheets can be imported.')) ?>
    </div>
<?php endif; ?>

<?php if (!$plan): ?>
<div class="grid md:grid-cols-2 gap-4">
    <div class="bg-white rounded-xl shadow-sm p-5 text-sm space-y-3">
        <h2 class="font-semibold text-slate-800">1. <?= $h(cL('Unduh template', 'Download the template')) ?></h2>
        <p class="text-slate-600"><?= $h(cL('Template berisi sheet CCTV, sheet NVR, dan petunjuk. Kolom NVR & Status sudah berupa pilihan (dropdown).', 'The template has a CCTV sheet, an NVR sheet and a guide. NVR & Status columns are dropdowns.')) ?></p>
        <div class="flex flex-wrap gap-2">
            <a href="cctv_import.php?template=1" class="inline-flex items-center gap-2 rounded-lg bg-green-600 hover:bg-green-700 text-white px-4 py-2 font-medium"><?= icon('download') ?> <?= $h(cL('Template kosong', 'Blank template')) ?></a>
            <a href="cctv_import.php?template=1&data=1" class="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 px-4 py-2 font-medium"><?= icon('download') ?> <?= $h(cL('Template + data yang ada', 'Template + existing data')) ?></a>
        </div>
        <ul class="list-disc pl-5 text-xs text-slate-500 space-y-1">
            <li><?= $h(cL('CCTV: Nama CCTV & Lokasi wajib. Isi NVR + Channel (D1 = 1) agar status kamera terbaca dari NVR.', 'CCTV: name & location required. Fill NVR + channel (D1 = 1) so status is read from the NVR.')) ?></li>
            <li><?= $h(cL('NVR (opsional): Nama NVR wajib; isi IP, port, username & password agar bisa dipantau.', 'NVR (optional): name required; fill IP, port, username & password for monitoring.')) ?></li>
            <li><?= $h(cL('Nomor Aset kosong = dibuat otomatis. IP yang sudah ada = data lama diperbarui.', 'Empty asset number = auto-numbered. Existing IP = existing asset updated.')) ?></li>
            <li><?= $h(cL('"Template + data yang ada" untuk mengubah banyak kamera sekaligus: edit lalu import lagi.', '"Template + existing data" lets you edit many cameras at once and import again.')) ?></li>
        </ul>
    </div>
    <form method="post" enctype="multipart/form-data" class="bg-white rounded-xl shadow-sm p-5 text-sm space-y-3">
        <h2 class="font-semibold text-slate-800">2. <?= $h(cL('Upload file', 'Upload the file')) ?></h2>
        <p class="text-slate-600"><?= $h(cL('Setelah upload muncul preview. Data baru tersimpan setelah Anda klik Simpan.', 'A preview is shown after upload. Nothing is saved until you click Save.')) ?></p>
        <input type="file" name="excel_file" accept=".xlsx,.xls" required class="w-full border border-slate-300 rounded-lg px-3 py-2">
        <button type="submit" class="inline-flex items-center gap-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 font-medium"><?= icon('upload') ?> <?= $h(cL('Upload & cek', 'Upload & check')) ?></button>
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="upload">
    </form>
</div>
<?php else:
    $okRows = $count($plan['nvr'], 'new') + $count($plan['nvr'], 'update') + $count($plan['cctv'], 'new') + $count($plan['cctv'], 'update');
    $errRows = $count($plan['nvr'], 'error') + $count($plan['cctv'], 'error');
?>
<div class="bg-white rounded-xl shadow-sm p-4 mb-4 text-sm">
    <p class="text-slate-500 mb-3"><?= $h(cL('File', 'File')) ?>: <span class="font-medium text-slate-800"><?= $h($pending['name']) ?></span></p>
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        <?php foreach ([['CCTV', 'cctv', 'new'], ['CCTV', 'cctv', 'update'], ['CCTV', 'cctv', 'error'], ['NVR', 'nvr', 'new'], ['NVR', 'nvr', 'update'], ['NVR', 'nvr', 'error']] as [$lbl, $k, $a]): ?>
            <div class="rounded-lg border border-slate-200 px-3 py-2">
                <p class="text-xs text-slate-500"><?= $h($lbl . ' · ' . $badge[$a][1]) ?></p>
                <p class="text-xl font-semibold <?= $a === 'error' ? 'text-red-600' : ($a === 'new' ? 'text-green-700' : 'text-blue-700') ?>"><?= $count($plan[$k], $a) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    <?php foreach ($plan['notes'] as $n): ?><p class="mt-3 text-amber-700 bg-amber-50 rounded-lg px-3 py-2"><?= $h($n) ?></p><?php endforeach; ?>
    <?php if ($errRows): ?><p class="mt-3 text-red-700 bg-red-50 rounded-lg px-3 py-2"><?= $h(cL("$errRows baris error akan dilewati. Perbaiki di Excel lalu upload ulang, atau simpan baris yang benar saja.", "$errRows error rows will be skipped. Fix them in Excel and re-upload, or save the valid rows only.")) ?></p><?php endif; ?>
    <form method="post" class="mt-4 flex flex-wrap gap-2">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <?php if ($okRows): ?><button name="action" value="save" class="rounded-lg bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 font-medium"><?= $h(cL("Simpan $okRows baris", "Save $okRows rows")) ?></button><?php endif; ?>
        <button name="action" value="cancel" class="rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 px-5 py-2"><?= $h(cL('Batal / upload ulang', 'Cancel / re-upload')) ?></button>
    </form>
</div>

<?php foreach (['nvr' => 'NVR', 'cctv' => 'CCTV'] as $k => $label): if (!$plan[$k]) continue; ?>
<div class="bg-white rounded-xl shadow-sm mb-4 overflow-hidden">
    <h2 class="px-4 py-3 border-b font-semibold text-slate-800"><?= $h(cL('Sheet ', 'Sheet ') . $label) ?> <span class="text-sm font-normal text-slate-500">(<?= count($plan[$k]) ?> <?= $h(cL('baris', 'rows')) ?>)</span></h2>
    <div class="overflow-x-auto">
    <table class="w-full text-sm" data-rt="off">
        <thead class="bg-slate-50 text-slate-600 text-xs text-left">
            <tr>
                <th class="px-3 py-2"><?= $h(cL('Baris', 'Row')) ?></th>
                <th class="px-3 py-2"><?= $h(cL('Aksi', 'Action')) ?></th>
                <th class="px-3 py-2"><?= $h(cL('Nomor Aset', 'Asset No.')) ?></th>
                <th class="px-3 py-2"><?= $h(cL('Nama', 'Name')) ?></th>
                <th class="px-3 py-2"><?= $h(cL('Lokasi', 'Location')) ?></th>
                <th class="px-3 py-2">IP</th>
                <th class="px-3 py-2">Brand / Type</th>
                <th class="px-3 py-2"><?= $k === 'cctv' ? 'NVR / Ch' : 'Port / User' ?></th>
                <th class="px-3 py-2">Status</th>
                <th class="px-3 py-2"><?= $h(cL('Keterangan', 'Notes')) ?></th>
            </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
        <?php foreach ($plan[$k] as $r): $d = $r['d']; ?>
            <tr class="<?= $r['action'] === 'error' ? 'bg-red-50/50' : '' ?>">
                <td class="px-3 py-2 text-slate-400"><?= (int)$r['excel_row'] ?></td>
                <td class="px-3 py-2"><span class="text-xs rounded-full px-2 py-0.5 <?= $badge[$r['action']][0] ?>"><?= $h($badge[$r['action']][1]) ?></span></td>
                <td class="px-3 py-2 whitespace-nowrap"><?= $r['asset_number'] !== '' ? $h($r['asset_number']) : '<span class="text-slate-400">' . $h(cL('otomatis', 'auto')) . '</span>' ?></td>
                <td class="px-3 py-2 font-medium text-slate-800"><?= $h($d['name']) ?></td>
                <td class="px-3 py-2"><?= $h($d['location']) ?></td>
                <td class="px-3 py-2 whitespace-nowrap"><?= $h($d['ip']) ?></td>
                <td class="px-3 py-2"><?= $h(trim($d['brand'] . ' ' . $d['type'])) ?></td>
                <td class="px-3 py-2 whitespace-nowrap"><?= $k === 'cctv' ? $h(trim($d['nvr'] . ($d['channel'] !== '' ? ' · ch ' . $d['channel'] : ''))) : $h(trim(($d['port'] ?: '') . ($d['user'] !== '' ? ' · ' . $d['user'] : ''))) ?></td>
                <td class="px-3 py-2"><?= $d['status'] !== '' || $r['action'] !== 'update' ? $h(cctvImpStatus($d['status'])) : '<span class="text-slate-400">' . $h(cL('tetap', 'unchanged')) . '</span>' ?></td>
                <td class="px-3 py-2 text-xs">
                    <?php foreach ($r['errors'] as $e): ?><p class="text-red-700"><?= $h($e) ?></p><?php endforeach; ?>
                    <?php foreach ($r['warnings'] as $w): ?><p class="text-amber-700"><?= $h($w) ?></p><?php endforeach; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
