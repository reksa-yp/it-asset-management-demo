# Map CCTV (menu CCTV → Map CCTV, khusus admin)

Denah CCTV interaktif: unggah layout gedung, tempatkan titik kamera, lihat status dan hubungannya ke NVR dan switch PoE,
lalu cetak atau unduh sebagai PDF.

Tabel database dibuat otomatis saat menu pertama kali dibuka (`cctv_maps`, `cctv_map_points`, `cctv_map_cfg`, `cctv_map_nvr`).
Folder `assets/uploads/cctv_map/` dibuat otomatis; pastikan PHP bisa menulis ke sana dan sertakan di backup bersama folder uploads lainnya.
Pembaca PDF (`assets/js/pdfjs/`) berjalan lokal, jadi tidak butuh internet.

## Cara pakai
1. **Unggah layout** (PDF, JPG, atau PNG). Bisa banyak peta, misalnya Outdoor dan Lantai 2. PDF asli ikut disimpan.
2. Klik **Edit posisi** lalu tambah titik **CCTV** (dipilih dari data aset CCTV) atau **Switch PoE**. Geser titik, atur **arah** dan **sudut pandang**
   (sampai 360° untuk kamera fisheye), atau hapus. Ukuran titik diatur slider **Titik** di toolbar.
3. **Warna otomatis**: tiap NVR punya warna sendiri (diatur admin di kotak Keterangan saat mode Edit). **CCTV baru** berwarna khusus sampai
   N hari sejak tanggal pasang (bawaan 7 hari, bisa diubah), lalu otomatis ikut warna NVR-nya. Warna khusus per titik tetap bisa dipilih.
4. Arahkan kursor ke titik untuk melihat nama, IP, tanggal pasang, NVR, switch dan port, serta status. Klik titik untuk panel detail.
5. Sambungan kamera ke **switch PoE + port eth** tersimpan ke topologi menu **Jaringan**, jadi topologi ikut berubah. Syarat: aset CCTV punya IP.
6. **Keterangan** (jumlah per NVR, baru, dummy, total) dihitung otomatis dari titik di peta dan ikut tercetak.
7. **Cetak langsung** atau **unduh PDF** kertas A4/A3 (orientasi mengikuti layout), serta **unduh PNG** (gambar peta saja).
   Cetak/PDF memakai kop surat, judul otomatis "MAP CCTV - <nama peta>", tanggal update, dan ringkasan jumlah CCTV per NVR.
   Halaman berikutnya berisi **daftar CCTV per NVR** (No, Nama, IP, Channel, Switch/Port, Tgl pasang, Status), diurutkan sesuai nomor di peta.

## Titik rencana
Di mode Edit klik **Titik Rencana** lalu klik di peta untuk menandai calon lokasi pemasangan (lingkaran ungu putus-putus R1, R2, …).
Titik rencana punya nama, catatan, arah, sudut dan jarak pandang, tetapi hanya penanda: tidak dihitung sebagai CCTV dan tidak terhubung ke
aset, NVR, atau switch. Centang **Rencana** di toolbar untuk menampilkan atau menyembunyikannya; yang tampil ikut dicetak di halaman terakhir.

## Impor titik dari PDF
Di mode Edit: **Impor titik dari PDF**.
- Pilih PDF layout yang sama dengan peta. Nomor di PDF dicocokkan dengan nomor urut CCTV (sama dengan List View: NVR 1, NVR 2, lalu tanpa NVR).
- Titik menempel ke **ikon kamera** dan arahnya dibaca dari panah di PDF bila ada.
- Pratinjau menampilkan jumlah titik yang akan dibuat, nomor yang tidak ditemukan (tambah manual), dan nomor ganda (ditandai di catatan titik: perlu dicek).
- Titik yang sudah ada di peta dilewati.

## Hapus peta
Mode Edit → tombol **Peta ini** → **Hapus peta**.

File: `cctv_map.php`, `cctv_map_api.php`, `includes/cctv_map.php`, `includes/cctv_nav.php` (tab Map CCTV).
