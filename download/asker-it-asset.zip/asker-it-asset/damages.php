<?php
/**
 * Menu Aset Rusak (khusus admin): daftar aset rusak dengan tanggal rusak, kerusakan, lokasi penyimpanan,
 * status perbaikan (Rusak / Dalam Perbaikan / Selesai Diperbaiki / Disposal), export Excel & print.
 * Buka langsung dengan aset terpilih: damages.php?asset_id=123 (dari tombol "Tandai Rusak" di menu Aset).
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/damage.php';
require_once __DIR__ . '/includes/categories.php';

$db = getDB();
ensureDamageTable($db);   // hanya membuat tabel BARU asset_damages jika belum ada

$f       = damageFilters();
$damages = getDamages($db, $f);
$counts  = getDamageCounts($db);
$qs      = damageFilterQuery($f);
$categories = array_column(getAssetCategories($db), 'name');
$storageOptions = getDamageStorageOptions($db);

// Aset yang bisa ditandai rusak (belum punya catatan rusak yang masih terbuka) + penggunanya.
$openMap   = getOpenDamageMap($db);
$assetRows = $db->query("SELECT id, asset_number, category, device_name, department, location, status FROM assets ORDER BY asset_number")->fetchAll();
$ownersMap = getAssetOwnersMap($db, array_column($assetRows, 'id'));
$assetData = [];
foreach ($assetRows as $a) {
    if (isset($openMap[(int)$a['id']])) continue;
    $assetData[] = [
        'id' => (int)$a['id'], 'no' => $a['asset_number'], 'cat' => $a['category'], 'name' => (string)$a['device_name'],
        'dept' => (string)$a['department'], 'loc' => (string)$a['location'], 'status' => $a['status'],
        'owners' => array_column($ownersMap[$a['id']] ?? [], 'full_name'),
    ];
}

$msg = $_SESSION['damage_msg'] ?? null;
unset($_SESSION['damage_msg']);
$openAssetId = (int)($_GET['asset_id'] ?? 0);
$openAssetBlocked = $openAssetId && isset($openMap[$openAssetId]);

$pageTitle = t('page_title_damages');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

$h = fn($v) => htmlspecialchars((string)$v);
$fmtDate = fn($d) => date('d M Y', strtotime($d));
$statusLabels = ['Digunakan' => t('status_used'), 'Stok' => t('status_stock'), 'Tidak Digunakan' => t('status_unused')];
$stateUrl = function (string $state) use ($f) { $g = $f; $g['state'] = $state; return 'damages.php?' . damageFilterQuery($g); };
?>

<div class="flex flex-wrap items-center justify-between gap-3 mb-4">
    <p class="text-sm text-slate-500 max-w-xl"><?= t('dmg_intro') ?></p>
    <div class="flex flex-wrap gap-2">
        <button type="button" onclick="openDamageModal()" class="inline-flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('alert') ?> <?= t('dmg_btn_new') ?>
        </button>
        <a href="damage_export_excel.php?<?= $h($qs) ?>" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('sheet') ?> <?= t('btn_export_excel') ?>
        </a>
        <a href="damage_print.php?<?= $h($qs) ?>" target="_blank" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('printer') ?> <?= t('dmg_btn_print') ?>
        </a>
    </div>
</div>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>
<?php if ($openAssetBlocked): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 bg-amber-50 text-amber-800"><?= $h(t('dmg_err_already_open', $openMap[$openAssetId]['asset_number'])) ?></div>
<?php endif; ?>

<!-- Kartu ringkasan per status (klik untuk menyaring) -->
<div class="grid grid-cols-2 xl:grid-cols-4 gap-3 mb-4">
    <?php foreach ([
        ['broken', 'alert', 'bg-red-50 text-red-700'],
        ['repair', 'wrench', 'bg-amber-50 text-amber-700'],
        ['fixed', 'check-circle', 'bg-green-50 text-green-700'],
        ['disposed', 'trash', 'bg-slate-100 text-slate-600'],
    ] as [$st, $ic, $tone]): ?>
        <a href="<?= $h($stateUrl($st)) ?>" class="bg-white rounded-xl shadow-sm p-4 flex items-start gap-3 border-2 <?= $f['state'] === $st ? 'border-blue-400' : 'border-transparent hover:border-slate-200' ?>">
            <span class="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 <?= $tone ?>"><?= icon($ic, 'w-5 h-5') ?></span>
            <div><p class="text-xs text-slate-500"><?= $h(damageStateLabel($st)) ?></p><p class="text-2xl font-semibold text-slate-800 leading-tight tabular-nums"><?= $counts[$st] ?></p></div>
        </a>
    <?php endforeach; ?>
</div>

<!-- Filter -->
<form method="get" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('th_status') ?></span>
        <select name="state" class="border border-slate-300 rounded-lg px-2 py-1.5 w-full sm:w-auto sm:min-w-[170px]">
            <option value="open" <?= $f['state'] === 'open' ? 'selected' : '' ?>><?= t('dmg_filter_open') ?></option>
            <?php foreach (array_keys(DAMAGE_STATES) as $st): ?><option value="<?= $st ?>" <?= $f['state'] === $st ? 'selected' : '' ?>><?= $h(damageStateLabel($st)) ?></option><?php endforeach; ?>
            <option value="all" <?= $f['state'] === 'all' ? 'selected' : '' ?>><?= t('stock_all') ?></option>
        </select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('mut_col_category') ?></span>
        <select name="cat" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[140px]">
            <option value=""><?= t('stock_all') ?></option>
            <?php foreach ($categories as $c): ?><option value="<?= $h($c) ?>" <?= $f['cat'] === $c ? 'selected' : '' ?>><?= $h($c) ?></option><?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('dmg_filter_from') ?></span>
        <input type="date" name="from" value="<?= $h($f['from']) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('stock_filter_to') ?></span>
        <input type="date" name="to" value="<?= $h($f['to']) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <label class="flex flex-col gap-1 flex-1 min-w-[180px]"><span class="text-xs text-slate-500"><?= t('stock_search') ?></span>
        <input type="search" name="q" value="<?= $h($f['q']) ?>" placeholder="<?= $h(t('dmg_search_ph')) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= t('stock_apply') ?></button>
    <a href="damages.php" class="text-slate-500 hover:text-slate-700 px-2 py-1.5"><?= t('btn_reset_filter') ?></a>
</form>

<!-- Daftar aset rusak -->
<div class="bg-white rounded-xl shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-left text-xs text-slate-500">
        <tr>
            <th class="py-2 px-3 font-medium"><?= t('th_asset_no') ?></th>
            <th class="py-2 px-3 font-medium"><?= t('dmg_col_asset') ?></th>
            <th class="py-2 px-3 font-medium"><?= t('dmg_col_date') ?></th>
            <th class="py-2 px-3 font-medium"><?= t('dmg_col_issue') ?></th>
            <th class="py-2 px-3 font-medium"><?= t('dmg_col_storage') ?></th>
            <th class="py-2 px-3 font-medium"><?= t('dmg_col_last_user') ?></th>
            <th class="py-2 px-3 font-medium"><?= t('th_status') ?></th>
            <th class="py-2 px-3 font-medium text-right"><?= t('dmg_col_days') ?></th>
            <th class="py-2 px-3 font-medium"><?= t('th_action') ?></th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($damages as $d):
            $no = $d['current_number'] ?: $d['asset_number'];
            $payload = ['id' => (int)$d['id'], 'no' => $no, 'cat' => $d['current_category'] ?: $d['asset_category'], 'name' => $d['current_name'] ?: $d['asset_name'],
                        'damage_date' => $d['damage_date'], 'issue' => $d['issue'], 'storage' => $d['storage_location'], 'state' => $d['state'], 'note' => (string)$d['note']]; ?>
            <tr class="border-t hover:bg-slate-50 align-top">
                <td class="py-2 px-3 whitespace-nowrap">
                    <?php if ($d['current_number']): ?>
                        <a href="assets.php?q=<?= urlencode($no) ?>" class="font-medium text-blue-600 hover:underline"><?= $h($no) ?></a>
                        <div class="text-[11px] text-slate-400"><?= $h($statusLabels[$d['asset_status']] ?? $d['asset_status']) ?></div>
                    <?php else: ?>
                        <span class="font-medium text-slate-500"><?= $h($no) ?></span><div class="text-[11px] text-red-500"><?= t('dmg_asset_deleted') ?></div>
                    <?php endif; ?>
                </td>
                <td class="py-2 px-3 min-w-[9rem]"><?= $h($d['current_category'] ?: $d['asset_category']) ?><div class="text-xs text-slate-500"><?= $h(($d['current_name'] ?: $d['asset_name']) ?: '') ?></div></td>
                <td class="py-2 px-3 whitespace-nowrap tabular-nums"><?= $fmtDate($d['damage_date']) ?></td>
                <td class="py-2 px-3 min-w-[14rem]"><?= $h($d['issue']) ?><?php if ($d['note']): ?><div class="text-xs text-slate-500 mt-0.5"><?= nl2br($h($d['note'])) ?></div><?php endif; ?></td>
                <td class="py-2 px-3 whitespace-nowrap"><?= $h($d['storage_location']) ?></td>
                <td class="py-2 px-3 min-w-[9rem]"><?= $h($d['last_user_names'] ?: t('dash')) ?><?php if ($d['last_department']): ?><div class="text-xs text-slate-400"><?= $h($d['last_department']) ?></div><?php endif; ?></td>
                <td class="py-2 px-3 whitespace-nowrap">
                    <span class="px-2 py-0.5 rounded-full text-xs font-semibold <?= damageStateBadge($d['state']) ?>"><?= $h(damageStateLabel($d['state'])) ?></span>
                    <?php if ($d['closed_date']): ?><div class="text-[11px] text-slate-400 mt-0.5"><?= $fmtDate($d['closed_date']) ?></div><?php endif; ?>
                </td>
                <td class="py-2 px-3 text-right tabular-nums whitespace-nowrap text-slate-600"><?= t('dmg_days', damageDays($d)) ?></td>
                <td class="py-2 px-3 whitespace-nowrap">
                    <button type="button" class="inline-flex items-center gap-1 rounded-lg border border-slate-300 hover:bg-slate-50 px-2.5 py-1 text-xs font-medium"
                            onclick='openDamageEdit(<?= json_encode($payload, JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP) ?>)'><?= icon('pencil', 'w-3.5 h-3.5') ?> <?= t('dmg_btn_update') ?></button>
                    <form method="post" action="damage_save.php" class="inline" onsubmit="return confirm(<?= $h(json_encode(t('dmg_confirm_delete', $no))) ?>)">
                        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
                        <input type="hidden" name="back" value="<?= $h($qs) ?>">
                        <button type="submit" class="p-1.5 rounded-lg text-slate-400 hover:bg-red-50 hover:text-red-600" title="<?= $h(t('link_delete')) ?>"><?= icon('trash') ?></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$damages): ?>
            <tr><td colspan="9" class="p-8 text-center text-slate-400"><?= t('dmg_empty') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- ===== Modal tandai rusak / update ===== -->
<div id="damageModal" class="hidden fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
    <form method="post" action="damage_save.php" id="damageForm" class="bg-white rounded-xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto text-sm">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" id="dfAction" value="create">
        <input type="hidden" name="id" id="dfId" value="">
        <input type="hidden" name="asset_id" id="dfAssetId" value="">
        <input type="hidden" name="back" value="<?= $h($qs) ?>">
        <div class="flex items-center justify-between px-5 py-4 border-b">
            <h3 class="font-semibold text-slate-800" id="dfTitle"><?= t('dmg_modal_new') ?></h3>
            <button type="button" data-modal-close onclick="closeDamageModal()" class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button>
        </div>
        <div class="px-5 py-4 space-y-3">
            <!-- Pilih aset (hanya saat tandai rusak baru) -->
            <div id="dfPickWrap" class="space-y-1">
                <span class="font-medium text-slate-700"><?= t('dmg_pick_asset') ?> <span class="text-red-500">*</span></span>
                <input type="search" id="dfAssetSearch" placeholder="<?= $h(t('mut_asset_search_ph')) ?>" autocomplete="off" class="w-full border border-slate-300 rounded-lg px-3 py-2" oninput="filterDamageAssets()">
                <select id="dfAssetSelect" size="5" class="w-full border border-slate-300 rounded-lg px-2 py-1 text-sm" onchange="pickDamageAsset(this.value)"></select>
                <p id="dfAssetCount" class="text-xs text-slate-400"></p>
            </div>
            <div id="dfAssetInfo" class="hidden rounded-lg bg-red-50 p-3">
                <p class="font-medium text-red-800" id="dfAssetNo"></p>
                <p class="text-red-700/80 text-xs" id="dfAssetMeta"></p>
            </div>
            <div class="grid sm:grid-cols-2 gap-3">
                <label class="flex flex-col gap-1"><span class="font-medium text-slate-700"><?= t('dmg_col_date') ?> <span class="text-red-500">*</span></span>
                    <input type="date" name="damage_date" id="dfDate" required max="<?= date('Y-m-d') ?>" class="border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="flex flex-col gap-1"><span class="font-medium text-slate-700"><?= t('dmg_col_storage') ?> <span class="text-red-500">*</span></span>
                    <input name="storage_location" id="dfStorage" required maxlength="100" list="dfStorageList" autocomplete="off" class="border border-slate-300 rounded-lg px-3 py-2" placeholder="<?= $h(t('dmg_storage_ph')) ?>">
                    <datalist id="dfStorageList"><?php foreach ($storageOptions as $so): ?><option value="<?= $h($so) ?>"></option><?php endforeach; ?></datalist></label>
                <label class="flex flex-col gap-1 sm:col-span-2"><span class="font-medium text-slate-700"><?= t('dmg_col_issue') ?> <span class="text-red-500">*</span></span>
                    <textarea name="issue" id="dfIssue" required maxlength="255" rows="2" class="border border-slate-300 rounded-lg px-3 py-2" placeholder="<?= $h(t('dmg_issue_ph')) ?>"></textarea></label>
                <label class="flex flex-col gap-1 sm:col-span-2 hidden" id="dfStateWrap"><span class="font-medium text-slate-700"><?= t('dmg_state_label') ?></span>
                    <select name="state" id="dfState" class="border border-slate-300 rounded-lg px-3 py-2" onchange="updateStateHint()">
                        <?php foreach (array_keys(DAMAGE_STATES) as $st): ?><option value="<?= $st ?>"><?= $h(damageStateLabel($st)) ?></option><?php endforeach; ?>
                    </select>
                    <span id="dfStateHint" class="text-xs text-slate-500"></span></label>
                <label class="flex flex-col gap-1 sm:col-span-2"><span class="font-medium text-slate-700"><?= t('stock_note') ?> <span class="text-slate-400 font-normal">(<?= t('stock_optional') ?>)</span></span>
                    <textarea name="note" id="dfNote" rows="2" maxlength="2000" class="border border-slate-300 rounded-lg px-3 py-2" placeholder="<?= $h(t('dmg_note_ph')) ?>"></textarea></label>
            </div>
            <label id="dfReleaseWrap" class="hidden flex items-start gap-2 cursor-pointer">
                <input type="checkbox" name="release_owner" value="1" id="dfRelease" checked class="mt-0.5 h-4 w-4 accent-red-600">
                <span><span id="dfReleaseLabel"></span><br><span class="text-xs text-slate-500"><?= t('dmg_release_hint') ?></span></span>
            </label>
            <p id="dfNewHint" class="text-xs text-slate-500"><?= t('dmg_new_hint') ?></p>
            <p id="dfErr" class="hidden bg-red-50 text-red-700 rounded-lg px-3 py-2"></p>
        </div>
        <div class="px-5 py-3 border-t flex justify-end gap-2">
            <button type="button" onclick="closeDamageModal()" class="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"><?= t('btn_cancel') ?></button>
            <button type="submit" class="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-medium"><?= t('btn_save') ?></button>
        </div>
    </form>
</div>

<script>
const DMG_ASSETS = <?= json_encode($assetData, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const DMG_STATUS = <?= json_encode($statusLabels, JSON_UNESCAPED_UNICODE) ?>;
const DMG_T = <?= json_encode([
    'new' => t('dmg_modal_new'), 'edit' => t('dmg_modal_edit'), 'count' => tRaw('dmg_asset_count'),
    'release' => tRaw('dmg_release_label'), 'err_asset' => t('dmg_err_asset'),
    'hint_open' => t('dmg_hint_open'), 'hint_fixed' => t('dmg_hint_fixed'), 'hint_disposed' => t('dmg_hint_disposed'),
    'used_by' => tRaw('dmg_used_by'),
], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const TODAY = '<?= date('Y-m-d') ?>';
let dmgPicked = null;
const $d = id => document.getElementById(id);

function filterDamageAssets() {
    const words = $d('dfAssetSearch').value.trim().toLowerCase().split(/\s+/).filter(Boolean);
    const list = DMG_ASSETS.filter(a => {
        const hay = (a.no + ' ' + a.cat + ' ' + a.name + ' ' + a.dept + ' ' + a.owners.join(' ')).toLowerCase();
        return words.every(w => hay.includes(w));
    });
    const sel = $d('dfAssetSelect');
    sel.innerHTML = '';
    list.slice(0, 300).forEach(a => sel.appendChild(new Option(
        a.no + ' — ' + a.cat + (a.name ? ' · ' + a.name : '') + (a.owners.length ? ' · ' + a.owners.join(', ') : ''), a.id)));
    $d('dfAssetCount').textContent = DMG_T.count.replace('%d', list.length);
    if (list.length === 1) { sel.value = list[0].id; pickDamageAsset(list[0].id); }
}
function pickDamageAsset(id) {
    dmgPicked = DMG_ASSETS.find(a => a.id == id) || null;
    $d('dfAssetId').value = dmgPicked ? dmgPicked.id : '';
    $d('dfAssetInfo').classList.toggle('hidden', !dmgPicked);
    if (!dmgPicked) { $d('dfReleaseWrap').classList.add('hidden'); return; }
    $d('dfAssetNo').textContent = dmgPicked.no;
    $d('dfAssetMeta').textContent = [dmgPicked.cat, dmgPicked.name, DMG_STATUS[dmgPicked.status] || dmgPicked.status,
        dmgPicked.owners.length ? DMG_T.used_by.replace('%s', dmgPicked.owners.join(', ')) : ''].filter(Boolean).join(' · ');
    const hasOwner = dmgPicked.owners.length > 0;
    $d('dfReleaseWrap').classList.toggle('hidden', !hasOwner);
    $d('dfReleaseWrap').classList.toggle('flex', hasOwner);
    $d('dfReleaseLabel').textContent = DMG_T.release.replace('%s', dmgPicked.owners.join(', '));
}
function resetDamageForm() {
    $d('dfErr').classList.add('hidden');
    $d('dfDate').value = TODAY; $d('dfIssue').value = ''; $d('dfStorage').value = ''; $d('dfNote').value = '';
    $d('dfRelease').checked = true; dmgPicked = null; $d('dfAssetId').value = '';
}
function openDamageModal(assetId) {
    resetDamageForm();
    $d('dfAction').value = 'create'; $d('dfId').value = '';
    $d('dfTitle').textContent = DMG_T.new;
    $d('dfPickWrap').classList.remove('hidden');
    $d('dfStateWrap').classList.add('hidden');
    $d('dfNewHint').classList.remove('hidden');
    $d('dfAssetSearch').value = '';
    const pre = assetId ? DMG_ASSETS.find(a => a.id == assetId) : null;
    if (pre) $d('dfAssetSearch').value = pre.no;
    filterDamageAssets();
    if (pre) { $d('dfAssetSelect').value = pre.id; pickDamageAsset(pre.id); } else pickDamageAsset('');
    $d('damageModal').classList.remove('hidden');
    setTimeout(() => (pre ? $d('dfIssue') : $d('dfAssetSearch')).focus(), 50);
}
function openDamageEdit(d) {
    resetDamageForm();
    $d('dfAction').value = 'update'; $d('dfId').value = d.id;
    $d('dfTitle').textContent = DMG_T.edit;
    $d('dfPickWrap').classList.add('hidden');
    $d('dfReleaseWrap').classList.add('hidden'); $d('dfReleaseWrap').classList.remove('flex');
    $d('dfNewHint').classList.add('hidden');
    $d('dfStateWrap').classList.remove('hidden');
    $d('dfAssetInfo').classList.remove('hidden');
    $d('dfAssetNo').textContent = d.no;
    $d('dfAssetMeta').textContent = [d.cat, d.name].filter(Boolean).join(' · ');
    $d('dfDate').value = d.damage_date; $d('dfIssue').value = d.issue; $d('dfStorage').value = d.storage; $d('dfNote').value = d.note;
    $d('dfState').value = d.state;
    updateStateHint();
    $d('damageModal').classList.remove('hidden');
}
function updateStateHint() {
    const s = $d('dfState').value;
    $d('dfStateHint').textContent = s === 'fixed' ? DMG_T.hint_fixed : s === 'disposed' ? DMG_T.hint_disposed : DMG_T.hint_open;
}
function closeDamageModal() { $d('damageModal').classList.add('hidden'); }
$d('damageForm').addEventListener('submit', e => {
    if ($d('dfAction').value === 'create' && !$d('dfAssetId').value) {
        e.preventDefault();
        $d('dfErr').textContent = DMG_T.err_asset; $d('dfErr').classList.remove('hidden');
    }
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeDamageModal(); });
<?php if ($openAssetId && !$openAssetBlocked): ?>
openDamageModal(<?= $openAssetId ?>);
<?php endif; ?>
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
