<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/upgrade_alert.php';
require_once __DIR__ . '/includes/stock.php';

$db = getDB();

$totalAsset   = $db->query("SELECT COUNT(*) c FROM assets")->fetch()['c'];
$totalTicketQ = $db->query("SELECT COUNT(*) c FROM tickets WHERE status IN ('Menunggu','Proses')")->fetch()['c'];
$fixedToday    = getTicketsFixedToday($db);     // lihat includes/ticket_cancel.php
$totalTodayFix = count($fixedToday);

// Angka kartu diperbarui otomatis tanpa memuat ulang halaman (dashboard.php?stats=1, dipanggil berkala
// oleh skrip di bawah), jadi "hari ini" ikut berganti sendiri saat tanggal berganti.
if (isset($_GET['stats'])) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode(['ok' => true, 'total_asset' => (int)$totalAsset, 'ticket_queue' => (int)$totalTicketQ, 'fixed_today' => (int)$totalTodayFix]);
    exit;
}

// Rincian jumlah aset per jenis, ditampilkan saat kartu "Jumlah Aset Keseluruhan" diklik.
$assetBreakdown = $db->query("
    SELECT category, COUNT(*) AS total FROM assets GROUP BY category ORDER BY total DESC
")->fetchAll();

// Susun data untuk grafik lingkaran (donut chart) memakai CSS conic-gradient murni,
// jadi tidak butuh library JS eksternal / koneksi internet.
$breakdownTotal = array_sum(array_column($assetBreakdown, 'total'));
$chartColors = ['#3b82f6','#f59e0b','#22c55e','#a855f7','#ef4444','#06b6d4','#eab308','#ec4899','#64748b','#14b8a6'];
$cursorPct = 0;
$gradientParts = [];
foreach ($assetBreakdown as $i => &$cb) {
    $cb['color'] = $chartColors[$i % count($chartColors)];
    $cb['pct'] = $breakdownTotal > 0 ? round($cb['total'] / $breakdownTotal * 100, 1) : 0;
    $start = $cursorPct;
    $end   = $breakdownTotal > 0 ? $cursorPct + ($cb['total'] / $breakdownTotal * 100) : 0;
    $gradientParts[] = "{$cb['color']} {$start}% {$end}%";
    $cursorPct = $end;
}
unset($cb);
$donutGradient = $gradientParts ? implode(', ', $gradientParts) : '#e2e8f0 0% 100%';

// ===== Notifikasi "Aset Perlu Di-Upgrade" =====
// Diambil dari histori Ticketing IT: setiap tiket (Rincian Masalah) atau hasil
// pengecekan/kesimpulan teknisi yang mengandung kata kunci "harus upgrade"
// dianggap menandai aset terkait perlu di-upgrade. Hanya membaca data yang
// sudah ada, tidak butuh kolom/tabel baru. Query-nya ada di includes/upgrade_alert.php
// (dipakai bersama oleh upgrade_list_print.php & upgrade_list_pdf.php).
$upgradeAssets = getUpgradeAssets($db);

// Stok barang yang menipis / habis (hanya membaca tabel stok baru, jika sudah ada).
$lowStock = getLowStockCategories($db);

// Data tambahan: 5 tiket terbaru
$recentTickets = $db->query("
    SELECT t.id, t.ticket_number, t.problem_detail, t.status, t.created_at, u.full_name AS pelapor
    FROM tickets t JOIN users u ON u.id = t.reported_by
    ORDER BY t.created_at DESC LIMIT 5
")->fetchAll();
$recentTickets = applyTicketCancellations($db, $recentTickets);

$pageTitle = t('dashboard_title');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

$ticketStatusLabel = [
    'Menunggu' => t('ticket_status_waiting'),
    'Proses'   => t('ticket_status_process'),
    'Selesai'  => t('ticket_status_done'),
];

$upgradeMarked = $_GET['upgrade_marked'] ?? '';
?>

<?php if ($upgradeMarked === '1'): ?>
    <div class="mb-4 rounded-lg px-4 py-3 text-sm bg-green-50 text-green-700"><?= t('upgrade_marked_done_success') ?></div>
<?php elseif ($upgradeMarked === 'need_migration'): ?>
    <div class="mb-4 rounded-lg px-4 py-3 text-sm bg-amber-50 text-amber-700">
        <?= t('upgrade_marked_done_need_migration') ?>
    </div>
<?php endif; ?>

<div class="mb-4">
    <button type="button" onclick="startScanQr()"
            class="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg px-5 py-2.5 text-sm font-medium shadow-sm">
        <?= icon('tag', 'w-4 h-4') ?> <?= t('scan_btn') ?>
    </button>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
    <button type="button" onclick="toggleAssetBreakdown()"
            class="text-left bg-white rounded-xl shadow-sm p-5 border-l-4 border-blue-500 hover:bg-slate-50 transition cursor-pointer">
        <div class="flex items-center justify-between gap-2">
            <p class="text-sm text-slate-500"><?= t('stat_total_assets') ?></p>
            <svg id="assetBreakdownChevron" class="w-4 h-4 text-slate-400 transition-transform shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M6 9l6 6 6-6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <p class="text-3xl font-bold text-slate-800 mt-1" id="statTotalAsset"><?= (int)$totalAsset ?></p>
    </button>
    <div class="bg-white rounded-xl shadow-sm p-5 border-l-4 border-amber-500">
        <p class="text-sm text-slate-500"><?= t('stat_ticket_queue') ?></p>
        <p class="text-3xl font-bold text-slate-800 mt-1" id="statTicketQueue"><?= (int)$totalTicketQ ?></p>
    </div>
    <button type="button" onclick="document.getElementById('fixedTodayBox').classList.toggle('hidden')"
            class="text-left bg-white rounded-xl shadow-sm p-5 border-l-4 border-green-500 hover:bg-slate-50 transition cursor-pointer">
        <p class="text-sm text-slate-500"><?= t('stat_fixed_today') ?> <span class="text-xs text-slate-400">(<?= date('d M Y') ?>)</span></p>
        <p class="text-3xl font-bold text-slate-800 mt-1" id="statFixedToday"><?= (int)$totalTodayFix ?></p>
        <p class="text-xs text-slate-400 mt-1"><?= t('stat_fixed_today_hint') ?></p>
    </button>
</div>

<!-- Rincian "Perbaikan Selesai Hari Ini": tiket mana saja yang dihitung, kapan dibuat & kapan selesai -->
<div id="fixedTodayBox" class="hidden bg-white rounded-xl shadow-sm mb-4 overflow-hidden">
    <div class="px-5 py-3 border-b">
        <h2 class="font-semibold text-slate-800"><?= t('fixed_today_title') ?></h2>
        <p class="text-xs text-slate-400"><?= t('fixed_today_note') ?></p>
    </div>
    <?php if (!$fixedToday): ?>
        <p class="p-6 text-center text-sm text-slate-400"><?= t('fixed_today_none') ?></p>
    <?php else: ?>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-slate-50 text-left text-xs text-slate-500">
            <tr>
                <th class="py-2 px-4"><?= t('th_ticket_no') ?></th>
                <th class="py-2 px-4"><?= t('th_reporter') ?></th>
                <th class="py-2 px-4"><?= t('th_problem') ?></th>
                <th class="py-2 px-4" data-priority="2"><?= t('fixed_today_created') ?></th>
                <th class="py-2 px-4" data-priority="1"><?= t('fixed_today_done') ?></th>
                <th class="py-2 px-4"><?= t('xls_hdr_handled_by') ?></th>
            </tr>
            </thead>
            <tbody class="divide-y">
            <?php foreach ($fixedToday as $ft): ?>
                <tr>
                    <td class="py-2 px-4 font-medium whitespace-nowrap"><?= htmlspecialchars($ft['ticket_number']) ?></td>
                    <td class="py-2 px-4"><?= htmlspecialchars($ft['pelapor']) ?></td>
                    <td class="py-2 px-4"><?= htmlspecialchars(mb_strimwidth((string)$ft['problem_detail'], 0, 80, '…')) ?></td>
                    <td class="py-2 px-4 whitespace-nowrap text-slate-500"><?= date('d M Y H:i', strtotime($ft['created_at'])) ?></td>
                    <td class="py-2 px-4 whitespace-nowrap font-medium text-green-700"><?= date('d M Y H:i', strtotime($ft['done_at'])) ?></td>
                    <td class="py-2 px-4"><?= htmlspecialchars($ft['handler'] ?: t('dash')) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php if ($lowStock): ?>
<a href="stock.php" class="flex flex-wrap items-center gap-3 bg-amber-50 border border-amber-200 rounded-xl px-5 py-3 mb-4 hover:bg-amber-100/60 transition">
    <span class="w-9 h-9 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center shrink-0"><?= icon('package', 'w-5 h-5') ?></span>
    <div class="flex-1 min-w-0">
        <p class="font-semibold text-amber-800"><?= sprintf(t('stock_dash_low_title'), count($lowStock)) ?></p>
        <p class="text-xs text-amber-700 truncate">
            <?= htmlspecialchars(implode(', ', array_map(fn($s) => $s['name'] . ' (' . (int)$s['stock'] . ' ' . $s['unit'] . ')', $lowStock))) ?>
        </p>
    </div>
    <span class="text-xs font-medium text-amber-700"><?= t('stock_dash_open') ?> &rarr;</span>
</a>
<?php endif; ?>

<div id="assetBreakdownPanel" class="hidden bg-white rounded-xl shadow-sm p-5 mb-6">
    <h3 class="font-semibold text-slate-700 mb-3"><?= t('breakdown_by_type') ?></h3>
    <?php if ($assetBreakdown): ?>
    <div class="flex flex-col sm:flex-row items-center sm:items-start gap-6">
        <!-- Grafik lingkaran (donut), dibuat murni pakai CSS conic-gradient -->
        <div class="relative shrink-0 mx-auto sm:mx-0" style="width:170px;height:170px;">
            <div class="rounded-full w-full h-full" style="background:conic-gradient(<?= $donutGradient ?>);"></div>
            <div class="absolute inset-0 m-auto rounded-full bg-white flex flex-col items-center justify-center" style="width:100px;height:100px;">
                <span class="text-2xl font-bold text-slate-800"><?= (int)$breakdownTotal ?></span>
                <span class="text-[11px] text-slate-400"><?= t('stat_total_assets') ?></span>
            </div>
        </div>

        <!-- Legenda + jumlah per jenis -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full">
            <?php foreach ($assetBreakdown as $cb): ?>
                <div class="flex items-center gap-2 rounded-lg border border-slate-100 bg-slate-50 px-3 py-2">
                    <span class="w-3 h-3 rounded-full shrink-0" style="background:<?= htmlspecialchars($cb['color']) ?>;"></span>
                    <span class="text-sm text-slate-600 truncate flex-1"><?= htmlspecialchars($cb['category']) ?></span>
                    <span class="text-sm font-semibold text-slate-800"><?= (int)$cb['total'] ?></span>
                    <span class="text-xs text-slate-400 w-12 text-right"><?= $cb['pct'] ?>%</span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php else: ?>
        <p class="text-sm text-slate-400"><?= t('no_assets_yet') ?></p>
    <?php endif; ?>
</div>

<script>
function toggleAssetBreakdown() {
    document.getElementById('assetBreakdownPanel').classList.toggle('hidden');
    document.getElementById('assetBreakdownChevron').classList.toggle('rotate-180');
}
function toggleUpgradeAlert() {
    document.getElementById('upgradeAlertPanel').classList.toggle('hidden');
    document.getElementById('upgradeAlertChevron').classList.toggle('rotate-180');
}
</script>

<?php if ($upgradeAssets): ?>
<div class="bg-red-50 border border-red-200 rounded-xl shadow-sm mb-6 overflow-hidden">
    <button type="button" onclick="toggleUpgradeAlert()" class="w-full text-left px-5 py-4 flex items-center justify-between gap-3 hover:bg-red-100/50 transition">
        <div class="flex items-center gap-3">
            <span class="w-9 h-9 rounded-full bg-red-100 text-red-600 flex items-center justify-center shrink-0"><?= icon('alert', 'w-5 h-5') ?></span>
            <div>
                <p class="font-semibold text-red-700"><?= sprintf(t('upgrade_alert_title'), count($upgradeAssets)) ?></p>
                <p class="text-xs text-red-500"><?= t('upgrade_alert_hint') ?></p>
            </div>
        </div>
        <svg id="upgradeAlertChevron" class="w-4 h-4 text-red-400 transition-transform shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M6 9l6 6 6-6" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </button>
    <div id="upgradeAlertPanel" class="<?= $upgradeMarked !== '' ? '' : 'hidden' ?> border-t border-red-200 bg-white">
        <div class="flex justify-end gap-2 px-4 pt-3">
            <a href="upgrade_list_print.php" target="_blank"
               class="inline-flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg px-3 py-1.5 text-xs font-medium">
                <?= icon('printer', 'w-3.5 h-3.5') ?> <?= t('btn_print') ?>
            </a>
            <a href="upgrade_list_pdf.php" target="_blank"
               class="inline-flex items-center gap-1 bg-orange-600 hover:bg-orange-700 text-white rounded-lg px-3 py-1.5 text-xs font-medium">
                <?= icon('file-text', 'w-3.5 h-3.5') ?> <?= t('link_pdf') ?>
            </a>
        </div>
        <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="text-left text-slate-500 border-b bg-slate-50">
                    <th class="py-2 px-4"><?= t('th_asset_no') ?></th>
                    <th class="py-2 px-4"><?= t('th_type') ?></th>
                    <th class="py-2 px-4"><?= t('th_department') ?></th>
                    <th class="py-2 px-4"><?= t('th_ticket_no') ?></th>
                    <th class="py-2 px-4"><?= t('upgrade_note_label') ?></th>
                    <th class="py-2 px-4"><?= t('th_date') ?></th>
                    <th class="py-2 px-4"></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($upgradeAssets as $ua): ?>
                <tr class="border-b last:border-0 hover:bg-slate-50">
                    <td class="py-2 px-4 font-medium">
                        <a href="assets.php?q=<?= urlencode($ua['asset_number']) ?>" class="text-blue-600 hover:underline">
                            <?= htmlspecialchars($ua['device_name'] ?: $ua['asset_number']) ?>
                        </a>
                    </td>
                    <td class="py-2 px-4"><?= htmlspecialchars($ua['category']) ?></td>
                    <td class="py-2 px-4"><?= htmlspecialchars($ua['department'] ?: t('dash')) ?></td>
                    <td class="py-2 px-4"><?= htmlspecialchars($ua['ticket_number']) ?></td>
                    <td class="py-2 px-4 text-slate-500 max-w-xs truncate" title="<?= htmlspecialchars($ua['matched_text'] ?? '') ?>">
                        <?= htmlspecialchars($ua['matched_text'] ?? '') ?>
                    </td>
                    <td class="py-2 px-4 text-slate-500"><?= date('d M Y', strtotime($ua['ticket_date'])) ?></td>
                    <td class="py-2 px-4 text-right">
                        <div class="flex justify-end items-center gap-2">
                            <!-- Proses Upgrade: isi komponen yang di-upgrade, data aset ikut diperbarui & tercatat di riwayat -->
                            <a href="asset_upgrade.php?asset_id=<?= (int)$ua['asset_id'] ?>&amp;ticket_id=<?= (int)$ua['ticket_id'] ?>"
                               class="inline-flex items-center gap-1 bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap">
                                <?= icon('arrow-up', 'w-3.5 h-3.5') ?> <?= t('btn_process_upgrade') ?>
                            </a>
                            <form method="post" action="upgrade_ack.php" onsubmit="return confirm('<?= htmlspecialchars(t('upgrade_mark_done_confirm'), ENT_QUOTES) ?>');">
                                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                                <input type="hidden" name="asset_id" value="<?= (int)$ua['asset_id'] ?>">
                                <input type="hidden" name="ticket_id" value="<?= (int)$ua['ticket_id'] ?>">
                                <button type="submit" title="<?= htmlspecialchars(t('upgrade_mark_done_hint')) ?>" class="inline-flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap">
                                    <?= icon('check', 'w-3.5 h-3.5') ?> <?= t('btn_mark_upgrade_done') ?>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="bg-white rounded-xl shadow-sm p-5">
    <h2 class="font-semibold text-slate-700 mb-3"><?= t('recent_tickets') ?></h2>
    <div class="overflow-x-auto">
    <table class="w-full text-sm">
        <thead>
            <tr class="text-left text-slate-500 border-b">
                <th class="py-2 pr-3"><?= t('th_ticket_no') ?></th>
                <th class="py-2 pr-3"><?= t('th_reporter') ?></th>
                <th class="py-2 pr-3"><?= t('th_problem') ?></th>
                <th class="py-2 pr-3"><?= t('th_status') ?></th>
                <th class="py-2 pr-3"><?= t('th_date') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($recentTickets as $t): ?>
            <tr class="border-b last:border-0">
                <td class="py-2 pr-3 font-medium"><?= htmlspecialchars($t['ticket_number']) ?></td>
                <td class="py-2 pr-3"><?= htmlspecialchars($t['pelapor']) ?></td>
                <td class="py-2 pr-3 max-w-xs truncate"><?= htmlspecialchars($t['problem_detail']) ?></td>
                <td class="py-2 pr-3">
                    <?php
                        $badge = ticketStatusBadges();
                    ?>
                    <span class="px-2 py-0.5 rounded-full text-xs font-medium <?= $badge[$t['status']] ?>"><?= htmlspecialchars(ticketStatusLabels()[$t['status']] ?? $t['status']) ?></span>
                </td>
                <td class="py-2 pr-3 text-slate-500"><?= date('d M Y H:i', strtotime($t['created_at'])) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$recentTickets): ?>
            <tr><td colspan="5" class="py-4 text-center text-slate-400"><?= t('no_tickets_yet') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

<?php
// Angka kartu Dashboard diperbarui otomatis tiap 30 detik dan saat tab dibuka kembali.
$extraScripts = ($extraScripts ?? '') . <<<'HTML'
<script>
(function () {
    var map = { total_asset: 'statTotalAsset', ticket_queue: 'statTicketQueue', fixed_today: 'statFixedToday' };
    function refresh() {
        fetch('dashboard.php?stats=1', { credentials: 'same-origin', cache: 'no-store', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d || !d.ok) return;
                Object.keys(map).forEach(function (k) {
                    var el = document.getElementById(map[k]);
                    if (el && typeof d[k] === 'number') el.textContent = d[k];
                });
            })
            .catch(function () {});
    }
    setInterval(refresh, 30000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) refresh(); });
})();
</script>
HTML;
?>
<?php require __DIR__ . '/includes/scan_modal.php'; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
