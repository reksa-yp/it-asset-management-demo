<?php
/**
 * Versi PDF untuk daftar "Aset Perlu Di-Upgrade" di Dashboard.
 * Memakai query yang sama persis dengan dashboard.php (lihat includes/upgrade_alert.php).
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/upgrade_alert.php';
require_once __DIR__ . '/vendor/autoload.php'; // composer require dompdf/dompdf

use Dompdf\Dompdf;
use Dompdf\Options;

$db = getDB();
$upgradeAssets = getUpgradeAssets($db);

$rowsHtml = '';
if ($upgradeAssets) {
    foreach ($upgradeAssets as $ua) {
        $rowsHtml .= '<tr>'
            . '<td>' . htmlspecialchars($ua['device_name'] ?: $ua['asset_number']) . '</td>'
            . '<td>' . htmlspecialchars($ua['category']) . '</td>'
            . '<td>' . htmlspecialchars($ua['department'] ?: t('dash')) . '</td>'
            . '<td>' . htmlspecialchars($ua['ticket_number']) . '</td>'
            . '<td>' . htmlspecialchars($ua['matched_text'] ?? '') . '</td>'
            . '<td>' . date('d M Y', strtotime($ua['ticket_date'])) . '</td>'
            . '</tr>';
    }
} else {
    $rowsHtml = '<tr><td colspan="6" style="color:#94a3b8;font-style:italic;">' . htmlspecialchars(t('upgrade_list_empty')) . '</td></tr>';
}

$html = '<html><head><meta charset="UTF-8"><style>
    body { font-family: Arial, sans-serif; color: #1e293b; font-size: 11px; }
    h1 { font-size: 16px; margin: 0 0 4px; }
    p.sub { font-size: 10px; color: #64748b; margin: 0 0 14px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #cbd5e1; padding: 5px 7px; text-align: left; vertical-align: top; }
    th { background: #f1f5f9; }
</style></head><body>'
    . '<h1>' . htmlspecialchars(t('upgrade_list_title')) . '</h1>'
    . '<p class="sub">' . htmlspecialchars(t('upgrade_list_subtitle')) . ' &bull; ' . htmlspecialchars(t('printed_at')) . ': ' . date('d M Y H:i') . '</p>'
    . '<table><thead><tr>'
    . '<th>' . t('th_asset_no') . '</th>'
    . '<th>' . t('th_type') . '</th>'
    . '<th>' . t('th_department') . '</th>'
    . '<th>' . t('th_ticket_no') . '</th>'
    . '<th>' . t('upgrade_note_label') . '</th>'
    . '<th>' . t('th_date') . '</th>'
    . '</tr></thead><tbody>' . $rowsHtml . '</tbody></table>'
    . '</body></html>';

$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->setPaper('A4', 'landscape');
$dompdf->loadHtml($html);
$dompdf->render();
$dompdf->stream('Daftar_Aset_Perlu_Upgrade_' . date('Ymd_His') . '.pdf', ['Attachment' => true]);
exit;
