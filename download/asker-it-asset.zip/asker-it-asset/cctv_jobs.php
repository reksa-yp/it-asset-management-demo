<?php
/**
 * Menu CCTV > Pekerjaan (khusus admin): riwayat pekerjaan CCTV (hardisk NVR, tambah titik, dll.),
 * filter bulan / jenis / NVR / status, export Excel, dan pengaturan jenis pekerjaan.
 * Logika & tabel: includes/cctv_jobs.php. Form tambah/edit: includes/cctv_jobs_view.php.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv_jobs.php';

$db = getDB();
ensureCctvTables($db);
cctvJobsEnsure($db);
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES);

$ym = (string)($_GET['ym'] ?? date('Y-m'));
if (!preg_match('/^\d{4}-\d{2}$/', $ym)) $ym = date('Y-m');
$all = !empty($_GET['all']);
$f = [
    'from' => $all ? '' : $ym . '-01', 'to' => $all ? '' : date('Y-m-t', strtotime($ym . '-01')),
    'type_id' => (int)($_GET['type'] ?? 0), 'nvr_id' => (int)($_GET['nvr'] ?? 0),
    'status' => isset(cctvJobStatuses()[$_GET['status'] ?? '']) ? (string)$_GET['status'] : '',
];
$jobs = cctvJobsList($db, $f);
$types = cctvJobTypes($db, false);
$nvrs = cctvNvrList($db);
$periodLabel = $all ? cL('Semua waktu', 'All time') : cctvMonthTitle($ym);

if (($_GET['out'] ?? '') === 'xlsx') {
    require_once __DIR__ . '/vendor/autoload.php';
    $ss = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sh = $ss->getActiveSheet();
    $sh->setTitle(cL('Pekerjaan CCTV', 'CCTV jobs'));
    $sh->setCellValue('A1', t('app_name') . ' — ' . cL('Pekerjaan CCTV', 'CCTV jobs'));
    $sh->setCellValue('A2', cL('Periode', 'Period') . ': ' . $periodLabel . '   •   ' . cL('Dicetak', 'Printed') . ': ' . date('d M Y H:i'));
    $sh->getStyle('A1')->getFont()->setBold(true)->setSize(13);
    $cols = [cL('Tanggal', 'Date'), 'Shift', cL('Jenis pekerjaan', 'Job type'), 'NVR', cL('Kamera', 'Camera'), cL('Rincian', 'Details'), cL('Barang dari stok', 'Items from stock'),
             cL('Aset kamera', 'Camera assets'), cL('Keterangan', 'Notes'), cL('Petugas', 'Officers'), 'Status', cL('Dicatat oleh', 'Recorded by')];
    $sh->fromArray($cols, null, 'A4');
    $r = 5;
    foreach ($jobs as $j) {
        $lines = array_values(array_filter(cctvJobDetailLines(array_merge($j, ['assets' => [], 'stock_text' => ''])), fn($l) => $l !== ''));
        $sh->fromArray([date('d/m/Y', strtotime($j['job_date'])), $j['shift'], $j['type_name'], $j['nvr_name'], $j['camera_label'], implode("\n", $lines),
            (string)$j['stock_text'], implode(', ', array_map(fn($l) => $l['asset_number'], $j['assets'])), (string)$j['note'], $j['officers'],
            cctvJobStatuses()[$j['status']] ?? $j['status'], (string)$j['created_by_name']], null, 'A' . $r, true);
        $r++;
    }
    $last = 'L';
    $head = $sh->getStyle("A4:{$last}4");
    $head->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
    $head->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
    $sh->getStyle("A4:{$last}" . max(4, $r - 1))->getBorders()->getAllBorders()->setBorderStyle('thin')->getColor()->setRGB('CBD5E1');
    $sh->getStyle("A5:{$last}" . max(5, $r - 1))->getAlignment()->setVertical('top')->setWrapText(true);
    foreach (['A' => 12, 'B' => 9, 'C' => 28, 'D' => 22, 'E' => 26, 'F' => 40, 'G' => 24, 'H' => 24, 'I' => 34, 'J' => 18, 'K' => 14, 'L' => 18] as $c => $w) $sh->getColumnDimension($c)->setWidth($w);
    $sh->freezePane('A5');
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="Pekerjaan_CCTV_' . ($all ? 'semua' : $ym) . '.xlsx"');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($ss))->save('php://output');
    exit;
}

$q = array_filter(['ym' => $all ? '' : $ym, 'all' => $all ? 1 : '', 'type' => $f['type_id'] ?: '', 'nvr' => $f['nvr_id'] ?: '', 'status' => $f['status']]);
$jobsCtx = [
    'jobs' => $jobs, 'date' => date('Y-m-d'), 'shift' => cctvShiftOptions()[max(0, cctvShiftIndexNow(cctvShiftOptions()))] ?? '',
    'back' => 'cctv_jobs.php' . ($q ? '?' . http_build_query($q) : ''), 'show_date' => true,
    'title' => cL('Riwayat pekerjaan', 'Job history') . ' · ' . $periodLabel . ' (' . count($jobs) . ')',
    'sub' => cL('Hanya admin yang bisa menambah, mengubah, dan menghapus pekerjaan. Petugas checklist tidak melihat menu ini.', 'Only admins can add, edit and delete jobs.'),
];

$pageTitle = cL('Pekerjaan CCTV', 'CCTV Jobs');
$cctvTab = 'jobs';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="mb-3">
    <h1 class="text-xl font-semibold text-slate-800"><?= $h(cL('Pekerjaan CCTV', 'CCTV Jobs')) ?></h1>
    <p class="text-sm text-slate-500"><?= $h(cL('Catatan pekerjaan fisik di sistem CCTV: hardisk NVR, tambah titik, pindah posisi, ganti kamera, perbaikan kabel, dan lainnya.', 'Physical work on the CCTV system: NVR disks, new points, relocation, replacement, cabling and more.')) ?></p>
</div>
<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<form method="get" class="bg-white rounded-xl shadow-sm p-3 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Bulan', 'Month')) ?></span>
        <input type="month" name="ym" value="<?= $h($ym) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5" <?= $all ? 'disabled' : '' ?>></label>
    <label class="flex items-center gap-1.5 pb-2"><input type="checkbox" name="all" value="1" <?= $all ? 'checked' : '' ?> onchange="this.form.ym.disabled = this.checked"> <?= $h(cL('Semua waktu', 'All time')) ?></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Jenis', 'Type')) ?></span>
        <select name="type" class="border border-slate-300 rounded-lg px-2 py-1.5"><option value=""><?= $h(cL('Semua jenis', 'All types')) ?></option><?php foreach ($types as $t): ?><option value="<?= (int)$t['id'] ?>" <?= $f['type_id'] === (int)$t['id'] ? 'selected' : '' ?>><?= $h($t['name']) ?></option><?php endforeach; ?></select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">NVR</span>
        <select name="nvr" class="border border-slate-300 rounded-lg px-2 py-1.5"><option value=""><?= $h(cL('Semua NVR', 'All NVRs')) ?></option><?php foreach ($nvrs as $n): ?><option value="<?= (int)$n['id'] ?>" <?= $f['nvr_id'] === (int)$n['id'] ? 'selected' : '' ?>><?= $h($n['name']) ?></option><?php endforeach; ?></select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">Status</span>
        <select name="status" class="border border-slate-300 rounded-lg px-2 py-1.5"><option value=""><?= $h(cL('Semua status', 'All statuses')) ?></option><?php foreach (cctvJobStatuses() as $k => $l): ?><option value="<?= $k ?>" <?= $f['status'] === $k ? 'selected' : '' ?>><?= $h($l) ?></option><?php endforeach; ?></select></label>
    <button class="bg-slate-200 hover:bg-slate-300 rounded-lg px-3 py-1.5"><?= $h(cL('Tampilkan', 'Show')) ?></button>
    <a href="cctv_jobs.php?<?= $h(http_build_query($q + ['out' => 'xlsx'])) ?>" class="ml-auto inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white rounded-lg px-4 py-2 font-medium"><?= icon('sheet', 'w-4 h-4') ?> Export Excel</a>
</form>

<?php require __DIR__ . '/includes/cctv_jobs_view.php'; ?>

<!-- Jenis pekerjaan -->
<details class="bg-white rounded-xl shadow-sm p-4 mt-5" id="jenis">
    <summary class="cursor-pointer font-semibold text-slate-800 flex items-center gap-2"><?= icon('settings', 'w-5 h-5 text-slate-500') ?> <?= $h(cL('Jenis pekerjaan', 'Job types')) ?> <span class="text-xs font-normal text-slate-500">(<?= count(array_filter($types, fn($t) => (int)$t['is_active'])) ?>)</span></summary>
    <form method="post" action="cctv_job_save.php" class="mt-3 space-y-2 text-sm" id="jtForm">
        <input type="hidden" name="csrf_token" value="<?= $h(csrfToken()) ?>"><input type="hidden" name="act" value="types"><input type="hidden" name="back" value="cctv_jobs.php#jenis">
        <p class="text-xs text-slate-500"><?= $h(cL('Bentuk isian menentukan kolom yang muncul di form. Kata kunci stok = barang Stok Barang yang otomatis diusulkan (mis. "hardisk"). Jenis yang sudah dipakai tidak dihapus, hanya disembunyikan.', 'Form type decides which fields appear. Stock keyword = stock item suggested automatically. Used types are hidden, not deleted.')) ?></p>
        <div class="overflow-x-auto border border-slate-200 rounded-lg">
        <table class="w-full text-sm" id="jtTable">
            <thead class="bg-slate-50 text-left text-xs uppercase text-slate-500"><tr><th class="px-3 py-2"><?= $h(cL('Nama jenis', 'Name')) ?></th><th class="px-3 py-2"><?= $h(cL('Bentuk isian', 'Form type')) ?></th><th class="px-3 py-2"><?= $h(cL('Kata kunci stok', 'Stock keyword')) ?></th><th class="px-3 py-2"><?= $h(cL('Hapus', 'Delete')) ?></th></tr></thead>
            <tbody>
            <?php foreach (array_merge(array_filter($types, fn($t) => (int)$t['is_active']), [['id' => 0, 'name' => '', 'kind' => 'cam', 'stock_hint' => '']]) as $i => $t): $tpl = (int)$t['id'] === 0; ?>
            <tr class="border-t border-slate-100 <?= $tpl ? 'hidden jt-tpl' : '' ?>">
                <td class="px-3 py-1.5"><input type="hidden" name="jt_id[<?= $tpl ? '__I__' : $i ?>]" value="<?= (int)$t['id'] ?>" <?= $tpl ? 'disabled' : '' ?>><input name="jt_name[<?= $tpl ? '__I__' : $i ?>]" value="<?= $h($t['name']) ?>" maxlength="100" class="w-full min-w-[12rem] border rounded-lg px-2 py-1.5" <?= $tpl ? 'disabled' : '' ?>></td>
                <td class="px-3 py-1.5"><select name="jt_kind[<?= $tpl ? '__I__' : $i ?>]" class="border rounded-lg px-2 py-1.5" <?= $tpl ? 'disabled' : '' ?>><?php foreach (cctvJobKinds() as $k => $l): ?><option value="<?= $k ?>" <?= $t['kind'] === $k ? 'selected' : '' ?>><?= $h($l) ?></option><?php endforeach; ?></select></td>
                <td class="px-3 py-1.5"><input name="jt_hint[<?= $tpl ? '__I__' : $i ?>]" value="<?= $h($t['stock_hint']) ?>" maxlength="60" class="w-32 border rounded-lg px-2 py-1.5" <?= $tpl ? 'disabled' : '' ?>></td>
                <td class="px-3 py-1.5 text-center"><input type="checkbox" name="jt_del[<?= $tpl ? '__I__' : $i ?>]" value="1" class="w-4 h-4" <?= $tpl ? 'disabled' : '' ?>></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <div class="flex flex-wrap justify-between gap-2">
            <button type="button" id="jtAdd" class="inline-flex items-center gap-1 text-sm font-medium text-blue-600 hover:underline"><?= icon('plus', 'w-4 h-4') ?> <?= $h(cL('Tambah jenis', 'Add type')) ?></button>
            <button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium"><?= $h(cL('Simpan jenis pekerjaan', 'Save job types')) ?></button>
        </div>
    </form>
</details>
<script>
(function () {
    var n = 0, tb = document.querySelector('#jtTable tbody'), tpl = tb.querySelector('.jt-tpl');
    document.getElementById('jtAdd').addEventListener('click', function () {
        var r = tpl.cloneNode(true), k = 'n' + (n++);
        r.classList.remove('hidden', 'jt-tpl');
        r.querySelectorAll('[name]').forEach(function (i) { i.name = i.name.replace('__I__', k); i.disabled = false; });
        tb.appendChild(r); r.querySelector('input[name^="jt_name"]').focus();
    });
    if (location.hash === '#jenis') document.getElementById('jenis').open = true;
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
