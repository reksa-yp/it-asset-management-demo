<?php
/**
 * Cetak / Simpan PDF laporan petugas CCTV yang dipilih (khusus admin), dengan kop surat.
 *   ?ids=3,5,8        laporan yang dicetak (dipilih di menu CCTV > Laporan petugas)
 *   &out=pdf          unduh PDF (Dompdf); tanpa ini = halaman cetak browser (dialog Print langsung muncul)
 * Kolom "Tindakan / paraf" sengaja kosong untuk diisi teknisi di lapangan.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv.php';
require_once __DIR__ . '/includes/letterhead.php';

$db = getDB();
ensureCctvTables($db);
$h = fn($v) => htmlspecialchars((string)$v);
$pdf = ($_GET['out'] ?? '') === 'pdf';

$ids = array_values(array_unique(array_filter(array_map('intval', explode(',', (string)($_GET['ids'] ?? ''))))));
$reports = [];
if ($ids) {
    $st = $db->prepare("SELECT * FROM cctv_reports WHERE id IN (" . implode(',', array_fill(0, count($ids), '?')) . ") ORDER BY status = 'done', reported_at");
    $st->execute($ids);
    $reports = $st->fetchAll();
}
$camById = [];
foreach (cctvCameras($db) as $c) $camById[$c['id']] = $c;
$open = count(array_filter($reports, fn($r) => $r['status'] !== 'done'));

$title = cL('DAFTAR LAPORAN CCTV YANG HARUS DITANGANI', 'CCTV REPORTS TO BE HANDLED');
$fileBase = 'Laporan_CCTV_' . date('Ymd_Hi');

ob_start(); ?>
<h1 class="ttl"><?= $h($title) ?></h1>
<p class="sub"><?= $h(documentCreatedAt()) ?> &middot; <?= count($reports) ?> <?= $h(cL('laporan', 'reports')) ?> (<?= $open ?> <?= $h(cL('belum ditangani', 'open')) ?>)</p>
<?php if (!$reports): ?>
    <p class="empty"><?= $h(cL('Tidak ada laporan yang dipilih.', 'No reports selected.')) ?></p>
<?php else: ?>
<table class="g">
    <thead><tr>
        <th style="width:22px">No</th>
        <th style="width:68px"><?= $h(cL('Waktu lapor', 'Reported')) ?></th>
        <th><?= $h(cL('Kamera', 'Camera')) ?></th>
        <th style="width:96px">NVR / IP</th>
        <th style="width:90px"><?= $h(cL('Masalah', 'Problem')) ?></th>
        <th><?= $h(cL('Keterangan', 'Details')) ?></th>
        <th style="width:70px"><?= $h(cL('Pelapor', 'Reporter')) ?></th>
        <th style="width:60px">Status</th>
        <th style="width:130px"><?= $h(cL('Tindakan / paraf', 'Action / initials')) ?></th>
    </tr></thead>
    <tbody>
    <?php foreach ($reports as $i => $r): $c = $camById[(int)$r['asset_id']] ?? null; ?>
        <tr>
            <td class="c"><?= $i + 1 ?></td>
            <td><?= $h(date('d/m/Y H:i', strtotime((string)$r['reported_at']))) ?></td>
            <td><b><?= $h($c ? ($c['name'] ?: $c['location']) : '#' . $r['asset_id']) ?></b><br><span class="muted"><?= $h(trim(($c['number'] ?? '') . ' · ' . ($c['location'] ?? ''), ' ·')) ?></span></td>
            <td><?= $h($c && $c['nvr_name'] !== '' ? $c['nvr_name'] . ' ch ' . (int)$c['channel'] : '-') ?><br><span class="muted"><?= $h($c && $c['ip'] !== '' ? $c['ip'] : '-') ?></span></td>
            <td><?= $h(cctvIssueLabel((string)$r['issue'])) ?><?= cctvIsChecklistReport($r) ? '<br><span class="muted">' . $h(cL('dari checklist', 'from checklist')) . '</span>' : '' ?></td>
            <td><?= $h($r['note'] ?? '') ?></td>
            <td><?= $h($r['reporter_name'] ?? '') ?></td>
            <td><?= $r['status'] === 'done'
                ? '<span class="ok">' . $h(cL('Selesai', 'Done')) . '</span><br><span class="muted">' . $h(date('d/m/Y', strtotime((string)$r['handled_at']))) . '</span>'
                : '<span class="x">' . $h(cL('Belum', 'Open')) . '</span>' ?></td>
            <td><?= $r['status'] === 'done' ? $h($r['admin_note'] ?? '') : '' ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<table class="sign"><tr>
    <?php foreach (cctvSigners($db) as $s): ?>
        <td><?= $h($s['label']) ?>,<div class="sign-line"><?= $s['name'] !== '' ? $h($s['name']) : '&nbsp;' ?></div><div class="sign-title"><?= $h($s['title']) ?></div></td>
    <?php endforeach; ?>
</tr></table>
<?php endif;
$body = ob_get_clean();

$css = '
    body { font-family: Helvetica, Arial, sans-serif; font-size: 9pt; color: #1e293b; }
    h1.ttl { text-align: center; font-size: 13pt; margin: 0 0 2px; }
    p.sub { text-align: center; color: #475569; margin: 0 0 8px; font-size: 8.5pt; }
    table.g { width: 100%; border-collapse: collapse; }
    table.g th, table.g td { border: 1px solid #94a3b8; padding: 3px 4px; vertical-align: top; text-align: left; }
    table.g th { background: #e5ecf6; text-align: center; }
    table.g td.c { text-align: center; }
    table.g tr { page-break-inside: avoid; }
    .muted { color: #64748b; font-size: 8pt; }
    .x { color: #b91c1c; font-weight: bold; }
    .ok { color: #15803d; font-weight: bold; }
    .empty { padding: 24px; text-align: center; color: #64748b; border: 1px dashed #94a3b8; }
    table.sign { width: 100%; margin-top: 18px; border-collapse: collapse; page-break-inside: avoid; }
    table.sign td { width: 33%; text-align: center; vertical-align: top; padding: 0 10px; }
    .sign-line { margin-top: 48px; border-top: 1px solid #111827; padding-top: 2px; font-weight: bold; }
    .sign-title { color: #374151; }
';

if ($pdf) {
    require_once __DIR__ . '/vendor/autoload.php';
    $opt = new \Dompdf\Options();
    $opt->set('isRemoteEnabled', true);
    $opt->set('defaultFont', 'DejaVu Sans');
    $dompdf = new \Dompdf\Dompdf($opt);
    $dompdf->setPaper('A4', 'landscape');
    $dompdf->loadHtml('<html><head><meta charset="UTF-8"><style>' . letterheadPdfCss() . $css . '</style></head><body>' . letterheadPdfHtml() . $body . '</body></html>', 'UTF-8');
    $dompdf->render();
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    $dompdf->stream($fileBase . '.pdf', ['Attachment' => true]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="<?= $h(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $h($fileBase) ?></title>
<style>
    @page { size: A4 landscape; }
    body { margin: 20px; }
    <?= $css ?>
    .no-print { margin: 16px 0; text-align: center; }
    .no-print button, .no-print a { background: #1F3DD1; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 13px; cursor: pointer; text-decoration: none; display: inline-block; margin: 0 4px; }
    .no-print a.sec { background: #475569; }
    @media print { body { margin: 0; } .no-print { display: none; } }
<?= letterheadCss() ?></style>
</head>
<body onload="window.print()">
    <?= letterheadOpen() ?>
    <?= $body ?>
    <?= letterheadClose() ?>
    <div class="no-print">
        <button onclick="window.print()"><?= $h(cL('Cetak lagi', 'Print again')) ?></button>
        <a class="sec" href="?<?= $h(http_build_query(array_merge($_GET, ['out' => 'pdf']))) ?>"><?= $h(cL('Unduh PDF', 'Download PDF')) ?></a>
    </div>
</body>
</html>
