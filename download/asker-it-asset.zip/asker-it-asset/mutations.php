<?php
/**
 * Menu Mutasi Aset (khusus admin): catat pemindahan kepemilikan aset dari user lama ke user baru
 * (atau dikembalikan ke Stok IT), riwayat mutasi, cetak Berita Acara, export Excel.
 * Buka langsung dengan aset terpilih: mutations.php?asset_id=123
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/mutation.php';
require_once __DIR__ . '/includes/categories.php';

$db = getDB();
ensureMutationTable($db);   // hanya membuat tabel BARU asset_mutations jika belum ada

$f         = mutationFilters();
$mutations = getMutations($db, $f);
$qs        = mutationFilterQuery($f);
$categories = array_column(getAssetCategories($db), 'name');

// Data untuk form: semua aset + pengguna saat ini, dan user aktif.
$assetRows = $db->query("SELECT id, asset_number, category, device_name, department, location, status FROM assets ORDER BY asset_number")->fetchAll();
$ownersMap = getAssetOwnersMap($db, array_column($assetRows, 'id'));
$assetData = [];
foreach ($assetRows as $a) {
    $owners = $ownersMap[$a['id']] ?? [];
    $assetData[] = [
        'id' => (int)$a['id'], 'no' => $a['asset_number'], 'cat' => $a['category'], 'name' => (string)$a['device_name'],
        'dept' => (string)$a['department'], 'loc' => (string)$a['location'], 'status' => $a['status'],
        'owners' => array_column($owners, 'full_name'), 'owner_ids' => array_column($owners, 'id'),
    ];
}
$users = $db->query("SELECT id, full_name, department FROM users WHERE is_active = 1 ORDER BY full_name")->fetchAll();

// Kartu ringkasan (mengikuti filter).
$totalMut    = count($mutations);
$assetsMoved = count(array_unique(array_column($mutations, 'asset_id')));
$toStock     = count(array_filter($mutations, fn($m) => trim((string)$m['to_user_names']) === ''));
$thisMonth   = (int)$db->query("SELECT COUNT(*) FROM asset_mutations WHERE mutation_date >= '" . date('Y-m-01') . "' AND mutation_date <= '" . date('Y-m-t') . "'")->fetchColumn();

$msg = $_SESSION['mutation_msg'] ?? null;
unset($_SESSION['mutation_msg']);
$openAssetId = (int)($_GET['asset_id'] ?? 0);

$pageTitle = t('page_title_mutations');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

$h = fn($v) => htmlspecialchars((string)$v);
$fmtDate = fn($d) => date('d M Y', strtotime($d));
$reasonTone = [
    'rotation' => 'bg-blue-100 text-blue-700', 'resign' => 'bg-red-100 text-red-700', 'replacement' => 'bg-amber-100 text-amber-700',
    'loan' => 'bg-purple-100 text-purple-700', 'return' => 'bg-slate-200 text-slate-700', 'handover' => 'bg-green-100 text-green-700',
    'other' => 'bg-slate-100 text-slate-600',
];
$sourceLabel = ['menu' => '', 'stock' => t('mut_source_stock'), 'asset_form' => t('mut_source_asset_form'), 'damage' => t('mut_source_damage')];
?>

<div class="flex flex-wrap items-center justify-between gap-3 mb-4">
    <p class="text-sm text-slate-500 max-w-xl"><?= t('mut_intro') ?></p>
    <div class="flex flex-wrap gap-2">
        <button type="button" onclick="openMutationModal()" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('transfer') ?> <?= t('mut_btn_new') ?>
        </button>
        <a href="mutation_export_excel.php?<?= $h($qs) ?>" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('sheet') ?> <?= t('btn_export_excel') ?>
        </a>
        <a href="mutation_print.php?<?= $h($qs) ?>&list=1" target="_blank" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('printer') ?> <?= t('mut_btn_print_list') ?>
        </a>
    </div>
</div>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 flex flex-wrap items-center gap-3 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>">
        <span><?= $h($msg['text']) ?></span>
        <?php if (!empty($msg['print'])): ?>
            <a href="mutation_print.php?id=<?= (int)$msg['print'] ?>" target="_blank" class="inline-flex items-center gap-1 font-medium underline"><?= icon('printer') ?> <?= t('mut_btn_print_ba') ?></a>
        <?php endif; ?>
    </div>
<?php endif; ?>

<!-- Filter -->
<form method="get" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('stock_filter_from') ?></span>
        <input type="date" name="from" value="<?= $h($f['from']) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('stock_filter_to') ?></span>
        <input type="date" name="to" value="<?= $h($f['to']) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('mut_col_category') ?></span>
        <select name="category" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[140px]">
            <option value=""><?= t('stock_all') ?></option>
            <?php foreach ($categories as $c): ?><option value="<?= $h($c) ?>" <?= $f['category'] === $c ? 'selected' : '' ?>><?= $h($c) ?></option><?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= t('mut_col_reason') ?></span>
        <select name="reason" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[160px]">
            <option value=""><?= t('stock_all') ?></option>
            <?php foreach (MUTATION_REASONS as $r): ?><option value="<?= $r ?>" <?= $f['reason'] === $r ? 'selected' : '' ?>><?= $h(mutationReasonLabel($r)) ?></option><?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1 flex-1 min-w-[180px]"><span class="text-xs text-slate-500"><?= t('stock_search') ?></span>
        <input type="search" name="q" value="<?= $h($f['q']) ?>" placeholder="<?= $h(t('mut_search_ph')) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= t('stock_apply') ?></button>
    <a href="mutations.php" class="text-slate-500 hover:text-slate-700 px-2 py-1.5"><?= t('mut_this_year') ?></a>
    <a href="mutations.php?from=&to=" class="text-slate-500 hover:text-slate-700 px-2 py-1.5"><?= t('stock_all_time') ?></a>
</form>

<!-- Kartu ringkasan -->
<div class="grid grid-cols-2 xl:grid-cols-4 gap-3 mb-4">
    <?php foreach ([
        [t('mut_card_total'), $totalMut, 'transfer', 'bg-brand-50 text-brand-700'],
        [t('mut_card_assets'), $assetsMoved, 'laptop', 'bg-indigo-50 text-indigo-700'],
        [t('mut_card_to_stock'), $toStock, 'package', 'bg-slate-100 text-slate-600'],
        [t('mut_card_month'), $thisMonth, 'clock', 'bg-green-50 text-green-700'],
    ] as [$label, $val, $ic, $tone]): ?>
        <div class="bg-white rounded-xl shadow-sm p-4 flex items-start gap-3">
            <span class="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 <?= $tone ?>"><?= icon($ic, 'w-5 h-5') ?></span>
            <div><p class="text-xs text-slate-500"><?= $h($label) ?></p><p class="text-2xl font-semibold text-slate-800 leading-tight tabular-nums"><?= $val ?></p></div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Riwayat mutasi -->
<div class="bg-white rounded-xl shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-left text-xs text-slate-500">
        <tr>
            <th class="py-2.5 px-3"><?= t('mut_col_number') ?></th>
            <th class="py-2.5 px-3"><?= t('th_date') ?></th>
            <th class="py-2.5 px-3"><?= t('mut_col_asset') ?></th>
            <th class="py-2.5 px-3"><?= t('mut_col_from') ?></th>
            <th class="py-2.5 px-3 w-6"></th>
            <th class="py-2.5 px-3"><?= t('mut_col_to') ?></th>
            <th class="py-2.5 px-3"><?= t('mut_col_reason') ?></th>
            <th class="py-2.5 px-3"><?= t('mut_col_condition') ?></th>
            <th class="py-2.5 px-3 text-right"><?= t('mut_btn_ba_short') ?></th>
        </tr>
        </thead>
        <tbody class="divide-y">
        <?php foreach ($mutations as $m): ?>
            <tr class="hover:bg-slate-50 align-top">
                <td class="py-2.5 px-3 font-medium text-brand-700 whitespace-nowrap"><?= $h($m['mutation_number']) ?>
                    <?php if (!empty($sourceLabel[$m['source']])): ?><div class="text-[11px] font-normal text-slate-400"><?= $h($sourceLabel[$m['source']]) ?></div><?php endif; ?></td>
                <td class="py-2.5 px-3 whitespace-nowrap"><?= $fmtDate($m['mutation_date']) ?>
                    <div class="text-[11px] text-slate-400" title="<?= $h(t('mut_col_by')) ?>"><?= $h($m['created_by_name'] ?: '') ?></div></td>
                <td class="py-2.5 px-3"><div class="font-medium whitespace-nowrap"><?= $h($m['asset_number']) ?></div>
                    <div class="text-xs text-slate-500"><?= $h($m['asset_category']) ?><?= $m['asset_name'] ? ' · ' . $h($m['asset_name']) : '' ?></div></td>
                <td class="py-2.5 px-3 min-w-[9rem]"><div class="<?= trim((string)$m['from_user_names']) === '' ? 'text-slate-400 italic' : '' ?>"><?= $h(mutationPartyLabel($m['from_user_names'])) ?></div>
                    <div class="text-xs text-slate-500"><?= $h(implode(' · ', array_filter([$m['from_department'], $m['from_location']]))) ?></div></td>
                <td class="py-2.5 px-1 text-slate-400"><?= icon('arrow-right', 'w-4 h-4') ?></td>
                <td class="py-2.5 px-3 min-w-[9rem]"><div class="font-medium <?= trim((string)$m['to_user_names']) === '' ? 'text-slate-400 italic' : '' ?>"><?= $h(mutationPartyLabel($m['to_user_names'])) ?></div>
                    <div class="text-xs text-slate-500"><?= $h(implode(' · ', array_filter([$m['to_department'], $m['to_location']]))) ?></div></td>
                <td class="py-2.5 px-3"><span class="px-2 py-0.5 rounded-full text-xs font-semibold whitespace-nowrap <?= $reasonTone[$m['reason']] ?? $reasonTone['other'] ?>"><?= $h(mutationReasonLabel($m['reason'])) ?></span>
                    <?php if ($m['note']): ?><div class="text-xs text-slate-500 mt-1 max-w-[16rem]"><?= $h(mb_strimwidth($m['note'], 0, 90, '…')) ?></div><?php endif; ?></td>
                <td class="py-2.5 px-3"><?= $h(mutationConditionLabel($m['asset_condition'])) ?></td>
                <td class="py-2.5 px-3 text-right whitespace-nowrap">
                    <a href="mutation_print.php?id=<?= (int)$m['id'] ?>" target="_blank" title="<?= $h(t('mut_btn_print_ba')) ?>" class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-brand-700 hover:bg-brand-50"><?= icon('printer', 'w-4 h-4') ?></a>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$mutations): ?>
            <tr><td colspan="9" class="py-10 text-center text-slate-400"><?= t('mut_empty') ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- ===== Modal Mutasi Aset ===== -->
<div id="mutationModal" class="hidden fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
    <form method="post" action="mutation_save.php" id="mutationForm" class="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[92vh] overflow-y-auto">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="asset_id" id="mfAssetId" value="">
        <div class="flex items-center justify-between px-5 py-4 border-b sticky top-0 bg-white z-10">
            <h3 class="font-semibold text-slate-800"><?= t('mut_modal_title') ?></h3>
            <button type="button" data-modal-close onclick="closeMutationModal()" class="text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button>
        </div>
        <div class="px-5 py-4 space-y-4 text-sm">
            <!-- 1. Pilih aset -->
            <div>
                <p class="font-medium text-slate-700 mb-1">1. <?= t('mut_step_asset') ?> <span class="text-red-500">*</span></p>
                <input type="search" id="mfAssetSearch" placeholder="<?= $h(t('mut_asset_search_ph')) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2 mb-1" oninput="filterAssets()">
                <select id="mfAssetSelect" size="5" class="w-full border border-slate-300 rounded-lg px-2 py-1 text-sm" onchange="pickAsset(this.value)"></select>
                <div id="mfCurrent" class="hidden mt-2 rounded-lg bg-slate-50 border p-3">
                    <p class="text-xs text-slate-500"><?= t('mut_current_owner') ?></p>
                    <p class="font-semibold text-slate-800" id="mfCurOwner"></p>
                    <p class="text-xs text-slate-500" id="mfCurInfo"></p>
                </div>
            </div>

            <!-- 2. Tujuan -->
            <div>
                <p class="font-medium text-slate-700 mb-1">2. <?= t('mut_step_target') ?> <span class="text-red-500">*</span></p>
                <div class="grid grid-cols-2 gap-1 bg-slate-100 rounded-lg p-1 mb-2">
                    <label class="text-center rounded-md py-1.5 font-medium cursor-pointer has-[:checked]:bg-white has-[:checked]:shadow-sm has-[:checked]:text-brand-700">
                        <input type="radio" name="target" value="user" class="sr-only" checked onchange="toggleTarget()"> <?= t('mut_target_user') ?></label>
                    <label class="text-center rounded-md py-1.5 font-medium cursor-pointer has-[:checked]:bg-white has-[:checked]:shadow-sm has-[:checked]:text-brand-700">
                        <input type="radio" name="target" value="stock" class="sr-only" onchange="toggleTarget()"> <?= t('mut_target_stock') ?></label>
                </div>
                <div id="mfUserBox">
                    <input type="search" id="mfUserSearch" placeholder="<?= $h(t('mut_user_search_ph')) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2 mb-1" oninput="filterUsers()">
                    <div id="mfUserList" class="max-h-44 overflow-y-auto border rounded-lg divide-y">
                        <?php foreach ($users as $u): ?>
                            <label class="mf-user flex items-center gap-2 px-3 py-1.5 hover:bg-slate-50 cursor-pointer" data-text="<?= $h(mb_strtolower($u['full_name'] . ' ' . $u['department'])) ?>">
                                <input type="checkbox" name="to_user_ids[]" value="<?= (int)$u['id'] ?>" class="mf-user-check" onchange="updateUserCount()">
                                <span class="flex-1"><?= $h($u['full_name']) ?></span>
                                <span class="text-xs text-slate-400"><?= $h($u['department']) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <p class="text-xs text-slate-500 mt-1"><span id="mfUserCount">0</span> <?= t('mut_users_selected') ?> · <?= t('mut_user_hint') ?></p>
                </div>
                <p id="mfStockHint" class="hidden text-xs bg-amber-50 text-amber-700 rounded-lg px-3 py-2"><?= t('mut_stock_hint') ?></p>
            </div>

            <!-- 3. Detail -->
            <div>
                <p class="font-medium text-slate-700 mb-1">3. <?= t('mut_step_detail') ?></p>
                <div class="grid sm:grid-cols-2 gap-3">
                    <label class="flex flex-col gap-1"><span class="text-slate-600"><?= t('mut_date') ?> <span class="text-red-500">*</span></span>
                        <input type="date" name="mutation_date" id="mfDate" required value="<?= date('Y-m-d') ?>" class="border border-slate-300 rounded-lg px-3 py-2"></label>
                    <label class="flex flex-col gap-1"><span class="text-slate-600"><?= t('mut_new_location') ?></span>
                        <input name="to_location" id="mfLocation" maxlength="100" class="border border-slate-300 rounded-lg px-3 py-2" placeholder="<?= $h(t('mut_location_ph')) ?>"></label>
                    <label class="flex flex-col gap-1"><span class="text-slate-600"><?= t('mut_col_reason') ?> <span class="text-red-500">*</span></span>
                        <select name="reason" id="mfReason" class="border border-slate-300 rounded-lg px-3 py-2">
                            <?php foreach (MUTATION_REASONS as $r): if ($r === 'handover') continue; ?><option value="<?= $r ?>"><?= $h(mutationReasonLabel($r)) ?></option><?php endforeach; ?>
                        </select></label>
                    <label class="flex flex-col gap-1"><span class="text-slate-600"><?= t('mut_col_condition') ?> <span class="text-red-500">*</span></span>
                        <select name="asset_condition" class="border border-slate-300 rounded-lg px-3 py-2">
                            <?php foreach (MUTATION_CONDITIONS as $c): ?><option value="<?= $c ?>"><?= $h(mutationConditionLabel($c)) ?></option><?php endforeach; ?>
                        </select></label>
                    <label class="flex flex-col gap-1 sm:col-span-2"><span class="text-slate-600"><?= t('stock_note') ?></span>
                        <textarea name="note" rows="2" maxlength="2000" class="border border-slate-300 rounded-lg px-3 py-2" placeholder="<?= $h(t('mut_note_ph')) ?>"></textarea></label>
                </div>
            </div>
            <p id="mfErr" class="hidden text-sm bg-red-50 text-red-700 rounded-lg px-3 py-2"></p>
        </div>
        <div class="px-5 py-3 border-t flex justify-end gap-2 sticky bottom-0 bg-white">
            <button type="button" onclick="closeMutationModal()" class="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm"><?= t('btn_cancel') ?></button>
            <button type="submit" class="inline-flex items-center gap-1 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium"><?= icon('check') ?> <?= t('mut_btn_save') ?></button>
        </div>
    </form>
</div>

<script>
const mutAssets = <?= json_encode($assetData, JSON_UNESCAPED_UNICODE) ?>;
const mutText = <?= json_encode([
    'stock' => t('mut_party_stock'), 'err_asset' => t('mut_err_asset'), 'err_user' => t('mut_err_no_user'),
    'err_same' => t('mut_err_same_user'), 'status' => t('th_status'),
], JSON_UNESCAPED_UNICODE) ?>;
let mutPicked = null;

function renderAssetOptions(list) {
    const sel = document.getElementById('mfAssetSelect');
    sel.innerHTML = '';
    list.slice(0, 300).forEach(a => {
        const o = document.createElement('option');
        o.value = a.id;
        o.textContent = a.no + ' — ' + (a.name || a.cat) + ' — ' + (a.owners.length ? a.owners.join(', ') : mutText.stock);
        if (mutPicked && mutPicked.id === a.id) o.selected = true;
        sel.appendChild(o);
    });
}
function filterAssets() {
    const q = document.getElementById('mfAssetSearch').value.trim().toLowerCase();
    renderAssetOptions(!q ? mutAssets : mutAssets.filter(a =>
        (a.no + ' ' + a.cat + ' ' + a.name + ' ' + a.dept + ' ' + a.loc + ' ' + a.owners.join(' ')).toLowerCase().includes(q)));
}
function pickAsset(id) {
    mutPicked = mutAssets.find(a => a.id === +id) || null;
    document.getElementById('mfAssetId').value = mutPicked ? mutPicked.id : '';
    document.getElementById('mfCurrent').classList.toggle('hidden', !mutPicked);
    if (!mutPicked) return;
    document.getElementById('mfCurOwner').textContent = mutPicked.no + ' · ' + (mutPicked.owners.length ? mutPicked.owners.join(', ') : mutText.stock);
    document.getElementById('mfCurInfo').textContent = [mutPicked.cat, mutPicked.name, mutPicked.dept, mutPicked.loc, mutText.status + ': ' + mutPicked.status].filter(Boolean).join(' · ');
    document.getElementById('mfLocation').value = mutPicked.loc || '';
    // Pengguna lama tidak dicentang otomatis; user memilih penerima baru.
    document.querySelectorAll('.mf-user-check').forEach(cb => cb.checked = false);
    updateUserCount();
}
function filterUsers() {
    const q = document.getElementById('mfUserSearch').value.trim().toLowerCase();
    document.querySelectorAll('.mf-user').forEach(el => el.classList.toggle('hidden', q !== '' && !el.dataset.text.includes(q)));
}
function updateUserCount() {
    document.getElementById('mfUserCount').textContent = document.querySelectorAll('.mf-user-check:checked').length;
}
function toggleTarget() {
    const stock = document.querySelector('input[name="target"]:checked').value === 'stock';
    document.getElementById('mfUserBox').classList.toggle('hidden', stock);
    document.getElementById('mfStockHint').classList.toggle('hidden', !stock);
    const r = document.getElementById('mfReason');
    if (stock && r.value === 'rotation') r.value = 'return';
}
function openMutationModal(assetId) {
    document.getElementById('mutationForm').reset();
    document.getElementById('mfErr').classList.add('hidden');
    document.getElementById('mfDate').value = new Date().toISOString().slice(0, 10);
    mutPicked = null;
    document.getElementById('mfAssetSearch').value = '';
    filterAssets(); filterUsers(); toggleTarget(); updateUserCount();
    document.getElementById('mfCurrent').classList.add('hidden');
    if (assetId) {
        const a = mutAssets.find(x => x.id === +assetId);
        if (a) { document.getElementById('mfAssetSearch').value = a.no; filterAssets(); pickAsset(a.id); }
    }
    document.getElementById('mutationModal').classList.remove('hidden');
}
function closeMutationModal() { document.getElementById('mutationModal').classList.add('hidden'); }
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMutationModal(); });

document.getElementById('mutationForm').addEventListener('submit', e => {
    const err = document.getElementById('mfErr');
    const stock = document.querySelector('input[name="target"]:checked').value === 'stock';
    const picked = Array.from(document.querySelectorAll('.mf-user-check:checked')).map(cb => +cb.value).sort();
    let msg = '';
    if (!mutPicked) msg = mutText.err_asset;
    else if (!stock && picked.length === 0) msg = mutText.err_user;
    else if (!stock && JSON.stringify(picked) === JSON.stringify(mutPicked.owner_ids.map(Number).sort())
             && (document.getElementById('mfLocation').value.trim() === (mutPicked.loc || ''))) msg = mutText.err_same;
    if (msg) { e.preventDefault(); err.textContent = msg; err.classList.remove('hidden'); }
});

<?php if ($openAssetId): ?>openMutationModal(<?= $openAssetId ?>);<?php endif; ?>
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
