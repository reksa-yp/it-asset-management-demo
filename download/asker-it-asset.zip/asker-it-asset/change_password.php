<?php
/**
 * Ganti Password Login: setiap user mengganti password login-nya sendiri.
 * Password baru dikosongkan = tidak ada perubahan (tetap memakai password dari admin).
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();

const SELF_PASSWORD_MIN = 6;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $old  = (string)($_POST['old_password'] ?? '');
    $new  = (string)($_POST['new_password'] ?? '');
    $new2 = (string)($_POST['new_password2'] ?? '');
    $msg  = ['ok' => true, 'text' => t('selfpw_saved')];

    if ($new === '' && $new2 === '') {
        $msg = ['ok' => true, 'text' => t('selfpw_no_change')];
    } else {
        $db = getDB();
        $st = $db->prepare("SELECT password FROM users WHERE id = ? AND is_active = 1");
        $st->execute([(int)$_SESSION['user_id']]);
        $hash = (string)$st->fetchColumn();
        if ($hash === '' || !password_verify($old, $hash)) {
            $msg = ['ok' => false, 'text' => t('selfpw_err_old')];
        } elseif (strlen($new) < SELF_PASSWORD_MIN) {
            $msg = ['ok' => false, 'text' => t('selfpw_err_short', SELF_PASSWORD_MIN)];
        } elseif ($new !== $new2) {
            $msg = ['ok' => false, 'text' => t('selfpw_err_confirm')];
        } elseif (password_verify($new, $hash)) {
            $msg = ['ok' => false, 'text' => t('selfpw_err_same')];
        } else {
            $db->prepare("UPDATE users SET password = ? WHERE id = ?")
               ->execute([password_hash($new, PASSWORD_BCRYPT), (int)$_SESSION['user_id']]);
        }
    }
    $_SESSION['selfpw_msg'] = $msg;
    header('Location: change_password.php');
    exit;
}

$selfpwMsg = $_SESSION['selfpw_msg'] ?? null;
unset($_SESSION['selfpw_msg']);

$pageTitle = t('page_title_selfpw');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="max-w-xl">
    <p class="text-sm text-slate-500 mb-4"><?= t('selfpw_intro') ?></p>

    <?php if ($selfpwMsg): ?>
        <div class="mb-4 rounded-lg px-4 py-3 text-sm <?= $selfpwMsg['ok'] ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200' ?>">
            <?= htmlspecialchars($selfpwMsg['text']) ?>
        </div>
    <?php endif; ?>

    <form method="post" autocomplete="off" class="bg-white rounded-xl shadow-sm text-sm">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <div class="p-5 space-y-4">
            <div>
                <label class="block mb-1 font-medium" for="old_password"><?= t('selfpw_old') ?></label>
                <input type="password" name="old_password" id="old_password" autocomplete="current-password" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block mb-1 font-medium" for="new_password"><?= t('selfpw_new') ?> <span class="text-xs font-normal text-slate-400"><?= t('selfpw_new_hint', SELF_PASSWORD_MIN) ?></span></label>
                <input type="password" name="new_password" id="new_password" autocomplete="new-password" class="w-full border rounded-lg px-3 py-2" placeholder="<?= htmlspecialchars(t('selfpw_new_placeholder')) ?>">
            </div>
            <div>
                <label class="block mb-1 font-medium" for="new_password2"><?= t('selfpw_new2') ?></label>
                <input type="password" name="new_password2" id="new_password2" autocomplete="new-password" class="w-full border rounded-lg px-3 py-2">
            </div>
            <label class="flex items-center gap-2 text-slate-600">
                <input type="checkbox" onclick="document.querySelectorAll('#old_password,#new_password,#new_password2').forEach(function(i){i.type=this.checked?'text':'password'},this)" class="h-4 w-4">
                <?= t('selfpw_show') ?>
            </label>
        </div>
        <div class="form-actions-sticky p-5 flex justify-end gap-3 rounded-b-xl border-t">
            <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium"><?= t('btn_save') ?></button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
