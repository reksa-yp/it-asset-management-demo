<?php
/** Laporan Stok Barang siap cetak (A4). Dialog print muncul otomatis. Mengikuti filter aktif. */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/stock.php';

$db = getDB();
ensureStockTables($db);
$f            = stockFilters();
$recap        = getStockRecap($db, $f);
$transactions = getStockTransactions($db, $f, true);
$recapUser    = getStockRecapByUser($transactions);
$logo         = appLogoDataUri();
$fmt          = fn($d) => date('d M Y', strtotime($d));
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars(t('stock_report_title')) ?> — <?= htmlspecialchars(stockPeriodLabel($f)) ?></title>
<style>
    @page { size: A4; margin: 14mm 12mm; }
    body { font-family: Arial, sans-serif; color: #1e293b; margin: 24px; font-size: 11px; }
    .head { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 2px solid #1F3DD1; padding-bottom: 8px; margin-bottom: 12px; }
    .brand { display: flex; align-items: center; gap: 10px; }
    .brand img { height: 36px; }
    .brand .name { font-size: 16px; font-weight: bold; color: #1F3DD1; }
    .muted { color: #64748b; }
    h2 { font-size: 12px; margin: 16px 0 6px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #cbd5e1; padding: 4px 6px; text-align: left; vertical-align: top; }
    th { background: #eef2ff; }
    .r { text-align: right; }
    tfoot td { font-weight: bold; background: #f8fafc; }
    .sign { display: flex; justify-content: space-around; margin-top: 36px; text-align: center; page-break-inside: avoid; }
    .sign div { width: 40%; }
    .sign .line { margin-top: 56px; }
    .no-print { margin-top: 20px; text-align: center; }
    .no-print button { background: #1F3DD1; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 13px; cursor: pointer; }
    @media print { body { margin: 0; } .no-print { display: none; } tr { page-break-inside: avoid; } }
</style>
</head>
<body>
    <div class="head">
        <div class="brand">
            <?php if ($logo): ?><img src="<?= $logo ?>" alt=""><?php endif; ?>
            <div><div class="name"><?= htmlspecialchars(t('app_name')) ?></div><div class="muted"><?= htmlspecialchars(t('stock_report_title')) ?></div></div>
        </div>
        <div class="muted" style="text-align:right">
            <?= htmlspecialchars(t('stock_period')) ?>: <?= htmlspecialchars(stockPeriodLabel($f)) ?><br>
            <?= htmlspecialchars(t('printed_at')) ?>: <?= date('d M Y H:i') ?>
        </div>
    </div>

    <h2>A. <?= htmlspecialchars(t('stock_tab_recap')) ?></h2>
    <table>
        <thead><tr><th>No</th><th><?= t('stock_category') ?></th><th class="r"><?= t('stock_opening') ?></th><th class="r"><?= t('stock_type_in') ?></th><th class="r"><?= t('stock_type_out') ?></th><th class="r"><?= t('stock_closing') ?></th><th><?= t('th_status') ?></th></tr></thead>
        <tbody>
        <?php foreach ($recap as $i => $r): ?>
            <tr><td><?= $i + 1 ?></td><td><?= htmlspecialchars($r['name']) ?></td><td class="r"><?= $r['opening'] ?></td><td class="r"><?= $r['qty_in'] ?></td><td class="r"><?= $r['qty_out'] ?></td>
                <td class="r"><b><?= $r['closing'] ?></b> <?= htmlspecialchars($r['unit']) ?></td><td><?= stockStatusLabel($r['status']) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot><tr><td colspan="2"><?= t('stock_total') ?></td><td class="r"><?= array_sum(array_column($recap, 'opening')) ?></td><td class="r"><?= array_sum(array_column($recap, 'qty_in')) ?></td>
            <td class="r"><?= array_sum(array_column($recap, 'qty_out')) ?></td><td class="r"><?= array_sum(array_column($recap, 'closing')) ?></td><td></td></tr></tfoot>
    </table>

    <h2>B. <?= htmlspecialchars(t('stock_tab_history')) ?></h2>
    <table>
        <thead><tr><th>No</th><th><?= t('th_date') ?></th><th><?= t('stock_type') ?></th><th><?= t('stock_category') ?></th><th class="r"><?= t('stock_type_in') ?></th><th class="r"><?= t('stock_type_out') ?></th><th><?= t('stock_given_to') ?></th><th><?= t('stock_note') ?></th></tr></thead>
        <tbody>
        <?php $trxAssets = getStockTrxAssets($db, array_column($transactions, 'id')); ?>
        <?php foreach ($transactions as $i => $tx): $in = $tx['type'] === 'in'; $txIds = array_column($trxAssets[(int)$tx['id']] ?? [], 'asset_number'); ?>
            <tr><td><?= $i + 1 ?></td><td style="white-space:nowrap"><?= $fmt($tx['trx_date']) ?></td><td><?= $in ? t('stock_type_in') : t('stock_type_out') ?></td>
                <td><?= htmlspecialchars($tx['category_name']) ?><?= $tx['item_name'] ? ' – ' . htmlspecialchars($tx['item_name']) : '' ?><?= $txIds ? '<br><span class="muted" style="font-size:10px">' . htmlspecialchars(t('stock_asset_ids')) . ': ' . htmlspecialchars(implode(', ', $txIds)) . '</span>' : '' ?></td>
                <td class="r"><?= $in ? (int)$tx['qty'] : '' ?></td><td class="r"><?= $in ? '' : (int)$tx['qty'] ?></td>
                <td><?= $in ? '' : htmlspecialchars(($tx['recipient_name'] ?? '') . ($tx['recipient_department'] ? ' (' . $tx['recipient_department'] . ')' : '')) ?></td>
                <td><?= htmlspecialchars($tx['note'] ?? '') ?></td></tr>
        <?php endforeach; ?>
        <?php if (!$transactions): ?><tr><td colspan="8" class="muted" style="text-align:center"><?= t('stock_no_transactions') ?></td></tr><?php endif; ?>
        </tbody>
    </table>

    <?php if ($recapUser): ?>
    <h2>C. <?= htmlspecialchars(t('stock_tab_user')) ?></h2>
    <table>
        <thead><tr><th>No</th><th><?= t('stock_user') ?></th><th><?= t('th_department') ?></th><th><?= t('stock_items_received') ?></th><th class="r"><?= t('stock_total_items') ?></th></tr></thead>
        <tbody>
        <?php foreach ($recapUser as $i => $u): ?>
            <tr><td><?= $i + 1 ?></td><td><?= htmlspecialchars($u['name']) ?></td><td><?= htmlspecialchars($u['department']) ?></td>
                <td><?= htmlspecialchars(implode(', ', array_map(fn($k, $v) => "$k ($v)", array_keys($u['items']), $u['items']))) ?></td><td class="r"><?= $u['total'] ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <div class="sign">
        <div><?= t('stock_sign_made') ?>,<div class="line">( ______________________ )</div><div class="muted"><?= htmlspecialchars(currentUser()['full_name'] ?? 'Admin IT') ?></div></div>
        <div><?= t('stock_sign_ack') ?>,<div class="line">( ______________________ )</div><div class="muted"><?= t('stock_sign_head') ?></div></div>
    </div>

    <div class="no-print"><button onclick="window.print()"><?= t('btn_print') ?></button></div>
    <script>window.addEventListener('load', () => setTimeout(() => window.print(), 300));</script>
</body>
</html>
