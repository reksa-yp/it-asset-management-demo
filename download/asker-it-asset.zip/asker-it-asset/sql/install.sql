-- =====================================================================
-- IT Asset Management - Struktur Database (instalasi baru)
-- Dijalankan otomatis oleh install.php. Bisa juga diimpor manual lewat
-- phpMyAdmin ke database kosong (lalu buat akun admin lewat install.php).
-- Aman dijalankan ulang: semua tabel memakai CREATE TABLE IF NOT EXISTS.
-- =====================================================================

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50)  NOT NULL UNIQUE,
    password      VARCHAR(255) NOT NULL,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(100) DEFAULT NULL,
    department    VARCHAR(100) DEFAULT NULL,
    pc_username   VARCHAR(100) DEFAULT NULL,
    pc_password   VARCHAR(100) DEFAULT NULL,
    role          ENUM('admin','user') NOT NULL DEFAULT 'user',
    is_active     TINYINT(1) NOT NULL DEFAULT 1,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_categories (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(50) NOT NULL UNIQUE,
    abbr        VARCHAR(10) NOT NULL,
    sort_order  INT UNSIGNED NOT NULL DEFAULT 0,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO asset_categories (name, abbr, sort_order) VALUES
    ('Desktop PC', 'PC', 1),
    ('Laptop', 'LT', 2),
    ('Printer', 'PRN', 3),
    ('Monitor', 'MN', 4),
    ('Aksesoris', 'AKS', 5),
    ('Tablet', 'TAB', 6);

CREATE TABLE IF NOT EXISTS assets (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_number      VARCHAR(30)  NOT NULL UNIQUE,
    category          VARCHAR(50)  NOT NULL,
    device_name       VARCHAR(100) DEFAULT NULL,
    owner_user_id     INT UNSIGNED DEFAULT NULL,
    department        VARCHAR(100) DEFAULT NULL,
    owner_email       VARCHAR(100) DEFAULT NULL,
    pc_username       VARCHAR(100) DEFAULT NULL,
    pc_password       VARCHAR(100) DEFAULT NULL,
    ip_address        VARCHAR(45)  DEFAULT NULL,
    hostname          VARCHAR(100) DEFAULT NULL,
    os_name           VARCHAR(100) DEFAULT NULL,
    os_status         ENUM('Original','Belum Original') NOT NULL DEFAULT 'Belum Original',
    software          TEXT DEFAULT NULL,
    software_serial_number VARCHAR(100) DEFAULT NULL,
    software_status   ENUM('Original','Belum Original') NOT NULL DEFAULT 'Belum Original',
    motherboard_brand VARCHAR(150) DEFAULT NULL,
    processor         VARCHAR(150) DEFAULT NULL,
    ram               VARCHAR(50)  DEFAULT NULL,
    storage           VARCHAR(50)  DEFAULT NULL,
    serial_number     VARCHAR(100) DEFAULT NULL,
    purchase_date     DATE DEFAULT NULL,
    location          VARCHAR(100) DEFAULT NULL,
    status            ENUM('Digunakan','Stok','Tidak Digunakan') NOT NULL DEFAULT 'Stok',
    printer_info      VARCHAR(150) DEFAULT NULL,
    monitor_info      VARCHAR(150) DEFAULT NULL,
    accessories       VARCHAR(150) DEFAULT NULL,
    created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_assets_status (status),
    INDEX idx_assets_owner (owner_user_id),
    CONSTRAINT fk_assets_owner FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_owners (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id   INT UNSIGNED NOT NULL,
    user_id    INT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_asset_user (asset_id, user_id),
    CONSTRAINT fk_asset_owners_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
    CONSTRAINT fk_asset_owners_user  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_software (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id       INT UNSIGNED NOT NULL,
    software_name  VARCHAR(150) NOT NULL,
    serial_number  VARCHAR(100) DEFAULT NULL,
    status         ENUM('Original','Belum Original') NOT NULL DEFAULT 'Belum Original',
    sort_order     INT UNSIGNED NOT NULL DEFAULT 0,
    created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_asset_software_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS tickets (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_number   VARCHAR(30) NOT NULL UNIQUE,
    asset_id        INT UNSIGNED DEFAULT NULL,
    reported_by     INT UNSIGNED NOT NULL,
    handled_by      INT UNSIGNED DEFAULT NULL,
    problem_detail  TEXT NOT NULL,
    status          ENUM('Menunggu','Proses','Selesai') NOT NULL DEFAULT 'Menunggu',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolved_at     DATETIME DEFAULT NULL,
    INDEX idx_tickets_status (status),
    INDEX idx_tickets_asset (asset_id),
    CONSTRAINT fk_tickets_asset  FOREIGN KEY (asset_id)    REFERENCES assets(id) ON DELETE SET NULL,
    CONSTRAINT fk_tickets_report FOREIGN KEY (reported_by) REFERENCES users(id)  ON DELETE CASCADE,
    CONSTRAINT fk_tickets_handle FOREIGN KEY (handled_by)  REFERENCES users(id)  ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ticket_logs (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_id   INT UNSIGNED NOT NULL,
    status      ENUM('Menunggu','Proses','Selesai') NOT NULL,
    note        VARCHAR(255) DEFAULT NULL,
    changed_by  INT UNSIGNED DEFAULT NULL,
    changed_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_logs_ticket FOREIGN KEY (ticket_id)  REFERENCES tickets(id) ON DELETE CASCADE,
    CONSTRAINT fk_logs_user   FOREIGN KEY (changed_by) REFERENCES users(id)   ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ticket_work_details (
    ticket_id    INT UNSIGNED NOT NULL PRIMARY KEY,
    work_detail  TEXT DEFAULT NULL,
    asset_check  TEXT DEFAULT NULL,
    filled_by    INT UNSIGNED DEFAULT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_twd_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_upgrade_ack (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id          INT NOT NULL,
    ticket_id         INT NOT NULL,
    acknowledged_by   INT NULL,
    acknowledged_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_asset_ticket (asset_id, ticket_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_upgrade_logs (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    asset_id      INT NOT NULL,
    ticket_id     INT NULL,
    upgrade_date  DATE NOT NULL,
    notes         TEXT NULL,
    created_by    VARCHAR(150) NULL,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_asset (asset_id),
    KEY idx_ticket (ticket_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_upgrade_log_items (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    log_id      INT UNSIGNED NOT NULL,
    field_name  VARCHAR(60)  NOT NULL,
    label       VARCHAR(150) NOT NULL,
    old_value   TEXT NULL,
    new_value   TEXT NULL,
    KEY idx_log (log_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ticket_cancellations (
    ticket_id     INT UNSIGNED NOT NULL PRIMARY KEY,
    cancelled_by  INT UNSIGNED DEFAULT NULL,
    reason        VARCHAR(255) DEFAULT NULL,
    cancelled_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_tablet_details (
    asset_id          INT UNSIGNED NOT NULL PRIMARY KEY,
    tablet_id         VARCHAR(50)  DEFAULT NULL,
    tablet_condition  ENUM('Bagus','Rusak') NOT NULL DEFAULT 'Bagus',
    updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_tablet_id (tablet_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS stock_categories (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(60)  NOT NULL UNIQUE,
    unit        VARCHAR(20)  NOT NULL DEFAULT 'pcs',
    min_stock   INT UNSIGNED NOT NULL DEFAULT 0,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS stock_transactions (
    id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id           INT UNSIGNED NOT NULL,
    type                  ENUM('in','out') NOT NULL,
    trx_date              DATE NOT NULL,
    qty                   INT UNSIGNED NOT NULL,
    item_name             VARCHAR(100) DEFAULT NULL,
    user_id               INT UNSIGNED DEFAULT NULL,
    recipient_name        VARCHAR(100) DEFAULT NULL,
    recipient_department  VARCHAR(100) DEFAULT NULL,
    note                  VARCHAR(255) DEFAULT NULL,
    created_by            INT UNSIGNED DEFAULT NULL,
    created_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_stock_cat_date (category_id, trx_date),
    INDEX idx_stock_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS stock_asset_links (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    stock_trx_id  INT UNSIGNED NOT NULL,
    asset_id      INT UNSIGNED NOT NULL,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_sal_trx_asset (stock_trx_id, asset_id),
    INDEX idx_sal_asset (asset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_mutations (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    mutation_number  VARCHAR(30)  NOT NULL UNIQUE,
    mutation_date    DATE         NOT NULL,
    asset_id         INT UNSIGNED NOT NULL,
    asset_number     VARCHAR(30)  NOT NULL,
    asset_category   VARCHAR(60)  DEFAULT NULL,
    asset_name       VARCHAR(150) DEFAULT NULL,
    from_user_ids    VARCHAR(255) DEFAULT NULL,
    from_user_names  VARCHAR(500) DEFAULT NULL,
    from_department  VARCHAR(100) DEFAULT NULL,
    from_location    VARCHAR(100) DEFAULT NULL,
    to_user_ids      VARCHAR(255) DEFAULT NULL,
    to_user_names    VARCHAR(500) DEFAULT NULL,
    to_department    VARCHAR(100) DEFAULT NULL,
    to_location      VARCHAR(100) DEFAULT NULL,
    reason           VARCHAR(30)  NOT NULL DEFAULT 'other',
    asset_condition  VARCHAR(20)  NOT NULL DEFAULT 'good',
    note             TEXT         DEFAULT NULL,
    source           VARCHAR(20)  NOT NULL DEFAULT 'menu',
    created_by       INT UNSIGNED DEFAULT NULL,
    created_by_name  VARCHAR(100) DEFAULT NULL,
    created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_mut_asset (asset_id),
    INDEX idx_mut_date (mutation_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_damages (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id          INT UNSIGNED NOT NULL,
    asset_number      VARCHAR(30)  NOT NULL,
    asset_category    VARCHAR(60)  DEFAULT NULL,
    asset_name        VARCHAR(150) DEFAULT NULL,
    damage_date       DATE         NOT NULL,
    issue             VARCHAR(255) NOT NULL,
    storage_location  VARCHAR(100) NOT NULL,
    last_user_names   VARCHAR(500) DEFAULT NULL,
    last_department   VARCHAR(100) DEFAULT NULL,
    prev_status       VARCHAR(20)  DEFAULT NULL,
    state             VARCHAR(20)  NOT NULL DEFAULT 'broken',
    note              TEXT         DEFAULT NULL,
    closed_date       DATE         DEFAULT NULL,
    created_by        INT UNSIGNED DEFAULT NULL,
    created_by_name   VARCHAR(100) DEFAULT NULL,
    created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_dmg_asset (asset_id),
    INDEX idx_dmg_state (state),
    INDEX idx_dmg_date (damage_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_pc_passwords (
    asset_id     INT UNSIGNED NOT NULL PRIMARY KEY,
    pc_password  VARCHAR(100) NOT NULL,
    updated_by   INT UNSIGNED DEFAULT NULL,
    updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_positions (
    user_id     INT UNSIGNED NOT NULL PRIMARY KEY,
    position    VARCHAR(100) NOT NULL,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_accessories (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id        INT UNSIGNED NOT NULL,
    accessory_name  VARCHAR(100) NOT NULL,
    brand_type      VARCHAR(100) DEFAULT NULL,
    sort_order      INT UNSIGNED NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_acc_asset (asset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
