<?php
/**
 * Antrian Ticket — daftar tiket IT yang sedang Menunggu/Proses dari SEMUA
 * pengguna (bukan cuma tiket sendiri), read-only, tanpa aksi admin.
 * Tujuannya supaya user biasa bisa lihat posisi antrian & seberapa sibuk IT.
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();

$db = getDB();

$tickets = $db->query("
    SELECT t.*, u.full_name AS pelapor, a.asset_number
    FROM tickets t
    JOIN users u ON u.id = t.reported_by
    LEFT JOIN assets a ON a.id = t.asset_id
    WHERE t.status IN ('Menunggu','Proses')
    ORDER BY FIELD(t.status,'Menunggu','Proses'), t.created_at ASC
")->fetchAll();

$badge = ['Menunggu'=>'bg-slate-100 text-slate-600','Proses'=>'bg-amber-100 text-amber-700'];
$statusLabel = [
    'Menunggu' => t('ticket_status_waiting'),
    'Proses'   => t('ticket_status_process'),
];

$myUserId = $_SESSION['user_id'];

$pageTitle = t('page_title_ticket_queue');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<p class="text-sm text-slate-500 mb-4"><?= htmlspecialchars(t('info_ticket_queue')) ?></p>

<!-- Layar lebar: baris ringkas tanpa scroll ke samping. Layar kecil: kartu. -->
<?php $qCols = 'lg:grid-cols-[3rem_10.5rem_minmax(8rem,12rem)_minmax(0,1fr)_7rem]'; ?>
<div class="bg-white rounded-xl shadow-sm">
    <div class="list-head-sticky hidden lg:grid <?= $qCols ?> gap-4 px-4 py-2 bg-slate-50 text-xs font-medium uppercase tracking-wide text-slate-500 rounded-t-xl border-b">
        <div><?= t('th_queue_no') ?></div>
        <div><?= t('th_ticket_no') ?></div>
        <div><?= t('th_reporter') ?></div>
        <div><?= t('ticket_col_problem') ?></div>
        <div><?= t('th_status') ?></div>
    </div>
    <?php $no = 1; foreach ($tickets as $t): ?>
        <?php $isMine = (int) $t['reported_by'] === (int) $myUserId; ?>
        <div class="grid grid-cols-[2.5rem_1fr] <?= $qCols ?> gap-x-3 gap-y-1 lg:gap-4 px-4 py-3 border-b last:border-0 <?= $isMine ? 'bg-blue-50/60' : 'hover:bg-slate-50/70' ?>">
            <div class="row-span-4 lg:row-span-1 text-lg lg:text-sm font-semibold text-slate-400 tabular-nums">#<?= $no++ ?></div>
            <div class="min-w-0">
                <div class="text-sm font-semibold text-slate-800 whitespace-nowrap">
                    <?= htmlspecialchars($t['ticket_number']) ?>
                    <?php if ($isMine): ?><span class="ml-1 text-[10px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 align-middle"><?= htmlspecialchars(t('lbl_my_ticket')) ?></span><?php endif; ?>
                </div>
                <div class="text-xs text-slate-500"><?= date('d M Y H:i', strtotime($t['created_at'])) ?></div>
            </div>
            <div class="text-sm text-slate-600 min-w-0 truncate"><?= htmlspecialchars($t['pelapor']) ?></div>
            <div class="text-sm min-w-0">
                <?php if (!empty($t['asset_number'])): ?><span class="inline-block mb-1 text-xs font-medium bg-slate-100 text-slate-600 rounded px-1.5 py-0.5"><?= htmlspecialchars($t['asset_number']) ?></span><?php endif; ?>
                <p class="text-slate-700 break-words line-clamp-2" title="<?= htmlspecialchars($t['problem_detail']) ?>"><?= htmlspecialchars($t['problem_detail']) ?></p>
            </div>
            <div><span class="px-2 py-0.5 rounded-full text-xs font-medium <?= $badge[$t['status']] ?>"><?= htmlspecialchars($statusLabel[$t['status']] ?? $t['status']) ?></span></div>
        </div>
    <?php endforeach; ?>
    <?php if (!$tickets): ?>
        <p class="py-8 text-center text-sm text-slate-400"><?= t('no_queue_tickets') ?></p>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
