<?php
/**
 * Menu Agen Kantor (khusus admin): lokasi server (kantor / hosting), aktifkan Agen Kantor, kunci, status,
 * dan unduh paket agen untuk dipasang di PC kantor.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv_rtsp.php';

$h = fn($v) => htmlspecialchars((string)$v);
$back = function (bool $ok, string $text) {
    $_SESSION['agent_msg'] = ['ok' => $ok, 'text' => $text];
    header('Location: agent.php');
    exit;
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $act = (string)($_POST['action'] ?? '');
    if ($act === 'server_save') {
        $mode = in_array($_POST['server_mode'] ?? '', ['auto', 'office', 'hosting'], true) ? (string)$_POST['server_mode'] : 'auto';
        saveAgentSettings(['server_mode' => $mode]);
        if ($mode === 'auto') agentDetectServer(true);
        $back(true, cL('Lokasi server disimpan: ', 'Server location saved: ') . (isHostingServer() ? cL('hosting', 'hosting') : cL('jaringan kantor', 'office network')) . '.');
    }
    if ($act === 'agent_save') {
        $s = agentSettings();
        $on = !empty($_POST['enabled']);
        $url = trim((string)($_POST['public_url'] ?? ''));
        if ($url !== '' && !preg_match('#^https?://[^\s]+$#i', $url)) $back(false, cL('Alamat aplikasi harus diawali http:// atau https://', 'The app address must start with http:// or https://'));
        $chg = ['enabled' => $on, 'public_url' => $url];
        if ($on && ($s['key'] === '' || !empty($_POST['new_key']))) $chg['key'] = bin2hex(random_bytes(20));
        saveAgentSettings($chg);
        $back(true, $on ? cL('Agen Kantor aktif. Unduh paket agen lalu pasang di PC kantor.', 'Office Agent enabled. Download the agent package and install it on an office PC.')
            . (!empty($_POST['new_key']) ? cL(' Kunci baru dibuat: paket agen lama tidak berlaku, unduh ulang.', ' New key created: download the package again.') : '')
            : cL('Agen Kantor dinonaktifkan.', 'Office Agent disabled.'));
    }
}
$msg = $_SESSION['agent_msg'] ?? null;
unset($_SESSION['agent_msg']);

$s = agentSettings(true);
$mode = serverMode();
$online = agentOnline();
$db = getDB();
ensureCctvTables($db);
$agentNvr = array_filter(cctvNvrList($db), fn($n) => cctvNvrConn($n)['mode'] === 'agen');
$hasCurl = function_exists('curl_init');
$isHttps = stripos(agentBaseUrl(), 'https://') === 0;

$pageTitle = cL('Agen Kantor', 'Office Agent');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
$card = 'bg-white rounded-xl shadow-sm p-5 mb-5';
?>
<div class="mb-4">
    <h1 class="text-xl font-semibold text-slate-800"><?= $h(cL('Agen Kantor & lokasi server', 'Office Agent & server location')) ?></h1>
    <p class="text-sm text-slate-500"><?= $h(cL('Untuk aplikasi yang dipasang di hosting: agen di PC kantor menjalankan cek CCTV, snapshot, ping & scan jaringan lalu mengirim hasilnya ke sini.', 'For apps on web hosting: an agent on an office PC runs CCTV checks, snapshots, ping & network scans and sends the results here.')) ?></p>
</div>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<section class="<?= $card ?>">
    <h2 class="font-semibold text-slate-800 mb-1">1. <?= $h(cL('Lokasi server', 'Server location')) ?></h2>
    <p class="text-sm text-slate-600 mb-3"><?= $h(cL('Saat ini: ', 'Currently: ')) ?><b><?= $h($mode === 'hosting' ? cL('Hosting (internet)', 'Web hosting (internet)') : cL('Jaringan kantor', 'Office network')) ?></b>
        <?php if ($s['server_mode'] === 'auto'): ?><span class="text-slate-500">· <?= $h(cL('terdeteksi otomatis', 'auto-detected')) ?><?= $s['detected_at'] !== '' ? ' ' . $h(date('d M Y H:i', strtotime($s['detected_at']))) : '' ?></span><?php endif; ?></p>
    <form method="post" class="grid gap-2 sm:grid-cols-3 text-sm">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="server_save">
        <?php foreach (['auto' => [cL('Otomatis', 'Automatic'), cL('Windows/XAMPP = kantor. Server yang tidak bisa ping = hosting.', 'Windows/XAMPP = office. A server that cannot ping = hosting.')],
                        'office' => [cL('Jaringan kantor', 'Office network'), cL('XAMPP / server lokal / VPS yang tersambung VPN ke kantor. Ping & IP lokal dijangkau langsung.', 'XAMPP / local server / VPS on a VPN to the office.')],
                        'hosting' => [cL('Hosting', 'Web hosting'), cL('Hostinger, cPanel, dsb. IP lokal kantor tidak terjangkau; pakai Agen Kantor.', 'Hostinger, cPanel, etc. Office IPs unreachable; use the Office Agent.')]] as $k => [$label, $desc]): ?>
            <label class="flex gap-2 items-start rounded-lg border border-slate-200 p-3 cursor-pointer has-[:checked]:border-blue-600 has-[:checked]:bg-blue-50">
                <input type="radio" name="server_mode" value="<?= $k ?>" <?= $s['server_mode'] === $k ? 'checked' : '' ?> class="mt-0.5 w-4 h-4">
                <span><span class="font-medium text-slate-800"><?= $h($label) ?></span><span class="block text-xs text-slate-600"><?= $h($desc) ?></span></span>
            </label>
        <?php endforeach; ?>
        <div class="sm:col-span-3"><button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= $h(cL('Simpan', 'Save')) ?></button></div>
    </form>
    <div class="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4 text-sm">
        <?php foreach ([
            [cL('Cek & scan jaringan', 'Network check & scan'), agentLanMode() === 'local' ? cL('Langsung dari server', 'Directly from the server') : (agentLanMode() === 'agent' ? cL('Lewat Agen Kantor', 'Via the Office Agent') : cL('Disembunyikan (butuh agen)', 'Hidden (needs the agent)')), agentLanMode() !== 'none'],
            [cL('NVR ber-IP lokal', 'Local-IP NVRs'), $mode === 'office' ? cL('Langsung', 'Direct') : cL('Lewat agen / IP publik / tunnel', 'Via agent / public IP / tunnel'), true],
            [cL('Video live RTSP', 'RTSP live video'), cctvFfmpegPath() !== '' ? cL('ffmpeg tersedia', 'ffmpeg available') : cL('Tidak ada ffmpeg: snapshot', 'No ffmpeg: snapshots'), true],
            [cL('Cek CCTV terjadwal', 'Scheduled CCTV check'), agentEnabled() ? cL('Dipicu Agen Kantor', 'Triggered by the agent') : ($mode === 'hosting' ? cL('Cron Job hosting', 'Hosting cron job') : cL('Task Scheduler Windows', 'Windows Task Scheduler')), true],
        ] as [$l, $v, $ok]): ?>
            <div class="rounded-lg border border-slate-200 p-3"><p class="text-xs text-slate-500"><?= $h($l) ?></p><p class="font-medium <?= $ok ? 'text-slate-800' : 'text-amber-700' ?>"><?= $h($v) ?></p></div>
        <?php endforeach; ?>
    </div>
</section>

<section class="<?= $card ?>">
    <div class="flex flex-wrap items-start justify-between gap-3 mb-3">
        <div>
            <h2 class="font-semibold text-slate-800 mb-1">2. <?= $h(cL('Agen Kantor', 'Office Agent')) ?></h2>
            <p class="text-sm text-slate-600"><?= $h(cL('Tidak perlu IP publik, port forwarding, atau VPN: agen hanya membuat koneksi keluar ke aplikasi ini.', 'No public IP, port forwarding or VPN: the agent only makes outgoing connections to this app.')) ?></p>
        </div>
        <span class="inline-flex items-center gap-2 rounded-full px-3 py-1 text-sm font-semibold <?= $online ? 'bg-green-100 text-green-800' : (agentEnabled() ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700') ?>">
            <span class="w-2 h-2 rounded-full bg-current"></span><?= $h($online ? cL('Online', 'Online') : (agentEnabled() ? cL('Belum / tidak melapor', 'Not reporting') : cL('Nonaktif', 'Off'))) ?></span>
    </div>
    <?php if (agentEnabled()): ?>
        <p class="text-sm text-slate-700 mb-3"><?= $h(agentStatusText()) ?><?php if (!empty($s['info']['php'])): ?> · PHP <?= $h($s['info']['php']) ?> · <?= $h(cL('agen v', 'agent v')) . $h($s['info']['version'] ?? '?') ?><?php endif; ?>
            <?php if ($agentNvr): ?> · <?= count($agentNvr) ?> <?= $h(cL('NVR lewat agen', 'NVR(s) via agent')) ?><?php endif; ?></p>
    <?php endif; ?>
    <?php if (!$isHttps && agentEnabled()): ?>
        <p class="mb-3 text-sm rounded-lg px-3 py-2 bg-amber-50 text-amber-900"><?= $h(cL('Aplikasi dibuka lewat HTTP. Aktifkan SSL/HTTPS di hosting agar kunci agen & data NVR terkirim terenkripsi.', 'The app is served over HTTP. Enable SSL/HTTPS so the agent key and NVR data are encrypted.')) ?></p>
    <?php endif; ?>
    <form method="post" class="grid gap-3 sm:grid-cols-2 text-sm items-end">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="agent_save">
        <label class="flex items-center gap-2 sm:col-span-2"><input type="checkbox" name="enabled" value="1" <?= $s['enabled'] ? 'checked' : '' ?> class="w-4 h-4"> <b><?= $h(cL('Aktifkan Agen Kantor', 'Enable the Office Agent')) ?></b></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Alamat aplikasi yang dihubungi agen (kosong = otomatis)', 'App address the agent calls (blank = automatic)')) ?></span>
            <input name="public_url" value="<?= $h($s['public_url']) ?>" placeholder="<?= $h(agentBaseUrl()) ?>" class="border border-slate-300 rounded-lg px-3 py-2 font-mono text-xs"></label>
        <div class="text-xs text-slate-600"><?= $h(cL('Kunci agen', 'Agent key')) ?>: <code class="text-slate-800"><?= $s['key'] !== '' ? $h(substr($s['key'], 0, 6) . '…' . substr($s['key'], -4)) : '-' ?></code>
            <?php if ($s['key'] !== ''): ?><label class="ml-2"><input type="checkbox" name="new_key" value="1"> <?= $h(cL('buat kunci baru (agen lama berhenti)', 'new key (old agent stops)')) ?></label><?php endif; ?></div>
        <div class="sm:col-span-2 flex flex-wrap gap-2">
            <button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium"><?= $h(cL('Simpan', 'Save')) ?></button>
            <?php if (agentEnabled()): ?>
                <a href="agent_download.php" class="inline-flex items-center gap-2 rounded-lg border border-slate-300 hover:bg-slate-50 px-4 py-2 font-medium text-slate-800"><?= icon('download') ?> <?= $h(cL('Unduh paket agen (.zip)', 'Download agent package (.zip)')) ?></a>
            <?php endif; ?>
        </div>
    </form>
    <?php if (!$hasCurl): ?><p class="mt-3 text-xs text-red-700"><?= $h(cL('Ekstensi PHP curl di server ini tidak aktif.', 'PHP curl is disabled on this server.')) ?></p><?php endif; ?>
</section>

<section class="<?= $card ?>">
    <h2 class="font-semibold text-slate-800 mb-2">3. <?= $h(cL('Cara memasang agen di PC kantor', 'Installing the agent on an office PC')) ?></h2>
    <ol class="list-decimal pl-5 text-sm text-slate-700 space-y-1.5">
        <li><?= $h(cL('Centang "Aktifkan Agen Kantor", Simpan, lalu klik "Unduh paket agen". Berkas sudah berisi alamat aplikasi & kunci.', 'Tick "Enable", save, then "Download agent package". It already contains the app address & key.')) ?></li>
        <li><?= $h(cL('Ekstrak ke PC Windows di kantor yang selalu menyala, mis. C:\\AgenKantor.', 'Extract it on an always-on office Windows PC, e.g. C:\\AgenKantor.')) ?></li>
        <li><?= $h(cL('Butuh PHP: XAMPP di C:\\xampp, atau unduh PHP for Windows (zip, x64 Thread Safe) dari windows.php.net lalu ekstrak ke folder "php" di dalam folder agen.', 'Needs PHP: XAMPP in C:\\xampp, or PHP for Windows (zip) extracted into a "php" folder inside the agent folder.')) ?></li>
        <li><?= $h(cL('Uji: klik 2x jalankan_agen.bat. Status di halaman ini harus menjadi Online dalam ±10 detik.', 'Test: double-click jalankan_agen.bat. This page should show Online within ~10 s.')) ?></li>
        <li><?= $h(cL('Permanen: klik kanan pasang_agen.bat > Run as administrator (agen menyala otomatis setiap PC dihidupkan).', 'Permanent: right-click pasang_agen.bat > Run as administrator (starts with Windows).')) ?></li>
        <li><?= $h(cL('CCTV: di CCTV > Pengaturan > 1, pilih "Agen Kantor" pada NVR dan isi IP lokal NVR. Menu Jaringan otomatis memakai agen untuk Cek & Scan.', 'CCTV: in CCTV > Settings > 1 choose "Office Agent" for the NVR with its local IP. The Network menu uses the agent for Check & Scan.')) ?></li>
    </ol>
    <p class="text-xs text-slate-500 mt-3"><?= $h(cL('Yang dikirim agen: status NVR, snapshot kamera saat dibutuhkan (Monitoring/List View), hasil ping, port & tabel ARP. Video RTSP tidak dikirim lewat agen.', 'The agent sends NVR status, camera snapshots when needed, ping/port results and the ARP table. RTSP video is not relayed.')) ?></p>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
