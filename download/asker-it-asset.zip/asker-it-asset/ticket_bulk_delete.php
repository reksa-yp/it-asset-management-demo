<?php
/**
 * Hapus beberapa tiket (riwayat ticketing) sekaligus, dipanggil dari
 * form checkbox di tickets.php. Hanya admin yang boleh mengakses.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tickets.php');
    exit;
}
csrfCheck();

$rawIds = $_POST['ids'] ?? [];
$ids = array_values(array_unique(array_filter(
    array_map('intval', (array)$rawIds),
    fn($v) => $v > 0
)));

if ($ids) {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = getDB()->prepare("DELETE FROM tickets WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $_SESSION['ticket_bulk_msg'] = ['ok' => true, 'text' => count($ids) . ' tiket berhasil dihapus.'];
} else {
    $_SESSION['ticket_bulk_msg'] = ['ok' => false, 'text' => 'Tidak ada tiket yang dipilih untuk dihapus.'];
}

header('Location: tickets.php');
exit;
