# Pekerjaan CCTV (khusus admin)

Mencatat pekerjaan fisik di sistem CCTV: penambahan / ganti hardisk NVR, tambah titik CCTV,
pindah posisi kamera, ganti kamera, perbaikan kabel / konektor, ganti adaptor / power, dan lainnya.
Petugas checklist (user dengan Akses Checklist CCTV) tidak melihat fitur ini.

## Mencatat pekerjaan
1. Buka **CCTV › Checklist**, pilih tanggal & shift. Di bawah tabel checklist ada bagian
   **Pekerjaan CCTV shift ini** (atau buka tab **CCTV › Pekerjaan**).
2. Klik **Tambah pekerjaan** atau salah satu tombol jenis pekerjaan.
3. Isi NVR, rincian, status (Selesai / Dalam proses / Menunggu barang), petugas, keterangan,
   dan foto sebelum / sesudah (maks. 4).

Isian khusus:
- **Hardisk NVR**: jumlah HDD, kapasitas per HDD, merek, kapasitas NVR sebelum → sesudah, perkiraan lama rekaman.
- **Tambah titik CCTV**: jumlah titik, channel awal di NVR, lokasi, merek/tipe kamera, lalu pilih:
  - *Pakai kamera CCTV berstatus Stok* di menu Aset → status jadi Digunakan, NVR & channel terisi (langsung ikut monitoring);
  - *Buat aset CCTV baru* → nomor aset dibuat otomatis, satu aset per titik;
  - *Jangan daftarkan dulu*.
  Aset kamera hanya dibuat / dipakai sekali per pekerjaan (saat pertama disimpan).

## Ambil barang dari Stok Barang
Centang **Ambil dari stok**, pilih barang dan jumlahnya. Barang yang habis tidak bisa dipilih dan
jumlah tidak boleh melebihi sisa stok. Saat disimpan tercatat sebagai **Barang Keluar** untuk "CCTV"
di menu Stok Barang. Mengubah jumlah ikut mengubah transaksi stoknya; menghapus pekerjaan
mengembalikan barang ke stok (aset kamera yang sudah dibuat tidak ikut terhapus).

## Riwayat, cetak, dan Excel
- Tab **CCTV › Pekerjaan**: riwayat dengan filter bulan / jenis / NVR / status, dan **Export Excel**.
- Pekerjaan ikut tercetak di **cetak checklist per shift** dan **laporan bulanan** (cetak / PDF).
- Daftar jenis pekerjaan bisa ditambah / diubah di bagian **Jenis pekerjaan** di bawah tab Pekerjaan
  (bentuk isian + kata kunci barang stok yang otomatis diusulkan).

## Catatan teknis
Tabel baru: `cctv_job_types`, `cctv_jobs`, `cctv_job_assets` (dibuat otomatis). Tabel lama tidak diubah;
yang berubah hanya isinya (transaksi Barang Keluar dan status aset kamera). Foto disimpan di
`assets/uploads/cctv/pekerjaan/`.
