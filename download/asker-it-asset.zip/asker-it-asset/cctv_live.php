<?php
/**
 * Live preview CCTV (khusus admin) lewat RTSP sub-stream NVR, diolah ffmpeg di server.
 *   s=t : 1 frame kecil untuk thumbnail kartu Monitoring (disimpan sementara beberapa detik)
 *   s=f : 1 frame besar (cadangan bila video tidak bisa diputar)
 *   s=v : video live MJPEG (multipart) untuk tampilan "Lihat live" — langsung diputar oleh tag <img> di browser
 * RTSP terpisah dari web NVR (ISAPI), jadi tetap jalan walau halaman web NVR bermasalah. Tidak butuh plugin browser.
 * Gambar sementara: includes/data/cctv_live/ (maks. 2 file per kamera, selalu tertimpa).
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
session_write_close();                       // jangan kunci sesi: banyak gambar dimuat bersamaan
require_once __DIR__ . '/includes/cctv_rtsp.php';

$fail = function (int $status, string $msg) {
    http_response_code($status);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Cctv-Live: ' . rawurlencode($msg));
    echo $msg;
    exit;
};

$id   = (int)($_GET['id'] ?? 0);
$mode = (string)($_GET['s'] ?? 't');
if (!in_array($mode, ['t', 'f', 'v'], true)) $mode = 't';
$db   = getDB();
ensureCctvTables($db);

$cam = null;
foreach (cctvCameras($db) as $c) if ((int)$c['id'] === $id) { $cam = $c; break; }
if (!$cam) $fail(404, cL('Kamera tidak ditemukan', 'Camera not found'));
$nvrs = cctvNvrList($db);
$nvr  = $nvrs[(int)($cam['nvr_id'] ?? 0)] ?? null;
if (!$nvr || (int)($cam['channel'] ?? 0) < 1) $fail(404, cL('Preview hanya untuk kamera yang terhubung ke NVR (isi NVR & channel di Pengaturan)', 'Preview only for cameras mapped to an NVR'));
if ((int)($nvr['is_active'] ?? 1) !== 1) $fail(404, cL('NVR nonaktif', 'NVR inactive'));
if (strtolower((string)$nvr['brand']) === 'ping') $fail(404, cL('Live preview butuh NVR Hikvision/Dahua (RTSP)', 'Live preview needs a Hikvision/Dahua NVR'));
$bin = cctvFfmpegPath();
if ($bin === '') $fail(503, cL('ffmpeg belum terpasang di server (lihat CCTV > Pengaturan > 1)', 'ffmpeg is not installed on the server'));

$dir = __DIR__ . '/includes/data/cctv_live';
if (!is_dir($dir)) @mkdir($dir, 0775, true);
$prefFile = $dir . '/nvr_url.json';
$ch = (int)$cam['channel'];

/* ---------- Video live (MJPEG) ---------- */
if ($mode === 'v') {
    // Format URL yang terakhir berhasil untuk NVR ini (std / old).
    $pref = is_file($prefFile) ? (json_decode((string)@file_get_contents($prefFile), true) ?: []) : [];
    $url  = cctvRtspUrl($nvr, $ch, ($pref['rtsp_' . (int)$nvr['id']] ?? 'std') === 'old' ? 'old' : 'std');
    $errFile = tempnam(sys_get_temp_dir(), 'ccv');
    $cmd = array_merge([$bin], cctvRtspInputArgs($url),
        ['-an', '-t', '900', '-vf', 'scale=960:-2', '-r', '8', '-q:v', '7', '-f', 'mpjpeg', 'pipe:1']);   // maks. 15 menit per tontonan
    $p = @proc_open($cmd, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['file', $errFile, 'w']], $pipes, null, null, ['bypass_shell' => true]);
    if (!is_resource($p)) { @unlink($errFile); $fail(500, cL('ffmpeg tidak bisa dijalankan', 'Cannot start ffmpeg')); }
    fclose($pipes[0]);
    @set_time_limit(0);
    ignore_user_abort(true);
    // Tunggu potongan pertama: bila RTSP gagal, kirim pesan error (bukan video kosong).
    $first = fread($pipes[1], 65536);
    if ($first === false || $first === '') {
        fclose($pipes[1]); proc_close($p);
        $se = (string)@file_get_contents($errFile); @unlink($errFile);
        $fail(502, cctvRtspError($se, 1));
    }
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: multipart/x-mixed-replace;boundary=ffmpeg');
    header('Cache-Control: no-store');
    header('X-Accel-Buffering: no');
    echo $first; flush();
    while (!feof($pipes[1])) {
        $buf = fread($pipes[1], 65536);
        if ($buf === false) break;
        if ($buf === '') { usleep(20000); continue; }
        echo $buf; flush();
        if (connection_aborted()) break;               // tampilan ditutup / pindah kamera
    }
    proc_terminate($p);
    fclose($pipes[1]); proc_close($p);
    @unlink($errFile);
    exit;
}

/* ---------- Frame tunggal (thumbnail / cadangan) ---------- */
$full  = $mode === 'f';
$cache = $dir . '/' . $id . '_' . ($full ? 'f' : 't') . '.jpg';
$ttl   = $full ? 2 : 20;                     // detik
$fresh = is_file($cache) && (time() - filemtime($cache)) < $ttl && filesize($cache) > 0;

// 1 permintaan RTSP sekaligus per NVR (antre maks. 15 detik) agar NVR tidak dibebani.
$lock = null;
if (!$fresh) {
    $lock = @fopen($dir . '/nvr_' . (int)$nvr['id'] . '.lock', 'c');
    $got = false;
    if ($lock) { for ($i = 0; $i < 75 && !($got = flock($lock, LOCK_EX | LOCK_NB)); $i++) usleep(200000); }
    if ($lock && !$got) {
        fclose($lock); $lock = null;
        if (is_file($cache)) { $fresh = true; header('X-Cctv-Live: stale'); }
        else $fail(503, cL('Antrian NVR penuh, coba lagi', 'NVR queue busy, try again'));
    }
    clearstatcache(true, $cache);
    if (!$fresh && is_file($cache) && (time() - filemtime($cache)) < $ttl && filesize($cache) > 0) $fresh = true;   // sudah diambil permintaan lain
}

if (!$fresh) {
    $jpg = cctvRtspFrame($nvr, $ch, $err, $full ? 1280 : 480, $prefFile);
    if ($jpg === '') {
        if (is_file($cache) && (time() - filemtime($cache)) < 120) {
            header('X-Cctv-Live: stale');     // gambar terakhir (maks. 2 menit) tetap ditampilkan
        } else {
            $fail(502, in_array($cam['state'], ['off', 'vl'], true) ? cL('Kamera mati, tidak ada gambar', 'Camera down, no image') : $err);
        }
    } else {
        $tmp = $cache . '.' . getmypid() . '.tmp';
        if (@file_put_contents($tmp, $jpg) !== false) @rename($tmp, $cache);
        else { header('Content-Type: image/jpeg'); header('Cache-Control: no-store'); echo $jpg; exit; }
    }
}

header('Content-Type: image/jpeg');
header('Cache-Control: no-store');
header('X-Cctv-Time: ' . date('H:i:s', filemtime($cache)));
readfile($cache);
