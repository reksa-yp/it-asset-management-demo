<?php
/**
 * Pengaturan Sistem (khusus admin): ubah nama aplikasi & logo.
 * Data disimpan di includes/data/app_settings.json — tidak memakai database.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();

    $current = appSettings();
    $newName = trim((string)($_POST['app_name'] ?? ''));
    $newName = function_exists('mb_substr') ? mb_substr($newName, 0, 60) : substr($newName, 0, 60);
    $logo    = $current['logo'];
    $prefix  = normalizeAssetPrefix((string)($_POST['asset_prefix'] ?? ''));
    $msg     = ['ok' => true, 'text' => t('settings_saved')];

    if (!empty($_POST['reset_all'])) {
        // Kembalikan ke bawaan: nama dari file bahasa & logo teks.
        deleteLogoFile($logo);
        $newName = '';
        $logo    = '';
        $prefix  = $current['asset_prefix']; // awalan Nomor Aset tidak ikut di-reset (supaya penomoran tetap konsisten)
        $msg     = ['ok' => true, 'text' => t('settings_reset_done')];
    } else {
        if (!empty($_POST['remove_logo'])) {
            deleteLogoFile($logo);
            $logo = '';
        }
        $upload = handleLogoUpload('logo');
        if (!$upload['ok']) {
            $msg = ['ok' => false, 'text' => t($upload['error'])];
        } elseif ($upload['file'] !== '') {
            deleteLogoFile($logo);      // hapus logo lama, ganti dengan yang baru
            $logo = $upload['file'];
        }
    }

    if ($msg['ok'] && !saveAppSettings(['app_name' => $newName, 'logo' => $logo, 'asset_prefix' => $prefix])) {
        $msg = ['ok' => false, 'text' => t('settings_save_failed')];
    }

    $_SESSION['settings_msg'] = $msg;
    header('Location: settings.php');
    exit;
}

$settingsMsg = $_SESSION['settings_msg'] ?? null;
unset($_SESSION['settings_msg']);

$settings    = appSettings();
$defaultName = (loadDictionary()['app_name'] ?? 'IT Asset Management');
$logoUrl     = appLogoUrl();

$pageTitle = t('page_title_settings');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="max-w-2xl">
    <p class="text-sm text-slate-500 mb-4"><?= t('settings_intro') ?></p>

    <?php if ($settingsMsg): ?>
        <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $settingsMsg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>">
            <?= htmlspecialchars($settingsMsg['text']) ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="bg-white rounded-xl shadow-sm divide-y">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

        <!-- Pratinjau -->
        <div class="p-5">
            <p class="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-3"><?= t('settings_preview') ?></p>
            <div class="flex items-center gap-3 bg-slate-800 rounded-lg px-4 h-16 max-w-xs">
                <div id="previewLogoBox">
                    <?php if ($logoUrl): ?>
                        <img id="previewLogoImg" src="<?= htmlspecialchars($logoUrl) ?>" class="w-8 h-8 rounded-lg object-contain bg-white p-0.5" alt="">
                    <?php else: ?>
                        <div id="previewLogoText" class="w-8 h-8 rounded-lg bg-brand-500 text-white font-bold flex items-center justify-center text-sm"><?= htmlspecialchars(appInitials()) ?></div>
                    <?php endif; ?>
                </div>
                <span id="previewName" class="font-semibold text-white truncate"><?= htmlspecialchars(t('app_name')) ?></span>
            </div>
        </div>

        <!-- Nama sistem -->
        <div class="p-5">
            <label for="app_name" class="block text-sm font-medium text-slate-700 mb-1"><?= t('settings_app_name') ?></label>
            <input type="text" id="app_name" name="app_name" maxlength="60"
                   value="<?= htmlspecialchars($settings['app_name']) ?>"
                   placeholder="<?= htmlspecialchars($defaultName) ?>"
                   class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
            <p class="text-xs text-slate-400 mt-1"><?= t('settings_app_name_hint') ?></p>
        </div>

        <!-- Awalan Nomor Aset -->
        <div class="p-5">
            <label for="asset_prefix" class="block text-sm font-medium text-slate-700 mb-1"><?= t('settings_asset_prefix') ?></label>
            <input type="text" id="asset_prefix" name="asset_prefix" maxlength="6" pattern="[A-Za-z0-9]{0,6}"
                   value="<?= htmlspecialchars($settings['asset_prefix']) ?>"
                   placeholder="<?= htmlspecialchars(APP_ASSET_PREFIX_DEFAULT) ?>"
                   class="w-40 border border-slate-300 rounded-lg px-3 py-2 text-sm uppercase focus:outline-none focus:ring-2 focus:ring-brand-500">
            <p class="text-xs text-slate-400 mt-1"><?= t('settings_asset_prefix_hint') ?></p>
        </div>

        <!-- Logo -->
        <div class="p-5">
            <label class="block text-sm font-medium text-slate-700 mb-2"><?= t('settings_logo') ?></label>
            <div class="flex items-start gap-4">
                <div class="w-20 h-20 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0" id="logoThumb">
                    <?php if ($logoUrl): ?>
                        <img src="<?= htmlspecialchars($logoUrl) ?>" class="max-w-full max-h-full object-contain" alt="">
                    <?php else: ?>
                        <span class="text-slate-300"><?= icon('upload', 'w-6 h-6') ?></span>
                    <?php endif; ?>
                </div>
                <div class="flex-1 min-w-0 space-y-2">
                    <input type="file" name="logo" id="logoInput" accept="image/png,image/jpeg,image/webp,image/gif"
                           class="block w-full text-sm text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-slate-100 file:px-3 file:py-2 file:text-sm file:font-medium file:text-slate-700 hover:file:bg-slate-200">
                    <p class="text-xs text-slate-400"><?= t('settings_logo_hint') ?></p>
                    <?php if ($logoUrl): ?>
                        <label class="inline-flex items-center gap-2 text-sm text-red-600">
                            <input type="checkbox" name="remove_logo" value="1" class="rounded border-slate-300">
                            <?= t('settings_remove_logo') ?>
                        </label>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="form-actions-sticky p-5 flex flex-wrap items-center justify-between gap-3 rounded-b-xl">
            <button type="submit" name="reset_all" value="1"
                    onclick="return confirm('<?= htmlspecialchars(t('settings_reset_confirm'), ENT_QUOTES) ?>')"
                    class="text-sm text-slate-500 hover:text-red-600"><?= t('settings_reset') ?></button>
            <button type="submit" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
                <?= icon('check') ?> <?= t('btn_save') ?>
            </button>
        </div>
    </form>
</div>

<script>
// Pratinjau langsung saat nama diketik / logo dipilih (sebelum disimpan).
(function () {
    const nameInput = document.getElementById('app_name');
    const previewName = document.getElementById('previewName');
    const defaultName = <?= json_encode($defaultName) ?>;
    nameInput.addEventListener('input', () => {
        previewName.textContent = nameInput.value.trim() || defaultName;
    });

    const logoInput = document.getElementById('logoInput');
    logoInput.addEventListener('change', () => {
        const file = logoInput.files[0];
        if (!file) return;
        const url = URL.createObjectURL(file);
        document.getElementById('previewLogoBox').innerHTML =
            '<img src="' + url + '" class="w-8 h-8 rounded-lg object-contain bg-white p-0.5" alt="">';
        document.getElementById('logoThumb').innerHTML =
            '<img src="' + url + '" class="max-w-full max-h-full object-contain" alt="">';
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
