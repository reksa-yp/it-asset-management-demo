# Panduan Menu CCTV: monitoring, notifikasi email, checklist & laporan

Menu **CCTV** memantau status kamera lewat NVR (Hikvision / Dahua) atau IP kamera, mencatat log kamera mati,
mengirim notifikasi (pop-up web admin + email), dan menggantikan form checklist kertas (cetak / PDF / Excel,
per shift dan rekap bulanan, per NVR).

## 1. Pasang update

1. Backup dulu: export database lewat phpMyAdmin dan salin folder `C:\xampp\htdocs\asker-it-asset`.
2. Ekstrak `update_cctv_monitoring_checklist.zip` ke `C:\xampp\htdocs\asker-it-asset\` → pilih **timpa**.
3. Login sebagai admin → menu **CCTV** muncul di sidebar (di bawah Aset Rusak). Tekan **Ctrl+F5**.
4. Tabel baru dibuat otomatis saat menu dibuka pertama kali (tabel lama tidak diubah):
   `cctv_nvr, cctv_cameras, cctv_status, cctv_events, cctv_notices, cctv_check_items, cctv_checklists,
   cctv_checklist_results, user_cctv_access, cctv_checklist_nvr, cctv_nvr_assets, asset_cctv_info, cctv_reports, cctv_holidays, cctv_snapshots, cctv_email_log`.

## 2. Siapkan data kamera (menu Asset)

1. **Kategori Aset** → tambah kategori **CCTV** (nama kategori harus mengandung kata CCTV / Kamera / Camera).
2. **Kategori Aset** → tambah juga kategori **NVR** (nama mengandung NVR / DVR / XVR).
3. **Daftarkan NVR dulu sebagai aset**: Asset → filter **NVR** → **+ Tambah Aset**. Form NVR berisi:
   **Nama NVR**, **Lokasi**, **IP Address**, **Port HTTP NVR** (kosong = 80), **Brand**, **Type**, **Serial Number**,
   **Tanggal Pembelian**, **Username NVR** & **Password NVR** (untuk monitoring).
   - Saat disimpan, NVR **otomatis terdaftar di CCTV → Pengaturan → NVR** (tertulis "dari aset IT/STOK/NVR/001").
   - Edit aset NVR = data NVR di menu CCTV ikut berubah. Password dikosongkan = tidak diubah.
   - Hapus aset NVR = NVR di menu CCTV ikut terhapus dan kamera di NVR itu menjadi "tanpa NVR".
   - Merk Hikvision/HiLook → metode Hikvision, Dahua/Imou → Dahua, merk lain → cek port saja.
4. **Daftarkan kamera**: Asset → filter **CCTV** → **+ Tambah Aset**. Form CCTV berisi:
   **Nama CCTV**, **Lokasi**, **IP Address**, **Brand**, **Type**, **Masuk ke NVR** dan **Channel NVR**.
   - Pilih NVR tempat kamera terhubung + nomor channel (D1 = 1, D2 = 2, ...). Kamera langsung masuk ke
     menu CCTV (monitoring, checklist, laporan) di bawah NVR tersebut. Tanpa NVR = dicek lewat IP kamera.
   - Nomor aset dibuat otomatis saat disimpan (format `IT/STOK/CCTV/001`: DG = Digunakan tanpa departement,
     STOK = status Stok), status otomatis **Digunakan**.
   - Lokasi = nama yang tampil di monitoring, checklist, email & laporan.
   - Brand & Type disimpan di tabel baru `asset_cctv_info`, dan juga ditulis ke kolom "Brand Type" aset.
   - Di daftar aset, aset CCTV & NVR mendapat tombol **Web** (membuka halaman web perangkat) sebagai pengganti VNC.

### Input cepat dari Excel (banyak kamera sekaligus)

1. Asset → filter **CCTV** atau **NVR** → tombol **Import CCTV / NVR** (atau Import dari Excel → bagian *Import CCTV & NVR*).
2. Unduh **Template kosong** (atau **Template + data yang ada** untuk mengubah banyak kamera sekaligus).
3. Isi sheet **NVR** (opsional) dan sheet **CCTV**:
   - CCTV: Nomor Aset (kosong = otomatis), **Nama CCTV**, **Lokasi**, IP Address, Brand, Type, **NVR** (pilih dari daftar),
     **Channel** (1 atau D1), Status (Digunakan / Stok / Tidak Digunakan, kosong = Digunakan).
   - NVR: Nomor Aset, **Nama NVR**, Lokasi, IP, Port HTTP, Brand, Type, Serial Number, Tanggal Pembelian, Username & Password NVR, Status.
   - Kolom NVR di sheet CCTV boleh menyebut NVR yang baru ditulis di sheet NVR pada file yang sama.
4. Upload → muncul **preview**: baris *Baru*, *Diperbarui*, *Error* (dengan alasannya) dan peringatan. Klik **Simpan N baris**.
   Baris error dilewati; perbaiki di Excel lalu upload ulang.
5. Aturan update: Nomor Aset atau IP yang sudah ada (kamera tanpa IP: nama + lokasi sama) = data lama diperbarui.
   Sel kosong = data lama tetap; isi **-** untuk mengosongkan (mis. NVR "-" = lepas dari NVR). Password NVR kosong = tidak diubah.

## 3. User NVR & tes koneksi (CCTV → Pengaturan → 1. NVR / DVR)

NVR dari aset sudah muncul di sini. NVR juga masih bisa ditambah langsung di halaman ini (tanpa aset).

1. Di NVR, buat **user khusus** untuk aplikasi (lebih aman dari memakai admin):
   - Hikvision: Configuration → System → User Management → Add → level **Operator** / **User**.
   - Dahua: Setting → System → Account → Add user → group **user**.
2. Isi username/password user tadi di aset NVR (atau di sini): Nama, Merk (Hikvision / Dahua / *Merk lain: cek port saja*), IP NVR, port HTTP
   (biasanya **80**), username & password user tadi → **Simpan NVR**.
3. Klik **Tes koneksi** → harus muncul `NVR online · N channel terbaca` + daftar `ch1=Online, ch2=...`.

> Hati-hati: Hikvision mengunci user setelah beberapa kali password salah. Jika tes gagal "Login NVR gagal",
> cek ulang password sebelum mencoba lagi.

## 4. Pemetaan kamera (Pengaturan → 2. Pemetaan kamera)

Pemetaan NVR + channel sudah terisi dari form aset CCTV. Halaman ini untuk cek ulang / ubah sekaligus banyak kamera.

- Kamera di port PoE NVR / lewat NVR: pilih **NVR** + isi **Channel** (nomor kamera di NVR, mis. D1 = 1, D2 = 2).
- Kamera di switch tanpa NVR: biarkan NVR kosong; IP diambil dari data aset (boleh diisi lain), port kosong = 554/80.
- Hilangkan centang **Pantau** untuk kamera yang memang tidak dipakai.
- **Simpan pemetaan**, lalu buka **Monitoring → Cek sekarang**. Semua kamera harus berstatus Online / Offline (bukan "Belum dipantau").

## 5. Notifikasi email (Pengaturan → 3)

Gmail (akun Google kantor / pribadi khusus IT):
1. Aktifkan **2-Step Verification** di akun Google.
2. Buka myaccount.google.com → Security → **App passwords** → buat (nama: IT System CCTV) → salin 16 huruf.
3. Isi: host `smtp.gmail.com`, port `587`, keamanan `TLS`, user = alamat Gmail, password = App Password,
   penerima = email IT/GA (pisahkan koma) → centang **Kirim notifikasi email** → **Simpan & kirim email tes**.

Mail server kantor: isi host/port/user dari penyedia email kantor (umumnya 587 TLS atau 465 SSL).
Server harus bisa terhubung ke internet / mail server lewat port tersebut.

Email dikirim jika kamera sudah **mati / video loss selama 30 menit** (bisa diubah: langsung, 5, 10, 15, 30, 60, 120 menit),
sekali per kejadian, dan saat kamera itu **hidup kembali**. Gangguan singkat (< 30 menit) tidak mengirim email, tetapi tetap muncul
sebagai pop-up web dan tercatat di log. Beberapa kamera yang mencapai 30 menit bersamaan dikirim dalam **satu** email.

**Monitoring realtime**: halaman Monitoring memperbarui angka, kartu kamera & tabel NVR sendiri (tanda ● Live) begitu ada hasil cek baru,
tanpa perlu refresh. Kartu kamera mati menampilkan lama mati dan jam email akan / sudah dikirim.
Agar lebih realtime, jadwalkan Task Scheduler **setiap 1 menit** (bagian 6).

## 6. Jadwal pengecekan otomatis (Task Scheduler di server)

**Cara cepat (disarankan):** di server buka `C:\xampp\htdocs\asker-it-asset\scripts\`, klik kanan **`pasang_jadwal_cctv.bat`**
→ **Run as administrator**. Task **"Cek CCTV IT System"** dibuat otomatis (tiap 1 menit, akun SYSTEM, tanpa password),
langsung dijalankan sekali, lalu status & log ditampilkan. Selesai, langkah manual di bawah tidak perlu.

Cara manual:

1. Task Scheduler → **Create Task**.
2. General: nama `Cek CCTV IT System`, **Run whether user is logged on or not**, centang **Run with highest privileges**.
3. Triggers → New: **Daily**, mulai 00:00, centang **Repeat task every 1 minute** (atau 2 minutes) for a duration of **Indefinitely**.
4. Actions → New → Start a program: `C:\xampp\htdocs\asker-it-asset\scripts\cctv_check.bat`
   (Start in: `C:\xampp\htdocs\asker-it-asset\scripts`).
5. Settings: **Do not start a new instance** jika task masih berjalan.
6. OK → isi password akun Windows → klik kanan task → **Run**.
7. Cek di **CCTV → Monitoring**: "Cek terakhir" harus berubah tiap 2 menit. Log: `includes\data\cctv_check_log.txt`.

Jika XAMPP tidak di `C:\xampp`, ubah `PHP_EXE` dan `APP_DIR` di `scripts\cctv_check.bat`.

## 7. User khusus CCTV (Security / user lain)

Management User → Ubah / tambah user (role **User**) → centang **Akses CCTV (Checklist & Lapor)** → Simpan.
User itu mendapat menu **CCTV (Checklist & Lapor)** dengan 3 tab:
- **Checklist**: melihat & mencetak checklist; mengisi hanya pada shift yang diatur untuk user CCTV (default tidak ada, lihat bagian 8).
- **Lapor CCTV mati**: pilih kamera, jenis masalah (mati, buram, posisi bergeser, IR, rusak fisik, lainnya),
  keterangan & foto → **Kirim laporan**. Laporan langsung muncul sebagai pop-up di web admin dan dikirim ke
  email notifikasi. Di halaman ini user juga melihat status kamera saat ini (hanya lihat) dan riwayat laporannya.
- **Cetak checklist**: cetak / PDF / Excel checklist per shift.

Monitoring, log, laporan bulanan & pengaturan tetap khusus admin. Admin menindaklanjuti di
**CCTV → Laporan petugas** → isi keterangan → **Tandai selesai** (pelapor melihat statusnya berubah).
- **Pilih & cetak laporan**: di Laporan petugas, centang beberapa laporan (atau centang judul kolom untuk semua yang tampil),
  lalu **Cetak terpilih** atau **Simpan PDF**. Dokumen A4 mendatar dengan kop surat, kolom NVR/IP, kolom kosong
  "Tindakan / paraf" untuk teknisi, dan 3 tanda tangan.

## 8. Pemakaian harian

- **Checklist 2x sehari**: **Pagi** dan **Sore**, keduanya diisi **Admin IT** (tidak ada checklist malam).
  Halaman checklist otomatis memilih Pagi sebelum jam 12:00 dan Sore sesudahnya. Rekap bulanan menghitung 2 checklist per hari.
  Pengaturan lama (Pagi, Siang/Sore, Malam) otomatis menjadi Pagi, Sore. Checklist Malam yang sudah terisi tetap tersimpan di database.
  Jika suatu saat perlu, shift & petugasnya bisa diubah di **CCTV → Pengaturan → 4** (nama shift dipisah koma; pilihan
  pengisi per shift: Admin IT / User CCTV yang ditunjuk / Admin & user CCTV).
- **Hari libur checklist** (CCTV → Pengaturan → 6): **Sabtu & Minggu** otomatis libur (bisa diubah per hari).
  Libur nasional, cuti bersama & cuti perusahaan diisi manual: Tanggal (+ "Sampai" untuk beberapa hari) + Keterangan → **Tambah**.
  Pada hari libur checklist tidak wajib: tidak dihitung "terlewat", ditandai **L** merah dengan kolom merah muda di rekap bulanan (cetak, PDF & Excel), dan daftar liburnya ikut tercetak.
  Checklist tetap bisa diisi bila ada pengecekan (halaman checklist menampilkan keterangan biru "Hari libur").
- **Checklist susulan** (Pengaturan → 6 → "Isi checklist susulan", `cctv_isi_susulan.php`): mengisi checklist hari-hari yang lalu
  sekaligus dengan hasil semua kamera OK. Hari libur dan shift yang sudah terisi dilewati; petugas diberi tanda "(susulan)".
- **Checklist**: pilih tanggal, shift & **NVR yang dicek** (default NVR pertama; bisa "Semua NVR"). Tiap NVR tercatat petugas & jam ceknya sendiri, jadi beberapa petugas bisa mengecek NVR berbeda di shift yang sama → klik tombol item (✓ OK, klik lagi ✗ bermasalah) → kamera bermasalah wajib
  diberi keterangan, foto opsional (di HP langsung buka kamera) → **Simpan checklist**. Tombol
  "Tandai semua kamera online OK" mempercepat pengisian. Checklist yang sama bisa diedit lagi.
- **Temuan checklist otomatis jadi laporan**: kamera yang item-nya ditandai ✗ (mis. posisi tidak lurus, gambar buram)
  otomatis masuk ke **Laporan petugas** dengan status *Belum ditangani* dan label "dari checklist", berisi masalah,
  keterangan & foto dari checklist, lalu muncul pop-up di web admin. Menyimpan ulang checklist yang sama memperbarui
  laporan itu (tidak dobel). Laporan ditutup lewat **Tandai selesai** seperti laporan biasa.
- **Monitoring** menampilkan IP kamera di setiap kartu.
- **Log CCTV mati**: riwayat otomatis mati/hidup + durasi; admin bisa menambah keterangan perbaikan.
  Yang dicatat hanya kamera yang mati **lebih dari batas menit email** (Pengaturan > Notifikasi email >
  "Kirim email jika kamera mati selama", bawaan 30 menit). Gangguan singkat di bawah batas tidak masuk log & rekap.
  Pilih "Langsung" bila ingin semua gangguan tercatat.
- **Cetak & laporan**:
  - *Per shift*: pengganti form kertas (A4 portrait) dengan kop & 3 tanda tangan, **dipisah per NVR** (1 halaman / 1 sheet Excel per NVR; tanda tangan "Diperiksa oleh" = petugas NVR itu). Bisa juga pilih 1 NVR saja.
  - Rekap bulanan bisa difilter per NVR; tanpa filter, tabel dikelompokkan per NVR.
  - *Rekap bulanan*: kamera × tanggal (✓/✗), shift yang terlewat, temuan, uptime, log mati (A4 landscape).
  - Per shift dan rekap bulanan sama-sama punya **Cetak langsung**, **Simpan PDF**, dan **Export Excel**.
  - **Cetak / PDF rekap bulanan** (A4 landscape, ukuran tetap, tidak mengecil seperti hasil cetak Excel) dipisah per NVR:
    1. **VIEW NVR** — gambar multi-view selebar kertas, IP NVR lokal & publik, dan daftar kamera 2 kolom, semuanya 1 halaman.
    2. **Rekap** — kamera × tanggal, 1 halaman per NVR (ukuran baris & huruf menyesuaikan jumlah kamera; NVR 64 kamera memakai huruf lebih kecil).
    3. **Log CCTV mati** — halaman terpisah per NVR (judul kolom diulang bila lebih dari 1 halaman).
    4. Di akhir: **Temuan & laporan petugas** serta pekerjaan CCTV.
    Kop surat dipadatkan khusus laporan ini; bila kop belum diisi (menu Kop Surat), ruang kop ikut dikecilkan.
  - **Export Excel** rekap bulanan berisi cover **VIEW_<NVR>** dan **Rekap <NVR>**
    (1 sheet per NVR, juga saat memilih Semua NVR; halaman 2 tiap sheet Rekap = Log CCTV mati kamera NVR itu),
    lalu Temuan, Detail Checklist, Laporan Petugas.
- **Dashboard** menampilkan peringatan merah jika ada CCTV mati.

### List View CCTV (snapshot per kamera)

- Menu **CCTV → List View**: galeri snapshot tiap kamera + type, channel, IP, status & uptime, dikelompokkan per NVR.
- Snapshot diambil **lewat NVR** (Hikvision ISAPI / Dahua snapshot.cgi), tidak perlu password tiap kamera:
  - otomatis **Senin pertama tiap bulan mulai jam 09:00** oleh Task Scheduler (`cctv_check.bat`); jika hari itu server mati,
    diambil pada pengecekan berikutnya. Jadwal bisa diubah di halaman List View (Senin pertama / setiap hari / nonaktif, jam mulai).
    Tersimpan 1 gambar per kamera per bulan di `assets\uploads\cctv\snap\YYYY-MM\` (ikut backup lengkap);
  - atau manual: tombol **Ambil snapshot sekarang** (semua NVR / NVR yang dipilih).
- Kamera tanpa NVR / tanpa channel memakai **foto checklist** bulan itu (jika ada).
- **Unduh Excel** = laporan bulanan format List View: **1 sheet per NVR** (baris pertama data NVR, lalu kamera urut channel,
  kolom VIEW CCTV berisi gambar). Pilih bulan & NVR sebelum mengunduh.
- User NVR cukup level **Operator/User** dengan hak *Live View* / *Remote Preview* untuk mengambil snapshot.
- **Cover checklist**: Export Excel rekap bulanan (Cetak & laporan) otomatis berisi sheet **VIEW_<NVR>** di depan, 1 per NVR:
  judul "NVR 1 (64CH)", gambar multi-view (disusun dari snapshot bulan itu, urut channel), IP NVR lokal & publik, lalu tabel
  2 kolom NO | LOKASI | CHANNEL | IP ADDRESS | DEVICE TYPE (A4 landscape, 1 halaman). IP publik diisi di halaman List View.

## 9. Pemecahan masalah

| Gejala | Penyebab umum | Solusi |
|---|---|---|
| Tes koneksi: "NVR tidak merespons" | IP/port salah, NVR beda jaringan, firewall | Buka `http://IP-NVR` dari browser server; samakan port HTTP |
| "Login NVR gagal" | User/password salah, user terkunci | Cek user di NVR, tunggu kunci terbuka (Hikvision ±30 menit) |
| "NVR online, tetapi daftar channel tidak terbaca" | Firmware lama / API mati / DVR analog tertentu | Pilih merk "cek port saja" dan pantau lewat IP kamera |
| Semua kamera satu NVR offline bersamaan | NVR mati / listrik / switch NVR | Cek NVR; log mencatat "NVR tidak merespons" |
| "Cek terakhir" tidak berubah | Task Scheduler belum jalan / salah path | Lihat bagian 6 dan `includes\data\cctv_check_log.txt` |
| Email gagal (pesan SMTP) | App Password salah, port diblok, belum 2-Step | Ulangi bagian 5; coba port 465 SSL |
| Foto checklist tidak tersimpan | Foto > 8 MB atau batas upload PHP | Naikkan `upload_max_filesize` & `post_max_size` di `C:\xampp\php\php.ini` (mis. 64M), restart Apache |
| "Login NVR gagal" padahal password benar | Ekstensi curl PHP mati (NVR baru wajib Digest auth) | `C:\xampp\php\php.ini`: pastikan `extension=curl` tanpa titik koma, restart Apache |
| Jam di log/email mundur 5-6 jam | XAMPP bawaan memakai zona Europe/Berlin | Sudah dipaksa WIB sejak update ini. Data lama: jalankan `scripts\perbaiki_jam_cctv.sql` sekali. Disarankan juga `php.ini`: `date.timezone = Asia/Jakarta`, restart Apache |

## 10. Catatan

- Notifikasi di aplikasi Android berbunyi saat aplikasi sedang terbuka; saat HP terkunci, andalkan **email**
  (aktifkan notifikasi aplikasi email di HP).
- Password NVR & SMTP disimpan di database / `includes\data\cctv_settings.json` (folder ini diblok dari browser).
  Batasi akses ke file backup untuk tim IT.
- Saat backup, sertakan tabel CCTV (database) dan folder foto `assets\uploads\cctv`.
  Batasi akses folder backup NAS untuk tim IT.
- Backup lengkap (`backup_to_nas.bat`) otomatis ikut menyimpan tabel CCTV dan foto checklist (`assets\uploads\cctv`).

## Live preview (RTSP sub-stream)

Thumbnail kamera di Monitoring dan video **Lihat live** diambil dari **RTSP sub-stream** NVR memakai **ffmpeg** di server.
RTSP terpisah dari web NVR, jadi tetap jalan walau halaman web NVR bermasalah, dan tidak butuh plugin/Internet Explorer.

1. Unduh ffmpeg untuk Windows (paket *ffmpeg-release-essentials.zip* dari gyan.dev), ekstrak sehingga ada
   `C:\xampp\ffmpeg\bin\ffmpeg.exe`. Lokasi lain bisa diisi di CCTV > Pengaturan > 1 (kotak "Live preview").
2. CCTV > Pengaturan > 1: isi **Port RTSP** tiap NVR (bawaan 554), lalu klik **Tes RTSP** (isi nomor channel) —
   harus muncul "RTSP berhasil".
3. Alamat yang dipakai: Hikvision `rtsp://user:pass@IP:554/Streaming/Channels/{ch}02` (cadangan firmware lama
   `/h264/ch{ch}/sub/av_stream`), Dahua `.../cam/realmonitor?channel={ch}&subtype=1`.

Pesan Tes RTSP: *Login RTSP ditolak* = user/password; *Channel tidak ditemukan* = nomor channel/format; *Port RTSP ditolak*
= port salah; *timeout* = NVR tidak merespons RTSP. ffmpeg hanya berjalan selama gambar/video dibuka.
