<?php
/**
 * Berita Acara Serah Terima Barang (stok) — A4 dengan kop surat, dialog print otomatis.
 *   stock_handover_print.php?id=12            -> semua Barang Keluar untuk penerima & tanggal yang sama dengan transaksi #12
 *   stock_handover_print.php?id=12&single=1   -> hanya transaksi #12
 * Kalau barang yang diserahkan punya ID Aset, bagian "Detail Aset" ditampilkan sebelum daftar barang
 * (isi sama dengan detail aset; khusus Tablet tanpa Serial Number OS & Status OS).
 * Selalu 1 halaman A4: kop dipadatkan, detail aset ringkas (>2 aset = tabel ringkas), dan ukuran isi
 * diperkecil otomatis (JS) bila masih melebihi 1 halaman.
 * Hanya MEMBACA data. Tidak ada tabel/kolom baru.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/letterhead.php';
require_once __DIR__ . '/includes/stock.php';
require_once __DIR__ . '/includes/asset_accessories.php';

$db = getDB();
ensureStockTables($db);
$h    = fn($v) => htmlspecialchars((string)$v);
$dash = t('dash');
$id   = (int)($_GET['id'] ?? 0);
$single = !empty($_GET['single']);

$sel = "SELECT t.*, c.name AS category_name, c.unit FROM stock_transactions t JOIN stock_categories c ON c.id = t.category_id";
$idsParam = array_values(array_unique(array_filter(array_map('intval', explode(',', (string)($_GET['ids'] ?? ''))), fn($n) => $n > 0)));
$groups = [];
if ($idsParam) {
    // Beberapa transaksi terpilih: kelompokkan per penerima + tanggal, 1 berita acara (1 halaman) per kelompok.
    $in = implode(',', array_fill(0, count($idsParam), '?'));
    $st = $db->prepare("$sel WHERE t.type = 'out' AND t.id IN ($in) ORDER BY t.trx_date, t.id");
    $st->execute($idsParam);
    foreach ($st->fetchAll() as $r) {
        $who = !empty($r['user_id']) ? 'u' . (int)$r['user_id'] : (trim((string)$r['recipient_name']) !== '' ? 'n' . trim((string)$r['recipient_name']) : 'x' . (int)$r['id']);
        $groups[$r['trx_date'] . '|' . $who][] = $r;
    }
    $groups = array_values($groups);
    if (!$groups) { http_response_code(404); die($h(t('stock_ba_err_not_found'))); }
} else {
    $st = $db->prepare("$sel WHERE t.id = ? AND t.type = 'out'");
    $st->execute([$id]);
    $main = $st->fetch();
    if (!$main) { http_response_code(404); die($h(t('stock_ba_err_not_found'))); }
    $rows = [$main];
    if (!$single) {
        if (!empty($main['user_id'])) {
            $st = $db->prepare("$sel WHERE t.type = 'out' AND t.trx_date = ? AND t.user_id = ? ORDER BY t.id");
            $st->execute([$main['trx_date'], (int)$main['user_id']]);
            $rows = $st->fetchAll() ?: [$main];
        } elseif (trim((string)$main['recipient_name']) !== '') {
            $st = $db->prepare("$sel WHERE t.type = 'out' AND t.trx_date = ? AND t.user_id IS NULL AND t.recipient_name = ? ORDER BY t.id");
            $st->execute([$main['trx_date'], $main['recipient_name']]);
            $rows = $st->fetchAll() ?: [$main];
        }
    }
    $groups = [$rows];
}
$multi = count($groups) > 1;
$firstRows = $groups[0];
$baNo0 = 'BA-STK/' . date('Ym', strtotime($firstRows[0]['trx_date'])) . '/' . str_pad((string)min(array_map(fn($r) => (int)$r['id'], $firstRows)), 4, '0', STR_PAD_LEFT);

$kopTop    = (function_exists('letterheadHas') && !letterheadHas('header')) ? 12 : 22;   // ruang kop atas/bawah (mm)
$kopBottom = (function_exists('letterheadHas') && !letterheadHas('footer')) ? 12 : 17;
?>
<!DOCTYPE html>
<html lang="<?= $h(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $h(t('stock_ba_title') . ' ' . $baNo0) ?></title>
<style>
    @page { size: A4; margin: 0; }
    body { font-family: Arial, sans-serif; color: #1e293b; margin: 24px; font-size: 11px; }
    .fit { width: 182mm; margin: 0 auto; }
    .ba-page { page-break-after: always; break-after: page; } .ba-page:last-of-type { page-break-after: auto; break-after: auto; }
    .head { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 1.5px solid #173A68; padding-bottom: 4px; margin-bottom: 8px; }
    .brand { display: flex; align-items: center; gap: 10px; }
    .brand .name { font-size: 12px; font-weight: bold; color: #1e293b; }
    .muted { color: #64748b; }
    h1 { text-align: center; font-size: 14px; margin: 2px 0 1px; letter-spacing: .5px; }
    .no { text-align: center; margin-bottom: 6px; }
    p { margin: 4px 0; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #cbd5e1; padding: 2px 5px; text-align: left; vertical-align: top; }
    th { background: #eef2ff; }
    .r { text-align: right; }
    .kv td:first-child { width: 38%; color: #475569; background: #f8fafc; }
    .kv4 td.k { width: 15%; color: #475569; background: #f8fafc; }
    .kv4 td.v { width: 35%; }
    .two { display: flex; gap: 10px; margin: 6px 0; }
    .two > div { flex: 1; }
    .box-title { font-weight: bold; margin: 8px 0 3px; }
    .asset-box { border: 1px solid #cbd5e1; border-radius: 4px; padding: 5px 7px; margin-bottom: 6px; }
    .asset-box .ttl { font-weight: bold; font-size: 11.5px; }
    .asset-box table { font-size: 10px; margin-top: 3px; }
    .asset-box td { padding: 1px 5px; }
    table.sumtbl { font-size: 9.5px; }
    table.sumtbl td, table.sumtbl th { padding: 2px 4px; }
    tfoot td { font-weight: bold; background: #f8fafc; }
    .sign { display: flex; justify-content: space-between; margin-top: 12px; text-align: center; }
    .sign > div { width: 23%; }
    .sign .line { margin-top: 36px; border-top: 1px solid #334155; padding-top: 3px; font-weight: bold; }
    .small { font-size: 10px; }
    .no-print { margin-top: 20px; text-align: center; }
    .no-print button, .no-print a { display: inline-block; background: #1F3DD1; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 13px; cursor: pointer; text-decoration: none; margin: 0 4px; }
    .no-print a { background: #fff; color: #1F3DD1; border: 1px solid #1F3DD1; }
    @media print { body { margin: 0; } .no-print { display: none; } tr { page-break-inside: avoid; } }
<?= letterheadCss() ?>
<?php /* Kop dipadatkan supaya ruang isi cukup untuk 1 halaman (bila kop kosong, ruangnya ikut dikecilkan). */ ?>
    .lh-header img { width: auto !important; height: 12mm !important; } .lh-footer img { width: auto !important; height: 6mm !important; }
    .lh-footer td { font-size: 6pt !important; line-height: 1.25 !important; }
    @media print { .lh-header { top: 8mm; height: 12mm; } .lh-footer { bottom: 5mm; height: 12mm; } .lh-space-top { height: <?= $kopTop ?>mm; } .lh-space-bottom { height: <?= $kopBottom ?>mm; } }
</style>
</head>
<body>
    <?= letterheadOpen() ?>
<?php foreach ($groups as $gi => $rows):
$main = $rows[0];
$trxAssets = getStockTrxAssets($db, array_column($rows, 'id'));
$totalQty  = array_sum(array_map(fn($r) => (int)$r['qty'], $rows));
$firstId   = min(array_map(fn($r) => (int)$r['id'], $rows));

// ===== Detail aset yang ikut diserahkan =====
$detailAssets = [];
foreach ($rows as $r) {
    foreach ($trxAssets[(int)$r['id']] ?? [] as $la) {
        $a = getAssetForCurrentUser((int)$la['id']);
        if ($a) $detailAssets[(int)$a['id']] = $a;
    }
}
$accessoryMap = $detailAssets ? getAccessoryItemsForAssets($db, array_values($detailAssets)) : [];
$tabletIds    = array_keys(array_filter($detailAssets, fn($a) => isTabletCategory($a['category'])));
$tabletMap    = ($tabletIds && function_exists('getTabletDetailsMap')) ? getTabletDetailsMap($db, $tabletIds) : [];
$categoryLabels = ['Desktop PC' => t('cat_desktop'), 'Laptop' => t('cat_laptop'), 'Printer' => t('cat_printer'), 'Monitor' => t('cat_monitor'), 'Aksesoris' => t('cat_accessory')];
$statusLabels   = ['Digunakan' => t('status_used'), 'Stok' => t('status_stock'), 'Tidak Digunakan' => t('status_unused')];
$v = fn($x) => $h(($x ?? '') !== '' ? $x : $dash);

$ts      = strtotime($main['trx_date']);
$baNo    = 'BA-STK/' . date('Ym', $ts) . '/' . str_pad((string)$firstId, 4, '0', STR_PAD_LEFT);
$days    = currentLang() === 'id' ? ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'] : ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
$months  = currentLang() === 'id'
    ? ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
    : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
$dayName  = $days[(int)date('w', $ts)];
$longDate = date('j', $ts) . ' ' . $months[(int)date('n', $ts) - 1] . ' ' . date('Y', $ts);

$recipient = trim((string)$main['recipient_name']);
$recDept   = trim((string)$main['recipient_department']);
$recPos    = '';
if (!empty($main['user_id'])) {
    try { $recPos = getUserPosition($db, (int)$main['user_id']); } catch (Throwable $e) { $recPos = ''; }
}
$giver    = currentUser()['full_name'] ?? 'Admin IT';
$giverPos = '';
if (!empty(currentUser()['id'])) {
    try { $giverPos = getUserPosition($db, (int)currentUser()['id']); } catch (Throwable $e) { $giverPos = ''; }
}
?>
    <div class="ba-page"><div class="fit" id="fit<?= $gi ?>">
    <div class="head">
        <div class="brand"><div class="name"><?= $h(t('stock_ba_title')) ?></div></div>
        <div class="muted" style="text-align:right"><?= htmlspecialchars(documentCreatedAt()) ?></div>
    </div>

    <h1><?= $h(mb_strtoupper(t('stock_ba_title'))) ?></h1>
    <div class="no"><?= t('mut_ba_number') ?>: <b><?= $h($baNo) ?></b></div>

    <p><?= $h(t('stock_ba_opening', $dayName, $longDate)) ?></p>

    <div class="two">
        <div>
            <div class="box-title"><?= t('mut_ba_from') ?></div>
            <table class="kv">
                <tr><td><?= t('stock_ba_name') ?></td><td><?= $h($giver) ?></td></tr>
                <tr><td><?= t('th_position') ?></td><td><?= $h($giverPos ?: $dash) ?></td></tr>
                <tr><td><?= t('lbl_department') ?></td><td><?= $h(t('stock_ba_it_dept')) ?></td></tr>
            </table>
        </div>
        <div>
            <div class="box-title"><?= t('mut_ba_to') ?></div>
            <table class="kv">
                <tr><td><?= t('stock_ba_name') ?></td><td><b><?= $h($recipient ?: $dash) ?></b></td></tr>
                <tr><td><?= t('th_position') ?></td><td><?= $h($recPos ?: $dash) ?></td></tr>
                <tr><td><?= t('lbl_department') ?></td><td><?= $h($recDept ?: $dash) ?></td></tr>
            </table>
        </div>
    </div>

    <?php if ($detailAssets): ?>
    <div class="box-title"><?= t('stock_ba_asset_detail') ?></div>
    <?php
    // Hanya isian yang terisi yang ditampilkan (kosong / "-" dilewati), sesuai jenis asetnya.
    $filled = fn($x) => trim((string)($x ?? '')) !== '' && trim((string)$x) !== '-';
    $accOf = function (array $a) use ($accessoryMap) {
        $acc = $accessoryMap[(int)$a['id']] ?? [];
        return $acc ? implode(', ', array_map(fn($x) => $x['name'] . ($x['brand'] !== '' ? ' (' . $x['brand'] . ')' : ''), $acc)) : (string)($a['accessories'] ?? '');
    };
    $softOf = function (array $a) use ($h) {
        $out = [];
        foreach (($a['software_items'] ?? []) as $si) {
            $out[] = $h($si['software_name']) . (trim((string)$si['serial_number']) !== '' ? ' (' . $h($si['serial_number']) . ')' : '') . ' — ' . $h($si['status'] === 'Original' ? t('os_original') : t('os_not_original'));
        }
        return implode('; ', $out);
    };
    // Daftar [label, nilai-html] yang terisi untuk 1 aset
    $fieldsOf = function (array $a) use ($db, $h, $filled, $accOf, $categoryLabels, $tabletMap) {
        $isTab = isTabletCategory($a['category']); $tab = $tabletMap[(int)$a['id']] ?? [];
        $f = [];
        $add = function ($label, $val, $html = false) use (&$f, $filled, $h) { if ($filled($val)) $f[] = [$label, $html ? (string)$val : $h($val)]; };
        $add(t('lbl_asset_number'), $a['asset_number']);
        $add(t('lbl_asset_type'), $categoryLabels[$a['category']] ?? $a['category']);
        $add(t('lbl_device_name'), $a['device_name']);
        $add(t('lbl_user'), $a['owner_name'] ?? '');
        $add(t('lbl_department'), $a['department']);
        $add(t('field_position'), assetOwnerPositions($db, (int)$a['id']));
        $add(t('lbl_location'), $a['location']);
        $add(t('lbl_purchase_date'), !empty($a['purchase_date'] ?? null) ? date('d M Y', strtotime($a['purchase_date'])) : '');
        $add(t('lbl_ip_address'), $a['ip_address']);
        $add(t('lbl_hostname'), $a['hostname']);
        $add(t('lbl_os'), $a['os_name']);
        if ($isTab) {
            $add(t('tablet_lbl_serial'), $a['serial_number']);
            $add(t('tablet_lbl_id'), $tab['tablet_id'] ?? '');
            if ($filled($tab['tablet_condition'] ?? '')) $add(t('tablet_lbl_condition'), ($tab['tablet_condition'] ?? 'Bagus') === 'Rusak' ? t('tablet_cond_bad') : t('tablet_cond_good'));
            $add(t('tablet_lbl_brand'), $a['motherboard_brand'] ?? '');
        } else {
            $add(t('lbl_serial_number'), $a['serial_number']);
            if ($filled($a['os_name'])) $add(t('field_os_status'), ($a['os_status'] ?? '') === 'Original' ? t('os_original') : t('os_not_original'));
            $add(t('lbl_motherboard'), $a['motherboard_brand'] ?? '');
            $add(t('lbl_processor'), $a['processor']);
            $add(t('lbl_ram'), $a['ram']);
            $add(t('lbl_storage'), $a['storage']);
            $add(t('lbl_monitor'), $a['monitor_info']);
            $add(t('lbl_printer'), $a['printer_info']);
        }
        $add(t('lbl_accessories'), $accOf($a));
        return $f;
    };
    if (count($detailAssets) > 2):
        // Banyak aset: 1 baris per aset; kolom yang kosong di semua aset tidak ditampilkan.
        $rowsData = [];
        foreach ($detailAssets as $a) {
            $isTab = isTabletCategory($a['category']); $tab = $tabletMap[(int)$a['id']] ?? [];
            $spec = $isTab
                ? array_filter([$filled($tab['tablet_id'] ?? '') ? t('tablet_lbl_id') . ': ' . $tab['tablet_id'] : '', $a['motherboard_brand'] ?? '', $accOf($a)], $filled)
                : array_filter([$a['processor'] ?? '', $a['ram'] ?? '', $a['storage'] ?? '', $a['monitor_info'] ?? '', $a['printer_info'] ?? ''], $filled);
            $rowsData[] = ['no' => $a['asset_number'], 'type' => $categoryLabels[$a['category']] ?? $a['category'], 'name' => $a['device_name'], 'user' => $a['owner_name'] ?? '', 'sn' => $a['serial_number'], 'ip' => $a['ip_address'], 'spec' => implode(' · ', $spec)];
        }
        $cols = ['no' => t('lbl_asset_number'), 'type' => t('lbl_asset_type'), 'name' => t('lbl_device_name'), 'user' => t('lbl_user'), 'sn' => t('lbl_serial_number'), 'ip' => t('lbl_ip_address'), 'spec' => t('info_hardware_specs')];
        foreach ($cols as $k => $lbl) { if (!array_filter(array_column($rowsData, $k), $filled)) unset($cols[$k]); }
    ?>
    <table class="sumtbl">
        <thead><tr><th style="width:20px">No</th><?php foreach ($cols as $lbl): ?><th><?= $h($lbl) ?></th><?php endforeach; ?></tr></thead>
        <tbody>
        <?php foreach ($rowsData as $i => $r): ?>
            <tr><td><?= $i + 1 ?></td><?php foreach ($cols as $k => $lbl): ?><td><?= $h($r[$k]) ?></td><?php endforeach; ?></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: foreach ($detailAssets as $a):
        $fields = $fieldsOf($a); $soft = $softOf($a);
        $showSoft = !isTabletCategory($a['category']) && $soft !== '';
    ?>
    <div class="asset-box">
        <div class="ttl"><?= $h($a['asset_number']) ?><?= $filled($a['device_name']) ? ' — ' . $h($a['device_name']) : '' ?>
            <span class="muted small" style="font-weight:normal">&bull; <?= $h($categoryLabels[$a['category']] ?? $a['category']) ?> &bull; <?= $h(t('th_status')) ?>: <?= $h($statusLabels[$a['status']] ?? $a['status']) ?></span></div>
        <table class="kv4">
            <?php for ($i = 0; $i < count($fields); $i += 2): $l = $fields[$i]; $r = $fields[$i + 1] ?? null; ?>
            <tr><td class="k"><?= $h($l[0]) ?></td><td class="v"<?= $r ? '' : ' colspan="3"' ?>><?= $l[1] ?></td><?php if ($r): ?><td class="k"><?= $h($r[0]) ?></td><td class="v"><?= $r[1] ?></td><?php endif; ?></tr>
            <?php endfor; ?>
            <?php if ($showSoft): ?><tr><td class="k"><?= t('lbl_installed_software') ?></td><td class="v" colspan="3"><?= $soft ?></td></tr><?php endif; ?>
        </table>
    </div>
    <?php endforeach; endif; ?>
    <?php endif; ?>

    <div class="box-title"><?= t('stock_ba_items') ?></div>
    <table>
        <thead><tr><th style="width:28px">No</th><th><?= t('stock_category') ?></th><th><?= t('stock_item_name') ?></th><th><?= t('stock_asset_ids') ?></th><th class="r" style="width:70px"><?= t('stock_qty') ?></th><th><?= t('stock_note') ?></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $i => $r): $ids = array_column($trxAssets[(int)$r['id']] ?? [], 'asset_number'); ?>
            <tr><td><?= $i + 1 ?></td><td><?= $h($r['category_name']) ?></td><td><?= $h($r['item_name'] ?: $dash) ?></td>
                <td class="small"><?= $ids ? implode(', ', array_map($h, $ids)) : $dash ?></td>
                <td class="r"><b><?= (int)$r['qty'] ?></b> <?= $h($r['unit']) ?></td><td><?= $h($r['note'] ?: $dash) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
        <?php if (count($rows) > 1): ?><tfoot><tr><td colspan="4"><?= t('stock_total') ?></td><td class="r"><?= $totalQty ?></td><td></td></tr></tfoot><?php endif; ?>
    </table>

    <p style="margin-top:8px"><?= $h(t('stock_ba_closing')) ?></p>

<?php
// Kolom tanda tangan: nama di atas garis, jabatan di bawahnya. Nama kosong = garis kosong untuk ditulis tangan.
$signCol = function (string $label, string $name, string $title) use ($h) {
    return '<div>' . $h($label) . ',<div class="line">' . ($name !== '' ? $h($name) : '&nbsp;') . '</div>'
         . ($title !== '' ? '<div class="muted small">' . $h($title) . '</div>' : '') . '</div>';
};
?>
    <div class="sign">
        <?= $signCol(t('stock_ba_sign_giver'), $giver, $giverPos) ?>
        <?= $signCol(t('stock_ba_sign_receiver'), $recipient, $recPos) ?>
        <?= $signCol(t('mut_ba_sign_it'), findUserNameByPosition($db, t('stock_ba_sign_asst')), t('stock_ba_sign_asst')) ?>
        <?= $signCol(t('mut_ba_sign_it'), findUserNameByPosition($db, t('stock_ba_sign_mgr')), t('stock_ba_sign_mgr')) ?>
    </div>

    </div></div><!-- .fit -->
<?php endforeach; ?>
    <?= letterheadClose() ?>
    <div class="no-print">
        <button onclick="window.print()"><?= t('btn_print') ?></button>
        <?php if ($multi || $idsParam): ?>
        <?php elseif (!$single && count($rows) > 1): ?><a href="?id=<?= $id ?>&single=1"><?= $h(t('stock_ba_only_this')) ?></a>
        <?php elseif ($single): ?><a href="?id=<?= $id ?>"><?= $h(t('stock_ba_all_day')) ?></a><?php endif; ?>
    </div>
    <script>
    // Pastikan isi muat 1 halaman A4: bila lebih tinggi dari ruang kosong di antara kop, isi diperkecil (zoom).
    (function () {
        var KOP_TOP = <?= (int)$kopTop ?>, KOP_BOTTOM = <?= (int)$kopBottom ?>, PX = 96 / 25.4;
        function fitOne(el) {
            el.style.zoom = ''; el.style.width = '';
            var avail = (297 - KOP_TOP - KOP_BOTTOM - 4) * PX;          // tinggi isi 1 halaman (px)
            var s = 1, hgt = el.getBoundingClientRect().height;
            if (hgt > avail) {
                s = Math.max(0.55, avail / hgt);
                for (var i = 0; i < 12; i++) {                           // iterasi: lebar menyesuaikan zoom, tinggi diukur ulang
                    el.style.zoom = s; el.style.width = (182 / s) + 'mm';
                    if (el.getBoundingClientRect().height * s <= avail || s <= 0.55) break;
                    s = Math.max(0.55, s * 0.96);
                }
            }
        }
        function fit() { var els = document.querySelectorAll('.fit'); for (var i = 0; i < els.length; i++) fitOne(els[i]); }
        window.addEventListener('load', function () { fit(); setTimeout(function () { window.print(); }, 300); });
        window.addEventListener('beforeprint', fit);
    })();
    </script>
</body>
</html>
