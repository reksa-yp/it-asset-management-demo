<?php
/**
 * Berita Acara Serah Terima Barang (stok) — A4 dengan kop surat, dialog print otomatis.
 *   stock_handover_print.php?id=12            -> semua Barang Keluar untuk penerima & tanggal yang sama dengan transaksi #12
 *   stock_handover_print.php?id=12&single=1   -> hanya transaksi #12
 * Kalau barang yang diserahkan punya ID Aset, bagian "Detail Aset" ditampilkan sebelum daftar barang
 * (isi sama dengan detail aset; khusus Tablet tanpa Serial Number OS & Status OS).
 * Hanya MEMBACA data. Tidak ada tabel/kolom baru.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/letterhead.php';
require_once __DIR__ . '/includes/stock.php';
require_once __DIR__ . '/includes/asset_accessories.php';

$db = getDB();
ensureStockTables($db);
$h    = fn($v) => htmlspecialchars((string)$v);
$dash = t('dash');
$id   = (int)($_GET['id'] ?? 0);
$single = !empty($_GET['single']);

$sel = "SELECT t.*, c.name AS category_name, c.unit FROM stock_transactions t JOIN stock_categories c ON c.id = t.category_id";
$st = $db->prepare("$sel WHERE t.id = ? AND t.type = 'out'");
$st->execute([$id]);
$main = $st->fetch();
if (!$main) { http_response_code(404); die($h(t('stock_ba_err_not_found'))); }

$rows = [$main];
if (!$single) {
    // Gabungkan semua barang yang diberikan ke penerima yang sama pada tanggal yang sama.
    if (!empty($main['user_id'])) {
        $st = $db->prepare("$sel WHERE t.type = 'out' AND t.trx_date = ? AND t.user_id = ? ORDER BY t.id");
        $st->execute([$main['trx_date'], (int)$main['user_id']]);
        $rows = $st->fetchAll() ?: [$main];
    } elseif (trim((string)$main['recipient_name']) !== '') {
        $st = $db->prepare("$sel WHERE t.type = 'out' AND t.trx_date = ? AND t.user_id IS NULL AND t.recipient_name = ? ORDER BY t.id");
        $st->execute([$main['trx_date'], $main['recipient_name']]);
        $rows = $st->fetchAll() ?: [$main];
    }
}
$trxAssets = getStockTrxAssets($db, array_column($rows, 'id'));
$totalQty  = array_sum(array_map(fn($r) => (int)$r['qty'], $rows));
$firstId   = min(array_map(fn($r) => (int)$r['id'], $rows));

// ===== Detail aset yang ikut diserahkan =====
$detailAssets = [];
foreach ($rows as $r) {
    foreach ($trxAssets[(int)$r['id']] ?? [] as $la) {
        $a = getAssetForCurrentUser((int)$la['id']);
        if ($a) $detailAssets[(int)$a['id']] = $a;
    }
}
$accessoryMap = $detailAssets ? getAccessoryItemsForAssets($db, array_values($detailAssets)) : [];
$tabletIds    = array_keys(array_filter($detailAssets, fn($a) => isTabletCategory($a['category'])));
$tabletMap    = ($tabletIds && function_exists('getTabletDetailsMap')) ? getTabletDetailsMap($db, $tabletIds) : [];
$categoryLabels = ['Desktop PC' => t('cat_desktop'), 'Laptop' => t('cat_laptop'), 'Printer' => t('cat_printer'), 'Monitor' => t('cat_monitor'), 'Aksesoris' => t('cat_accessory')];
$statusLabels   = ['Digunakan' => t('status_used'), 'Stok' => t('status_stock'), 'Tidak Digunakan' => t('status_unused')];
$v = fn($x) => $h(($x ?? '') !== '' ? $x : $dash);

$ts      = strtotime($main['trx_date']);
$baNo    = 'BA-STK/' . date('Ym', $ts) . '/' . str_pad((string)$firstId, 4, '0', STR_PAD_LEFT);
$days    = currentLang() === 'id' ? ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'] : ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
$months  = currentLang() === 'id'
    ? ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
    : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
$dayName  = $days[(int)date('w', $ts)];
$longDate = date('j', $ts) . ' ' . $months[(int)date('n', $ts) - 1] . ' ' . date('Y', $ts);

$recipient = trim((string)$main['recipient_name']);
$recDept   = trim((string)$main['recipient_department']);
$recPos    = '';
if (!empty($main['user_id'])) {
    try { $recPos = getUserPosition($db, (int)$main['user_id']); } catch (Throwable $e) { $recPos = ''; }
}
$giver    = currentUser()['full_name'] ?? 'Admin IT';
$giverPos = '';
if (!empty(currentUser()['id'])) {
    try { $giverPos = getUserPosition($db, (int)currentUser()['id']); } catch (Throwable $e) { $giverPos = ''; }
}
?>
<!DOCTYPE html>
<html lang="<?= $h(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $h(t('stock_ba_title') . ' ' . $baNo) ?></title>
<style>
    @page { size: A4; margin: 14mm 14mm; }
    body { font-family: Arial, sans-serif; color: #1e293b; margin: 24px; font-size: 12px; }
    .head { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 1.5px solid #173A68; padding-bottom: 6px; margin-bottom: 14px; }
    .brand { display: flex; align-items: center; gap: 10px; }
    .brand .name { font-size: 13px; font-weight: bold; color: #1e293b; }
    .muted { color: #64748b; }
    h1 { text-align: center; font-size: 15px; margin: 6px 0 2px; letter-spacing: .5px; }
    .no { text-align: center; margin-bottom: 14px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #cbd5e1; padding: 5px 7px; text-align: left; vertical-align: top; }
    th { background: #eef2ff; }
    .r { text-align: right; }
    .kv td:first-child { width: 38%; color: #475569; background: #f8fafc; }
    .two { display: flex; gap: 12px; margin: 12px 0; }
    .two > div { flex: 1; }
    .box-title { font-weight: bold; margin: 14px 0 6px; }
    .asset-box { border: 1px solid #cbd5e1; border-radius: 4px; padding: 8px 10px; margin-bottom: 10px; page-break-inside: avoid; }
    .asset-box .ttl { font-weight: bold; font-size: 12.5px; }
    .asset-box .two { margin: 8px 0 0; }
    .asset-box .sub { font-weight: bold; margin: 0 0 4px; font-size: 11px; color: #334155; }
    .asset-box table { font-size: 11px; }
    .asset-box td { padding: 3px 6px; }
    tfoot td { font-weight: bold; background: #f8fafc; }
    .sign { display: flex; justify-content: space-between; margin-top: 34px; text-align: center; page-break-inside: avoid; }
    .sign > div { width: 23%; }
    .sign .line { margin-top: 64px; border-top: 1px solid #334155; padding-top: 4px; font-weight: bold; }
    .small { font-size: 10.5px; }
    .no-print { margin-top: 20px; text-align: center; }
    .no-print button, .no-print a { display: inline-block; background: #1F3DD1; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 13px; cursor: pointer; text-decoration: none; margin: 0 4px; }
    .no-print a { background: #fff; color: #1F3DD1; border: 1px solid #1F3DD1; }
    @media print { body { margin: 0; } .no-print { display: none; } tr { page-break-inside: avoid; } }
<?= letterheadCss() ?></style>
</head>
<body>
    <?= letterheadOpen() ?>
    <div class="head">
        <div class="brand"><div class="name"><?= $h(t('stock_ba_title')) ?></div></div>
        <div class="muted" style="text-align:right"><?= htmlspecialchars(documentCreatedAt()) ?></div>
    </div>

    <h1><?= $h(mb_strtoupper(t('stock_ba_title'))) ?></h1>
    <div class="no"><?= t('mut_ba_number') ?>: <b><?= $h($baNo) ?></b></div>

    <p><?= $h(t('stock_ba_opening', $dayName, $longDate)) ?></p>

    <div class="two">
        <div>
            <div class="box-title"><?= t('mut_ba_from') ?></div>
            <table class="kv">
                <tr><td><?= t('stock_ba_name') ?></td><td><?= $h($giver) ?></td></tr>
                <tr><td><?= t('th_position') ?></td><td><?= $h($giverPos ?: $dash) ?></td></tr>
                <tr><td><?= t('lbl_department') ?></td><td><?= $h(t('stock_ba_it_dept')) ?></td></tr>
            </table>
        </div>
        <div>
            <div class="box-title"><?= t('mut_ba_to') ?></div>
            <table class="kv">
                <tr><td><?= t('stock_ba_name') ?></td><td><b><?= $h($recipient ?: $dash) ?></b></td></tr>
                <tr><td><?= t('th_position') ?></td><td><?= $h($recPos ?: $dash) ?></td></tr>
                <tr><td><?= t('lbl_department') ?></td><td><?= $h($recDept ?: $dash) ?></td></tr>
            </table>
        </div>
    </div>

    <?php if ($detailAssets): ?>
    <div class="box-title"><?= t('stock_ba_asset_detail') ?></div>
    <?php foreach ($detailAssets as $a):
        $isTab = isTabletCategory($a['category']);
        $acc   = $accessoryMap[(int)$a['id']] ?? [];
        $accTx = $acc ? implode(', ', array_map(fn($x) => $x['name'] . ($x['brand'] !== '' ? ' (' . $x['brand'] . ')' : ''), $acc)) : (string)($a['accessories'] ?? '');
        $tab   = $tabletMap[(int)$a['id']] ?? [];
    ?>
    <div class="asset-box">
        <div class="ttl"><?= $h($a['asset_number']) ?> — <?= $h($a['device_name'] ?: $a['category']) ?></div>
        <div class="muted small"><?= $h($categoryLabels[$a['category']] ?? $a['category']) ?> &bull; <?= $h(t('th_status')) ?>: <?= $h($statusLabels[$a['status']] ?? $a['status']) ?></div>
        <div class="two">
            <div>
                <div class="sub"><?= t('info_general') ?></div>
                <table class="kv">
                    <tr><td><?= t('lbl_asset_number') ?></td><td><?= $v($a['asset_number']) ?></td></tr>
                    <tr><td><?= t('lbl_asset_type') ?></td><td><?= $h($categoryLabels[$a['category']] ?? $a['category']) ?></td></tr>
                    <tr><td><?= t('lbl_device_name') ?></td><td><?= $v($a['device_name']) ?></td></tr>
                    <tr><td><?= t('lbl_user') ?></td><td><?= $v($a['owner_name'] ?? '') ?></td></tr>
                    <tr><td><?= t('lbl_department') ?></td><td><?= $v($a['department']) ?></td></tr>
                    <tr><td><?= t('field_position') ?></td><td><?= $v(assetOwnerPositions($db, (int)$a['id'])) ?></td></tr>
                    <tr><td><?= t('lbl_location') ?></td><td><?= $v($a['location']) ?></td></tr>
                    <tr><td><?= t('lbl_purchase_date') ?></td><td><?= !empty($a['purchase_date'] ?? null) ? date('d M Y', strtotime($a['purchase_date'])) : $dash ?></td></tr>
                </table>
            </div>
            <div>
                <div class="sub"><?= t('info_network_system') ?></div>
                <table class="kv">
                    <tr><td><?= t('lbl_ip_address') ?></td><td><?= $v($a['ip_address']) ?></td></tr>
                    <tr><td><?= t('lbl_hostname') ?></td><td><?= $v($a['hostname']) ?></td></tr>
                    <tr><td><?= t('lbl_os') ?></td><td><?= $v($a['os_name']) ?></td></tr>
                    <?php if ($isTab): ?>
                    <tr><td><?= t('tablet_lbl_serial') ?></td><td><?= $v($a['serial_number']) ?></td></tr>
                    <?php else: ?>
                    <tr><td><?= t('lbl_serial_number') ?></td><td><?= $v($a['serial_number']) ?></td></tr>
                    <tr><td><?= t('field_os_status') ?></td><td><?= $h($a['os_status'] === 'Original' ? t('os_original') : t('os_not_original')) ?></td></tr>
                    <?php endif; ?>
                </table>
                <?php if ($isTab): ?>
                <div class="sub" style="margin-top:8px"><?= t('tablet_info_title') ?></div>
                <table class="kv">
                    <tr><td><?= t('tablet_lbl_id') ?></td><td><?= $v($tab['tablet_id'] ?? '') ?></td></tr>
                    <tr><td><?= t('tablet_lbl_condition') ?></td><td><?= $h(($tab['tablet_condition'] ?? 'Bagus') === 'Rusak' ? t('tablet_cond_bad') : t('tablet_cond_good')) ?></td></tr>
                    <tr><td><?= t('tablet_lbl_brand') ?></td><td><?= $v($a['motherboard_brand'] ?? '') ?></td></tr>
                    <tr><td><?= t('lbl_accessories') ?></td><td><?= $v($accTx) ?></td></tr>
                </table>
                <?php endif; ?>
            </div>
        </div>
        <?php if (!$isTab): ?>
        <div class="sub" style="margin-top:8px"><?= t('info_hardware_specs') ?></div>
        <table class="kv">
            <tr><td style="width:19%"><?= t('lbl_processor') ?></td><td style="width:31%"><?= $v($a['processor']) ?></td><td style="width:19%; color:#475569; background:#f8fafc"><?= t('lbl_ram') ?></td><td><?= $v($a['ram']) ?></td></tr>
            <tr><td><?= t('lbl_storage') ?></td><td><?= $v($a['storage']) ?></td><td style="color:#475569; background:#f8fafc"><?= t('lbl_monitor') ?></td><td><?= $v($a['monitor_info']) ?></td></tr>
            <tr><td><?= t('lbl_motherboard') ?></td><td><?= $v($a['motherboard_brand'] ?? '') ?></td><td style="color:#475569; background:#f8fafc"><?= t('lbl_printer') ?></td><td><?= $v($a['printer_info']) ?></td></tr>
            <tr><td><?= t('lbl_accessories') ?></td><td colspan="3"><?= $v($accTx) ?></td></tr>
            <tr><td><?= t('lbl_installed_software') ?></td><td colspan="3"><?php if (!empty($a['software_items'])): foreach ($a['software_items'] as $i => $si): ?><?= $i ? '<br>' : '' ?><?= $h($si['software_name']) ?><?= $si['serial_number'] ? ' (' . $h($si['serial_number']) . ')' : '' ?> — <?= $h($si['status'] === 'Original' ? t('os_original') : t('os_not_original')) ?><?php endforeach; else: ?><?= $dash ?><?php endif; ?></td></tr>
        </table>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>

    <div class="box-title"><?= t('stock_ba_items') ?></div>
    <table>
        <thead><tr><th style="width:28px">No</th><th><?= t('stock_category') ?></th><th><?= t('stock_item_name') ?></th><th><?= t('stock_asset_ids') ?></th><th class="r" style="width:70px"><?= t('stock_qty') ?></th><th><?= t('stock_note') ?></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $i => $r): $ids = array_column($trxAssets[(int)$r['id']] ?? [], 'asset_number'); ?>
            <tr><td><?= $i + 1 ?></td><td><?= $h($r['category_name']) ?></td><td><?= $h($r['item_name'] ?: $dash) ?></td>
                <td class="small"><?= $ids ? implode('<br>', array_map($h, $ids)) : $dash ?></td>
                <td class="r"><b><?= (int)$r['qty'] ?></b> <?= $h($r['unit']) ?></td><td><?= $h($r['note'] ?: $dash) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
        <?php if (count($rows) > 1): ?><tfoot><tr><td colspan="4"><?= t('stock_total') ?></td><td class="r"><?= $totalQty ?></td><td></td></tr></tfoot><?php endif; ?>
    </table>

    <p style="margin-top:14px"><?= $h(t('stock_ba_closing')) ?></p>

<?php
// Kolom tanda tangan: nama di atas garis, jabatan di bawahnya. Nama kosong = garis kosong untuk ditulis tangan.
$signCol = function (string $label, string $name, string $title) use ($h) {
    return '<div>' . $h($label) . ',<div class="line">' . ($name !== '' ? $h($name) : '&nbsp;') . '</div>'
         . ($title !== '' ? '<div class="muted small">' . $h($title) . '</div>' : '') . '</div>';
};
?>
    <div class="sign">
        <?= $signCol(t('stock_ba_sign_giver'), $giver, $giverPos) ?>
        <?= $signCol(t('stock_ba_sign_receiver'), $recipient, $recPos) ?>
        <?= $signCol(t('mut_ba_sign_it'), findUserNameByPosition($db, t('stock_ba_sign_asst')), t('stock_ba_sign_asst')) ?>
        <?= $signCol(t('mut_ba_sign_it'), findUserNameByPosition($db, t('stock_ba_sign_mgr')), t('stock_ba_sign_mgr')) ?>
    </div>

    <?= letterheadClose() ?>
    <div class="no-print">
        <button onclick="window.print()"><?= t('btn_print') ?></button>
        <?php if (!$single && count($rows) > 1): ?><a href="?id=<?= $id ?>&single=1"><?= $h(t('stock_ba_only_this')) ?></a>
        <?php elseif ($single): ?><a href="?id=<?= $id ?>"><?= $h(t('stock_ba_all_day')) ?></a><?php endif; ?>
    </div>
    <script>window.addEventListener('load', () => setTimeout(() => window.print(), 300));</script>
</body>
</html>
