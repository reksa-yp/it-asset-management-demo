<?php
/**
 * Cetak Mutasi Aset (A4, dialog print otomatis):
 *   mutation_print.php?id=5            -> Berita Acara Mutasi / Serah Terima Aset (1 mutasi)
 *   mutation_print.php?list=1&from=... -> Laporan daftar mutasi sesuai filter
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/letterhead.php';
require_once __DIR__ . '/includes/mutation.php';

$db = getDB();
ensureMutationTable($db);
$logo = appLogoDataUri();
$h    = fn($v) => htmlspecialchars((string)$v);
$dash = t('dash');
$fmt  = fn($d) => date('d M Y', strtotime($d));

$isList = !empty($_GET['list']);
if ($isList) {
    $f = mutationFilters();
    $rows = getMutations($db, $f);
    $period = ($f['from'] ? $fmt($f['from']) : '…') . ' – ' . ($f['to'] ? $fmt($f['to']) : '…');
} else {
    $st = $db->prepare("SELECT * FROM asset_mutations WHERE id = ?");
    $st->execute([(int)($_GET['id'] ?? 0)]);
    $m = $st->fetch();
    if (!$m) { http_response_code(404); die($h(t('mut_err_not_found'))); }
    $asset = $db->prepare("SELECT id, category, serial_number, motherboard_brand, accessories FROM assets WHERE id = ?");
    $asset->execute([(int)$m['asset_id']]);
    $asset = $asset->fetch() ?: ['id' => 0, 'category' => '', 'serial_number' => '', 'motherboard_brand' => '', 'accessories' => ''];
    // Tablet: Serial Number tetap dicetak (itu serial perangkatnya). Desktop PC / Laptop tidak,
    // karena di sana kolom itu berisi serial OS.
    $showSerial = isTabletCategory($m['asset_category'] ?: $asset['category']);
    // Aksesoris aset (Nama + Brand/Type) yang ikut diserahkan. Lihat includes/asset_accessories.php.
    require_once __DIR__ . '/includes/asset_accessories.php';
    $accessoryItems = getAccessoryItemsForAssets($db, [$asset])[(int)$asset['id']] ?? [];
    // Ambil hari & tanggal dalam bahasa aktif
    $days = currentLang() === 'id' ? ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'] : ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    $dayName = $days[(int)date('w', strtotime($m['mutation_date']))];
    $months = currentLang() === 'id'
        ? ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
        : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    $ts = strtotime($m['mutation_date']);
    $longDate = date('j', $ts) . ' ' . $months[(int)date('n', $ts) - 1] . ' ' . date('Y', $ts);
}
?>
<!DOCTYPE html>
<html lang="<?= $h(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $isList ? $h(t('mut_report_title')) : $h(t('mut_ba_title') . ' ' . $m['mutation_number']) ?></title>
<style>
    @page { size: A4; margin: 14mm 14mm; }
    body { font-family: Arial, sans-serif; color: #1e293b; margin: 24px; font-size: 12px; }
    .head { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 1.5px solid #173A68; padding-bottom: 6px; margin-bottom: 14px; }
    .brand { display: flex; align-items: center; gap: 10px; }
    .brand img { height: 36px; }
    .brand .name { font-size: 13px; font-weight: bold; color: #1e293b; }
    .muted { color: #64748b; }
    h1 { text-align: center; font-size: 15px; margin: 6px 0 2px; letter-spacing: .5px; }
    .no { text-align: center; margin-bottom: 14px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #cbd5e1; padding: 5px 7px; text-align: left; vertical-align: top; }
    th { background: #eef2ff; }
    .kv td:first-child { width: 32%; color: #475569; background: #f8fafc; }
    .two { display: flex; gap: 12px; margin: 12px 0; }
    .two > div { flex: 1; }
    .box-title { font-weight: bold; margin: 14px 0 6px; }
    .sign { display: flex; justify-content: space-between; margin-top: 34px; text-align: center; page-break-inside: avoid; }
    .sign > div { width: 31%; }
    .sign .line { margin-top: 64px; border-top: 1px solid #334155; padding-top: 4px; font-weight: bold; }
    .small { font-size: 10.5px; }
    .no-print { margin-top: 20px; text-align: center; }
    .no-print button { background: #1F3DD1; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 13px; cursor: pointer; }
    @media print { body { margin: 0; } .no-print { display: none; } tr { page-break-inside: avoid; } }
<?= letterheadCss() ?></style>
</head>
<body>
    <?= letterheadOpen() ?>
    <div class="head">
        <div class="brand">
            <div class="name"><?= $h($isList ? t('mut_report_title') : t('mut_ba_title')) ?></div>
        </div>
        <div class="muted" style="text-align:right">
            <?php if ($isList): ?><?= $h(t('stock_period')) ?>: <?= $h($period) ?><br><?php endif; ?>
            <?= htmlspecialchars(documentCreatedAt()) ?>
        </div>
    </div>

<?php if ($isList): ?>
    <table class="small">
        <thead><tr><th>No</th><th><?= t('mut_col_number') ?></th><th><?= t('th_date') ?></th><th><?= t('mut_col_asset') ?></th><th><?= t('mut_col_from') ?></th><th><?= t('mut_col_to') ?></th><th><?= t('mut_col_reason') ?></th><th><?= t('mut_col_condition') ?></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $i => $r): ?>
            <tr><td><?= $i + 1 ?></td><td style="white-space:nowrap"><?= $h($r['mutation_number']) ?></td><td style="white-space:nowrap"><?= $fmt($r['mutation_date']) ?></td>
                <td><b><?= $h($r['asset_number']) ?></b><br><span class="muted"><?= $h($r['asset_category']) ?><?= $r['asset_name'] ? ' · ' . $h($r['asset_name']) : '' ?></span></td>
                <td><?= $h(mutationPartyLabel($r['from_user_names'])) ?><br><span class="muted"><?= $h(implode(' · ', array_filter([$r['from_department'], $r['from_location']]))) ?></span></td>
                <td><?= $h(mutationPartyLabel($r['to_user_names'])) ?><br><span class="muted"><?= $h(implode(' · ', array_filter([$r['to_department'], $r['to_location']]))) ?></span></td>
                <td><?= $h(mutationReasonLabel($r['reason'])) ?><?= $r['note'] ? '<br><span class="muted">' . $h($r['note']) . '</span>' : '' ?></td>
                <td><?= $h(mutationConditionLabel($r['asset_condition'])) ?></td></tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="8" class="muted" style="text-align:center"><?= t('mut_empty') ?></td></tr><?php endif; ?>
        </tbody>
    </table>
    <div class="sign" style="justify-content:space-around">
        <div><?= t('stock_sign_made') ?>,<div class="line"><?= $h(currentUser()['full_name'] ?? 'Admin IT') ?></div></div>
        <div><?= t('stock_sign_ack') ?>,<div class="line"><?= t('stock_sign_head') ?></div></div>
    </div>

<?php else: ?>
    <h1><?= $h(mb_strtoupper(t('mut_ba_title'))) ?></h1>
    <div class="no"><?= t('mut_ba_number') ?>: <b><?= $h($m['mutation_number']) ?></b></div>

    <p><?= $h(t('mut_ba_opening', $dayName, $longDate)) ?></p>

    <div class="box-title"><?= t('mut_ba_asset_data') ?></div>
    <table class="kv">
        <tr><td><?= t('lbl_asset_number') ?></td><td><b><?= $h($m['asset_number']) ?></b></td></tr>
        <tr><td><?= t('lbl_asset_type') ?></td><td><?= $h($m['asset_category'] ?: $dash) ?></td></tr>
        <tr><td><?= t('lbl_device_name') ?></td><td><?= $h($m['asset_name'] ?: $dash) ?></td></tr>
        <?php if ($showSerial): ?><tr><td><?= t('xls_hdr_serial') ?></td><td><?= $h($asset['serial_number'] ?: $dash) ?></td></tr><?php endif; ?>
        <tr><td><?= t('lbl_accessories') ?></td><td><?php if ($accessoryItems): foreach ($accessoryItems as $i => $acc): ?><?= $i ? '<br>' : '' ?><?= ($i + 1) . '. ' . $h($acc['name']) ?><?= $acc['brand'] !== '' ? ' (' . $h($acc['brand']) . ')' : '' ?><?php endforeach; else: ?><?= $dash ?><?php endif; ?></td></tr>
        <tr><td><?= t('tablet_lbl_brand') ?></td><td><?= $h($asset['motherboard_brand'] ?: $dash) ?></td></tr>
        <tr><td><?= t('mut_col_condition') ?></td><td><?= $h(mutationConditionLabel($m['asset_condition'])) ?></td></tr>
    </table>

    <div class="two">
        <div>
            <div class="box-title"><?= t('mut_ba_from') ?></div>
            <table class="kv">
                <tr><td><?= t('lbl_user') ?></td><td><?= $h(mutationPartyLabel($m['from_user_names'])) ?></td></tr>
                <tr><td><?= t('lbl_department') ?></td><td><?= $h($m['from_department'] ?: $dash) ?></td></tr>
                <tr><td><?= t('lbl_location') ?></td><td><?= $h($m['from_location'] ?: $dash) ?></td></tr>
            </table>
        </div>
        <div>
            <div class="box-title"><?= t('mut_ba_to') ?></div>
            <table class="kv">
                <tr><td><?= t('lbl_user') ?></td><td><b><?= $h(mutationPartyLabel($m['to_user_names'])) ?></b></td></tr>
                <tr><td><?= t('lbl_department') ?></td><td><?= $h($m['to_department'] ?: $dash) ?></td></tr>
                <tr><td><?= t('lbl_location') ?></td><td><?= $h($m['to_location'] ?: $dash) ?></td></tr>
            </table>
        </div>
    </div>

    <table class="kv">
        <tr><td><?= t('mut_col_reason') ?></td><td><?= $h(mutationReasonLabel($m['reason'])) ?></td></tr>
        <tr><td><?= t('stock_note') ?></td><td><?= nl2br($h($m['note'] ?: $dash)) ?></td></tr>
    </table>

    <p style="margin-top:14px"><?= $h(t('mut_ba_closing')) ?></p>

    <div class="sign">
        <div><?= t('mut_ba_sign_from') ?>,<div class="line"><?= $h(mutationPartyLabel($m['from_user_names'])) ?></div></div>
        <div><?= t('mut_ba_sign_to') ?>,<div class="line"><?= $h(mutationPartyLabel($m['to_user_names'])) ?></div></div>
        <div><?= t('mut_ba_sign_it') ?>,<div class="line"><?= t('mut_ba_sign_it_title') ?></div></div>
    </div>
<?php endif; ?>

    <?= letterheadClose() ?>
    <div class="no-print"><button onclick="window.print()"><?= t('btn_print') ?></button></div>
    <script>window.addEventListener('load', () => setTimeout(() => window.print(), 300));</script>
</body>
</html>
