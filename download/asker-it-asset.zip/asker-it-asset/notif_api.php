<?php
/**
 * API Pusat Notifikasi (lonceng di header, halaman notifications.php, aplikasi Android).
 *   GET  ?a=count                      -> jumlah belum dibaca (+ per kategori, max_id)
 *   GET  ?a=list&tab=unread|all&cat=   -> daftar notifikasi
 *   GET  ?a=unread&since=<id>          -> notifikasi belum dibaca yang lebih baru dari <id> (aplikasi Android)
 *   GET  ?a=open&id=<id>               -> tandai dibaca lalu buka halaman tujuannya
 *   POST a=read  (ids[] atau all=1)    -> tandai dibaca
 *   POST a=delete (ids[])              -> hapus
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/notifications.php';

$a = (string)($_GET['a'] ?? $_POST['a'] ?? 'count');

if (empty($_SESSION['user_id'])) {
    if ($a === 'open') { header('Location: login.php'); exit; }
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'login']);
    exit;
}
$uid = (int)$_SESSION['user_id'];
$db  = getDB();

if ($a === 'open') {
    $id = (int)($_GET['id'] ?? 0);
    $url = 'notifications.php';
    try {
        $st = $db->prepare("SELECT url FROM app_notifications WHERE id = ? AND user_id = ?");
        $st->execute([$id, $uid]);
        $u = (string)($st->fetchColumn() ?: '');
        // Hanya halaman di dalam aplikasi ini (bukan alamat luar).
        if ($u !== '' && preg_match('#^[a-z0-9_]+\.php([?\#].*)?$#i', $u)) $url = $u;
        notifMarkRead($db, $uid, [$id]);
    } catch (Throwable $e) {}
    header('Location: ' . $url);
    exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$json = fn($d) => print json_encode($d, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $ids = array_map('intval', (array)($_POST['ids'] ?? []));
    if ($a === 'read')   { $n = notifMarkRead($db, $uid, $ids, !empty($_POST['all'])); }
    elseif ($a === 'delete') { $n = notifDelete($db, $uid, $ids); }
    else { $json(['ok' => false]); exit; }
    $json(['ok' => true, 'changed' => $n] + ['unread' => notifUnreadCounts($db, $uid)['total']]);
    exit;
}

if ($a === 'list') {
    $tab = ($_GET['tab'] ?? 'unread') === 'all' ? 'all' : 'unread';
    $cat = (string)($_GET['cat'] ?? '');
    $c = notifUnreadCounts($db, $uid);
    $json(['ok' => true, 'unread' => $c['total'], 'by_cat' => $c['by_cat'], 'max_id' => $c['max_id'],
           'items' => array_map('notifOut', notifList($db, $uid, $tab, $cat, (int)($_GET['limit'] ?? 20)))]);
    exit;
}

if ($a === 'unread') {
    $since = (int)($_GET['since'] ?? 0);
    $c = notifUnreadCounts($db, $uid);
    $items = [];
    // Pertama kali (since <= 0): hanya patokan, tidak mengirim notifikasi lama.
    if ($since > 0) {
        $rows = array_reverse(notifList($db, $uid, 'unread', '', 20, 0, $since));
        $items = array_map('notifOut', $rows);
    }
    $json(['ok' => true, 'unread' => $c['total'], 'max_id' => $c['max_id'], 'items' => $items]);
    exit;
}

$c = notifUnreadCounts($db, $uid);
$json(['ok' => true, 'unread' => $c['total'], 'by_cat' => $c['by_cat'], 'max_id' => $c['max_id']]);
