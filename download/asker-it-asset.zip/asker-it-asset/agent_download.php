<?php
/**
 * Unduh paket Agen Kantor (.zip): isi folder tools/agen_kantor + agen_config.json berisi alamat aplikasi & kunci agen.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

if (!agentEnabled()) { header('Location: agent.php'); exit; }
if (!class_exists('ZipArchive')) { http_response_code(500); exit('Ekstensi PHP zip tidak aktif.'); }

$src = __DIR__ . '/tools/agen_kantor';
$tmp = tempnam(sys_get_temp_dir(), 'agen');
$zip = new ZipArchive();
if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) { http_response_code(500); exit('Gagal membuat zip.'); }
foreach (['asker_agent.php', 'jalankan_agen.bat', 'pasang_agen.bat', 'hapus_agen.bat', 'BACA_SAYA.txt'] as $f) {
    if (is_file($src . '/' . $f)) $zip->addFile($src . '/' . $f, 'AgenKantor/' . $f);
}
$zip->addFromString('AgenKantor/agen_config.json', json_encode([
    'url'     => agentBaseUrl(),
    'key'     => agentSettings()['key'],
    'created' => date('Y-m-d H:i:s'),
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
$zip->close();

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="AgenKantor.zip"');
header('Content-Length: ' . filesize($tmp));
header('Cache-Control: no-store');
readfile($tmp);
@unlink($tmp);
