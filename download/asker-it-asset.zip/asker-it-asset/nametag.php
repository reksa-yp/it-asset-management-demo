<?php
/**
 * Menu Nametag (semua user): nametag meja lipat 29,1 x 13,5 cm, dicetak di kertas F4.
 * User mengatur nametag miliknya sendiri; admin bisa memilih user lain (?uid=).
 * Lihat includes/nametag.php (tabel nametags, gambar cetak) dan nametag_print.php (cetak / PDF).
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();
require_once __DIR__ . '/includes/nametag.php';

$db    = getDB();
$me    = (int)$_SESSION['user_id'];
$admin = isAdmin();
$uid   = $admin ? (int)($_GET['uid'] ?? $_POST['uid'] ?? $me) : $me;
$hasGuest = $admin && is_file(__DIR__ . '/includes/nametag_guest_view.php');
$tab   = $hasGuest && ($_GET['tab'] ?? '') === 'tamu' ? 'tamu' : 'karyawan';   // tab "Nametag tamu" khusus admin
$h     = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES);
ntEnsure($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $r = ntSave($db, $uid, $_POST, $_FILES['photo'] ?? null, $me);
    $_SESSION['nt_msg'] = $r;
    $go = (string)($_POST['go'] ?? '');
    if ($r['ok'] && $go === 'print') { header('Location: nametag_print.php?uid=' . $uid); exit; }
    if ($r['ok'] && $go === 'pdf') { unset($_SESSION['nt_msg']); header('Location: nametag_print.php?uid=' . $uid . '&pdf=1'); exit; }
    header('Location: nametag.php' . ($admin && $uid !== $me ? '?uid=' . $uid : ''));
    exit;
}
$msg = $_SESSION['nt_msg'] ?? null;
unset($_SESSION['nt_msg']);

$d = ntGet($db, $uid);
if (!$d) { $uid = $me; $d = ntGet($db, $me); }
$users = [];
if ($admin) {
    try { $users = $db->query("SELECT id, full_name, department FROM users WHERE is_active = 1 ORDER BY full_name")->fetchAll(); }
    catch (Throwable $e) { $users = $db->query("SELECT id, full_name, department FROM users ORDER BY full_name")->fetchAll(); }
}
$photoUrl = $d['photo'] !== '' ? NT_PHOTO_URL . '/' . rawurlencode($d['photo']) . '?v=' . @filemtime(NT_PHOTO_DIR . '/' . $d['photo']) : '';
// Logo putih (PNG transparan) di nametag; ganti file ini untuk logo perusahaan lain.
$logo = is_file(__DIR__ . '/assets/img/nametag_logo.png') ? 'assets/img/nametag_logo.png?v=' . filemtime(__DIR__ . '/assets/img/nametag_logo.png') : '';

$pageTitle = 'Nametag';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<style>
<?= ntFontCss() ?>
#ntPreview svg { width: 100%; height: auto; display: block; border-radius: 4px; box-shadow: 0 10px 30px -12px rgba(15,23,42,.45); }
</style>
<?php if ($hasGuest): ?>
<div class="max-w-6xl mx-auto flex gap-6 border-b border-slate-200 mb-4 text-sm font-medium">
    <a href="nametag.php" class="pb-2 border-b-2 <?= $tab === 'karyawan' ? 'border-brand-600 text-brand-700' : 'border-transparent text-slate-500 hover:text-slate-700' ?>"><?= $h(ntL('Nametag karyawan', 'Staff name tags')) ?></a>
    <a href="nametag.php?tab=tamu" class="pb-2 border-b-2 <?= $tab === 'tamu' ? 'border-brand-600 text-brand-700' : 'border-transparent text-slate-500 hover:text-slate-700' ?>"><?= $h(ntL('Nametag tamu', 'Guest name tags')) ?> <span class="ml-1 text-[10px] font-bold bg-brand-100 text-brand-700 rounded-full px-1.5 py-0.5">ADMIN</span></a>
</div>
<?php endif; ?>
<?php if ($tab === 'tamu') { require __DIR__ . '/includes/nametag_guest_view.php'; require_once __DIR__ . '/includes/footer.php'; return; } ?>
<div class="max-w-6xl mx-auto">
<div class="flex flex-wrap items-end justify-between gap-3 mb-3">
    <div>
        <h1 class="text-xl font-semibold text-slate-800">Nametag</h1>
        <p class="text-sm text-slate-500"><?= $h(ntL('Nametag meja (dilipat dua, tegak) 29,1 × 13,5 cm. Cetak atau simpan PDF di kertas F4.', 'Folded desk name tag, 29.1 × 13.5 cm. Print or save as PDF on F4 paper.')) ?></p>
    </div>
    <?php if ($admin): ?>
    <form method="get" class="flex items-end gap-2 text-sm">
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(ntL('Buat nametag untuk', 'Name tag for')) ?></span>
            <select name="uid" onchange="this.form.submit()" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[16rem] max-w-full">
                <?php foreach ($users as $u): ?><option value="<?= (int)$u['id'] ?>" <?= (int)$u['id'] === $uid ? 'selected' : '' ?>><?= $h($u['full_name'] . ($u['department'] ? ' — ' . $u['department'] : '')) ?></option><?php endforeach; ?>
            </select></label>
    </form>
    <?php endif; ?>
</div>

<?php if ($msg): ?>
<div class="mb-3 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['msg']) ?></div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" id="ntForm" class="grid gap-4 lg:grid-cols-[minmax(0,22rem)_minmax(0,1fr)] items-start">
    <input type="hidden" name="csrf_token" value="<?= $h(csrfToken()) ?>">
    <input type="hidden" name="uid" value="<?= $uid ?>">
    <section class="bg-white rounded-xl shadow-sm p-4 flex flex-col gap-3 text-sm min-w-0">
        <?php if (!$d['saved']): ?><p class="text-xs rounded-lg bg-blue-50 text-blue-700 px-3 py-2"><?= $h(ntL('Data terisi otomatis dari akun. Periksa, unggah foto, lalu simpan.', 'Filled in from the account. Check it, upload a photo, then save.')) ?></p><?php endif; ?>
        <label class="flex flex-col gap-1"><span class="text-xs font-semibold text-slate-500"><?= $h(ntL('Nama lengkap', 'Full name')) ?></span>
            <input name="full_name" id="fFull" required maxlength="150" value="<?= $h($d['full_name']) ?>" class="border border-slate-300 rounded-lg px-3 py-2">
            <span class="text-xs text-slate-400"><?= $h(ntL('Dari data user; boleh diubah khusus untuk nametag.', 'From the user account; can be changed for the name tag only.')) ?></span></label>
        <label class="flex flex-col gap-1"><span class="text-xs font-semibold text-slate-500"><?= $h(ntL('Nama panggilan', 'Nickname')) ?></span>
            <input name="nick" id="fNick" maxlength="60" value="<?= $h($d['nick']) ?>" class="border border-slate-300 rounded-lg px-3 py-2">
            <span class="text-xs text-slate-400"><?= $h(ntL('Tampil di sebelah nama lengkap, dipisah " / ". Kosongkan bila tidak perlu.', 'Shown after the full name, separated by " / ". Leave empty if not needed.')) ?></span></label>
        <div class="grid grid-cols-2 gap-3">
            <label class="flex flex-col gap-1 min-w-0"><span class="text-xs font-semibold text-slate-500"><?= $h(ntL('Departemen', 'Department')) ?></span>
                <input name="department" id="fDept" maxlength="120" value="<?= $h($d['department']) ?>" class="border border-slate-300 rounded-lg px-3 py-2 w-full"></label>
            <label class="flex flex-col gap-1 min-w-0"><span class="text-xs font-semibold text-slate-500"><?= $h(ntL('Jabatan / bagian', 'Position')) ?></span>
                <input name="position" id="fPos" maxlength="150" value="<?= $h($d['position']) ?>" class="border border-slate-300 rounded-lg px-3 py-2 w-full"></label>
        </div>
        <div>
            <span class="text-xs font-semibold text-slate-500"><?= $h(ntL('Foto', 'Photo')) ?></span>
            <div class="flex gap-3 items-center mt-1">
                <div id="ntThumb" class="w-16 h-[5.3rem] rounded-lg overflow-hidden border-2 border-sky-400 bg-slate-700 flex items-center justify-center text-[10px] text-sky-300 text-center shrink-0">
                    <?php if ($photoUrl): ?><img src="<?= $h($photoUrl) ?>" alt="" class="w-full h-full object-cover"><?php else: ?><?= $h(ntL('Belum ada foto', 'No photo')) ?><?php endif; ?>
                </div>
                <div class="flex flex-col gap-1.5 min-w-0">
                    <div class="flex flex-wrap gap-2">
                        <button type="button" id="btnCam" class="inline-flex items-center gap-2 border border-slate-300 rounded-lg px-3 py-1.5 font-medium hover:bg-slate-50"><?= icon('camera', 'w-4 h-4') ?> <?= $h(ntL('Ambil foto', 'Take photo')) ?></button>
                        <button type="button" id="btnFile" class="inline-flex items-center gap-2 border border-slate-300 rounded-lg px-3 py-1.5 font-medium hover:bg-slate-50"><?= icon('upload', 'w-4 h-4') ?> <?= $h(ntL('Pilih file', 'Choose file')) ?></button>
                        <?php if ($photoUrl): ?><label class="inline-flex items-center gap-1 text-xs text-red-600"><input type="checkbox" name="remove_photo" value="1" id="fRemove"> <?= $h(ntL('Hapus foto', 'Remove photo')) ?></label><?php endif; ?>
                    </div>
                    <input type="file" name="photo" id="fPhoto" accept="image/jpeg,image/png,image/webp" class="hidden">
                    <span class="text-xs text-slate-400"><?= $h(ntL('Foto setengah badan, menghadap depan. Atur posisi dengan slider.', 'Half-body photo, facing forward. Adjust with the sliders.')) ?></span>
                </div>
            </div>
            <div id="ntAdj" class="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 items-center text-xs text-slate-500 mt-3">
                <span><?= $h(ntL('Perbesar', 'Zoom')) ?></span><input type="range" name="zoom" id="fZoom" min="100" max="250" value="<?= (int)$d['zoom'] ?>">
                <span><?= $h(ntL('Geser ←→', 'Move ←→')) ?></span><input type="range" name="pos_x" id="fPx" min="-50" max="50" value="<?= (int)$d['pos_x'] ?>">
                <span><?= $h(ntL('Geser ↑↓', 'Move ↑↓')) ?></span><input type="range" name="pos_y" id="fPy" min="-50" max="50" value="<?= (int)$d['pos_y'] ?>">
            </div>
        </div>
        <button type="submit" name="go" value="" class="w-full bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2.5 font-semibold"><?= $h(ntL('Simpan data nametag', 'Save name tag')) ?></button>
    </section>

    <section class="bg-white rounded-xl shadow-sm p-4 min-w-0">
        <div id="ntPreview"></div>
        <p class="text-xs text-slate-500 mt-2"><?= $h(ntL('Bagian atas otomatis terbalik: setelah dilipat di garis tengah, nama terbaca dari dua sisi meja.', 'The top half is flipped so the name reads from both sides once folded.')) ?></p>
        <div class="mt-4 rounded-xl border border-amber-300 bg-amber-50 text-amber-800 px-4 py-3 text-sm flex gap-3 leading-relaxed">
            <span aria-hidden="true">⚠️</span>
            <span><b class="block"><?= $h(ntL('Wajib kertas F4 (21,5 × 33 cm)', 'F4 paper required (21.5 × 33 cm)')) ?></b>
            <?= ntL('Saat mencetak pilih ukuran kertas <b>F4 / Folio</b>, orientasi <b>Landscape</b>, skala <b>100% (Actual size)</b>, margin <b>None</b>. Jangan pakai A4: tepinya hanya tersisa 3 mm sehingga nametag bisa terpotong printer. Disarankan kertas tebal (art carton 210–260 gsm).',
                    'When printing choose <b>F4 / Folio</b> paper, <b>Landscape</b>, scale <b>100% (Actual size)</b>, margins <b>None</b>. Do not use A4: only 3 mm margin is left, so printers may cut off the name tag. Thick paper (210–260 gsm) is recommended.') ?></span>
        </div>
        <div class="flex flex-wrap gap-2 mt-4">
            <button type="submit" name="go" value="print" class="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2 font-medium"><?= icon('printer', 'w-4 h-4') ?> <?= $h(ntL('Simpan & Cetak', 'Save & Print')) ?></button>
            <button type="submit" name="go" value="pdf" class="inline-flex items-center gap-2 border border-slate-300 hover:bg-slate-50 rounded-lg px-4 py-2 font-medium"><?= icon('download', 'w-4 h-4') ?> <?= $h(ntL('Simpan PDF (F4)', 'Save PDF (F4)')) ?></button>
        </div>
    </section>
</form>
</div>

<script>
(function () {
    var LOGO = <?= json_encode($logo) ?>, PATTERN = <?= json_encode(ntPattern()) ?>;
    var photo = <?= json_encode($photoUrl) ?>;
    function $(id) { return document.getElementById(id); }
    function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
    function up(id) { return $(id).value.trim().toUpperCase(); }
    function lineName() { var f = up('fFull'), n = up('fNick'); return n ? f + ' / ' + n : f; }
    function lineDept() { var a = up('fDept'), b = up('fPos'); return a && b ? a + ' / ' + b : (a || b); }
    function half(id) {
        var ph, removed = $('fRemove') && $('fRemove').checked;
        if (photo && !removed) {
            var z = +$('fZoom').value / 100, w = 190 * z, h = 249 * z,
                x = 38 + (190 - w) / 2 - (+$('fPx').value) * (w - 190) / 100,
                y = 123 + (249 - h) / 2 - (+$('fPy').value) * (h - 249) / 100;
            ph = '<clipPath id="ntc' + id + '"><rect x="38" y="123" width="190" height="249"/></clipPath><image href="' + esc(photo) + '" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" preserveAspectRatio="xMidYMid slice" clip-path="url(#ntc' + id + ')"/>';
        } else {
            ph = '<rect x="38" y="123" width="190" height="249" fill="#2c3a5c"/><circle cx="133" cy="212" r="38" fill="#3f5179"/><path d="M68 372 q0-80 65-80 q65 0 65 80z" fill="#3f5179"/>';
        }
        var pat = PATTERN.map(function (p) {
            var y = p[2] - 402 - 5;
            return p[3] === 'o' ? '<rect x="' + p[0] + '" y="' + y + '" width="' + (p[1] - p[0]) + '" height="10" fill="none" stroke="#bad9f0" stroke-width="2.5"/>'
                                : '<rect x="' + p[0] + '" y="' + y + '" width="' + (p[1] - p[0]) + '" height="10" fill="' + (p[3] === 'm' ? '#6eafde' : '#bad9f0') + '"/>';
        }).join('');
        return '<g>' + ph + '<rect x="38" y="123" width="190" height="249" fill="none" stroke="#6eafde" stroke-width="3"/>'
            + (LOGO ? '<image href="' + LOGO + '" x="35" y="22" width="195" height="80"/>' : '') + pat
            + '<text class="nm" x="826" y="188" text-anchor="middle" fill="#fff" font-family="NtTagB, Arial, sans-serif" font-size="87">' + esc(lineName()) + '</text>'
            + '<text class="dp" x="826" y="310" text-anchor="middle" fill="#fff" font-family="NtTagL, Arial, sans-serif" font-size="51">' + esc(lineDept()) + '</text></g>';
    }
    function render() {
        var box = $('ntPreview');
        box.innerHTML = '<svg viewBox="0 0 1719 797" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Nametag">'
            + '<rect width="1719" height="797" fill="#222e47"/>'
            + '<g transform="translate(0,398)">' + half('b') + '</g><g transform="rotate(180 859.5 199.5)">' + half('t') + '</g>'
            + '<line x1="0" y1="398.5" x2="1719" y2="398.5" stroke="#3a4a6e" stroke-width="2"/>'
            + '<rect x="1.5" y="1.5" width="1716" height="794" fill="none" stroke="#6eafde" stroke-width="3"/></svg>';
        box.querySelectorAll('text').forEach(function (t) {
            var max = t.classList.contains('nm') ? 1136 : 1166, fs = +t.getAttribute('font-size'), n = 0;
            while (t.getComputedTextLength() > max && fs > 20 && n++ < 60) { fs *= 0.97; t.setAttribute('font-size', fs); }
        });
    }
    ['fFull', 'fNick', 'fDept', 'fPos', 'fZoom', 'fPx', 'fPy'].forEach(function (id) { $(id).addEventListener('input', render); });
    if ($('fRemove')) $('fRemove').addEventListener('change', render);
    var input = $('fPhoto');
    function useFile(f) {
        if (!f || !/^image\//.test(f.type)) return;
        // Simpan di input (dikirim saat Simpan) + pratinjau langsung
        try { var dt = new DataTransfer(); dt.items.add(f); input.files = dt.files; } catch (e) {}
        var r = new FileReader();
        r.onload = function () {
            photo = r.result;
            $('ntThumb').innerHTML = '<img src="' + photo + '" alt="" class="w-full h-full object-cover">';
            $('fZoom').value = 100; $('fPx').value = 0; $('fPy').value = 0;
            if ($('fRemove')) $('fRemove').checked = false;
            render();
        };
        r.readAsDataURL(f);
    }
    input.addEventListener('change', function () { if (this.files && this.files[0]) useFile(this.files[0]); });
    $('btnFile').addEventListener('click', function () { input.click(); });
    $('btnCam').addEventListener('click', function () {
        // Kamera langsung (footer.php: itCamera; aplikasi Android / kamera laptop), selain itu pilih file.
        if (window.itCamera) window.itCamera(input, useFile); else input.click();
    });
    render();
    if (document.fonts && document.fonts.load) Promise.all([document.fonts.load('40px NtTagB'), document.fonts.load('40px NtTagL')]).then(render, render);
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
