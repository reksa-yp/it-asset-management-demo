<?php
/**
 * Menu CCTV > Pengaturan (khusus admin):
 *   NVR yang dipantau, pemetaan kamera (aset CCTV) ke NVR/channel atau IP, item checklist,
 *   shift, notifikasi web & email (SMTP), dan cara memasang jadwal pengecekan (Task Scheduler).
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv.php';
require_once __DIR__ . '/includes/cctv_rtsp.php';

$db = getDB();
ensureCctvTables($db);
$h = fn($v) => htmlspecialchars((string)$v);
$back = function (bool $ok, string $text, string $anchor = '') {
    $_SESSION['cctv_msg'] = ['ok' => $ok, 'text' => $text];
    header('Location: cctv_settings.php' . ($anchor ? '#' . $anchor : ''));
    exit;
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $act = (string)($_POST['action'] ?? '');

    if ($act === 'nvr_save') {
        $id    = (int)($_POST['id'] ?? 0);
        $name  = mb_substr(trim((string)($_POST['name'] ?? '')), 0, 60);
        $brand = in_array($_POST['brand'] ?? '', ['hikvision', 'dahua', 'ping'], true) ? $_POST['brand'] : 'hikvision';
        $ip    = trim((string)($_POST['ip_address'] ?? ''));
        $port  = max(1, min(65535, (int)($_POST['port'] ?? 80)));
        $user  = mb_substr(trim((string)($_POST['username'] ?? '')), 0, 60);
        $pass  = (string)($_POST['password'] ?? '');
        $act1  = !empty($_POST['is_active']) ? 1 : 0;
        $rtsp  = max(1, min(65535, (int)($_POST['rtsp_port'] ?? 554) ?: 554));
        $conn  = isset(cctvConnModes()[$_POST['conn_mode'] ?? '']) ? (string)$_POST['conn_mode'] : 'lokal';
        $live  = in_array($_POST['live_view'] ?? '', ['auto', 'snap', 'video'], true) ? (string)$_POST['live_view'] : 'auto';
        $rtTpl = mb_substr(trim((string)($_POST['rtsp_tpl'] ?? '')), 0, 300);
        $snTpl = mb_substr(trim((string)($_POST['snap_tpl'] ?? '')), 0, 300);
        if ($name === '' || $ip === '') $back(false, cL('Nama dan alamat NVR wajib diisi.', 'NVR name and address are required.'), 'nvr');
        if (preg_match('#\s#', $ip)) $back(false, cL('Alamat NVR tidak boleh berisi spasi.', 'The NVR address must not contain spaces.'), 'nvr');
        if ($rtTpl !== '' && !preg_match('#^rtsps?://#i', $rtTpl)) $back(false, cL('Alamat RTSP manual harus diawali rtsp://', 'Manual RTSP address must start with rtsp://'), 'nvr');
        if ($snTpl !== '' && !preg_match('#^(https?://|/)#i', $snTpl)) $back(false, cL('Alamat snapshot manual harus diawali http://, https:// atau /', 'Manual snapshot address must start with http://, https:// or /'), 'nvr');
        if ($conn === 'tunnel' && $port === 80) $port = 443;
        if ($id) {
            if ($pass === '') {
                $db->prepare("UPDATE cctv_nvr SET name=?, brand=?, ip_address=?, port=?, username=?, is_active=? WHERE id=?")->execute([$name, $brand, $ip, $port, $user, $act1, $id]);
            } else {
                $db->prepare("UPDATE cctv_nvr SET name=?, brand=?, ip_address=?, port=?, username=?, password=?, is_active=? WHERE id=?")->execute([$name, $brand, $ip, $port, $user, $pass, $act1, $id]);
            }
        } else {
            $db->prepare("INSERT INTO cctv_nvr (name, brand, ip_address, port, username, password, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
               ->execute([$name, $brand, $ip, $port, $user, $pass, $act1, date('Y-m-d H:i:s')]);
            $id = (int)$db->lastInsertId();
        }
        $cs = cctvSettings();
        $k = (string)$id;
        $rp = (array)$cs['rtsp_port']; $rp[$k] = $rtsp;
        $cm = (array)$cs['nvr_conn']; $cm[$k] = $conn;
        $lv = (array)$cs['live_view']; $lv[$k] = $live;
        $rt = (array)$cs['rtsp_tpl']; if ($rtTpl !== '') $rt[$k] = $rtTpl; else unset($rt[$k]);
        $sn = (array)$cs['snap_tpl']; if ($snTpl !== '') $sn[$k] = $snTpl; else unset($sn[$k]);
        saveCctvSettings(['rtsp_port' => $rp, 'nvr_conn' => $cm, 'live_view' => $lv, 'rtsp_tpl' => $rt, 'snap_tpl' => $sn]);
        $note = '';
        if ($conn === 'agen' && !agentEnabled()) $note = cL(' Aktifkan dulu Agen Kantor di menu Agen Kantor.', ' Enable the Office Agent first.');
        elseif ($conn === 'lokal' && isHostingServer() && agentIsPrivateHost($ip)) $note = cL(' Perhatian: server ini di hosting, IP lokal tidak terjangkau. Pilih IP publik, Cloudflare Tunnel, atau Agen Kantor.', ' Note: this server is on hosting; a local IP is unreachable.');
        $back(true, cL('NVR disimpan.', 'NVR saved.') . $note, 'nvr');
    }
    if ($act === 'nvr_delete') {
        $id = (int)($_POST['id'] ?? 0);
        $db->prepare("DELETE FROM cctv_nvr WHERE id = ?")->execute([$id]);
        $cs = cctvSettings(); $chg = [];
        foreach (['rtsp_port', 'nvr_conn', 'live_view', 'rtsp_tpl', 'snap_tpl'] as $f) { $a = (array)$cs[$f]; unset($a[(string)$id]); $chg[$f] = $a; }
        saveCctvSettings($chg);
        $db->prepare("UPDATE cctv_cameras SET nvr_id = NULL, channel = NULL WHERE nvr_id = ?")->execute([$id]);
        if (cctvTableExists($db, 'cctv_nvr_assets')) $db->prepare("DELETE FROM cctv_nvr_assets WHERE nvr_id = ?")->execute([$id]);
        $back(true, cL('NVR dihapus.', 'NVR deleted.'), 'nvr');
    }
    if ($act === 'nvr_test') {
        $st = $db->prepare("SELECT * FROM cctv_nvr WHERE id = ?");
        $st->execute([(int)($_POST['id'] ?? 0)]);
        $n = $st->fetch();
        if (!$n) $back(false, 'NVR?', 'nvr');
        $r = cctvReadNvr($n, 20);   // lewat Agen Kantor: tunggu maks. 20 detik
        $chs = $r['channels'];
        ksort($chs);
        $list = $chs ? ' · ' . implode(', ', array_map(fn($k, $v) => 'ch' . $k . '=' . cctvStateLabel($v), array_keys($chs), $chs)) : '';
        $back($r['ok'], $n['name'] . ': ' . $r['detail'] . $list, 'nvr');
    }
    if ($act === 'rtsp_test') {
        $st = $db->prepare("SELECT * FROM cctv_nvr WHERE id = ?");
        $st->execute([(int)($_POST['id'] ?? 0)]);
        $n = $st->fetch();
        if (!$n) $back(false, 'NVR?', 'nvr');
        $ch = max(1, (int)($_POST['ch'] ?? 1));
        $t0 = microtime(true);
        if (!is_dir(__DIR__ . '/includes/data/cctv_live')) @mkdir(__DIR__ . '/includes/data/cctv_live', 0775, true);
        $video = cctvLiveUsesVideo($n);
        $jpg = cctvLiveFrame($n, $ch, $err, 480, __DIR__ . '/includes/data/cctv_live/nvr_url.json', cctvNvrConn($n)['mode'] === 'agen' ? 20 : 0);
        $info = $jpg !== '' && function_exists('getimagesizefromstring') ? @getimagesizefromstring($jpg) : null;
        $how = $video ? cL('RTSP/ffmpeg', 'RTSP/ffmpeg') : cL('snapshot HTTP', 'HTTP snapshot');
        $back($jpg !== '', $n['name'] . ' ch ' . $ch . ' — ' . ($jpg !== ''
            ? cL('Gambar berhasil diambil', 'Picture OK') . ' (' . $how . ($info ? ', ' . $info[0] . 'x' . $info[1] : '') . '), ' . number_format(microtime(true) - $t0, 1) . cL(' detik. Live preview siap dipakai.', ' s. Live preview is ready.')
            : $err) . ($video || cctvRtspAllowed($n) ? ' · ' . cctvRtspUrl($n, $ch, 'std', true) : ''), 'nvr');
    }
    if ($act === 'ffmpeg_save') {
        $path = trim((string)($_POST['ffmpeg_path'] ?? ''), " \t\n\r\0\x0B\"");
        saveCctvSettings(['ffmpeg_path' => mb_substr($path, 0, 250)]);
        $back(true, cL('Lokasi ffmpeg disimpan.', 'ffmpeg location saved.'), 'nvr');
    }
    if ($act === 'cams_save') {
        $nvr = (array)($_POST['nvr'] ?? []); $ch = (array)($_POST['ch'] ?? []); $ipo = (array)($_POST['ip'] ?? []);
        $prt = (array)($_POST['port'] ?? []); $mon = (array)($_POST['mon'] ?? []);
        $del = $db->prepare("DELETE FROM cctv_cameras WHERE asset_id = ?");
        $ins = $db->prepare("INSERT INTO cctv_cameras (asset_id, nvr_id, channel, ip_address, port, monitored, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $db->beginTransaction();
        foreach (cctvCameras($db) as $c) {
            $aid = $c['id'];
            if (!array_key_exists($aid, $nvr)) continue;
            $nid = (int)$nvr[$aid] ?: null;
            $chn = (int)($ch[$aid] ?? 0) ?: null;
            $ip  = trim((string)($ipo[$aid] ?? ''));
            $p   = (int)($prt[$aid] ?? 0) ?: null;
            $del->execute([$aid]);
            $ins->execute([$aid, $nid, $nid ? $chn : null, $ip !== '' ? $ip : null, $p, !empty($mon[$aid]) ? 1 : 0, date('Y-m-d H:i:s')]);
        }
        $db->commit();
        $back(true, cL('Pemetaan kamera disimpan. Klik "Cek sekarang" di Monitoring untuk mencoba.', 'Camera mapping saved. Use "Check now" in Monitoring to try it.'), 'cams');
    }
    if ($act === 'items_save') {
        $rows = (array)($_POST['item'] ?? []);
        $upd = $db->prepare("UPDATE cctv_check_items SET code=?, label=?, sort_order=?, is_active=? WHERE id=?");
        $codes = [];
        foreach ($rows as $id => $r) {
            $code = strtoupper(mb_substr(trim((string)($r['code'] ?? '')), 0, 5));
            $label = mb_substr(trim((string)($r['label'] ?? '')), 0, 100);
            if ($code === '' || $label === '' || isset($codes[$code])) continue;
            $codes[$code] = true;
            $upd->execute([$code, $label, (int)($r['sort'] ?? 0), !empty($r['active']) ? 1 : 0, (int)$id]);
        }
        $nc = strtoupper(mb_substr(trim((string)($_POST['new_code'] ?? '')), 0, 5));
        $nl = mb_substr(trim((string)($_POST['new_label'] ?? '')), 0, 100);
        if ($nc !== '' && $nl !== '' && !isset($codes[$nc])) {
            $max = (int)$db->query("SELECT COALESCE(MAX(sort_order), 0) FROM cctv_check_items")->fetchColumn();
            $db->prepare("INSERT INTO cctv_check_items (code, label, sort_order, is_active) VALUES (?, ?, ?, 1)")->execute([$nc, $nl, $max + 1]);
        }
        $back(true, cL('Item checklist disimpan.', 'Checklist items saved.'), 'items');
    }
    if ($act === 'off_week_save') {
        $wd = array_values(array_filter(array_map('intval', (array)($_POST['off_wd'] ?? [])), fn($d) => $d >= 1 && $d <= 7));
        sort($wd);
        saveCctvSettings(['off_weekdays' => $wd]);
        $back(true, cL('Hari libur mingguan disimpan.', 'Weekly days off saved.'), 'holidays');
    }
    if ($act === 'holiday_add') {
        $from = (string)($_POST['h_from'] ?? '');
        $to   = (string)($_POST['h_to'] ?? '') ?: $from;
        $name = mb_substr(trim((string)($_POST['h_name'] ?? '')), 0, 100);
        $okDate = fn($d) => preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && strtotime($d);
        if (!$okDate($from) || !$okDate($to) || $to < $from) $back(false, cL('Tanggal libur tidak valid.', 'Invalid date.'), 'holidays');
        if ($name === '') $back(false, cL('Isi keterangan libur (mis. Cuti bersama Idulfitri).', 'Enter a holiday name.'), 'holidays');
        if ((strtotime($to) - strtotime($from)) / 86400 > 31) $back(false, cL('Rentang libur maksimal 31 hari.', 'Maximum range is 31 days.'), 'holidays');
        $del = $db->prepare("DELETE FROM cctv_holidays WHERE holiday_date = ?");
        $ins = $db->prepare("INSERT INTO cctv_holidays (holiday_date, name, created_at) VALUES (?, ?, ?)");
        $n = 0;
        for ($t = strtotime($from); $t <= strtotime($to); $t = strtotime('+1 day', $t)) {
            $d = date('Y-m-d', $t);
            $del->execute([$d]);
            $ins->execute([$d, $name, date('Y-m-d H:i:s')]);
            // Checklist susulan otomatis di tanggal libur ini dihapus (checklist yang diisi petugas tetap).
            $ids = $db->prepare("SELECT id FROM cctv_checklists WHERE check_date = ? AND user_name LIKE '%(susulan)'");
            $ids->execute([$d]);
            foreach ($ids->fetchAll(PDO::FETCH_COLUMN) as $cid) {
                $db->prepare("DELETE FROM cctv_checklist_results WHERE checklist_id = ?")->execute([(int)$cid]);
                $db->prepare("DELETE FROM cctv_checklist_nvr WHERE checklist_id = ?")->execute([(int)$cid]);
                $db->prepare("DELETE FROM cctv_checklists WHERE id = ?")->execute([(int)$cid]);
            }
            $n++;
        }
        $_SESSION['cctv_hol_year'] = substr($from, 0, 4);
        $back(true, cL("$n hari libur ditambahkan.", "$n day(s) off added."), 'holidays');
    }
    if ($act === 'holiday_delete') {
        $db->prepare("DELETE FROM cctv_holidays WHERE holiday_date = ?")->execute([(string)($_POST['h_date'] ?? '')]);
        $back(true, cL('Hari libur dihapus.', 'Day off removed.'), 'holidays');
    }
    if ($act === 'general_save') {
        $shifts = array_values(array_filter(array_map('trim', explode(',', (string)($_POST['shifts'] ?? ''))), 'strlen'));
        $changes = [
            'checklist_mode' => ($_POST['checklist_mode'] ?? '') === 'daily' ? 'daily' : 'shift',
            'shifts'         => $shifts ?: ['Pagi', 'Sore'],
            'shift_roles'    => array_map(fn($r) => in_array($r, ['admin', 'cctv', 'both'], true) ? $r : 'admin', (array)($_POST['shift_role'] ?? [])),
            'fail_threshold' => max(1, min(10, (int)($_POST['fail_threshold'] ?? 2))),
            'interval_min'   => max(1, min(60, (int)($_POST['interval_min'] ?? 2))),
            'notify_web'     => !empty($_POST['notify_web']),
            'web_after_min'  => in_array((int)($_POST['web_after_min'] ?? 10), [0, 2, 5, 10, 15, 30], true) ? (int)$_POST['web_after_min'] : 10,
            'notify_recover' => !empty($_POST['notify_recover']),
        ];
        if (!empty($_POST['new_key'])) $changes['check_key'] = bin2hex(random_bytes(12));
        if (!empty($_POST['clear_key'])) $changes['check_key'] = '';
        saveCctvSettings($changes);
        $back(true, cL('Pengaturan disimpan.', 'Settings saved.'), 'general');
    }
    if ($act === 'email_save' || $act === 'email_test') {
        $changes = [
            'notify_email'   => !empty($_POST['notify_email']),
            'email_after_min'=> max(0, min(1440, (int)($_POST['email_after_min'] ?? 30))),
            'email_to'       => trim((string)($_POST['email_to'] ?? '')),
            'smtp_host'      => trim((string)($_POST['smtp_host'] ?? '')),
            'smtp_port'      => max(1, min(65535, (int)($_POST['smtp_port'] ?? 587))),
            'smtp_secure'    => in_array($_POST['smtp_secure'] ?? '', ['tls', 'ssl', 'none'], true) ? $_POST['smtp_secure'] : 'tls',
            'smtp_user'      => trim((string)($_POST['smtp_user'] ?? '')),
            'smtp_from'      => trim((string)($_POST['smtp_from'] ?? '')),
            'smtp_from_name' => trim((string)($_POST['smtp_from_name'] ?? '')) ?: 'IT System - CCTV',
        ];
        if ((string)($_POST['smtp_pass'] ?? '') !== '') $changes['smtp_pass'] = (string)$_POST['smtp_pass'];
        saveCctvSettings($changes);
        if ($act === 'email_save') $back(true, cL('Pengaturan email disimpan.', 'Email settings saved.'), 'email');
        $s = cctvSettings(true);
        $to = cctvEmailRecipients($s);
        $err = $to ? cctvSmtpSend($s, $to, '[CCTV] Tes notifikasi email',
            '<div style="font-family:Arial,sans-serif;font-size:13px"><p><b>Tes email berhasil.</b></p><p>Notifikasi CCTV mati / hidup kembali akan dikirim ke alamat ini oleh IT System.</p><p style="color:#64748b">Dikirim ' . date('d M Y H:i') . '</p></div>')
            : cL('Isi dulu alamat email penerima.', 'Fill in the recipient address first.');
        $back($err === '', $err === '' ? cL('Email tes terkirim ke ', 'Test email sent to ') . implode(', ', $to) . cL('. Cek kotak masuk (juga folder Spam).', '. Check the inbox (and Spam).') : $err, 'email');
    }
}
$msg = $_SESSION['cctv_msg'] ?? null;
unset($_SESSION['cctv_msg']);

$set   = cctvSettings(true);
$nvrs  = cctvNvrList($db);
$cams  = cctvCameras($db);
$items = cctvCheckItems($db, false);
$nvrToAsset = cctvNvrToAsset($db);
$assetNo = [];
if ($nvrToAsset) {
    $st = $db->prepare("SELECT id, asset_number FROM assets WHERE id IN (" . implode(',', array_fill(0, count($nvrToAsset), '?')) . ")");
    $st->execute(array_values($nvrToAsset));
    foreach ($st->fetchAll() as $r) $assetNo[(int)$r['id']] = $r['asset_number'];
}
$editNvr = isset($_GET['edit_nvr']) ? ($nvrs[(int)$_GET['edit_nvr']] ?? null) : null;
$appDir  = str_replace('/', '\\', __DIR__);
$phpExe  = (PHP_OS_FAMILY === 'Windows' && PHP_BINARY && stripos(PHP_BINARY, 'php') !== false && stripos(PHP_BINARY, 'httpd') === false) ? PHP_BINARY : 'C:\\xampp\\php\\php.exe';
$input = 'border border-slate-300 rounded-lg px-2 py-1.5 text-sm';
$card  = 'bg-white rounded-xl shadow-sm p-5 mb-5 scroll-mt-4';

$pageTitle = cL('Pengaturan CCTV', 'CCTV Settings');
$cctvTab = 'settings';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="mb-3">
    <h1 class="text-xl font-semibold text-slate-800"><?= $h(cL('Pengaturan CCTV', 'CCTV Settings')) ?></h1>
    <p class="text-sm text-slate-500"><?= $h(cL('Urutan pemasangan: 1) daftarkan NVR, 2) petakan kamera ke NVR/channel, 3) atur notifikasi email, 4) pasang jadwal pengecekan.', 'Setup order: 1) add NVR, 2) map cameras, 3) email notification, 4) schedule the check.')) ?></p>
</div>

<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<?php if (isHostingServer()): ?>
    <div class="mb-4 text-sm rounded-lg px-4 py-3 bg-blue-50 border border-blue-100 text-slate-700">
        <b><?= $h(cL('Server ini berjalan di hosting.', 'This server runs on web hosting.')) ?></b>
        <?= $h(cL('NVR ber-IP lokal tidak bisa dijangkau langsung. Pilih "IP publik / DDNS", "Cloudflare Tunnel", atau "Agen Kantor" pada NVR. Live preview memakai snapshot bila ffmpeg tidak ada.', 'Local NVR IPs are unreachable. Use Public IP / DDNS, Cloudflare Tunnel or the Office Agent. Live preview uses snapshots without ffmpeg.')) ?>
        <a href="agent.php" class="text-blue-700 underline"><?= $h(agentStatusText()) ?></a>
    </div>
<?php endif; ?>
<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 break-words <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<!-- 1. NVR -->
<section id="nvr" class="<?= $card ?>">
    <h2 class="font-semibold text-slate-800 mb-1">1. NVR / DVR</h2>
    <p class="text-xs text-slate-600 mb-2"><?= $h(cL('NVR yang diinput sebagai aset (kategori NVR) otomatis masuk ke daftar ini. NVR juga bisa ditambah langsung di sini.', 'NVRs added as assets (NVR category) appear here automatically. You can also add one here.')) ?></p>
    <p class="text-xs text-slate-500 mb-3"><?= $h(cL('Hikvision & Dahua: status tiap channel dibaca langsung dari NVR (butuh user/password NVR, sebaiknya user khusus hak "lihat saja"). "Cek port saja" hanya mengecek NVR menyala; kamera lalu dicek lewat IP-nya masing-masing.', 'Hikvision & Dahua: per-channel status is read from the NVR (needs an NVR user). "Port check only" just checks the NVR is up; cameras are then checked by their own IP.')) ?></p>
    <?php if ($nvrs): ?>
    <div class="overflow-x-auto mb-4"><table class="w-full text-sm">
        <thead class="bg-slate-50 text-slate-500 text-xs"><tr><th class="text-left px-3 py-2"><?= $h(cL('Nama', 'Name')) ?></th><th class="text-left px-3 py-2"><?= $h(cL('Merk', 'Brand')) ?></th><th class="text-left px-3 py-2"><?= $h(cL('Alamat', 'Address')) ?></th><th class="text-left px-3 py-2">RTSP</th><th class="text-left px-3 py-2">User</th><th class="text-left px-3 py-2">Status</th><th class="px-3 py-2"></th></tr></thead>
        <tbody>
        <?php foreach ($nvrs as $n): ?>
            <tr class="border-t">
                <td class="px-3 py-2 font-medium"><?= $h($n['name']) ?><?= (int)$n['is_active'] ? '' : ' <span class="text-xs text-slate-400">(' . $h(cL('nonaktif', 'inactive')) . ')</span>' ?>
                    <?php if (isset($nvrToAsset[(int)$n['id']])): ?><div class="text-xs font-normal text-slate-500"><?= $h(cL('dari aset', 'from asset')) ?> <?= $h($assetNo[$nvrToAsset[(int)$n['id']]] ?? '#' . $nvrToAsset[(int)$n['id']]) ?></div><?php endif; ?></td>
                <td class="px-3 py-2"><?= $h(['hikvision' => 'Hikvision', 'dahua' => 'Dahua', 'ping' => cL('Cek port saja', 'Port check only')][$n['brand']] ?? $n['brand']) ?></td>
                <?php $nc = cctvNvrConn($n); ?>
                <td class="px-3 py-2 text-xs"><span class="font-mono"><?= $h($nc['mode'] === 'agen' ? $n['ip_address'] . ':' . (int)$n['port'] : cctvNvrBase($n)) ?></span>
                    <div class="mt-0.5"><span class="inline-block rounded-full px-2 py-0.5 text-[11px] font-semibold <?= ['lokal' => 'bg-slate-100 text-slate-700', 'publik' => 'bg-blue-50 text-blue-800', 'tunnel' => 'bg-orange-50 text-orange-800', 'agen' => 'bg-violet-50 text-violet-800'][$nc['mode']] ?>"><?= $h(cctvConnModes()[$nc['mode']][0]) ?></span>
                    <?php if (cctvNvrUnreachable($n)): ?><span class="text-red-700"><?= $h(cL('tidak terjangkau dari hosting', 'unreachable from hosting')) ?></span><?php endif; ?></div></td>
                <td class="px-3 py-2 font-mono text-xs"><?= cctvRtspAllowed($n) ? cctvRtspPort($n) . ($nc['rtsp_tpl'] !== '' ? ' <span class="font-sans text-slate-500">(' . $h(cL('manual', 'manual')) . ')</span>' : '') : '-' ?>
                    <div class="font-sans text-slate-500"><?= $h(cctvLiveAvailable($n) ? (cctvLiveUsesVideo($n) ? cL('Live: video', 'Live: video') : cL('Live: snapshot', 'Live: snapshot')) : cL('Live: -', 'Live: -')) ?></div></td>
                <td class="px-3 py-2 text-xs"><?= $h($n['username']) ?></td>
                <td class="px-3 py-2 text-xs"><?= $n['last_check'] ? cctvStateBadge($n['last_state'] === 'on' ? 'on' : 'off') . ' <span class="text-slate-500">' . $h($n['last_detail']) . '</span>' : '-' ?></td>
                <td class="px-3 py-2 whitespace-nowrap text-right">
                    <form method="post" class="inline"><input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="nvr_test"><input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
                        <button class="px-2 py-1 rounded-lg border border-slate-300 hover:bg-slate-50 text-xs"><?= $h(cL('Tes koneksi', 'Test')) ?></button></form>
                    <?php if (cctvLiveAvailable($n)): ?>
                    <form method="post" class="inline-flex items-center gap-1" title="<?= $h(cL('Ambil 1 gambar dari channel ini (RTSP atau snapshot HTTP)', 'Grab one picture from this channel (RTSP or HTTP snapshot)')) ?>"><input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="rtsp_test"><input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
                        <input type="number" name="ch" value="1" min="1" max="256" class="w-14 border border-slate-300 rounded-lg px-1 py-0.5 text-xs" aria-label="Channel">
                        <button class="px-2 py-1 rounded-lg border border-slate-300 hover:bg-slate-50 text-xs"><?= $h(cL('Tes gambar', 'Test picture')) ?></button></form>
                    <?php endif; ?>
                    <a href="cctv_settings.php?edit_nvr=<?= (int)$n['id'] ?>#nvr" class="px-2 py-1 rounded-lg border border-slate-300 hover:bg-slate-50 text-xs inline-block"><?= $h(cL('Ubah', 'Edit')) ?></a>
                    <form method="post" class="inline" onsubmit="return confirm('<?= $h(cL('Hapus NVR ini?', 'Delete this NVR?')) ?>')"><input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="nvr_delete"><input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
                        <button class="px-2 py-1 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 text-xs"><?= $h(cL('Hapus', 'Delete')) ?></button></form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?php endif; ?>
    <?php $ec = $editNvr ? cctvNvrConn($editNvr) : ['mode' => isHostingServer() ? (agentEnabled() ? 'agen' : 'publik') : 'lokal', 'rtsp_tpl' => '', 'snap_tpl' => '', 'live' => 'auto']; ?>
    <form method="post" id="nvrForm" class="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 items-end text-sm">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="nvr_save">
        <input type="hidden" name="id" value="<?= (int)($editNvr['id'] ?? 0) ?>">
        <p class="sm:col-span-2 lg:col-span-4 font-medium text-slate-700"><?= $h($editNvr ? cL('Ubah NVR: ', 'Edit NVR: ') . $editNvr['name'] : cL('Tambah NVR', 'Add NVR')) ?></p>
        <fieldset class="sm:col-span-2 lg:col-span-4">
            <legend class="text-xs text-slate-500 mb-1"><?= $h(cL('Cara server terhubung ke NVR', 'How the server reaches the NVR')) ?>
                · <?= $h(cL('Server ini: ', 'This server: ')) ?><b><?= $h(isHostingServer() ? cL('hosting', 'hosting') : cL('jaringan kantor', 'office network')) ?></b></legend>
            <div class="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                <?php foreach (cctvConnModes() as $k => [$label, $desc]): ?>
                <label class="flex gap-2 items-start rounded-lg border border-slate-200 p-2.5 cursor-pointer has-[:checked]:border-blue-600 has-[:checked]:bg-blue-50">
                    <input type="radio" name="conn_mode" value="<?= $k ?>" <?= $ec['mode'] === $k ? 'checked' : '' ?> class="mt-0.5 w-4 h-4">
                    <span><span class="font-medium text-slate-800"><?= $h($label) ?></span><span class="block text-xs text-slate-600"><?= $h($desc) ?></span></span>
                </label>
                <?php endforeach; ?>
            </div>
        </fieldset>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Nama', 'Name')) ?></span><input name="name" required maxlength="60" value="<?= $h($editNvr['name'] ?? '') ?>" placeholder="NVR-01 Gudang" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Merk', 'Brand')) ?></span>
            <select name="brand" id="nvrBrand" class="<?= $input ?>">
                <?php foreach (['hikvision' => 'Hikvision (ISAPI)', 'dahua' => 'Dahua (HTTP API)', 'ping' => cL('Merk lain: cek port + alamat manual', 'Other: port check + manual address')] as $k => $v): ?>
                    <option value="<?= $k ?>" <?= ($editNvr['brand'] ?? 'hikvision') === $k ? 'selected' : '' ?>><?= $h($v) ?></option>
                <?php endforeach; ?>
            </select></label>
        <label class="flex flex-col gap-1 sm:col-span-2"><span class="text-xs text-slate-500" id="nvrHostLabel"><?= $h(cL('Alamat NVR', 'NVR address')) ?></span>
            <input name="ip_address" id="nvrHost" required maxlength="60" value="<?= $h($editNvr['ip_address'] ?? '') ?>" placeholder="192.168.1.20" autocomplete="off" class="<?= $input ?> font-mono">
            <span class="text-xs text-slate-500" id="nvrHostHelp"></span></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500" id="nvrPortLabel"><?= $h(cL('Port HTTP', 'HTTP port')) ?></span><input name="port" id="nvrPort" type="number" min="1" max="65535" value="<?= (int)($editNvr['port'] ?? 80) ?>" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1" id="nvrRtspWrap"><span class="text-xs text-slate-500" id="nvrRtspLabel"><?= $h(cL('Port RTSP (video live)', 'RTSP port (live video)')) ?></span><input name="rtsp_port" id="nvrRtsp" type="number" min="1" max="65535" value="<?= $editNvr ? cctvRtspPort($editNvr) : 554 ?>" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">Username NVR</span><input name="username" id="nvrUser" value="<?= $h($editNvr['username'] ?? '') ?>" autocomplete="off" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">Password NVR</span><input name="password" type="password" autocomplete="new-password" placeholder="<?= $h($editNvr ? cL('kosongkan = tidak diubah', 'blank = unchanged') : '') ?>" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1" title="<?= $h(cL('Otomatis = video RTSP bila ffmpeg ada di server, selain itu snapshot.', 'Automatic = RTSP video when ffmpeg exists, otherwise snapshots.')) ?>"><span class="text-xs text-slate-500"><?= $h(cL('Tampilan live', 'Live view')) ?></span>
            <select name="live_view" class="<?= $input ?>">
                <?php foreach (['auto' => cL('Otomatis', 'Automatic'), 'snap' => cL('Snapshot', 'Snapshot'), 'video' => cL('Video RTSP (ffmpeg)', 'RTSP video (ffmpeg)')] as $k => $v): ?>
                    <option value="<?= $k ?>" <?= $ec['live'] === $k ? 'selected' : '' ?>><?= $h($v) ?></option>
                <?php endforeach; ?>
            </select></label>
        <label class="flex items-center gap-2 pb-2"><input type="checkbox" name="is_active" value="1" <?= ($editNvr['is_active'] ?? 1) ? 'checked' : '' ?> class="w-4 h-4"> <?= $h(cL('Aktif dipantau', 'Monitor this NVR')) ?></label>

        <details class="sm:col-span-2 lg:col-span-4 rounded-lg border border-slate-200 bg-slate-50/60 p-3" <?= ($ec['rtsp_tpl'] !== '' || $ec['snap_tpl'] !== '' || ($editNvr['brand'] ?? '') === 'ping') ? 'open' : '' ?>>
            <summary class="cursor-pointer font-medium text-slate-700"><?= $h(cL('Alamat manual (opsional) — untuk merek lain atau format khusus', 'Manual addresses (optional) — for other brands or custom formats')) ?></summary>
            <div class="grid gap-3 lg:grid-cols-2 mt-3">
                <label class="flex flex-col gap-1" id="nvrRtspTplWrap"><span class="text-xs text-slate-500"><?= $h(cL('Alamat RTSP manual (kosong = otomatis sesuai merek)', 'Manual RTSP address (blank = automatic by brand)')) ?></span>
                    <input name="rtsp_tpl" id="nvrRtspTpl" maxlength="300" value="<?= $h($ec['rtsp_tpl']) ?>" placeholder="rtsp://{user}:{pass}@{host}:{port}/Streaming/Channels/{ch}02" class="<?= $input ?> font-mono text-xs"></label>
                <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Alamat snapshot manual (kosong = otomatis sesuai merek)', 'Manual snapshot address (blank = automatic by brand)')) ?></span>
                    <input name="snap_tpl" id="nvrSnapTpl" maxlength="300" value="<?= $h($ec['snap_tpl']) ?>" placeholder="/cgi-bin/snapshot.cgi?channel={ch}" class="<?= $input ?> font-mono text-xs"></label>
                <p class="lg:col-span-2 text-xs text-slate-600"><?= $h(cL('Kode yang bisa dipakai: {user} {pass} {host} {port} {ch} (nomor channel), {ch0} (channel - 1), {ch2} (2 digit, mis. 01). Snapshot boleh hanya path (diawali /), alamat & port HTTP di atas dipakai otomatis.', 'Codes: {user} {pass} {host} {port} {ch}, {ch0} (channel - 1), {ch2} (2 digits). A snapshot path starting with / uses the address & HTTP port above.')) ?></p>
            </div>
        </details>
        <div class="sm:col-span-2 lg:col-span-4 rounded-lg bg-slate-900 text-slate-100 px-3 py-2 font-mono text-xs break-all" id="nvrPreview"></div>

        <div class="flex gap-2 pb-0.5 sm:col-span-2 lg:col-span-4">
            <button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= $h(cL('Simpan NVR', 'Save NVR')) ?></button>
            <?php if ($editNvr): ?><a href="cctv_settings.php#nvr" class="px-3 py-1.5 text-slate-500"><?= $h(cL('Batal', 'Cancel')) ?></a><?php endif; ?>
        </div>
    </form>
    <script>
    (function () {
        var f = document.getElementById('nvrForm'); if (!f) return;
        var T = <?= json_encode([
            'host' => ['lokal' => cL('IP lokal NVR', 'NVR local IP'), 'publik' => cL('IP publik atau nama DDNS', 'Public IP or DDNS name'), 'tunnel' => cL('Hostname Cloudflare Tunnel', 'Cloudflare Tunnel hostname'), 'agen' => cL('IP lokal NVR (dibaca oleh Agen Kantor)', 'NVR local IP (read by the Office Agent)')],
            'ph'   => ['lokal' => '192.168.1.20', 'publik' => '103.147.92.15 / kantor.ddns.net', 'tunnel' => 'nvr1.domainanda.com', 'agen' => '192.168.1.20'],
            'help' => ['lokal' => cL('Server harus berada di jaringan kantor (XAMPP / server lokal).', 'The server must be on the office network.'),
                       'publik' => cL('Port di bawah = port luar yang diteruskan router ke NVR (port forwarding). Pakai port selain 80/554 dan password NVR yang kuat.', 'Ports below = external ports forwarded by the router to the NVR.'),
                       'tunnel' => cL('Di Cloudflare Zero Trust > Tunnels: Public Hostname ini diarahkan ke http://IP-NVR:80. Port 443.', 'In Cloudflare Zero Trust > Tunnels: point this hostname to http://NVR-IP:80. Port 443.'),
                       'agen' => cL('Server tidak menghubungi NVR langsung. Agen Kantor di PC kantor yang membaca NVR. Video RTSP tidak tersedia, live memakai snapshot.', 'The Office Agent reads the NVR. No RTSP video; live uses snapshots.')],
            'port' => ['lokal' => cL('Port HTTP', 'HTTP port'), 'publik' => cL('Port HTTP (luar)', 'HTTP port (external)'), 'tunnel' => cL('Port HTTPS', 'HTTPS port'), 'agen' => cL('Port HTTP', 'HTTP port')],
            'rtsp' => ['lokal' => cL('Port RTSP (video live)', 'RTSP port (live video)'), 'publik' => cL('Port RTSP (luar)', 'RTSP port (external)')],
            'snapOnly' => cL('Live memakai snapshot HTTP (RTSP tidak tersedia untuk cara ini).', 'Live uses HTTP snapshots (no RTSP for this mode).'),
            'rtspUrl' => cL('Alamat RTSP channel 1: ', 'RTSP address channel 1: '), 'snapUrl' => cL('Snapshot channel 1: ', 'Snapshot channel 1: '), 'none' => cL('Merk lain: isi alamat manual untuk live preview.', 'Other brand: fill a manual address for live preview.'),
        ], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
        function v(id) { var e = document.getElementById(id); return e ? e.value.trim() : ''; }
        function mode() { var r = f.querySelector('input[name="conn_mode"]:checked'); return r ? r.value : 'lokal'; }
        function fill(t, port) {
            return t.split('{user}').join(encodeURIComponent(v('nvrUser'))).split('{pass}').join('****').split('{host}').join(host())
                .split('{port}').join(port).split('{ch}').join('1').split('{ch0}').join('0').split('{ch2}').join('01');
        }
        function host() { return v('nvrHost').replace(/^[a-z]+:\/\//i, '').replace(/\/.*$/, '').replace(/:\d+$/, '') || 'IP'; }
        function upd() {
            var m = mode(), brand = v('nvrBrand'), port = v('nvrPort') || '80', rtspOk = m === 'lokal' || m === 'publik';
            document.getElementById('nvrHostLabel').textContent = T.host[m];
            document.getElementById('nvrHost').placeholder = T.ph[m];
            document.getElementById('nvrHostHelp').textContent = T.help[m];
            document.getElementById('nvrPortLabel').textContent = T.port[m];
            document.getElementById('nvrRtspWrap').style.display = rtspOk ? '' : 'none';
            document.getElementById('nvrRtspTplWrap').style.display = rtspOk ? '' : 'none';
            if (rtspOk) document.getElementById('nvrRtspLabel').textContent = T.rtsp[m];
            var https = m === 'tunnel' || port === '443', base = /^https?:\/\//i.test(v('nvrHost')) ? v('nvrHost').replace(/\/$/, '') : (https ? 'https://' : 'http://') + host() + ((port === '80' && !https) || (port === '443' && https) ? '' : ':' + port);
            var rt = v('nvrRtspTpl'), sn = v('nvrSnapTpl'), lines = [];
            if (rtspOk) {
                var auto = brand === 'dahua' ? 'rtsp://{user}:{pass}@{host}:{port}/cam/realmonitor?channel={ch}&subtype=1' : (brand === 'hikvision' ? 'rtsp://{user}:{pass}@{host}:{port}/Streaming/Channels/{ch}02' : '');
                if (rt || auto) lines.push(T.rtspUrl + fill(rt || auto, v('nvrRtsp') || '554'));
            } else lines.push(T.snapOnly);
            var sAuto = brand === 'dahua' ? '/cgi-bin/snapshot.cgi?channel={ch}' : (brand === 'hikvision' ? '/ISAPI/Streaming/channels/{ch}01/picture' : '');
            if (sn || sAuto) { var su = fill(sn || sAuto, port); lines.push(T.snapUrl + (/^https?:\/\//i.test(su) ? su : base + su)); }
            if (brand === 'ping' && !rt && !sn) lines.push(T.none);
            document.getElementById('nvrPreview').textContent = lines.join('\n');
            document.getElementById('nvrPreview').style.whiteSpace = 'pre-line';
        }
        f.addEventListener('input', upd); f.addEventListener('change', function (e) {
            if (e.target.name === 'conn_mode') { var p = document.getElementById('nvrPort'); if (e.target.value === 'tunnel' && p.value === '80') p.value = '443'; else if (e.target.value !== 'tunnel' && p.value === '443') p.value = '80'; }
            upd();
        });
        upd();
    })();
    </script>

    <?php $ffBin = cctvFfmpegPath(); $ffVer = cctvFfmpegVersion($ffBin); ?>
    <div class="mt-5 rounded-lg border <?= $ffBin !== '' ? 'border-green-200 bg-green-50/50' : 'border-amber-200 bg-amber-50' ?> p-3 text-sm">
        <p class="font-medium text-slate-700"><?= $h(cL('Live preview: video RTSP (ffmpeg) atau snapshot', 'Live preview: RTSP video (ffmpeg) or snapshots')) ?></p>
        <p class="text-xs text-slate-600 mt-1"><?= $h(cL('Dengan ffmpeg di server, "Lihat live" memutar video dari RTSP sub-stream NVR. Tanpa ffmpeg (mis. di hosting), atau untuk Cloudflare Tunnel & Agen Kantor, live memakai snapshot HTTP dari NVR yang diperbarui ±1-2 detik sekali.', 'With ffmpeg on the server, live view plays the RTSP sub-stream. Without ffmpeg (e.g. hosting), or via Cloudflare Tunnel / Office Agent, live uses HTTP snapshots refreshed every 1-2 s.')) ?></p>
        <p class="text-xs mt-2"><?= $ffBin !== ''
            ? '<span class="text-green-700 font-semibold">' . $h(cL('ffmpeg ditemukan', 'ffmpeg found')) . '</span> <span class="font-mono text-slate-600">' . $h($ffBin) . '</span>' . ($ffVer !== '' ? ' · v' . $h($ffVer) : '')
            : '<span class="text-amber-800 font-semibold">' . $h(cL('ffmpeg belum ditemukan: live memakai snapshot.', 'ffmpeg not found: live uses snapshots.')) . '</span> ' . $h(isHostingServer() ? cL('Shared hosting umumnya tidak menyediakan ffmpeg; snapshot tetap berjalan.', 'Shared hosting usually has no ffmpeg; snapshots still work.') : cL('Untuk video: unduh "ffmpeg-release-essentials.zip" dari gyan.dev, ekstrak sehingga ada C:\\xampp\\ffmpeg\\bin\\ffmpeg.exe, lalu muat ulang halaman ini.', 'For video: download ffmpeg (essentials build), extract to C:\\xampp\\ffmpeg\\bin\\ffmpeg.exe and reload.')) ?></p>
        <form method="post" class="mt-2 flex flex-wrap items-end gap-2">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="ffmpeg_save">
            <label class="flex flex-col gap-1 flex-1 min-w-[240px]"><span class="text-xs text-slate-500"><?= $h(cL('Lokasi ffmpeg.exe (kosongkan = cari otomatis)', 'ffmpeg.exe location (blank = auto)')) ?></span>
                <input name="ffmpeg_path" value="<?= $h($set['ffmpeg_path']) ?>" placeholder="C:\xampp\ffmpeg\bin\ffmpeg.exe" class="<?= $input ?> font-mono text-xs"></label>
            <button class="px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-white text-xs"><?= $h(cL('Simpan', 'Save')) ?></button>
        </form>
    </div>
</section>

<!-- 2. Kamera -->
<section id="cams" class="<?= $card ?>">
    <h2 class="font-semibold text-slate-800 mb-1">2. <?= $h(cL('Pemetaan kamera', 'Camera mapping')) ?></h2>
    <p class="text-xs text-slate-500 mb-3"><?= $h(cL('Daftar diambil dari aset kategori CCTV. Pilih NVR + nomor channel (sesuai tampilan di NVR, mis. D1 = 1). Kamera yang tersambung ke switch boleh tanpa NVR: cukup IP (default dari data aset) dan port (kosong = 554/80).', 'Taken from CCTV-category assets. Pick NVR + channel number (e.g. D1 = 1). Cameras on a switch can skip NVR: IP (defaults to the asset IP) and port (blank = 554/80).')) ?></p>
    <?php if (!$cams): ?>
        <p class="text-sm text-slate-500"><?= $h(cL('Belum ada aset kategori CCTV. Tambahkan kategori "CCTV" di Kategori Aset, lalu input kamera di menu Asset.', 'No CCTV assets yet.')) ?></p>
    <?php else: ?>
    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="cams_save">
        <div class="overflow-x-auto"><table class="w-full text-sm">
            <thead class="bg-slate-50 text-slate-500 text-xs"><tr>
                <th class="text-left px-3 py-2"><?= $h(cL('Kamera', 'Camera')) ?></th><th class="text-left px-3 py-2">NVR</th><th class="text-left px-3 py-2">Channel</th>
                <th class="text-left px-3 py-2"><?= $h(cL('IP kamera', 'Camera IP')) ?></th><th class="text-left px-3 py-2">Port</th><th class="text-left px-3 py-2"><?= $h(cL('Pantau', 'Monitor')) ?></th><th class="text-left px-3 py-2"><?= $h(cL('Cara cek', 'Method')) ?></th>
            </tr></thead>
            <tbody>
            <?php foreach ($cams as $c): $m = cctvCheckMethod($c); ?>
                <tr class="border-t">
                    <td class="px-3 py-2 min-w-[180px]"><div class="font-medium"><?= $h($c['location'] ?: $c['name']) ?></div><div class="text-xs text-slate-500"><?= $h($c['number']) ?> · <?= $h($c['name']) ?></div></td>
                    <td class="px-3 py-2"><select name="nvr[<?= $c['id'] ?>]" class="<?= $input ?> min-w-[130px]"><option value="0">— <?= $h(cL('tanpa NVR', 'none')) ?> —</option>
                        <?php foreach ($nvrs as $n): ?><option value="<?= (int)$n['id'] ?>" <?= (int)$c['nvr_id'] === (int)$n['id'] ? 'selected' : '' ?>><?= $h($n['name']) ?></option><?php endforeach; ?></select></td>
                    <td class="px-3 py-2"><input type="number" min="1" max="256" name="ch[<?= $c['id'] ?>]" value="<?= $h($c['channel'] ?? '') ?>" class="<?= $input ?> w-20"></td>
                    <td class="px-3 py-2"><input name="ip[<?= $c['id'] ?>]" value="<?= $h($c['ip_override']) ?>" placeholder="<?= $h($c['asset_ip'] ?: cL('IP di data aset', 'asset IP')) ?>" class="<?= $input ?> w-36 font-mono"></td>
                    <td class="px-3 py-2"><input type="number" min="1" max="65535" name="port[<?= $c['id'] ?>]" value="<?= $h($c['port'] ?? '') ?>" placeholder="554" class="<?= $input ?> w-20"></td>
                    <td class="px-3 py-2 text-center"><input type="checkbox" name="mon[<?= $c['id'] ?>]" value="1" <?= $c['monitored'] ? 'checked' : '' ?> class="w-4 h-4"></td>
                    <td class="px-3 py-2 text-xs whitespace-nowrap"><?= $m === 'nvr' ? $h('NVR ' . $c['nvr_name'] . ' ch ' . $c['channel']) : ($m === 'ip' ? $h('IP ' . $c['ip']) : '<span class="text-amber-600">' . $h(cL('belum bisa dicek', 'not checkable')) . '</span>') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <button class="mt-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 text-sm font-medium"><?= $h(cL('Simpan pemetaan', 'Save mapping')) ?></button>
    </form>
    <?php endif; ?>
</section>

<!-- 3. Notifikasi email -->
<section id="email" class="<?= $card ?>">
    <h2 class="font-semibold text-slate-800 mb-1">3. <?= $h(cL('Notifikasi email', 'Email notification')) ?></h2>
    <p class="text-xs text-slate-500 mb-3"><?= $h(cL('Dikirim saat kamera terdeteksi mati/video loss (dan saat hidup kembali bila diaktifkan). Gmail: host smtp.gmail.com, port 587, TLS, user = alamat Gmail, password = App Password 16 huruf (bukan password login).', 'Sent when a camera goes down (and back up if enabled). Gmail: smtp.gmail.com, 587, TLS, App Password.')) ?></p>
    <form method="post" class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 text-sm">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <label class="flex items-center gap-2 sm:col-span-2 lg:col-span-3"><input type="checkbox" name="notify_email" value="1" <?= $set['notify_email'] ? 'checked' : '' ?> class="w-4 h-4"> <b><?= $h(cL('Kirim notifikasi email', 'Send email notifications')) ?></b></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Kirim email jika kamera mati selama', 'Email when a camera has been down for')) ?></span>
            <select name="email_after_min" class="<?= $input ?>">
                <?php foreach ([0, 5, 10, 15, 30, 60, 120] as $m): ?><option value="<?= $m ?>" <?= (int)$set['email_after_min'] === $m ? 'selected' : '' ?>><?= $h($m === 0 ? cL('Langsung (begitu terdeteksi)', 'Immediately') : $m . cL(' menit', ' minutes')) ?></option><?php endforeach; ?>
            </select>
            <span class="text-xs text-slate-400"><?= $h(cL('Batas ini juga dipakai Log CCTV mati: kamera yang mati kurang dari batas ini tidak dicatat di log & rekap. Email "online kembali" hanya dikirim untuk kamera yang sudah diemailkan mati.', 'This threshold is also used by the CCTV downtime log: shorter drops are not logged. Recovery emails only for cameras already emailed.')) ?></span></label>
        <label class="flex flex-col gap-1 sm:col-span-2 lg:col-span-3"><span class="text-xs text-slate-500"><?= $h(cL('Penerima (pisahkan dengan koma)', 'Recipients (comma separated)')) ?></span><input name="email_to" value="<?= $h($set['email_to']) ?>" placeholder="it@perusahaan.co.id, ga@perusahaan.co.id" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">SMTP host</span><input name="smtp_host" value="<?= $h($set['smtp_host']) ?>" placeholder="smtp.gmail.com" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">Port</span><input type="number" name="smtp_port" value="<?= (int)$set['smtp_port'] ?>" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Keamanan', 'Security')) ?></span><select name="smtp_secure" class="<?= $input ?>">
            <?php foreach (['tls' => 'TLS / STARTTLS (587)', 'ssl' => 'SSL (465)', 'none' => cL('Tanpa enkripsi (25)', 'None (25)')] as $k => $v): ?><option value="<?= $k ?>" <?= $set['smtp_secure'] === $k ? 'selected' : '' ?>><?= $h($v) ?></option><?php endforeach; ?>
        </select></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">SMTP user</span><input name="smtp_user" value="<?= $h($set['smtp_user']) ?>" autocomplete="off" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">SMTP password</span><input type="password" name="smtp_pass" autocomplete="new-password" placeholder="<?= $h($set['smtp_pass'] !== '' ? cL('tersimpan · kosongkan = tidak diubah', 'saved · blank = unchanged') : '') ?>" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Email pengirim', 'From address')) ?></span><input name="smtp_from" value="<?= $h($set['smtp_from']) ?>" placeholder="<?= $h(cL('kosong = sama dengan SMTP user', 'blank = SMTP user')) ?>" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Nama pengirim', 'From name')) ?></span><input name="smtp_from_name" value="<?= $h($set['smtp_from_name']) ?>" class="<?= $input ?>"></label>
        <div class="flex flex-wrap gap-2 sm:col-span-2 lg:col-span-3">
            <button name="action" value="email_save" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= $h(cL('Simpan', 'Save')) ?></button>
            <button name="action" value="email_test" class="px-4 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-50"><?= $h(cL('Simpan & kirim email tes', 'Save & send test email')) ?></button>
        </div>
    </form>
</section>

<!-- 4. Umum -->
<section id="general" class="<?= $card ?>">
    <h2 class="font-semibold text-slate-800 mb-3">4. <?= $h(cL('Checklist, notifikasi web & aturan mati', 'Checklist, web notification & rules')) ?></h2>
    <form method="post" class="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 text-sm items-end">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="general_save">
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Checklist diisi', 'Checklist frequency')) ?></span><select name="checklist_mode" class="<?= $input ?>">
            <option value="shift" <?= $set['checklist_mode'] === 'shift' ? 'selected' : '' ?>><?= $h(cL('Setiap shift', 'Every shift')) ?></option>
            <option value="daily" <?= $set['checklist_mode'] === 'daily' ? 'selected' : '' ?>><?= $h(cL('Sekali sehari', 'Once a day')) ?></option></select></label>
        <label class="flex flex-col gap-1 lg:col-span-1"><span class="text-xs text-slate-500"><?= $h(cL('Nama shift (pisah koma)', 'Shift names (comma)')) ?></span><input name="shifts" value="<?= $h(implode(', ', $set['shifts'])) ?>" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Dianggap mati setelah gagal', 'Down after failures')) ?></span><select name="fail_threshold" class="<?= $input ?>">
            <?php for ($i = 1; $i <= 5; $i++): ?><option value="<?= $i ?>" <?= $set['fail_threshold'] === $i ? 'selected' : '' ?>><?= $i ?>x <?= $h(cL('cek berturut-turut', 'checks in a row')) ?></option><?php endfor; ?></select></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Interval Task Scheduler (menit)', 'Scheduler interval (min)')) ?></span><input type="number" min="1" max="60" name="interval_min" value="<?= (int)$set['interval_min'] ?>" class="<?= $input ?>"></label>
        <div class="sm:col-span-2 lg:col-span-4 flex flex-wrap gap-3 items-end">
            <span class="text-xs text-slate-500 w-full"><?= $h(cL('Siapa yang mengisi tiap shift (shift baru: simpan dulu nama shift-nya, lalu atur di sini)', 'Who fills each shift (save new shift names first)')) ?></span>
            <?php foreach ($set['shifts'] as $sh): ?>
                <label class="flex flex-col gap-1"><span class="text-xs text-slate-600 font-medium"><?= $h($sh) ?></span>
                    <select name="shift_role[<?= $h($sh) ?>]" class="<?= $input ?>">
                        <?php foreach (['admin', 'cctv', 'both'] as $r): ?><option value="<?= $r ?>" <?= ($set['shift_roles'][$sh] ?? 'admin') === $r ? 'selected' : '' ?>><?= $h(cctvShiftRoleLabel($r)) ?></option><?php endforeach; ?>
                    </select></label>
            <?php endforeach; ?>
        </div>
        <label class="flex flex-wrap items-center gap-2"><input type="checkbox" name="notify_web" value="1" <?= $set['notify_web'] ? 'checked' : '' ?> class="w-4 h-4"> <?= $h(cL('Pop-up di web admin, jika kamera mati selama', 'Web pop-up for admins when a camera is down for')) ?>
            <select name="web_after_min" class="border border-slate-300 rounded-lg px-2 py-1 text-sm">
                <?php foreach ([0, 2, 5, 10, 15, 30] as $m): ?><option value="<?= $m ?>" <?= (int)$set['web_after_min'] === $m ? 'selected' : '' ?>><?= $h($m === 0 ? cL('langsung', 'immediately') : $m . cL(' menit', ' min')) ?></option><?php endforeach; ?>
            </select></label>
        <label class="flex items-center gap-2"><input type="checkbox" name="notify_recover" value="1" <?= $set['notify_recover'] ? 'checked' : '' ?> class="w-4 h-4"> <?= $h(cL('Beri tahu juga saat hidup kembali', 'Also notify when back up')) ?></label>
        <div class="text-xs text-slate-500 lg:col-span-2"><?= $h(cL('Kunci URL (opsional, untuk memicu cek dari perangkat lain)', 'URL key (optional)')) ?>:
            <code class="text-slate-700"><?= $set['check_key'] !== '' ? $h('cctv_check.php?key=' . $set['check_key']) : '-' ?></code>
            <label class="ml-2"><input type="checkbox" name="new_key" value="1"> <?= $h(cL('buat baru', 'new')) ?></label>
            <?php if ($set['check_key'] !== ''): ?><label class="ml-2"><input type="checkbox" name="clear_key" value="1"> <?= $h(cL('hapus', 'remove')) ?></label><?php endif; ?>
        </div>
        <div class="sm:col-span-2 lg:col-span-4"><button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= $h(cL('Simpan', 'Save')) ?></button></div>
    </form>
    <p class="text-xs text-slate-500 mt-3"><?= $h(cL('Akses Checklist CCTV untuk user biasa (mis. Security) diberikan di Management User > Ubah user > centang "Akses Checklist CCTV".', 'Give regular users (e.g. Security) access in User Management > edit user > "CCTV checklist access".')) ?></p>
</section>

<!-- 5. Item checklist -->
<section id="items" class="<?= $card ?>">
    <h2 class="font-semibold text-slate-800 mb-3">5. <?= $h(cL('Item checklist', 'Checklist items')) ?></h2>
    <form method="post" class="text-sm">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="items_save">
        <div class="overflow-x-auto"><table class="w-full text-sm">
            <thead class="bg-slate-50 text-slate-500 text-xs"><tr><th class="text-left px-3 py-2"><?= $h(cL('Urutan', 'Order')) ?></th><th class="text-left px-3 py-2"><?= $h(cL('Kode', 'Code')) ?></th><th class="text-left px-3 py-2"><?= $h(cL('Keterangan item', 'Item label')) ?></th><th class="text-left px-3 py-2"><?= $h(cL('Aktif', 'Active')) ?></th></tr></thead>
            <tbody>
            <?php foreach ($items as $it): ?>
                <tr class="border-t">
                    <td class="px-3 py-2"><input type="number" name="item[<?= (int)$it['id'] ?>][sort]" value="<?= (int)$it['sort_order'] ?>" class="<?= $input ?> w-16"></td>
                    <td class="px-3 py-2"><input name="item[<?= (int)$it['id'] ?>][code]" value="<?= $h($it['code']) ?>" maxlength="5" class="<?= $input ?> w-16 uppercase"></td>
                    <td class="px-3 py-2"><input name="item[<?= (int)$it['id'] ?>][label]" value="<?= $h($it['label']) ?>" maxlength="100" class="<?= $input ?> w-full min-w-[260px]"></td>
                    <td class="px-3 py-2"><input type="checkbox" name="item[<?= (int)$it['id'] ?>][active]" value="1" <?= (int)$it['is_active'] ? 'checked' : '' ?> class="w-4 h-4"></td>
                </tr>
            <?php endforeach; ?>
                <tr class="border-t bg-slate-50/60">
                    <td class="px-3 py-2 text-xs text-slate-500"><?= $h(cL('Baru', 'New')) ?></td>
                    <td class="px-3 py-2"><input name="new_code" maxlength="5" placeholder="K" class="<?= $input ?> w-16 uppercase"></td>
                    <td class="px-3 py-2"><input name="new_label" maxlength="100" placeholder="<?= $h(cL('mis. Lensa bersih', 'e.g. Lens clean')) ?>" class="<?= $input ?> w-full min-w-[260px]"></td>
                    <td></td>
                </tr>
            </tbody>
        </table></div>
        <p class="text-xs text-slate-500 mt-2"><?= $h(cL('Item yang dinonaktifkan tidak muncul di checklist baru, tetapi data lama tetap tersimpan.', 'Inactive items disappear from new checklists; old data is kept.')) ?></p>
        <button class="mt-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= $h(cL('Simpan item', 'Save items')) ?></button>
    </form>
</section>

<!-- 6. Hari libur checklist -->
<?php
    $holYear = (string)($_GET['hy'] ?? ($_SESSION['cctv_hol_year'] ?? date('Y')));
    unset($_SESSION['cctv_hol_year']);
    if (!preg_match('/^\d{4}$/', $holYear)) $holYear = date('Y');
    $holList = cctvHolidayMap($db, $holYear . '-01-01', $holYear . '-12-31');
    $wdNames = cctvWeekdayNames();
    $offWd = array_flip($set['off_weekdays']);
?>
<section id="holidays" class="<?= $card ?>">
    <h2 class="font-semibold text-slate-800 mb-1">6. <?= $h(cL('Hari libur checklist', 'Checklist days off')) ?></h2>
    <p class="text-sm text-slate-500 mb-3"><?= $h(cL('Pada hari libur checklist tidak wajib: tidak dihitung "terlewat" di rekap bulanan dan ditandai L. Checklist tetap bisa diisi bila ada pengecekan.', 'On days off the checklist is not required: not counted as missed, marked L in the monthly report. It can still be filled in.')) ?></p>

    <form method="post" class="text-sm mb-5">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="off_week_save">
        <p class="font-medium text-slate-700 mb-2"><?= $h(cL('Libur mingguan', 'Weekly days off')) ?></p>
        <div class="flex flex-wrap gap-x-4 gap-y-2">
            <?php foreach ($wdNames as $n => $label): ?>
                <label class="inline-flex items-center gap-2"><input type="checkbox" name="off_wd[]" value="<?= $n ?>" <?= isset($offWd[$n]) ? 'checked' : '' ?> class="w-4 h-4"> <?= $h($label) ?></label>
            <?php endforeach; ?>
        </div>
        <button class="mt-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= $h(cL('Simpan', 'Save')) ?></button>
    </form>

    <p class="font-medium text-slate-700 mb-2 text-sm"><?= $h(cL('Libur nasional, cuti bersama & cuti perusahaan (isi manual)', 'National holidays & company leave (manual)')) ?></p>
    <form method="post" class="grid sm:grid-cols-[auto_auto_1fr_auto] gap-3 items-end text-sm mb-4">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="holiday_add">
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Tanggal', 'Date')) ?></span><input type="date" name="h_from" required class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Sampai (opsional)', 'Until (optional)')) ?></span><input type="date" name="h_to" class="<?= $input ?>"></label>
        <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Keterangan', 'Name')) ?></span><input name="h_name" required maxlength="100" placeholder="<?= $h(cL('mis. Cuti bersama Idulfitri', 'e.g. Company leave')) ?>" class="<?= $input ?> w-full"></label>
        <button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium"><?= $h(cL('+ Tambah', '+ Add')) ?></button>
    </form>

    <form method="get" action="cctv_settings.php#holidays" class="flex items-center gap-2 text-sm mb-2">
        <span class="text-slate-500"><?= $h(cL('Tahun', 'Year')) ?></span>
        <select name="hy" onchange="this.form.submit()" class="<?= $input ?> w-auto">
            <?php for ($y = (int)date('Y') - 2; $y <= (int)date('Y') + 1; $y++): ?><option value="<?= $y ?>" <?= (string)$y === $holYear ? 'selected' : '' ?>><?= $y ?></option><?php endfor; ?>
        </select>
        <span class="text-slate-500"><?= count($holList) ?> <?= $h(cL('hari', 'days')) ?></span>
    </form>
    <?php if ($holList): ?>
    <div class="overflow-x-auto"><table class="w-full text-sm" data-rt="off">
        <thead class="bg-slate-50 text-slate-500 text-xs"><tr><th class="text-left px-3 py-2"><?= $h(cL('Tanggal', 'Date')) ?></th><th class="text-left px-3 py-2"><?= $h(cL('Hari', 'Day')) ?></th><th class="text-left px-3 py-2"><?= $h(cL('Keterangan', 'Name')) ?></th><th></th></tr></thead>
        <tbody>
        <?php foreach ($holList as $d => $name): $wn = (int)date('N', strtotime($d)); ?>
            <tr class="border-t">
                <td class="px-3 py-2 whitespace-nowrap"><?= $h(date('d/m/Y', strtotime($d))) ?></td>
                <td class="px-3 py-2 <?= isset($offWd[$wn]) ? 'text-slate-400' : '' ?>"><?= $h($wdNames[$wn]) ?></td>
                <td class="px-3 py-2"><?= $h($name) ?></td>
                <td class="px-3 py-2 text-right">
                    <form method="post" onsubmit="return confirm('<?= $h(cL('Hapus hari libur ini?', 'Remove this day off?')) ?>')">
                        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                        <input type="hidden" name="action" value="holiday_delete">
                        <input type="hidden" name="h_date" value="<?= $h($d) ?>">
                        <button class="text-red-600 hover:underline text-xs"><?= $h(cL('Hapus', 'Delete')) ?></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?php else: ?>
        <p class="text-sm text-slate-400"><?= $h(cL('Belum ada libur yang diisi untuk tahun ini.', 'No days off entered for this year.')) ?></p>
    <?php endif; ?>
    <p class="text-sm mt-4"><a href="cctv_isi_susulan.php" class="text-brand-700 hover:underline"><?= $h(cL('Isi checklist susulan untuk hari-hari yang lalu →', 'Back-fill checklists for past days →')) ?></a></p>
</section>

<!-- 7. Jadwal -->
<?php $agentNvr = count(array_filter($nvrs, fn($n) => cctvNvrConn($n)['mode'] === 'agen')); $cronUrl = agentBaseUrl() . 'cctv_check.php?key=' . ($set['check_key'] !== '' ? $set['check_key'] : 'KUNCI'); ?>
<section id="schedule" class="<?= $card ?>">
    <h2 class="font-semibold text-slate-800 mb-1">7. <?= $h(cL('Jadwal pengecekan otomatis', 'Automatic check schedule')) ?></h2>
    <p class="text-sm text-slate-600 mb-3"><?= $h(cL('Cek terakhir', 'Last check')) ?>: <b><?= $set['last_run'] !== '' ? $h(date('d M Y H:i:s', strtotime($set['last_run'])) . ' · ' . $set['last_run_info']) : $h(cL('belum pernah', 'never')) ?></b></p>

    <?php if (agentEnabled()): ?>
    <div class="mb-4 rounded-lg border border-violet-200 bg-violet-50/60 p-3 text-sm text-slate-700">
        <b><?= $h(cL('Agen Kantor aktif:', 'Office Agent on:')) ?></b>
        <?= $h(cL('setiap kali agen melapor, server menjalankan cek CCTV sesuai interval di bagian 4. Jadwal di bawah tidak wajib, kecuali ada NVR lewat IP publik / Cloudflare Tunnel dan agen sering mati.', 'each agent report triggers the CCTV check at the interval in section 4. The schedules below are optional.')) ?>
        <a href="agent.php" class="text-blue-700 underline"><?= $h(agentStatusText()) ?></a>
    </div>
    <?php endif; ?>

    <div class="grid gap-5 lg:grid-cols-2">
    <div class="<?= isHostingServer() ? 'order-2' : '' ?>">
    <h3 class="font-medium text-slate-800 mb-1"><?= $h(cL('Server Windows (XAMPP di kantor): Task Scheduler', 'Windows server (XAMPP): Task Scheduler')) ?></h3>
    <ol class="list-decimal pl-5 text-sm text-slate-600 space-y-1">
        <li><?= $h(cL('Cara cepat: klik kanan scripts\\pasang_jadwal_cctv.bat > Run as administrator. Atau manual: Task Scheduler > Create Task, "Run whether user is logged on or not", centang "Run with highest privileges".', 'Quick: right click scripts\\pasang_jadwal_cctv.bat > Run as administrator. Or manually: Task Scheduler > Create Task.')) ?></li>
        <li><?= $h(cL('Tab Triggers > New: Daily, mulai 00:00, centang "Repeat task every" ' . (int)$set['interval_min'] . ' minutes "for a duration of" Indefinitely.', 'Triggers > New: Daily, repeat every ' . (int)$set['interval_min'] . ' minutes indefinitely.')) ?></li>
        <li><?= $h(cL('Tab Actions > New > Start a program:', 'Actions > New > Start a program:')) ?>
            <div class="mt-1 bg-slate-900 text-slate-100 rounded-lg px-3 py-2 font-mono text-xs overflow-x-auto whitespace-nowrap">Program/script: <?= $h($phpExe) ?><br>Add arguments: -f "<?= $h($appDir . '\\cctv_check.php') ?>"<br>Start in: <?= $h($appDir) ?></div>
            <span class="text-xs text-slate-500"><?= $h(cL('Atau pakai file scripts\\cctv_check.bat (sekaligus mencatat log ke includes\\data\\cctv_check_log.txt).', 'Or use scripts\\cctv_check.bat (also logs to includes\\data\\cctv_check_log.txt).')) ?></span></li>
        <li><?= $h(cL('Klik kanan task > Run, lalu buka tab Monitoring: "Cek terakhir" harus berubah.', 'Right click > Run, then check "Last check" in Monitoring.')) ?></li>
    </ol>
    </div>
    <div class="<?= isHostingServer() ? 'order-1' : '' ?>">
    <h3 class="font-medium text-slate-800 mb-1"><?= $h(cL('Hosting (Hostinger, cPanel): Cron Job', 'Web hosting (Hostinger, cPanel): Cron Job')) ?></h3>
    <ol class="list-decimal pl-5 text-sm text-slate-600 space-y-1">
        <li><?= $h(cL('Di bagian 4 centang "buat baru" pada Kunci URL lalu Simpan, sehingga ada kunci rahasia.', 'In section 4 tick "new" next to URL key and save, to get a secret key.')) ?></li>
        <li><?= $h(cL('Hostinger: hPanel > Advanced > Cron Jobs. cPanel: Advanced > Cron Jobs. Pilih tiap ' . max(1, (int)$set['interval_min']) . ' menit (Hostinger minimal tiap 1 menit, sebagian hosting minimal 5 menit).', 'Hostinger: hPanel > Advanced > Cron Jobs. cPanel: Advanced > Cron Jobs. Every ' . max(1, (int)$set['interval_min']) . ' minutes.')) ?></li>
        <li><?= $h(cL('Isi perintah:', 'Command:')) ?>
            <div class="mt-1 bg-slate-900 text-slate-100 rounded-lg px-3 py-2 font-mono text-xs overflow-x-auto whitespace-nowrap">wget -q -O /dev/null "<?= $h($cronUrl) ?>"</div>
            <span class="text-xs text-slate-500"><?= $h(cL('Jika wget tidak tersedia: curl -s "alamat di atas" > /dev/null', 'Without wget: curl -s "the address above" > /dev/null')) ?></span></li>
        <li><?= $h(cL('Tunggu beberapa menit, lalu cek "Cek terakhir" di atas.', 'Wait a few minutes, then check "Last check" above.')) ?></li>
    </ol>
    <?php if ($agentNvr): ?><p class="text-xs text-slate-500 mt-2"><?= $h(cL($agentNvr . ' NVR memakai Agen Kantor: datanya dibaca saat agen melapor.', $agentNvr . ' NVR(s) use the Office Agent.')) ?></p><?php endif; ?>
    </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
