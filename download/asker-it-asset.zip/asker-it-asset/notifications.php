<?php
/**
 * Halaman Notifikasi (semua user): daftar lengkap notifikasi milik user yang login.
 * Tab Belum dibaca / Semua, filter kategori, tandai dibaca & hapus massal. Lihat includes/notifications.php.
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();
require_once __DIR__ . '/includes/notifications.php';

$db  = getDB();
$uid = (int)$_SESSION['user_id'];
$h   = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES);
notifEnsure($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $ids = (array)($_POST['ids'] ?? []);
    $act = (string)($_POST['act'] ?? '');
    if ($act === 'readall') $n = notifMarkRead($db, $uid, [], true);
    elseif ($act === 'read') $n = notifMarkRead($db, $uid, $ids);
    elseif ($act === 'delete') $n = notifDelete($db, $uid, $ids);
    else $n = 0;
    $_SESSION['notif_msg'] = $n
        ? ($act === 'delete' ? $n . notifL(' notifikasi dihapus.', ' notifications deleted.') : $n . notifL(' notifikasi ditandai dibaca.', ' notifications marked as read.'))
        : notifL('Tidak ada yang diubah. Pilih notifikasi terlebih dahulu.', 'Nothing changed. Select notifications first.');
    header('Location: notifications.php?' . http_build_query(['tab' => $_POST['tab'] ?? 'unread', 'cat' => $_POST['cat'] ?? '']));
    exit;
}
$msg = $_SESSION['notif_msg'] ?? '';
unset($_SESSION['notif_msg']);

$tab  = ($_GET['tab'] ?? 'unread') === 'all' ? 'all' : 'unread';
$cats = notifCats();
$cat  = isset($cats[$_GET['cat'] ?? '']) ? (string)$_GET['cat'] : '';
$per  = 50;
$page = max(1, (int)($_GET['p'] ?? 1));
$total = notifCount($db, $uid, $tab, $cat);
$pages = max(1, (int)ceil($total / $per));
$page  = min($page, $pages);
$rows  = notifList($db, $uid, $tab, $cat, $per, ($page - 1) * $per);
$counts = notifUnreadCounts($db, $uid);
$q = fn(array $over) => 'notifications.php?' . http_build_query(array_merge(['tab' => $tab, 'cat' => $cat], $over));

$pageTitle = notifL('Notifikasi', 'Notifications');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="max-w-4xl mx-auto">
<div class="flex flex-wrap items-end justify-between gap-3 mb-3">
    <div>
        <h1 class="text-xl font-semibold text-slate-800"><?= $h(notifL('Notifikasi', 'Notifications')) ?></h1>
        <p class="text-sm text-slate-500"><?= $h(notifL('Semua pemberitahuan untuk Anda. Notifikasi disimpan ' . NOTIF_KEEP_DAYS . ' hari.', 'All notifications for you. Kept for ' . NOTIF_KEEP_DAYS . ' days.')) ?></p>
    </div>
    <?php if ($counts['total']): ?>
    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= $h(csrfToken()) ?>">
        <input type="hidden" name="act" value="readall"><input type="hidden" name="tab" value="<?= $h($tab) ?>"><input type="hidden" name="cat" value="<?= $h($cat) ?>">
        <button class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium"><?= icon('check', 'w-4 h-4') ?> <?= $h(notifL('Tandai semua dibaca', 'Mark all as read')) ?></button>
    </form>
    <?php endif; ?>
</div>

<?php if ($msg): ?><div class="mb-3 text-sm rounded-lg px-3 py-2 bg-green-50 text-green-700"><?= $h($msg) ?></div><?php endif; ?>

<div class="bg-white rounded-xl shadow-sm">
    <div class="flex flex-wrap items-end justify-between gap-2 px-4 pt-3 border-b border-slate-100">
        <div class="flex gap-5 text-sm" role="tablist">
            <a href="<?= $h($q(['tab' => 'unread', 'p' => 1])) ?>" class="pb-2 border-b-2 font-medium <?= $tab === 'unread' ? 'border-brand-600 text-brand-700' : 'border-transparent text-slate-500 hover:text-slate-700' ?>"><?= $h(notifL('Belum dibaca', 'Unread')) ?><?= $counts['total'] ? ' (' . $counts['total'] . ')' : '' ?></a>
            <a href="<?= $h($q(['tab' => 'all', 'p' => 1])) ?>" class="pb-2 border-b-2 font-medium <?= $tab === 'all' ? 'border-brand-600 text-brand-700' : 'border-transparent text-slate-500 hover:text-slate-700' ?>"><?= $h(notifL('Semua', 'All')) ?></a>
        </div>
        <div class="flex flex-wrap gap-1.5 pb-2">
            <?php foreach (array_merge(['' => ['label' => notifL('Semua', 'All')]], $cats) as $k => $c): $n = $k === '' ? $counts['total'] : ($counts['by_cat'][$k] ?? 0); ?>
            <a href="<?= $h($q(['cat' => $k, 'p' => 1])) ?>" class="text-xs px-2.5 py-1 rounded-full border <?= $cat === $k ? 'bg-brand-600 border-brand-600 text-white' : 'border-slate-200 text-slate-600 hover:bg-slate-50' ?>"><?= $h($c['label']) ?><?= $n ? ' ' . $n : '' ?></a>
            <?php endforeach; ?>
        </div>
    </div>

    <form method="post" id="notifForm">
        <input type="hidden" name="csrf_token" value="<?= $h(csrfToken()) ?>">
        <input type="hidden" name="tab" value="<?= $h($tab) ?>"><input type="hidden" name="cat" value="<?= $h($cat) ?>">
        <?php if ($rows): ?>
        <div class="flex flex-wrap items-center gap-3 px-4 py-2 bg-slate-50 text-sm">
            <label class="flex items-center gap-2"><input type="checkbox" id="nSelAll" class="w-4 h-4"> <?= $h(notifL('Pilih semua', 'Select all')) ?></label>
            <button name="act" value="read" class="text-brand-700 hover:underline"><?= $h(notifL('Tandai dibaca', 'Mark as read')) ?></button>
            <button name="act" value="delete" class="text-red-600 hover:underline" onclick="return confirm('<?= $h(notifL('Hapus notifikasi yang dipilih?', 'Delete selected notifications?')) ?>')"><?= $h(notifL('Hapus', 'Delete')) ?></button>
            <span class="ml-auto text-xs text-slate-500 tabular-nums"><?= $total ?> <?= $h(notifL('notifikasi', 'notifications')) ?></span>
        </div>
        <ul class="divide-y divide-slate-100">
            <?php foreach ($rows as $r): $o = notifOut($r); $c = $cats[$o['cat']] ?? $cats['system']; ?>
            <li class="flex items-start gap-3 px-4 py-3 <?= $o['read'] ? '' : 'bg-brand-50/40' ?> hover:bg-slate-50">
                <input type="checkbox" name="ids[]" value="<?= $o['id'] ?>" class="nSel mt-2.5 w-4 h-4 shrink-0" aria-label="<?= $h(notifL('Pilih', 'Select')) ?>">
                <a href="<?= $h($o['open']) ?>" class="flex items-start gap-3 min-w-0 flex-1">
                    <span class="w-9 h-9 rounded-full flex items-center justify-center shrink-0 <?= $c['cls'] ?>"><?= icon($c['icon'], 'w-4 h-4') ?></span>
                    <span class="min-w-0 flex-1">
                        <span class="block leading-snug <?= $o['read'] ? 'text-slate-700' : 'font-semibold text-slate-800' ?>"><?= $h($o['title']) ?></span>
                        <?php if ($o['body'] !== ''): ?><span class="block text-sm text-slate-500 leading-snug break-words"><?= $h($o['body']) ?></span><?php endif; ?>
                        <span class="block text-xs text-slate-400 mt-0.5" title="<?= $h($o['time']) ?>"><?= $h($c['label']) ?> · <?= $h($o['ago']) ?></span>
                    </span>
                </a>
                <?php if (!$o['read']): ?><span class="w-2 h-2 rounded-full bg-brand-600 mt-3 shrink-0" title="<?= $h(notifL('Belum dibaca', 'Unread')) ?>"></span><?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php else: ?>
        <div class="px-4 py-12 text-center text-slate-500 text-sm">
            <?= icon('bell', 'w-8 h-8 mx-auto mb-2 text-slate-300') ?>
            <?= $h($tab === 'unread' ? notifL('Semua notifikasi sudah dibaca.', 'You are all caught up.') : notifL('Belum ada notifikasi.', 'No notifications yet.')) ?>
        </div>
        <?php endif; ?>
    </form>

    <?php if ($pages > 1): ?>
    <div class="flex items-center justify-between px-4 py-3 border-t border-slate-100 text-sm">
        <span class="text-slate-500"><?= $h(notifL('Halaman', 'Page')) ?> <?= $page ?> / <?= $pages ?></span>
        <div class="flex gap-2">
            <?php if ($page > 1): ?><a href="<?= $h($q(['p' => $page - 1])) ?>" class="px-3 py-1 rounded-lg border border-slate-200 hover:bg-slate-50">‹</a><?php endif; ?>
            <?php if ($page < $pages): ?><a href="<?= $h($q(['p' => $page + 1])) ?>" class="px-3 py-1 rounded-lg border border-slate-200 hover:bg-slate-50">›</a><?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
</div>
<script>
(function () {
    var all = document.getElementById('nSelAll');
    if (all) all.addEventListener('change', function () {
        document.querySelectorAll('.nSel').forEach(function (c) { c.checked = all.checked; });
    });
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
