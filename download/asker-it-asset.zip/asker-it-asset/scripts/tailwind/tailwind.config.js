/**
 * Tailwind CSS (v3.4.17) untuk IT System — dibuat sekali menjadi file assets/css/tailwind.css,
 * supaya tampilan tetap utuh walau internet kantor mati (tidak lagi memakai cdn.tailwindcss.com).
 * Build ulang setelah menambah/mengubah class di file PHP/JS (lihat BACA_SAYA.txt di folder ini).
 */
module.exports = {
  content: [
    '../../*.php',
    '../../includes/**/*.php',
    '../../lang/**/*.php',
    '../../assets/js/**/*.js',
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef4ff', 100: '#dbe7fe', 200: '#bfd6fe', 300: '#93b9fd',
          400: '#6094fa', 500: '#3b6ff2', 600: '#274fe6', 700: '#1f3dd1',
          800: '#2033a8', 900: '#1f2f85'
        }
      }
    }
  },
  plugins: [],
};
