@echo off
:: =====================================================================
:: Pengecekan status CCTV otomatis (IT Asset Management)
:: Dijalankan Task Scheduler setiap 1 menit (dipasang oleh pasang_jadwal_cctv.bat). Lihat PANDUAN_CCTV.md.
:: Log: includes\data\cctv_check_log.txt (otomatis diganti baru jika > 2 MB)
:: =====================================================================
setlocal
:: ---------- KONFIGURASI ----------
set "PHP_EXE=C:\xampp\php\php.exe"
set "APP_DIR=%~dp0.."
:: ---------------------------------
set "LOG=%APP_DIR%\includes\data\cctv_check_log.txt"

if not exist "%PHP_EXE%" (
    echo [%date% %time%] ERROR: php.exe tidak ditemukan di %PHP_EXE% >> "%LOG%"
    exit /b 1
)
for %%A in ("%LOG%") do if %%~zA GTR 2000000 move /y "%LOG%" "%LOG%.old" >nul

"%PHP_EXE%" -f "%APP_DIR%\cctv_check.php" >> "%LOG%" 2>&1
exit /b %errorlevel%
