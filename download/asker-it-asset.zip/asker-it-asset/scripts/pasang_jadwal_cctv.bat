@echo off
:: =====================================================================
:: Pasang jadwal pengecekan CCTV otomatis (Task Scheduler) - IT Asset Management
:: Klik kanan file ini > "Run as administrator".
:: Membuat task "Cek CCTV IT System": jalan setiap 1 menit, akun SYSTEM
:: (tetap jalan walau tidak ada yang login, tanpa perlu password Windows).
:: Aman dijalankan ulang: task lama dengan nama sama akan diganti.
:: =====================================================================
setlocal
title Pasang jadwal cek CCTV
set "TASK=Cek CCTV IT System"
set "BAT=%~dp0cctv_check.bat"
set "PHP_EXE=C:\xampp\php\php.exe"
set "APP_DIR=%~dp0.."

echo.
echo  Pasang jadwal pengecekan CCTV otomatis
echo  ======================================
echo.

:: Harus Run as administrator
net session >nul 2>&1
if errorlevel 1 (
    echo  [GAGAL] Jalankan file ini dengan klik kanan ^> "Run as administrator".
    echo.
    pause
    exit /b 1
)
if not exist "%BAT%" (
    echo  [GAGAL] File cctv_check.bat tidak ditemukan di folder: %~dp0
    echo          Pastikan file ini ada di folder scripts\ di dalam folder aplikasi
    echo.
    pause
    exit /b 1
)
if not exist "%PHP_EXE%" (
    echo  [PERINGATAN] php.exe tidak ditemukan di %PHP_EXE%
    echo               Jika XAMPP tidak di C:\xampp, ubah PHP_EXE dan APP_DIR di scripts\cctv_check.bat
    echo.
)
if not exist "%APP_DIR%\cctv_check.php" (
    echo  [PERINGATAN] cctv_check.php tidak ditemukan. Pastikan update CCTV sudah diekstrak ke folder aplikasi.
    echo.
)

echo  Membuat task "%TASK%" (setiap 1 menit, akun SYSTEM)...
schtasks /Create /TN "%TASK%" /TR "\"%BAT%\"" /SC MINUTE /MO 1 /RU SYSTEM /RL HIGHEST /F
if errorlevel 1 (
    echo.
    echo  [GAGAL] Task tidak bisa dibuat. Coba buat manual (lihat PANDUAN_CCTV.md bagian 6).
    echo.
    pause
    exit /b 1
)

echo.
echo  Menjalankan pengecekan pertama...
schtasks /Run /TN "%TASK%" >nul
timeout /t 20 /nobreak >nul

echo.
echo  Status task:
schtasks /Query /TN "%TASK%" /V /FO LIST | findstr /I /C:"TaskName" /C:"Status" /C:"Next Run Time" /C:"Last Run Time" /C:"Last Result"
echo.
echo  Log terakhir (includes\data\cctv_check_log.txt):
if exist "%APP_DIR%\includes\data\cctv_check_log.txt" (
    powershell -NoProfile -Command "Get-Content -Path '%APP_DIR%\includes\data\cctv_check_log.txt' -Tail 8"
) else (
    echo  (belum ada log - tunggu 1 menit lalu buka menu CCTV ^> Monitoring)
)
echo.
echo  SELESAI. Buka menu CCTV ^> Monitoring: "Cek terakhir" akan berubah setiap 1 menit.
echo  Untuk menghapus jadwal: schtasks /Delete /TN "%TASK%" /F
echo.
pause
