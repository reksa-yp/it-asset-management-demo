<?php
/**
 * Simpan kategori aset baru, atau update kategori yang sudah ada.
 * Kalau nama kategori diubah (rename), semua aset yang masih memakai nama
 * lama ikut di-update ke nama baru, supaya data aset tidak jadi "yatim"
 * (category-nya tidak cocok dengan kategori manapun di daftar).
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/categories.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: categories.php');
    exit;
}
csrfCheck();

$id        = $_POST['id'] ?: null;
$name      = trim($_POST['name'] ?? '');
$abbr      = strtoupper(trim($_POST['abbr'] ?? ''));
$sortOrder = (int)($_POST['sort_order'] ?? 0);

if ($name === '' || $abbr === '') {
    $_SESSION['category_msg'] = ['ok' => false, 'text' => t('category_save_required')];
    header('Location: categories.php');
    exit;
}

$db = getDB();

// Nama kategori harus unik (selain dirinya sendiri saat edit).
$dupStmt = $db->prepare("SELECT id FROM asset_categories WHERE name = ? AND id <> ?");
$dupStmt->execute([$name, $id ?: 0]);
if ($dupStmt->fetch()) {
    $_SESSION['category_msg'] = ['ok' => false, 'text' => t('category_name_duplicate')];
    header('Location: categories.php');
    exit;
}

try {
    $db->beginTransaction();

    if ($id) {
        $oldStmt = $db->prepare("SELECT name FROM asset_categories WHERE id = ?");
        $oldStmt->execute([$id]);
        $oldName = $oldStmt->fetchColumn();

        $stmt = $db->prepare("UPDATE asset_categories SET name=?, abbr=?, sort_order=? WHERE id=?");
        $stmt->execute([$name, $abbr, $sortOrder, $id]);

        // Rename cascade: samakan data aset lama yang masih pakai nama kategori sebelumnya.
        if ($oldName !== false && $oldName !== $name) {
            $cascade = $db->prepare("UPDATE assets SET category = ? WHERE category = ?");
            $cascade->execute([$name, $oldName]);
        }
    } else {
        $stmt = $db->prepare("INSERT INTO asset_categories (name, abbr, sort_order) VALUES (?, ?, ?)");
        $stmt->execute([$name, $abbr, $sortOrder]);
    }

    $db->commit();
    $_SESSION['category_msg'] = ['ok' => true, 'text' => t('category_saved')];
} catch (Throwable $e) {
    $db->rollBack();
    $_SESSION['category_msg'] = ['ok' => false, 'text' => t('category_save_failed')];
}

header('Location: categories.php');
exit;
