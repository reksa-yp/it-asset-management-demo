<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();

// Terima banyak ID (ids[]=1&ids[]=2...) atau tetap kompatibel dengan id= tunggal (link lama)
$rawIds = $_GET['ids'] ?? ($_GET['id'] ?? null);
if ($rawIds === null) {
    http_response_code(404);
    die(htmlspecialchars(t('access_denied_asset')));
}
if (!is_array($rawIds)) { $rawIds = [$rawIds]; }
$rawIds = array_values(array_unique(array_filter(array_map('intval', $rawIds))));

$assetsToPrint = [];
foreach ($rawIds as $assetId) {
    $asset = getAssetForCurrentUser($assetId);
    if ($asset) { $assetsToPrint[] = $asset; }
}
if (empty($assetsToPrint)) {
    http_response_code(404);
    die(htmlspecialchars(t('access_denied_asset')));
}
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars(t('print_title')) ?><?= count($assetsToPrint) > 1 ? ' (' . count($assetsToPrint) . ')' : ' ' . htmlspecialchars($assetsToPrint[0]['asset_number']) ?></title>
<style>
    body { margin: 20px; }
    .asset-print-page:not(:last-child) { page-break-after: always; }
    .no-print { margin-top: 16px; text-align: center; }
    .no-print button {
        background:#1F3DD1; color:#fff; border:none; border-radius:6px;
        padding:8px 18px; font-size:13px; cursor:pointer;
    }
    @media print { .no-print { display: none; } }
</style>
</head>
<body onload="window.print()">
    <?php foreach ($assetsToPrint as $asset): ?>
    <div class="asset-print-page">
        <?php
        $h = getDB()->prepare("
            SELECT t.*, wd.work_detail AS work_detail, wd.asset_check AS asset_check
            FROM tickets t
            LEFT JOIN ticket_work_details wd ON wd.ticket_id = t.id
            WHERE t.asset_id = ? ORDER BY t.created_at DESC
        ");
        $h->execute([$asset['id']]);
        $history = $h->fetchAll();
        require __DIR__ . '/includes/asset_detail_template.php';
        ?>
    </div>
    <?php endforeach; ?>

    <div class="no-print">
        <button onclick="window.print()"><?= t('btn_print_again') ?></button>
    </div>
</body>
</html>
