<?php
/**
 * Pengecekan status CCTV otomatis. Dijalankan oleh Windows Task Scheduler setiap 1-5 menit:
 *     C:\xampp\php\php.exe -f C:\xampp\htdocs\asker-it-asset\cctv_check.php
 * (lihat scripts\cctv_check.bat dan PANDUAN_CCTV.md)
 *
 * Bisa juga dipicu lewat URL (mis. dari server/NAS lain) jika "Kunci URL" diisi di Pengaturan CCTV:
 *     http://IP-SERVER/asker-it-asset/cctv_check.php?key=KUNCI
 * Tanpa kunci yang benar, akses lewat browser ditolak.
 */
$isCli = PHP_SAPI === 'cli';
if (!$isCli) {
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
}
date_default_timezone_set('Asia/Jakarta');   // jam WIB, tidak ikut php.ini (XAMPP bawaan = Europe/Berlin)

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/cctv.php';

if (!$isCli) {
    $key = (string)(cctvSettings()['check_key'] ?? '');
    if ($key === '' || !hash_equals($key, (string)($_GET['key'] ?? ''))) {
        http_response_code(403);
        exit("403 - akses ditolak\n");
    }
}

// Cegah dua proses berjalan bersamaan (mis. cek sebelumnya masih menunggu NVR yang lambat).
$lockFile = __DIR__ . '/includes/data/cctv_check.lock';
$lock = @fopen($lockFile, 'c');
if ($lock && !flock($lock, LOCK_EX | LOCK_NB)) {
    exit("Pengecekan sebelumnya masih berjalan, dilewati.\n");
}

set_time_limit(900);   // termasuk snapshot harian List View
try {
    $sum = runCctvCheck(getDB());
    echo '[' . date('Y-m-d H:i:s') . '] ' . cctvSettings()['last_run_info'] . "\n";
    foreach ($sum['nvr'] as $n) echo '  NVR ' . $n . "\n";
    foreach ($sum['down'] as $d) echo '  MATI   ' . $d['cam']['number'] . ' ' . $d['cam']['location'] . ' (' . $d['detail'] . ")\n";
    foreach ($sum['up'] as $u)   echo '  HIDUP  ' . $u['cam']['number'] . ' ' . $u['cam']['location'] . "\n";
    if ($sum['email'] !== '') echo '  EMAIL GAGAL: ' . $sum['email'] . "\n";
    elseif (!empty($sum['emailed_down']) || !empty($sum['emailed_up'])) echo '  Email terkirim (' . (int)($sum['emailed_down'] ?? 0) . ' mati, ' . (int)($sum['emailed_up'] ?? 0) . " hidup kembali).\n";
    // Snapshot List View CCTV: 1x sehari (mulai jam di Pengaturan), sesudah cek status.
    require_once __DIR__ . '/includes/cctv_snapshot.php';
    if ($snap = cctvAutoSnapshotDaily(getDB())) {
        echo '  SNAPSHOT ' . $snap['ok'] . ' kamera' . ($snap['fail'] ? ', gagal ' . count($snap['fail']) : '') . "\n";
    }
} catch (Throwable $e) {
    echo '[' . date('Y-m-d H:i:s') . '] ERROR: ' . $e->getMessage() . "\n";
    if ($lock) { flock($lock, LOCK_UN); fclose($lock); }
    exit(1);
}
if ($lock) { flock($lock, LOCK_UN); fclose($lock); }
