<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
if (!isAdmin()) { http_response_code(403); echo json_encode(['ok'=>false,'items'=>[]]); exit; }
try {
    $db = getDB();
    require_once __DIR__ . '/includes/notifications.php';
    if (!notifEnsure($db)) throw new RuntimeException('notifications unavailable');
    // Hanya notifikasi pengajuan baru yang baru masuk; tetap menggunakan pusat notifikasi yang ada.
    $st = $db->prepare("SELECT id,title,body,url,ref_id,created_at FROM app_notifications WHERE user_id=? AND category='request' AND type='request_new' AND created_at >= DATE_SUB(NOW(), INTERVAL 2 MINUTE) ORDER BY id DESC LIMIT 8");
    $st->execute([(int)$_SESSION['user_id']]);
    $items = [];
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $items[] = ['id'=>(int)$r['id'],'title'=>$r['title'],'body'=>$r['body'] ?? '', 'url'=>$r['url'] ?: 'request.php','created_at'=>date('d M Y H:i',strtotime($r['created_at']))];
    echo json_encode(['ok'=>true,'items'=>$items,'max_id'=>$items ? max(array_column($items,'id')) : 0]);
} catch (Throwable $e) { echo json_encode(['ok'=>true,'items'=>[],'max_id'=>0]); }
