<?php
/**
 * Menampilkan foto Chat Grup. File foto tersimpan terenkripsi di includes/data/chat_photos/,
 * jadi hanya bisa dibuka lewat sini oleh user yang login dan menjadi anggota grupnya.
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();
require_once __DIR__ . '/includes/chat.php';

$db = getDB();
ensureChatTables($db);
$st = $db->prepare("SELECT group_id, photo_path FROM chat_messages WHERE id = ? AND deleted_by IS NULL");
$st->execute([(int)($_GET['id'] ?? 0)]);
$m = $st->fetch();
if (!$m || !$m['photo_path'] || !isset(chatMyGroups($db, (int)$_SESSION['user_id'])[(int)$m['group_id']])) { http_response_code(404); exit; }
$file = CHAT_PHOTO_DIR . '/' . $m['photo_path'];
if (strpos((string)$m['photo_path'], '..') !== false || !is_file($file)) { http_response_code(404); exit; }
$plain = chatDecrypt($db, (string)file_get_contents($file));
if ($plain === null || ($p = strpos($plain, "\n")) === false) { http_response_code(410); exit; }
$mime = substr($plain, 0, $p);
if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) { http_response_code(415); exit; }
header('Content-Type: ' . $mime);
header('Cache-Control: private, max-age=86400');
header('X-Content-Type-Options: nosniff');
echo substr($plain, $p + 1);
