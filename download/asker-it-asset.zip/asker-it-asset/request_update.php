<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
if (!isAdmin()) { http_response_code(403); exit('Akses ditolak.'); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: request.php?view=' . urlencode($returnView)); exit; }
csrfCheck();
$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
$status = trim((string)($_POST['status'] ?? ''));
$note = trim((string)($_POST['admin_note'] ?? ''));
$noteEn = trim((string)($_POST['admin_note_en'] ?? ''));
if ($noteEn === '') $noteEn = null;
$returnView = (string)($_POST['return_view'] ?? 'all');
if (!in_array($returnView, ['all','pending','approved','rejected'], true)) $returnView = 'all';
$allowed = ['Menunggu','Disetujui','Ditolak','Selesai'];
if (!$id || !in_array($status, $allowed, true) || mb_strlen($note) > 3000) {
    $_SESSION['request_flash'] = ['type'=>'error','message'=>'Status atau catatan tidak valid.'];
    header('Location: request.php?view=' . urlencode($returnView)); exit;
}
require_once __DIR__ . '/includes/request_feature.php';
$db = getDB(); ensureRequestTable($db);
$stmt = $db->prepare('UPDATE user_requests SET status=?, admin_note=?, admin_note_en=?, handled_by=? WHERE id=?');
$stmt->execute([$status, $note !== '' ? $note : null, $noteEn, (int)$_SESSION['user_id'], $id]);
$_SESSION['request_flash'] = ['type'=>'success','message'=>$stmt->rowCount() >= 0 ? 'Status pengajuan berhasil diperbarui.' : 'Tidak ada perubahan.'];
header('Location: request.php?view=' . urlencode($returnView)); exit;
