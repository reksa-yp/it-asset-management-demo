<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$db = getDB();

$search = trim($_GET['q'] ?? '');
$filterRole       = trim($_GET['role'] ?? '');
$filterDepartment = trim($_GET['department'] ?? '');

// Daftar departement diambil dari data user yang benar-benar ada.
$departmentOptions = $db->query(
    "SELECT DISTINCT department FROM users WHERE department IS NOT NULL AND department <> '' ORDER BY department"
)->fetchAll(PDO::FETCH_COLUMN);

// Jumlah user per departement (untuk pilihan di modal Export Excel). '' = tanpa departement.
$exportDeptCounts = [];
foreach ($db->query("SELECT COALESCE(department, '') AS d, is_active, COUNT(*) AS n FROM users GROUP BY COALESCE(department, ''), is_active") as $r) {
    $d = trim((string)$r['d']);
    $exportDeptCounts[$d] = $exportDeptCounts[$d] ?? ['all' => 0, 'active' => 0];
    $exportDeptCounts[$d]['all'] += (int)$r['n'];
    if ((int)$r['is_active'] === 1) $exportDeptCounts[$d]['active'] += (int)$r['n'];
}
ksort($exportDeptCounts, SORT_NATURAL | SORT_FLAG_CASE);

// ===== Pagination (sama seperti menu Penambahan Aset IT) =====
// Default tampilan: "Tampilkan Semua" (tanpa LIMIT).
$allowedPerPage = [10, 50, 100];
$perPageParam = $_GET['per_page'] ?? 'all';
if ($perPageParam === 'all') {
    $perPage = 'all';
} else {
    $perPage = (int)$perPageParam;
    if (!in_array($perPage, $allowedPerPage, true)) $perPage = 'all';
}
$page = max(1, (int)($_GET['page'] ?? 1));

$conditions = [];
$params = [];

if ($search !== '') {
    $conditions[] = "(full_name LIKE ? OR username LIKE ? OR email LIKE ?)";
    $like = "%$search%";
    array_push($params, $like, $like, $like);
}
if ($filterRole !== '') {
    $conditions[] = "role = ?";
    $params[] = $filterRole;
}
if ($filterDepartment !== '') {
    $conditions[] = "department = ?";
    $params[] = $filterDepartment;
}

$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';

$countSql = "SELECT COUNT(*) FROM users" . $where;
$countStmt = $db->prepare($countSql);
$countStmt->execute($params);
$totalUsers = (int)$countStmt->fetchColumn();
if ($perPage === 'all') {
    $totalPages = 1;
    $page = 1;
    $offset = 0;
    $limitClause = '';
} else {
    $totalPages = max(1, (int)ceil($totalUsers / $perPage));
    if ($page > $totalPages) $page = $totalPages;
    $offset = ($page - 1) * $perPage;
    $limitClause = "LIMIT $perPage OFFSET $offset";
}

$sql = "SELECT id, username, full_name, email, department, pc_username, pc_password, role, is_active, created_at
        FROM users" . $where . "
        ORDER BY created_at DESC
        $limitClause";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$userList = $stmt->fetchAll();
// Jabatan tiap user (tabel baru user_positions)
$positionMap = getUserPositionMap($db, array_column($userList, 'id'));
foreach ($userList as &$uRow) { $uRow['position'] = $positionMap[(int)$uRow['id']] ?? ''; }
unset($uRow);
$positionOptions = userPositionOptions($db);

// Bangun URL halaman (mempertahankan q, filter, & per_page yang sedang aktif)
function userPageUrl(string $search, $perPage, int $p, string $role = '', string $department = ''): string {
    $q = ['per_page' => $perPage, 'page' => $p];
    if ($search !== '')     $q['q'] = $search;
    if ($role !== '')       $q['role'] = $role;
    if ($department !== '') $q['department'] = $department;
    return '?' . http_build_query($q);
}

$isFiltered = ($search !== '' || $filterRole !== '' || $filterDepartment !== '');

$importMsg = $_SESSION['user_import_msg'] ?? null;
unset($_SESSION['user_import_msg']);

$pageTitle = t('page_title_users');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="bg-white rounded-xl shadow-sm px-3 py-3 mb-4">
<div class="flex flex-wrap items-center justify-between gap-3">
    <form method="get" class="flex flex-wrap items-center gap-2">
        <input type="hidden" name="per_page" value="<?= htmlspecialchars((string)$perPage) ?>">
        <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="<?= htmlspecialchars(t('search_placeholder_user')) ?>"
               class="border rounded-lg px-3 py-2 text-sm w-56">

        <select name="role" onchange="this.form.submit()" class="border rounded-lg px-3 py-2 text-sm">
            <option value=""><?= t('filter_all_roles') ?></option>
            <option value="admin" <?= $filterRole === 'admin' ? 'selected' : '' ?>><?= t('role_admin') ?></option>
            <option value="user" <?= $filterRole === 'user' ? 'selected' : '' ?>><?= t('role_user') ?></option>
        </select>

        <select name="department" onchange="this.form.submit()" class="border rounded-lg px-3 py-2 text-sm">
            <option value=""><?= t('filter_all_departments') ?></option>
            <?php foreach ($departmentOptions as $d): ?>
                <option value="<?= htmlspecialchars($d) ?>" <?= $filterDepartment === $d ? 'selected' : '' ?>>
                    <?= htmlspecialchars($d) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button class="bg-slate-200 hover:bg-slate-300 rounded-lg px-3 py-2 text-sm"><?= t('btn_search') ?></button>
        <?php if ($isFiltered): ?>
            <a href="users.php" class="text-sm text-slate-500 hover:text-slate-700 underline px-1"><?= t('btn_reset_filter') ?></a>
        <?php endif; ?>
    </form>
    <div class="flex flex-wrap items-center gap-2">
        <span id="userSelectedInfo" class="hidden text-xs text-slate-500 mr-1"><span id="userSelectedCount">0</span> <?= t('users_selected') ?></span>
        <button type="button" id="btnEditUser" onclick="editSelectedUser()" disabled
                class="user-action-btn opacity-40 cursor-not-allowed bg-amber-500 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('btn_edit') ?></button>
        <button type="button" id="btnDeleteUser" onclick="deleteSelectedUsers()" disabled
                class="user-action-btn opacity-40 cursor-not-allowed bg-red-600 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= t('link_delete') ?></button>
        <a href="user_download_template.php"
           class="inline-flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('download') ?> <?= t('btn_download_template') ?>
        </a>
        <button type="button" onclick="openUserExportModal()"
           class="inline-flex items-center gap-1 bg-green-600 hover:bg-green-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('sheet') ?> <?= t('btn_export_excel') ?>
        </button>
        <button type="button" onclick="openImportModal()"
                class="inline-flex items-center gap-1 bg-slate-600 hover:bg-slate-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('upload') ?> <?= t('btn_import_excel') ?>
        </button>
        <button type="button" onclick="openUserModal()" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= t('btn_add_user') ?>
        </button>
    </div>
</div>
</div>

<?php if ($importMsg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $importMsg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>">
        <?= htmlspecialchars($importMsg['text']) ?>
    </div>
<?php endif; ?>

<form id="userBulkForm" method="post" action="user_bulk_delete.php"
      onsubmit="return confirmDelete(bulkDeleteConfirmTextUser.replace('%d', selectedUserCount()))">
<input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

<div class="bg-white rounded-xl shadow-sm asset-table-wrap">
<table class="w-full text-sm whitespace-nowrap">
    <thead class="bg-slate-50 text-slate-500 text-left">
        <tr>
            <th class="py-2 px-3 w-8">
                <input type="checkbox" id="checkAllUsers" onclick="toggleAllUsers(this)">
            </th>
            <th class="py-2 px-3"><?= t('th_name') ?></th>
            <th class="py-2 px-3"><?= t('th_username') ?></th>
            <th class="py-2 px-3"><?= t('th_email') ?></th>
            <th class="py-2 px-3"><?= t('th_department') ?></th>
            <th class="py-2 px-3"><?= t('th_position') ?></th>
            <th class="py-2 px-3"><?= t('th_pc_login') ?></th>
            <th class="py-2 px-3"><?= t('th_role') ?></th>
            <th class="py-2 px-3"><?= t('th_status') ?></th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($userList as $u): ?>
        <tr class="border-t hover:bg-slate-50">
            <td class="py-2 px-3">
                <?php if ($u['id'] != $_SESSION['user_id']): ?>
                    <input type="checkbox" name="ids[]" value="<?= $u['id'] ?>" class="user-check" onclick="updateUserSelection()">
                <?php endif; ?>
            </td>
            <td class="py-2 px-3 font-medium"><?= htmlspecialchars($u['full_name']) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($u['username']) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($u['email'] ?? t('dash')) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($u['department'] ?: t('dash')) ?></td>
            <td class="py-2 px-3"><?= htmlspecialchars($u['position'] ?: t('dash')) ?></td>
            <td class="py-2 px-3 text-xs">
                <?php if ($u['pc_username'] || $u['pc_password']): ?>
                    <div class="text-slate-600"><?= t('pc_user_label') ?>: <span class="font-medium"><?= htmlspecialchars($u['pc_username'] ?: t('dash')) ?></span></div>
                    <div class="text-slate-400 flex items-center gap-1">
                        <?= t('pc_pass_label') ?>:
                        <span class="pc-pass-mask">••••••••</span>
                        <span class="pc-pass-real hidden font-medium text-slate-600"><?= htmlspecialchars($u['pc_password'] ?: t('dash')) ?></span>
                        <button type="button" onclick="togglePcPassword(this)" class="text-blue-600 hover:underline"><?= t('btn_view') ?></button>
                    </div>
                <?php else: ?>
                    <span class="text-slate-400"><?= t('dash') ?></span>
                <?php endif; ?>
            </td>
            <td class="py-2 px-3">
                <span class="px-2 py-0.5 rounded-full text-xs font-medium <?= $u['role']==='admin' ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-600' ?>">
                    <?= $u['role']==='admin' ? t('role_admin') : t('role_user') ?>
                </span>
            </td>
            <td class="py-2 px-3"><?= $u['is_active'] ? t('status_active') : t('status_inactive') ?></td>
        </tr>
    <?php endforeach; ?>
    <?php if (!$userList): ?>
        <tr><td colspan="8" class="py-6 text-center text-slate-400"><?= $isFiltered ? t('no_users_filtered') : t('no_users_yet') ?></td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>
</form>

<!-- ===== Pagination ===== -->
<div class="flex flex-wrap items-center justify-between gap-3 mt-4 text-sm text-slate-600">
    <form method="get" class="flex flex-wrap items-center gap-2">
        <?php if ($search !== ''): ?><input type="hidden" name="q" value="<?= htmlspecialchars($search) ?>"><?php endif; ?>
        <?php if ($filterRole !== ''): ?><input type="hidden" name="role" value="<?= htmlspecialchars($filterRole) ?>"><?php endif; ?>
        <?php if ($filterDepartment !== ''): ?><input type="hidden" name="department" value="<?= htmlspecialchars($filterDepartment) ?>"><?php endif; ?>
        <input type="hidden" name="page" value="1">
        <span><?= t('pagination_show') ?></span>
        <select name="per_page" onchange="this.form.submit()" class="border rounded-lg px-2 py-1 text-sm">
            <option value="all" <?= $perPage === 'all' ? 'selected' : '' ?>><?= t('pagination_show_all') ?></option>
            <?php foreach ($allowedPerPage as $pp): ?>
                <option value="<?= $pp ?>" <?= $perPage === $pp ? 'selected' : '' ?>><?= $pp ?></option>
            <?php endforeach; ?>
        </select>
        <span><?= t('pagination_per_page') ?></span>
        <span class="text-slate-400">&bull; <?= t('pagination_total_users') ?>: <?= $totalUsers ?></span>
        <span id="userSelectedInfoBottom" class="hidden text-slate-400">&bull; <span id="userSelectedCountBottom">0</span> <?= t('users_selected') ?></span>
    </form>

    <?php if ($totalPages > 1): ?>
    <div class="flex items-center gap-1">
        <a href="<?= userPageUrl($search, $perPage, max(1, $page - 1), $filterRole, $filterDepartment) ?>"
           class="px-3 py-1.5 rounded-lg border <?= $page <= 1 ? 'opacity-40 pointer-events-none' : 'hover:bg-slate-100' ?>">&laquo;</a>

        <?php
        $windowEnd   = min($totalPages, max($page + 3, 7));
        $windowStart = max(1, $windowEnd - 6);
        for ($p = $windowStart; $p <= $windowEnd; $p++):
        ?>
            <a href="<?= userPageUrl($search, $perPage, $p, $filterRole, $filterDepartment) ?>"
               class="px-3 py-1.5 rounded-lg border <?= $p === $page ? 'bg-blue-600 text-white border-blue-600' : 'hover:bg-slate-100' ?>"><?= $p ?></a>
        <?php endfor; ?>

        <a href="<?= userPageUrl($search, $perPage, min($totalPages, $page + 1), $filterRole, $filterDepartment) ?>"
           class="px-3 py-1.5 rounded-lg border <?= $page >= $totalPages ? 'opacity-40 pointer-events-none' : 'hover:bg-slate-100' ?>">&raquo;</a>
    </div>
    <?php endif; ?>
</div>

<div id="userModal" class="fixed inset-0 bg-black/40 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <form method="post" action="user_save.php" class="p-5 space-y-3 text-sm">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="id" id="u_id">
            <div class="flex items-start justify-between gap-3 sticky top-0 z-10 bg-white -mx-5 -mt-5 px-5 pt-5 pb-2">
                <h2 class="font-semibold text-lg" id="userModalTitle"><?= t('modal_add_user_title') ?></h2>
                <button type="button" onclick="closeUserModal()" data-modal-close title="<?= htmlspecialchars(t('btn_close')) ?>" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="shrink-0 -mr-1 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><?= icon('x', 'w-5 h-5') ?></button>
            </div>

            <div>
                <label class="block mb-1 font-medium"><?= t('field_full_name') ?></label>
                <input name="full_name" id="u_full_name" required class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block mb-1 font-medium"><?= t('field_username') ?></label>
                <input name="username" id="u_username" required class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block mb-1 font-medium"><?= t('field_email') ?></label>
                <input type="email" name="email" id="u_email" class="w-full border rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block mb-1 font-medium"><?= t('field_department') ?></label>
                <input name="department" id="u_department" class="w-full border rounded-lg px-3 py-2" placeholder="<?= htmlspecialchars(t('department_placeholder')) ?>">
            </div>
            <div>
                <label class="block mb-1 font-medium"><?= t('field_position') ?></label>
                <input name="position" id="u_position" maxlength="100" list="positionOptions" autocomplete="off" class="w-full border rounded-lg px-3 py-2" placeholder="<?= htmlspecialchars(t('position_placeholder')) ?>">
                <datalist id="positionOptions">
                    <?php foreach ($positionOptions as $po): ?><option value="<?= htmlspecialchars($po) ?>"></option><?php endforeach; ?>
                </datalist>
            </div>
            <div>
                <label class="block mb-1 font-medium"><?= t('field_password') ?> <span class="text-xs text-slate-400" id="pwHint"><?= t('password_hint') ?></span></label>
                <input type="password" name="password" id="u_password" class="w-full border rounded-lg px-3 py-2">
            </div>

            <div class="pt-2 border-t">
                <p class="text-xs font-medium text-slate-400 uppercase tracking-wide mt-2 mb-2"><?= t('pc_login_section_title') ?></p>
                <div class="space-y-3">
                    <div>
                        <label class="block mb-1 font-medium"><?= t('field_pc_username') ?></label>
                        <input name="pc_username" id="u_pc_username" class="w-full border rounded-lg px-3 py-2">
                    </div>
                    <div>
                        <label class="block mb-1 font-medium"><?= t('field_pc_password') ?></label>
                        <!-- Password tampil apa adanya (bukan titik-titik) dan bisa diketik / diubah sendiri -->
                        <input type="text" name="pc_password" id="u_pc_password" autocomplete="off" spellcheck="false"
                               placeholder="<?= htmlspecialchars(t('pc_pass_placeholder')) ?>"
                               class="w-full border rounded-lg px-3 py-2 font-mono text-base tracking-wide">
                        <div class="flex flex-wrap items-center gap-2 mt-2">
                            <button type="button" onclick="generatePcPassword()" class="rounded-lg border border-blue-200 bg-blue-50 hover:bg-blue-100 text-brand-700 px-3 py-1.5 text-sm font-medium"><?= t('pc_pass_gen_btn') ?></button>
                            <label class="flex items-center gap-1.5 text-xs text-slate-500"><?= t('pc_pass_gen_length') ?>
                                <select id="u_pc_password_len" class="border rounded-lg px-2 py-1 text-sm text-slate-700">
                                    <?php foreach ([6, 7, 8, 10, 12] as $len): ?><option value="<?= $len ?>" <?= $len === 7 ? 'selected' : '' ?>><?= $len ?></option><?php endforeach; ?>
                                </select>
                            </label>
                        </div>
                        <div id="pcPassRules" class="hidden flex flex-wrap gap-1.5 mt-2 text-[11px]">
                            <?php foreach (['len' => t('pc_pass_rule_len'), 'upper' => t('pc_pass_rule_upper'), 'lower' => t('pc_pass_rule_lower'),
                                            'digit' => t('pc_pass_rule_digit'), 'symbol' => t('pc_pass_rule_symbol')] as $rk => $rl): ?>
                                <span data-rule="<?= $rk ?>" class="px-2 py-0.5 rounded-full bg-slate-100 text-slate-500"><?= htmlspecialchars($rl) ?></span>
                            <?php endforeach; ?>
                        </div>
                        <p class="text-xs text-slate-400 mt-1.5"><?= t('pc_pass_gen_hint') ?></p>
                    </div>
                </div>
            </div>

            <div>
                <label class="block mb-1 font-medium"><?= t('field_role') ?></label>
                <select name="role" id="u_role" class="w-full border rounded-lg px-3 py-2">
                    <option value="user"><?= t('option_role_user') ?></option>
                    <option value="admin"><?= t('option_role_admin') ?></option>
                </select>
            </div>
            <div>
                <label class="block mb-1 font-medium"><?= t('field_status') ?></label>
                <select name="is_active" id="u_is_active" class="w-full border rounded-lg px-3 py-2">
                    <option value="1"><?= t('status_active') ?></option>
                    <option value="0"><?= t('status_inactive') ?></option>
                </select>
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t mt-3">
                <button type="button" onclick="closeUserModal()" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200"><?= t('btn_cancel') ?></button>
                <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium"><?= t('btn_save') ?></button>
            </div>
        </form>
    </div>
</div>

<div id="userImportModal" class="fixed inset-0 bg-black/40 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-md">
        <form method="post" action="user_import_process.php" enctype="multipart/form-data" class="p-5 space-y-3 text-sm">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <div class="flex items-start justify-between gap-3">
                <h2 class="font-semibold text-lg"><?= t('import_user_title') ?></h2>
                <button type="button" onclick="closeImportModal()" data-modal-close title="<?= htmlspecialchars(t('btn_close')) ?>" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="shrink-0 -mr-1 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><?= icon('x', 'w-5 h-5') ?></button>
            </div>
            <p class="text-xs text-slate-500">
                <?= t('import_user_instructions') ?>
            </p>
            <div class="rounded-lg bg-teal-50 border border-teal-100 p-3 text-xs text-slate-600 space-y-2">
                <p><?= t('import_au_user_hint') ?></p>
                <a href="download_template.php?type=asset_user" class="inline-flex items-center gap-1 rounded-lg bg-white border border-teal-200 hover:bg-teal-100 text-teal-800 px-3 py-1.5 font-medium">
                    <?= icon('download') ?> <?= t('btn_download_template_au') ?>
                </a>
            </div>
            <input type="file" name="excel_file" accept=".xlsx,.xls" required
                   class="w-full border rounded-lg px-3 py-2 text-sm">
            <div class="flex justify-end gap-2 pt-3 border-t mt-3">
                <button type="button" onclick="closeImportModal()" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200"><?= t('btn_cancel') ?></button>
                <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium"><?= t('btn_upload_import') ?></button>
            </div>
        </form>
    </div>
</div>

<!-- ===== Modal Export User: pilih satu / beberapa departement ===== -->
<div id="userExportModal" class="fixed inset-0 bg-black/40 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col">
        <form method="get" action="user_export_excel.php" id="userExportForm" class="flex flex-col min-h-0 text-sm">
            <div class="flex items-start justify-between gap-3 px-5 pt-5">
                <h2 class="font-semibold text-lg"><?= t('user_export_title') ?></h2>
                <button type="button" onclick="closeUserExportModal()" data-modal-close aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="shrink-0 -mr-1 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><?= icon('x', 'w-5 h-5') ?></button>
            </div>
            <div class="px-5 py-3 space-y-3 overflow-y-auto">
                <div class="flex items-center justify-between gap-2">
                    <span class="font-medium text-slate-700"><?= t('field_department') ?></span>
                    <span class="flex gap-3 text-xs">
                        <button type="button" onclick="setUserExportDepts(true)" class="text-blue-600 hover:underline"><?= t('user_export_select_all') ?></button>
                        <button type="button" onclick="setUserExportDepts(false)" class="text-blue-600 hover:underline"><?= t('user_export_select_none') ?></button>
                    </span>
                </div>
                <input type="search" id="ueDeptSearch" autocomplete="off" oninput="filterUserExportDepts()" class="w-full border rounded-lg px-3 py-2" placeholder="<?= htmlspecialchars(t('user_export_dept_search')) ?>">
                <div id="ueDeptList" class="grid sm:grid-cols-2 gap-1.5 max-h-64 overflow-y-auto pr-1">
                    <?php foreach ($exportDeptCounts as $d => $c): $val = $d === '' ? '__none__' : $d; ?>
                        <label class="ue-dept flex items-center gap-2 border border-slate-200 rounded-lg px-2 py-1.5 cursor-pointer hover:bg-slate-50" data-name="<?= htmlspecialchars(mb_strtolower($d === '' ? t('user_export_no_dept') : $d)) ?>">
                            <input type="checkbox" name="dept[]" value="<?= htmlspecialchars($val) ?>" onchange="updateUserExportInfo()" class="h-4 w-4 accent-green-600" data-all="<?= $c['all'] ?>" data-active="<?= $c['active'] ?>">
                            <span class="flex-1 min-w-0 truncate <?= $d === '' ? 'italic text-slate-500' : '' ?>"><?= htmlspecialchars($d === '' ? t('user_export_no_dept') : $d) ?></span>
                            <span class="text-xs text-slate-400 tabular-nums"><?= $c['all'] ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
                <label class="block"><span class="block mb-1 font-medium text-slate-700"><?= t('field_status') ?></span>
                    <select name="active" id="ueActive" onchange="updateUserExportInfo()" class="w-full border rounded-lg px-3 py-2">
                        <option value=""><?= t('user_export_status_all') ?></option>
                        <option value="1"><?= t('user_export_status_active') ?></option>
                        <option value="0"><?= t('user_export_status_inactive') ?></option>
                    </select></label>
                <p id="ueInfo" class="rounded-lg bg-green-50 text-green-800 px-3 py-2 font-medium"></p>
            </div>
            <div class="flex justify-end gap-2 px-5 py-3 border-t">
                <button type="button" onclick="closeUserExportModal()" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200"><?= t('btn_cancel') ?></button>
                <button type="submit" id="ueSubmit" class="inline-flex items-center gap-1 px-4 py-2 rounded-lg bg-green-600 hover:bg-green-700 text-white font-medium"><?= icon('sheet') ?> <?= t('user_export_btn') ?></button>
            </div>
        </form>
    </div>
</div>

<script>
var userExportFilterDept = <?= json_encode($filterDepartment) ?>;
var userExportT = <?= json_encode(['count' => tRaw('user_export_count'), 'none' => tRaw('user_export_pick_one')]) ?>;
function openUserExportModal() {
    // Pilihan awal mengikuti filter departement yang sedang aktif di halaman (kalau ada).
    document.querySelectorAll('#ueDeptList input').forEach(cb => {
        cb.checked = userExportFilterDept === '' || cb.value === userExportFilterDept;
    });
    document.getElementById('ueDeptSearch').value = '';
    filterUserExportDepts();
    document.getElementById('ueActive').value = '';
    updateUserExportInfo();
    const m = document.getElementById('userExportModal');
    m.classList.remove('hidden'); m.classList.add('flex');
}
function closeUserExportModal() {
    const m = document.getElementById('userExportModal');
    m.classList.add('hidden'); m.classList.remove('flex');
}
function setUserExportDepts(on) {
    // Hanya departement yang sedang tampil (hasil cari) yang ikut dicentang / dikosongkan.
    document.querySelectorAll('#ueDeptList .ue-dept').forEach(l => { if (!l.classList.contains('hidden')) l.querySelector('input').checked = on; });
    updateUserExportInfo();
}
function filterUserExportDepts() {
    const q = document.getElementById('ueDeptSearch').value.trim().toLowerCase();
    document.querySelectorAll('#ueDeptList .ue-dept').forEach(l => l.classList.toggle('hidden', q !== '' && !l.dataset.name.includes(q)));
}
function updateUserExportInfo() {
    const act = document.getElementById('ueActive').value;
    let n = 0, picked = 0;
    document.querySelectorAll('#ueDeptList input:checked').forEach(cb => {
        picked++;
        const all = +cb.dataset.all, active = +cb.dataset.active;
        n += act === '1' ? active : act === '0' ? all - active : all;
    });
    document.getElementById('ueInfo').textContent = picked ? userExportT.count.replace('%d', n).replace('%d', picked) : userExportT.none;
    const btn = document.getElementById('ueSubmit');
    btn.disabled = !picked || !n;
    btn.classList.toggle('opacity-50', btn.disabled);
}
document.getElementById('userExportForm').addEventListener('submit', () => setTimeout(closeUserExportModal, 300));
</script>

<script>
var bulkDeleteConfirmTextUser = <?= json_encode(tRaw('confirm_bulk_delete_user')) ?>;
var singleDeleteConfirmTextUser = <?= json_encode(tRaw('confirm_delete_user')) ?>;
var modalAddUserTitle = <?= json_encode(t('modal_add_user_title')) ?>;
var modalEditUserTitle = <?= json_encode(t('modal_edit_user_title')) ?>;
var btnViewLabel = <?= json_encode(t('btn_view')) ?>;
var btnHideLabel = <?= json_encode(t('btn_hide')) ?>;
var userDataMap = <?= json_encode(array_column($userList, null, 'id'), JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var currentUserId = <?= (int)$_SESSION['user_id'] ?>;

function openImportModal() {
    document.getElementById('userImportModal').classList.remove('hidden');
    document.getElementById('userImportModal').classList.add('flex');
}
function closeImportModal() {
    document.getElementById('userImportModal').classList.add('hidden');
    document.getElementById('userImportModal').classList.remove('flex');
}
function openUserModal(data) {
    document.getElementById('userModal').classList.remove('hidden');
    document.getElementById('userModal').classList.add('flex');
    ['id','full_name','username','email','department','position','pc_username','pc_password','role'].forEach(f => {
        const el = document.getElementById('u_' + f);
        if (el) el.value = data && data[f] ? data[f] : '';
    });
    document.getElementById('u_is_active').value = data ? (data.is_active ?? 1) : 1;
    document.getElementById('u_password').required = !data;
    document.getElementById('pwHint').style.display = data ? 'inline' : 'none';
    document.getElementById('userModalTitle').innerText = data ? modalEditUserTitle : modalAddUserTitle;
    if (typeof checkPcPassword === 'function') checkPcPassword(); // segarkan penanda aturan Password PC
}
function closeUserModal() {
    document.getElementById('userModal').classList.add('hidden');
    document.getElementById('userModal').classList.remove('flex');
}
function togglePcPassword(btn) {
    const wrap = btn.parentElement;
    const mask = wrap.querySelector('.pc-pass-mask');
    const real = wrap.querySelector('.pc-pass-real');
    const showing = !real.classList.contains('hidden');
    mask.classList.toggle('hidden', !showing);
    real.classList.toggle('hidden', showing);
    btn.innerText = showing ? btnViewLabel : btnHideLabel;
}

// ===== Pilih baris untuk aktifkan tombol Edit/Hapus di atas (sama seperti menu Aset) =====
function getSelectedUserIds() {
    return Array.from(document.querySelectorAll('.user-check:checked')).map(cb => cb.value);
}
function selectedUserCount() {
    return getSelectedUserIds().length;
}
function setUserActionBtnEnabled(id, enabled) {
    const btn = document.getElementById(id);
    btn.disabled = !enabled;
    btn.classList.toggle('opacity-40', !enabled);
    btn.classList.toggle('cursor-not-allowed', !enabled);
}
function updateUserSelection() {
    const all    = document.querySelectorAll('.user-check');
    const ids    = getSelectedUserIds();
    const single = ids.length === 1;
    const any    = ids.length > 0;

    document.getElementById('userSelectedCount').innerText = ids.length;
    document.getElementById('userSelectedInfo').classList.toggle('hidden', ids.length === 0);
    document.getElementById('userSelectedCountBottom').innerText = ids.length;
    document.getElementById('userSelectedInfoBottom').classList.toggle('hidden', ids.length === 0);

    setUserActionBtnEnabled('btnEditUser', single);
    setUserActionBtnEnabled('btnDeleteUser', any);

    const master = document.getElementById('checkAllUsers');
    master.checked = all.length > 0 && ids.length === all.length;
    master.indeterminate = ids.length > 0 && ids.length < all.length;
}
function toggleAllUsers(master) {
    document.querySelectorAll('.user-check').forEach(cb => cb.checked = master.checked);
    updateUserSelection();
}
function clearUserSelection() {
    document.querySelectorAll('.user-check').forEach(cb => cb.checked = false);
    updateUserSelection();
}

// ===== Aksi tombol di atas, berlaku untuk user yang dicentang (sama seperti menu Aset) =====
function editSelectedUser() {
    const ids = getSelectedUserIds();
    if (ids.length !== 1) return;
    openUserModal(userDataMap[ids[0]]);
}
function deleteSelectedUsers() {
    const ids = getSelectedUserIds();
    if (ids.length === 0) return;
    if (ids.length === 1) {
        const user = userDataMap[ids[0]];
        const msg = singleDeleteConfirmTextUser.replace('%s', user ? user.username : '');
        if (confirmDelete(msg)) {
            window.location.href = 'user_delete.php?id=' + ids[0];
        }
    } else {
        document.getElementById('userBulkForm').requestSubmit();
    }
}
</script>

<?php
// Generate Password PC otomatis dengan pola tetap: 3 HURUF (campuran besar & kecil) + ANGKA + 1 SIMBOL
// di akhir, contoh: kMa249$. Karakter yang mirip (O/0, l/1/I) tidak dipakai supaya tidak salah baca
// saat diketik ulang. Acak memakai crypto.getRandomValues bila tersedia. (Sama dengan includes/pc_password.php.)
$extraScripts = ($extraScripts ?? '') . <<<'HTML'
<script>
function generatePcPassword() {
    var upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ', lower = 'abcdefghijkmnpqrstuvwxyz', digits = '23456789', symbols = '!@#$%&*?';
    var len = Math.max(6, parseInt(document.getElementById('u_pc_password_len').value, 10) || 7);
    function rnd(n) {
        if (window.crypto && window.crypto.getRandomValues) {
            var a = new Uint32Array(1), limit = Math.floor(4294967296 / n) * n;
            do { window.crypto.getRandomValues(a); } while (a[0] >= limit);
            return a[0] % n;
        }
        return Math.floor(Math.random() * n);
    }
    function pick(set) { return set.charAt(rnd(set.length)); }
    // 3 huruf: selalu ada minimal 1 huruf besar dan 1 huruf kecil, posisinya diacak.
    var chars = [pick(upper), pick(lower), pick(upper + lower)];
    for (var i = 2; i > 0; i--) { var j = rnd(i + 1), t = chars[i]; chars[i] = chars[j]; chars[j] = t; }
    for (var d = 0; d < len - 4; d++) chars.push(pick(digits));   // angka di tengah
    chars.push(pick(symbols));                                   // simbol paling akhir
    var input = document.getElementById('u_pc_password');
    input.value = chars.join('');
    input.focus();
    checkPcPassword();
}
// Penanda aturan (hanya informasi, tidak menghalangi simpan): berguna saat password diketik / diubah sendiri.
function checkPcPassword() {
    var v = document.getElementById('u_pc_password').value;
    var box = document.getElementById('pcPassRules');
    box.classList.toggle('hidden', v === '');
    var ok = { len: v.length >= 6, upper: /[A-Z]/.test(v), lower: /[a-z]/.test(v), digit: /[0-9]/.test(v), symbol: /[^A-Za-z0-9\s]/.test(v) };
    box.querySelectorAll('[data-rule]').forEach(function (el) {
        var good = ok[el.dataset.rule];
        el.className = 'px-2 py-0.5 rounded-full ' + (good ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700');
    });
}
document.getElementById('u_pc_password').addEventListener('input', checkPcPassword);
</script>
HTML;
?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
