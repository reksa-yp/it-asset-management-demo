<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

// ===== Template gabungan Aset + User (download_template.php?type=asset_user) =====
// 1 baris = 1 aset + 1 penggunanya, lengkap seperti form Tambah Aset & Tambah User.
if (($_GET['type'] ?? '') === 'asset_user') {
    require_once __DIR__ . '/vendor/autoload.php';
    require_once __DIR__ . '/includes/asset_user_import.php';
    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    writeAssetUserTemplate($spreadsheet, array_column(getAssetCategories(getDB()), 'name'));
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="template_aset_user.xlsx"');
    header('Cache-Control: max-age=0');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet))->save('php://output');
    exit;
}

// ===== Template khusus Tablet (download_template.php?type=tablet) =====
// Dibuat langsung (bukan file statis) supaya judul kolom selalu sama persis dengan hasil Export Tablet.
if (($_GET['type'] ?? '') === 'tablet') {
    require_once __DIR__ . '/vendor/autoload.php';
    require_once __DIR__ . '/includes/tablet_excel.php';

    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    writeTabletSheet($spreadsheet->getActiveSheet(), [], [], [], 'Inventory');

    // Sheet petunjuk (tidak ikut di-import).
    $help = $spreadsheet->createSheet();
    $help->setTitle(t('tablet_tpl_help_sheet'));
    $lines = [t('tablet_tpl_help_title'), ''];
    for ($i = 1; $i <= 9; $i++) { $lines[] = t('tablet_tpl_help_' . $i); }
    foreach ($lines as $i => $line) { $help->setCellValue('A' . ($i + 1), $line); }
    $help->getStyle('A1')->getFont()->setBold(true)->setSize(13);
    $help->getColumnDimension('A')->setWidth(120);
    $spreadsheet->setActiveSheetIndex(0);

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="template_tablet.xlsx"');
    header('Cache-Control: max-age=0');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet))->save('php://output');
    exit;
}

$file = __DIR__ . '/templates/template_inventory_it.xlsx';
if (!file_exists($file)) {
    die('File template tidak ditemukan di server.');
}

// File template dimuat lalu diberi kop + judul + petunjuk (judul kolom pindah ke baris 8).
// Jika gagal diproses, file template asli tetap dikirim apa adanya.
try {
    require_once __DIR__ . '/vendor/autoload.php';
    require_once __DIR__ . '/includes/xls_number.php';
    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($file);
    $tplSheet = $spreadsheet->getSheet(0);
    if (xlsHeaderRowIndex($tplSheet) === 1) {
        xlsAddTitleBlock($tplSheet, 1, xlsL('Template Import Aset ', 'Asset Import Template ') . xlsCompanyName(), xlsTemplateLines());
    }
    $spreadsheet->setActiveSheetIndex(0);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="template_inventory_it.xlsx"');
    header('Cache-Control: max-age=0');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet))->save('php://output');
    exit;
} catch (Throwable $e) {
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="template_inventory_it.xlsx"');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}
