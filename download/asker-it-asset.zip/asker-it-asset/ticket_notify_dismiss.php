<?php
/**
 * Endpoint AJAX (dipanggil saat admin menutup popup notifikasi tiket baru).
 * Menyimpan id tiket terakhir yang sudah dilihat, supaya tiket yang sama
 * tidak muncul lagi sebagai popup setelah ditutup.
 *
 * VERSI TANPA UBAH DATABASE:
 * Disimpan di file JSON lokal (includes/data/last_seen_tickets.json) dengan
 * format { "user_id": last_ticket_id, ... }, BUKAN di kolom tabel users.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'CSRF token tidak valid']);
    exit;
}

$lastId = (int)($_POST['last_id'] ?? 0);
$userId = (string)$_SESSION['user_id'];

$storageDir  = __DIR__ . '/includes/data';
$storageFile = $storageDir . '/last_seen_tickets.json';

if (!is_dir($storageDir)) {
    mkdir($storageDir, 0775, true);
}

// Buka file dengan lock supaya aman kalau ada beberapa admin menutup popup bersamaan.
$fp = fopen($storageFile, 'c+');
if ($fp === false) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Tidak bisa menulis file penyimpanan']);
    exit;
}

flock($fp, LOCK_EX);
$content = stream_get_contents($fp);
$data = json_decode($content, true);
if (!is_array($data)) {
    $data = [];
}

$data[$userId] = max((int)($data[$userId] ?? 0), $lastId);

ftruncate($fp, 0);
rewind($fp);
fwrite($fp, json_encode($data));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);

echo json_encode(['ok' => true]);
