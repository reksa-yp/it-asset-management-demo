<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
require_once __DIR__ . '/includes/letterhead.php';
require_once __DIR__ . '/vendor/autoload.php'; // composer require dompdf/dompdf

use Dompdf\Dompdf;
use Dompdf\Options;

// Terima banyak ID (ids[]=1&ids[]=2...) atau tetap kompatibel dengan id= tunggal (link lama)
$rawIds = $_GET['ids'] ?? ($_GET['id'] ?? null);
if ($rawIds === null) {
    http_response_code(404);
    die(htmlspecialchars(t('access_denied_asset')));
}
if (!is_array($rawIds)) { $rawIds = [$rawIds]; }
$rawIds = array_values(array_unique(array_filter(array_map('intval', $rawIds))));

$assetsToPrint = [];
foreach ($rawIds as $assetId) {
    $asset = getAssetForCurrentUser($assetId);
    if ($asset) { $assetsToPrint[] = $asset; }
}
if (empty($assetsToPrint)) {
    http_response_code(404);
    die(htmlspecialchars(t('access_denied_asset')));
}

// Render fragment HTML untuk tiap aset (sama seperti versi print), pisahkan tiap aset dengan page-break
$bodyHtmlParts = [];
foreach ($assetsToPrint as $asset) {
    $h = getDB()->prepare("
        SELECT t.*, wd.work_detail AS work_detail, wd.asset_check AS asset_check
        FROM tickets t
        LEFT JOIN ticket_work_details wd ON wd.ticket_id = t.id
        WHERE t.asset_id = ? ORDER BY t.created_at DESC
    ");
    $h->execute([$asset['id']]);
    $history = $h->fetchAll();

    ob_start();
    require __DIR__ . '/includes/asset_detail_template.php';
    $bodyHtmlParts[] = ob_get_clean();
}
$pageBreakStyle = 'page-break-after: always;';
$lastIndex = count($bodyHtmlParts) - 1;
$bodyHtml = '';
foreach ($bodyHtmlParts as $i => $part) {
    $style = $i < $lastIndex ? ' style="' . $pageBreakStyle . '"' : '';
    $bodyHtml .= '<div' . $style . '>' . $part . '</div>';
}

$html = '<html><head><meta charset="UTF-8"><style>' . letterheadPdfCss() . '</style></head><body>'
      . letterheadPdfHtml() . $bodyHtml . '</body></html>';

$options = new Options();
$options->set('isRemoteEnabled', true); // untuk font/gambar eksternal jika ada
$dompdf = new Dompdf($options);
$dompdf->setPaper('A4', 'portrait');
$dompdf->loadHtml($html);
$dompdf->render();

if (count($assetsToPrint) === 1) {
    $filename = 'Detail_Aset_' . preg_replace('/[^A-Za-z0-9_-]/', '_', $assetsToPrint[0]['asset_number']) . '.pdf';
} else {
    $filename = 'Detail_Aset_' . count($assetsToPrint) . '_item_' . date('Ymd_His') . '.pdf';
}
$dompdf->stream($filename, ['Attachment' => true]);
exit;
