<?php
/**
 * INSTALLER - IT Asset Management
 * Buka sekali lewat browser: http://localhost/it_asset_management/install.php
 *
 * Yang dikerjakan:
 *   0. Pilih jenis instalasi: sistem operasi (Windows / Linux), jenis server (lokal / VPS / hosting),
 *      dan database (MySQL / MariaDB). Petunjuk, pengaturan awal & langkah lanjutan menyesuaikan pilihan ini.
 *   1. Cek kebutuhan server (versi PHP, ekstensi, folder yang harus bisa ditulis)
 *   2. Membuat database (jika belum ada) dan semua tabel dari sql/install.sql
 *   3. Membuat akun admin pertama
 *   4. Menulis config/database.php
 *   5. Mengunci installer (includes/data/installed.lock) supaya tidak bisa dijalankan ulang
 *
 * Untuk instal ulang: hapus file includes/data/installed.lock.
 */
session_start();

const INSTALL_LOCK   = __DIR__ . '/includes/data/installed.lock';
const INSTALL_SQL    = __DIR__ . '/sql/install.sql';
const INSTALL_CONFIG = __DIR__ . '/config/database.php';
const INSTALL_APPSET = __DIR__ . '/includes/data/app_settings.json';
const INSTALL_PROFILE = __DIR__ . '/includes/data/install_profile.json';
const INSTALL_CCTVSET = __DIR__ . '/includes/data/cctv_settings.json';
require_once __DIR__ . '/includes/agent.php';   // lokasi server (kantor / hosting) & deteksi otomatis

function h(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/** Pecah isi file .sql menjadi daftar perintah (baris komentar "--" dibuang). */
function installSqlStatements(string $file): array
{
    $lines = [];
    foreach (preg_split('/\R/', (string)file_get_contents($file)) as $line) {
        if (preg_match('/^\s*--/', $line)) continue;
        $lines[] = $line;
    }
    $statements = [];
    foreach (preg_split('/;\s*(?:\n|$)/', implode("\n", $lines)) as $stmt) {
        $stmt = trim($stmt);
        if ($stmt !== '') $statements[] = $stmt;
    }
    return $statements;
}

/** Isi file config/database.php dengan kredensial hasil instalasi. */
function installConfigContent(string $host, string $name, string $user, string $pass, int $port = 3306): string
{
    return "<?php\n"
        . "/**\n * Konfigurasi koneksi database.\n * Ditulis otomatis oleh install.php. Boleh diubah manual kalau kredensial MySQL berganti.\n */\n"
        . "define('DB_HOST', " . var_export($host, true) . ");\n"
        . "define('DB_NAME', " . var_export($name, true) . ");\n"
        . "define('DB_USER', " . var_export($user, true) . ");\n"
        . "define('DB_PASS', " . var_export($pass, true) . ");\n"
        . "define('DB_PORT', " . var_export($port, true) . ");\n\n"
        . <<<'PHP'
function getDB(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';port=' . (defined('DB_PORT') ? DB_PORT : 3306) . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            die('Koneksi database gagal: ' . $e->getMessage());
        }
    }
    return $pdo;
}

PHP;
}

// ---------- Cek kebutuhan server ----------
$checks = [
    ['PHP 8.0 atau lebih baru (terpasang: ' . PHP_VERSION . ')', version_compare(PHP_VERSION, '8.0.0', '>=')],
    ['Ekstensi PHP: pdo_mysql', extension_loaded('pdo_mysql')],
    ['Ekstensi PHP: mbstring', extension_loaded('mbstring')],
    ['Ekstensi PHP: gd (logo, label & PDF)', extension_loaded('gd')],
    ['Ekstensi PHP: zip (export/import Excel)', extension_loaded('zip')],
    ['Folder vendor/ tersedia (PhpSpreadsheet & Dompdf)', is_file(__DIR__ . '/vendor/autoload.php')],
    ['File sql/install.sql tersedia', is_file(INSTALL_SQL)],
    ['Folder config/ bisa ditulis', is_writable(dirname(INSTALL_CONFIG)) && (!is_file(INSTALL_CONFIG) || is_writable(INSTALL_CONFIG))],
    ['Folder includes/data/ bisa ditulis', is_writable(dirname(INSTALL_LOCK))],
    ['Folder assets/uploads/logo/ bisa ditulis', is_writable(__DIR__ . '/assets/uploads/logo')],
];
$requirementsOk = !in_array(false, array_column($checks, 1), true);

$locked  = is_file(INSTALL_LOCK);
$errors  = [];
$log     = [];
$success = false;

// ---------- Pilihan jenis instalasi (tebakan awal dari server ini) ----------
$detOs = PHP_OS_FAMILY === 'Windows' ? 'windows' : 'linux';
$detServer = $detOs === 'windows' ? 'lokal' : (agentDetectServer() === 'hosting' ? 'hosting' : 'vps');
$OS_OPTS = ['windows' => ['Windows', 'XAMPP / Windows Server'], 'linux' => ['Linux', 'Ubuntu, Debian, CentOS, panel hosting']];
$SERVER_OPTS = [
    'lokal'   => ['Server lokal (kantor)', 'XAMPP / PC server di jaringan kantor. Semua fitur jalan langsung (ping, scan, NVR lokal, video RTSP).'],
    'vps'     => ['VPS / cloud server', 'Server sendiri di internet (akses root). Video RTSP bisa (pasang ffmpeg). Jaringan kantor lewat VPN atau Agen Kantor.'],
    'hosting' => ['Shared hosting', 'Hostinger, cPanel, dsb. Database dibuat di panel. Jaringan kantor & CCTV lokal lewat Agen Kantor / IP publik.'],
];
$DB_OPTS = ['mysql' => ['MySQL', '5.7 / 8.x'], 'mariadb' => ['MariaDB', '10.x / 11.x (bawaan XAMPP)']];

$form = [
    'os' => $detOs, 'server' => $detServer, 'db_type' => $detOs === 'windows' ? 'mariadb' : 'mysql', 'vpn' => '',
    'db_host' => 'localhost', 'db_port' => '3306', 'db_name' => 'it_asset_management', 'db_user' => $detServer === 'hosting' ? '' : 'root', 'db_pass' => '',
    'create_user' => $detServer === 'vps' ? '1' : '', 'new_user' => 'asset_app', 'new_pass' => '',
    'app_name' => '', 'asset_prefix' => '',
    'full_name' => '', 'username' => 'admin',
];

if (empty($_SESSION['install_token'])) {
    $_SESSION['install_token'] = bin2hex(random_bytes(32));
}

if (!$locked && $_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($form as $k => $v) { $form[$k] = trim((string)($_POST[$k] ?? '')); }
    $form['db_pass'] = (string)($_POST['db_pass'] ?? ''); // password tidak di-trim
    $form['new_pass'] = (string)($_POST['new_pass'] ?? '');
    if (!isset($OS_OPTS[$form['os']])) $form['os'] = $detOs;
    if (!isset($SERVER_OPTS[$form['server']])) $form['server'] = $detServer;
    if (!isset($DB_OPTS[$form['db_type']])) $form['db_type'] = 'mysql';
    $createUser = $form['create_user'] !== '' && $form['server'] !== 'hosting';
    $dbPort = (int)$form['db_port'] ?: 3306;
    $password  = (string)($_POST['password'] ?? '');
    $password2 = (string)($_POST['password2'] ?? '');
    $prefix    = substr(preg_replace('/[^A-Z0-9]/', '', strtoupper($form['asset_prefix'])), 0, 6);
    $appName   = mb_substr($form['app_name'], 0, 60);

    if (!hash_equals($_SESSION['install_token'], (string)($_POST['install_token'] ?? ''))) {
        $errors[] = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
    }
    if (!$requirementsOk) $errors[] = 'Kebutuhan server belum terpenuhi (lihat daftar di atas).';
    if ($form['db_host'] === '') $errors[] = 'Host database wajib diisi.';
    if (!preg_match('/^[A-Za-z0-9_]{1,64}$/', $form['db_name'])) $errors[] = 'Nama database hanya boleh huruf, angka, dan garis bawah (_).';
    if ($form['db_user'] === '') $errors[] = 'User database wajib diisi.';
    if ($dbPort < 1 || $dbPort > 65535) $errors[] = 'Port database tidak valid.';
    if ($createUser) {
        if (!preg_match('/^[A-Za-z0-9_]{1,32}$/', $form['new_user'])) $errors[] = 'User database baru hanya boleh huruf, angka, dan garis bawah (maks. 32).';
        if (strlen($form['new_pass']) < 8) $errors[] = 'Password user database baru minimal 8 karakter.';
        if (strcasecmp($form['new_user'], 'root') === 0) $errors[] = 'User database baru tidak boleh bernama root.';
    }
    if ($form['full_name'] === '') $errors[] = 'Nama lengkap admin wajib diisi.';
    if (!preg_match('/^[A-Za-z0-9._-]{3,50}$/', $form['username'])) $errors[] = 'Username admin 3-50 karakter (huruf, angka, titik, strip, garis bawah).';
    if (strlen($password) < 6) $errors[] = 'Password admin minimal 6 karakter.';
    if ($password !== $password2) $errors[] = 'Konfirmasi password admin tidak sama.';

    if (!$errors) {
        try {
            try {
                $pdo = new PDO('mysql:host=' . $form['db_host'] . ';port=' . $dbPort . ';charset=utf8mb4', $form['db_user'], $form['db_pass'], [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]);
            } catch (PDOException $e) {
                $m = $e->getMessage();
                if (strpos($m, '1045') !== false) {
                    $m = 'Login database ditolak untuk user "' . $form['db_user'] . '". Kolom User & Password harus berisi akun MySQL/MariaDB yang SUDAH ADA'
                       . ($form['server'] === 'hosting' ? ' (dibuat di panel hosting, lengkap dengan awalannya).' : ($form['server'] === 'lokal' && $form['os'] === 'windows' ? ' (XAMPP bawaan: root, password kosong — hapus isian password yang diisi otomatis browser).' : ' (mis. root).'))
                       . ' Detail: ' . $e->getMessage();
                } elseif (strpos($m, '2002') !== false) {
                    $m = 'Server database tidak bisa dihubungi di ' . $form['db_host'] . ':' . $dbPort . '. Pastikan MySQL/MariaDB berjalan. Detail: ' . $e->getMessage();
                }
                throw new RuntimeException($m);
            }
            $ver = (string)$pdo->query('SELECT VERSION()')->fetchColumn();
            $log[] = 'Terhubung ke ' . (stripos($ver, 'mariadb') !== false ? 'MariaDB' : 'MySQL') . ' ' . preg_replace('/-.*$/', '', $ver) . '.';

            $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . $form['db_name'] . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
            $pdo->exec('USE `' . $form['db_name'] . '`');
            $log[] = 'Database "' . $form['db_name'] . '" siap.';

            // Server lokal / VPS: buat user database khusus aplikasi (aplikasi tidak memakai root).
            $cfgUser = $form['db_user']; $cfgPass = $form['db_pass'];
            if ($createUser) {
                $hosts = in_array(strtolower($form['db_host']), ['localhost', '127.0.0.1', '::1'], true) ? ['localhost', '127.0.0.1'] : ['%'];
                foreach ($hosts as $hh) {
                    $acct = $pdo->quote($form['new_user']) . '@' . $pdo->quote($hh);
                    $pdo->exec('CREATE USER IF NOT EXISTS ' . $acct . ' IDENTIFIED BY ' . $pdo->quote($form['new_pass']));
                    $pdo->exec('ALTER USER ' . $acct . ' IDENTIFIED BY ' . $pdo->quote($form['new_pass']));
                    $pdo->exec('GRANT ALL PRIVILEGES ON `' . $form['db_name'] . '`.* TO ' . $acct);
                }
                $pdo->exec('FLUSH PRIVILEGES');
                $cfgUser = $form['new_user']; $cfgPass = $form['new_pass'];
                $log[] = 'User database "' . $form['new_user'] . '" dibuat khusus untuk aplikasi (hak akses hanya ke database "' . $form['db_name'] . '").';
            }

            $statements = installSqlStatements(INSTALL_SQL);
            foreach ($statements as $i => $sql) {
                try {
                    $pdo->exec($sql);
                } catch (PDOException $e) {
                    throw new RuntimeException('Perintah SQL ke-' . ($i + 1) . ' gagal: ' . $e->getMessage());
                }
            }
            $log[] = count($statements) . ' perintah SQL dijalankan (tabel dibuat).';

            $adminCount = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
            if ($adminCount > 0) {
                $log[] = 'Database ini sudah punya akun admin, jadi akun admin baru TIDAK dibuat. Login memakai akun admin yang lama.';
            } else {
                $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, role, is_active) VALUES (?, ?, ?, 'admin', 1)");
                $stmt->execute([$form['username'], password_hash($password, PASSWORD_BCRYPT), $form['full_name']]);
                $log[] = 'Akun admin "' . $form['username'] . '" dibuat.';
            }

            if (file_put_contents(INSTALL_CONFIG, installConfigContent($form['db_host'], $form['db_name'], $cfgUser, $cfgPass, $dbPort), LOCK_EX) === false) {
                throw new RuntimeException('Gagal menulis config/database.php. Pastikan folder config bisa ditulis.');
            }
            $log[] = 'config/database.php ditulis.';

            if ($appName !== '' || $prefix !== '') {
                $existing = is_file(INSTALL_APPSET) ? json_decode((string)file_get_contents(INSTALL_APPSET), true) : [];
                if (!is_array($existing)) $existing = [];
                $existing['app_name']     = $appName !== '' ? $appName : ($existing['app_name'] ?? '');
                $existing['logo']         = $existing['logo'] ?? '';
                $existing['asset_prefix'] = $prefix !== '' ? $prefix : ($existing['asset_prefix'] ?? '');
                $existing['updated_at']   = date('Y-m-d H:i:s');
                file_put_contents(INSTALL_APPSET, json_encode($existing, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
                $log[] = 'Nama sistem / awalan Nomor Aset disimpan.';
            }

            // Pengaturan awal sesuai jenis instalasi.
            $serverMode = ($form['server'] === 'lokal' || ($form['server'] === 'vps' && $form['vpn'] !== '')) ? 'office' : 'hosting';
            saveAgentSettings(['server_mode' => $serverMode]);
            $cctv = is_file(INSTALL_CCTVSET) ? json_decode((string)file_get_contents(INSTALL_CCTVSET), true) : [];
            if (!is_array($cctv)) $cctv = [];
            if (empty($cctv['check_key']) && !($form['os'] === 'windows' && $form['server'] === 'lokal')) $cctv['check_key'] = bin2hex(random_bytes(12));   // untuk Cron Job
            if ($form['os'] === 'linux' && empty($cctv['ffmpeg_path']) && is_file('/usr/bin/ffmpeg')) $cctv['ffmpeg_path'] = '/usr/bin/ffmpeg';
            file_put_contents(INSTALL_CCTVSET, json_encode($cctv, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), LOCK_EX);
            file_put_contents(INSTALL_PROFILE, json_encode(['os' => $form['os'], 'server' => $form['server'], 'db' => $form['db_type'], 'vpn' => $form['vpn'] !== '', 'db_version' => $ver, 'installed_at' => date('Y-m-d H:i:s')], JSON_PRETTY_PRINT), LOCK_EX);
            $log[] = 'Jenis instalasi: ' . $OS_OPTS[$form['os']][0] . ' · ' . $SERVER_OPTS[$form['server']][0] . ' · ' . $DB_OPTS[$form['db_type']][0] . ' (lokasi server: ' . ($serverMode === 'office' ? 'jaringan kantor' : 'internet/hosting') . ').';
            $checkKey = (string)($cctv['check_key'] ?? '');

            if (file_put_contents(INSTALL_LOCK, 'Terinstal pada ' . date('Y-m-d H:i:s') . "\n", LOCK_EX) === false) {
                throw new RuntimeException('Gagal membuat file kunci includes/data/installed.lock.');
            }
            unset($_SESSION['install_token']);
            $success = true;
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Instalasi — IT Asset Management</title>
<link rel="stylesheet" href="assets/css/tailwind.css"><?php /* Tailwind lokal: tanpa internet */ ?>
</head>
<body class="min-h-screen bg-slate-100 py-10 px-4 text-slate-700">
<div class="max-w-2xl mx-auto">
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">Instalasi IT Asset Management</h1>
        <p class="text-sm text-slate-500 mt-1">Inventaris aset IT &amp; ticketing helpdesk. Isi formulir di bawah, sisanya dikerjakan otomatis.</p>
    </div>

<?php if ($success):
    $appDir  = __DIR__;
    $isWin   = $form['os'] === 'windows';
    $scheme  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $baseUrl = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/') . '/';
    $steps = [];
    $steps[] = 'Hapus file <code>install.php</code> dari server.';
    if ($form['server'] === 'hosting') {
        $steps[] = 'Aktifkan <b>SSL/HTTPS</b> di panel hosting (dibutuhkan juga untuk scan QR dengan kamera HP).';
        $steps[] = 'Cek CCTV otomatis: buat <b>Cron Job</b> tiap 1–5 menit di panel hosting (hPanel/cPanel → Cron Jobs) dengan perintah:<br><code class="break-all">wget -q -O /dev/null "' . h($baseUrl . 'cctv_check.php?key=' . $checkKey) . '"</code>';
        $steps[] = 'Jaringan kantor (cek/scan jaringan, NVR ber-IP lokal): aktifkan <b>Agen Kantor</b> di menu Agen Kantor, atau hubungkan NVR lewat IP publik / Cloudflare Tunnel di CCTV → Pengaturan.';
    } elseif ($isWin) {
        $steps[] = 'Cek CCTV otomatis: klik kanan <code>scripts\\pasang_jadwal_cctv.bat</code> → <b>Run as administrator</b>.';
        $steps[] = 'Video live CCTV: unduh ffmpeg (gyan.dev, "release essentials"), ekstrak sehingga ada <code>C:\\xampp\\ffmpeg\\bin\\ffmpeg.exe</code>.';
        if ($form['server'] === 'vps') $steps[] = 'Buka port 80/443 di firewall VPS dan pasang SSL. Jaringan kantor: VPN ke kantor atau <b>Agen Kantor</b>.';
        else $steps[] = 'Opsional: akses dari luar kantor lewat Cloudflare Tunnel atau domain + HTTPS.';
    } else {
        $steps[] = 'Cek CCTV otomatis: tambahkan ke crontab (<code>crontab -e</code>):<br><code class="break-all">* * * * * php ' . h($appDir) . '/cctv_check.php &gt;&gt; ' . h($appDir) . '/includes/data/cctv_check_log.txt 2&gt;&amp;1</code>';
        $steps[] = 'Video live CCTV: pasang ffmpeg, mis. <code>sudo apt install ffmpeg</code> (Ubuntu/Debian). Tanpa ffmpeg, live memakai snapshot.';
        $steps[] = 'Pastikan web server boleh menulis ke <code>config/</code>, <code>includes/data/</code>, <code>assets/uploads/</code> (mis. <code>sudo chown -R www-data: ' . h($appDir) . '</code>), lalu pasang HTTPS (mis. <code>sudo certbot --apache</code>).';
        if ($form['server'] === 'vps') $steps[] = $form['vpn'] !== '' ? 'VPS tersambung VPN: ping, scan & NVR lokal kantor dijangkau langsung.' : 'Jaringan kantor (cek/scan, NVR lokal): aktifkan <b>Agen Kantor</b>, atau hubungkan NVR lewat IP publik / Cloudflare Tunnel.';
    }
?>
    <div class="bg-white rounded-xl shadow-sm p-6">
        <h2 class="text-lg font-semibold text-green-700 mb-3">Instalasi berhasil</h2>
        <ul class="text-sm space-y-1 mb-5 list-disc pl-5">
            <?php foreach ($log as $l): ?><li><?= h($l) ?></li><?php endforeach; ?>
        </ul>
        <h3 class="font-semibold text-slate-800 mb-2">Langkah berikutnya untuk <?= h($OS_OPTS[$form['os']][0] . ' · ' . $SERVER_OPTS[$form['server']][0]) ?></h3>
        <ol class="text-sm space-y-2 mb-5 list-decimal pl-5 [&_code]:bg-slate-100 [&_code]:px-1 [&_code]:rounded">
            <?php foreach ($steps as $st): ?><li><?= $st ?></li><?php endforeach; ?>
        </ol>
        <p class="text-xs text-slate-500 mb-5">Langkah ini juga ada di <code class="bg-slate-100 px-1 rounded">PANDUAN_INSTALASI.md</code>. Lokasi server bisa diubah nanti di menu Agen Kantor.</p>
        <a href="login.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-5 py-2.5 text-sm font-medium">Buka halaman login</a>
    </div>

<?php elseif ($locked): ?>
    <div class="bg-white rounded-xl shadow-sm p-6">
        <h2 class="text-lg font-semibold text-slate-800 mb-2">Aplikasi sudah terinstal</h2>
        <p class="text-sm mb-5">Installer dikunci supaya tidak dijalankan ulang. Untuk instal ulang, hapus file <code class="bg-slate-100 px-1 rounded">includes/data/installed.lock</code> terlebih dulu.</p>
        <a href="login.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-5 py-2.5 text-sm font-medium">Buka halaman login</a>
    </div>

<?php else: ?>
    <?php if ($errors): ?>
    <div class="mb-5 rounded-xl bg-red-50 border border-red-200 px-5 py-4 text-sm text-red-700">
        <p class="font-semibold mb-1">Instalasi belum berhasil:</p>
        <ul class="list-disc pl-5 space-y-0.5"><?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul>
        <?php if ($log): ?><p class="mt-2 text-red-600">Langkah yang sempat selesai: <?= h(implode(' ', $log)) ?> Aman untuk dicoba lagi.</p><?php endif; ?>
    </div>
    <?php endif; ?>

    <form method="post" id="instForm" class="space-y-5" autocomplete="off">
        <input type="hidden" name="install_token" value="<?= h($_SESSION['install_token']) ?>">

        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="font-semibold text-slate-800 mb-1">1. Jenis instalasi</h2>
            <p class="text-xs text-slate-500 mb-4">Sudah ditebak dari server ini, silakan ubah bila kurang tepat. Petunjuk database, pengaturan awal & langkah lanjutan mengikuti pilihan ini.</p>
            <?php foreach ([['os', 'Sistem operasi server', $OS_OPTS, 'sm:grid-cols-2'], ['server', 'Jenis server', $SERVER_OPTS, 'sm:grid-cols-3'], ['db_type', 'Database', $DB_OPTS, 'sm:grid-cols-2']] as [$name, $title, $opts, $cols]): ?>
            <p class="text-sm font-medium text-slate-700 mb-2"><?= h($title) ?></p>
            <div class="grid <?= $cols ?> gap-2 mb-4 text-sm">
                <?php foreach ($opts as $k => [$label, $desc]): ?>
                <label class="flex gap-2 items-start rounded-lg border border-slate-200 p-3 cursor-pointer has-[:checked]:border-blue-600 has-[:checked]:bg-blue-50">
                    <input type="radio" name="<?= $name ?>" value="<?= $k ?>" <?= $form[$name] === $k ? 'checked' : '' ?> class="mt-0.5 w-4 h-4">
                    <span><span class="font-medium text-slate-800"><?= h($label) ?></span><span class="block text-xs text-slate-600"><?= h($desc) ?></span></span>
                </label>
                <?php endforeach; ?>
            </div>
            <?php if ($name === 'server'): ?>
            <label id="vpnWrap" class="flex items-center gap-2 text-sm -mt-2 mb-4"><input type="checkbox" name="vpn" value="1" <?= $form['vpn'] !== '' ? 'checked' : '' ?> class="w-4 h-4"> VPS ini tersambung VPN ke jaringan kantor (bisa ping IP lokal kantor)</label>
            <?php endif; ?>
            <?php endforeach; ?>
            <p class="text-xs text-slate-500">Database lain (PostgreSQL, SQL Server) belum didukung: aplikasi memakai MySQL/MariaDB.</p>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="font-semibold text-slate-800 mb-3">2. Kebutuhan server</h2>
            <ul class="text-sm space-y-1.5">
                <?php foreach ($checks as [$label, $ok]): ?>
                <li class="flex items-start gap-2">
                    <span class="mt-0.5 inline-block w-14 shrink-0 text-center rounded text-xs font-semibold py-0.5 <?= $ok ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>"><?= $ok ? 'OK' : 'GAGAL' ?></span>
                    <span><?= h($label) ?></span>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php if (!$requirementsOk): ?>
                <p class="mt-4 text-sm text-red-700">Perbaiki dulu bagian yang GAGAL, lalu muat ulang halaman ini.</p>
                <p class="mt-1 text-xs text-slate-600" id="reqHelp"></p>
            <?php endif; ?>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="font-semibold text-slate-800 mb-1">3. Database <span id="dbName">MySQL</span></h2>
            <div id="dbHelp" class="text-xs text-slate-600 mb-4 rounded-lg bg-slate-50 border border-slate-200 px-3 py-2"></div>
            <div class="grid sm:grid-cols-2 gap-4 text-sm">
                <label class="block"><span class="block mb-1 font-medium">Host</span>
                    <input name="db_host" required value="<?= h($form['db_host']) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">Port</span>
                    <input name="db_port" type="number" min="1" max="65535" value="<?= h($form['db_port']) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block sm:col-span-2"><span class="block mb-1 font-medium">Nama database</span>
                    <input name="db_name" id="dbNameInput" required pattern="[A-Za-z0-9_]+" value="<?= h($form['db_name']) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium" id="dbUserLabel">User MySQL yang sudah ada</span>
                    <input name="db_user" id="dbUser" required value="<?= h($form['db_user']) ?>" autocomplete="off" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium" id="dbPassLabel">Password user tersebut</span>
                    <input type="password" name="db_pass" value="" autocomplete="new-password" data-lpignore="true" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="(kosong jika tidak ada)"></label>
            </div>
            <div id="createWrap" class="mt-4 rounded-lg border border-slate-200 p-3 text-sm">
                <label class="flex items-center gap-2 font-medium"><input type="checkbox" name="create_user" value="1" id="createUser" <?= $form['create_user'] !== '' ? 'checked' : '' ?> class="w-4 h-4"> Buatkan user database baru khusus aplikasi (disarankan untuk VPS)</label>
                <p class="text-xs text-slate-500 mt-1">Isi User/Password di atas dengan akun root (atau admin MySQL). Installer membuat user baru yang hanya bisa mengakses database ini, dan aplikasi memakai user baru tersebut.</p>
                <div id="createFields" class="grid sm:grid-cols-2 gap-4 mt-3">
                    <label class="block"><span class="block mb-1 font-medium">User database baru</span>
                        <input name="new_user" value="<?= h($form['new_user']) ?>" pattern="[A-Za-z0-9_]+" autocomplete="off" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                    <label class="block"><span class="block mb-1 font-medium">Password user baru (min. 8)</span>
                        <input type="password" name="new_pass" minlength="8" autocomplete="new-password" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="font-semibold text-slate-800 mb-1">4. Identitas sistem <span class="font-normal text-slate-400">(opsional)</span></h2>
            <p class="text-xs text-slate-400 mb-4">Bisa diubah kapan saja di menu Pengaturan Sistem, termasuk logo.</p>
            <div class="grid sm:grid-cols-2 gap-4 text-sm">
                <label class="block"><span class="block mb-1 font-medium">Nama sistem</span>
                    <input name="app_name" maxlength="60" value="<?= h($form['app_name']) ?>" placeholder="IT Asset Management" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">Awalan Nomor Aset</span>
                    <input name="asset_prefix" maxlength="6" pattern="[A-Za-z0-9]*" value="<?= h($form['asset_prefix']) ?>" placeholder="AST" class="w-full border border-slate-300 rounded-lg px-3 py-2 uppercase">
                    <span class="block mt-1 text-xs text-slate-400">Contoh hasil: AST/FIN/PC/001</span></label>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="font-semibold text-slate-800 mb-4">5. Akun admin pertama</h2>
            <div class="grid sm:grid-cols-2 gap-4 text-sm">
                <label class="block"><span class="block mb-1 font-medium">Nama lengkap</span>
                    <input name="full_name" required maxlength="100" value="<?= h($form['full_name']) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">Username</span>
                    <input name="username" required maxlength="50" value="<?= h($form['username']) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">Password</span>
                    <input type="password" name="password" required minlength="6" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">Ulangi password</span>
                    <input type="password" name="password2" required minlength="6" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
            </div>
        </div>

        <button type="submit" <?= $requirementsOk ? '' : 'disabled' ?>
                class="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white font-medium rounded-lg py-3 text-sm">Instal sekarang</button>
    </form>
    <script>
    (function () {
        var f = document.getElementById('instForm'); if (!f) return;
        function val(n) { var r = f.querySelector('input[name="' + n + '"]:checked'); return r ? r.value : ''; }
        var HELP = {
            'windows|lokal': 'XAMPP bawaan: host <b>localhost</b>, port 3306, user <b>root</b>, password <b>kosong</b>. Database dibuat otomatis. Jika browser mengisi password otomatis, hapus isiannya.',
            'linux|lokal': 'Isi akun MySQL/MariaDB yang sudah ada (mis. root). Di Ubuntu, root MySQL sering memakai auth_socket: buat dulu user dengan password, atau centang "Buatkan user database baru" memakai akun admin MySQL.',
            'windows|vps': 'Isi akun admin MySQL/MariaDB di VPS (mis. root), lalu centang "Buatkan user database baru" agar aplikasi tidak memakai root.',
            'linux|vps': 'Isi akun admin MySQL/MariaDB di VPS (mis. root dengan password), lalu centang "Buatkan user database baru" agar aplikasi tidak memakai root. Database dibuat otomatis.',
            'hosting': '<b>Buat database & user dulu di panel hosting</b> (Hostinger: Databases → Management, cPanel: MySQL Database Wizard dengan ALL PRIVILEGES). Isi nama database dan user <b>lengkap dengan awalannya</b> (mis. u123456789_aset), host <b>localhost</b>. Installer tidak bisa membuat user di shared hosting.'
        };
        var REQ = {
            windows: 'Windows/XAMPP: buka C:\\xampp\\php\\php.ini, hapus titik koma di depan extension=gd, zip, mbstring, pdo_mysql, curl, lalu restart Apache.',
            linux: 'Linux: pasang ekstensi PHP, mis. sudo apt install php-mysql php-mbstring php-gd php-zip php-curl, lalu restart web server. Hosting: aktifkan di pengaturan PHP panel hosting.'
        };
        function upd() {
            var os = val('os'), sv = val('server'), db = val('db_type'), hosting = sv === 'hosting';
            document.getElementById('dbName').textContent = db === 'mariadb' ? 'MariaDB' : 'MySQL';
            document.getElementById('dbHelp').innerHTML = HELP[hosting ? 'hosting' : os + '|' + sv] || '';
            document.getElementById('vpnWrap').style.display = sv === 'vps' ? '' : 'none';
            var cw = document.getElementById('createWrap'), cu = document.getElementById('createUser');
            cw.style.display = hosting ? 'none' : '';
            document.getElementById('createFields').style.display = cu.checked && !hosting ? '' : 'none';
            var admin = cu.checked && !hosting;
            document.getElementById('dbUserLabel').textContent = admin ? 'User admin MySQL (mis. root)' : (hosting ? 'User database (dari panel hosting)' : 'User MySQL yang sudah ada');
            document.getElementById('dbPassLabel').textContent = admin ? 'Password admin MySQL' : 'Password user tersebut';
            var u = document.getElementById('dbUser');
            if (hosting && u.value === 'root') u.value = '';
            if (!hosting && u.value === '') u.value = 'root';
            u.placeholder = hosting ? 'u123456789_aset' : 'root';
            document.getElementById('dbNameInput').placeholder = hosting ? 'u123456789_aset' : 'it_asset_management';
            var rh = document.getElementById('reqHelp'); if (rh) rh.textContent = REQ[os] || '';
        }
        f.addEventListener('change', function (e) {
            if (e.target.name === 'server' && e.target.value === 'vps') { var cu = document.getElementById('createUser'); if (!cu.checked) cu.checked = true; }
            upd();
        });
        upd();
    })();
    </script>
<?php endif; ?>

    <p class="mt-8 text-center text-xs text-slate-400">@Copyright by ASKER</p>
</div>
</body>
</html>
