<?php
/**
 * INSTALLER - IT Asset Management
 * Buka sekali lewat browser: http://localhost/it_asset_management/install.php
 *
 * Yang dikerjakan:
 *   1. Cek kebutuhan server (versi PHP, ekstensi, folder yang harus bisa ditulis)
 *   2. Membuat database (jika belum ada) dan semua tabel dari sql/install.sql
 *   3. Membuat akun admin pertama
 *   4. Menulis config/database.php
 *   5. Mengunci installer (includes/data/installed.lock) supaya tidak bisa dijalankan ulang
 *
 * Untuk instal ulang: hapus file includes/data/installed.lock.
 */
session_start();

const INSTALL_LOCK   = __DIR__ . '/includes/data/installed.lock';
const INSTALL_SQL    = __DIR__ . '/sql/install.sql';
const INSTALL_CONFIG = __DIR__ . '/config/database.php';
const INSTALL_APPSET = __DIR__ . '/includes/data/app_settings.json';

function h(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/** Pecah isi file .sql menjadi daftar perintah (baris komentar "--" dibuang). */
function installSqlStatements(string $file): array
{
    $lines = [];
    foreach (preg_split('/\R/', (string)file_get_contents($file)) as $line) {
        if (preg_match('/^\s*--/', $line)) continue;
        $lines[] = $line;
    }
    $statements = [];
    foreach (preg_split('/;\s*(?:\n|$)/', implode("\n", $lines)) as $stmt) {
        $stmt = trim($stmt);
        if ($stmt !== '') $statements[] = $stmt;
    }
    return $statements;
}

/** Isi file config/database.php dengan kredensial hasil instalasi. */
function installConfigContent(string $host, string $name, string $user, string $pass): string
{
    return "<?php\n"
        . "/**\n * Konfigurasi koneksi database.\n * Ditulis otomatis oleh install.php. Boleh diubah manual kalau kredensial MySQL berganti.\n */\n"
        . "define('DB_HOST', " . var_export($host, true) . ");\n"
        . "define('DB_NAME', " . var_export($name, true) . ");\n"
        . "define('DB_USER', " . var_export($user, true) . ");\n"
        . "define('DB_PASS', " . var_export($pass, true) . ");\n\n"
        . <<<'PHP'
function getDB(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            die('Koneksi database gagal: ' . $e->getMessage());
        }
    }
    return $pdo;
}

PHP;
}

// ---------- Cek kebutuhan server ----------
$checks = [
    ['PHP 8.0 atau lebih baru (terpasang: ' . PHP_VERSION . ')', version_compare(PHP_VERSION, '8.0.0', '>=')],
    ['Ekstensi PHP: pdo_mysql', extension_loaded('pdo_mysql')],
    ['Ekstensi PHP: mbstring', extension_loaded('mbstring')],
    ['Ekstensi PHP: gd (logo, label & PDF)', extension_loaded('gd')],
    ['Ekstensi PHP: zip (export/import Excel)', extension_loaded('zip')],
    ['Folder vendor/ tersedia (PhpSpreadsheet & Dompdf)', is_file(__DIR__ . '/vendor/autoload.php')],
    ['File sql/install.sql tersedia', is_file(INSTALL_SQL)],
    ['Folder config/ bisa ditulis', is_writable(dirname(INSTALL_CONFIG)) && (!is_file(INSTALL_CONFIG) || is_writable(INSTALL_CONFIG))],
    ['Folder includes/data/ bisa ditulis', is_writable(dirname(INSTALL_LOCK))],
    ['Folder assets/uploads/logo/ bisa ditulis', is_writable(__DIR__ . '/assets/uploads/logo')],
];
$requirementsOk = !in_array(false, array_column($checks, 1), true);

$locked  = is_file(INSTALL_LOCK);
$errors  = [];
$log     = [];
$success = false;

$form = [
    'db_host' => 'localhost', 'db_name' => 'it_asset_management', 'db_user' => 'root', 'db_pass' => '',
    'app_name' => '', 'asset_prefix' => '',
    'full_name' => '', 'username' => 'admin',
];

if (empty($_SESSION['install_token'])) {
    $_SESSION['install_token'] = bin2hex(random_bytes(32));
}

if (!$locked && $_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($form as $k => $v) { $form[$k] = trim((string)($_POST[$k] ?? '')); }
    $form['db_pass'] = (string)($_POST['db_pass'] ?? ''); // password tidak di-trim
    $password  = (string)($_POST['password'] ?? '');
    $password2 = (string)($_POST['password2'] ?? '');
    $prefix    = substr(preg_replace('/[^A-Z0-9]/', '', strtoupper($form['asset_prefix'])), 0, 6);
    $appName   = mb_substr($form['app_name'], 0, 60);

    if (!hash_equals($_SESSION['install_token'], (string)($_POST['install_token'] ?? ''))) {
        $errors[] = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
    }
    if (!$requirementsOk) $errors[] = 'Kebutuhan server belum terpenuhi (lihat daftar di atas).';
    if ($form['db_host'] === '') $errors[] = 'Host database wajib diisi.';
    if (!preg_match('/^[A-Za-z0-9_]{1,64}$/', $form['db_name'])) $errors[] = 'Nama database hanya boleh huruf, angka, dan garis bawah (_).';
    if ($form['db_user'] === '') $errors[] = 'User database wajib diisi.';
    if ($form['full_name'] === '') $errors[] = 'Nama lengkap admin wajib diisi.';
    if (!preg_match('/^[A-Za-z0-9._-]{3,50}$/', $form['username'])) $errors[] = 'Username admin 3-50 karakter (huruf, angka, titik, strip, garis bawah).';
    if (strlen($password) < 6) $errors[] = 'Password admin minimal 6 karakter.';
    if ($password !== $password2) $errors[] = 'Konfirmasi password admin tidak sama.';

    if (!$errors) {
        try {
            $pdo = new PDO('mysql:host=' . $form['db_host'] . ';charset=utf8mb4', $form['db_user'], $form['db_pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            $log[] = 'Terhubung ke server MySQL.';

            $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . $form['db_name'] . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
            $pdo->exec('USE `' . $form['db_name'] . '`');
            $log[] = 'Database "' . $form['db_name'] . '" siap.';

            $statements = installSqlStatements(INSTALL_SQL);
            foreach ($statements as $i => $sql) {
                try {
                    $pdo->exec($sql);
                } catch (PDOException $e) {
                    throw new RuntimeException('Perintah SQL ke-' . ($i + 1) . ' gagal: ' . $e->getMessage());
                }
            }
            $log[] = count($statements) . ' perintah SQL dijalankan (tabel dibuat).';

            $adminCount = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
            if ($adminCount > 0) {
                $log[] = 'Database ini sudah punya akun admin, jadi akun admin baru TIDAK dibuat. Login memakai akun admin yang lama.';
            } else {
                $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, role, is_active) VALUES (?, ?, ?, 'admin', 1)");
                $stmt->execute([$form['username'], password_hash($password, PASSWORD_BCRYPT), $form['full_name']]);
                $log[] = 'Akun admin "' . $form['username'] . '" dibuat.';
            }

            if (file_put_contents(INSTALL_CONFIG, installConfigContent($form['db_host'], $form['db_name'], $form['db_user'], $form['db_pass']), LOCK_EX) === false) {
                throw new RuntimeException('Gagal menulis config/database.php. Pastikan folder config bisa ditulis.');
            }
            $log[] = 'config/database.php ditulis.';

            if ($appName !== '' || $prefix !== '') {
                $existing = is_file(INSTALL_APPSET) ? json_decode((string)file_get_contents(INSTALL_APPSET), true) : [];
                if (!is_array($existing)) $existing = [];
                $existing['app_name']     = $appName !== '' ? $appName : ($existing['app_name'] ?? '');
                $existing['logo']         = $existing['logo'] ?? '';
                $existing['asset_prefix'] = $prefix !== '' ? $prefix : ($existing['asset_prefix'] ?? '');
                $existing['updated_at']   = date('Y-m-d H:i:s');
                file_put_contents(INSTALL_APPSET, json_encode($existing, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
                $log[] = 'Nama sistem / awalan Nomor Aset disimpan.';
            }

            if (file_put_contents(INSTALL_LOCK, 'Terinstal pada ' . date('Y-m-d H:i:s') . "\n", LOCK_EX) === false) {
                throw new RuntimeException('Gagal membuat file kunci includes/data/installed.lock.');
            }
            unset($_SESSION['install_token']);
            $success = true;
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Instalasi — IT Asset Management</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate-100 py-10 px-4 text-slate-700">
<div class="max-w-2xl mx-auto">
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">Instalasi IT Asset Management</h1>
        <p class="text-sm text-slate-500 mt-1">Inventaris aset IT &amp; ticketing helpdesk. Isi formulir di bawah, sisanya dikerjakan otomatis.</p>
    </div>

<?php if ($success): ?>
    <div class="bg-white rounded-xl shadow-sm p-6">
        <h2 class="text-lg font-semibold text-green-700 mb-3">Instalasi berhasil</h2>
        <ul class="text-sm space-y-1 mb-5 list-disc pl-5">
            <?php foreach ($log as $l): ?><li><?= h($l) ?></li><?php endforeach; ?>
        </ul>
        <p class="text-sm mb-5">Installer sudah dikunci. Demi keamanan, sebaiknya hapus file <code class="bg-slate-100 px-1 rounded">install.php</code> dari server.</p>
        <a href="login.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-5 py-2.5 text-sm font-medium">Buka halaman login</a>
    </div>

<?php elseif ($locked): ?>
    <div class="bg-white rounded-xl shadow-sm p-6">
        <h2 class="text-lg font-semibold text-slate-800 mb-2">Aplikasi sudah terinstal</h2>
        <p class="text-sm mb-5">Installer dikunci supaya tidak dijalankan ulang. Untuk instal ulang, hapus file <code class="bg-slate-100 px-1 rounded">includes/data/installed.lock</code> terlebih dulu.</p>
        <a href="login.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-5 py-2.5 text-sm font-medium">Buka halaman login</a>
    </div>

<?php else: ?>
    <div class="bg-white rounded-xl shadow-sm p-6 mb-5">
        <h2 class="font-semibold text-slate-800 mb-3">1. Kebutuhan server</h2>
        <ul class="text-sm space-y-1.5">
            <?php foreach ($checks as [$label, $ok]): ?>
            <li class="flex items-start gap-2">
                <span class="mt-0.5 inline-block w-14 shrink-0 text-center rounded text-xs font-semibold py-0.5 <?= $ok ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>"><?= $ok ? 'OK' : 'GAGAL' ?></span>
                <span><?= h($label) ?></span>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php if (!$requirementsOk): ?>
            <p class="mt-4 text-sm text-red-700">Perbaiki dulu bagian yang GAGAL, lalu muat ulang halaman ini.</p>
        <?php endif; ?>
    </div>

    <?php if ($errors): ?>
    <div class="mb-5 rounded-xl bg-red-50 border border-red-200 px-5 py-4 text-sm text-red-700">
        <p class="font-semibold mb-1">Instalasi belum berhasil:</p>
        <ul class="list-disc pl-5 space-y-0.5"><?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul>
        <?php if ($log): ?><p class="mt-2 text-red-600">Langkah yang sempat selesai: <?= h(implode(' ', $log)) ?> Aman untuk dicoba lagi.</p><?php endif; ?>
    </div>
    <?php endif; ?>

    <form method="post" class="space-y-5" autocomplete="off">
        <input type="hidden" name="install_token" value="<?= h($_SESSION['install_token']) ?>">

        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="font-semibold text-slate-800 mb-1">2. Database MySQL</h2>
            <p class="text-xs text-slate-400 mb-4">XAMPP bawaan: host <b>localhost</b>, user <b>root</b>, password kosong. Database dibuat otomatis kalau belum ada.</p>
            <div class="grid sm:grid-cols-2 gap-4 text-sm">
                <label class="block"><span class="block mb-1 font-medium">Host</span>
                    <input name="db_host" required value="<?= h($form['db_host']) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">Nama database</span>
                    <input name="db_name" required pattern="[A-Za-z0-9_]+" value="<?= h($form['db_name']) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">User</span>
                    <input name="db_user" required value="<?= h($form['db_user']) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">Password</span>
                    <input type="password" name="db_pass" value="" class="w-full border border-slate-300 rounded-lg px-3 py-2" placeholder="(kosong jika tidak ada)"></label>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="font-semibold text-slate-800 mb-1">3. Identitas sistem <span class="font-normal text-slate-400">(opsional)</span></h2>
            <p class="text-xs text-slate-400 mb-4">Bisa diubah kapan saja di menu Pengaturan Sistem, termasuk logo.</p>
            <div class="grid sm:grid-cols-2 gap-4 text-sm">
                <label class="block"><span class="block mb-1 font-medium">Nama sistem</span>
                    <input name="app_name" maxlength="60" value="<?= h($form['app_name']) ?>" placeholder="IT Asset Management" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">Awalan Nomor Aset</span>
                    <input name="asset_prefix" maxlength="6" pattern="[A-Za-z0-9]*" value="<?= h($form['asset_prefix']) ?>" placeholder="AST" class="w-full border border-slate-300 rounded-lg px-3 py-2 uppercase">
                    <span class="block mt-1 text-xs text-slate-400">Contoh hasil: AST/FIN/PC/001</span></label>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="font-semibold text-slate-800 mb-4">4. Akun admin pertama</h2>
            <div class="grid sm:grid-cols-2 gap-4 text-sm">
                <label class="block"><span class="block mb-1 font-medium">Nama lengkap</span>
                    <input name="full_name" required maxlength="100" value="<?= h($form['full_name']) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">Username</span>
                    <input name="username" required maxlength="50" value="<?= h($form['username']) ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">Password</span>
                    <input type="password" name="password" required minlength="6" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
                <label class="block"><span class="block mb-1 font-medium">Ulangi password</span>
                    <input type="password" name="password2" required minlength="6" class="w-full border border-slate-300 rounded-lg px-3 py-2"></label>
            </div>
        </div>

        <button type="submit" <?= $requirementsOk ? '' : 'disabled' ?>
                class="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white font-medium rounded-lg py-3 text-sm">Instal sekarang</button>
    </form>
<?php endif; ?>

    <p class="mt-8 text-center text-xs text-slate-400">@Copyright by ASKER</p>
</div>
</body>
</html>
