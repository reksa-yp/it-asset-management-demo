<?php
/**
 * Kop Surat (khusus admin): atur logo, ornamen, nama & alamat perusahaan yang dicetak di
 * semua dokumen (Print / PDF) dan di kepala file Excel.
 * Data disimpan di includes/data/letterhead.json — tidak memakai database.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/letterhead.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $cur = letterheadSettings();
    $new = [
        'enabled'      => !empty($_POST['enabled']),
        'company_name' => (string)($_POST['company_name'] ?? ''),
        'short_name'   => (string)($_POST['short_name'] ?? ''),
        'address'      => (string)($_POST['address'] ?? ''),
        'timezone'     => (string)($_POST['timezone'] ?? ''),
    ];
    $msg = ['ok' => true, 'text' => t('lh_saved')];
    foreach (LETTERHEAD_SLOTS as $slot) {
        $new[$slot] = $cur[$slot];
        if (!empty($_POST['remove_' . $slot])) {
            deleteLetterheadFile($new[$slot]);
            $new[$slot] = '';
        }
        $up = handleLetterheadUpload($slot, $slot);
        if (!$up['ok']) {
            $msg = ['ok' => false, 'text' => t($up['error'])];
        } elseif ($up['file'] !== '') {
            deleteLetterheadFile($new[$slot]);
            $new[$slot] = $up['file'];
        }
    }
    // Gambar yang berhasil diunggah tetap disimpan walau ada gambar lain yang ditolak.
    if (!saveLetterheadSettings($new)) $msg = ['ok' => false, 'text' => t('lh_save_failed')];
    $_SESSION['letterhead_msg'] = $msg;
    header('Location: letterhead_settings.php');
    exit;
}

$lhMsg = $_SESSION['letterhead_msg'] ?? null;
unset($_SESSION['letterhead_msg']);
$s = letterheadSettings();
$slotInfo = [
    'logo'        => [t('lh_logo'), t('lh_logo_hint')],
    'ornament'    => [t('lh_ornament'), t('lh_ornament_hint')],
    'footer_logo' => [t('lh_footer_logo'), t('lh_footer_logo_hint')],
];

$pageTitle = t('page_title_letterhead');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="max-w-3xl">
    <p class="text-sm text-slate-500 mb-4"><?= t('lh_intro') ?></p>

    <?php if ($lhMsg): ?>
        <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $lhMsg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>">
            <?= htmlspecialchars($lhMsg['text']) ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="bg-white rounded-xl shadow-sm divide-y">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

        <!-- Pratinjau kop yang tersimpan -->
        <div class="p-5">
            <div class="flex items-center justify-between gap-3 mb-3">
                <p class="text-xs font-semibold uppercase tracking-wide text-slate-400"><?= t('lh_preview') ?></p>
                <a href="letterhead_preview.php" target="_blank" rel="noopener" class="text-sm text-blue-600 hover:underline"><?= t('lh_preview_btn') ?></a>
            </div>
            <div class="border border-slate-200 rounded-lg bg-white p-5">
                <?php if (letterheadHas('header')): ?><?= letterheadPart('header') ?><?php else: ?><p class="text-xs text-slate-400 italic"><?= t('lh_empty_header') ?></p><?php endif; ?>
                <div class="my-4 space-y-2">
                    <div class="h-2 rounded bg-slate-100 w-2/3"></div><div class="h-2 rounded bg-slate-100"></div><div class="h-2 rounded bg-slate-100 w-5/6"></div>
                </div>
                <?php if (letterheadHas('footer')): ?><?= letterheadPart('footer') ?><?php else: ?><p class="text-xs text-slate-400 italic text-right"><?= t('lh_empty_footer') ?></p><?php endif; ?>
            </div>
            <?php if (!$s['enabled']): ?><p class="mt-2 text-xs text-amber-600"><?= t('lh_disabled_note') ?></p>
            <?php elseif ($s['logo'] === '' && letterheadImagePath('logo') !== ''): ?><p class="mt-2 text-xs text-slate-400"><?= t('lh_uses_app_logo') ?></p><?php endif; ?>
        </div>

        <div class="p-5 space-y-4">
            <label class="flex items-center gap-2 text-sm font-medium text-slate-700">
                <input type="checkbox" name="enabled" value="1" <?= $s['enabled'] ? 'checked' : '' ?> class="rounded border-slate-300">
                <?= t('lh_enabled') ?>
            </label>
            <div class="grid sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1" for="lh_company"><?= t('lh_company_name') ?></label>
                    <input type="text" id="lh_company" name="company_name" maxlength="100" value="<?= htmlspecialchars($s['company_name']) ?>"
                           placeholder="PT. Contoh Maju Bersama" class="w-full border rounded-lg px-3 py-2 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1" for="lh_short"><?= t('lh_short_name') ?></label>
                    <input type="text" id="lh_short" name="short_name" maxlength="30" value="<?= htmlspecialchars($s['short_name']) ?>"
                           placeholder="CMB" class="w-full border rounded-lg px-3 py-2 text-sm">
                    <p class="text-xs text-slate-400 mt-1"><?= t('lh_short_name_hint') ?></p>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1" for="lh_address"><?= t('lh_address') ?></label>
                <textarea id="lh_address" name="address" rows="4" maxlength="500" class="w-full border rounded-lg px-3 py-2 text-sm"
                          placeholder="Jl. Contoh No. 1, Kawasan Industri&#10;Kota, Provinsi 12345&#10;T. (021) 000-0000"><?= htmlspecialchars($s['address']) ?></textarea>
                <p class="text-xs text-slate-400 mt-1"><?= t('lh_address_hint') ?></p>
            </div>
            <div class="sm:w-1/2">
                <label class="block text-sm font-medium text-slate-700 mb-1" for="lh_tz"><?= t('lh_timezone') ?></label>
                <select id="lh_tz" name="timezone" class="w-full border rounded-lg px-3 py-2 text-sm">
                    <?php foreach (LETTERHEAD_TIMEZONES as $tz => $label): ?>
                        <option value="<?= $tz ?>" <?= $s['timezone'] === $tz ? 'selected' : '' ?>><?= $label ?> (<?= $tz ?>)</option>
                    <?php endforeach; ?>
                </select>
                <p class="text-xs text-slate-400 mt-1"><?= t('lh_timezone_hint') ?></p>
            </div>
        </div>

        <?php foreach ($slotInfo as $slot => [$label, $hint]): $url = letterheadImageUrl($slot); ?>
        <div class="p-5">
            <label class="block text-sm font-medium text-slate-700 mb-2"><?= $label ?></label>
            <div class="flex items-start gap-4">
                <div class="w-32 h-20 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0">
                    <?php if ($url): ?><img src="<?= htmlspecialchars($url) ?>" class="max-w-full max-h-full object-contain" alt="">
                    <?php else: ?><span class="text-xs text-slate-400"><?= t('lh_no_image') ?></span><?php endif; ?>
                </div>
                <div class="flex-1 space-y-2">
                    <input type="file" name="<?= $slot ?>" accept="image/png,image/jpeg"
                           class="block w-full text-sm text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-slate-100 file:px-3 file:py-2 file:text-sm file:font-medium hover:file:bg-slate-200">
                    <p class="text-xs text-slate-400"><?= $hint ?></p>
                    <?php if ($url): ?>
                        <label class="inline-flex items-center gap-2 text-sm text-slate-600">
                            <input type="checkbox" name="remove_<?= $slot ?>" value="1" class="rounded border-slate-300"> <?= t('lh_remove') ?>
                        </label>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>

        <div class="form-actions-sticky p-5 flex justify-end rounded-b-xl">
            <button type="submit" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
                <?= icon('check') ?> <?= t('btn_save') ?>
            </button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
