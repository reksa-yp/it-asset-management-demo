<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['excel_file']['tmp_name'])) {
    header('Location: users.php');
    exit;
}
csrfCheck();

$validRoles    = ['admin', 'user'];
$activeWords   = ['aktif', 'active', '1', 'ya', 'yes'];
$inactiveWords = ['nonaktif', 'tidak aktif', 'inactive', '0', 'tidak', 'no'];

try {
    $spreadsheet = IOFactory::load($_FILES['excel_file']['tmp_name']);
    $sheet = $spreadsheet->getActiveSheet();

    // File gabungan Aset + User juga bisa di-upload dari menu User.
    require_once __DIR__ . '/includes/asset_user_import.php';
    if (isAssetUserXlsHeader(readSheetHeader($sheet))) {
        $db = getDB();
        $db->beginTransaction();
        $res = importAssetUserSheet($db, $sheet);
        $db->commit();
        $text = t('import_au_done', $res['assets_new'], $res['assets_upd'], $res['users_new'], $res['users_upd'], $res['skipped']);
        if ($res['errors']) $text .= ' ' . t('import_au_notes') . ' ' . implode(' | ', array_slice($res['errors'], 0, 8));
        $_SESSION['user_import_msg'] = ['ok' => true, 'text' => $text];
        header('Location: users.php');
        exit;
    }
    $rows  = $sheet->toArray(null, true, true, true); // keyed by column letter (A, B, C...)

    $headerRow = array_shift($rows); // baris pertama = header
    $colMap = [];
    foreach ($headerRow as $letter => $title) {
        $colMap[trim((string)$title)] = $letter;
    }

    $required = ['Nama Lengkap', 'Username'];
    foreach ($required as $r) {
        if (!isset($colMap[$r])) {
            throw new Exception("Kolom wajib '$r' tidak ditemukan. Pastikan format sesuai template.");
        }
    }

    $db = getDB();
    ensureUserPositionTable($db); // dibuat sebelum transaksi (CREATE TABLE mengakhiri transaksi di MySQL)
    $findUser = $db->prepare("SELECT id, password FROM users WHERE username = ? LIMIT 1");

    $insert = $db->prepare("INSERT INTO users
        (full_name, username, email, department, password, pc_username, pc_password, role, is_active)
        VALUES (?,?,?,?,?,?,?,?,?)");

    $updateWithPassword = $db->prepare("UPDATE users SET
        full_name=?, email=?, department=?, password=?, pc_username=?, pc_password=?, role=?, is_active=?
        WHERE username=?");

    $updateNoPassword = $db->prepare("UPDATE users SET
        full_name=?, email=?, department=?, pc_username=?, pc_password=?, role=?, is_active=?
        WHERE username=?");

    $get = fn(array $row, string $key) => isset($colMap[$key]) ? trim((string)($row[$colMap[$key]] ?? '')) : '';

    $inserted = 0; $updated = 0; $skipped = 0; $errors = [];
    $rowNum = 1; // baris 1 = header, data mulai dari baris 2

    $db->beginTransaction();

    foreach ($rows as $row) {
        $rowNum++;

        $fullName = $get($row, 'Nama Lengkap');
        $username = $get($row, 'Username');

        if ($fullName === '' || $username === '') {
            $skipped++;
            continue;
        }

        $email    = $get($row, 'Email');
        $department = $get($row, 'Departement');
        $position = $get($row, 'Jabatan');
        $password = $get($row, 'Password');

        $pcUsername = $get($row, 'Username PC');
        $pcPassword = $get($row, 'Password PC');
        $pcUsername = $pcUsername !== '' ? $pcUsername : null;
        $pcPassword = $pcPassword !== '' ? $pcPassword : null;

        $roleRaw = strtolower($get($row, 'Role'));
        $role = in_array($roleRaw, $validRoles, true) ? $roleRaw : 'user';

        $statusRaw = strtolower($get($row, 'Status'));
        if (in_array($statusRaw, $inactiveWords, true)) {
            $isActive = 0;
        } else {
            // default aktif kalau kosong atau tidak dikenali
            $isActive = 1;
        }

        $findUser->execute([$username]);
        $existing = $findUser->fetch();

        if ($existing) {
            // Update user yang sudah ada. Username tidak diubah lewat import (dipakai sebagai kunci pencocokan).
            if ($password !== '') {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $updateWithPassword->execute([$fullName, $email, $department, $hash, $pcUsername, $pcPassword, $role, $isActive, $username]);
            } else {
                $updateNoPassword->execute([$fullName, $email, $department, $pcUsername, $pcPassword, $role, $isActive, $username]);
            }
            // Jabatan hanya diubah kalau file punya kolom Jabatan dan selnya diisi.
            if ($position !== '') saveUserPosition($db, (int)$existing['id'], $position);
            $updated++;
        } else {
            // User baru wajib punya password.
            if ($password === '') {
                $errors[] = "Baris $rowNum ($username): dilewati, Password wajib diisi untuk user baru.";
                $skipped++;
                continue;
            }
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $insert->execute([$fullName, $username, $email, $department, $hash, $pcUsername, $pcPassword, $role, $isActive]);
            if ($position !== '') saveUserPosition($db, (int)$db->lastInsertId(), $position);
            $inserted++;
        }
    }

    // Aset yang dipakai user-user ini ikut data terbaru dari master User
    // (Departement, Email, Username & Password PC). Lihat includes/asset_user_sync.php.
    if (assetOwnersTableExists($db)) {
        syncAssetsUserData($db, array_map('intval', $db->query("SELECT DISTINCT asset_id FROM asset_owners")->fetchAll(PDO::FETCH_COLUMN)));
    }

    $db->commit();

    $text = "Import selesai: $inserted user baru ditambahkan, $updated user diperbarui, $skipped baris dilewati.";
    if ($errors) {
        $text .= ' Detail: ' . implode(' | ', array_slice($errors, 0, 5));
        if (count($errors) > 5) {
            $text .= ' (dan ' . (count($errors) - 5) . ' lainnya)';
        }
    }

    $_SESSION['user_import_msg'] = ['ok' => true, 'text' => $text];
} catch (Throwable $e) {
    if (isset($db) && $db->inTransaction()) { $db->rollBack(); }
    $_SESSION['user_import_msg'] = ['ok' => false, 'text' => 'Import gagal: ' . $e->getMessage()];
}

header('Location: users.php');
exit;
