<?php
/**
 * Menu "Chat Grup" (semua user): obrolan grup terenkripsi, kirim foto (dikecilkan otomatis), balas,
 * sebut nama (@nama), dibaca oleh, hapus pesan, sematkan, bagikan tiket/aset, grup pengumuman.
 * Data diambil lewat chat_api.php (cek pesan baru tiap 3 detik selama halaman ini dibuka).
 *   chat.php?g=ID[&m=PESAN]  -> langsung buka grup (dan sorot pesan) dari notifikasi
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();
require_once __DIR__ . '/includes/chat.php';

$db = getDB();
ensureChatTables($db);
$admin = isAdmin();
$me = currentUser();
$keyError = '';
try { chatKey($db); } catch (Throwable $e) { $keyError = $e->getMessage(); }
$set = chatSettings();
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES);

$pageTitle = chL('Chat Grup', 'Group Chat');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<style>
    main:has(#chatApp) > footer { display: none; }
    #chatApp { --line: #e2e8f0; --muted: #64748b; --brand: #274fe6; --brand-50: #eef4ff; --mine: #dbe7fe; display: grid; grid-template-columns: 300px 1fr; background: #fff; border-radius: 14px; overflow: hidden; box-shadow: 0 1px 3px rgba(15,23,42,.08); min-height: 420px; position: relative; }
    #chatApp .groups { border-right: 1px solid var(--line); display: flex; flex-direction: column; min-width: 0; min-height: 0; }
    #chatApp .glist { overflow-y: auto; flex: 1; }
    #chatApp .gitem { width: 100%; text-align: left; display: grid; grid-template-columns: 40px 1fr auto; gap: 2px 10px; padding: 10px 14px; border-bottom: 1px solid #f1f5f9; align-items: center; }
    #chatApp .gitem:hover { background: #f8fafc; }
    #chatApp .gitem.on { background: var(--brand-50); }
    #chatApp .av { width: 40px; height: 40px; border-radius: 50%; display: grid; place-items: center; font-weight: 700; font-size: 14px; color: #fff; grid-row: span 2; flex-shrink: 0; }
    #chatApp .gitem b { font-size: 14px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    #chatApp .gitem .last { grid-column: 2; font-size: 12px; color: var(--muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    #chatApp .gitem .t { font-size: 11px; color: var(--muted); align-self: start; }
    #chatApp .gitem .badges { grid-column: 3; justify-self: end; display: flex; gap: 4px; }
    #chatApp .unread { background: var(--brand); color: #fff; font-size: 10px; font-weight: 700; border-radius: 999px; padding: 1px 6px; }
    #chatApp .at { background: #f59e0b; color: #fff; font-size: 10px; font-weight: 700; border-radius: 999px; padding: 1px 5px; }
    #chatApp .tag { font-size: 10px; font-weight: 700; color: #b45309; background: #fef3c7; border-radius: 4px; padding: 0 4px; margin-left: 4px; vertical-align: 1px; }
    #chatApp .room { display: flex; flex-direction: column; min-width: 0; min-height: 0; background: #f8fafc; }
    #chatApp .msgs { flex: 1; overflow-y: auto; padding: 14px; display: flex; flex-direction: column; gap: 6px; min-height: 0; }
    #chatApp .day { align-self: center; font-size: 11px; color: var(--muted); background: #e2e8f0; border-radius: 999px; padding: 2px 10px; margin: 6px 0; }
    #chatApp .sys { align-self: center; font-size: 12px; color: var(--muted); text-align: center; max-width: 85%; background: #eef2f7; border-radius: 8px; padding: 3px 10px; white-space: pre-line; }
    #chatApp .m { position: relative; max-width: min(72%, 520px); background: #fff; border: 1px solid var(--line); border-radius: 12px 12px 12px 4px; padding: 6px 10px 4px; align-self: flex-start; font-size: 14px; line-height: 1.45; overflow-wrap: anywhere; }
    #chatApp .m.me { align-self: flex-end; background: var(--mine); border-color: #bfd6fe; border-radius: 12px 12px 4px 12px; }
    #chatApp .m.flash { box-shadow: 0 0 0 3px #fde047; }
    #chatApp .m .from { font-size: 12px; font-weight: 700; margin-bottom: 1px; padding-right: 22px; }
    #chatApp .m .foot { display: flex; gap: 6px; justify-content: flex-end; align-items: center; font-size: 10.5px; color: var(--muted); margin-top: 2px; font-variant-numeric: tabular-nums; }
    #chatApp .m .readbtn { font-size: 10.5px; color: var(--muted); }
    #chatApp .m .readbtn.all { color: #2563eb; }
    #chatApp .m img.ph { display: block; border-radius: 8px; margin: 4px 0 2px; max-height: 260px; max-width: 100%; width: auto; cursor: zoom-in; background: #e2e8f0; min-width: 80px; min-height: 60px; }
    #chatApp .m .del { font-style: italic; color: var(--muted); }
    #chatApp .m .quote { border-left: 3px solid var(--brand); background: rgba(39,79,230,.06); border-radius: 4px; padding: 3px 8px; margin: 2px 0 4px; font-size: 12.5px; cursor: pointer; }
    #chatApp .m .quote b { display: block; font-size: 11.5px; color: var(--brand); }
    #chatApp .mention { background: #fef08a; border-radius: 3px; padding: 0 2px; font-weight: 600; }
    #chatApp .m .more { position: absolute; top: 3px; right: 4px; width: 22px; height: 22px; border-radius: 6px; color: var(--muted); opacity: 0; font-size: 15px; line-height: 1; }
    #chatApp .m:hover .more, #chatApp .m:focus-within .more { opacity: 1; }
    @media (hover: none) { #chatApp .m .more { opacity: .7; } }
    #chatApp .card { display: flex; gap: 10px; align-items: flex-start; border: 1px solid var(--line); border-radius: 10px; background: #fff; padding: 8px 10px; margin: 4px 0 2px; }
    #chatApp .card:hover { border-color: #93b9fd; }
    #chatApp .card .ci { width: 38px; height: 34px; border-radius: 8px; display: grid; place-items: center; flex-shrink: 0; font-weight: 700; font-size: 10px; }
    #chatApp .card b { display: block; font-size: 13px; }
    #chatApp .card small { display: block; font-size: 12px; color: var(--muted); }
    #chatApp .card .open { font-size: 12px; color: var(--brand); font-weight: 600; margin-top: 2px; display: block; }
    .chat-menu { position: fixed; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 8px 24px rgba(15,23,42,.16); padding: 6px; display: flex; flex-direction: column; min-width: 200px; max-height: 60vh; overflow-y: auto; z-index: 70; }
    .chat-menu.hidden { display: none; }
    .chat-menu button { display: flex; align-items: center; gap: 10px; padding: 8px 10px; border-radius: 8px; text-align: left; font-size: 13.5px; }
    .chat-menu button:hover, .chat-menu button:focus-visible { background: #eef4ff; }
    .chat-menu button.red { color: #b91c1c; }
    .chat-menu button:disabled { color: #94a3b8; cursor: not-allowed; background: none; }
    .chat-menu svg { width: 18px; height: 18px; color: #274fe6; flex-shrink: 0; }
    .chat-menu small { display: block; font-size: 11.5px; color: #64748b; }
    .chat-menu h5 { margin: 4px 10px 2px; font-size: 11px; text-transform: uppercase; letter-spacing: .05em; color: #64748b; }
    .chat-menu .ppl { font-size: 13px; padding: 2px 10px; display: flex; justify-content: space-between; gap: 10px; }
    .chat-menu .ppl span { color: #64748b; font-size: 12px; }
    #chatApp .icon-btn { width: 40px; height: 40px; border-radius: 10px; border: 1px solid #cbd5e1; background: #fff; display: grid; place-items: center; flex-shrink: 0; color: var(--muted); }
    #chatApp .icon-btn.send { background: var(--brand); border-color: var(--brand); color: #fff; }
    #chatApp .icon-btn svg { width: 20px; height: 20px; }
    #chatApp .back { display: none; }
    @media (max-width: 767.98px) {
        #chatApp { grid-template-columns: 1fr; }
        #chatApp.in-room .groups { display: none; }
        #chatApp:not(.in-room) .room { display: none; }
        #chatApp .back { display: grid; }
        #chatApp .m { max-width: 86%; }
    }
</style>

<?php if ($keyError): ?>
    <div class="bg-red-50 border border-red-200 text-red-800 rounded-xl px-4 py-3 mb-3 text-sm"><?= $h($keyError) ?></div>
<?php endif; ?>

<div id="chatApp">
    <section class="groups" aria-label="<?= $h(chL('Daftar grup', 'Groups')) ?>">
        <div class="flex items-center gap-2 px-4 h-14 border-b">
            <h2 class="font-semibold text-slate-800"><?= $h(chL('Chat Grup', 'Group Chat')) ?></h2>
            <span class="ml-auto"></span>
            <?php if ($admin): ?><button type="button" id="btnManage" class="border border-slate-300 hover:bg-slate-50 rounded-lg px-3 py-1.5 text-xs font-semibold"><?= $h(chL('Kelola grup', 'Manage groups')) ?></button><?php endif; ?>
        </div>
        <div class="glist" id="glist"><p class="p-4 text-sm text-slate-500"><?= $h(chL('Memuat…', 'Loading…')) ?></p></div>
    </section>

    <section class="room" aria-label="<?= $h(chL('Percakapan', 'Conversation')) ?>">
        <div class="flex items-center gap-3 px-3 sm:px-4 h-14 bg-white border-b">
            <button type="button" class="icon-btn back" id="btnBack" aria-label="<?= $h(chL('Kembali ke daftar grup', 'Back to groups')) ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg></button>
            <span class="av" id="rAv" style="width:36px;height:36px"></span>
            <span class="min-w-0 flex-1"><b class="block text-[15px] truncate" id="rName"></b><small class="block text-xs text-slate-500 truncate" id="rSub"></small></span>
            <span class="hidden sm:inline-flex items-center gap-1.5 text-[11px] font-semibold text-green-700 bg-green-100 rounded-full px-2.5 py-1 whitespace-nowrap" title="<?= $h(chL('Pesan & foto disimpan terenkripsi AES-256 di server', 'Messages & photos are stored AES-256 encrypted on the server')) ?>">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg><?= $h(chL('Terenkripsi', 'Encrypted')) ?></span>
        </div>
        <div id="pinbar" class="hidden flex items-center gap-2 bg-amber-50 border-b border-amber-200 px-4 py-1.5 text-sm"></div>
        <div class="msgs" id="msgs" aria-live="polite"></div>
        <div id="replybar" class="hidden flex items-center gap-2 px-3 py-1.5 border-t bg-white text-[12.5px]"></div>
        <div id="pending" class="hidden flex items-center gap-2 px-3 py-1.5 border-t border-amber-200 bg-amber-50 text-amber-800 text-[12.5px]"></div>
        <div id="readonly" class="hidden bg-white border-t px-4 py-3 text-sm text-slate-500 text-center">📢 <?= $h(chL('Grup pengumuman: hanya admin yang dapat mengirim pesan di sini.', 'Announcement group: only admins can post here.')) ?></div>
        <form id="compose" class="hidden relative bg-white border-t p-2.5 flex gap-2 items-end">
            <input type="file" id="fileCam" accept="image/*" capture="environment" class="hidden">
            <input type="file" id="fileGal" accept="image/*" class="hidden">
            <button type="button" class="icon-btn" id="btnAttach" aria-haspopup="menu" aria-expanded="false" title="<?= $h(chL('Foto / bagikan', 'Photo / share')) ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg></button>
            <textarea id="txt" rows="1" maxlength="4000" class="flex-1 min-w-0 resize-none border border-slate-300 rounded-xl px-3 py-2 text-sm max-h-32" placeholder="<?= $h(chL('Tulis pesan… ketik @ untuk menyebut nama', 'Write a message… type @ to mention')) ?>" aria-label="<?= $h(chL('Pesan', 'Message')) ?>"></textarea>
            <button type="submit" class="icon-btn send" id="btnSend" aria-label="<?= $h(chL('Kirim', 'Send')) ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4z"/></svg></button>
        </form>
    </section>
</div>

<div id="chatMenu" class="chat-menu hidden" role="menu"></div>

<!-- Bagikan tiket / aset -->
<div id="sharePanel" class="hidden fixed inset-0 z-[60] bg-slate-900/50 flex items-center justify-center p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col">
        <div class="flex items-center gap-2 px-5 py-4 border-b"><h3 class="font-semibold"><?= $h(chL('Bagikan ke grup', 'Share to group')) ?></h3><button type="button" data-modal-close data-close class="ml-auto text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button></div>
        <div class="p-4 space-y-3 overflow-y-auto">
            <input type="search" id="shareQ" class="w-full border rounded-lg px-3 py-2 text-sm" placeholder="<?= $h($admin ? chL('Cari no. tiket, masalah, no. aset, nama perangkat…', 'Search ticket no., problem, asset no., device…') : chL('Cari no. tiket atau masalah (tiket Anda)…', 'Search your ticket no. or problem…')) ?>">
            <div id="shareList" class="space-y-2 text-sm"></div>
        </div>
    </div>
</div>

<div id="lightbox" class="hidden fixed inset-0 z-[80] bg-slate-950/85 flex items-center justify-center p-4"><img id="lbImg" alt="" class="max-h-[90vh] max-w-full rounded-lg"></div>

<?php if ($admin): ?>
<!-- Kelola grup (admin) -->
<div id="manage" class="hidden fixed inset-0 z-[60] bg-slate-900/50 flex items-center justify-center p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div class="flex items-center gap-2 px-5 py-4 border-b"><h3 class="font-semibold text-lg"><?= $h(chL('Kelola grup chat', 'Manage chat groups')) ?></h3><button type="button" data-modal-close data-close class="ml-auto text-slate-400 hover:text-slate-600"><?= icon('x', 'w-5 h-5') ?></button></div>
        <div class="p-5 space-y-6 overflow-y-auto text-sm">
            <section class="space-y-3">
                <h4 class="text-xs font-semibold uppercase tracking-wider text-slate-500"><?= $h(chL('Grup', 'Group')) ?></h4>
                <div class="flex flex-wrap gap-2"><select id="mGroup" class="border rounded-lg px-3 py-2 min-w-0 flex-1"></select><button type="button" id="mDel" class="border border-red-200 text-red-700 hover:bg-red-50 rounded-lg px-3 py-2 font-medium"><?= $h(chL('Hapus grup', 'Delete group')) ?></button></div>
                <label class="block"><span class="block text-xs text-slate-500 mb-1"><?= $h(chL('Nama grup', 'Group name')) ?></span><input type="text" id="mName" maxlength="100" class="w-full border rounded-lg px-3 py-2"></label>
                <label class="flex gap-2 items-start"><input type="checkbox" id="mAnn" class="mt-0.5"><span><b><?= $h(chL('Grup pengumuman', 'Announcement group')) ?></b>: <?= $h(chL('hanya admin yang boleh menulis, user hanya membaca', 'only admins post, users read')) ?></span></label>
                <label class="flex gap-2 items-start"><input type="checkbox" id="mAllUsers" class="mt-0.5"><span><b><?= $h(chL('Semua user terdaftar', 'All registered users')) ?></b> <?= $h(chL('(user baru otomatis ikut)', '(new users join automatically)')) ?></span></label>
                <div id="mMemberWrap">
                    <div class="flex flex-wrap items-center gap-2 mb-2"><span class="text-xs text-slate-500"><?= $h(chL('Anggota', 'Members')) ?> <span id="mCount"></span></span><input type="search" id="mFind" class="border rounded-lg px-2 py-1 text-xs ml-auto" placeholder="<?= $h(chL('Cari nama / departement', 'Search name / dept')) ?>"><button type="button" id="mAll" class="border rounded-lg px-2 py-1 text-xs"><?= $h(chL('Pilih semua', 'Select all')) ?></button><button type="button" id="mNone" class="border rounded-lg px-2 py-1 text-xs"><?= $h(chL('Kosongkan', 'Clear')) ?></button></div>
                    <div id="mMembers" class="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-64 overflow-y-auto pr-1"></div>
                </div>
                <p class="text-xs text-slate-500"><?= $h(chL('User yang dinonaktifkan di Management User otomatis keluar dari semua grup dan tidak bisa membaca chat lagi.', 'Users deactivated in User Management leave all groups automatically.')) ?></p>
                <div class="flex justify-end"><button type="button" id="mSave" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-semibold"><?= $h(chL('Simpan grup', 'Save group')) ?></button></div>
            </section>
            <section class="space-y-2 border-t pt-5">
                <h4 class="text-xs font-semibold uppercase tracking-wider text-slate-500"><?= $h(chL('Kunci enkripsi', 'Encryption key')) ?></h4>
                <div class="rounded-lg border border-red-200 bg-red-50 text-red-900 px-3 py-2 leading-relaxed"><b><?= $h(chL('Simpan cadangan kunci di tempat terpisah.', 'Keep a separate backup of the key.')) ?></b> <?= $h(chL('Semua pesan dan foto chat hanya bisa dibuka dengan kunci ini. Kalau server di-install ulang dan kuncinya hilang, chat lama tidak bisa dibuka lagi, walaupun database sudah di-backup. Untuk memulihkan: salin file chat_key.php ke folder includes/data/.', 'All chat messages and photos can only be read with this key. If the server is reinstalled and the key is lost, old chats cannot be opened, even with a database backup. To restore: copy chat_key.php into includes/data/.')) ?></div>
                <div class="flex flex-wrap items-center gap-3"><a href="chat_api.php?a=key" id="mKey" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-semibold"><?= $h(chL('Unduh cadangan kunci', 'Download key backup')) ?></a><span id="mKeyInfo" class="text-xs"></span></div>
            </section>
            <section class="space-y-3 border-t pt-5">
                <h4 class="text-xs font-semibold uppercase tracking-wider text-slate-500"><?= $h(chL('Pengaturan & penyimpanan', 'Settings & storage')) ?></h4>
                <div id="mStats" class="grid grid-cols-2 sm:grid-cols-4 gap-2"></div>
                <div class="flex flex-wrap items-center gap-2"><label for="mRet" class="text-slate-600"><?= $h(chL('Simpan foto selama', 'Keep photos for')) ?></label><select id="mRet" class="border rounded-lg px-2 py-1.5"><?php foreach ([30, 60, 90, 180, 365] as $d): ?><option value="<?= $d ?>"><?= $d ?></option><?php endforeach; ?></select><span class="text-slate-600"><?= $h(chL('hari', 'days')) ?></span></div>
                <div class="flex flex-wrap items-center gap-2"><label for="mCctv" class="text-slate-600"><?= $h(chL('Kirim temuan checklist CCTV ke grup', 'Send CCTV checklist findings to')) ?></label><select id="mCctv" class="border rounded-lg px-2 py-1.5"></select></div>
                <p class="text-xs text-slate-500"><?= $h(chL('Foto dikecilkan di HP/PC sebelum dikirim (maks. 1600 px). Foto yang lebih lama dari batas di atas dihapus otomatis sekali sehari; teks pesannya tetap ada.', 'Photos are resized before sending (max 1600 px). Photos older than the limit above are deleted once a day; the text stays.')) ?></p>
                <div class="flex justify-end"><button type="button" id="mSetSave" class="border border-slate-300 hover:bg-slate-50 rounded-lg px-4 py-2 font-semibold"><?= $h(chL('Simpan pengaturan', 'Save settings')) ?></button></div>
            </section>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
(function () {
    'use strict';
    var ME = <?= (int)$me['id'] ?>, ADMIN = <?= $admin ? 'true' : 'false' ?>, CSRF = <?= json_encode(csrfToken()) ?>;
    var START_G = <?= (int)($_GET['g'] ?? 0) ?>, START_M = <?= (int)($_GET['m'] ?? 0) ?>, RETENTION = <?= (int)$set['retention'] ?>;
    var T = <?= json_encode([
        'you' => chL('Anda', 'You'), 'today' => chL('Hari ini', 'Today'), 'noMsg' => chL('Belum ada pesan. Mulai percakapan di grup ini.', 'No messages yet.'),
        'noGroup' => chL('Anda belum masuk grup mana pun. Admin dapat menambahkan Anda ke grup.', 'You are not in any group yet.'),
        'deleted' => chL('Pesan ini dihapus', 'This message was deleted'), 'deletedAdmin' => chL('Pesan ini dihapus oleh admin', 'Deleted by an admin'),
        'purged' => chL('Foto sudah dihapus (lebih dari %d hari)', 'Photo removed (older than %d days)'), 'members' => chL('anggota', 'members'),
        'allUsers' => chL('Semua user terdaftar', 'All registered users'), 'announce' => chL('PENGUMUMAN', 'ANNOUNCEMENT'), 'pinned' => chL('Disematkan:', 'Pinned:'),
        'unpin' => chL('Lepas', 'Unpin'), 'reply' => chL('Balas', 'Reply'), 'pin' => chL('Sematkan di atas', 'Pin to top'), 'unpinMsg' => chL('Lepas sematan', 'Unpin'),
        'del' => chL('Hapus', 'Delete'), 'delHint' => chL('Bisa dalam 1 jam setelah dikirim', 'Within 1 hour of sending'), 'delLate' => chL('Lewat 1 jam, minta admin', 'Over 1 hour: ask an admin'),
        'asAdmin' => chL('Sebagai admin', 'As admin'), 'delAgain' => chL('Pilih Hapus sekali lagi dalam 4 detik untuk menghapus.', 'Choose Delete again within 4 seconds.'),
        'readYes' => chL('Sudah dibaca', 'Read by'), 'readNo' => chL('Belum dibaca', 'Not read yet'), 'none' => chL('Belum ada', 'Nobody yet'), 'allRead' => chL('Semua sudah membaca', 'Everyone has read it'),
        'replying' => chL('Membalas', 'Replying to'), 'cancel' => chL('Batal', 'Cancel'), 'mention' => chL('Sebut nama', 'Mention'),
        'camera' => chL('Buka kamera', 'Open camera'), 'cameraSub' => chL('Potret langsung dari HP', 'Take a photo'), 'gallery' => chL('Pilih dari galeri / file', 'Choose from gallery / files'),
        'gallerySub' => chL('Foto yang sudah ada atau screenshot', 'An existing photo or screenshot'), 'share' => chL('Bagikan tiket / aset', 'Share a ticket / asset'), 'shareSub' => chL('Kirim kartu yang bisa diklik', 'Send a clickable card'),
        'photoReady' => chL('Foto siap dikirim.', 'Photo ready.'), 'photoHint' => chL('Tambahkan keterangan bila perlu, lalu tekan kirim.', 'Add a caption if needed, then send.'),
        'notImage' => chL('File ini bukan gambar yang bisa dibaca. Pilih foto JPG atau PNG.', 'Not a readable image. Choose a JPG or PNG.'),
        'failed' => chL('Gagal', 'Failed'), 'openTicket' => chL('Buka tiket →', 'Open ticket →'), 'openAsset' => chL('Buka detail aset →', 'Open asset →'), 'openReport' => chL('Buka laporan petugas →', 'Open officer reports →'),
        'shareEmpty' => chL('Tidak ada yang cocok.', 'No matches.'), 'newGroup' => chL('+ Grup baru', '+ New group'), 'saved' => chL('Tersimpan.', 'Saved.'),
        'delGroupAgain' => chL('Klik lagi untuk menghapus grup ini beserta semua pesannya', 'Click again to delete this group and all messages'), 'noneOpt' => chL('— tidak dikirim —', '— off —'),
        'keyNever' => chL('Belum pernah dicadangkan.', 'Never backed up.'), 'keyAt' => chL('Terakhir dicadangkan', 'Last backed up'),
        'statMsg' => chL('Pesan', 'Messages'), 'statPhoto' => chL('Foto tersimpan', 'Stored photos'), 'statAvg' => chL('Rata-rata per foto', 'Avg per photo'), 'statText' => chL('Teks', 'Text'),
        'typing' => chL('Mengirim…', 'Sending…'),
    ], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
    var app = document.getElementById('chatApp'), $ = function (id) { return document.getElementById(id); };
    var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]; }); };
    var pad = function (n) { return ('0' + n).slice(-2); };
    var dt = function (s) { return new Date(String(s).replace(' ', 'T')); };
    var hm = function (s) { var d = dt(s); return pad(d.getHours()) + '.' + pad(d.getMinutes()); };
    var kb = function (n) { return n >= 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; };
    var first = function (n) { return String(n || '').trim().split(/\s+/)[0]; };

    var lastSig = '', groups = [], cur = 0, G = null, msgs = [], byId = {}, reads = {}, replyTo = 0, pend = null, share = null, busy = false, timer = null;
    window.CHAT_CUR = 0;

    // ---- Ukuran: isi tinggi layar di bawah judul halaman (dan di atas menu bawah HP) ----
    function fitHeight() {
        var top = app.getBoundingClientRect().top + (document.querySelector('main') ? document.querySelector('main').scrollTop : 0);
        var bn = document.getElementById('bottomNav'), bh = bn && getComputedStyle(bn).display !== 'none' ? bn.offsetHeight : 0;
        app.style.height = Math.max(420, window.innerHeight - top - bh - 12) + 'px';
    }
    window.addEventListener('resize', fitHeight);

    function api(params, body) {
        var url = 'chat_api.php?' + new URLSearchParams(params).toString();
        var opt = body ? {method: 'POST', body: body, credentials: 'same-origin'} : {credentials: 'same-origin'};
        return fetch(url, opt).then(function (r) { return r.text(); }).then(function (t) { try { return JSON.parse(t); } catch (e) { return {ok: false, error: t.slice(0, 200) || 'error'}; } });
    }
    function post(a, data) {
        var fd = data instanceof FormData ? data : new FormData();
        if (!(data instanceof FormData)) Object.keys(data || {}).forEach(function (k) { fd.append(k, data[k]); });
        fd.append('a', a); fd.append('csrf_token', CSRF);
        return api({a: a}, fd);
    }
    function toast(msg, bad) { if (window.chatToast) window.chatToast(msg, bad); else alert(msg); }

    // ---- Daftar grup ----
    function renderGroups() {
        var total = 0;
        $('glist').innerHTML = groups.map(function (g) {
            var open = g.id === cur && app.classList.contains('in-room'), un = open ? 0 : g.unread; total += un;
            return '<button type="button" class="gitem' + (g.id === cur ? ' on' : '') + '" data-g="' + g.id + '"><span class="av" style="background:' + g.color + '">' + esc(g.name.charAt(0).toUpperCase()) + '</span>'
                + '<b>' + esc(g.name) + (g.announce ? '<span class="tag">' + esc(T.announce) + '</span>' : '') + '</b><span class="t">' + (g.last_at ? hm(g.last_at) : '') + '</span>'
                + '<span class="last">' + esc(g.last || '') + '</span><span class="badges">' + (!open && g.mention && un ? '<span class="at">@</span>' : '') + (un ? '<span class="unread">' + un + '</span>' : '') + '</span></button>';
        }).join('') || '<p class="p-4 text-sm text-slate-500">' + esc(T.noGroup) + '</p>';
        [].forEach.call($('glist').querySelectorAll('[data-g]'), function (b) { b.onclick = function () { openGroup(+b.dataset.g); }; });
        if (window.chatSetBadge) window.chatSetBadge(total);
    }
    function openGroup(gid, flashId) {
        if (gid !== cur || !G) { cur = gid; G = null; msgs = []; byId = {}; reads = {}; replyTo = 0; lastSig = ''; clearPend(); $('msgs').innerHTML = ''; $('msgs').dataset.end = ''; }
        window.CHAT_CUR = gid;
        app.classList.add('in-room');
        try { history.replaceState(null, '', 'chat.php?g=' + gid); } catch (e) {}
        poll(true).then(function () { if (flashId) flash(flashId); else if (!$('compose').classList.contains('hidden') && window.matchMedia('(min-width: 768px)').matches) $('txt').focus(); });
    }
    $('btnBack').onclick = function () { app.classList.remove('in-room'); window.CHAT_CUR = 0; renderGroups(); };

    // ---- Ambil pesan baru (tiap 3 detik saat halaman terlihat) ----
    function poll(force) {
        if (busy && !force) return Promise.resolve();
        busy = true;
        var last = msgs.length ? msgs[msgs.length - 1].id : 0, firstId = msgs.length ? msgs[0].id : 0;
        var seen = document.visibilityState === 'visible' && app.classList.contains('in-room') ? '1' : '0';
        return api({a: 'poll', g: cur || 0, after: last, from: firstId, seen: seen}).then(function (d) {
            busy = false;
            if (!d.ok) return;
            groups = d.groups || [];
            if (!cur && groups.length && window.matchMedia('(min-width: 768px)').matches) { cur = groups[0].id; return openGroup(cur); }
            if (d.group) {
                var wasEmpty = !msgs.length;
                G = d.group; reads = d.reads || {};
                var added = (d.messages || []).filter(function (m) { return !byId[m.id]; });
                added.forEach(function (m) { byId[m.id] = m; msgs.push(m); });
                (d.deleted || []).forEach(function (id) { var m = byId[id]; if (m && !m.deleted) { m.deleted = m.u === ME ? 'self' : 'admin'; m.text = ''; m.card = null; m.photo = ''; } });
                // Gambar ulang hanya kalau ada yang berubah (pesan baru/dihapus, dibaca, sematan, anggota).
                var sig = JSON.stringify([G, reads, msgs.map(function (m) { return m.id + (m.deleted ? 'd' : ''); })]);
                if (sig !== lastSig || force) { lastSig = sig; renderRoom(wasEmpty ? 'bottom' : (added.some(function (m) { return m.u === ME; }) ? 'bottom' : 'auto')); }
            } else if (cur && !groups.some(function (g) { return g.id === cur; })) { cur = 0; app.classList.remove('in-room'); }
            renderGroups();
        }).catch(function () { busy = false; });
    }
    function schedule() { clearTimeout(timer); timer = setTimeout(function () { poll().then(schedule); }, document.visibilityState === 'visible' ? 3000 : 15000); }
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') poll(true); });

    // ---- Ruang chat ----
    function fmt(text) {
        var names = (G ? G.members : []).map(function (m) { return first(m.name).toLowerCase(); });
        return esc(text).replace(/@([\p{L}\p{N}_]+)/gu, function (all, n) { return names.indexOf(n.toLowerCase()) >= 0 ? '<span class="mention">' + all + '</span>' : all; }).replace(/\n/g, '<br>');
    }
    // mode: 'bottom' = gulir ke pesan terbaru, 'auto' = ikut ke bawah hanya kalau sedang di bawah, 'keep' = tetap
    function renderRoom(mode) {
        if (!G) return;
        $('rAv').style.background = G.color; $('rAv').textContent = G.name.charAt(0).toUpperCase();
        $('rName').innerHTML = esc(G.name) + (G.announce ? '<span class="tag" style="font-size:10px;font-weight:700;color:#b45309;background:#fef3c7;border-radius:4px;padding:0 4px;margin-left:6px">' + esc(T.announce) + '</span>' : '');
        $('rSub').textContent = (G.all ? T.allUsers + ' · ' : '') + G.members.length + ' ' + T.members + ': ' + G.members.map(function (m) { return m.id === ME ? T.you : first(m.name); }).join(', ');
        var pb = $('pinbar');
        pb.classList.toggle('hidden', !G.pinned);
        if (G.pinned) {
            pb.innerHTML = '<span aria-hidden="true">📌</span><button type="button" class="flex-1 min-w-0 text-left truncate" id="pinGo"><b>' + esc(T.pinned) + '</b> ' + esc(G.pinned.text) + '</button>' + (ADMIN ? '<button type="button" id="pinOff" class="border border-amber-300 rounded-lg px-2 py-0.5 text-xs">' + esc(T.unpin) + '</button>' : '');
            $('pinGo').onclick = function () { flash(G.pinned.id); };
            if ($('pinOff')) $('pinOff').onclick = function () { post('pin', {g: cur, id: 0}).then(function () { poll(true); }); };
        }
        $('compose').classList.toggle('hidden', !G.can_write); $('readonly').classList.toggle('hidden', !!G.can_write);
        var box = $('msgs'), nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 120, keep = box.scrollTop;
        var others = G.members.filter(function (m) { return m.id !== ME; }).map(function (m) { return m.id; });
        var lastDay = '', html = '';
        msgs.forEach(function (m) {
            var d = dt(m.at), day = d.toDateString();
            if (day !== lastDay) { lastDay = day; html += '<div class="day">' + (new Date().toDateString() === day ? T.today : pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear()) + '</div>'; }
            if (m.kind === 'sys') { html += '<div class="sys">' + esc(m.text || '') + '</div>'; return; }
            var mine = m.u === ME, body = '';
            if (m.deleted) body = '<div class="del">🚫 ' + esc(m.deleted === 'self' ? T.deleted : T.deletedAdmin) + '</div>';
            else {
                if (m.reply) body += '<div class="quote" data-jump="' + m.reply + '"><b>' + esc(m.rq ? m.rq.name : '') + '</b>' + esc(m.rq ? m.rq.text : '') + '</div>';
                if (m.card) {
                    var c = m.card, cc = c.type === 'temuan' ? ['#fef3c7', '#b45309', 'CCTV', T.openReport] : c.type === 'tiket' ? ['#dbe7fe', '#1f3dd1', 'TIKET', T.openTicket] : ['#dcfce7', '#15803d', 'ASET', T.openAsset];
                    body += '<a href="' + esc(c.url || '#') + '" class="card"><span class="ci" style="background:' + cc[0] + ';color:' + cc[1] + '">' + cc[2] + '</span><span class="min-w-0"><b>' + esc(c.title) + '</b><small>' + esc(c.ref) + (c.sub ? ' · ' + esc(c.sub) : '') + '</small><span class="open">' + esc(cc[3]) + '</span></span></a>';
                }
                if (m.photo) body += '<img class="ph" src="' + esc(m.photo) + '" alt="" loading="lazy">';
                else if (m.purged) body += '<div class="text-xs text-slate-500">📷 ' + esc(T.purged.replace('%d', RETENTION)) + '</div>';
                if (m.text) body += '<div>' + fmt(m.text) + '</div>';
            }
            var tick = '';
            if (mine && !m.deleted) {
                var who = others.filter(function (id) { return (reads[id] || 0) >= m.id; }).length;
                tick = '<button type="button" class="readbtn' + (who >= others.length && others.length ? ' all' : '') + '" data-read="' + m.id + '">✓✓ ' + who + '/' + others.length + '</button>';
            }
            html += '<div class="m' + (mine ? ' me' : '') + '" data-id="' + m.id + '">'
                + (m.deleted ? '' : '<button type="button" class="more" data-more="' + m.id + '" aria-label="⋯">⋯</button>')
                + (mine ? '' : '<div class="from" style="color:' + m.color + '">' + esc(m.name) + (m.dept ? ' <span style="font-weight:400;color:#64748b">· ' + esc(m.dept) + '</span>' : '') + '</div>')
                + body + '<div class="foot">' + (m.photo && m.orig > m.size ? '<span>' + kb(m.orig) + ' → ' + kb(m.size) + '</span>' : '') + '<span>' + hm(m.at) + '</span>' + tick + '</div></div>';
        });
        box.innerHTML = html || '<p class="sys">' + esc(T.noMsg) + '</p>';
        var toBottom = mode === 'bottom' || (mode === 'auto' && nearBottom);
        box.scrollTop = toBottom ? box.scrollHeight : keep;
        [].forEach.call(box.querySelectorAll('img.ph'), function (im) { im.onclick = function () { $('lbImg').src = im.src; $('lightbox').classList.remove('hidden'); }; im.onload = function () { if (toBottom) box.scrollTop = box.scrollHeight; }; });
        [].forEach.call(box.querySelectorAll('[data-more]'), function (b) { b.onclick = function (e) { e.stopPropagation(); msgMenu(b); }; });
        [].forEach.call(box.querySelectorAll('[data-read]'), function (b) { b.onclick = function (e) { e.stopPropagation(); readMenu(b); }; });
        [].forEach.call(box.querySelectorAll('[data-jump]'), function (q) { q.onclick = function () { flash(+q.dataset.jump); }; });
        renderReply();
    }
    function flash(id) {
        var el = document.querySelector('#msgs .m[data-id="' + id + '"]'); if (!el) return;
        el.scrollIntoView({block: 'center', behavior: 'smooth'}); el.classList.add('flash'); setTimeout(function () { el.classList.remove('flash'); }, 1800);
    }
    // Muat pesan lebih lama saat digulir ke atas
    $('msgs').addEventListener('scroll', function () {
        var box = this;
        if (box.scrollTop > 40 || !msgs.length || box.dataset.loading === '1' || box.dataset.end === String(cur)) return;
        box.dataset.loading = '1';
        var h0 = box.scrollHeight;
        api({a: 'older', g: cur, before: msgs[0].id}).then(function (d) {
            box.dataset.loading = '';
            if (!d.ok || !d.messages || !d.messages.length) { box.dataset.end = String(cur); return; }
            d.messages.forEach(function (m) { byId[m.id] = m; });
            msgs = d.messages.concat(msgs);
            renderRoom('keep'); box.scrollTop = box.scrollHeight - h0;
        });
    });

    // ---- Menu pesan: Balas, Sematkan, Hapus; Dibaca oleh ----
    var menu = $('chatMenu');
    function place(anchor) {
        menu.classList.remove('hidden');
        var r = anchor.getBoundingClientRect(), mw = menu.offsetWidth, mh = menu.offsetHeight;
        menu.style.left = Math.max(8, Math.min(window.innerWidth - mw - 8, r.right - mw)) + 'px';
        menu.style.top = (r.bottom + mh + 8 > window.innerHeight ? Math.max(8, r.top - mh - 4) : r.bottom + 4) + 'px';
    }
    function closeMenu() { menu.classList.add('hidden'); $('btnAttach').setAttribute('aria-expanded', 'false'); }
    document.addEventListener('click', function (e) { if (!e.target.closest('#chatMenu') && !e.target.closest('#btnAttach')) closeMenu(); });
    var ICO = {
        reply: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg>',
        pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 17v5"/><path d="M5 17h14l-2-5V5H7v7z"/></svg>',
        del: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M6 6l1 14h10l1-14"/></svg>',
        cam: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>',
        gal: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>',
        link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg>'
    };
    var delArm = {id: 0, t: 0};
    function msgMenu(btn) {
        var m = byId[+btn.dataset.more]; if (!m) return;
        var mine = m.u === ME, age = Date.now() - dt(m.at).getTime(), canDel = ADMIN || (mine && age < 3600e3);
        var html = (G.can_write ? '<button type="button" data-a="reply">' + ICO.reply + esc(T.reply) + '</button>' : '')
            + (ADMIN ? '<button type="button" data-a="pin">' + ICO.pin + esc(G.pinned && G.pinned.id === m.id ? T.unpinMsg : T.pin) + '</button>' : '')
            + (mine || ADMIN ? '<button type="button" data-a="del" class="red"' + (canDel ? '' : ' disabled') + '>' + ICO.del + '<span>' + esc(T.del) + (mine && !ADMIN ? '<small>' + esc(canDel ? T.delHint : T.delLate) + '</small>' : (!mine ? '<small>' + esc(T.asAdmin) + '</small>' : '')) + '</span></button>' : '');
        if (!html) return;
        menu.innerHTML = html; place(btn);
        [].forEach.call(menu.querySelectorAll('[data-a]'), function (b) {
            b.onclick = function () {
                closeMenu();
                if (b.dataset.a === 'reply') { replyTo = m.id; renderReply(); $('txt').focus(); }
                if (b.dataset.a === 'pin') post('pin', {g: cur, id: G.pinned && G.pinned.id === m.id ? 0 : m.id}).then(function () { poll(true); });
                if (b.dataset.a === 'del') {
                    if (delArm.id !== m.id || Date.now() - delArm.t > 4000) { delArm = {id: m.id, t: Date.now()}; toast(T.delAgain); return; }
                    delArm = {id: 0, t: 0};
                    post('delete', {id: m.id}).then(function (d) { if (!d.ok) { toast(d.error || T.failed, true); return; } m.deleted = mine ? 'self' : 'admin'; m.text = ''; m.card = null; m.photo = ''; renderRoom('keep'); poll(true); });
                }
            };
        });
    }
    function readMenu(btn) {
        var m = byId[+btn.dataset.read]; if (!m) return;
        var others = G.members.filter(function (x) { return x.id !== ME; });
        var yes = others.filter(function (x) { return (reads[x.id] || 0) >= m.id; }), no = others.filter(function (x) { return (reads[x.id] || 0) < m.id; });
        var row = function (x) { return '<div class="ppl">' + esc(x.name) + '<span>' + esc(x.dept) + '</span></div>'; };
        menu.innerHTML = '<h5>' + esc(T.readYes) + ' (' + yes.length + ')</h5>' + (yes.map(row).join('') || '<div class="ppl"><span>' + esc(T.none) + '</span></div>')
            + '<h5 style="margin-top:8px">' + esc(T.readNo) + ' (' + no.length + ')</h5>' + (no.map(row).join('') || '<div class="ppl"><span>' + esc(T.allRead) + '</span></div>');
        place(btn);
    }
    function renderReply() {
        var m = replyTo && byId[replyTo], rb = $('replybar');
        rb.classList.toggle('hidden', !m);
        if (!m) return;
        var s = m.card ? m.card.title : (m.text || (m.photo ? '📷' : ''));
        rb.innerHTML = '<span class="flex-1 min-w-0 truncate border-l-[3px] border-blue-600 pl-2"><b class="text-blue-700">' + esc(T.replying) + ' ' + esc(m.u === ME ? T.you : m.name) + '</b> · ' + esc(s) + '</span><button type="button" id="replyX" class="border rounded-lg px-2 py-0.5 text-xs">' + esc(T.cancel) + '</button>';
        $('replyX').onclick = function () { replyTo = 0; renderReply(); };
    }

    // ---- Kirim pesan ----
    function fit() { var t = $('txt'); t.style.height = 'auto'; t.style.height = Math.min(128, t.scrollHeight) + 'px'; }
    $('compose').addEventListener('submit', function (e) {
        e.preventDefault(); closeMenu();
        var text = $('txt').value.trim();
        if (!text && !pend && !share) return;
        var fd = new FormData();
        fd.append('g', cur); fd.append('text', text); fd.append('reply', replyTo || 0);
        if (pend) { fd.append('photo', pend.blob, 'foto.jpg'); fd.append('orig', pend.orig); }
        if (share) { fd.append('share_type', share.type); fd.append('share_id', share.id); }
        $('btnSend').disabled = true;
        post('send', fd).then(function (d) {
            $('btnSend').disabled = false;
            if (!d.ok) { toast(d.error || T.failed, true); return; }
            $('txt').value = ''; fit(); replyTo = 0; share = null; clearPend(); poll(true);
        }).catch(function () { $('btnSend').disabled = false; toast(T.failed, true); });
    });
    $('txt').addEventListener('keydown', function (e) {
        if (!menu.classList.contains('hidden') && menu.dataset.kind === 'mention' && (e.key === 'Enter' || e.key === 'Tab')) { var f = menu.querySelector('button'); if (f) { e.preventDefault(); f.click(); return; } }
        if (e.key === 'Enter' && !e.shiftKey && window.matchMedia('(min-width: 768px)').matches) { e.preventDefault(); $('compose').requestSubmit(); }
    });
    // Sebut nama: ketik @ lalu pilih anggota grup
    $('txt').addEventListener('input', function () {
        fit();
        var t = this, before = t.value.slice(0, t.selectionStart), mm = before.match(/@([\p{L}\p{N}_]*)$/u);
        menu.dataset.kind = '';
        if (!mm || !G) { if (!menu.classList.contains('hidden') && menu.querySelector('[data-n]')) closeMenu(); return; }
        var q = mm[1].toLowerCase(), list = G.members.filter(function (x) { return x.id !== ME && first(x.name).toLowerCase().indexOf(q) === 0; }).slice(0, 8);
        if (!list.length) { closeMenu(); return; }
        menu.innerHTML = '<h5>' + esc(T.mention) + '</h5>' + list.map(function (x) { return '<button type="button" data-n="' + esc(first(x.name)) + '"><span>' + esc(x.name) + '<small>' + esc(x.dept) + '</small></span></button>'; }).join('');
        menu.dataset.kind = 'mention'; place(t);
        menu.style.top = Math.max(8, t.getBoundingClientRect().top - menu.offsetHeight - 6) + 'px';
        menu.style.left = t.getBoundingClientRect().left + 'px';
        [].forEach.call(menu.querySelectorAll('[data-n]'), function (b) {
            b.onclick = function () { var pos = t.selectionStart, start = before.length - mm[0].length; t.value = t.value.slice(0, start) + '@' + b.dataset.n + ' ' + t.value.slice(pos); var c = start + b.dataset.n.length + 2; t.setSelectionRange(c, c); closeMenu(); t.focus(); };
        });
    });

    // ---- Lampiran: kamera, galeri, tempel screenshot, bagikan tiket/aset ----
    $('btnAttach').onclick = function (e) {
        e.stopPropagation();
        if (!menu.classList.contains('hidden') && menu.dataset.kind === 'attach') { closeMenu(); return; }
        menu.innerHTML = '<button type="button" data-a="cam">' + ICO.cam + '<span>' + esc(T.camera) + '<small>' + esc(T.cameraSub) + '</small></span></button>'
            + '<button type="button" data-a="gal">' + ICO.gal + '<span>' + esc(T.gallery) + '<small>' + esc(T.gallerySub) + '</small></span></button>'
            + '<button type="button" data-a="share">' + ICO.link + '<span>' + esc(T.share) + '<small>' + esc(T.shareSub) + '</small></span></button>';
        menu.dataset.kind = 'attach'; place(this); this.setAttribute('aria-expanded', 'true');
        var r = this.getBoundingClientRect(); menu.style.left = r.left + 'px'; menu.style.top = Math.max(8, r.top - menu.offsetHeight - 6) + 'px';
        menu.querySelector('[data-a="cam"]').onclick = function () { closeMenu(); $('fileCam').click(); };
        menu.querySelector('[data-a="gal"]').onclick = function () { closeMenu(); $('fileGal').click(); };
        menu.querySelector('[data-a="share"]').onclick = function () { closeMenu(); openShare(); };
    };
    ['fileCam', 'fileGal'].forEach(function (id) { $(id).addEventListener('change', function () { var f = this.files[0]; this.value = ''; if (f) pickPhoto(f); }); });
    document.addEventListener('paste', function (e) {
        if ($('compose').classList.contains('hidden') || !app.classList.contains('in-room')) return;
        var t = e.target; if (t && t !== $('txt') && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
        var f = null; [].forEach.call((e.clipboardData && e.clipboardData.items) || [], function (it) { if (!f && it.kind === 'file' && /^image\//.test(it.type)) f = it.getAsFile(); });
        if (f) { e.preventDefault(); pickPhoto(f); }
    });
    $('msgs').addEventListener('dragover', function (e) { if (e.dataTransfer && [].indexOf.call(e.dataTransfer.types || [], 'Files') >= 0) e.preventDefault(); });
    $('msgs').addEventListener('drop', function (e) { var f = e.dataTransfer && e.dataTransfer.files[0]; if (f && !$('compose').classList.contains('hidden')) { e.preventDefault(); pickPhoto(f); } });
    // Foto dikecilkan di perangkat pengirim: sisi terpanjang maks. 1600 px, JPEG 0,75.
    function pickPhoto(f) {
        var url = URL.createObjectURL(f), im = new Image();
        im.onload = function () {
            var s = Math.min(1, 1600 / Math.max(im.width, im.height)), cv = document.createElement('canvas');
            cv.width = Math.round(im.width * s); cv.height = Math.round(im.height * s);
            cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height); URL.revokeObjectURL(url);
            cv.toBlob(function (b) {
                if (!b) { toast(T.notImage, true); return; }
                clearPend(); share = null;
                pend = {blob: b, orig: f.size, url: URL.createObjectURL(b)};
                var p = $('pending'); p.classList.remove('hidden');
                p.innerHTML = '<img src="' + pend.url + '" alt="" class="w-11 h-11 object-cover rounded-md"><span class="flex-1 min-w-0"><b>' + esc(T.photoReady) + '</b> ' + kb(f.size) + ' → ' + kb(b.size) + ' (' + cv.width + '×' + cv.height + ' px). ' + esc(T.photoHint) + '</span><button type="button" id="pCancel" class="border border-amber-300 rounded-lg px-2 py-0.5 text-xs">' + esc(T.cancel) + '</button>';
                $('pCancel').onclick = clearPend; $('txt').focus();
            }, 'image/jpeg', 0.75);
        };
        im.onerror = function () { URL.revokeObjectURL(url); toast(T.notImage, true); };
        im.src = url;
    }
    function clearPend() { if (pend && pend.url) URL.revokeObjectURL(pend.url); pend = null; if (!share) $('pending').classList.add('hidden'); }

    var sq = null;
    function openShare() {
        $('sharePanel').classList.remove('hidden'); $('shareQ').value = ''; searchShare(); setTimeout(function () { $('shareQ').focus(); }, 50);
    }
    function searchShare() {
        api({a: 'share_search', q: $('shareQ').value.trim()}).then(function (d) {
            var items = d.items || [];
            $('shareList').innerHTML = items.map(function (c, i) {
                var cc = c.type === 'tiket' ? ['#dbe7fe', '#1f3dd1', 'TIKET'] : ['#dcfce7', '#15803d', 'ASET'];
                return '<button type="button" data-i="' + i + '" class="w-full flex gap-3 items-start text-left border rounded-lg p-2.5 hover:border-blue-400"><span class="w-10 h-9 rounded-lg grid place-items-center text-[10px] font-bold shrink-0" style="background:' + cc[0] + ';color:' + cc[1] + '">' + cc[2] + '</span><span class="min-w-0"><b class="block truncate">' + esc(c.title) + '</b><small class="block text-slate-500">' + esc(c.ref) + ' · ' + esc(c.sub) + '</small></span></button>';
            }).join('') || '<p class="text-slate-500">' + esc(T.shareEmpty) + '</p>';
            [].forEach.call($('shareList').querySelectorAll('[data-i]'), function (b) {
                b.onclick = function () {
                    var c = items[+b.dataset.i]; $('sharePanel').classList.add('hidden');
                    clearPend(); share = {type: c.type, id: c.id};
                    var p = $('pending'); p.classList.remove('hidden');
                    p.innerHTML = '<span class="flex-1 min-w-0 truncate">🔗 <b>' + esc(c.ref) + '</b> · ' + esc(c.title) + '</span><button type="button" id="sCancel" class="border border-amber-300 rounded-lg px-2 py-0.5 text-xs">' + esc(T.cancel) + '</button>';
                    $('sCancel').onclick = function () { share = null; p.classList.add('hidden'); };
                    $('txt').focus();
                };
            });
        });
    }
    $('shareQ').addEventListener('input', function () { clearTimeout(sq); sq = setTimeout(searchShare, 250); });

    // ---- Tutup panel ----
    $('lightbox').onclick = function () { this.classList.add('hidden'); };
    [].forEach.call(document.querySelectorAll('[data-close]'), function (b) { b.onclick = function () { b.closest('.fixed').classList.add('hidden'); }; });
    ['sharePanel', 'manage'].forEach(function (id) { var p = $(id); if (p) p.addEventListener('mousedown', function (e) { if (e.target === p) p.classList.add('hidden'); }); });
    document.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape') return;
        closeMenu(); $('lightbox').classList.add('hidden'); $('sharePanel').classList.add('hidden'); if ($('manage')) $('manage').classList.add('hidden');
        if (replyTo) { replyTo = 0; renderReply(); }
    });

    // ---- Kelola grup (admin) ----
    if (ADMIN) {
        var AD = null, mg = 0, gdel = 0;
        var openManage = function () {
            api({a: 'admin'}).then(function (d) {
                if (!d.ok) { toast(d.error || T.failed, true); return; }
                AD = d; mg = mg || cur || (d.groups[0] && d.groups[0].id) || 0; renderManage(); $('manage').classList.remove('hidden');
            });
        };
        $('btnManage').onclick = openManage;
        var renderManage = function () {
            var g = AD.groups.filter(function (x) { return x.id === mg; })[0] || {id: 0, name: '', all: false, announce: false, members: [ME]};
            $('mGroup').innerHTML = AD.groups.map(function (x) { return '<option value="' + x.id + '"' + (x.id === mg ? ' selected' : '') + '>' + esc(x.name) + '</option>'; }).join('') + '<option value="0"' + (mg === 0 ? ' selected' : '') + '>' + esc(T.newGroup) + '</option>';
            $('mName').value = g.name; $('mAnn').checked = g.announce; $('mAllUsers').checked = g.all; $('mDel').classList.toggle('hidden', !g.id);
            var sel = {}; g.members.forEach(function (id) { sel[id] = 1; });
            $('mMembers').innerHTML = AD.users.map(function (u) { return '<label class="flex gap-2 items-center border rounded-lg px-2 py-1.5" data-s="' + esc((u.name + ' ' + u.dept).toLowerCase()) + '"><input type="checkbox" value="' + u.id + '"' + (sel[u.id] ? ' checked' : '') + '><span class="min-w-0"><span class="block truncate">' + esc(u.name) + '</span><small class="block text-xs text-slate-500 truncate">' + esc(u.dept || '-') + (u.admin ? ' · admin' : '') + '</small></span></label>'; }).join('');
            var upd = function () { $('mMemberWrap').classList.toggle('opacity-50', $('mAllUsers').checked); [].forEach.call($('mMembers').querySelectorAll('input'), function (c) { c.disabled = $('mAllUsers').checked; }); $('mCount').textContent = '(' + ($('mAllUsers').checked ? AD.users.length : $('mMembers').querySelectorAll('input:checked').length) + '/' + AD.users.length + ')'; };
            $('mAllUsers').onchange = upd; $('mMembers').onchange = upd; upd();
            var s = AD.settings, st = AD.stats;
            $('mRet').value = String(s.retention);
            $('mCctv').innerHTML = '<option value="0">' + esc(T.noneOpt) + '</option>' + AD.groups.map(function (x) { return '<option value="' + x.id + '"' + (x.id === +s.cctv_group ? ' selected' : '') + '>' + esc(x.name) + '</option>'; }).join('');
            $('mKeyInfo').innerHTML = s.key_backup_at ? '<span class="text-green-700 font-semibold">✓ ' + esc(T.keyAt) + ' ' + esc(s.key_backup_at.slice(0, 16)) + '</span>' : '<span class="text-red-700 font-semibold">' + esc(T.keyNever) + '</span>';
            $('mStats').innerHTML = [[T.statMsg, st.messages.toLocaleString('id-ID')], [T.statPhoto, st.photos.toLocaleString('id-ID') + ' · ' + kb(st.photo_bytes)], [T.statAvg, st.photos ? kb(st.photo_bytes / st.photos) : '-'], [T.statText, kb(st.text_bytes)]].map(function (x) { return '<div class="border rounded-lg p-2.5"><span class="block text-xs text-slate-500">' + esc(x[0]) + '</span><b class="block text-base tabular-nums">' + esc(x[1]) + '</b></div>'; }).join('');
        };
        $('mGroup').onchange = function () { mg = +this.value; gdel = 0; renderManage(); };
        $('mFind').oninput = function () { var q = this.value.trim().toLowerCase(); [].forEach.call($('mMembers').children, function (l) { l.classList.toggle('hidden', q && l.dataset.s.indexOf(q) < 0); }); };
        $('mAll').onclick = function () { [].forEach.call($('mMembers').querySelectorAll('label:not(.hidden) input'), function (c) { c.checked = true; }); $('mMembers').onchange(); };
        $('mNone').onclick = function () { [].forEach.call($('mMembers').querySelectorAll('input'), function (c) { c.checked = +c.value === ME; }); $('mMembers').onchange(); };
        $('mSave').onclick = function () {
            var fd = new FormData();
            fd.append('id', mg); fd.append('name', $('mName').value.trim());
            if ($('mAllUsers').checked) fd.append('is_all', '1'); if ($('mAnn').checked) fd.append('is_announce', '1');
            [].forEach.call($('mMembers').querySelectorAll('input:checked'), function (c) { fd.append('members[]', c.value); });
            post('save_group', fd).then(function (d) { if (!d.ok) { toast(d.error || T.failed, true); return; } mg = d.id; toast(T.saved); openManage(); poll(true); });
        };
        $('mDel').onclick = function () {
            if (Date.now() - gdel > 4000) { gdel = Date.now(); toast(T.delGroupAgain); return; }
            post('delete_group', {id: mg}).then(function (d) { if (!d.ok) { toast(d.error || T.failed, true); return; } if (mg === cur) { cur = 0; app.classList.remove('in-room'); } mg = 0; gdel = 0; openManage(); poll(true); });
        };
        $('mSetSave').onclick = function () { post('settings', {retention: $('mRet').value, cctv_group: $('mCctv').value}).then(function (d) { if (d.ok) { RETENTION = +$('mRet').value; toast(T.saved); } else toast(d.error || T.failed, true); }); };
        $('mKey').addEventListener('click', function () { setTimeout(openManage, 1500); });
    }

    // ---- Mulai ----
    fitHeight();
    if (START_G) { cur = START_G; openGroup(START_G, START_M); } else poll(true);
    schedule();
    setTimeout(fitHeight, 300);
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
