<?php
/**
 * Menu CCTV > Monitoring (khusus admin): status semua kamera dari pengecekan otomatis (cctv_check.php).
 * Kamera = aset kategori CCTV. Pemetaan NVR/channel & notifikasi diatur di cctv_settings.php.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv.php';
require_once __DIR__ . '/includes/cctv_rtsp.php';

$db = getDB();
ensureCctvTables($db);
$h = fn($v) => htmlspecialchars((string)$v);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'check_now') {
    csrfCheck();
    set_time_limit(240);
    try {
        $sum = runCctvCheck($db);
        $text = cL('Pengecekan selesai: ', 'Check finished: ') . cctvSettings()['last_run_info'];
        if ($sum['down']) $text .= ' · ' . count($sum['down']) . cL(' kamera baru terdeteksi mati', ' camera(s) newly down');
        if ($sum['email'] !== '') $text .= ' · ' . cL('Email gagal: ', 'Email failed: ') . $sum['email'];
        $_SESSION['cctv_msg'] = ['ok' => $sum['email'] === '', 'text' => $text];
    } catch (Throwable $e) {
        $_SESSION['cctv_msg'] = ['ok' => false, 'text' => cL('Pengecekan gagal: ', 'Check failed: ') . $e->getMessage()];
    }
    header('Location: cctv.php');
    exit;
}
$msg = $_SESSION['cctv_msg'] ?? null;
unset($_SESSION['cctv_msg']);

$set   = cctvSettings();
$cams  = cctvCameras($db);
$nvrs  = cctvNvrList($db);
$fNvr  = (int)($_GET['nvr'] ?? 0);
$fSt   = (string)($_GET['st'] ?? '');
$q     = trim((string)($_GET['q'] ?? ''));

$count = ['on' => 0, 'bad' => 0, 'unknown' => 0];
foreach ($cams as $c) {
    $method = cctvCheckMethod($c);
    if ($method === '' || $c['state'] === 'unknown') $count['unknown']++;
    elseif ($c['state'] === 'on') $count['on']++;
    else $count['bad']++;
}
$openReports = cctvOpenReports($db);
$nvrOn = count(array_filter($nvrs, fn($n) => (int)$n['is_active'] === 1 && $n['last_state'] === 'on'));
$nvrActive = count(array_filter($nvrs, fn($n) => (int)$n['is_active'] === 1));

$shown = array_values(array_filter($cams, function ($c) use ($fNvr, $fSt, $q) {
    if ($fNvr && (int)$c['nvr_id'] !== $fNvr) return false;
    if ($fSt === 'bad' && !in_array($c['state'], ['off', 'vl'], true)) return false;
    if ($fSt !== '' && $fSt !== 'bad' && $c['state'] !== $fSt) return false;
    if ($q !== '' && stripos($c['number'] . ' ' . $c['name'] . ' ' . $c['location'] . ' ' . $c['ip'], $q) === false) return false;
    return true;
}));
// Yang bermasalah tampil paling depan.
usort($shown, fn($a, $b) => (in_array($b['state'], ['off', 'vl'], true) <=> in_array($a['state'], ['off', 'vl'], true)) ?: strcmp($a['number'], $b['number']));

$lastRun = $set['last_run'] !== '' ? strtotime($set['last_run']) : 0;
$stale   = !$lastRun || (time() - $lastRun) > max(10, $set['interval_min'] * 5) * 60;
$fmtDt   = fn($d) => $d ? date('d M Y H:i', strtotime((string)$d)) : '-';

// Realtime: halaman mengecek tanda perubahan tiap 10 detik dan memuat ulang bagian status bila berubah.
if (($_GET['ajax'] ?? '') === 'sig') {
    header('Content-Type: application/json');
    header('Cache-Control: no-store');
    $sig = $set['last_run'] . '|' . md5(json_encode(array_map(fn($c) => [$c['id'], $c['state'], $c['since']], $cams))) . '|' . array_sum(array_map('count', $openReports));
    echo json_encode(['sig' => md5($sig)]);
    exit;
}
// Email untuk kamera yang sedang mati: sudah terkirim (jam) / akan dikirim (jam).
$emailDelay = (int)$set['email_after_min'];
$mailInfo = [];
if ($set['notify_email'] && cctvTableExists($db, 'cctv_email_log')) {
    foreach ($db->query("SELECT e.asset_id, e.started_at, m.sent_at FROM cctv_events e LEFT JOIN cctv_email_log m ON m.event_id = e.id WHERE e.ended_at IS NULL")->fetchAll() as $r) {
        $mailInfo[(int)$r['asset_id']] = ['sent' => $r['sent_at'], 'due' => date('Y-m-d H:i:s', strtotime((string)$r['started_at']) + $emailDelay * 60)];
    }
}
$downFor = function (?string $since): string {
    if (!$since) return '';
    $m = max(0, (int)floor((time() - strtotime($since)) / 60));
    return $m < 60 ? $m . cL(' menit', ' min') : floor($m / 60) . cL(' jam ', ' h ') . ($m % 60) . cL(' menit', ' min');
};

$pageTitle = 'CCTV';
$cctvTab = 'monitor';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="flex flex-wrap items-center justify-between gap-3 mb-3">
    <div>
        <h1 class="text-xl font-semibold text-slate-800">CCTV</h1>
        <p class="text-sm text-slate-500"><?= $h(cL('Status kamera dari pengecekan otomatis ke NVR / IP kamera.', 'Camera status from automatic NVR / IP checks.')) ?></p>
    </div>
    <form method="post" class="flex items-center gap-3">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="check_now">
        <span class="text-xs text-slate-500 text-right"><?= $h(cL('Cek terakhir', 'Last check')) ?>:<br><b id="cctvLastRun" class="text-slate-700 tabular-nums"><?= $lastRun ? $h(date('d M Y H:i:s', $lastRun)) : '-' ?></b>
            <br><span class="inline-flex items-center gap-1 text-green-700"><span class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> Live</span></span>
        <button type="submit" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= icon('refresh') ?> <?= $h(cL('Cek sekarang', 'Check now')) ?></button>
    </form>
</div>

<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<?php if (!$cams): ?>
    <div class="bg-white rounded-xl shadow-sm p-6 text-sm text-slate-600 space-y-2">
        <p class="font-semibold text-slate-800"><?= $h(cL('Belum ada aset CCTV.', 'No CCTV assets yet.')) ?></p>
        <p><?= $h(cL('Tambahkan kamera di menu Asset dengan kategori yang mengandung kata "CCTV" (mis. kategori "CCTV"), isi IP Address dan Lokasinya. Setelah itu atur NVR & channel di tab Pengaturan.', 'Add cameras in the Asset menu with a category containing "CCTV", fill in IP Address and Location, then map NVR & channel in Settings.')) ?></p>
        <a href="categories.php" class="inline-block text-blue-600 hover:underline"><?= $h(cL('Buka Kategori Aset', 'Open Asset Categories')) ?> &rarr;</a>
    </div>
<?php else: ?>

<?php $nOpenRep = array_sum(array_map('count', $openReports)); if ($nOpenRep): ?>
    <a href="cctv_lapor.php" class="mb-4 flex items-center gap-2 text-sm rounded-lg px-4 py-3 bg-amber-50 border border-amber-200 text-amber-800 hover:bg-amber-100/60">
        <?= icon('alert') ?> <b><?= $nOpenRep ?> <?= $h(cL('laporan petugas belum ditangani', 'open officer report(s)')) ?></b> &rarr;
    </a>
<?php endif; ?>
<?php if ($stale): ?>
    <div class="mb-4 text-sm rounded-lg px-4 py-3 bg-amber-50 border border-amber-200 text-amber-800">
        <b><?= $h(cL('Pengecekan otomatis belum berjalan.', 'Automatic check is not running.')) ?></b>
        <?= $h(cL('Status di bawah tidak diperbarui otomatis sampai Task Scheduler dipasang (lihat tab Pengaturan > Jadwal pengecekan). Tombol "Cek sekarang" tetap bisa dipakai.', 'Status below is not refreshed until Task Scheduler is set up (see Settings > Check schedule). "Check now" still works.')) ?>
    </div>
<?php endif; ?>

<div id="cctvLiveStats" class="grid grid-cols-2 xl:grid-cols-4 gap-3 mb-4">
    <?php foreach ([
        [cL('Total kamera', 'Total cameras'), count($cams), 'camera', 'bg-blue-50 text-blue-700', ''],
        [cL('Online', 'Online'), $count['on'], 'check-circle', 'bg-green-50 text-green-700', 'on'],
        [cL('Bermasalah', 'Problem'), $count['bad'], 'alert', 'bg-red-50 text-red-700', 'bad'],
        [cL('NVR online', 'NVR online'), $nvrActive ? $nvrOn . '/' . $nvrActive : '-', 'monitor', 'bg-slate-100 text-slate-600', null],
    ] as [$label, $val, $ic, $tone, $st]): ?>
        <?php $tag = $st === null ? 'div' : 'a'; ?>
        <<?= $tag ?> <?= $st !== null ? 'href="cctv.php' . ($st !== '' ? '?st=' . $st : '') . '"' : '' ?> class="bg-white rounded-xl shadow-sm p-4 flex items-start gap-3 border-2 <?= $st !== null && $fSt === $st ? 'border-blue-400' : ($st === 'bad' && $val ? 'border-red-300' : 'border-transparent') ?>">
            <span class="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 <?= $tone ?>"><?= icon($ic, 'w-5 h-5') ?></span>
            <div><p class="text-xs text-slate-500"><?= $h($label) ?></p><p class="text-2xl font-semibold leading-tight tabular-nums <?= $st === 'bad' && $val ? 'text-red-600' : 'text-slate-800' ?>"><?= $h($val) ?></p></div>
        </<?= $tag ?>>
    <?php endforeach; ?>
</div>

<form method="get" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">NVR</span>
        <select name="nvr" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[140px]">
            <option value="0"><?= $h(cL('Semua', 'All')) ?></option>
            <?php foreach ($nvrs as $n): ?><option value="<?= (int)$n['id'] ?>" <?= $fNvr === (int)$n['id'] ? 'selected' : '' ?>><?= $h($n['name']) ?></option><?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">Status</span>
        <select name="st" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[150px]">
            <option value=""><?= $h(cL('Semua', 'All')) ?></option>
            <option value="bad" <?= $fSt === 'bad' ? 'selected' : '' ?>><?= $h(cL('Bermasalah', 'Problem')) ?></option>
            <?php foreach (CCTV_STATES as $s): ?><option value="<?= $s ?>" <?= $fSt === $s ? 'selected' : '' ?>><?= $h(cctvStateLabel($s)) ?></option><?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1 flex-1 min-w-[180px]"><span class="text-xs text-slate-500"><?= $h(cL('Cari', 'Search')) ?></span>
        <input type="search" name="q" value="<?= $h($q) ?>" placeholder="<?= $h(cL('No aset, nama, lokasi, IP', 'Asset no, name, location, IP')) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= $h(cL('Terapkan', 'Apply')) ?></button>
    <a href="cctv.php" class="text-slate-500 hover:text-slate-700 px-2 py-1.5"><?= $h(cL('Reset', 'Reset')) ?></a>
    <label class="flex flex-col gap-1 ml-auto"><span class="text-xs text-slate-500"><?= $h(cL('Preview kamera', 'Camera preview')) ?></span>
        <select id="liveMode" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[170px]">
            <option value="0"><?= $h(cL('Mati (status saja)', 'Off (status only)')) ?></option>
            <option value="10"><?= $h(cL('Tampil, perbarui 10 detik', 'On, refresh 10 s')) ?></option>
            <option value="30"><?= $h(cL('Tampil, perbarui 30 detik', 'On, refresh 30 s')) ?></option>
            <option value="60"><?= $h(cL('Tampil, perbarui 1 menit', 'On, refresh 1 min')) ?></option>
        </select></label>
</form>

<div id="cctvLiveGrid" class="grid gap-3 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 mb-6">
    <?php foreach ($shown as $c):
        $method = cctvCheckMethod($c);
        $state  = $method === '' ? 'unknown' : $c['state'];
        $tone   = ['off' => 'border-red-300 bg-red-50/60', 'vl' => 'border-amber-300 bg-amber-50/60'][$state] ?? (!empty($openReports[$c['id']]) ? 'border-amber-300 bg-amber-50/40' : 'border-slate-200 bg-white');
    ?>
        <?php $lvNvr = $method === 'nvr' ? ($nvrs[(int)$c['nvr_id']] ?? null) : null;
              $canLive = $lvNvr && cctvLiveAvailable($lvNvr); $liveKind = $canLive && cctvLiveUsesVideo($lvNvr) ? 'v' : 's';
              $liveTitle = $c['name'] ?: $c['location']; ?>
        <div class="rounded-xl border <?= $tone ?> p-3 text-sm flex flex-col gap-1 min-w-0 overflow-hidden">
            <div class="cctv-live hidden -mx-3 -mt-3 mb-2 relative bg-slate-900 aspect-video <?= $canLive ? 'cursor-zoom-in' : '' ?>"
                 data-id="<?= $canLive ? (int)$c['id'] : '' ?>" data-live="<?= $liveKind ?>" data-title="<?= $h($liveTitle) ?>" data-sub="<?= $h($c['number'] . ($c['location'] !== '' ? ' · ' . $c['location'] : '') . ($canLive ? ' · ' . $c['nvr_name'] . ' ch ' . (int)$c['channel'] : '')) ?>">
                <img alt="" class="absolute inset-0 w-full h-full object-cover opacity-0 transition-opacity duration-300">
                <span class="cctv-live-msg absolute inset-0 flex items-center justify-center p-3 text-center text-xs text-slate-400"><?= $h($canLive ? cL('Memuat preview…', 'Loading preview…') : ($lvNvr ? cL('Preview belum tersedia untuk NVR ini (lihat Pengaturan > 1)', 'Preview unavailable for this NVR (see Settings > 1)') : cL('Preview hanya untuk kamera lewat NVR', 'Preview only for cameras via NVR'))) ?></span>
                <span class="cctv-live-time absolute top-1 left-1 hidden rounded bg-black/55 px-1.5 py-0.5 text-[10px] font-mono text-white"></span>
            </div>
            <div class="flex items-start justify-between gap-2">
                <div class="min-w-0">
                    <p class="font-semibold text-slate-800 truncate"><?= $h($c['name'] ?: $c['location']) ?></p>
                    <p class="text-xs text-slate-500 truncate"><?= $h($c['number']) ?><?= $c['location'] !== '' ? ' · ' . $h($c['location']) : '' ?></p>
                </div>
                <?= cctvStateBadge($state) ?>
            </div>
            <p class="text-xs text-slate-500 font-mono truncate">
                <?php if ($method === 'nvr'): ?><?= $h($c['nvr_name']) ?> · ch <?= (int)$c['channel'] ?>
                    <?php if ($canLive): ?><button type="button" class="cctv-open ml-1 font-sans text-blue-600 hover:underline" data-id="<?= (int)$c['id'] ?>"><?= $h(cL('Lihat live', 'View live')) ?> &rsaquo;</button><?php endif; ?>
                <?php elseif ($method === 'ip'): ?>IP <?= $h($c['ip']) ?><?= $c['port'] ? ':' . (int)$c['port'] : '' ?>
                <?php else: ?><?= $h(cL('Belum diatur: isi NVR/channel atau IP di Pengaturan', 'Not set: map NVR/channel or IP in Settings')) ?><?php endif; ?>
            </p>
            <?php if ($method !== 'ip'): ?><p class="text-xs text-slate-500 font-mono truncate">IP <?= $c['ip'] !== '' ? $h($c['ip']) : '-' ?></p><?php endif; ?>
            <?php foreach (array_slice($openReports[$c['id']] ?? [], 0, 2) as $rp): ?>
                <a href="cctv_lapor.php" class="text-xs text-amber-700 hover:underline"><?= $h(cL('Dilaporkan', 'Reported')) ?>: <?= $h(cctvIssueLabel((string)$rp['issue'])) ?> · <?= $h($rp['reporter_name']) ?>, <?= $h(date('d M H:i', strtotime((string)$rp['reported_at']))) ?></a>
            <?php endforeach; ?>
            <?php if ($method !== '' && in_array($state, ['off', 'vl'], true)): ?>
                <p class="text-xs text-red-700"><?= $h(cL('Sejak', 'Since')) ?> <?= $h($fmtDt($c['since'])) ?> (<b><?= $h($downFor($c['since'])) ?></b>)<?= $c['detail'] !== '' ? ' · ' . $h($c['detail']) : '' ?></p>
                <?php if ($mi = $mailInfo[$c['id']] ?? null): ?>
                    <p class="text-xs <?= $mi['sent'] ? 'text-slate-500' : 'text-amber-700' ?>"><?= $mi['sent']
                        ? $h(cL('Email terkirim ', 'Email sent ') . date('H:i', strtotime((string)$mi['sent'])))
                        : $h(cL('Email otomatis pukul ', 'Email at ') . date('H:i', strtotime($mi['due'])) . cL(' jika masih mati', ' if still down')) ?></p>
                <?php endif; ?>
            <?php elseif ($method !== '' && $c['last_check']): ?>
                <p class="text-xs text-slate-400"><?= $h(cL('Dicek', 'Checked')) ?> <?= $h($fmtDt($c['last_check'])) ?></p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    <?php if (!$shown): ?><p class="text-sm text-slate-500"><?= $h(cL('Tidak ada kamera yang cocok dengan filter.', 'No cameras match the filter.')) ?></p><?php endif; ?>
</div>

<?php if ($nvrs): ?>
<div id="cctvLiveNvr" class="bg-white rounded-xl shadow-sm overflow-x-auto mb-4">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-slate-500 text-xs"><tr>
            <th class="text-left px-4 py-2">NVR</th><th class="text-left px-4 py-2">IP</th><th class="text-left px-4 py-2"><?= $h(cL('Merk', 'Brand')) ?></th>
            <th class="text-left px-4 py-2">Status</th><th class="text-left px-4 py-2"><?= $h(cL('Keterangan', 'Detail')) ?></th><th class="text-left px-4 py-2"><?= $h(cL('Dicek', 'Checked')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($nvrs as $n): ?>
            <tr class="border-t">
                <td class="px-4 py-2 font-medium"><?= $h($n['name']) ?></td>
                <td class="px-4 py-2 font-mono text-xs"><?= $h($n['ip_address']) ?>:<?= (int)$n['port'] ?></td>
                <td class="px-4 py-2"><?= $h(ucfirst($n['brand'])) ?></td>
                <td class="px-4 py-2"><?= (int)$n['is_active'] !== 1 ? '<span class="text-xs text-slate-400">' . $h(cL('Nonaktif', 'Inactive')) . '</span>' : cctvStateBadge($n['last_state'] === 'on' ? 'on' : ($n['last_state'] ? 'off' : 'unknown')) ?></td>
                <td class="px-4 py-2 text-xs text-slate-600"><?= $h($n['last_detail'] ?? '') ?></td>
                <td class="px-4 py-2 text-xs text-slate-500 whitespace-nowrap"><?= $h($fmtDt($n['last_check'])) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
<?php endif; ?>

<!-- Tampilan live: memenuhi seluruh layar & selalu pas tanpa scroll (gambar diskalakan otomatis). -->
<div id="liveModal" class="fixed inset-0 z-[60] hidden bg-black" role="dialog" aria-modal="true">
    <div class="w-full h-full flex flex-col bg-slate-900 text-white">
        <div class="flex items-start justify-between gap-3 px-4 py-2.5 border-b border-white/10 shrink-0">
            <div class="min-w-0"><p id="lmTitle" class="font-semibold truncate"></p><p id="lmSub" class="text-xs text-slate-400 truncate"></p></div>
            <div class="flex items-center gap-2 shrink-0">
                <span class="inline-flex items-center gap-1 text-xs text-red-400"><span class="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span> LIVE</span>
                <button type="button" id="lmFull" class="rounded-lg px-2 py-1 text-slate-300 hover:bg-white/10 text-lg leading-none" title="<?= $h(cL('Layar penuh (F / klik 2x)', 'Full screen (F / double-click)')) ?>" aria-label="<?= $h(cL('Layar penuh', 'Full screen')) ?>">&#x26F6;</button>
                <button type="button" id="lmClose" class="rounded-lg px-2 py-1 text-slate-300 hover:bg-white/10" aria-label="Tutup"><?= icon('x', 'w-5 h-5') ?></button>
            </div>
        </div>
        <div id="lmStage" class="relative bg-black flex-1 min-h-0">
            <img id="lmImg" alt="" class="absolute inset-0 w-full h-full object-contain">
            <span id="lmMsg" class="absolute inset-0 flex items-center justify-center p-4 text-center text-sm text-slate-400"></span>
            <button type="button" id="lmPrev" class="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/50 hover:bg-black/70 w-10 h-10 text-2xl leading-none" aria-label="Sebelumnya">&lsaquo;</button>
            <button type="button" id="lmNext" class="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/50 hover:bg-black/70 w-10 h-10 text-2xl leading-none" aria-label="Berikutnya">&rsaquo;</button>
        </div>
        <div class="flex flex-wrap items-center justify-between gap-2 px-4 py-1.5 text-xs text-slate-400 shrink-0">
            <span id="lmInfo"></span>
            <span class="hidden sm:inline"><?= $h(cL('Video RTSP (ffmpeg) atau snapshot NVR. Panah kiri/kanan pindah kamera, F / klik 2x layar penuh, Esc menutup.', 'RTSP video (ffmpeg) or NVR snapshots. Left/right to switch, F / double-click for full screen, Esc to close.')) ?></span>
        </div>
    </div>
</div>

<script>
// Preview kamera: thumbnail per kartu (berkala) + tampilan besar ±1 detik. Gambar lewat cctv_live.php (server mengambil dari NVR).
(function () {
    var KEY = 'cctvLiveSec', sel = document.getElementById('liveMode');
    var mode = 30; try { var sv = localStorage.getItem(KEY); if (sv !== null) mode = parseInt(sv, 10) || 0; } catch (e) {}   // bawaan: tampil, perbarui 30 detik
    if (sel) sel.value = String(mode);
    var cache = {}, loading = {}, active = 0, MAX = 2, visible = new Set(), io = null;
    function pad(n) { return (n < 10 ? '0' : '') + n; }
    function clock(d) { return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()); }
    function boxes() { return [].slice.call(document.querySelectorAll('.cctv-live')); }
    function paint(box) {
        var c = cache[box.dataset.id]; if (!c) return;
        var img = box.querySelector('img'), t = box.querySelector('.cctv-live-time'), m = box.querySelector('.cctv-live-msg');
        if (c.url) { if (img.src !== c.url) img.src = c.url; img.classList.remove('opacity-0'); m.classList.add('hidden'); t.textContent = c.time; t.classList.remove('hidden'); }
        else if (c.err) { m.textContent = c.err; m.classList.remove('hidden'); }
    }
    function grab(id, size) {
        return fetch('cctv_live.php?id=' + id + '&s=' + size + '&_=' + Date.now(), {cache: 'no-store', credentials: 'same-origin'}).then(function (r) {
            if (!r.ok) return r.text().then(function (t) { throw new Error(t || ('HTTP ' + r.status)); });
            var stale = r.headers.get('X-Cctv-Live') === 'stale', tm = r.headers.get('X-Cctv-Time');
            return r.blob().then(function (b) { return {url: URL.createObjectURL(b), time: (tm || clock(new Date())) + (stale ? ' *' : '')}; });
        });
    }
    function load(box) {
        var id = box.dataset.id; if (!id || loading[id]) return;
        loading[id] = true; active++;
        grab(id, 't').then(function (res) {
            var old = cache[id]; if (old && old.url) setTimeout(function () { URL.revokeObjectURL(old.url); }, 2000);
            cache[id] = {url: res.url, time: res.time, at: Date.now()};
        }).catch(function (e) {
            cache[id] = Object.assign(cache[id] || {}, {err: (cache[id] && cache[id].url) ? null : e.message, at: Date.now()});
        }).finally(function () {
            loading[id] = false; active--;
            boxes().forEach(function (b) { if (b.dataset.id === id) paint(b); });
        });
    }
    function tick() {
        if (!mode || document.hidden) return;
        boxes().forEach(function (b) {
            if (active >= MAX || !b.dataset.id || !visible.has(b)) return;
            var c = cache[b.dataset.id];
            if (!c || Date.now() - c.at >= mode * 1000) load(b);
        });
    }
    function init() {
        if (io) io.disconnect(); visible.clear();
        io = 'IntersectionObserver' in window ? new IntersectionObserver(function (en) {
            en.forEach(function (x) { if (x.isIntersecting) visible.add(x.target); else visible.delete(x.target); });
        }, {rootMargin: '200px'}) : null;
        boxes().forEach(function (b) {
            b.classList.toggle('hidden', !mode);
            if (io) io.observe(b); else visible.add(b);
            paint(b);
            b.onclick = function () { if (b.dataset.id) openModal(b.dataset.id); };
        });
        [].slice.call(document.querySelectorAll('.cctv-open')).forEach(function (a) { a.onclick = function () { openModal(a.dataset.id); }; });
    }
    if (sel) sel.onchange = function () { mode = parseInt(sel.value, 10) || 0; try { localStorage.setItem(KEY, String(mode)); } catch (e) {} init(); tick(); };
    window.cctvLiveInit = init;
    setInterval(tick, 1000);

    // Tampilan besar
    var md = document.getElementById('liveModal'), mImg = document.getElementById('lmImg'), mMsg = document.getElementById('lmMsg'),
        mInfo = document.getElementById('lmInfo'), curId = null, run = 0;
    function ids() { var a = []; boxes().forEach(function (b) { if (b.dataset.id && a.indexOf(b.dataset.id) < 0) a.push(b.dataset.id); }); return a; }
    function meta(id) { var b = document.querySelector('.cctv-live[data-id="' + id + '"]'); return b ? {t: b.dataset.title, s: b.dataset.sub, v: b.dataset.live !== 's'} : {t: '', s: '', v: true}; }
    // Mode snapshot (tanpa ffmpeg / hosting / Agen Kantor): gambar besar diambil ulang terus-menerus, ±1-2 detik sekali.
    function snapLoop(my) {
        if (my !== run) return;
        grab(curId, 'f').then(function (res) {
            if (my !== run) { URL.revokeObjectURL(res.url); return; }
            var old = mImg.src; mImg.src = res.url; mMsg.classList.add('hidden');
            if (old && old.indexOf('blob:') === 0) setTimeout(function () { URL.revokeObjectURL(old); }, 1500);
            mInfo.textContent = <?= json_encode(cL('Snapshot dari NVR · diperbarui otomatis · ', 'NVR snapshot · auto refresh · ')) ?> + res.time;
            setTimeout(function () { snapLoop(my); }, 1200);
        }).catch(function (e) {
            if (my !== run) return;
            if (!mImg.getAttribute('src')) { mMsg.textContent = e.message; mMsg.classList.remove('hidden'); }
            setTimeout(function () { snapLoop(my); }, 3000);
        });
    }
    function openModal(id) {
        curId = String(id); var m = meta(curId), my = ++run;
        document.getElementById('lmTitle').textContent = m.t; document.getElementById('lmSub').textContent = m.s;
        mImg.onload = mImg.onerror = null; mImg.removeAttribute('src');
        mMsg.textContent = m.v ? <?= json_encode(cL('Menghubungkan ke NVR (RTSP)…', 'Connecting to NVR (RTSP)…')) ?> : <?= json_encode(cL('Mengambil gambar dari NVR…', 'Fetching picture from NVR…')) ?>; mMsg.classList.remove('hidden'); mInfo.textContent = '';
        md.classList.remove('hidden'); document.documentElement.style.overflow = 'hidden';
        if (!m.v) { snapLoop(my); return; }
        // Video live MJPEG dari RTSP sub-stream: diputar langsung oleh <img>.
        mImg.onload = function () { if (my !== run) return; mMsg.classList.add('hidden'); mInfo.textContent = <?= json_encode(cL('Video live · RTSP sub-stream · mulai ', 'Live video · RTSP sub-stream · since ')) ?> + clock(new Date()); };
        mImg.onerror = function () {
            if (my !== run) return;
            // Ambil pesan error dari server (mis. login ditolak / channel tidak ada / ffmpeg belum ada).
            grab(curId, 'f').then(function (res) {
                if (my !== run) { URL.revokeObjectURL(res.url); return; }
                mImg.onload = mImg.onerror = null; mImg.src = res.url; mMsg.classList.add('hidden');
                mInfo.textContent = <?= json_encode(cL('Video tidak bisa diputar, menampilkan gambar ', 'Video unavailable, showing still from ')) ?> + res.time;
            }).catch(function (e) { if (my === run) { mMsg.textContent = e.message; mMsg.classList.remove('hidden'); } });
        };
        mImg.src = 'cctv_live.php?id=' + curId + '&s=v&_=' + Date.now();
    }
    function isFull() { return document.fullscreenElement || document.webkitFullscreenElement; }
    function toggleFull() {
        if (isFull()) { (document.exitFullscreen || document.webkitExitFullscreen).call(document); return; }
        var f = md.requestFullscreen || md.webkitRequestFullscreen; if (f) f.call(md);
    }
    function closeModal() {
        if (isFull()) { try { (document.exitFullscreen || document.webkitExitFullscreen).call(document); } catch (e) {} }
        run++; mImg.onload = mImg.onerror = null; mImg.removeAttribute('src'); mImg.src = 'data:,'; md.classList.add('hidden'); document.documentElement.style.overflow = ''; curId = null;
    }
    function step(d) { var a = ids(), i = a.indexOf(curId); if (a.length) openModal(a[(i + d + a.length) % a.length]); }
    document.getElementById('lmClose').onclick = closeModal;
    document.getElementById('lmFull').onclick = toggleFull;
    document.getElementById('lmStage').addEventListener('dblclick', function (e) { if (!e.target.closest('button')) toggleFull(); });
    document.getElementById('lmPrev').onclick = function () { step(-1); };
    document.getElementById('lmNext').onclick = function () { step(1); };
    md.addEventListener('click', function (e) { if (e.target === md) closeModal(); });
    document.addEventListener('keydown', function (e) {
        if (md.classList.contains('hidden')) return;
        // Esc saat layar penuh: browser keluar dari layar penuh dulu (tampilan tetap terbuka); Esc berikutnya menutup.
        if (e.key === 'Escape') { if (!isFull()) closeModal(); } else if (e.key === 'ArrowLeft') step(-1); else if (e.key === 'ArrowRight') step(1);
        else if (e.key === 'f' || e.key === 'F') toggleFull();
    });
    init();
})();

// Monitoring realtime: cek perubahan tiap 10 detik, lalu perbarui angka, kartu kamera & tabel NVR tanpa memuat ulang halaman.
(function () {
    var sig = null, busy = false;
    function refresh() {
        fetch(location.pathname + location.search, {headers: {'X-Requested-With': 'XMLHttpRequest'}, cache: 'no-store'})
            .then(function (r) { return r.text(); })
            .then(function (html) {
                var doc = new DOMParser().parseFromString(html, 'text/html');
                ['cctvLiveStats', 'cctvLiveGrid', 'cctvLiveNvr', 'cctvLastRun'].forEach(function (id) {
                    var a = document.getElementById(id), b = doc.getElementById(id);
                    if (a && b) a.innerHTML = b.innerHTML;
                });
                if (window.cctvLiveInit) window.cctvLiveInit();
            }).catch(function () {}).finally(function () { busy = false; });
    }
    function poll() {
        if (busy || document.hidden) return;
        var u = location.pathname + (location.search ? location.search + '&' : '?') + 'ajax=sig';
        fetch(u, {cache: 'no-store'}).then(function (r) { return r.json(); }).then(function (d) {
            if (sig !== null && d.sig !== sig) { busy = true; refresh(); }
            sig = d.sig;
        }).catch(function () {});
    }
    poll();
    setInterval(poll, 10000);
    setInterval(function () { if (!busy && !document.hidden) { busy = true; refresh(); } }, 60000);   // durasi "mati X menit" tetap jalan
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
