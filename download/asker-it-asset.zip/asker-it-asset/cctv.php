<?php
/**
 * Menu CCTV > Monitoring (khusus admin): status semua kamera dari pengecekan otomatis (cctv_check.php).
 * Kamera = aset kategori CCTV. Pemetaan NVR/channel & notifikasi diatur di cctv_settings.php.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv.php';

$db = getDB();
ensureCctvTables($db);
$h = fn($v) => htmlspecialchars((string)$v);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'check_now') {
    csrfCheck();
    set_time_limit(240);
    try {
        $sum = runCctvCheck($db);
        $text = cL('Pengecekan selesai: ', 'Check finished: ') . cctvSettings()['last_run_info'];
        if ($sum['down']) $text .= ' · ' . count($sum['down']) . cL(' kamera baru terdeteksi mati', ' camera(s) newly down');
        if ($sum['email'] !== '') $text .= ' · ' . cL('Email gagal: ', 'Email failed: ') . $sum['email'];
        $_SESSION['cctv_msg'] = ['ok' => $sum['email'] === '', 'text' => $text];
    } catch (Throwable $e) {
        $_SESSION['cctv_msg'] = ['ok' => false, 'text' => cL('Pengecekan gagal: ', 'Check failed: ') . $e->getMessage()];
    }
    header('Location: cctv.php');
    exit;
}
$msg = $_SESSION['cctv_msg'] ?? null;
unset($_SESSION['cctv_msg']);

$set   = cctvSettings();
$cams  = cctvCameras($db);
$nvrs  = cctvNvrList($db);
$fNvr  = (int)($_GET['nvr'] ?? 0);
$fSt   = (string)($_GET['st'] ?? '');
$q     = trim((string)($_GET['q'] ?? ''));

$count = ['on' => 0, 'bad' => 0, 'unknown' => 0];
foreach ($cams as $c) {
    $method = cctvCheckMethod($c);
    if ($method === '' || $c['state'] === 'unknown') $count['unknown']++;
    elseif ($c['state'] === 'on') $count['on']++;
    else $count['bad']++;
}
$openReports = cctvOpenReports($db);
$nvrOn = count(array_filter($nvrs, fn($n) => (int)$n['is_active'] === 1 && $n['last_state'] === 'on'));
$nvrActive = count(array_filter($nvrs, fn($n) => (int)$n['is_active'] === 1));

$shown = array_values(array_filter($cams, function ($c) use ($fNvr, $fSt, $q) {
    if ($fNvr && (int)$c['nvr_id'] !== $fNvr) return false;
    if ($fSt === 'bad' && !in_array($c['state'], ['off', 'vl'], true)) return false;
    if ($fSt !== '' && $fSt !== 'bad' && $c['state'] !== $fSt) return false;
    if ($q !== '' && stripos($c['number'] . ' ' . $c['name'] . ' ' . $c['location'] . ' ' . $c['ip'], $q) === false) return false;
    return true;
}));
// Yang bermasalah tampil paling depan.
usort($shown, fn($a, $b) => (in_array($b['state'], ['off', 'vl'], true) <=> in_array($a['state'], ['off', 'vl'], true)) ?: strcmp($a['number'], $b['number']));

$lastRun = $set['last_run'] !== '' ? strtotime($set['last_run']) : 0;
$stale   = !$lastRun || (time() - $lastRun) > max(10, $set['interval_min'] * 5) * 60;
$fmtDt   = fn($d) => $d ? date('d M Y H:i', strtotime((string)$d)) : '-';

// Realtime: halaman mengecek tanda perubahan tiap 10 detik dan memuat ulang bagian status bila berubah.
if (($_GET['ajax'] ?? '') === 'sig') {
    header('Content-Type: application/json');
    header('Cache-Control: no-store');
    $sig = $set['last_run'] . '|' . md5(json_encode(array_map(fn($c) => [$c['id'], $c['state'], $c['since']], $cams))) . '|' . array_sum(array_map('count', $openReports));
    echo json_encode(['sig' => md5($sig)]);
    exit;
}
// Email untuk kamera yang sedang mati: sudah terkirim (jam) / akan dikirim (jam).
$emailDelay = (int)$set['email_after_min'];
$mailInfo = [];
if ($set['notify_email'] && cctvTableExists($db, 'cctv_email_log')) {
    foreach ($db->query("SELECT e.asset_id, e.started_at, m.sent_at FROM cctv_events e LEFT JOIN cctv_email_log m ON m.event_id = e.id WHERE e.ended_at IS NULL")->fetchAll() as $r) {
        $mailInfo[(int)$r['asset_id']] = ['sent' => $r['sent_at'], 'due' => date('Y-m-d H:i:s', strtotime((string)$r['started_at']) + $emailDelay * 60)];
    }
}
$downFor = function (?string $since): string {
    if (!$since) return '';
    $m = max(0, (int)floor((time() - strtotime($since)) / 60));
    return $m < 60 ? $m . cL(' menit', ' min') : floor($m / 60) . cL(' jam ', ' h ') . ($m % 60) . cL(' menit', ' min');
};

$pageTitle = 'CCTV';
$cctvTab = 'monitor';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="flex flex-wrap items-center justify-between gap-3 mb-3">
    <div>
        <h1 class="text-xl font-semibold text-slate-800">CCTV</h1>
        <p class="text-sm text-slate-500"><?= $h(cL('Status kamera dari pengecekan otomatis ke NVR / IP kamera.', 'Camera status from automatic NVR / IP checks.')) ?></p>
    </div>
    <form method="post" class="flex items-center gap-3">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="check_now">
        <span class="text-xs text-slate-500 text-right"><?= $h(cL('Cek terakhir', 'Last check')) ?>:<br><b id="cctvLastRun" class="text-slate-700 tabular-nums"><?= $lastRun ? $h(date('d M Y H:i:s', $lastRun)) : '-' ?></b>
            <br><span class="inline-flex items-center gap-1 text-green-700"><span class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> Live</span></span>
        <button type="submit" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium"><?= icon('refresh') ?> <?= $h(cL('Cek sekarang', 'Check now')) ?></button>
    </form>
</div>

<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<?php if (!$cams): ?>
    <div class="bg-white rounded-xl shadow-sm p-6 text-sm text-slate-600 space-y-2">
        <p class="font-semibold text-slate-800"><?= $h(cL('Belum ada aset CCTV.', 'No CCTV assets yet.')) ?></p>
        <p><?= $h(cL('Tambahkan kamera di menu Asset dengan kategori yang mengandung kata "CCTV" (mis. kategori "CCTV"), isi IP Address dan Lokasinya. Setelah itu atur NVR & channel di tab Pengaturan.', 'Add cameras in the Asset menu with a category containing "CCTV", fill in IP Address and Location, then map NVR & channel in Settings.')) ?></p>
        <a href="categories.php" class="inline-block text-blue-600 hover:underline"><?= $h(cL('Buka Kategori Aset', 'Open Asset Categories')) ?> &rarr;</a>
    </div>
<?php else: ?>

<?php $nOpenRep = array_sum(array_map('count', $openReports)); if ($nOpenRep): ?>
    <a href="cctv_lapor.php" class="mb-4 flex items-center gap-2 text-sm rounded-lg px-4 py-3 bg-amber-50 border border-amber-200 text-amber-800 hover:bg-amber-100/60">
        <?= icon('alert') ?> <b><?= $nOpenRep ?> <?= $h(cL('laporan petugas belum ditangani', 'open officer report(s)')) ?></b> &rarr;
    </a>
<?php endif; ?>
<?php if ($stale): ?>
    <div class="mb-4 text-sm rounded-lg px-4 py-3 bg-amber-50 border border-amber-200 text-amber-800">
        <b><?= $h(cL('Pengecekan otomatis belum berjalan.', 'Automatic check is not running.')) ?></b>
        <?= $h(cL('Status di bawah tidak diperbarui otomatis sampai Task Scheduler dipasang (lihat tab Pengaturan > Jadwal pengecekan). Tombol "Cek sekarang" tetap bisa dipakai.', 'Status below is not refreshed until Task Scheduler is set up (see Settings > Check schedule). "Check now" still works.')) ?>
    </div>
<?php endif; ?>

<div id="cctvLiveStats" class="grid grid-cols-2 xl:grid-cols-4 gap-3 mb-4">
    <?php foreach ([
        [cL('Total kamera', 'Total cameras'), count($cams), 'camera', 'bg-blue-50 text-blue-700', ''],
        [cL('Online', 'Online'), $count['on'], 'check-circle', 'bg-green-50 text-green-700', 'on'],
        [cL('Bermasalah', 'Problem'), $count['bad'], 'alert', 'bg-red-50 text-red-700', 'bad'],
        [cL('NVR online', 'NVR online'), $nvrActive ? $nvrOn . '/' . $nvrActive : '-', 'monitor', 'bg-slate-100 text-slate-600', null],
    ] as [$label, $val, $ic, $tone, $st]): ?>
        <?php $tag = $st === null ? 'div' : 'a'; ?>
        <<?= $tag ?> <?= $st !== null ? 'href="cctv.php' . ($st !== '' ? '?st=' . $st : '') . '"' : '' ?> class="bg-white rounded-xl shadow-sm p-4 flex items-start gap-3 border-2 <?= $st !== null && $fSt === $st ? 'border-blue-400' : ($st === 'bad' && $val ? 'border-red-300' : 'border-transparent') ?>">
            <span class="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 <?= $tone ?>"><?= icon($ic, 'w-5 h-5') ?></span>
            <div><p class="text-xs text-slate-500"><?= $h($label) ?></p><p class="text-2xl font-semibold leading-tight tabular-nums <?= $st === 'bad' && $val ? 'text-red-600' : 'text-slate-800' ?>"><?= $h($val) ?></p></div>
        </<?= $tag ?>>
    <?php endforeach; ?>
</div>

<form method="get" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">NVR</span>
        <select name="nvr" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[140px]">
            <option value="0"><?= $h(cL('Semua', 'All')) ?></option>
            <?php foreach ($nvrs as $n): ?><option value="<?= (int)$n['id'] ?>" <?= $fNvr === (int)$n['id'] ? 'selected' : '' ?>><?= $h($n['name']) ?></option><?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">Status</span>
        <select name="st" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[150px]">
            <option value=""><?= $h(cL('Semua', 'All')) ?></option>
            <option value="bad" <?= $fSt === 'bad' ? 'selected' : '' ?>><?= $h(cL('Bermasalah', 'Problem')) ?></option>
            <?php foreach (CCTV_STATES as $s): ?><option value="<?= $s ?>" <?= $fSt === $s ? 'selected' : '' ?>><?= $h(cctvStateLabel($s)) ?></option><?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1 flex-1 min-w-[180px]"><span class="text-xs text-slate-500"><?= $h(cL('Cari', 'Search')) ?></span>
        <input type="search" name="q" value="<?= $h($q) ?>" placeholder="<?= $h(cL('No aset, nama, lokasi, IP', 'Asset no, name, location, IP')) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5"></label>
    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= $h(cL('Terapkan', 'Apply')) ?></button>
    <a href="cctv.php" class="text-slate-500 hover:text-slate-700 px-2 py-1.5"><?= $h(cL('Reset', 'Reset')) ?></a>
</form>

<div id="cctvLiveGrid" class="grid gap-3 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 mb-6">
    <?php foreach ($shown as $c):
        $method = cctvCheckMethod($c);
        $state  = $method === '' ? 'unknown' : $c['state'];
        $tone   = ['off' => 'border-red-300 bg-red-50/60', 'vl' => 'border-amber-300 bg-amber-50/60'][$state] ?? (!empty($openReports[$c['id']]) ? 'border-amber-300 bg-amber-50/40' : 'border-slate-200 bg-white');
    ?>
        <div class="rounded-xl border <?= $tone ?> p-3 text-sm flex flex-col gap-1 min-w-0">
            <div class="flex items-start justify-between gap-2">
                <div class="min-w-0">
                    <p class="font-semibold text-slate-800 truncate"><?= $h($c['location'] ?: $c['name']) ?></p>
                    <p class="text-xs text-slate-500 truncate"><?= $h($c['number']) ?> · <?= $h($c['name']) ?></p>
                </div>
                <?= cctvStateBadge($state) ?>
            </div>
            <p class="text-xs text-slate-500 font-mono truncate">
                <?php if ($method === 'nvr'): ?><?= $h($c['nvr_name']) ?> · ch <?= (int)$c['channel'] ?>
                <?php elseif ($method === 'ip'): ?>IP <?= $h($c['ip']) ?><?= $c['port'] ? ':' . (int)$c['port'] : '' ?>
                <?php else: ?><?= $h(cL('Belum diatur: isi NVR/channel atau IP di Pengaturan', 'Not set: map NVR/channel or IP in Settings')) ?><?php endif; ?>
            </p>
            <?php foreach (array_slice($openReports[$c['id']] ?? [], 0, 2) as $rp): ?>
                <a href="cctv_lapor.php" class="text-xs text-amber-700 hover:underline"><?= $h(cL('Dilaporkan', 'Reported')) ?>: <?= $h(cctvIssueLabel((string)$rp['issue'])) ?> · <?= $h($rp['reporter_name']) ?>, <?= $h(date('d M H:i', strtotime((string)$rp['reported_at']))) ?></a>
            <?php endforeach; ?>
            <?php if ($method !== '' && in_array($state, ['off', 'vl'], true)): ?>
                <p class="text-xs text-red-700"><?= $h(cL('Sejak', 'Since')) ?> <?= $h($fmtDt($c['since'])) ?> (<b><?= $h($downFor($c['since'])) ?></b>)<?= $c['detail'] !== '' ? ' · ' . $h($c['detail']) : '' ?></p>
                <?php if ($mi = $mailInfo[$c['id']] ?? null): ?>
                    <p class="text-xs <?= $mi['sent'] ? 'text-slate-500' : 'text-amber-700' ?>"><?= $mi['sent']
                        ? $h(cL('Email terkirim ', 'Email sent ') . date('H:i', strtotime((string)$mi['sent'])))
                        : $h(cL('Email otomatis pukul ', 'Email at ') . date('H:i', strtotime($mi['due'])) . cL(' jika masih mati', ' if still down')) ?></p>
                <?php endif; ?>
            <?php elseif ($method !== '' && $c['last_check']): ?>
                <p class="text-xs text-slate-400"><?= $h(cL('Dicek', 'Checked')) ?> <?= $h($fmtDt($c['last_check'])) ?></p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    <?php if (!$shown): ?><p class="text-sm text-slate-500"><?= $h(cL('Tidak ada kamera yang cocok dengan filter.', 'No cameras match the filter.')) ?></p><?php endif; ?>
</div>

<?php if ($nvrs): ?>
<div id="cctvLiveNvr" class="bg-white rounded-xl shadow-sm overflow-x-auto mb-4">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-slate-500 text-xs"><tr>
            <th class="text-left px-4 py-2">NVR</th><th class="text-left px-4 py-2">IP</th><th class="text-left px-4 py-2"><?= $h(cL('Merk', 'Brand')) ?></th>
            <th class="text-left px-4 py-2">Status</th><th class="text-left px-4 py-2"><?= $h(cL('Keterangan', 'Detail')) ?></th><th class="text-left px-4 py-2"><?= $h(cL('Dicek', 'Checked')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($nvrs as $n): ?>
            <tr class="border-t">
                <td class="px-4 py-2 font-medium"><?= $h($n['name']) ?></td>
                <td class="px-4 py-2 font-mono text-xs"><?= $h($n['ip_address']) ?>:<?= (int)$n['port'] ?></td>
                <td class="px-4 py-2"><?= $h(ucfirst($n['brand'])) ?></td>
                <td class="px-4 py-2"><?= (int)$n['is_active'] !== 1 ? '<span class="text-xs text-slate-400">' . $h(cL('Nonaktif', 'Inactive')) . '</span>' : cctvStateBadge($n['last_state'] === 'on' ? 'on' : ($n['last_state'] ? 'off' : 'unknown')) ?></td>
                <td class="px-4 py-2 text-xs text-slate-600"><?= $h($n['last_detail'] ?? '') ?></td>
                <td class="px-4 py-2 text-xs text-slate-500 whitespace-nowrap"><?= $h($fmtDt($n['last_check'])) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
<?php endif; ?>

<script>
// Monitoring realtime: cek perubahan tiap 10 detik, lalu perbarui angka, kartu kamera & tabel NVR tanpa memuat ulang halaman.
(function () {
    var sig = null, busy = false;
    function refresh() {
        fetch(location.pathname + location.search, {headers: {'X-Requested-With': 'XMLHttpRequest'}, cache: 'no-store'})
            .then(function (r) { return r.text(); })
            .then(function (html) {
                var doc = new DOMParser().parseFromString(html, 'text/html');
                ['cctvLiveStats', 'cctvLiveGrid', 'cctvLiveNvr', 'cctvLastRun'].forEach(function (id) {
                    var a = document.getElementById(id), b = doc.getElementById(id);
                    if (a && b) a.innerHTML = b.innerHTML;
                });
            }).catch(function () {}).finally(function () { busy = false; });
    }
    function poll() {
        if (busy || document.hidden) return;
        var u = location.pathname + (location.search ? location.search + '&' : '?') + 'ajax=sig';
        fetch(u, {cache: 'no-store'}).then(function (r) { return r.json(); }).then(function (d) {
            if (sig !== null && d.sig !== sig) { busy = true; refresh(); }
            sig = d.sig;
        }).catch(function () {});
    }
    poll();
    setInterval(poll, 10000);
    setInterval(function () { if (!busy && !document.hidden) { busy = true; refresh(); } }, 60000);   // durasi "mati X menit" tetap jalan
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
