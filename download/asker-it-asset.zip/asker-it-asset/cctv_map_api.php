<?php
/**
 * API Map CCTV (khusus admin, POST). Membalas JSON, kecuali a=export_pdf yang membalas file PDF.
 *   a=point_save | point_bulk | point_delete | link_set | nvr_color | cfg | map_create | map_replace | map_rename | map_delete | export_pdf
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cctv_map.php';

function cmOut(array $d, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($d, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function cmFail(string $m, int $code = 200): void { cmOut(['ok' => false, 'error' => $m], $code); }

if (empty($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') cmFail('Khusus admin. Silakan login ulang.', 403);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') cmFail('Metode tidak valid.', 405);
if (!hash_equals($_SESSION['csrf_token'] ?? '', (string)($_POST['csrf_token'] ?? ''))) cmFail('Sesi kedaluwarsa, muat ulang halaman.', 403);

$db = getDB();
ensureCctvMapTables($db);
$a = (string)($_POST['a'] ?? '');

try {
    switch ($a) {
        case 'point_save':
            $p = cctvMapSavePoint($db, $_POST);
            cmOut(['ok' => true, 'point' => $p]);

        case 'point_bulk':   // impor banyak titik sekaligus (dari nomor di PDF)
            $items = json_decode((string)($_POST['items'] ?? '[]'), true);
            if (!is_array($items) || !$items || count($items) > 600) cmFail('Data impor tidak valid.');
            $map = (int)($_POST['map'] ?? 0);
            $out = []; $skip = 0;
            $db->beginTransaction();
            try {
                foreach ($items as $it) {
                    if (!is_array($it)) { $skip++; continue; }
                    try { $out[] = cctvMapSavePoint($db, array_merge($it, ['map' => $map, 'kind' => 'cam', 'cat' => 'lama', 'id' => 0])); }
                    catch (RuntimeException $e) { $skip++; }
                }
                $db->commit();
            } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); throw $e; }
            cmOut(['ok' => true, 'points' => $out, 'skipped' => $skip]);

        case 'point_delete':
            $db->prepare("DELETE FROM cctv_map_points WHERE id = ?")->execute([(int)($_POST['id'] ?? 0)]);
            cmOut(['ok' => true]);

        case 'link_set':   // sambungkan kamera / perangkat ke switch + port (sinkron dengan topologi)
            $asset  = (int)($_POST['asset'] ?? 0);
            $parent = (int)($_POST['parent'] ?? 0) ?: null;
            $port   = trim((string)($_POST['port'] ?? ''));
            $all = netAssets($db);
            if (!isset($all[$asset])) cmFail('Aset ini belum bisa dihubungkan: isi IP Address pada data asetnya dulu.');
            if ($parent !== null && !isset($all[$parent])) cmFail('Switch tidak ditemukan.');
            if ($parent !== null && $port !== '') {
                $used = netUsedPorts($all, netExtraLinks($db));
                $key  = mb_strtolower(netEthName($port));
                $cur  = $all[$asset];
                $mine = $cur['parent'] === $parent && mb_strtolower(netEthName($cur['port'])) === $key;
                if (!$mine && isset($used[$parent][$key])) cmFail("Port {$port} sudah dipakai ({$used[$parent][$key]}).");
            }
            if (!netSetLink($db, $asset, $parent, $parent === null ? '' : $port)) cmFail('Koneksi ditolak (membentuk putaran atau perangkat tidak valid).');
            netLogLink($db, 'map', 'Map CCTV: ' . $all[$asset]['name'] . ($parent ? ' -> ' . $all[$parent]['name'] . ($port !== '' ? ' (' . netEthName($port) . ')' : '') : ' dilepas'));
            $all = netAssets($db);
            $links = [];
            foreach ($all as $x) if ($x['parent']) $links[$x['id']] = ['parent' => $x['parent'], 'port' => $x['port']];
            cmOut(['ok' => true, 'links' => $links ?: (object)[], 'used' => cctvMapUsedPorts($db, $all)]);

        case 'nvr_color':
            $c = cctvMapColor((string)($_POST['color'] ?? ''));
            $id = (int)($_POST['nvr_id'] ?? 0);
            if ($c === '' || !$id) cmFail('Warna tidak valid.');
            $db->prepare("REPLACE INTO cctv_map_nvr (nvr_id, color) VALUES (?, ?)")->execute([$id, $c]);
            cmOut(['ok' => true]);

        case 'cfg':
            $k = (string)($_POST['k'] ?? ''); $v = (string)($_POST['v'] ?? '');
            if ($k === 'days') cctvMapSaveCfg($db, 'days', (string)max(1, min(90, (int)$v)));
            elseif (in_array($k, ['baru_color', 'dummy_color'], true) && cctvMapColor($v) !== '') cctvMapSaveCfg($db, $k, cctvMapColor($v));
            elseif (preg_match('/^leg_(\d+)$/', $k) && cctvMapLegRect($v) !== '') cctvMapSaveCfg($db, $k, cctvMapLegRect($v));
            else cmFail('Pengaturan tidak dikenal.');
            cmOut(['ok' => true]);

        case 'map_create':
        case 'map_replace':
            $name = mb_substr(trim((string)($_POST['name'] ?? '')), 0, 100);
            [$file, $w, $h, $pdf] = cctvMapStoreFiles($_FILES['image'] ?? [], $_FILES['pdf'] ?? null);
            if ($a === 'map_create') {
                if ($name === '') $name = 'Peta ' . date('d/m/Y');
                $ord = (int)$db->query("SELECT COALESCE(MAX(sort_order),0)+1 FROM cctv_maps")->fetchColumn();
                $db->prepare("INSERT INTO cctv_maps (name, image, pdf, width, height, sort_order) VALUES (?,?,?,?,?,?)")
                   ->execute([$name, $file, $pdf, $w, $h, $ord]);
                $id = (int)$db->lastInsertId();
            } else {
                $id = (int)($_POST['id'] ?? 0);
                if (!$db->query("SELECT 1 FROM cctv_maps WHERE id = $id")->fetchColumn()) { @unlink(CCTV_MAP_DIR . '/' . $file); cmFail('Peta tidak ditemukan.'); }
                cctvMapRemoveFiles($db, $id);
                $db->prepare("UPDATE cctv_maps SET image=?, pdf=?, width=?, height=?, updated_at=NOW() WHERE id=?")->execute([$file, $pdf, $w, $h, $id]);
                if (($_POST['keep'] ?? '1') !== '1') $db->prepare("DELETE FROM cctv_map_points WHERE map_id = ?")->execute([$id]);
                if ($name !== '') $db->prepare("UPDATE cctv_maps SET name=? WHERE id=?")->execute([$name, $id]);
            }
            cmOut(['ok' => true, 'id' => $id]);

        case 'map_rename':
            $name = mb_substr(trim((string)($_POST['name'] ?? '')), 0, 100);
            if ($name === '') cmFail('Nama peta wajib diisi.');
            $db->prepare("UPDATE cctv_maps SET name=? WHERE id=?")->execute([$name, (int)($_POST['id'] ?? 0)]);
            cmOut(['ok' => true]);

        case 'map_delete':
            $id = (int)($_POST['id'] ?? 0);
            cctvMapRemoveFiles($db, $id);
            $db->prepare("DELETE FROM cctv_map_points WHERE map_id = ?")->execute([$id]);
            $db->prepare("DELETE FROM cctv_maps WHERE id = ?")->execute([$id]);
            cmOut(['ok' => true]);

        case 'export_pdf':   // gambar peta + titik + keterangan (dibuat browser) -> PDF A4 / A3
            $f = $_FILES['image'] ?? null;
            if (!$f || ($f['error'] ?? 1) !== UPLOAD_ERR_OK) cmFail('Gambar gagal diterima server.');
            $info = @getimagesize($f['tmp_name']);
            if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG], true)) cmFail('Gambar tidak valid.');
            require_once __DIR__ . '/vendor/autoload.php';
            @ini_set('memory_limit', '512M');
            @set_time_limit(120);
            $paper = ($_POST['paper'] ?? 'A4') === 'A3' ? 'A3' : 'A4';
            $mime  = $info[2] === IMAGETYPE_PNG ? 'image/png' : 'image/jpeg';
            $src   = 'data:' . $mime . ';base64,' . base64_encode((string)file_get_contents($f['tmp_name']));
            $title = mb_substr(trim((string)($_POST['title'] ?? 'Map CCTV')), 0, 120);
            $rows  = json_decode((string)($_POST['rows'] ?? '[]'), true);
            $rows  = is_array($rows) ? array_slice($rows, 0, 1000) : [];
            $plans = json_decode((string)($_POST['plans'] ?? '[]'), true);
            $plans = is_array($plans) ? array_slice($plans, 0, 300) : [];
            $summary = mb_substr(trim((string)($_POST['summary'] ?? '')), 0, 200);
            $asHtml = ($_POST['mode'] ?? '') === 'html';   // cetak langsung: HTML + window.print()
            $html = cctvMapDocHtml($title, $summary, $rows, $src, $info[0], $info[1], $paper, !$asHtml, $plans);
            if ($asHtml) { header('Content-Type: text/html; charset=utf-8'); header('Cache-Control: no-store'); echo $html; exit; }
            $land = $info[0] >= $info[1];
            $opt = new Dompdf\Options();
            $opt->set('isRemoteEnabled', false);
            $pdf = new Dompdf\Dompdf($opt);
            $pdf->setPaper($paper, $land ? 'landscape' : 'portrait');
            $pdf->loadHtml($html);
            $pdf->render();
            $fn = 'Map-CCTV-' . preg_replace('/[^A-Za-z0-9_-]+/', '-', $title) . '-' . $paper . '-' . date('Ymd') . '.pdf';
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $fn . '"');
            header('Cache-Control: no-store');
            echo $pdf->output();
            exit;

        default:
            cmFail('Aksi tidak dikenal.');
    }
} catch (RuntimeException $e) {
    cmFail($e->getMessage());
} catch (Throwable $e) {
    error_log('cctv_map_api: ' . $e->getMessage());
    cmFail('Terjadi kesalahan server: ' . $e->getMessage());
}
