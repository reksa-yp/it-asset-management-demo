<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/donate.php';
requireLogin();
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isAdmin()) { http_response_code(403); echo json_encode(['ok' => false, 'message' => 'Akses ditolak.']); exit; }
csrfCheck();
$en = function_exists('currentLang') && currentLang() === 'en';
if (!function_exists('sodium_crypto_sign_verify_detached')) {
    echo json_encode(['ok' => false, 'message' => $en ? 'PHP extension "sodium" is not enabled on this server.' : 'Ekstensi PHP "sodium" belum aktif di server ini.']); exit;
}
$code = trim((string)($_POST['code'] ?? ''));
$name = donateVerifyCode($code);
if ($name === null) { echo json_encode(['ok' => false, 'message' => $en ? 'Invalid donor code.' : 'Kode donatur tidak valid.']); exit; }
if (!donateSave($code, $name)) { echo json_encode(['ok' => false, 'message' => $en ? 'Could not save (folder includes/data is not writable).' : 'Gagal menyimpan (folder includes/data tidak bisa ditulis).']); exit; }
echo json_encode(['ok' => true, 'name' => $name, 'message' => $en ? 'Thank you for your support!' : 'Terima kasih atas dukungan Anda!']);
