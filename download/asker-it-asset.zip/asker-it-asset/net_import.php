<?php
/**
 * Import Perangkat Jaringan (switch, hub, router, access point) dari Excel (khusus admin). Alur sama dengan Import CCTV.
 *   ?template=1         unduh template kosong
 *   ?template=1&data=1  unduh template berisi perangkat jaringan yang sudah ada (edit massal lalu import lagi)
 * Upload -> preview (baru / diperbarui / error) -> Simpan. Lihat includes/net_import.php.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/includes/net_import.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$db = getDB();
ensureNetTables($db);
$h = fn($v) => htmlspecialchars((string)$v);
$cats = netImpCategories($db);
$backUrl = 'assets.php' . ($cats ? '?category=' . urlencode($cats[0]) : '');

function netImportDiscard(): void
{
    $p = $_SESSION['net_import'] ?? null;
    if ($p && !empty($p['file']) && is_file($p['file'])) @unlink($p['file']);
    unset($_SESSION['net_import']);
}

if (!empty($_GET['template'])) {
    $ss = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $withData = !empty($_GET['data']);
    writeNetImportTemplate($db, $ss, $withData);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . ($withData ? 'data_perangkat_jaringan_' . date('Ymd') : 'template_import_perangkat_jaringan') . '.xlsx"');
    header('Cache-Control: max-age=0');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($ss))->save('php://output');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $act = (string)($_POST['action'] ?? '');
    if ($act === 'add_cats') {
        $added = [];
        foreach (netImpMissingStdKinds($db) as $k) { netImpEnsureCategory($db, $k); $added[] = $k; }
        $_SESSION['net_imp_msg'] = ['ok' => true, 'text' => nL('Kategori ditambahkan: ', 'Categories added: ') . (implode(', ', $added) ?: '-')];
        header('Location: net_import.php');
        exit;
    }
    if ($act === 'upload') {
        netImportDiscard();
        try {
            if (empty($_FILES['excel_file']['tmp_name']) || !is_uploaded_file($_FILES['excel_file']['tmp_name'])) throw new Exception(nL('Pilih file Excel dulu.', 'Choose an Excel file first.'));
            $ss = IOFactory::load($_FILES['excel_file']['tmp_name']);
            if (!isNetImportSpreadsheet($ss)) throw new Exception(nL('File bukan format import Perangkat Jaringan (kolom "Nama Perangkat" & "Terhubung ke" tidak ditemukan). Unduh template dulu.', 'Not a network device import file. Download the template first.'));
            $tmp = tempnam(sys_get_temp_dir(), 'netimp_');
            if (!$tmp || !move_uploaded_file($_FILES['excel_file']['tmp_name'], $tmp)) throw new Exception(nL('File tidak bisa disimpan sementara di server.', 'Could not store the file temporarily.'));
            $_SESSION['net_import'] = ['file' => $tmp, 'name' => basename((string)$_FILES['excel_file']['name']), 'time' => time()];
        } catch (Throwable $e) {
            $_SESSION['net_imp_msg'] = ['ok' => false, 'text' => nL('Import gagal: ', 'Import failed: ') . $e->getMessage()];
        }
        header('Location: net_import.php');
        exit;
    }
    $pending = $_SESSION['net_import'] ?? null;
    if ($act === 'save' && $pending && is_file($pending['file'])) {
        try {
            $r = netImportApply($db, netImportPlan($db, IOFactory::load($pending['file'])));
            $text = nL("Import Perangkat Jaringan selesai: {$r['new']} baru, {$r['upd']} diperbarui", "Network import done: {$r['new']} new, {$r['upd']} updated");
            if ($r['skipped']) $text .= nL(", {$r['skipped']} baris error dilewati", ", {$r['skipped']} error rows skipped");
            if ($r['cats']) $text .= nL('. Kategori baru: ', '. New categories: ') . implode(', ', $r['cats']);
            if ($r['link_fail']) $text .= nL(". {$r['link_fail']} \"Terhubung ke\" tidak disimpan (sambungan melingkar)", ". {$r['link_fail']} links skipped (circular)");
            $_SESSION['asset_bulk_msg'] = ['ok' => true, 'text' => $text . '.'];
            netImportDiscard();
            $cats = netImpCategories($db);
            header('Location: assets.php' . ($cats ? '?category=' . urlencode($cats[0]) : ''));
            exit;
        } catch (Throwable $e) {
            $_SESSION['net_imp_msg'] = ['ok' => false, 'text' => nL('Gagal menyimpan, tidak ada data yang berubah: ', 'Save failed, nothing was changed: ') . $e->getMessage()];
            header('Location: net_import.php');
            exit;
        }
    }
    netImportDiscard();
    $_SESSION['net_imp_msg'] = ['ok' => false, 'text' => nL('Import dibatalkan.', 'Import cancelled.')];
    header('Location: net_import.php');
    exit;
}

$msg = $_SESSION['net_imp_msg'] ?? null;
unset($_SESSION['net_imp_msg']);
$pending = $_SESSION['net_import'] ?? null;
if ($pending && (time() - (int)$pending['time'] > 3600 || !is_file($pending['file']))) { netImportDiscard(); $pending = null; }
$plan = null;
if ($pending) {
    try { $plan = netImportPlan($db, IOFactory::load($pending['file'])); }
    catch (Throwable $e) { netImportDiscard(); $pending = null; $msg = ['ok' => false, 'text' => nL('File tidak bisa dibaca: ', 'Could not read file: ') . $e->getMessage()]; }
}
$missing = netImpMissingStdKinds($db);
$all = netAssets($db);

$pageTitle = nL('Import Perangkat Jaringan', 'Import Network Devices');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
$badge = ['new' => ['bg-green-100 text-green-700', nL('Baru', 'New')], 'update' => ['bg-blue-100 text-blue-700', nL('Diperbarui', 'Update')], 'error' => ['bg-red-100 text-red-700', 'Error']];
?>
<div class="flex flex-wrap items-center justify-between gap-3 mb-4">
    <div>
        <h1 class="text-xl font-semibold text-slate-800"><?= $h($pageTitle) ?></h1>
        <p class="text-sm text-slate-500"><?= $h(nL('Input banyak switch, hub, router & access point sekaligus. Data langsung masuk ke Asset dan menu Jaringan (topologi).', 'Add many switches, hubs, routers & APs at once. Data goes straight into Assets and the Network menu.')) ?></p>
    </div>
    <a href="<?= $h($backUrl) ?>" class="text-sm text-brand-700 hover:underline">&larr; <?= $h(nL('Kembali ke Asset', 'Back to assets')) ?></a>
</div>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<?php if ($missing && !$plan): ?>
    <form method="post" class="mb-4 text-sm rounded-lg px-3 py-2 bg-amber-50 border border-amber-200 text-amber-800 flex flex-wrap items-center gap-3">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>"><input type="hidden" name="action" value="add_cats">
        <span><?= $h(nL('Kategori aset belum ada: ', 'Missing asset categories: ') . implode(', ', $missing)) ?>. <?= $h(nL('Kategori dibutuhkan agar bisa dipilih di form Tambah Aset (import akan membuatnya otomatis).', 'Needed for the Add Asset form (the import creates them automatically).')) ?></span>
        <button class="rounded-lg bg-amber-600 hover:bg-amber-700 text-white px-3 py-1.5 font-medium"><?= $h(nL('Tambahkan sekarang', 'Add now')) ?></button>
    </form>
<?php endif; ?>

<?php if (!$plan): ?>
<div class="grid md:grid-cols-2 gap-4">
    <div class="bg-white rounded-xl shadow-sm p-5 text-sm space-y-3">
        <h2 class="font-semibold text-slate-800">1. <?= $h(nL('Unduh template', 'Download the template')) ?></h2>
        <p class="text-slate-600"><?= $h(nL('Template berisi sheet Jaringan dan petunjuk. Kolom Jenis, Terhubung ke & Status sudah berupa pilihan (dropdown).', 'The template has a Network sheet and a guide. Type, Connected to & Status are dropdowns.')) ?></p>
        <div class="flex flex-wrap gap-2">
            <a href="net_import.php?template=1" class="inline-flex items-center gap-2 rounded-lg bg-green-600 hover:bg-green-700 text-white px-4 py-2 font-medium"><?= icon('download') ?> <?= $h(nL('Template kosong', 'Blank template')) ?></a>
            <a href="net_import.php?template=1&data=1" class="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 px-4 py-2 font-medium"><?= icon('download') ?> <?= $h(nL('Template + data yang ada', 'Template + existing data')) ?></a>
        </div>
        <ul class="list-disc pl-5 text-xs text-slate-500 space-y-1">
            <li><?= $h(nL('Jenis, Nama Perangkat & Lokasi wajib untuk perangkat baru.', 'Type, device name & location are required for new devices.')) ?></li>
            <li><?= $h(nL('Switch/hub biasa (unmanaged): kosongkan IP Address. Router dengan banyak segmen: tulis semua IP dipisah koma (boleh /24); IP di segmen server otomatis jadi IP utama.', 'Unmanaged switch/hub: leave IP empty. Multi-segment router: list all IPs separated by commas (/24 allowed).')) ?></li>
            <li><?= $h(nL('Terhubung ke = switch/router di atasnya (nama, nomor aset, atau IP). Boleh menyebut baris lain di file yang sama.', 'Connected to = upstream switch/router (name, asset number or IP), may refer to another row.')) ?></li>
            <li><?= $h(nL('Nomor Aset kosong = dibuat otomatis. IP / nama+lokasi yang sudah ada = data lama diperbarui.', 'Empty asset number = auto-numbered. Existing IP / name+location = updated.')) ?></li>
        </ul>
    </div>
    <form method="post" enctype="multipart/form-data" class="bg-white rounded-xl shadow-sm p-5 text-sm space-y-3">
        <h2 class="font-semibold text-slate-800">2. <?= $h(nL('Upload file', 'Upload the file')) ?></h2>
        <p class="text-slate-600"><?= $h(nL('Setelah upload muncul preview. Data baru tersimpan setelah Anda klik Simpan.', 'A preview is shown after upload. Nothing is saved until you click Save.')) ?></p>
        <input type="file" name="excel_file" accept=".xlsx,.xls" required class="w-full border border-slate-300 rounded-lg px-3 py-2">
        <button type="submit" class="inline-flex items-center gap-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 font-medium"><?= icon('upload') ?> <?= $h(nL('Upload & cek', 'Upload & check')) ?></button>
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="action" value="upload">
    </form>
</div>
<?php else:
    $cnt = fn($a) => count(array_filter($plan['rows'], fn($r) => $r['action'] === $a));
    $okRows = $cnt('new') + $cnt('update');
    $errRows = $cnt('error');
    $rowName = function ($ref) use ($plan, $all) {
        if (!$ref) return '';
        if (isset($ref['id'])) return $all[$ref['id']]['name'] ?? ('#' . $ref['id']);
        return ($plan['rows'][$ref['row']]['d']['name'] ?? '') . ' ' . nL('(baris ', '(row ') . ($plan['rows'][$ref['row']]['excel_row'] ?? '') . ')';
    };
?>
<div class="bg-white rounded-xl shadow-sm p-4 mb-4 text-sm">
    <p class="text-slate-500 mb-3"><?= $h(nL('File', 'File')) ?>: <span class="font-medium text-slate-800"><?= $h($pending['name']) ?></span></p>
    <div class="grid grid-cols-3 gap-2 max-w-xl">
        <?php foreach (['new', 'update', 'error'] as $a): ?>
            <div class="rounded-lg border border-slate-200 px-3 py-2">
                <p class="text-xs text-slate-500"><?= $h($badge[$a][1]) ?></p>
                <p class="text-xl font-semibold <?= $a === 'error' ? 'text-red-600' : ($a === 'new' ? 'text-green-700' : 'text-blue-700') ?>"><?= $cnt($a) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    <?php foreach ($plan['notes'] as $n): ?><p class="mt-3 text-amber-700 bg-amber-50 rounded-lg px-3 py-2"><?= $h($n) ?></p><?php endforeach; ?>
    <?php if ($errRows): ?><p class="mt-3 text-red-700 bg-red-50 rounded-lg px-3 py-2"><?= $h(nL("$errRows baris error akan dilewati. Perbaiki di Excel lalu upload ulang, atau simpan baris yang benar saja.", "$errRows error rows will be skipped.")) ?></p><?php endif; ?>
    <form method="post" class="mt-4 flex flex-wrap gap-2">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <?php if ($okRows): ?><button name="action" value="save" class="rounded-lg bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 font-medium"><?= $h(nL("Simpan $okRows baris", "Save $okRows rows")) ?></button><?php endif; ?>
        <button name="action" value="cancel" class="rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 px-5 py-2"><?= $h(nL('Batal / upload ulang', 'Cancel / re-upload')) ?></button>
    </form>
</div>
<div class="bg-white rounded-xl shadow-sm mb-4 overflow-hidden">
    <div class="overflow-x-auto">
    <table class="w-full text-sm" data-rt="off">
        <thead class="bg-slate-50 text-slate-600 text-xs text-left"><tr>
            <th class="px-3 py-2"><?= $h(nL('Baris', 'Row')) ?></th><th class="px-3 py-2"><?= $h(nL('Aksi', 'Action')) ?></th>
            <th class="px-3 py-2"><?= $h(nL('Nomor Aset', 'Asset No.')) ?></th><th class="px-3 py-2"><?= $h(nL('Jenis', 'Type')) ?></th>
            <th class="px-3 py-2"><?= $h(nL('Nama', 'Name')) ?></th><th class="px-3 py-2"><?= $h(nL('Lokasi', 'Location')) ?></th>
            <th class="px-3 py-2">IP</th><th class="px-3 py-2">Brand / Type</th><th class="px-3 py-2">Port</th>
            <th class="px-3 py-2"><?= $h(nL('Terhubung ke', 'Connected to')) ?></th><th class="px-3 py-2">Status</th>
            <th class="px-3 py-2"><?= $h(nL('Keterangan', 'Notes')) ?></th>
        </tr></thead>
        <tbody class="divide-y divide-slate-100">
        <?php foreach ($plan['rows'] as $r): $d = $r['d']; ?>
            <tr class="<?= $r['action'] === 'error' ? 'bg-red-50/50' : '' ?>">
                <td class="px-3 py-2 text-slate-400"><?= (int)$r['excel_row'] ?></td>
                <td class="px-3 py-2"><span class="text-xs rounded-full px-2 py-0.5 <?= $badge[$r['action']][0] ?>"><?= $h($badge[$r['action']][1]) ?></span></td>
                <td class="px-3 py-2 whitespace-nowrap"><?= $r['asset_number'] !== '' ? $h($r['asset_number']) : '<span class="text-slate-400">' . $h(nL('otomatis', 'auto')) . '</span>' ?></td>
                <td class="px-3 py-2"><?= $h($r['category'] ?: $d['kind']) ?></td>
                <td class="px-3 py-2 font-medium text-slate-800"><?= $h($d['name']) ?></td>
                <td class="px-3 py-2"><?= $h($d['location']) ?></td>
                <td class="px-3 py-2 text-xs"><?php if ($r['ips']): ?><span class="font-semibold text-slate-800 whitespace-nowrap"><?= $h($r['main_ip']) ?></span> <span class="text-[10px] text-slate-400"><?= $h(nL('utama', 'main')) ?></span><?php $others = array_filter($r['ips'], fn($i) => $i['ip'] !== $r['main_ip']); if ($others): ?><div class="text-slate-500 max-w-[260px]">+ <?= $h(netIpListText(array_values($others))) ?></div><?php endif; ?><?php elseif ($d['ip'] !== ''): ?><?= $h($d['ip']) ?><?php else: ?><span class="text-slate-400"><?= $h(nL('tanpa IP', 'no IP')) ?></span><?php endif; ?></td>
                <td class="px-3 py-2"><?= $h(trim($d['brand'] . ' ' . $d['type'])) ?></td>
                <td class="px-3 py-2"><?= $h($d['ports']) ?></td>
                <td class="px-3 py-2 whitespace-nowrap"><?= $h(trim($rowName($r['parent']) ?: $d['parent'])) ?><?= netPortLabel($d['uplink'], $d['own']) !== '' ? ' <span class="text-slate-400 font-mono text-xs">' . $h(netPortLabel($d['uplink'], $d['own'])) . '</span>' : '' ?><?php foreach ($r['extra'] as $x): ?><div class="text-xs text-blue-700">&#8646; <?= $h($x['name']) ?><?= ($x['pa'] !== '' || $x['pb'] !== '') ? ' <span class="font-mono">(' . $h($x['pb'] . ' ⇄ ' . $x['pa']) . ')</span>' : '' ?></div><?php endforeach; ?></td>
                <td class="px-3 py-2"><?= $d['status'] !== '' || $r['action'] !== 'update' ? $h(cctvImpStatus($d['status'])) : '<span class="text-slate-400">' . $h(nL('tetap', 'unchanged')) . '</span>' ?></td>
                <td class="px-3 py-2 text-xs">
                    <?php foreach ($r['errors'] as $e): ?><p class="text-red-700"><?= $h($e) ?></p><?php endforeach; ?>
                    <?php foreach ($r['warnings'] as $w): ?><p class="text-amber-700"><?= $h($w) ?></p><?php endforeach; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
