# Standar Spesifikasi PC & Laptop

Menu **Standar Spesifikasi** (khusus admin) mengecek semua aset **Laptop** dan **Desktop PC**
terhadap spesifikasi minimal yang ditentukan IT, lalu menyusun laporan per departemen.

## 1. Atur standar
Setiap standar berisi: prosesor minimal, generasi minimal, RAM minimal, OS minimal,
wajib edisi Pro, wajib SSD, wajib VGA. Semua bisa diubah, ditambah, atau dihapus.

| Jenis | Berlaku untuk |
|---|---|
| Umum | Semua yang tidak cocok dengan standar lain (wajib ada 1) |
| Departemen | Departemen yang ditulis (pisah koma), harus sama dengan isian Departemen di data aset |
| Jabatan | Pemakai aset yang jabatannya mengandung kata kunci (pisah koma), mis. `Manager, GM` |

Standar awal: Admin & Staff (i3 gen 10, 8 GB, SSD), CAD (i5 gen 10, 8 GB, SSD, VGA),
Multimedia (i7 gen 10, 16 GB, SSD), Manager (i5 gen 10, 8 GB, SSD), semua Windows 11 Pro.
**Isi dulu nama departemen untuk CAD dan Multimedia**, lalu klik *Simpan standar*.

Urutan penentuan: standar yang dipilih manual di aset → departemen/jabatan yang cocok
(bila cocok dua, dipakai yang lebih tinggi) → standar Umum.

## 2. Cara sistem membaca spesifikasi
- Prosesor: `Intel Core i5-1035G1` → Core i5 gen 10, `i7-8700` → gen 8, `Core i5 Gen 10` juga dikenali.
  AMD Ryzen disetarakan (Ryzen 3 = i3, Ryzen 5 = i5, Ryzen 3000 ≈ gen 10, 5000 ≈ gen 11).
- RAM: `8 GB DDR4`, `2x8GB`, `8192 MB`. Penyimpanan: ada kata SSD/NVMe/M.2 = SSD.
- OS: `Windows 10 Pro`, `Windows 11 Home`, dst.
- VGA: isian **Graphic Card / VGA** di form aset. Bila kosong, dibaca dari kolom **Aksesoris**
  (NVIDIA, GeForce, GTX, RTX, Quadro, Radeon RX/Pro, Intel Arc). Kata "kabel VGA", "HDMI to VGA",
  port, converter, dan grafis bawaan (UHD, Iris, onboard) tidak dihitung. Tulisan "VGA" tanpa merek
  ditandai *perlu dicek*.
- Tombol **Salin VGA dari aksesoris** memindahkan kartu grafis yang terdeteksi ke isian VGA
  (bisa dicek dan diubah dulu). Kolom aksesoris tidak diubah.

## 3. Hasil & koreksi manual
Status: **Sesuai**, **Di bawah standar** (dengan saran *Upgrade* atau *Ganti unit*), **Data belum lengkap**.
Windows 11 butuh prosesor Intel gen 8+ / Ryzen 2000+; prosesor lebih lama disarankan ganti unit.

Klik **Edit** pada perangkat untuk: memilih standar, mengoreksi prosesor/generasi/RAM/SSD/OS/edisi,
mengisi VGA, memaksa status (mis. *Sesuai (pengecualian)*), menulis saran dan catatan.
Perangkat yang dikoreksi diberi label MANUAL; *Kembalikan ke otomatis* menghapus koreksinya.

## 4. Laporan
- **Export Excel**: sheet Standar, Per Departemen, Daftar Perangkat.
- **Laporan PDF (English)**: ringkasan, tabel standar, rekap per departemen, dan daftar perangkat
  di bawah standar beserta saran — siap dikirim ke atasan.

## Catatan teknis
Membuat 3 tabel baru bila belum ada: `spec_tiers`, `spec_overrides`, `asset_gpu`.
Tidak mengubah struktur tabel lama dan tidak mengubah data aset (kecuali isian VGA yang memang milik aset).
