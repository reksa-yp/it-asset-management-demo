<?php
/** Menu CCTV > Log CCTV mati (khusus admin): riwayat kamera mati/hidup, durasi, keterangan admin, rekap bulanan. */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv.php';

$db = getDB();
ensureCctvTables($db);
$h = fn($v) => htmlspecialchars((string)$v);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'note') {
    csrfCheck();
    $db->prepare("UPDATE cctv_events SET note = ? WHERE id = ?")
       ->execute([mb_substr(trim((string)($_POST['note'] ?? '')), 0, 250) ?: null, (int)($_POST['id'] ?? 0)]);
    $_SESSION['cctv_msg'] = ['ok' => true, 'text' => cL('Keterangan disimpan.', 'Note saved.')];
    header('Location: cctv_log.php?' . http_build_query(['ym' => $_POST['ym'] ?? '', 'cam' => $_POST['cam'] ?? '', 'nvr' => $_POST['nvr'] ?? '']));
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrfCheck();
    $back = ['ym' => $_POST['ym'] ?? '', 'cam' => $_POST['cam'] ?? '', 'nvr' => $_POST['nvr'] ?? ''];
    if (($_POST['scope'] ?? '') === 'filter') {
        // Semua log yang tampil sesuai filter (bulan + NVR + kamera)
        $fYm = preg_match('/^\d{4}-\d{2}$/', (string)$back['ym']) ? (string)$back['ym'] : date('Y-m');
        $r = cctvMonthReport($db, $fYm);
        $ids = [];
        foreach ($r['events'] as $ev) {
            $cm = $r['cam_by_id'][(int)$ev['asset_id']] ?? null;
            if ((int)$back['cam'] && (int)$ev['asset_id'] !== (int)$back['cam']) continue;
            if ((int)$back['nvr'] && (int)($cm['nvr_id'] ?? 0) !== (int)$back['nvr']) continue;
            $ids[] = (int)$ev['id'];
        }
    } else {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
    }
    $ids = array_values(array_unique(array_filter($ids)));
    $n = 0;
    if ($ids) {
        $db->beginTransaction();
        foreach (array_chunk($ids, 500) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '?'));
            // Kejadian yang masih berlangsung (kamera masih mati) tidak ikut dihapus.
            $st = $db->prepare("SELECT id FROM cctv_events WHERE id IN ($in) AND ended_at IS NOT NULL");
            $st->execute($chunk);
            $ok = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
            if (!$ok) continue;
            $in2 = implode(',', array_fill(0, count($ok), '?'));
            $db->prepare("DELETE FROM cctv_email_log WHERE event_id IN ($in2)")->execute($ok);
            $db->prepare("DELETE FROM cctv_notices WHERE event_id IN ($in2)")->execute($ok);
            $d = $db->prepare("DELETE FROM cctv_events WHERE id IN ($in2)");
            $d->execute($ok);
            $n += $d->rowCount();
        }
        $db->commit();
    }
    $_SESSION['cctv_msg'] = $n
        ? ['ok' => true, 'text' => $n . cL(' log CCTV dihapus.', ' CCTV log entries deleted.') . (count($ids) > $n ? ' ' . cL('Log kamera yang masih mati tidak dihapus.', 'Entries for cameras still down were kept.') : '')]
        : ['ok' => false, 'text' => cL('Tidak ada log yang dihapus. Pilih log terlebih dahulu (log kamera yang masih mati tidak bisa dihapus).', 'Nothing deleted. Select entries first (entries for cameras still down cannot be deleted).')];
    header('Location: cctv_log.php?' . http_build_query($back));
    exit;
}
$msg = $_SESSION['cctv_msg'] ?? null;
unset($_SESSION['cctv_msg']);

$ym  = (string)($_GET['ym'] ?? date('Y-m'));
if (!preg_match('/^\d{4}-\d{2}$/', $ym)) $ym = date('Y-m');
$fCam = (int)($_GET['cam'] ?? 0);
$fNvr = (int)($_GET['nvr'] ?? 0);
$rep = cctvMonthReport($db, $ym);
$nvrGroups = cctvNvrGroups($rep['cams']);
$events = array_values(array_filter($rep['events'], function ($e) use ($fCam, $fNvr, $rep) {
    if ($fCam && (int)$e['asset_id'] !== $fCam) return false;
    if ($fNvr && (int)(($rep['cam_by_id'][(int)$e['asset_id']] ?? [])['nvr_id'] ?? 0) !== $fNvr) return false;
    return true;
}));
usort($events, fn($a, $b) => strcmp((string)$b['started_at'], (string)$a['started_at']));
$camById = $rep['cam_by_id'];

// Pilihan bulan: 12 bulan terakhir.
$months = [];
for ($i = 0; $i < 12; $i++) { $m = date('Y-m', strtotime(date('Y-m-01') . " -$i month")); $months[$m] = cctvMonthTitle($m); }
if (!isset($months[$ym])) $months[$ym] = cctvMonthTitle($ym);

$pageTitle = cL('Log CCTV mati', 'CCTV downtime log');
$cctvTab = 'log';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="flex flex-wrap items-center justify-between gap-3 mb-3">
    <div>
        <h1 class="text-xl font-semibold text-slate-800"><?= $h(cL('Log CCTV mati', 'CCTV downtime log')) ?></h1>
        <p class="text-sm text-slate-500"><?= $h(cL('Tercatat otomatis setiap kali kamera mati dan hidup kembali.', 'Recorded automatically when a camera goes down and comes back.')) ?></p>
    </div>
    <div class="flex flex-wrap gap-2 text-sm">
        <a href="cctv_report.php?mode=month&ym=<?= $h($ym) ?>&out=xlsx" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 font-medium"><?= icon('sheet') ?> Export Excel</a>
    </div>
</div>

<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<form method="get" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Bulan', 'Month')) ?></span>
        <select name="ym" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[160px]">
            <?php foreach ($months as $k => $label): ?><option value="<?= $h($k) ?>" <?= $k === $ym ? 'selected' : '' ?>><?= $h($label) ?></option><?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">NVR</span>
        <select name="nvr" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[140px]">
            <option value="0"><?= $h(cL('Semua NVR', 'All NVRs')) ?></option>
            <?php foreach ($nvrGroups as $g): if (!$g['key']) continue; ?><option value="<?= (int)$g['key'] ?>" <?= $fNvr === (int)$g['key'] ? 'selected' : '' ?>><?= $h($g['name']) ?></option><?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Kamera', 'Camera')) ?></span>
        <select name="cam" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[200px]">
            <option value="0"><?= $h(cL('Semua', 'All')) ?></option>
            <?php foreach ($rep['cams'] as $c): ?><option value="<?= $c['id'] ?>" <?= $fCam === $c['id'] ? 'selected' : '' ?>><?= $h($c['number'] . ' · ' . ($c['name'] ?: $c['location'])) ?></option><?php endforeach; ?>
        </select></label>
    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= $h(cL('Terapkan', 'Apply')) ?></button>
</form>

<?php $nDel = count(array_filter($events, fn($e) => !empty($e['ended_at']))); ?>
<form id="bulkDel" method="post" onsubmit="return cctvConfirmDel(event)">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="ym" value="<?= $h($ym) ?>"><input type="hidden" name="cam" value="<?= $fCam ?>"><input type="hidden" name="nvr" value="<?= $fNvr ?>">
</form>
<?php if ($events): ?>
<div class="bg-white rounded-xl shadow-sm px-3 py-2 mb-2 flex flex-wrap items-center gap-2 text-sm">
    <span class="text-slate-500"><?= count($events) ?> log<?= $fNvr || $fCam ? ' ' . $h(cL('(sesuai filter)', '(filtered)')) : '' ?> · <span id="selCount">0</span> <?= $h(cL('dipilih', 'selected')) ?></span>
    <div class="flex flex-wrap gap-2 ml-auto">
        <button type="submit" form="bulkDel" name="scope" value="selected" id="btnDelSel" disabled class="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 disabled:opacity-40 disabled:cursor-not-allowed"><?= icon('trash', 'w-4 h-4') ?> <?= $h(cL('Hapus yang dipilih', 'Delete selected')) ?></button>
        <?php if ($nDel): ?><button type="submit" form="bulkDel" name="scope" value="filter" data-n="<?= $nDel ?>" class="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white"><?= icon('trash', 'w-4 h-4') ?> <?= $h(cL('Hapus semua log ini', 'Delete all these entries')) ?> (<?= $nDel ?>)</button><?php endif; ?>
    </div>
</div>
<?php endif; ?>

<div class="bg-white rounded-xl shadow-sm overflow-x-auto mb-6">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-slate-500 text-xs"><tr>
            <th class="px-3 py-2 w-8"><input type="checkbox" id="chkAll" class="w-4 h-4 align-middle" title="<?= $h(cL('Pilih semua', 'Select all')) ?>"></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Mati sejak', 'Down since')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Hidup lagi', 'Back up')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Durasi', 'Duration')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Kamera', 'Camera')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Jenis', 'Type')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Penyebab terdeteksi', 'Detected cause')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Keterangan admin', 'Admin note')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($events as $e): $c = $camById[(int)$e['asset_id']] ?? null;
            $dur = $e['ended_at'] ? (int)$e['duration_sec'] : time() - strtotime((string)$e['started_at']); ?>
            <tr class="border-t align-top">
                <td class="px-3 py-2"><?php if ($e['ended_at']): ?><input type="checkbox" name="ids[]" value="<?= (int)$e['id'] ?>" form="bulkDel" class="rowChk w-4 h-4 align-middle"><?php else: ?><input type="checkbox" disabled class="w-4 h-4 align-middle opacity-30" title="<?= $h(cL('Kamera masih mati, log belum bisa dihapus', 'Camera still down, cannot delete yet')) ?>"><?php endif; ?></td>
                <td class="px-3 py-2 whitespace-nowrap tabular-nums"><?= $h(date('d M Y H:i', strtotime((string)$e['started_at']))) ?></td>
                <td class="px-3 py-2 whitespace-nowrap tabular-nums"><?= $e['ended_at'] ? $h(date('d M Y H:i', strtotime((string)$e['ended_at']))) : '<span class="px-2 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-700">' . $h(cL('Masih mati', 'Still down')) . '</span>' ?></td>
                <td class="px-3 py-2 whitespace-nowrap tabular-nums"><?= $h(cctvDuration($dur)) ?><?= $e['ended_at'] ? '' : '+' ?></td>
                <td class="px-3 py-2"><div class="font-medium"><?= $h($c ? ($c['name'] ?: $c['location']) : '#' . $e['asset_id']) ?></div><div class="text-xs text-slate-500"><?= $h(trim(($c['location'] ?? '') . ' · ' . ($c['number'] ?? ''), ' ·')) ?><?= !empty($c['nvr_name']) ? ' · ' . $h($c['nvr_name']) . (!empty($c['channel']) ? ' ch ' . (int)$c['channel'] : '') : '' ?></div></td>
                <td class="px-3 py-2"><?= cctvStateBadge((string)$e['kind']) ?></td>
                <td class="px-3 py-2 text-xs text-slate-600"><?= $h($e['detail'] ?? '') ?></td>
                <td class="px-3 py-2">
                    <form method="post" class="flex gap-1">
                        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                        <input type="hidden" name="action" value="note"><input type="hidden" name="id" value="<?= (int)$e['id'] ?>">
                        <input type="hidden" name="ym" value="<?= $h($ym) ?>"><input type="hidden" name="cam" value="<?= $fCam ?>"><input type="hidden" name="nvr" value="<?= $fNvr ?>">
                        <input type="text" name="note" value="<?= $h($e['note'] ?? '') ?>" maxlength="250" placeholder="<?= $h(cL('mis. konektor RJ45 diganti', 'e.g. RJ45 replaced')) ?>" class="border border-slate-300 rounded-lg px-2 py-1 text-sm w-56">
                        <button class="px-2 py-1 rounded-lg border border-slate-300 hover:bg-slate-50 text-xs"><?= $h(cL('Simpan', 'Save')) ?></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$events): ?><tr><td colspan="8" class="px-3 py-6 text-center text-slate-500"><?= $h(cL('Tidak ada kamera mati di periode ini.', 'No downtime in this period.')) ?></td></tr><?php endif; ?>
        </tbody>
    </table>
</div>

<h2 class="font-semibold text-slate-800 mb-2"><?= $h(cL('Rekap per kamera', 'Summary per camera')) ?> · <?= $h(cctvMonthTitle($ym)) ?></h2>
<div class="bg-white rounded-xl shadow-sm overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-slate-500 text-xs"><tr>
            <th class="text-left px-3 py-2"><?= $h(cL('Kamera', 'Camera')) ?></th><th class="text-right px-3 py-2"><?= $h(cL('Kali mati', 'Times down')) ?></th>
            <th class="text-right px-3 py-2"><?= $h(cL('Total mati', 'Total downtime')) ?></th><th class="text-right px-3 py-2">Uptime</th>
        </tr></thead>
        <tbody>
        <?php $down = $rep['down']; uasort($down, fn($a, $b) => $b['sec'] <=> $a['sec']);
        foreach ($down as $aid => $d): $c = $camById[$aid] ?? null; ?>
            <tr class="border-t">
                <td class="px-3 py-2"><?= $h($c ? ($c['name'] ?: $c['location']) . ' · ' . $c['number'] : '#' . $aid) ?></td>
                <td class="px-3 py-2 text-right tabular-nums"><?= (int)$d['n'] ?></td>
                <td class="px-3 py-2 text-right tabular-nums"><?= $h(cctvDuration((int)$d['sec'])) ?></td>
                <td class="px-3 py-2 text-right tabular-nums"><?= number_format(100 - $d['sec'] / $rep['period_sec'] * 100, 1) ?>%</td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$down): ?><tr><td colspan="4" class="px-3 py-6 text-center text-slate-500"><?= $h(cL('Semua kamera 100% online.', 'All cameras 100% online.')) ?></td></tr><?php endif; ?>
        </tbody>
    </table>
</div>

<script>
(function () {
    var all = document.getElementById('chkAll'), rows = [].slice.call(document.querySelectorAll('.rowChk')),
        cnt = document.getElementById('selCount'), btn = document.getElementById('btnDelSel');
    function upd() { var n = rows.filter(function (c) { return c.checked; }).length; if (cnt) cnt.textContent = n; if (btn) btn.disabled = !n;
        if (all) { all.checked = n > 0 && n === rows.length; all.indeterminate = n > 0 && n < rows.length; } }
    if (all) all.addEventListener('change', function () { rows.forEach(function (c) { c.checked = all.checked; }); upd(); });
    rows.forEach(function (c) { c.addEventListener('change', upd); });
    upd();
    window.cctvConfirmDel = function (ev) {
        var b = ev.submitter, n = b && b.value === 'filter' ? b.getAttribute('data-n') : rows.filter(function (c) { return c.checked; }).length;
        return confirm(<?= json_encode(cL('Hapus ', 'Delete ')) ?> + n + <?= json_encode(cL(' log CCTV mati? Data yang dihapus tidak bisa dikembalikan dan tidak lagi muncul di rekap/Excel.', ' downtime entries? This cannot be undone and they will no longer appear in reports.')) ?>);
    };
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
