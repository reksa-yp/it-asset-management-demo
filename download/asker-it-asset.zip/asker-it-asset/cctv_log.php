<?php
/** Menu CCTV > Log CCTV mati (khusus admin): riwayat kamera mati/hidup, durasi, keterangan admin, rekap bulanan. */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv.php';

$db = getDB();
ensureCctvTables($db);
$h = fn($v) => htmlspecialchars((string)$v);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'note') {
    csrfCheck();
    $db->prepare("UPDATE cctv_events SET note = ? WHERE id = ?")
       ->execute([mb_substr(trim((string)($_POST['note'] ?? '')), 0, 250) ?: null, (int)($_POST['id'] ?? 0)]);
    $_SESSION['cctv_msg'] = ['ok' => true, 'text' => cL('Keterangan disimpan.', 'Note saved.')];
    header('Location: cctv_log.php?' . http_build_query(['ym' => $_POST['ym'] ?? '', 'cam' => $_POST['cam'] ?? '']));
    exit;
}
$msg = $_SESSION['cctv_msg'] ?? null;
unset($_SESSION['cctv_msg']);

$ym  = (string)($_GET['ym'] ?? date('Y-m'));
if (!preg_match('/^\d{4}-\d{2}$/', $ym)) $ym = date('Y-m');
$fCam = (int)($_GET['cam'] ?? 0);
$rep = cctvMonthReport($db, $ym);
$events = array_values(array_filter($rep['events'], fn($e) => !$fCam || (int)$e['asset_id'] === $fCam));
usort($events, fn($a, $b) => strcmp((string)$b['started_at'], (string)$a['started_at']));
$camById = $rep['cam_by_id'];

// Pilihan bulan: 12 bulan terakhir.
$months = [];
for ($i = 0; $i < 12; $i++) { $m = date('Y-m', strtotime(date('Y-m-01') . " -$i month")); $months[$m] = cctvMonthTitle($m); }
if (!isset($months[$ym])) $months[$ym] = cctvMonthTitle($ym);

$pageTitle = cL('Log CCTV mati', 'CCTV downtime log');
$cctvTab = 'log';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<div class="flex flex-wrap items-center justify-between gap-3 mb-3">
    <div>
        <h1 class="text-xl font-semibold text-slate-800"><?= $h(cL('Log CCTV mati', 'CCTV downtime log')) ?></h1>
        <p class="text-sm text-slate-500"><?= $h(cL('Tercatat otomatis setiap kali kamera mati dan hidup kembali.', 'Recorded automatically when a camera goes down and comes back.')) ?></p>
    </div>
    <div class="flex flex-wrap gap-2 text-sm">
        <a href="cctv_report.php?mode=month&ym=<?= $h($ym) ?>&out=xlsx" class="inline-flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg px-4 py-2 font-medium"><?= icon('sheet') ?> Export Excel</a>
    </div>
</div>

<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<form method="get" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Bulan', 'Month')) ?></span>
        <select name="ym" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[160px]">
            <?php foreach ($months as $k => $label): ?><option value="<?= $h($k) ?>" <?= $k === $ym ? 'selected' : '' ?>><?= $h($label) ?></option><?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Kamera', 'Camera')) ?></span>
        <select name="cam" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[200px]">
            <option value="0"><?= $h(cL('Semua', 'All')) ?></option>
            <?php foreach ($rep['cams'] as $c): ?><option value="<?= $c['id'] ?>" <?= $fCam === $c['id'] ? 'selected' : '' ?>><?= $h($c['number'] . ' · ' . ($c['location'] ?: $c['name'])) ?></option><?php endforeach; ?>
        </select></label>
    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 font-medium"><?= $h(cL('Terapkan', 'Apply')) ?></button>
</form>

<div class="bg-white rounded-xl shadow-sm overflow-x-auto mb-6">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-slate-500 text-xs"><tr>
            <th class="text-left px-3 py-2"><?= $h(cL('Mati sejak', 'Down since')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Hidup lagi', 'Back up')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Durasi', 'Duration')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Kamera', 'Camera')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Jenis', 'Type')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Penyebab terdeteksi', 'Detected cause')) ?></th>
            <th class="text-left px-3 py-2"><?= $h(cL('Keterangan admin', 'Admin note')) ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($events as $e): $c = $camById[(int)$e['asset_id']] ?? null;
            $dur = $e['ended_at'] ? (int)$e['duration_sec'] : time() - strtotime((string)$e['started_at']); ?>
            <tr class="border-t align-top">
                <td class="px-3 py-2 whitespace-nowrap tabular-nums"><?= $h(date('d M Y H:i', strtotime((string)$e['started_at']))) ?></td>
                <td class="px-3 py-2 whitespace-nowrap tabular-nums"><?= $e['ended_at'] ? $h(date('d M Y H:i', strtotime((string)$e['ended_at']))) : '<span class="px-2 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-700">' . $h(cL('Masih mati', 'Still down')) . '</span>' ?></td>
                <td class="px-3 py-2 whitespace-nowrap tabular-nums"><?= $h(cctvDuration($dur)) ?><?= $e['ended_at'] ? '' : '+' ?></td>
                <td class="px-3 py-2"><div class="font-medium"><?= $h($c ? ($c['location'] ?: $c['name']) : '#' . $e['asset_id']) ?></div><div class="text-xs text-slate-500"><?= $h($c['number'] ?? '') ?></div></td>
                <td class="px-3 py-2"><?= cctvStateBadge((string)$e['kind']) ?></td>
                <td class="px-3 py-2 text-xs text-slate-600"><?= $h($e['detail'] ?? '') ?></td>
                <td class="px-3 py-2">
                    <form method="post" class="flex gap-1">
                        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                        <input type="hidden" name="action" value="note"><input type="hidden" name="id" value="<?= (int)$e['id'] ?>">
                        <input type="hidden" name="ym" value="<?= $h($ym) ?>"><input type="hidden" name="cam" value="<?= $fCam ?>">
                        <input type="text" name="note" value="<?= $h($e['note'] ?? '') ?>" maxlength="250" placeholder="<?= $h(cL('mis. konektor RJ45 diganti', 'e.g. RJ45 replaced')) ?>" class="border border-slate-300 rounded-lg px-2 py-1 text-sm w-56">
                        <button class="px-2 py-1 rounded-lg border border-slate-300 hover:bg-slate-50 text-xs"><?= $h(cL('Simpan', 'Save')) ?></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$events): ?><tr><td colspan="7" class="px-3 py-6 text-center text-slate-500"><?= $h(cL('Tidak ada kamera mati di periode ini.', 'No downtime in this period.')) ?></td></tr><?php endif; ?>
        </tbody>
    </table>
</div>

<h2 class="font-semibold text-slate-800 mb-2"><?= $h(cL('Rekap per kamera', 'Summary per camera')) ?> · <?= $h(cctvMonthTitle($ym)) ?></h2>
<div class="bg-white rounded-xl shadow-sm overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="bg-slate-50 text-slate-500 text-xs"><tr>
            <th class="text-left px-3 py-2"><?= $h(cL('Kamera', 'Camera')) ?></th><th class="text-right px-3 py-2"><?= $h(cL('Kali mati', 'Times down')) ?></th>
            <th class="text-right px-3 py-2"><?= $h(cL('Total mati', 'Total downtime')) ?></th><th class="text-right px-3 py-2">Uptime</th>
        </tr></thead>
        <tbody>
        <?php $down = $rep['down']; uasort($down, fn($a, $b) => $b['sec'] <=> $a['sec']);
        foreach ($down as $aid => $d): $c = $camById[$aid] ?? null; ?>
            <tr class="border-t">
                <td class="px-3 py-2"><?= $h($c ? ($c['location'] ?: $c['name']) . ' · ' . $c['number'] : '#' . $aid) ?></td>
                <td class="px-3 py-2 text-right tabular-nums"><?= (int)$d['n'] ?></td>
                <td class="px-3 py-2 text-right tabular-nums"><?= $h(cctvDuration((int)$d['sec'])) ?></td>
                <td class="px-3 py-2 text-right tabular-nums"><?= number_format(100 - $d['sec'] / $rep['period_sec'] * 100, 1) ?>%</td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$down): ?><tr><td colspan="4" class="px-3 py-6 text-center text-slate-500"><?= $h(cL('Semua kamera 100% online.', 'All cameras 100% online.')) ?></td></tr><?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
