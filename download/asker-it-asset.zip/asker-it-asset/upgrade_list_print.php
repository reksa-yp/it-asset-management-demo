<?php
/**
 * Versi cetak (print) untuk daftar "Aset Perlu Di-Upgrade" di Dashboard.
 * Memakai query yang sama persis dengan dashboard.php (lihat includes/upgrade_alert.php).
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/upgrade_alert.php';

$db = getDB();
$upgradeAssets = getUpgradeAssets($db);
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars(t('upgrade_list_title')) ?></title>
<style>
    body { font-family: Arial, sans-serif; margin: 24px; color: #1e293b; }
    h1 { font-size: 18px; margin: 0 0 4px; }
    p.sub { font-size: 12px; color: #64748b; margin: 0 0 18px; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; }
    th, td { border: 1px solid #cbd5e1; padding: 6px 8px; text-align: left; vertical-align: top; }
    th { background: #f1f5f9; }
    .no-print { margin-top: 20px; text-align: center; }
    .no-print button {
        background: #1F3DD1; color: #fff; border: none; border-radius: 6px;
        padding: 8px 18px; font-size: 13px; cursor: pointer;
    }
    .empty { color: #94a3b8; font-style: italic; }
    @media print { .no-print { display: none; } }
</style>
</head>
<body>
    <h1><?= htmlspecialchars(t('upgrade_list_title')) ?></h1>
    <p class="sub"><?= htmlspecialchars(t('upgrade_list_subtitle')) ?> &bull; <?= htmlspecialchars(t('printed_at')) ?>: <?= date('d M Y H:i') ?></p>

    <?php if ($upgradeAssets): ?>
    <table>
        <thead>
            <tr>
                <th><?= t('th_asset_no') ?></th>
                <th><?= t('th_type') ?></th>
                <th><?= t('th_department') ?></th>
                <th><?= t('th_ticket_no') ?></th>
                <th><?= t('upgrade_note_label') ?></th>
                <th><?= t('th_date') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($upgradeAssets as $ua): ?>
            <tr>
                <td><?= htmlspecialchars($ua['device_name'] ?: $ua['asset_number']) ?></td>
                <td><?= htmlspecialchars($ua['category']) ?></td>
                <td><?= htmlspecialchars($ua['department'] ?: t('dash')) ?></td>
                <td><?= htmlspecialchars($ua['ticket_number']) ?></td>
                <td><?= htmlspecialchars($ua['matched_text'] ?? '') ?></td>
                <td><?= date('d M Y', strtotime($ua['ticket_date'])) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p class="empty"><?= t('upgrade_list_empty') ?></p>
    <?php endif; ?>

    <div class="no-print">
        <button onclick="window.print()"><?= htmlspecialchars(t('btn_print')) ?></button>
    </div>
</body>
</html>
