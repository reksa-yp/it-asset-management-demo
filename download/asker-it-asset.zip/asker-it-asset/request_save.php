<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
require_once __DIR__ . '/includes/request_feature.php';
require_once __DIR__ . '/includes/notifications.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: request.php'); exit; }
csrfCheck();

$type = trim($_POST['request_type'] ?? 'Baru');
$category = trim($_POST['category'] ?? '');
$description = trim($_POST['item_description'] ?? '');
$reason = trim($_POST['reason'] ?? '');
$descriptionEn = trim((string)($_POST['item_description_en'] ?? ''));
$reasonEn = trim((string)($_POST['reason_en'] ?? ''));
if ($descriptionEn === '') $descriptionEn = null;
if ($reasonEn === '') $reasonEn = null;
$allowedCategories = ['Aksesoris', 'Desktop PC', 'Laptop', 'Lainnya'];
if (!in_array($type, ['Baru', 'Penggantian'], true) ||
    !in_array($category, $allowedCategories, true) ||
    $description === '' || $reason === '') {
    $_SESSION['request_flash'] = ['type'=>'error','message'=>'Mohon lengkapi semua kolom pengajuan dan alasan.'];
    header('Location: request.php'); exit;
}

$image = null;
$upload = $_FILES['request_image'] ?? null;
if ($type === 'Penggantian' && (!$upload || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE)) {
    $_SESSION['request_flash'] = ['type'=>'error','message'=>'Foto barang yang ingin diganti wajib dilampirkan untuk pengajuan penggantian.'];
    header('Location: request.php'); exit;
}
if ($upload && ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
    if ($upload['error'] !== UPLOAD_ERR_OK || $upload['size'] > 8 * 1024 * 1024) {
        $_SESSION['request_flash'] = ['type'=>'error','message'=>'Gambar gagal diunggah atau ukurannya melebihi 8 MB.']; header('Location: request.php'); exit;
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($upload['tmp_name']);
    $exts = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
    if (!isset($exts[$mime])) {
        $_SESSION['request_flash'] = ['type'=>'error','message'=>'Format gambar harus JPG, PNG, WEBP, atau GIF.']; header('Location: request.php'); exit;
    }
    $folder = __DIR__ . '/assets/uploads/requests';
    if (!is_dir($folder) && !mkdir($folder, 0750, true) && !is_dir($folder)) {
        $_SESSION['request_flash'] = ['type'=>'error','message'=>'Folder penyimpanan gambar tidak dapat dibuat.']; header('Location: request.php'); exit;
    }
    $filename = 'request_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $exts[$mime];
    if (!move_uploaded_file($upload['tmp_name'], $folder . '/' . $filename)) {
        $_SESSION['request_flash'] = ['type'=>'error','message'=>'Gambar gagal disimpan. Silakan coba kembali.']; header('Location: request.php'); exit;
    }
    $image = 'assets/uploads/requests/' . $filename;
}

$db = getDB();
ensureRequestTable($db);
$submitterId = (int)$_SESSION['user_id'];
$targetChoice = trim((string)($_POST['target_user_id'] ?? $submitterId));
$manualName = trim((string)($_POST['target_manual_name'] ?? ''));
$manualDepartment = trim((string)($_POST['target_manual_department'] ?? ''));
$targetManual = ($targetChoice === 'manual');
if ($targetManual) {
    if ($manualName === '' || $manualDepartment === '' || mb_strlen($manualName) > 190 || mb_strlen($manualDepartment) > 120) {
        $_SESSION['request_flash'] = ['type'=>'error','message'=>'Nama dan departemen orang baru wajib diisi.'];
        header('Location: request.php'); exit;
    }
    if (!isAdmin()) {
        $deptStmt = $db->prepare("SELECT department FROM users WHERE id=? AND is_active=1 LIMIT 1");
        $deptStmt->execute([$submitterId]);
        $submitterDept = trim((string)$deptStmt->fetchColumn());
        if ($submitterDept === '' || mb_strtolower($manualDepartment) !== mb_strtolower($submitterDept)) {
            $_SESSION['request_flash'] = ['type'=>'error','message'=>'Pengajuan manual hanya diperbolehkan untuk orang dalam departemen Anda sendiri.'];
            header('Location: request.php'); exit;
        }
    }
    // User tanpa akun diwakili dengan user_id pengaju, sementara nama dan departemen target disimpan terpisah.
    $targetUserId = $submitterId;
} else {
    $requestedTarget = filter_var($targetChoice, FILTER_VALIDATE_INT);
    if (!$requestedTarget || $requestedTarget < 1) {
        $_SESSION['request_flash'] = ['type'=>'error','message'=>'User tujuan pengajuan tidak valid.'];
        header('Location: request.php'); exit;
    }
    if (isAdmin()) {
        $checkUser = $db->prepare("SELECT id FROM users WHERE id=? AND is_active=1 LIMIT 1");
        $checkUser->execute([$requestedTarget]);
    } else {
        $deptStmt = $db->prepare("SELECT department FROM users WHERE id=? AND is_active=1 LIMIT 1");
        $deptStmt->execute([$submitterId]);
        $submitterDept = $deptStmt->fetchColumn();
        $checkUser = $db->prepare("SELECT id FROM users WHERE id=? AND is_active=1 AND (id=? OR (department IS NOT NULL AND department <> '' AND department=?)) LIMIT 1");
        $checkUser->execute([$requestedTarget, $submitterId, $submitterDept]);
    }
    if (!$checkUser->fetchColumn()) {
        $_SESSION['request_flash'] = ['type'=>'error','message'=> isAdmin() ? 'User tujuan tidak ditemukan atau tidak aktif.' : 'Anda hanya dapat mengajukan untuk user aktif dalam departemen yang sama.'];
        header('Location: request.php'); exit;
    }
    $targetUserId = (int)$requestedTarget;
    $manualName = null; $manualDepartment = null;
}
$number = 'REQ-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
$stmt = $db->prepare("INSERT INTO user_requests (request_number,user_id,submitted_by_user_id,target_manual_name,target_manual_department,request_type,category,item_description,reason,item_description_en,reason_en,image_path) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
$stmt->execute([$number,$targetUserId,$submitterId,$manualName,$manualDepartment,$type,$category,$description,$reason,$descriptionEn,$reasonEn,$image]);
// Notifikasi pengajuan baru hanya dikirim kepada admin aktif.
try {
    $actorId = (int)($_SESSION['user_id'] ?? 0);
    $targetNameStmt = $db->prepare('SELECT full_name, department FROM users WHERE id = ? LIMIT 1');
    $targetNameStmt->execute([$targetUserId]);
    $targetUser = $targetNameStmt->fetch(PDO::FETCH_ASSOC) ?: [];
    $targetName = $targetManual ? $manualName : trim((string)($targetUser['full_name'] ?? 'User'));
    $body = $targetName . ' · ' . $type . ' · ' . $category;
    notifToAdmins($db, 'request', 'request_new', 'Pengajuan baru: ' . $number, $body, 'request.php', (int)$db->lastInsertId(), 'r:' . $number, $actorId);
} catch (Throwable $e) { /* Notifikasi tidak boleh menggagalkan penyimpanan pengajuan. */ }
$_SESSION['request_flash'] = ['type'=>'success','message'=>'Pengajuan berhasil dikirim dengan nomor ' . $number . '.'];
header('Location: request.php'); exit;
