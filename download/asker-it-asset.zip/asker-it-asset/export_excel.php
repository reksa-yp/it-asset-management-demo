<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/vendor/autoload.php'; // composer require phpoffice/phpspreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

$db = getDB();

// ===== Cakupan export =====
// 1) Kalau ada ids[] (dari baris yang dicentang di assets.php) -> export HANYA aset itu.
// 2) Kalau tidak, tapi ada q/category/department -> export sesuai pencarian/filter
//    yang sedang aktif (mis. filter Jenis Aset = "Desktop PC" -> export cuma Desktop PC).
// 3) Kalau tidak ada keduanya -> export seluruh data, seperti sebelumnya.
$ids        = array_filter(array_map('intval', (array)($_GET['ids'] ?? [])), fn($v) => $v > 0);
$search     = trim($_GET['q'] ?? '');
// Kategori sekarang bisa lebih dari satu (category[]=...&category[]=...), tapi
// tetap kompatibel dengan link lama yang mengirim category=... tunggal.
$categoryParam = $_GET['category'] ?? [];
$categories = array_values(array_filter(array_map('trim', (array)$categoryParam), fn($v) => $v !== ''));
// Departement juga bisa lebih dari satu (department[]=...), tetap kompatibel dengan department=... tunggal.
$departments = array_values(array_unique(array_filter(array_map('trim', (array)($_GET['department'] ?? [])), fn($v) => $v !== '')));

$location = trim((string)($_GET['location'] ?? ''));   // filter Lokasi dari daftar Aset (opsional)

$conditions = [];
$params = [];
$filenameParts = [];

if ($ids) {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $conditions[] = "a.id IN ($placeholders)";
    array_push($params, ...$ids);
    $filenameParts[] = 'terpilih';
} else {
    if ($search !== '') {
        // Pencarian nama pengguna sekarang lewat tabel asset_owners (1 aset
        // bisa dipakai beberapa pengguna). Lihat includes/asset_owners.php.
        if (assetOwnersTableExists($db)) {
            $conditions[] = "(a.asset_number LIKE ? OR a.device_name LIKE ? OR a.hostname LIKE ?
                OR EXISTS (SELECT 1 FROM asset_owners ao JOIN users u2 ON u2.id = ao.user_id
                            WHERE ao.asset_id = a.id AND u2.full_name LIKE ?))";
            $like = "%$search%";
            array_push($params, $like, $like, $like, $like);
        } else {
            $conditions[] = "(a.asset_number LIKE ? OR a.device_name LIKE ? OR a.hostname LIKE ?)";
            $like = "%$search%";
            array_push($params, $like, $like, $like);
        }
    }
    if ($categories) {
        $placeholders = implode(',', array_fill(0, count($categories), '?'));
        $conditions[] = "a.category IN ($placeholders)";
        array_push($params, ...$categories);
        // Nama file memuat nama kategori, mis. inventory_export_Desktop_PC_Laptop_....xlsx
        // (lebih dari 3 kategori -> disingkat "5_kategori").
        $filenameParts[] = count($categories) <= 3
            ? implode('_', array_map(fn($c) => trim(preg_replace('/[^A-Za-z0-9]+/', '_', $c), '_'), $categories))
            : count($categories) . '_kategori';
    }
    if ($departments) {
        $conditions[] = "a.department IN (" . implode(',', array_fill(0, count($departments), '?')) . ")";
        array_push($params, ...$departments);
        $filenameParts[] = count($departments) <= 3
            ? implode('_', array_map(fn($d) => trim(preg_replace('/[^A-Za-z0-9]+/', '_', $d), '_'), $departments))
            : count($departments) . '_departement';
    }
    if ($location !== '') {
        $conditions[] = "TRIM(a.location) = ?";
        $params[] = $location;
        $filenameParts[] = trim(preg_replace('/[^A-Za-z0-9]+/', '_', $location), '_');
    }
}

$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';

// Ambil data aset
$stmt = $db->prepare("
    SELECT a.* FROM assets a" . $where . "
    ORDER BY a.asset_number
");
$stmt->execute($params);
$assets = $stmt->fetchAll();

// Pengguna tiap aset (bisa lebih dari satu), diambil sekaligus.
$ownersMap = getAssetOwnersMap($db, array_column($assets, 'id'));
$ownerPositionMap = getUserPositionMap($db); // [id user => jabatan]
// Software tiap aset (bisa lebih dari satu), diambil sekaligus juga.
$softwareMap = getAssetSoftwareMap($db, array_column($assets, 'id'));

// ===== Export khusus Tablet =====
// Tablet SELALU diekspor dengan kolom khususnya sendiri (14 kolom, lihat includes/tablet_excel.php):
// ID Aset, Kategori, Pengguna, Departement, Lokasi, Serial Number, IP Address, Received Date,
// ID Tablet, Brand Type, Status Kondisi, Tanggal Input.
// File hasil export ini bisa langsung di-import lagi (menu Import dari Excel).
// - Isinya tablet saja          -> file hanya berisi 1 sheet "Inventory" berformat tablet.
// - Campuran tablet + jenis lain -> sheet "Inventory" (tanpa tablet) + sheet "Tablet".
require_once __DIR__ . '/includes/tablet_excel.php';
require_once __DIR__ . '/includes/xls_number.php';   // kolom No + kop/judul export
$tabletAssets = array_values(array_filter($assets, fn($a) => isTabletCategory($a['category'])));
$assets       = array_values(array_filter($assets, fn($a) => !isTabletCategory($a['category'])));
$tabletDetailsMap = getTabletDetailsMap($db, array_column($tabletAssets, 'id'));

$writeTabletSheet = function ($sheet, array $tabletAssets, string $title) use ($ownersMap, $tabletDetailsMap) {
    writeTabletSheet($sheet, $tabletAssets, $ownersMap, $tabletDetailsMap, $title);
};

// Hanya tablet -> file berisi 1 sheet "Inventory" berformat tablet (sama dengan file contoh).
if ($tabletAssets && !$assets) {
    $spreadsheet = new Spreadsheet();
    $writeTabletSheet($spreadsheet->getActiveSheet(), $tabletAssets, 'Inventory');
    $scopeSuffix = $filenameParts ? '_' . implode('_', $filenameParts) : '';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="inventory_export' . ($scopeSuffix ?: '_Tablet') . '_' . date('Ymd_His') . '.xlsx"');
    header('Cache-Control: max-age=0');
    (new Xlsx($spreadsheet))->save('php://output');
    exit;
}

// Riwayat tiket & riwayat perbaikan per aset, digabung jadi 1 sel (ringkas)
$ticketStmt = $db->prepare("
    SELECT ticket_number, status, created_at
    FROM tickets WHERE asset_id = ? ORDER BY created_at DESC
");

// ===== Header kolom mengikuti bahasa aktif user (ID/EN) via t(). Saat bahasa
// Indonesia, teksnya PERSIS sama dengan template_inventory_it.xlsx =====
$headers = [
    t('xls_hdr_asset_id'), t('xls_hdr_category'), t('xls_hdr_device_name'), t('xls_hdr_users'),
    t('xls_hdr_position'), // jabatan pengguna aset (kolom tambahan, diabaikan saat import)
    t('xls_hdr_department'), t('xls_hdr_ip'), t('xls_hdr_hostname'),
    t('xls_hdr_os'), t('xls_hdr_serial'), t('xls_hdr_os_status'), // kolom tambahan, di luar template asli
    t('xls_hdr_software'), t('xls_hdr_serial'), t('xls_hdr_software_status'), // kolom tambahan, di luar template asli
    t('xls_hdr_motherboard'), t('xls_hdr_processor'), t('xls_hdr_ram'), t('xls_hdr_storage'), t('xls_hdr_location'),
    t('xls_hdr_status'), t('xls_hdr_input_date'), t('xls_hdr_printer'), t('xls_hdr_monitor'), t('xls_hdr_accessories'),
    t('xls_hdr_ticket_history'), t('xls_hdr_repair_history'),
    t('xls_hdr_user_email'), // kolom tambahan, di luar template asli
    t('xls_hdr_pc_username'), t('xls_hdr_pc_password'), // kolom tambahan, login PC/laptop aset (data referensi IT)
    t('xls_hdr_purchase_date'), // kolom tambahan, di luar template asli
];

// Nilai status (Digunakan/Stok/Tidak Digunakan) diterjemahkan mengikuti bahasa aktif.
$assetStatusLangKey = ['Digunakan' => 'status_used', 'Stok' => 'status_stock', 'Tidak Digunakan' => 'status_unused'];

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Inventory');

// Tulis header (baris 1)
$sheet->fromArray($headers, null, 'A1');

// Susun data jadi array 2 dimensi dulu, baru tulis sekaligus (lebih stabil lintas versi PhpSpreadsheet)
$dataRows = [];
foreach ($assets as $a) {
    $ticketStmt->execute([$a['id']]);
    $tix = $ticketStmt->fetchAll();

    $riwayatTiket = implode('; ', array_map(
        fn($t) => $t['ticket_number'] . ' (' . date('d/m/Y H:i', strtotime($t['created_at'])) . ')',
        $tix
    ));
    $riwayatPerbaikan = implode('; ', array_map(
        fn($t) => $t['ticket_number'] . ': ' . $t['status'],
        $tix
    ));

    // Software bisa lebih dari satu -> tiap kolom digabung dipisah "; ", urutan
    // sejajar antar kolom (item ke-1 di Software = item ke-1 di Serial Number & Status).
    $softwareItems = $softwareMap[$a['id']] ?? [];
    $softwareNames  = $softwareItems ? implode('; ', array_column($softwareItems, 'software_name')) : '';
    $softwareSerials = $softwareItems ? implode('; ', array_map(fn($si) => $si['serial_number'] ?: '-', $softwareItems)) : '';
    $softwareStatuses = $softwareItems ? implode('; ', array_map(fn($si) => t($si['status'] === 'Original' ? 'os_original' : 'os_not_original'), $softwareItems)) : '';

    $dataRows[] = [
        $a['asset_number'],
        $a['category'],
        $a['device_name'],
        ownerNamesLabel($ownersMap[$a['id']] ?? []),
        ownerPositionsLabel($ownersMap[$a['id']] ?? [], $ownerPositionMap),
        $a['department'],
        $a['ip_address'],
        $a['hostname'],
        $a['os_name'],
        $a['serial_number'],
        t($a['os_status'] === 'Original' ? 'os_original' : 'os_not_original'),
        $softwareNames,
        $softwareSerials,
        $softwareStatuses,
        $a['motherboard_brand'] ?? '',
        $a['processor'],
        $a['ram'],
        $a['storage'],
        $a['location'],
        isset($assetStatusLangKey[$a['status']]) ? t($assetStatusLangKey[$a['status']]) : $a['status'],
        date('Y-m-d', strtotime($a['created_at'])),
        $a['printer_info'],
        $a['monitor_info'],
        $a['accessories'],
        $riwayatTiket ?: '-',
        $riwayatPerbaikan ?: '-',
        $a['owner_email'],
        $a['pc_username'],
        $a['pc_password'],
        !empty($a['purchase_date'] ?? null) ? date('Y-m-d', strtotime($a['purchase_date'])) : '',
    ];
}

if ($dataRows) {
    $sheet->fromArray($dataRows, null, 'A2');
}

$lastCol = count($headers);
$lastRow = 1 + count($dataRows);

// ===== Styling: header bold + background, border seluruh tabel, auto-fit kolom =====
$headerRange = 'A1:' . \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($lastCol) . '1';
$sheet->getStyle($headerRange)->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
$sheet->getStyle($headerRange)->getFill()
      ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
$sheet->getStyle($headerRange)->getAlignment()->setHorizontal('center');

if ($lastRow >= 1) {
    $fullRange = 'A1:' . \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($lastCol) . $lastRow;
    $sheet->getStyle($fullRange)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
}

// Auto-fit lebar kolom
for ($c = 1; $c <= $lastCol; $c++) {
    $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($c);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}
$sheet->freezePane('A2');

// Kolom No di paling kiri, lalu kop + judul otomatis + tanggal dibuat + jumlah aset di atas tabel.
xlsAddNumberColumn($sheet, 1, $lastRow);
xlsAddAssetTitleBlock($sheet, array_column($assets, 'category'), count($assets));

// Campuran: tablet ditaruh di sheet terpisah "Tablet" dengan kolom khususnya.
if ($tabletAssets) {
    $writeTabletSheet($spreadsheet->createSheet(), $tabletAssets, 'Tablet');
    $spreadsheet->setActiveSheetIndex(0);
}

// ===== Output =====
$scopeSuffix = $filenameParts ? '_' . implode('_', $filenameParts) : '';
$filename = 'inventory_export' . $scopeSuffix . '_' . date('Ymd_His') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
