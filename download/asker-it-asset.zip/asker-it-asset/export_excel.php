<?php
require_once __DIR__ . '/includes/auth.php';
requireAdminOrQme();   // admin, atau user QME (khusus aset Tablet)
require_once __DIR__ . '/vendor/autoload.php'; // composer require phpoffice/phpspreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

$db = getDB();

// ===== Cakupan export =====
// 1) Kalau ada ids[] (dari baris yang dicentang di assets.php) -> export HANYA aset itu.
// 2) Kalau tidak, tapi ada q/category/department -> export sesuai pencarian/filter
//    yang sedang aktif (mis. filter Jenis Aset = "Desktop PC" -> export cuma Desktop PC).
// 3) Kalau tidak ada keduanya -> export seluruh data, seperti sebelumnya.
$ids        = array_filter(array_map('intval', (array)($_GET['ids'] ?? [])), fn($v) => $v > 0);
$search     = trim($_GET['q'] ?? '');
// Kategori sekarang bisa lebih dari satu (category[]=...&category[]=...), tapi
// tetap kompatibel dengan link lama yang mengirim category=... tunggal.
$categoryParam = $_GET['category'] ?? [];
$categories = array_values(array_filter(array_map('trim', (array)$categoryParam), fn($v) => $v !== ''));
// Departement juga bisa lebih dari satu (department[]=...), tetap kompatibel dengan department=... tunggal.
$departments = array_values(array_unique(array_filter(array_map('trim', (array)($_GET['department'] ?? [])), fn($v) => $v !== '')));

// Lokasi juga bisa lebih dari satu (location[]=...), tetap kompatibel dengan location=... tunggal.
$locations = array_values(array_unique(array_filter(array_map('trim', (array)($_GET['location'] ?? [])), fn($v) => $v !== '')));

$conditions = [];
$params = [];
$filenameParts = [];

if ($ids) {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $conditions[] = "a.id IN ($placeholders)";
    array_push($params, ...$ids);
    $filenameParts[] = 'terpilih';
} else {
    if ($search !== '') {
        // Pencarian nama pengguna sekarang lewat tabel asset_owners (1 aset
        // bisa dipakai beberapa pengguna). Lihat includes/asset_owners.php.
        if (assetOwnersTableExists($db)) {
            $conditions[] = "(a.asset_number LIKE ? OR a.device_name LIKE ? OR a.hostname LIKE ?
                OR EXISTS (SELECT 1 FROM asset_owners ao JOIN users u2 ON u2.id = ao.user_id
                            WHERE ao.asset_id = a.id AND u2.full_name LIKE ?))";
            $like = "%$search%";
            array_push($params, $like, $like, $like, $like);
        } else {
            $conditions[] = "(a.asset_number LIKE ? OR a.device_name LIKE ? OR a.hostname LIKE ?)";
            $like = "%$search%";
            array_push($params, $like, $like, $like);
        }
    }
    if ($categories) {
        $placeholders = implode(',', array_fill(0, count($categories), '?'));
        $conditions[] = "a.category IN ($placeholders)";
        array_push($params, ...$categories);
        // Nama file memuat nama kategori, mis. inventory_export_Desktop_PC_Laptop_....xlsx
        // (lebih dari 3 kategori -> disingkat "5_kategori").
        $filenameParts[] = count($categories) <= 3
            ? implode('_', array_map(fn($c) => trim(preg_replace('/[^A-Za-z0-9]+/', '_', $c), '_'), $categories))
            : count($categories) . '_kategori';
    }
    if ($departments) {
        // '__none__' = "(Tanpa departemen)" dari filter daftar Aset
        $deptVals = array_values(array_filter($departments, fn($d) => $d !== '__none__'));
        $deptOr = [];
        if ($deptVals) { $deptOr[] = "a.department IN (" . implode(',', array_fill(0, count($deptVals), '?')) . ")"; array_push($params, ...$deptVals); }
        if (in_array('__none__', $departments, true)) $deptOr[] = "(a.department IS NULL OR TRIM(a.department) = '')";
        $conditions[] = '(' . implode(' OR ', $deptOr) . ')';
        $filenameParts[] = count($departments) <= 3
            ? implode('_', array_map(fn($d) => $d === '__none__' ? 'tanpa_dept' : trim(preg_replace('/[^A-Za-z0-9]+/', '_', $d), '_'), $departments))
            : count($departments) . '_departement';
    }
    if ($locations) {
        $conditions[] = "TRIM(a.location) IN (" . implode(',', array_fill(0, count($locations), '?')) . ")";
        array_push($params, ...$locations);
        $filenameParts[] = count($locations) <= 2
            ? implode('_', array_map(fn($l) => trim(preg_replace('/[^A-Za-z0-9]+/', '_', $l), '_'), $locations))
            : count($locations) . '_lokasi';
    }
}

// User QME: export selalu dibatasi ke aset kategori Tablet.
if (!isAdmin()) {
    $qc = qmeTabletCategories($db);
    $conditions[] = "a.category IN (" . implode(',', array_fill(0, count($qc), '?')) . ")";
    array_push($params, ...$qc);
}
$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';

// Ambil data aset
$stmt = $db->prepare("
    SELECT a.* FROM assets a" . $where . "
    ORDER BY a.asset_number
");
$stmt->execute($params);
$assets = $stmt->fetchAll();

// Pengguna tiap aset (bisa lebih dari satu), diambil sekaligus.
$ownersMap = getAssetOwnersMap($db, array_column($assets, 'id'));
$ownerPositionMap = getUserPositionMap($db); // [id user => jabatan]
// Software tiap aset (bisa lebih dari satu), diambil sekaligus juga.
$softwareMap = getAssetSoftwareMap($db, array_column($assets, 'id'));

// ===== Export khusus Tablet =====
// Tablet SELALU diekspor dengan kolom khususnya sendiri (14 kolom, lihat includes/tablet_excel.php):
// ID Aset, Kategori, Pengguna, Departement, Lokasi, Serial Number, IP Address, Received Date,
// ID Tablet, Brand Type, Status Kondisi, Tanggal Input.
// File hasil export ini bisa langsung di-import lagi (menu Import dari Excel).
// - Isinya tablet saja          -> file hanya berisi 1 sheet "Inventory" berformat tablet.
// - Campuran tablet + jenis lain -> sheet "Inventory" (tanpa tablet) + sheet "Tablet".
require_once __DIR__ . '/includes/tablet_excel.php';
require_once __DIR__ . '/includes/xls_number.php';   // kolom No + kop/judul export
require_once __DIR__ . '/includes/spec_standard.php'; // isian Graphic Card / VGA (tabel asset_gpu)
$tabletAssets = array_values(array_filter($assets, fn($a) => isTabletCategory($a['category'])));
$assets       = array_values(array_filter($assets, fn($a) => !isTabletCategory($a['category'])));
// Ext Telepon juga punya format kolom sendiri (lihat includes/ext_phone.php).
$extAssets    = array_values(array_filter($assets, fn($a) => isExtPhoneCategory($a['category'])));
$assets       = array_values(array_filter($assets, fn($a) => !isExtPhoneCategory($a['category'])));
// CCTV / NVR dan perangkat jaringan (router, switch, hub, AP): format kolom SAMA dengan template import-nya,
// supaya file export bisa langsung diedit lalu diimport ulang (tanpa kolom pengguna, riwayat tiket, dll.).
require_once __DIR__ . '/includes/net_import.php';   // juga memuat includes/cctv_import.php
$cctvAssets = array_values(array_filter($assets, fn($a) => isCctvCategory($a['category']) || isNvrCategory($a['category'])));
$assets     = array_values(array_filter($assets, fn($a) => !(isCctvCategory($a['category']) || isNvrCategory($a['category']))));
$netAssets  = array_values(array_filter($assets, fn($a) => isNetDeviceCategory($a['category'])));
$assets     = array_values(array_filter($assets, fn($a) => !isNetDeviceCategory($a['category'])));
$scopeSuffix = $filenameParts ? '_' . implode('_', $filenameParts) : '';
$sendXlsx = function (Spreadsheet $ss, string $name) {
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $name . '_' . date('Ymd_His') . '.xlsx"');
    header('Cache-Control: max-age=0');
    (new Xlsx($ss))->save('php://output');
    exit;
};
$groups = array_filter(['other' => $assets, 'tablet' => $tabletAssets, 'ext' => $extAssets, 'cctv' => $cctvAssets, 'net' => $netAssets]);
// Hanya CCTV / NVR -> file format Import CCTV (sheet CCTV + NVR + petunjuk), isi aset yang diexport.
if (array_keys($groups) === ['cctv']) {
    $ss = new Spreadsheet();
    writeCctvImportTemplate($db, $ss, true, array_column($cctvAssets, 'id'));
    $sendXlsx($ss, 'data_cctv_nvr' . $scopeSuffix);
}
// Hanya router / switch / hub / AP -> file format Import Perangkat Jaringan.
if (array_keys($groups) === ['net']) {
    $ss = new Spreadsheet();
    writeNetImportTemplate($db, $ss, true, array_column($netAssets, 'id'));
    $sendXlsx($ss, 'data_perangkat_jaringan' . $scopeSuffix);
}
/** Salin sheet data dari workbook template ke file export campuran (tanpa dropdown, karena sheet daftarnya tidak ikut). */
$appendSheets = function (Spreadsheet $target, Spreadsheet $src, array $names) {
    foreach ($names as $n) {
        $ws = $src->getSheetByName($n);
        if (!$ws || trim((string)$ws->getCell('C9')->getValue() . $ws->getCell('B9')->getValue()) === '') continue;   // sheet tanpa data dilewati
        foreach (array_keys($ws->getDataValidationCollection()) as $coord) $ws->setDataValidation($coord, null);
        $target->addExternalSheet($ws);
    }
};
$tabletDetailsMap = getTabletDetailsMap($db, array_column($tabletAssets, 'id'));

$writeTabletSheet = function ($sheet, array $tabletAssets, string $title) use ($ownersMap, $tabletDetailsMap) {
    writeTabletSheet($sheet, $tabletAssets, $ownersMap, $tabletDetailsMap, $title);
};

// Hanya Ext Telepon -> file berisi 1 sheet "Inventory" berformat Ext Telepon.
if (array_keys($groups) === ['ext']) {
    $spreadsheet = new Spreadsheet();
    writeExtPhoneSheet($spreadsheet->getActiveSheet(), $extAssets, $ownersMap, 'Inventory');
    $scopeSuffix = $filenameParts ? '_' . implode('_', $filenameParts) : '';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="inventory_export' . ($scopeSuffix ?: '_Ext_Telepon') . '_' . date('Ymd_His') . '.xlsx"');
    header('Cache-Control: max-age=0');
    (new Xlsx($spreadsheet))->save('php://output');
    exit;
}

// Hanya tablet -> file berisi 1 sheet "Inventory" berformat tablet (sama dengan file contoh).
if (array_keys($groups) === ['tablet']) {
    $spreadsheet = new Spreadsheet();
    $writeTabletSheet($spreadsheet->getActiveSheet(), $tabletAssets, 'Inventory');
    $scopeSuffix = $filenameParts ? '_' . implode('_', $filenameParts) : '';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="inventory_export' . ($scopeSuffix ?: '_Tablet') . '_' . date('Ymd_His') . '.xlsx"');
    header('Cache-Control: max-age=0');
    (new Xlsx($spreadsheet))->save('php://output');
    exit;
}

// Riwayat tiket & riwayat perbaikan per aset, digabung jadi 1 sel (ringkas)
$ticketStmt = $db->prepare("
    SELECT ticket_number, status, created_at
    FROM tickets WHERE asset_id = ? ORDER BY created_at DESC
");

// ===== Header kolom mengikuti bahasa aktif user (ID/EN) via t(). Saat bahasa
// Indonesia, teksnya PERSIS sama dengan template_inventory_it.xlsx =====
$headers = [
    t('xls_hdr_asset_id'), t('xls_hdr_category'), t('xls_hdr_device_name'), t('xls_hdr_users'),
    t('xls_hdr_position'), // jabatan pengguna aset (kolom tambahan, diabaikan saat import)
    t('xls_hdr_department'), t('xls_hdr_ip'), t('xls_hdr_hostname'),
    t('xls_hdr_os'), t('xls_hdr_serial'), t('xls_hdr_os_status'), // kolom tambahan, di luar template asli
    t('xls_hdr_software'), t('xls_hdr_serial'), t('xls_hdr_software_status'), // kolom tambahan, di luar template asli
    t('xls_hdr_motherboard'), t('xls_hdr_processor'), t('xls_hdr_ram'), t('xls_hdr_storage'),
    currentLang() === 'en' ? 'Graphics Card' : 'Graphic Card / VGA', // kolom tambahan (tabel asset_gpu), ikut terbaca saat import
    t('xls_hdr_location'),
    t('xls_hdr_status'), t('xls_hdr_input_date'), t('xls_hdr_printer'), t('xls_hdr_monitor'), t('xls_hdr_accessories'),
    t('xls_hdr_ticket_history'), t('xls_hdr_repair_history'),
    t('xls_hdr_user_email'), // kolom tambahan, di luar template asli
    t('xls_hdr_pc_username'), t('xls_hdr_pc_password'), // kolom tambahan, login PC/laptop aset (data referensi IT)
    t('xls_hdr_purchase_date'), // kolom tambahan, di luar template asli
];

// Nilai status (Digunakan/Stok/Tidak Digunakan) diterjemahkan mengikuti bahasa aktif.
$assetStatusLangKey = ['Digunakan' => 'status_used', 'Stok' => 'status_stock', 'Tidak Digunakan' => 'status_unused'];

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Inventory');

// Tulis header (baris 1)
$sheet->fromArray($headers, null, 'A1');

specEnsure($db);
$gpuMap = specGpuMap($db);

// Susun data jadi array 2 dimensi dulu, baru tulis sekaligus (lebih stabil lintas versi PhpSpreadsheet)
$dataRows = [];
foreach ($assets as $a) {
    $ticketStmt->execute([$a['id']]);
    $tix = $ticketStmt->fetchAll();

    $riwayatTiket = implode('; ', array_map(
        fn($t) => $t['ticket_number'] . ' (' . date('d/m/Y H:i', strtotime($t['created_at'])) . ')',
        $tix
    ));
    $riwayatPerbaikan = implode('; ', array_map(
        fn($t) => $t['ticket_number'] . ': ' . $t['status'],
        $tix
    ));

    // Software bisa lebih dari satu -> tiap kolom digabung dipisah "; ", urutan
    // sejajar antar kolom (item ke-1 di Software = item ke-1 di Serial Number & Status).
    $softwareItems = $softwareMap[$a['id']] ?? [];
    $softwareNames  = $softwareItems ? implode('; ', array_column($softwareItems, 'software_name')) : '';
    $softwareSerials = $softwareItems ? implode('; ', array_map(fn($si) => $si['serial_number'] ?: '-', $softwareItems)) : '';
    $softwareStatuses = $softwareItems ? implode('; ', array_map(fn($si) => t($si['status'] === 'Original' ? 'os_original' : 'os_not_original'), $softwareItems)) : '';

    $dataRows[] = [
        $a['asset_number'],
        $a['category'],
        $a['device_name'],
        ownerNamesLabel($ownersMap[$a['id']] ?? []),
        ownerPositionsLabel($ownersMap[$a['id']] ?? [], $ownerPositionMap),
        $a['department'],
        $a['ip_address'],
        $a['hostname'],
        $a['os_name'],
        $a['serial_number'],
        t($a['os_status'] === 'Original' ? 'os_original' : 'os_not_original'),
        $softwareNames,
        $softwareSerials,
        $softwareStatuses,
        $a['motherboard_brand'] ?? '',
        $a['processor'],
        $a['ram'],
        $a['storage'],
        $gpuMap[(int)$a['id']] ?? '',
        $a['location'],
        isset($assetStatusLangKey[$a['status']]) ? t($assetStatusLangKey[$a['status']]) : $a['status'],
        date('Y-m-d', strtotime($a['created_at'])),
        $a['printer_info'],
        $a['monitor_info'],
        $a['accessories'],
        $riwayatTiket ?: '-',
        $riwayatPerbaikan ?: '-',
        $a['owner_email'],
        $a['pc_username'],
        $a['pc_password'],
        !empty($a['purchase_date'] ?? null) ? date('Y-m-d', strtotime($a['purchase_date'])) : '',
    ];
}

if ($dataRows) {
    $sheet->fromArray($dataRows, null, 'A2');
}

$lastCol = count($headers);
$lastRow = 1 + count($dataRows);

// ===== Styling: header bold + background, border seluruh tabel, auto-fit kolom =====
$headerRange = 'A1:' . \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($lastCol) . '1';
$sheet->getStyle($headerRange)->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
$sheet->getStyle($headerRange)->getFill()
      ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
$sheet->getStyle($headerRange)->getAlignment()->setHorizontal('center');

if ($lastRow >= 1) {
    $fullRange = 'A1:' . \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($lastCol) . $lastRow;
    $sheet->getStyle($fullRange)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
}

// Auto-fit lebar kolom
for ($c = 1; $c <= $lastCol; $c++) {
    $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($c);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}
$sheet->freezePane('A2');

// Kolom No di paling kiri, lalu kop + judul otomatis + tanggal dibuat + jumlah aset di atas tabel.
xlsAddNumberColumn($sheet, 1, $lastRow);
xlsAddAssetTitleBlock($sheet, array_column($assets, 'category'), count($assets));

// Campuran: tablet ditaruh di sheet terpisah "Tablet" dengan kolom khususnya.
if ($tabletAssets) {
    $writeTabletSheet($spreadsheet->createSheet(), $tabletAssets, 'Tablet');
    $spreadsheet->setActiveSheetIndex(0);
}
// Campuran: Ext Telepon di sheet terpisah "Ext Telepon".
if ($extAssets) {
    writeExtPhoneSheet($spreadsheet->createSheet(), $extAssets, $ownersMap, 'Ext Telepon');
    $spreadsheet->setActiveSheetIndex(0);
}
// Campuran: CCTV / NVR dan perangkat jaringan di sheet sendiri, kolom sama dengan template import.
if ($cctvAssets) {
    $tmp = new Spreadsheet();
    writeCctvImportTemplate($db, $tmp, true, array_column($cctvAssets, 'id'));
    $appendSheets($spreadsheet, $tmp, ['CCTV', 'NVR']);
}
if ($netAssets) {
    $tmp = new Spreadsheet();
    writeNetImportTemplate($db, $tmp, true, array_column($netAssets, 'id'));
    $appendSheets($spreadsheet, $tmp, ['Jaringan', 'Network']);
}
// Tidak ada aset "umum" -> sheet Inventory kosong dibuang.
if (!$assets && $spreadsheet->getSheetCount() > 1) $spreadsheet->removeSheetByIndex(0);
$spreadsheet->setActiveSheetIndex(0);

// ===== Output =====
$filename = 'inventory_export' . $scopeSuffix . '_' . date('Ymd_His') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
