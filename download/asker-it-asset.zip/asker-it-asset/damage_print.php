<?php
/** Cetak laporan Aset Rusak (A4 landscape, dialog print otomatis), mengikuti filter aktif. */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/damage.php';

$db = getDB();
ensureDamageTable($db);
$f    = damageFilters();
$rows = getDamages($db, $f);
$logo = appLogoDataUri();
$h    = fn($v) => htmlspecialchars((string)$v);
$dash = t('dash');
$fmt  = fn($d) => date('d M Y', strtotime($d));
$stateText = $f['state'] === 'open' ? t('dmg_filter_open') : ($f['state'] === 'all' ? t('stock_all') : damageStateLabel($f['state']));
$period = ($f['from'] ? $fmt($f['from']) : '…') . ' – ' . ($f['to'] ? $fmt($f['to']) : '…');
?>
<!DOCTYPE html>
<html lang="<?= $h(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $h(t('dmg_report_title')) ?></title>
<style>
    @page { size: A4 landscape; margin: 12mm; }
    body { font-family: Arial, sans-serif; color: #1e293b; margin: 24px; font-size: 11.5px; }
    .head { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 2px solid #1F3DD1; padding-bottom: 8px; margin-bottom: 14px; }
    .brand { display: flex; align-items: center; gap: 10px; }
    .brand img { height: 36px; }
    .brand .name { font-size: 16px; font-weight: bold; color: #1F3DD1; }
    .muted { color: #64748b; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #cbd5e1; padding: 5px 7px; text-align: left; vertical-align: top; }
    th { background: #eef2ff; }
    .r { text-align: right; }
    .no-print { margin-top: 20px; text-align: center; }
    .no-print button { background: #1F3DD1; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 13px; cursor: pointer; }
    @media print { body { margin: 0; } .no-print { display: none; } tr { page-break-inside: avoid; } }
</style>
</head>
<body>
    <div class="head">
        <div class="brand">
            <?php if ($logo): ?><img src="<?= $logo ?>" alt=""><?php endif; ?>
            <div><div class="name"><?= $h(t('app_name')) ?></div><div class="muted"><?= $h(t('dmg_report_title')) ?></div></div>
        </div>
        <div class="muted" style="text-align:right">
            <?= $h(t('th_status')) ?>: <?= $h($stateText) ?> &bull; <?= $h(t('stock_period')) ?>: <?= $h($period) ?><br>
            <?= $h(t('printed_at')) ?>: <?= date('d M Y H:i') ?>
        </div>
    </div>

    <table>
        <thead><tr>
            <th>No</th><th><?= t('th_asset_no') ?></th><th><?= t('dmg_col_asset') ?></th><th><?= t('dmg_col_date') ?></th><th><?= t('dmg_col_issue') ?></th>
            <th><?= t('dmg_col_storage') ?></th><th><?= t('dmg_col_last_user') ?></th><th><?= t('dmg_state_label') ?></th><th class="r"><?= t('dmg_col_days') ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ($rows as $i => $d): ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td style="white-space:nowrap"><?= $h($d['current_number'] ?: $d['asset_number']) ?></td>
                <td><?= $h($d['current_category'] ?: $d['asset_category']) ?><?= ($d['current_name'] ?: $d['asset_name']) ? '<br><span class="muted">' . $h($d['current_name'] ?: $d['asset_name']) . '</span>' : '' ?></td>
                <td style="white-space:nowrap"><?= $fmt($d['damage_date']) ?></td>
                <td><?= $h($d['issue']) ?><?= $d['note'] ? '<br><span class="muted">' . nl2br($h($d['note'])) . '</span>' : '' ?></td>
                <td><?= $h($d['storage_location']) ?></td>
                <td><?= $h($d['last_user_names'] ?: $dash) ?><?= $d['last_department'] ? '<br><span class="muted">' . $h($d['last_department']) . '</span>' : '' ?></td>
                <td style="white-space:nowrap"><?= $h(damageStateLabel($d['state'])) ?><?= $d['closed_date'] ? '<br><span class="muted">' . $fmt($d['closed_date']) . '</span>' : '' ?></td>
                <td class="r" style="white-space:nowrap"><?= $h(t('dmg_days', damageDays($d))) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="9" class="muted" style="text-align:center"><?= t('dmg_empty') ?></td></tr><?php endif; ?>
        </tbody>
    </table>
    <p class="muted" style="margin-top:8px"><?= $h(t('dmg_total_rows', count($rows))) ?></p>

    <div class="no-print"><button onclick="window.print()"><?= t('btn_print') ?></button></div>
    <script>window.addEventListener('load', () => setTimeout(() => window.print(), 300));</script>
</body>
</html>
