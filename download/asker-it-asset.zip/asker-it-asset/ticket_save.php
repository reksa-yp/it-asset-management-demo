<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tickets.php');
    exit;
}
csrfCheck();

$assetId = $_POST['asset_id'] ?: null;
$detail  = trim($_POST['problem_detail'] ?? '');

if ($detail === '') {
    die('Rincian masalah wajib diisi.');
}

$db = getDB();
$ticketNumber = 'TCK-' . date('Ymd') . '-' . str_pad((string)random_int(1, 9999), 4, '0', STR_PAD_LEFT);

$stmt = $db->prepare("INSERT INTO tickets (ticket_number, asset_id, reported_by, problem_detail, status)
                       VALUES (?, ?, ?, ?, 'Menunggu')");
$stmt->execute([$ticketNumber, $assetId, $_SESSION['user_id'], $detail]);

$ticketId = $db->lastInsertId();
$db->prepare("INSERT INTO ticket_logs (ticket_id, status, note, changed_by) VALUES (?, 'Menunggu', 'Tiket dibuat oleh user', ?)")
   ->execute([$ticketId, $_SESSION['user_id']]);

header('Location: tickets.php');
exit;
