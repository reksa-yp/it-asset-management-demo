<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
require_once __DIR__ . '/includes/ticket_photos.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tickets.php');
    exit;
}
csrfCheck();

$assetId = $_POST['asset_id'] ?: null;
$detail  = trim($_POST['problem_detail'] ?? '');

if ($detail === '') {
    die('Rincian masalah wajib diisi.');
}

$db = getDB();
$ticketNumber = 'TCK-' . date('Ymd') . '-' . str_pad((string)random_int(1, 9999), 4, '0', STR_PAD_LEFT);

$stmt = $db->prepare("INSERT INTO tickets (ticket_number, asset_id, reported_by, problem_detail, status)
                       VALUES (?, ?, ?, ?, 'Menunggu')");
$stmt->execute([$ticketNumber, $assetId, $_SESSION['user_id'], $detail]);

$ticketId = $db->lastInsertId();
$db->prepare("INSERT INTO ticket_logs (ticket_id, status, note, changed_by) VALUES (?, 'Menunggu', 'Tiket dibuat oleh user', ?)")
   ->execute([$ticketId, $_SESSION['user_id']]);

// Foto permasalahan (opsional, maks. 3). Kalau gagal tersimpan, tiket tetap terkirim.
if (!empty($_FILES['photos'])) {
    try { ticketSavePhotos($db, (int)$ticketId, $_FILES['photos'], (int)$_SESSION['user_id']); } catch (Throwable $e) { /* abaikan */ }
}

// Pusat Notifikasi: tiket baru untuk semua admin (kunci "t:<id>" sama dengan pop-up tiket, supaya HP tidak berbunyi dua kali).
try {
    require_once __DIR__ . '/includes/notifications.php';
    $nPhotos = count(ticketPhotosMap($db, [(int)$ticketId])[(int)$ticketId] ?? []);
    $nUser = $db->prepare("SELECT full_name, department FROM users WHERE id = ?");
    $nUser->execute([(int)$_SESSION['user_id']]);
    $nU = $nUser->fetch() ?: [];
    notifToAdmins($db, 'ticket', 'ticket_new', notifL('Tiket baru ', 'New ticket ') . $ticketNumber,
        trim(($nU['full_name'] ?? '') . (!empty($nU['department']) ? ' (' . $nU['department'] . ')' : '')) . ': ' . mb_strimwidth($detail, 0, 140, '...')
        . ($nPhotos ? ' · ' . $nPhotos . notifL(' foto', ' photo(s)') : ''),
        'tickets.php?q=' . urlencode($ticketNumber), (int)$ticketId, 't:' . (int)$ticketId, (int)$_SESSION['user_id']);
} catch (Throwable $e) { /* notifikasi hanya pelengkap */ }

header('Location: tickets.php');
exit;
