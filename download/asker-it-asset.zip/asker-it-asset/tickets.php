<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
require_once __DIR__ . '/includes/ticket_photos.php';

$db = getDB();
$admin = isAdmin();
ensureTicketCancelTable($db); // tabel BARU ticket_cancellations (pembatalan tiket oleh user)

// Filter status (tab) & pencarian — untuk admin dan user.
$statusTabs   = ['Menunggu', 'Proses', 'Selesai', 'Dibatalkan'];
$filterStatus = in_array($_GET['status'] ?? '', $statusTabs, true) ? $_GET['status'] : '';
$search       = trim($_GET['q'] ?? '');

if ($admin) {
    // Filter "Ditangani Oleh" (handled_by): '' = semua, 'none' = belum ditangani,
    // angka = id admin/IT tertentu. Dipakai juga oleh tombol Export Excel di bawah.
    $filterHandledBy = trim($_GET['handled_by'] ?? '');
    // Filter periode tanggal (berdasarkan tanggal dibuat tiket), bebas diisi
    // salah satu atau keduanya. Format input date HTML selalu YYYY-MM-DD.
    $filterDateFrom = trim($_GET['date_from'] ?? '');
    $filterDateTo   = trim($_GET['date_to'] ?? '');
    $filterDateFrom = preg_match('/^\d{4}-\d{2}-\d{2}$/', $filterDateFrom) ? $filterDateFrom : '';
    $filterDateTo   = preg_match('/^\d{4}-\d{2}-\d{2}$/', $filterDateTo) ? $filterDateTo : '';

    $conditions = [];
    $params = [];
    if ($filterHandledBy === 'none') {
        $conditions[] = 't.handled_by IS NULL';
    } elseif ($filterHandledBy !== '') {
        $conditions[] = 't.handled_by = ?';
        $params[] = (int)$filterHandledBy;
    }
    if ($filterDateFrom !== '') {
        $conditions[] = 'DATE(t.created_at) >= ?';
        $params[] = $filterDateFrom;
    }
    if ($filterDateTo !== '') {
        $conditions[] = 'DATE(t.created_at) <= ?';
        $params[] = $filterDateTo;
    }
    $where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';

    $stmt = $db->prepare("
        SELECT t.*, u.full_name AS pelapor, a.asset_number, h.full_name AS handler,
               u.department AS user_department, a.department AS asset_department, a.location AS asset_location,
               wd.work_detail AS work_detail, wd.asset_check AS asset_check
        FROM tickets t
        JOIN users u ON u.id = t.reported_by
        LEFT JOIN assets a ON a.id = t.asset_id
        LEFT JOIN users h ON h.id = t.handled_by
        LEFT JOIN ticket_work_details wd ON wd.ticket_id = t.id
        $where
        ORDER BY FIELD(t.status,'Menunggu','Proses','Selesai'), t.created_at DESC
    ");
    $stmt->execute($params);
    $tickets = applyTicketCancellations($db, $stmt->fetchAll());

    // Waktu selesai tiap tiket (dari riwayat status), ditampilkan di daftar bersama tanggal dibuat.
    $doneAtMap = getTicketDoneAtMap($db, $tickets);
    foreach ($tickets as &$tkRow) { $tkRow['done_at'] = $doneAtMap[(int)$tkRow['id']] ?? ''; }
    unset($tkRow);

    // Riwayat update status tiap tiket (Menunggu -> Proses -> Selesai, kapan & oleh siapa).
    $ticketLogsMap = getTicketLogsMap($db, array_column($tickets, 'id'));

    // Departemen & lokasi pelapor (sama seperti di popup notifikasi tiket).
    foreach ($tickets as &$tkRow) {
        $info = ticketReporterDeptLocation($db, $tkRow);
        $tkRow['pelapor_department'] = $info['department'];
        $tkRow['pelapor_location']   = $info['location'];
    }
    unset($tkRow);

    // Daftar admin/IT yang bisa dipilih di filter: semua admin aktif, ditambah
    // siapa pun yang pernah tercatat sebagai penangani (jaga-jaga kalau akunnya
    // sudah bukan admin lagi atau nonaktif).
    $handlerOptions = $db->query("
        SELECT DISTINCT u.id, u.full_name
        FROM users u
        WHERE u.role = 'admin'
           OR u.id IN (SELECT handled_by FROM tickets WHERE handled_by IS NOT NULL)
        ORDER BY u.full_name
    ")->fetchAll();

    $myAssets = [];
} else {
    $stmt = $db->prepare("
        SELECT t.*, a.asset_number
        FROM tickets t LEFT JOIN assets a ON a.id = t.asset_id
        WHERE t.reported_by = ? ORDER BY t.created_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $tickets = applyTicketCancellations($db, $stmt->fetchAll());

    // 1 aset sekarang bisa dipakai beberapa pengguna sekaligus (lihat includes/asset_owners.php).
    $myAssetIds = getAssetIdsForUser($db, (int)$_SESSION['user_id']);
    $myAssets = [];
    if ($myAssetIds) {
        $placeholders = implode(',', array_fill(0, count($myAssetIds), '?'));
        $ma = $db->prepare("SELECT id, asset_number, device_name FROM assets WHERE id IN ($placeholders)");
        $ma->execute($myAssetIds);
        $myAssets = $ma->fetchAll();
    }
}

// Jumlah per status (sebelum filter status & pencarian) untuk tab.
$statusCounts = array_fill_keys($statusTabs, 0);
foreach ($tickets as $tk) { $statusCounts[$tk['status']] = ($statusCounts[$tk['status']] ?? 0) + 1; }
$totalAll = count($tickets);
// Terapkan pencarian & tab status.
if ($search !== '') {
    $needle = mb_strtolower($search);
    $tickets = array_values(array_filter($tickets, fn($tk) => mb_strpos(mb_strtolower(implode(' ', [
        $tk['ticket_number'], $tk['problem_detail'], $tk['asset_number'] ?? '', $tk['pelapor'] ?? '', $tk['handler'] ?? '',
        $tk['pelapor_department'] ?? '', $tk['pelapor_location'] ?? '',
    ])), $needle) !== false));
}
if ($filterStatus !== '') {
    $tickets = array_values(array_filter($tickets, fn($tk) => $tk['status'] === $filterStatus));
}
// Urutan: Menunggu, Proses, Selesai, Dibatalkan; lalu terbaru.
$order = array_flip($statusTabs);
usort($tickets, fn($a, $b) => [$order[$a['status']] ?? 9, $b['created_at']] <=> [$order[$b['status']] ?? 9, $a['created_at']]);

$badge = ticketStatusBadges();
$statusLabel = ticketStatusLabels();
$ticketPhotoMap = ticketPhotosMap($db, array_column($tickets, 'id'));   // foto permasalahan per tiket

$bulkMsg = $_SESSION['ticket_bulk_msg'] ?? null;
unset($_SESSION['ticket_bulk_msg']);

$pageTitle = t('page_title_tickets');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// Query string filter aktif (dipakai tab status, pencarian, & Export Excel).
$baseQuery = array_filter([
    'handled_by' => $admin ? $filterHandledBy : '',
    'date_from'  => $admin ? $filterDateFrom : '',
    'date_to'    => $admin ? $filterDateTo : '',
    'q'          => $search,
], fn($v) => $v !== '');
$activeFilterQuery = array_intersect_key($baseQuery, array_flip(['handled_by', 'date_from', 'date_to']));
$isTicketFiltered = (bool)$baseQuery || $filterStatus !== '';
$tabUrl = fn(string $st) => 'tickets.php' . (($q = http_build_query($baseQuery + ($st !== '' ? ['status' => $st] : []))) ? '?' . $q : '');
$tabDot = ['Menunggu' => 'bg-slate-400', 'Proses' => 'bg-amber-500', 'Selesai' => 'bg-green-500', 'Dibatalkan' => 'bg-red-400'];
?>

<?php if ($bulkMsg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $bulkMsg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>">
        <?= htmlspecialchars($bulkMsg['text']) ?>
    </div>
<?php endif; ?>

<?php if (!$admin): ?>
<!-- ===== Buat tiket baru (user) ===== -->
<div class="bg-white rounded-xl shadow-sm p-4 sm:p-5 mb-4">
    <h2 class="font-semibold text-slate-700 mb-3"><?= t('new_ticket_title') ?></h2>
    <form method="post" action="ticket_save.php" enctype="multipart/form-data" id="newTicketForm" class="grid gap-3 md:grid-cols-[16rem_1fr_auto] md:items-end text-sm">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <div>
            <label class="block mb-1 font-medium" for="newTicketAsset"><?= t('field_related_asset') ?></label>
            <select name="asset_id" id="newTicketAsset" class="w-full border rounded-lg px-3 py-2">
                <option value=""><?= t('option_no_specific_asset') ?></option>
                <?php foreach ($myAssets as $ma): ?>
                    <option value="<?= $ma['id'] ?>"><?= htmlspecialchars($ma['device_name'] ?: $ma['asset_number']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label class="block mb-1 font-medium" for="newTicketProblem"><?= t('field_problem_detail') ?></label>
            <textarea name="problem_detail" id="newTicketProblem" rows="2" required class="w-full border rounded-lg px-3 py-2"
                      placeholder="<?= htmlspecialchars(t('placeholder_problem')) ?>"></textarea>
        </div>
        <div class="flex gap-2 items-end">
            <!-- Foto permasalahan: buka kamera langsung atau pilih dari galeri/file (opsional, maks. 3) -->
            <div class="relative" id="tpWrap">
                <button type="button" id="tpBtn" aria-haspopup="menu" aria-expanded="false" title="<?= htmlspecialchars(tpL('Lampirkan foto masalah', 'Attach a photo of the problem')) ?>"
                        class="inline-flex items-center gap-1.5 border border-slate-300 hover:bg-slate-50 text-slate-600 rounded-lg px-3 py-2 font-medium whitespace-nowrap">
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg><span class="hidden sm:inline"><?= htmlspecialchars(tpL('Foto', 'Photo')) ?></span><span id="tpCount" class="hidden min-w-[1.25rem] text-xs font-semibold bg-blue-600 text-white rounded-full px-1.5"></span>
                </button>
                <div id="tpMenu" role="menu" class="hidden absolute left-0 md:left-auto md:right-0 bottom-full mb-2 z-30 w-64 bg-white border border-slate-200 rounded-xl shadow-lg p-1.5">
                    <button type="button" role="menuitem" id="tpCam" class="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left hover:bg-blue-50"><svg class="w-5 h-5 text-blue-600 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg><span><span class="block font-medium text-slate-800"><?= htmlspecialchars(tpL('Buka kamera', 'Open camera')) ?></span><span class="block text-xs text-slate-500"><?= htmlspecialchars(tpL('Potret langsung dari HP', 'Take a photo with your phone')) ?></span></span></button>
                    <button type="button" role="menuitem" id="tpGal" class="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left hover:bg-blue-50"><svg class="w-5 h-5 text-blue-600 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg><span><span class="block font-medium text-slate-800"><?= htmlspecialchars(tpL('Pilih dari galeri / file', 'Choose from gallery / files')) ?></span><span class="block text-xs text-slate-500"><?= htmlspecialchars(tpL('Foto yang sudah ada atau screenshot', 'An existing photo or screenshot')) ?></span></span></button>
                </div>
                <input type="file" id="tpInCam" accept="image/*" capture="environment" class="hidden">
                <input type="file" id="tpInGal" accept="image/*" multiple class="hidden">
                <input type="file" name="photos[]" id="tpFiles" accept="image/*" multiple class="hidden">
            </div>
            <button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium whitespace-nowrap"><?= t('btn_send_ticket') ?></button>
        </div>
        <div id="tpPreview" class="hidden md:col-span-3 flex flex-wrap items-center gap-2"></div>
        <p class="md:col-span-3 -mt-1 text-xs text-slate-500"><?= htmlspecialchars(tpL('Foto masalah (opsional, maks. ' . TICKET_PHOTO_MAX . '): klik tombol Foto, tempel screenshot dengan Ctrl+V (di HP: tahan kolom rincian lalu Tempel), atau seret gambar ke kotak ini.', 'Problem photos (optional, max ' . TICKET_PHOTO_MAX . '): use the Photo button, paste a screenshot with Ctrl+V, or drag an image onto this box.')) ?></p>
    </form>
</div>
<?php endif; ?>

<!-- ===== Toolbar: tab status, pencarian, filter admin ===== -->
<div class="bg-white rounded-xl shadow-sm p-3 mb-4 space-y-3">
    <div class="flex flex-wrap items-center gap-2 text-sm">
        <a href="<?= htmlspecialchars($tabUrl('')) ?>" class="px-3 py-1.5 rounded-full border font-medium <?= $filterStatus === '' ? 'bg-slate-800 text-white border-slate-800' : 'text-slate-600 hover:bg-slate-50' ?>">
            <?= t('ticket_tab_all') ?> <span class="ml-1 tabular-nums opacity-70"><?= $totalAll ?></span>
        </a>
        <?php foreach ($statusTabs as $st): ?>
            <a href="<?= htmlspecialchars($tabUrl($st)) ?>" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border font-medium <?= $filterStatus === $st ? 'bg-slate-800 text-white border-slate-800' : 'text-slate-600 hover:bg-slate-50' ?>">
                <span class="w-2 h-2 rounded-full <?= $tabDot[$st] ?>"></span><?= htmlspecialchars($statusLabel[$st]) ?>
                <span class="tabular-nums opacity-70"><?= (int)$statusCounts[$st] ?></span>
            </a>
        <?php endforeach; ?>
    </div>
    <form method="get" class="flex flex-wrap items-end gap-2 text-sm">
        <?php if ($filterStatus !== ''): ?><input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus) ?>"><?php endif; ?>
        <div class="flex-1 min-w-[12rem]">
            <label for="ticketSearch" class="block mb-1 text-xs text-slate-500"><?= t('ticket_search_label') ?></label>
            <input type="search" name="q" id="ticketSearch" value="<?= htmlspecialchars($search) ?>" placeholder="<?= htmlspecialchars(t($admin ? 'ticket_search_ph_admin' : 'ticket_search_ph_user')) ?>" class="w-full border rounded-lg px-3 py-2">
        </div>
        <?php if ($admin): ?>
        <div>
            <label for="filterHandledBy" class="block mb-1 text-xs text-slate-500"><?= t('filter_handled_by_label') ?></label>
            <select name="handled_by" id="filterHandledBy" class="border rounded-lg px-3 py-2">
                <option value="" <?= $filterHandledBy === '' ? 'selected' : '' ?>><?= t('filter_handled_by_all') ?></option>
                <option value="none" <?= $filterHandledBy === 'none' ? 'selected' : '' ?>><?= t('filter_handled_by_none') ?></option>
                <?php foreach ($handlerOptions as $h): ?>
                    <option value="<?= $h['id'] ?>" <?= $filterHandledBy === (string)$h['id'] ? 'selected' : '' ?>><?= htmlspecialchars($h['full_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="filterDateFrom" class="block mb-1 text-xs text-slate-500"><?= t('filter_date_from') ?></label>
            <input type="date" name="date_from" id="filterDateFrom" value="<?= htmlspecialchars($filterDateFrom) ?>" class="border rounded-lg px-3 py-2">
        </div>
        <div>
            <label for="filterDateTo" class="block mb-1 text-xs text-slate-500"><?= t('filter_date_to') ?></label>
            <input type="date" name="date_to" id="filterDateTo" value="<?= htmlspecialchars($filterDateTo) ?>" class="border rounded-lg px-3 py-2">
        </div>
        <?php endif; ?>
        <button type="submit" class="bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg px-3 py-2 font-medium"><?= t('btn_apply_filter') ?></button>
        <?php if ($isTicketFiltered): ?>
            <a href="tickets.php" class="text-slate-500 hover:underline px-1 py-2"><?= t('btn_reset_filter') ?></a>
        <?php endif; ?>
        <?php if ($admin): ?>
        <div class="flex flex-wrap items-center gap-2 ml-auto">
            <span id="ticketSelectedInfo" class="hidden text-xs text-slate-500"><span id="ticketSelectedCount">0</span> <?= t('tickets_selected') ?></span>
            <button type="button" id="btnDeleteTicket" onclick="deleteSelectedTickets()" disabled
                    class="ticket-action-btn opacity-40 cursor-not-allowed bg-red-600 text-white rounded-lg px-4 py-2 font-medium"><?= t('btn_delete_selected') ?></button>
            <button type="button" id="btnTkHist" onclick="toggleTicketHistory()" class="inline-flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg px-4 py-2" data-show="<?= htmlspecialchars(t('ticket_hist_show')) ?>" data-hide="<?= htmlspecialchars(t('ticket_hist_hide')) ?>"><?= t('ticket_hist_hide') ?></button>
            <a href="ticket_export_excel.php<?= $activeFilterQuery ? '?' . http_build_query($activeFilterQuery) : '' ?>" class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg px-4 py-2">
                <?= icon('sheet') ?> Export Excel
            </a>
        </div>
        <?php endif; ?>
    </form>
</div>

<?php if ($admin): ?>
<form id="ticketBulkForm" method="post" action="ticket_bulk_delete.php"
      onsubmit="return confirmDelete(bulkDeleteConfirmTextTicket.replace('%d', selectedTicketCount()))">
<input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
</form>
<?php endif; ?>

<!-- ===== Daftar tiket =====
     Layar lebar (>=1024px): baris tabel ringkas tanpa scroll ke samping.
     Layar kecil: kartu bertumpuk. Satu markup, jadi tidak ada data ganda. -->
<?php
$gridCols = $admin
    ? 'lg:grid-cols-[1.75rem_13rem_minmax(0,1fr)_minmax(8rem,10rem)_minmax(10rem,12rem)]'
    : 'lg:grid-cols-[10.5rem_minmax(0,1fr)_minmax(8rem,10rem)_minmax(7rem,9rem)]';
?>
<div class="bg-white rounded-xl shadow-sm">
    <div class="list-head-sticky hidden lg:grid <?= $gridCols ?> gap-4 px-4 py-2 bg-slate-50 text-xs font-medium uppercase tracking-wide text-slate-500 rounded-t-xl border-b">
        <?php if ($admin): ?><div><input type="checkbox" id="checkAllTickets" onclick="toggleAllTickets(this)" aria-label="<?= htmlspecialchars(t('ticket_select_all')) ?>"></div><?php endif; ?>
        <div><?= t('th_ticket_no') ?></div>
        <div><?= t('ticket_col_problem') ?></div>
        <div><?= t('th_status') ?></div>
        <div><?= $admin ? t('th_action') : '' ?></div>
    </div>

    <?php foreach ($tickets as $t): $cancelled = $t['is_cancelled']; ?>
    <div class="grid grid-cols-1 <?= $gridCols ?> gap-2 lg:gap-4 px-4 py-3 border-b last:border-0 hover:bg-slate-50/70 <?= $cancelled ? 'bg-red-50/30' : '' ?>">
        <?php if ($admin): ?>
        <div class="hidden lg:block pt-0.5">
            <input type="checkbox" name="ids[]" value="<?= $t['id'] ?>" form="ticketBulkForm" class="ticket-check" onclick="updateTicketSelection()" aria-label="<?= htmlspecialchars($t['ticket_number']) ?>">
        </div>
        <?php endif; ?>

        <!-- No. tiket, tanggal, pelapor -->
        <div class="flex lg:block items-start justify-between gap-2 min-w-0">
            <div class="min-w-0">
                <div class="flex items-center gap-2">
                    <?php if ($admin): ?><input type="checkbox" name="ids[]" value="<?= $t['id'] ?>" form="ticketBulkForm" class="ticket-check lg:hidden" disabled data-mobile onclick="updateTicketSelection()"><?php endif; ?>
                    <span class="text-sm font-semibold text-slate-800 whitespace-nowrap"><?= htmlspecialchars($t['ticket_number']) ?></span>
                </div>
                <?php if ($admin): ?>
                <div class="text-xs text-slate-500 mt-0.5"><span class="text-slate-400"><?= t('ticket_created_lbl') ?>:</span> <?= date('d M Y H:i', strtotime($t['created_at'])) ?></div>
                <?php if (!$cancelled && !empty($t['done_at'])): ?>
                    <div class="text-xs text-green-700 mt-0.5"><span class="text-green-600/80"><?= t('ticket_done_lbl') ?>:</span> <span class="font-medium"><?= date('d M Y H:i', strtotime($t['done_at'])) ?></span></div>
                    <div class="text-xs text-slate-400 mt-0.5"><?= t('ticket_duration_lbl') ?>: <?= htmlspecialchars(ticketDurationLabel($t['created_at'], $t['done_at'])) ?></div>
                <?php endif; ?>
                <?php else: ?>
                <div class="text-xs text-slate-500 mt-0.5"><?= date('d M Y H:i', strtotime($t['created_at'])) ?></div>
                <?php endif; ?>
                <?php if ($admin): ?><div class="text-xs text-slate-600 mt-0.5 truncate"><?= icon('users', 'w-3.5 h-3.5 inline -mt-0.5 text-slate-400') ?> <?= htmlspecialchars($t['pelapor']) ?></div>
                <div class="text-xs text-slate-500 mt-0.5 truncate" title="<?= htmlspecialchars($t['pelapor_department']) ?>"><span class="text-slate-400"><?= t('field_department') ?>:</span> <?= htmlspecialchars($t['pelapor_department']) ?></div>
                <div class="text-xs text-slate-500 mt-0.5 truncate" title="<?= htmlspecialchars($t['pelapor_location']) ?>"><span class="text-slate-400"><?= t('field_location') ?>:</span> <?= htmlspecialchars($t['pelapor_location']) ?></div>
                <?php endif; ?>
            </div>
            <span class="lg:hidden shrink-0 px-2 py-0.5 rounded-full text-xs font-medium <?= $badge[$t['status']] ?>"><?= htmlspecialchars($statusLabel[$t['status']] ?? $t['status']) ?></span>
        </div>

        <!-- Aset & rincian masalah -->
        <div class="min-w-0 text-sm">
            <?php if (!empty($t['asset_number'])): ?>
                <span class="inline-block mb-1 text-xs font-medium bg-slate-100 text-slate-600 rounded px-1.5 py-0.5"><?= htmlspecialchars($t['asset_number']) ?></span>
            <?php endif; ?>
            <p class="text-slate-700 whitespace-pre-line break-words ticket-problem line-clamp-3" data-full="0"><?= htmlspecialchars($t['problem_detail']) ?></p>
            <?= ticketPhotoThumbs($ticketPhotoMap[(int)$t['id']] ?? []) ?>
            <?php if (mb_strlen($t['problem_detail']) > 160 || substr_count($t['problem_detail'], "\n") >= 3): ?>
                <button type="button" onclick="toggleProblem(this)" class="text-xs text-blue-600 hover:underline mt-0.5"><?= t('ticket_show_more') ?></button>
            <?php endif; ?>
            <?php if ($admin): $tkLogs = $ticketLogsMap[(int)$t['id']] ?? []; $tkHasWork = !empty($t['work_detail']) || !empty($t['asset_check']); ?>
            <?php if ($tkLogs): $tkBadges = ticketStatusBadges(); $tkLabels = ticketStatusLabels(); $tkLast = count($tkLogs) - 1; ?>
                <!-- Riwayat update status: kapan dibuat / diproses / selesai dan oleh siapa -->
                <div class="tk-hist mt-2 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs">
                    <div class="text-[11px] font-semibold uppercase tracking-wide text-slate-500 mb-1.5"><?= t('ticket_hist_title') ?></div>
                    <ul class="space-y-1">
                        <?php foreach ($tkLogs as $li => $lg):
                            $lgStatus = ($cancelled && $li === $tkLast && $lg['status'] === 'Selesai') ? 'Dibatalkan' : $lg['status'];
                            $lgWho = trim((string)($lg['changer'] ?? '')) ?: '-';
                            $lgText = $li === 0 && $lg['status'] === 'Menunggu' ? t('ticket_hist_created_by', $lgWho) : t('ticket_hist_changed_by', $lgWho); ?>
                            <li class="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                                <span class="inline-block text-[11px] font-semibold rounded-full px-2 py-px <?= $tkBadges[$lgStatus] ?? 'bg-slate-100 text-slate-600' ?>"><?= htmlspecialchars($tkLabels[$lgStatus] ?? $lgStatus) ?></span>
                                <span class="text-slate-700 tabular-nums"><?= date('d M Y H:i', strtotime($lg['changed_at'])) ?></span>
                                <span class="text-slate-500 break-words">· <?= htmlspecialchars($lgText) ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if (!$cancelled && $t['status'] === 'Selesai' && !$tkHasWork): ?>
                        <div class="mt-1.5 italic text-slate-400"><?= t('ticket_hist_no_detail') ?></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <?php endif; ?>
            <?php if ($admin && !$cancelled && (!empty($t['work_detail']) || !empty($t['asset_check']))): ?>
                <!-- Detail pengerjaan (diisi lewat tombol Isi Detail / Lihat-Edit) langsung terlihat di daftar -->
                <div class="tk-hist mt-2 rounded-lg border border-green-100 bg-green-50/50 px-2.5 py-2 text-xs space-y-1">
                    <?php if (!empty($t['work_detail'])): ?>
                        <div><span class="font-semibold text-green-800"><?= t('field_work_detail') ?>:</span>
                            <span class="text-slate-700 whitespace-pre-line break-words"><?= htmlspecialchars($t['work_detail']) ?></span></div>
                    <?php endif; ?>
                    <?php if (!empty($t['asset_check'])): ?>
                        <div><span class="font-semibold text-green-800"><?= t('field_asset_check') ?>:</span>
                            <span class="text-slate-700 whitespace-pre-line break-words"><?= htmlspecialchars($t['asset_check']) ?></span></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <?php if ($cancelled): ?>
                <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars(t('ticket_cancelled_info', date('d M Y H:i', strtotime($t['cancelled_at'])))) ?><?= $t['cancel_reason'] ? ' — ' . htmlspecialchars($t['cancel_reason']) : '' ?></p>
            <?php endif; ?>
        </div>

        <!-- Status & penangan -->
        <div class="hidden lg:block text-sm">
            <span class="px-2 py-0.5 rounded-full text-xs font-medium <?= $badge[$t['status']] ?>"><?= htmlspecialchars($statusLabel[$t['status']] ?? $t['status']) ?></span>
            <?php if (!empty($t['handler']) && !$cancelled): ?>
                <div class="text-xs text-slate-500 mt-1"><?= t('th_handled_by') ?>: <?= htmlspecialchars($t['handler']) ?></div>
            <?php endif; ?>
        </div>
        <?php if (!empty($t['handler']) && !$cancelled): ?>
            <div class="lg:hidden text-xs text-slate-500 -mt-1"><?= t('th_handled_by') ?>: <?= htmlspecialchars($t['handler']) ?></div>
        <?php endif; ?>

        <!-- Aksi -->
        <div class="flex flex-wrap lg:flex-col items-start gap-2 text-xs">
            <?php if ($admin): ?>
                <?php if (!$cancelled): ?>
                <form method="post" action="ticket_update_status.php" class="flex gap-1 w-full">
                    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                    <input type="hidden" name="id" value="<?= $t['id'] ?>">
                    <select name="status" class="border rounded-lg text-xs px-2 py-1.5 flex-1 min-w-0" aria-label="<?= htmlspecialchars(t('th_status')) ?>">
                        <?php foreach (['Menunggu','Proses','Selesai'] as $s): ?>
                            <option value="<?= $s ?>" <?= $s===$t['status']?'selected':'' ?>><?= htmlspecialchars($statusLabel[$s]) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-2.5 py-1.5 font-medium"><?= t('btn_update') ?></button>
                </form>
                <?php endif; ?>
                <?php $isFilled = !empty($t['work_detail']) || !empty($t['asset_check']); ?>
                <button type="button" onclick="openWorkModal(<?= $t['id'] ?>)"
                        class="inline-flex items-center gap-1 font-medium px-2 py-1.5 rounded-lg <?= $isFilled ? 'bg-green-50 text-green-700 hover:bg-green-100' : 'bg-slate-100 text-slate-600 hover:bg-slate-200' ?>">
                    <?= $isFilled ? icon('check-circle', 'w-3.5 h-3.5') . ' ' . t('btn_view_work_detail') : icon('pencil', 'w-3.5 h-3.5') . ' ' . t('btn_fill_work_detail') ?>
                </button>
            <?php else: ?>
                <?php if ($t['status'] === 'Menunggu'): ?>
                    <button type="button" onclick='openCancelModal(<?= (int)$t['id'] ?>, <?= json_encode($t['ticket_number'], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'
                            class="inline-flex items-center gap-1 font-medium px-2.5 py-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50">
                        <?= icon('x', 'w-3.5 h-3.5') ?> <?= t('ticket_btn_cancel') ?>
                    </button>
                <?php elseif ($t['status'] === 'Proses'): ?>
                    <span class="text-slate-400"><?= t('ticket_cancel_hint_process') ?></span>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>

    <?php if (!$tickets): ?>
        <p class="py-8 text-center text-sm text-slate-400"><?= $isTicketFiltered ? t('no_tickets_filtered') : t('no_tickets_yet') ?></p>
    <?php endif; ?>
</div>

<?php if (!$admin): ?>
<!-- ===== Modal: Batalkan tiket (user) ===== -->
<div id="cancelModal" class="fixed inset-0 bg-black/40 hidden items-center justify-center z-50 p-4">
    <form method="post" action="ticket_cancel.php" class="bg-white rounded-xl shadow-xl w-full max-w-md p-5 space-y-3 text-sm">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="hidden" name="id" id="cancelTicketId">
        <div class="flex items-start justify-between gap-3">
            <h2 class="font-semibold text-lg"><?= t('ticket_cancel_title') ?></h2>
            <button type="button" onclick="closeCancelModal()" data-modal-close title="<?= htmlspecialchars(t('btn_close')) ?>" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="shrink-0 -mr-1 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><?= icon('x', 'w-5 h-5') ?></button>
        </div>
        <p class="text-slate-600" id="cancelTicketLabel"></p>
        <div>
            <label for="cancelReason" class="block mb-1 font-medium"><?= t('ticket_cancel_reason') ?> <span class="text-slate-400 font-normal">(<?= t('stock_optional') ?>)</span></label>
            <textarea name="reason" id="cancelReason" rows="2" maxlength="255" class="w-full border rounded-lg px-3 py-2" placeholder="<?= htmlspecialchars(t('ticket_cancel_reason_ph')) ?>"></textarea>
        </div>
        <div class="flex justify-end gap-2 pt-2">
            <button type="button" onclick="closeCancelModal()" class="px-4 py-2 rounded-lg border"><?= t('ticket_cancel_keep') ?></button>
            <button type="submit" class="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-medium"><?= t('ticket_cancel_confirm') ?></button>
        </div>
    </form>
</div>
<?php endif; ?>
<?php if ($admin): ?>
<!-- ===== Modal: Isi Detail Pengerjaan & Pengecekan Aset ===== -->
<div id="workDetailModal" class="fixed inset-0 bg-black/40 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <form method="post" action="ticket_work_detail_save.php" class="p-5 space-y-3">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="hidden" name="ticket_id" id="wd_ticket_id">
            <div class="flex items-start justify-between gap-3 sticky top-0 z-10 bg-white -mx-5 -mt-5 px-5 pt-5 pb-2">
                <h2 class="font-semibold text-lg"><?= t('modal_work_detail_title') ?></h2>
                <button type="button" onclick="closeWorkModal()" data-modal-close title="<?= htmlspecialchars(t('btn_close')) ?>" aria-label="<?= htmlspecialchars(t('btn_close')) ?>" class="shrink-0 -mr-1 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><?= icon('x', 'w-5 h-5') ?></button>
            </div>
            <p class="text-xs text-slate-500 mb-2" id="wd_ticket_label"></p>

            <div class="text-sm">
                <label class="block mb-1 font-medium"><?= t('field_work_detail') ?></label>
                <textarea name="work_detail" id="wd_work_detail" rows="4" class="w-full border rounded-lg px-3 py-2"
                          placeholder="<?= htmlspecialchars(t('placeholder_work_detail')) ?>"></textarea>
            </div>
            <div class="text-sm">
                <label class="block mb-1 font-medium"><?= t('field_asset_check') ?></label>
                <textarea name="asset_check" id="wd_asset_check" rows="4" class="w-full border rounded-lg px-3 py-2"
                          placeholder="<?= htmlspecialchars(t('placeholder_asset_check')) ?>"></textarea>
            </div>

            <div class="flex justify-end gap-2 pt-2">
                <button type="button" onclick="closeWorkModal()" class="px-4 py-2 rounded-lg border text-sm"><?= t('btn_cancel') ?></button>
                <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium"><?= t('btn_save') ?></button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<script>
<?php if ($admin): ?>
var ticketWorkMap = <?= json_encode(array_column($tickets, null, 'id'), JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
function openWorkModal(ticketId) {
    var t = ticketWorkMap[ticketId] || {};
    document.getElementById('wd_ticket_id').value = ticketId;
    document.getElementById('wd_ticket_label').innerText = t.ticket_number || '';
    document.getElementById('wd_work_detail').value = t.work_detail || '';
    document.getElementById('wd_asset_check').value = t.asset_check || '';
    document.getElementById('workDetailModal').classList.remove('hidden');
    document.getElementById('workDetailModal').classList.add('flex');
}
function closeWorkModal() {
    document.getElementById('workDetailModal').classList.add('hidden');
    document.getElementById('workDetailModal').classList.remove('flex');
}
<?php endif; ?>

var ticketCancelLabelText = <?= json_encode(tRaw('ticket_cancel_label')) ?>;
var showMoreText = <?= json_encode(t('ticket_show_more')) ?>, showLessText = <?= json_encode(t('ticket_show_less')) ?>;
function toggleProblem(btn) {
    const p = btn.previousElementSibling;
    const full = p.dataset.full === '1';
    p.classList.toggle('line-clamp-3', full);
    p.dataset.full = full ? '0' : '1';
    btn.textContent = full ? showMoreText : showLessText;
}
function openCancelModal(id, number) {
    document.getElementById('cancelTicketId').value = id;
    document.getElementById('cancelTicketLabel').textContent = ticketCancelLabelText.replace('%s', number);
    document.getElementById('cancelReason').value = '';
    const m = document.getElementById('cancelModal'); m.classList.remove('hidden'); m.classList.add('flex');
    setTimeout(() => document.getElementById('cancelReason').focus(), 50);
}
function closeCancelModal() {
    const m = document.getElementById('cancelModal'); if (!m) return; m.classList.add('hidden'); m.classList.remove('flex');
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeCancelModal(); if (typeof closeWorkModal === 'function') closeWorkModal(); } });
// Layar kecil memakai checkbox di kartu, layar lebar memakai kolom checkbox.
// Hanya satu set yang aktif supaya id tiket tidak terkirim dua kali.
function syncTicketCheckboxMode() {
    const wide = window.matchMedia('(min-width: 1024px)').matches;
    document.querySelectorAll('.ticket-check').forEach(cb => {
        const mobile = cb.hasAttribute('data-mobile');
        cb.disabled = wide ? mobile : !mobile;
        if (cb.disabled) cb.checked = false;
    });
    if (typeof updateTicketSelection === 'function' && document.getElementById('btnDeleteTicket')) updateTicketSelection();
}
window.addEventListener('resize', syncTicketCheckboxMode);
document.addEventListener('DOMContentLoaded', syncTicketCheckboxMode);

var bulkDeleteConfirmTextTicket = <?= json_encode(tRaw('confirm_bulk_delete_ticket')) ?>;

function getSelectedTicketIds() {
    return Array.from(document.querySelectorAll('.ticket-check:checked:not(:disabled)')).map(cb => cb.value);
}
function selectedTicketCount() {
    return getSelectedTicketIds().length;
}
function updateTicketSelection() {
    if (!document.getElementById('btnDeleteTicket')) return;
    const all = document.querySelectorAll('.ticket-check:not(:disabled)');
    const ids = getSelectedTicketIds();
    const any = ids.length > 0;

    document.getElementById('ticketSelectedCount').innerText = ids.length;
    document.getElementById('ticketSelectedInfo').classList.toggle('hidden', ids.length === 0);

    const btn = document.getElementById('btnDeleteTicket');
    btn.disabled = !any;
    btn.classList.toggle('opacity-40', !any);
    btn.classList.toggle('cursor-not-allowed', !any);

    const master = document.getElementById('checkAllTickets');
    if (master) {
        master.checked = all.length > 0 && ids.length === all.length;
        master.indeterminate = ids.length > 0 && ids.length < all.length;
    }
}
function toggleAllTickets(master) {
    document.querySelectorAll('.ticket-check:not(:disabled)').forEach(cb => cb.checked = master.checked);
    updateTicketSelection();
}
function deleteSelectedTickets() {
    const ids = getSelectedTicketIds();
    if (ids.length === 0) return;
    document.getElementById('ticketBulkForm').requestSubmit();
}
</script>

<?php if (!empty($admin)): ?>
<style>body.tk-hist-off .tk-hist { display: none; }</style>
<script>
// Tombol tampil/sembunyi riwayat update di daftar tiket; pilihan diingat di browser ini.
function applyTicketHistory(off) {
    document.body.classList.toggle('tk-hist-off', off);
    var b = document.getElementById('btnTkHist');
    if (b) b.textContent = off ? b.dataset.show : b.dataset.hide;
    if (typeof window.rtRefresh === 'function') window.rtRefresh();
}
function toggleTicketHistory() {
    var off = !document.body.classList.contains('tk-hist-off');
    try { localStorage.setItem('tkHistOff', off ? '1' : '0'); } catch (e) {}
    applyTicketHistory(off);
}
document.addEventListener('DOMContentLoaded', function () {
    var off = false;
    try { off = localStorage.getItem('tkHistOff') === '1'; } catch (e) {}
    if (off) applyTicketHistory(true);
});
</script>
<?php endif; ?>
<!-- Perbesar foto permasalahan tiket -->
<div id="tpLightbox" class="hidden fixed inset-0 z-[60] bg-slate-950/85 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-label="<?= htmlspecialchars(tpL('Foto permasalahan', 'Problem photo')) ?>">
    <img id="tpLbImg" src="" alt="" class="max-h-[85vh] max-w-full rounded-lg shadow-2xl">
    <a id="tpLbOpen" href="#" target="_blank" rel="noopener" class="absolute bottom-4 right-4 bg-white/90 hover:bg-white text-slate-800 text-sm font-medium rounded-lg px-3 py-1.5"><?= htmlspecialchars(tpL('Buka ukuran asli', 'Open full size')) ?></a>
</div>
<script>
(function () {
    // Thumbnail foto di daftar tiket: klik untuk memperbesar, klik di luar / Esc untuk menutup.
    var lb = document.getElementById('tpLightbox'), img = document.getElementById('tpLbImg');
    document.addEventListener('click', function (e) {
        var b = e.target.closest('.ticket-photo');
        if (b) { img.src = b.dataset.src; document.getElementById('tpLbOpen').href = b.dataset.src; lb.classList.remove('hidden'); return; }
        if (e.target === lb || e.target === img) lb.classList.add('hidden');
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') lb.classList.add('hidden'); });

    // Form tiket baru (user): pilih foto lewat kamera / galeri, dikecilkan dulu (maks. 1600 px) lalu dikirim bersama tiket.
    var form = document.getElementById('newTicketForm');
    if (!form) return;
    var MAX = <?= TICKET_PHOTO_MAX ?>, picked = [];   // [{file, url, orig}]
    var btn = document.getElementById('tpBtn'), menu = document.getElementById('tpMenu'), out = document.getElementById('tpFiles'),
        prev = document.getElementById('tpPreview'), cnt = document.getElementById('tpCount');
    function setMenu(open) { menu.classList.toggle('hidden', !open); btn.setAttribute('aria-expanded', open ? 'true' : 'false'); }
    btn.addEventListener('click', function (e) {
        e.stopPropagation();
        if (picked.length >= MAX) { alert(<?= json_encode(tpL('Maksimal ' . TICKET_PHOTO_MAX . ' foto per tiket. Hapus salah satu foto dulu.', 'Up to ' . TICKET_PHOTO_MAX . ' photos per ticket. Remove one first.')) ?>); return; }
        setMenu(menu.classList.contains('hidden'));
    });
    document.addEventListener('click', function (e) { if (!e.target.closest('#tpWrap')) setMenu(false); });
    document.getElementById('tpCam').onclick = function () {
        setMenu(false);
        var inp = document.getElementById('tpInCam');
        if (window.itCamera) window.itCamera(inp, function (f) { addFiles([f]); }); else inp.click();
    };
    document.getElementById('tpGal').onclick = function () { setMenu(false); document.getElementById('tpInGal').click(); };
    function addFiles(list) {
        var files = Array.prototype.filter.call(list, function (f) { return /^image\//.test(f.type); });
        if (!files.length) return 0;
        var room = MAX - picked.length;
        if (room <= 0) { alert(<?= json_encode(tpL('Maksimal ' . TICKET_PHOTO_MAX . ' foto per tiket. Hapus salah satu foto dulu.', 'Up to ' . TICKET_PHOTO_MAX . ' photos per ticket. Remove one first.')) ?>); return 0; }
        files.slice(0, room).forEach(function (f) { shrink(f, function (small) { if (picked.length < MAX) { picked.push({file: small, url: URL.createObjectURL(small), orig: f.size}); sync(); } }); });
        return files.length;
    }
    ['tpInCam', 'tpInGal'].forEach(function (id) {
        document.getElementById(id).addEventListener('change', function () { addFiles(this.files); this.value = ''; });
    });
    // Tempel screenshot (Ctrl+V / tahan lalu Tempel di HP) di mana saja pada halaman ini, kecuali di kolom isian lain.
    document.addEventListener('paste', function (e) {
        var cd = e.clipboardData; if (!cd) return;
        var t = e.target, inForm = form.contains(t);
        if (!inForm && t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
        var files = [];
        Array.prototype.forEach.call(cd.items || [], function (it) { if (it.kind === 'file') { var f = it.getAsFile(); if (f) files.push(f); } });
        if (!files.length && cd.files) files = Array.prototype.slice.call(cd.files);
        if (addFiles(files)) { e.preventDefault(); form.scrollIntoView({block: 'nearest'}); }
    });
    // Seret & lepas file gambar ke kotak form.
    var box = form.closest('.bg-white') || form;
    box.addEventListener('dragover', function (e) { if (e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') >= 0) { e.preventDefault(); box.classList.add('ring-2', 'ring-blue-400'); } });
    box.addEventListener('dragleave', function (e) { if (!box.contains(e.relatedTarget)) box.classList.remove('ring-2', 'ring-blue-400'); });
    box.addEventListener('drop', function (e) { box.classList.remove('ring-2', 'ring-blue-400'); if (e.dataTransfer && e.dataTransfer.files.length) { e.preventDefault(); addFiles(e.dataTransfer.files); } });
    function kb(n) { return n >= 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
    // Kecilkan foto di perangkat: sisi terpanjang maks. 1600 px, JPEG 0,8. Kalau gagal, kirim file aslinya.
    function shrink(f, done) {
        if (!/^image\//.test(f.type)) return;
        var url = URL.createObjectURL(f), im = new Image();
        im.onload = function () {
            var s = Math.min(1, 1600 / Math.max(im.width, im.height)), cv = document.createElement('canvas');
            cv.width = Math.round(im.width * s); cv.height = Math.round(im.height * s);
            cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height); URL.revokeObjectURL(url);
            cv.toBlob(function (b) {
                if (!b || b.size >= f.size) { done(f); return; }
                try { done(new File([b], (f.name || 'foto').replace(/\.\w+$/, '') + '.jpg', {type: 'image/jpeg'})); } catch (e) { done(f); }
            }, 'image/jpeg', 0.8);
        };
        im.onerror = function () { URL.revokeObjectURL(url); done(f); };
        im.src = url;
    }
    function sync() {
        try { var dt = new DataTransfer(); picked.forEach(function (p) { dt.items.add(p.file); }); out.files = dt.files; } catch (e) {}
        cnt.textContent = picked.length; cnt.classList.toggle('hidden', !picked.length);
        prev.classList.toggle('hidden', !picked.length);
        prev.innerHTML = picked.map(function (p, i) {
            return '<div class="relative"><img src="' + p.url + '" alt="" class="w-16 h-16 object-cover rounded-lg border border-slate-200">'
                + '<button type="button" data-rm="' + i + '" class="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-slate-800 text-white text-xs leading-5 text-center" aria-label="<?= htmlspecialchars(tpL('Hapus foto', 'Remove photo')) ?>">&times;</button>'
                + '<span class="block text-[10px] text-slate-500 text-center mt-0.5">' + kb(p.file.size) + '</span></div>';
        }).join('') + '<span class="text-xs text-slate-500">' + picked.length + ' / ' + MAX + ' <?= htmlspecialchars(tpL('foto · dikecilkan otomatis sebelum dikirim', 'photos · resized automatically before sending')) ?></span>';
        Array.prototype.forEach.call(prev.querySelectorAll('[data-rm]'), function (b) {
            b.onclick = function () { var p = picked.splice(+b.dataset.rm, 1)[0]; if (p) URL.revokeObjectURL(p.url); sync(); };
        });
    }
    form.addEventListener('submit', function () { btn.disabled = true; });
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
