<?php
/**
 * Menu CCTV > List View (khusus admin): daftar kamera per NVR + snapshot tampilan, type, IP, channel & status.
 *   cctv_listview.php?ym=YYYY-MM&nvr=all|id            -> halaman (galeri)
 *   cctv_listview.php?ym=YYYY-MM&nvr=all|id&out=xlsx   -> Excel laporan bulanan, 1 sheet per NVR
 *   POST action=snap                                  -> ambil snapshot sekarang dari NVR
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/cctv_snapshot.php';

$db = getDB();
ensureCctvTables($db);
$h = fn($v) => htmlspecialchars((string)$v);

$ym = (string)($_REQUEST['ym'] ?? date('Y-m'));
if (!preg_match('/^\d{4}-\d{2}$/', $ym) || $ym > date('Y-m')) $ym = date('Y-m');
$rep    = cctvMonthReport($db, $ym);
$groups = $rep['groups'];
$nvrSel = (string)($_REQUEST['nvr'] ?? 'all');
if ($nvrSel !== 'all' && (!ctype_digit($nvrSel) || !isset($groups[(int)$nvrSel]))) $nvrSel = 'all';
$showGroups = $nvrSel === 'all' ? $groups : [(int)$nvrSel => $groups[(int)$nvrSel]];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'pub_ip') {
    csrfCheck();
    $pub = [];
    foreach ((array)($_POST['pub'] ?? []) as $id => $ip) {
        $ip = trim((string)$ip);
        if ($ip !== '' && ctype_digit((string)$id)) $pub[(string)(int)$id] = mb_substr($ip, 0, 60);
    }
    saveCctvSettings(['nvr_public_ip' => $pub]);
    $_SESSION['cctv_msg'] = ['ok' => true, 'text' => cL('IP publik NVR disimpan (tampil di cover checklist).', 'NVR public IPs saved.')];
    header('Location: cctv_listview.php?' . http_build_query(['ym' => $ym, 'nvr' => $nvrSel]));
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'snap_cfg') {
    csrfCheck();
    $sch = in_array($_POST['snapshot_schedule'] ?? '', ['first_monday', 'daily', 'off'], true) ? $_POST['snapshot_schedule'] : 'first_monday';
    saveCctvSettings(['snapshot_schedule' => $sch, 'snapshot_hour' => max(0, min(23, (int)($_POST['snapshot_hour'] ?? 9)))]);
    $_SESSION['cctv_msg'] = ['ok' => true, 'text' => cL('Jadwal snapshot otomatis disimpan.', 'Snapshot schedule saved.')];
    header('Location: cctv_listview.php?' . http_build_query(['ym' => $ym, 'nvr' => $nvrSel]));
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'snap') {
    csrfCheck();
    $r = cctvTakeSnapshots($db, $nvrSel === 'all' ? null : (int)$nvrSel);
    $text = cL("Snapshot tersimpan: {$r['ok']} kamera.", "Snapshots saved: {$r['ok']} cameras.");
    if ($r['fail']) $text .= ' ' . cL('Gagal (kamera mati / NVR tidak merespons): ', 'Failed: ') . implode(', ', array_slice($r['fail'], 0, 10)) . (count($r['fail']) > 10 ? ', ...' : '') . '.';
    if ($r['skip']) $text .= ' ' . cL("{$r['skip']} kamera tanpa NVR/channel dilewati (bisa pakai foto checklist).", "{$r['skip']} cameras without NVR/channel skipped.");
    $_SESSION['cctv_msg'] = ['ok' => !$r['fail'] || $r['ok'] > 0, 'text' => $text];
    header('Location: cctv_listview.php?' . http_build_query(['ym' => date('Y-m'), 'nvr' => $nvrSel]));
    exit;
}

/* ---------------------------------------------------------------- Data */
$snaps   = cctvSnapshotMap($db, $ym);
$nvrs    = cctvNvrList($db);
$camIds  = array_column($rep['cams'], 'id');
$info    = cctvInfoMap($db, $camIds);
$nvrAsset = cctvNvrToAsset($db);
$nvrAssetRows = [];
if ($nvrAsset) {
    $st = $db->prepare("SELECT id, location FROM assets WHERE id IN (" . implode(',', array_fill(0, count($nvrAsset), '?')) . ")");
    $st->execute(array_values($nvrAsset));
    foreach ($st->fetchAll() as $a) $nvrAssetRows[(int)$a['id']] = $a;
}
$nvrInfo = cctvInfoMap($db, array_values($nvrAsset));
$isCurrent = $ym === date('Y-m');
// Status per kamera: dari snapshot bulan itu; bulan berjalan tanpa snapshot -> status sekarang.
$camStatus = function (array $c) use ($snaps, $isCurrent): string {
    $s = $snaps[$c['id']]['state'] ?? '';
    if ($s === '' && $isCurrent) $s = (string)($c['state'] ?? '');
    return $s;
};
$statusText = fn(string $s) => $s === '' ? '-' : cctvStateLabel($s);
$uptime = fn(array $c) => round(100 - (($rep['down'][$c['id']]['sec'] ?? 0) / $rep['period_sec'] * 100), 1);
$nvrRow = function (int $gk, array $g) use ($nvrs, $nvrAsset, $nvrAssetRows, $nvrInfo): ?array {
    $n = $nvrs[$gk] ?? null;
    if (!$n) return null;
    $aid = $nvrAsset[$gk] ?? 0;
    return [
        'name' => (string)$n['name'], 'type' => (string)($nvrInfo[$aid]['model'] ?? '') ?: strtoupper((string)$n['brand']),
        'location' => (string)($nvrAssetRows[$aid]['location'] ?? ''), 'channels' => count($g['cams']),
        'ip' => (string)$n['ip_address'], 'state' => (string)($n['last_state'] ?? ''),
    ];
};
$chLabel = fn($c) => (int)($c['channel'] ?? 0) > 0 ? 'D' . (int)$c['channel'] : '-';

/* ---------------------------------------------------------------- Excel */
if (($_GET['out'] ?? '') === 'xlsx') {
    require_once __DIR__ . '/vendor/autoload.php';
    require_once __DIR__ . '/includes/xls_number.php';
    $ss = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $ss->getDefaultStyle()->getFont()->setName('Arial')->setSize(10);
    // Kolom utama = NAMA CCTV (lokasi sebagai keterangan).
    $cols = [['NO', 6], ['NAMA CCTV', 28], ['LOKASI', 22], ['TYPE', 20], ['CHANNEL', 10], ['IP ADDRESS', 16], ['STATUS', 12], ['UPTIME', 9], ['VIEW CCTV', 40]];
    $thin = ['borders' => ['allBorders' => ['borderStyle' => 'thin', 'color' => ['rgb' => '94A3B8']]]];
    $used = [];
    $first = true;
    foreach ($showGroups as $gk => $g) {
        $sh = $first ? $ss->getActiveSheet() : $ss->createSheet();
        $first = false;
        $title = mb_substr(trim(preg_replace('/[\\\\\/\?\*\[\]:]+/', ' ', $g['name'])), 0, 28) ?: 'NVR';
        $t = $title; $k = 2;
        while (isset($used[mb_strtolower($t)])) $t = $title . ' ' . $k++;
        $used[mb_strtolower($t)] = true;
        $sh->setTitle($t);
        foreach ($cols as $i => [$label, $w]) {
            $L = chr(65 + $i);
            $sh->setCellValue($L . '1', $label);
            $sh->getColumnDimension($L)->setWidth($w);
        }
        xlsAddTitleBlock($sh, 1, 'LIST VIEW CCTV ' . mb_strtoupper($g['name']), [
            cL('Periode: ', 'Period: ') . cctvMonthTitle($ym) . '   |   ' . cL('Jumlah kamera: ', 'Cameras: ') . count($g['cams']),
            cL('VIEW CCTV = snapshot terakhir bulan ini dari NVR (atau foto checklist). Status = saat snapshot diambil; Uptime = dari monitoring otomatis.', 'VIEW = latest snapshot this month. Status = at snapshot time; Uptime from automatic monitoring.'),
        ]);
        $hr = 8;
        $sh->getStyle("A{$hr}:I{$hr}")->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
        $sh->getStyle("A{$hr}:I{$hr}")->getFill()->setFillType('solid')->getStartColor()->setRGB('1E3A8A');
        $sh->getStyle("A{$hr}:I{$hr}")->getAlignment()->setHorizontal('center')->setVertical('center');
        $sh->getRowDimension($hr)->setRowHeight(24);
        $r = $hr + 1;
        $statusStyle = function (string $cell, string $s) use ($sh) {
            $map = ['on' => ['DCFCE7', '15803D'], 'off' => ['FEE2E2', 'B91C1C'], 'vl' => ['FEF3C7', 'B45309']];
            if (!isset($map[$s])) return;
            $sh->getStyle($cell)->getFill()->setFillType('solid')->getStartColor()->setRGB($map[$s][0]);
            $sh->getStyle($cell)->getFont()->setBold(true)->getColor()->setRGB($map[$s][1]);
        };
        // Baris NVR
        if ($nv = $nvrRow((int)$gk, $g)) {
            $vals = ['NVR', $nv['name'], $nv['location'] ?: '-', $nv['type'], $nv['channels'], $nv['ip'], $nv['state'] === 'on' ? 'Online' : ($nv['state'] === 'off' ? 'Offline' : '-'), '', ''];
            foreach ($vals as $i => $v) $sh->setCellValueExplicit(chr(65 + $i) . $r, (string)$v, \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            $sh->getStyle("A{$r}:I{$r}")->getFill()->setFillType('solid')->getStartColor()->setRGB('E0E7FF');
            $sh->getStyle("A{$r}:I{$r}")->getFont()->setBold(true);
            $statusStyle('G' . $r, (string)$nv['state']);
            $sh->getRowDimension($r)->setRowHeight(30);
            $r++;
        }
        foreach ($g['cams'] as $i => $c) {
            $s = $camStatus($c);
            $vals = [$i + 1, $c['name'] ?: $c['location'], $c['location'] ?: '-', $info[$c['id']]['model'] ?? '', $chLabel($c), $c['ip'] ?: '-', $statusText($s), $uptime($c) . '%'];
            foreach ($vals as $j => $v) $sh->setCellValueExplicit(chr(65 + $j) . $r, (string)$v, \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            $statusStyle('G' . $r, $s);
            $sn = $snaps[$c['id']] ?? null;
            if ($sn) {
                $d = new \PhpOffice\PhpSpreadsheet\Worksheet\Drawing();
                $d->setPath($sn['file']);
                $d->setHeight(146);
                if ($d->getWidth() > 272) $d->setWidth(272);
                $d->setCoordinates('I' . $r);
                $d->setOffsetX(6);
                $d->setOffsetY(4);
                $d->setWorksheet($sh);
            } else {
                $sh->setCellValue('I' . $r, cL('Belum ada snapshot', 'No snapshot'));
                $sh->getStyle('I' . $r)->getFont()->setItalic(true)->getColor()->setRGB('94A3B8');
            }
            $sh->getRowDimension($r)->setRowHeight(116);
            $r++;
        }
        $last = $r - 1;
        $sh->getStyle("A{$hr}:I{$last}")->applyFromArray($thin);
        $sh->getStyle("A" . ($hr + 1) . ":H{$last}")->getAlignment()->setVertical('center')->setWrapText(true);
        $sh->getStyle("A" . ($hr + 1) . ":A{$last}")->getAlignment()->setHorizontal('center');
        $sh->getStyle("E" . ($hr + 1) . ":H{$last}")->getAlignment()->setHorizontal('center');
        $sh->getStyle("B" . ($hr + 1) . ":B{$last}")->getFont()->setBold(true);
        $sh->getStyle("I" . ($hr + 1) . ":I{$last}")->getAlignment()->setHorizontal('center')->setVertical('center');
        $sh->freezePane('A' . ($hr + 1));
        $ps = $sh->getPageSetup();
        $ps->setOrientation('portrait')->setPaperSize(\PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_A4)
           ->setFitToWidth(1)->setFitToHeight(0)->setRowsToRepeatAtTopByStartAndEnd($hr, $hr);
        $sh->getPageMargins()->setTop(0.4)->setBottom(0.4)->setLeft(0.3)->setRight(0.3);
    }
    $ss->setActiveSheetIndex(0);
    $fn = 'List_View_CCTV_' . str_replace(' ', '_', cctvMonthTitle($ym)) . ($nvrSel === 'all' ? '' : '_' . preg_replace('/[^A-Za-z0-9]+/', '_', $groups[(int)$nvrSel]['name'])) . '.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $fn . '"');
    header('Cache-Control: max-age=0');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($ss))->save('php://output');
    exit;
}

/* ---------------------------------------------------------------- Halaman */
$msg = $_SESSION['cctv_msg'] ?? null;
unset($_SESSION['cctv_msg']);
$months = [];
for ($i = 0; $i < 12; $i++) { $m = date('Y-m', strtotime(date('Y-m-01') . " -$i month")); $months[$m] = cctvMonthTitle($m); }
$set = cctvSettings();
$snapCount = count(array_filter($rep['cams'], fn($c) => isset($snaps[$c['id']])));
$pageTitle = 'List View CCTV';
$cctvTab = 'listview';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
$badge = ['on' => 'bg-green-100 text-green-700', 'off' => 'bg-red-100 text-red-700', 'vl' => 'bg-amber-100 text-amber-700'];
?>
<div class="mb-3">
    <h1 class="text-xl font-semibold text-slate-800">List View CCTV</h1>
    <p class="text-sm text-slate-500"><?= $h(cL('Snapshot tampilan tiap kamera + type, IP, channel & status. Laporan bulanan Excel: 1 sheet per NVR.', 'Camera snapshots with type, IP, channel & status. Monthly Excel: 1 sheet per NVR.')) ?></p>
</div>
<?php require __DIR__ . '/includes/cctv_nav.php'; ?>

<?php if ($msg): ?>
    <div class="mb-4 text-sm rounded-lg px-3 py-2 <?= $msg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>"><?= $h($msg['text']) ?></div>
<?php endif; ?>

<form method="get" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-end gap-3 text-sm">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Bulan', 'Month')) ?></span>
        <select name="ym" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[160px]" onchange="this.form.submit()">
            <?php foreach ($months as $k => $label): ?><option value="<?= $h($k) ?>" <?= $k === $ym ? 'selected' : '' ?>><?= $h($label) ?></option><?php endforeach; ?>
        </select></label>
    <?php if (count($groups) > 1): ?>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500">NVR</span>
        <select name="nvr" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[170px]" onchange="this.form.submit()">
            <option value="all" <?= $nvrSel === 'all' ? 'selected' : '' ?>><?= $h(cL('Semua NVR (1 sheet per NVR)', 'All NVRs (1 sheet each)')) ?></option>
            <?php foreach ($groups as $gk => $g): ?><option value="<?= $gk ?>" <?= $nvrSel === (string)$gk ? 'selected' : '' ?>><?= $h($g['name']) ?></option><?php endforeach; ?>
        </select></label>
    <?php endif; ?>
    <div class="flex flex-wrap gap-2 ml-auto">
        <a href="cctv_listview.php?<?= $h(http_build_query(['ym' => $ym, 'nvr' => $nvrSel, 'out' => 'xlsx'])) ?>" class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white rounded-lg px-4 py-2 font-medium"><?= icon('sheet') ?> <?= $h(cL('Unduh Excel', 'Download Excel')) ?></a>
    </div>
</form>

<form method="post" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-center gap-3 text-sm" onsubmit="this.querySelector('button').disabled=true;this.querySelector('button').textContent='<?= $h(cL('Mengambil snapshot...', 'Taking snapshots...')) ?>';">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
    <input type="hidden" name="action" value="snap">
    <input type="hidden" name="nvr" value="<?= $h($nvrSel) ?>">
    <span class="text-slate-600"><?= $h(cL('Snapshot ', 'Snapshots ') . cctvMonthTitle($ym) . ': ') ?><b><?= $snapCount ?> / <?= count($rep['cams']) ?></b> <?= $h(cL('kamera', 'cameras')) ?>.
        <?php $nextSnap = cctvNextSnapshotDate($set); ?>
        <?= $h($nextSnap !== '' ? cL('Snapshot otomatis berikutnya: ', 'Next automatic snapshot: ') . date('d/m/Y', strtotime($nextSnap)) . ' ' . str_pad((string)(int)$set['snapshot_hour'], 2, '0', STR_PAD_LEFT) . ':00.' : cL('Snapshot otomatis nonaktif.', 'Automatic snapshot off.')) ?></span>
    <button class="ml-auto inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium"><?= icon('camera') ?> <?= $h(cL('Ambil snapshot sekarang', 'Take snapshots now')) ?><?= $nvrSel !== 'all' ? ' · ' . $h($groups[(int)$nvrSel]['name']) : '' ?></button>
</form>

<form method="post" class="bg-white rounded-xl shadow-sm p-3 mb-4 flex flex-wrap items-end gap-3 text-sm">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
    <input type="hidden" name="action" value="snap_cfg">
    <input type="hidden" name="ym" value="<?= $h($ym) ?>"><input type="hidden" name="nvr" value="<?= $h($nvrSel) ?>">
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Jadwal snapshot otomatis', 'Automatic snapshot schedule')) ?></span>
        <select name="snapshot_schedule" class="border border-slate-300 rounded-lg px-2 py-1.5 min-w-[230px]">
            <?php foreach (['first_monday' => cL('Senin pertama tiap bulan', 'First Monday of each month'), 'daily' => cL('Setiap hari', 'Every day'), 'off' => cL('Nonaktif (manual saja)', 'Off (manual only)')] as $k => $label): ?>
                <option value="<?= $k ?>" <?= $set['snapshot_schedule'] === $k ? 'selected' : '' ?>><?= $h($label) ?></option>
            <?php endforeach; ?>
        </select></label>
    <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h(cL('Mulai jam', 'From hour')) ?></span>
        <select name="snapshot_hour" class="border border-slate-300 rounded-lg px-2 py-1.5">
            <?php for ($i = 6; $i <= 17; $i++): ?><option value="<?= $i ?>" <?= (int)$set['snapshot_hour'] === $i ? 'selected' : '' ?>><?= str_pad((string)$i, 2, '0', STR_PAD_LEFT) ?>:00</option><?php endfor; ?>
        </select></label>
    <button class="rounded-lg border border-slate-300 bg-white hover:bg-slate-50 px-4 py-1.5"><?= $h(cL('Simpan jadwal', 'Save schedule')) ?></button>
    <span class="text-xs text-slate-400"><?= $h(cL('Jika pada Senin pertama server mati, snapshot diambil pada pengecekan berikutnya.', 'If the server is off on the first Monday, it is taken at the next check.')) ?></span>
</form>

<?php if ($nvrs): $pubIp = (array)$set['nvr_public_ip']; ?>
<form method="post" class="bg-white rounded-xl shadow-sm p-3 mb-4 text-sm">
    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
    <input type="hidden" name="action" value="pub_ip">
    <input type="hidden" name="ym" value="<?= $h($ym) ?>"><input type="hidden" name="nvr" value="<?= $h($nvrSel) ?>">
    <p class="text-xs text-slate-500 mb-2"><?= $h(cL('IP publik NVR (opsional) — ditampilkan di sheet cover "VIEW_NVR" pada Export Excel rekap bulanan checklist.', 'NVR public IP (optional) — shown on the "VIEW_NVR" cover sheet of the monthly checklist Excel.')) ?></p>
    <div class="flex flex-wrap items-end gap-3">
        <?php foreach ($nvrs as $id => $n): ?>
            <label class="flex flex-col gap-1"><span class="text-xs text-slate-500"><?= $h($n['name']) ?> <span class="text-slate-400">(<?= $h($n['ip_address']) ?>)</span></span>
                <input name="pub[<?= (int)$id ?>]" value="<?= $h($pubIp[(string)$id] ?? '') ?>" placeholder="<?= $h(cL('IP publik', 'Public IP')) ?>" class="border border-slate-300 rounded-lg px-2 py-1.5 w-44"></label>
        <?php endforeach; ?>
        <button class="rounded-lg border border-slate-300 bg-white hover:bg-slate-50 px-4 py-1.5"><?= $h(cL('Simpan IP publik', 'Save public IPs')) ?></button>
    </div>
</form>
<?php endif; ?>

<?php foreach ($showGroups as $gk => $g): $nv = $nvrRow((int)$gk, $g); ?>
<section class="bg-white rounded-xl shadow-sm mb-5 overflow-hidden">
    <div class="px-4 py-3 border-b flex flex-wrap items-center gap-x-4 gap-y-1">
        <h2 class="font-semibold text-slate-800">LIST VIEW CCTV <?= $h(mb_strtoupper($g['name'])) ?></h2>
        <?php if ($nv): ?><span class="text-xs text-slate-500"><?= $h(trim($nv['type'] . ' · ' . $nv['ip'] . ' · ' . $nv['channels'] . ' ' . cL('kamera', 'cameras'), ' ·')) ?></span>
            <span class="text-xs rounded-full px-2 py-0.5 <?= $badge[$nv['state']] ?? 'bg-slate-100 text-slate-500' ?>">NVR <?= $h($nv['state'] === 'on' ? 'Online' : ($nv['state'] === 'off' ? 'Offline' : '-')) ?></span><?php endif; ?>
    </div>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 p-4">
    <?php foreach ($g['cams'] as $i => $c): $s = $camStatus($c); $sn = $snaps[$c['id']] ?? null; ?>
        <div class="border border-slate-200 rounded-lg overflow-hidden text-sm">
            <div class="aspect-video bg-slate-100 flex items-center justify-center">
                <?php if ($sn): ?><img src="<?= $h($sn['path']) ?>?v=<?= $h(strtotime($sn['taken_at'])) ?>" alt="<?= $h($c['name'] ?: $c['location']) ?>" loading="lazy" class="w-full h-full object-cover">
                <?php else: ?><span class="text-xs text-slate-400"><?= $h(cL('Belum ada snapshot', 'No snapshot')) ?></span><?php endif; ?>
            </div>
            <div class="p-2 space-y-0.5">
                <div class="flex items-start justify-between gap-2">
                    <p class="font-medium text-slate-800"><?= $i + 1 ?>. <?= $h($c['name'] ?: $c['location']) ?></p>
                    <span class="shrink-0 text-xs rounded-full px-2 py-0.5 <?= $badge[$s] ?? 'bg-slate-100 text-slate-500' ?>"><?= $h($statusText($s)) ?></span>
                </div>
<p class="text-xs text-slate-600"><?= $h($c['location'] ?: '-') ?></p>
                <p class="text-xs text-slate-500"><?= $h(($info[$c['id']]['model'] ?? '') ?: '-') ?> · <?= $h($chLabel($c)) ?> · <?= $h($c['ip'] ?: '-') ?></p>
                <p class="text-xs text-slate-400"><?= $h($c['number']) ?><?= $sn ? ' · ' . $h(date('d/m H:i', strtotime($sn['taken_at']))) . ($sn['source'] === 'checklist' ? ' (' . cL('foto checklist', 'checklist photo') . ')' : '') : '' ?></p>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</section>
<?php endforeach; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
