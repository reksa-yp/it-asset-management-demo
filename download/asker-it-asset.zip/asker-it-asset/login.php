<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/login_guard.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: ' . (($_SESSION['role'] ?? '') === 'admin' ? 'dashboard.php' : 'my_asset.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = t('error_required');
    } elseif (($lockWait = loginLockedSeconds(getDB(), $username)) > 0) {
        // Terlalu banyak salah password: tunggu dulu (percobaan tidak diperiksa sama sekali).
        $error = currentLang() === 'en'
            ? 'Too many wrong attempts. Try again in ' . max(1, (int)ceil($lockWait / 60)) . ' minute(s).'
            : 'Terlalu banyak percobaan salah. Coba lagi ' . max(1, (int)ceil($lockWait / 60)) . ' menit lagi.';
    } else {
        $stmt = getDB()->prepare('SELECT * FROM users WHERE username = ? AND is_active = 1 LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            loginRecord(getDB(), $username, true);
            session_regenerate_id(true);
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['username']  = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role']      = $user['role'];

            // Admin -> dashboard penuh. User biasa -> aset pribadi.
            // Login karena scan QR label -> langsung ke aset yang di-scan (hanya alamat scan.php yang diterima).
            $after = (string)($_SESSION['after_login'] ?? '');
            unset($_SESSION['after_login']);
            if (preg_match('/^scan\.php\?no=[A-Za-z0-9%._~\-]+$/', $after)) {
                header('Location: ' . $after);
                exit;
            }
            header('Location: ' . ($user['role'] === 'admin' ? 'dashboard.php' : 'my_asset.php'));
            exit;
        } else {
            loginRecord(getDB(), $username, false);
            $error = t('error_invalid');
        }
    }
}

$lang = currentLang();
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($lang) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — <?= htmlspecialchars(t('app_name')) ?></title>
<?= appFaviconTag() ?>
<?php $twCss = __DIR__ . '/assets/css/tailwind.css'; ?>
<link rel="stylesheet" href="assets/css/tailwind.css?v=<?= is_file($twCss) ? filemtime($twCss) : 0 ?>"><?php /* Tailwind lokal: tampilan tetap utuh tanpa internet (scripts/tailwind) */ ?>
</head>
<body class="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-800 via-slate-700 to-slate-900 px-4">
    <div class="w-full max-w-sm bg-white rounded-2xl shadow-xl p-8 relative">

        <!-- Pilihan bahasa: EN / ID, ditampilkan sebelum user login -->
        <div class="absolute top-4 right-4 flex items-center gap-1 bg-slate-100 rounded-full p-1">
            <span class="pl-1.5 pr-0.5 text-slate-400"><?= icon('globe', 'w-3.5 h-3.5') ?></span>
            <a href="set_lang.php?lang=id&redirect=login.php"
               title="Bahasa Indonesia"
               class="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold transition
                      <?= $lang === 'id' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700' ?>">
                ID
            </a>
            <a href="set_lang.php?lang=en&redirect=login.php"
               title="English"
               class="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold transition
                      <?= $lang === 'en' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700' ?>">
                EN
            </a>
        </div>

        <div class="text-center mb-6 mt-4">
            <div class="flex justify-center"><?= appLogoHtml('w-14 h-14 rounded-2xl', 'bg-blue-600 text-white font-bold text-xl') ?></div>
            <h1 class="mt-3 text-xl font-bold text-slate-800"><?= htmlspecialchars(t('app_name')) ?></h1>
            <p class="text-sm text-slate-500"><?= t('login_subtitle') ?></p>
        </div>

        <?php if ($error): ?>
            <div class="mb-4 text-sm bg-red-50 text-red-600 border border-red-200 rounded-lg px-3 py-2">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="post" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-slate-600 mb-1"><?= t('label_username') ?></label>
                <input type="text" name="username" required autofocus
                       class="w-full rounded-lg border-slate-300 focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border">
            </div>
            <div>
                <label class="block text-sm font-medium text-slate-600 mb-1"><?= t('label_password') ?></label>
                <input type="password" name="password" required
                       class="w-full rounded-lg border-slate-300 focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border">
            </div>
            <button type="submit"
                    class="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg py-2.5 text-sm transition">
                <?= t('btn_login') ?>
            </button>
        </form>
        <p class="mt-6 text-center text-xs text-slate-400">@Copyright by ASKER</p>
    </div>
</body>
</html>
