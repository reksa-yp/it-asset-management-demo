<?php
/**
 * Simpan data Aset Rusak: tandai rusak (create), update (lokasi / status perbaikan), hapus catatan.
 * Hanya mengisi tabel BARU asset_damages + memperbarui kolom yang sudah ada di tabel assets
 * (status, location) dan asset_owners (jika pengguna dilepas). Struktur tabel lama tidak diubah.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/damage.php';
require_once __DIR__ . '/includes/mutation.php';

$back = 'damages.php?' . preg_replace('/[^A-Za-z0-9_=&%.\-]/', '', (string)($_POST['back'] ?? ''));
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . $back); exit; }
csrfCheck();

$db = getDB();
ensureDamageTable($db);

$action  = (string)($_POST['action'] ?? '');
$date    = trim((string)($_POST['damage_date'] ?? ''));
$issue   = mb_substr(trim((string)($_POST['issue'] ?? '')), 0, 255);
$storage = mb_substr(trim((string)($_POST['storage_location'] ?? '')), 0, 100);
$note    = mb_substr(trim((string)($_POST['note'] ?? '')), 0, 2000);
$today   = date('Y-m-d');

$done = function (bool $ok, string $text) use ($back) {
    $_SESSION['damage_msg'] = ['ok' => $ok, 'text' => $text];
    header('Location: ' . $back);
    exit;
};
$validDate = fn($d) => preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && strtotime($d);

if ($action === 'create' || $action === 'update') {
    if (!$validDate($date)) $done(false, t('dmg_err_date'));
    if ($date > $today) $done(false, t('dmg_err_date_future'));
    if ($issue === '') $done(false, t('dmg_err_issue'));
    if ($storage === '') $done(false, t('dmg_err_storage'));
}

$loadAsset = function (int $id) use ($db) {
    $s = $db->prepare("SELECT id, asset_number, category, device_name, status, location FROM assets WHERE id = ?");
    $s->execute([$id]);
    return $s->fetch() ?: null;
};

// ================= TANDAI RUSAK =================
if ($action === 'create') {
    $asset = $loadAsset((int)($_POST['asset_id'] ?? 0));
    if (!$asset) $done(false, t('dmg_err_asset'));
    if (getOpenDamageMap($db, [(int)$asset['id']])) $done(false, t('dmg_err_already_open', $asset['asset_number']));

    $release = !empty($_POST['release_owner']);
    $before  = mutationSnapshot($db, (int)$asset['id']);
    $hasOwners = $before && $before['user_ids'] !== '';
    if ($release && $hasOwners) ensureMutationTable($db);   // DDL sebelum transaksi
    $me = currentUser();

    $db->beginTransaction();
    try {
        $db->prepare("INSERT INTO asset_damages (asset_id, asset_number, asset_category, asset_name, damage_date, issue,
                      storage_location, last_user_names, last_department, prev_status, state, note, created_by, created_by_name)
                      VALUES (?,?,?,?,?,?,?,?,?,?,'broken',?,?,?)")
           ->execute([(int)$asset['id'], $asset['asset_number'], mb_substr((string)$asset['category'], 0, 60),
                      mb_substr((string)($asset['device_name'] ?? ''), 0, 150) ?: null, $date, $issue, $storage,
                      $hasOwners ? mb_substr($before['user_names'], 0, 500) : null,
                      $hasOwners && $before['department'] ? mb_substr($before['department'], 0, 100) : null,
                      $asset['status'], $note ?: null, $me['id'] ?? null, mb_substr((string)($me['full_name'] ?? ''), 0, 100) ?: null]);

        $db->prepare("UPDATE assets SET status = 'Tidak Digunakan', location = ? WHERE id = ?")->execute([$storage, (int)$asset['id']]);
        $extra = '';
        if ($release && $hasOwners) {
            setAssetOwners($db, (int)$asset['id'], []);
            syncAssetUserData($db, (int)$asset['id']);
            $mutNo = recordAssetMutation($db, $before, mutationSnapshot($db, (int)$asset['id']), [
                'date' => $date, 'reason' => 'return', 'condition' => 'broken', 'source' => 'damage',
                'note' => t('dmg_mut_note', $issue, $storage),
            ]);
            $extra = ' ' . t('dmg_saved_released', $before['user_names'], $mutNo);
        }
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $done(false, t('dmg_err_save', $e->getMessage()));
    }
    $done(true, t('dmg_saved', $asset['asset_number'], $storage) . $extra);
}

// ================= UPDATE / HAPUS =================
$id = (int)($_POST['id'] ?? 0);
$s = $db->prepare("SELECT * FROM asset_damages WHERE id = ?");
$s->execute([$id]);
$dmg = $s->fetch();
if (!$dmg) $done(false, t('dmg_err_not_found'));
$asset = $loadAsset((int)$dmg['asset_id']);   // bisa null jika aset sudah dihapus dari Data Aset

if ($action === 'update') {
    $state = (string)($_POST['state'] ?? $dmg['state']);
    if (!isset(DAMAGE_STATES[$state])) $state = $dmg['state'];
    $wasOpen = damageStateOpen($dmg['state']);
    $isOpen  = damageStateOpen($state);
    if (!$wasOpen && $isOpen && $asset) {
        $other = getOpenDamageMap($db, [(int)$asset['id']]);
        if ($other && (int)reset($other)['id'] !== $id) $done(false, t('dmg_err_already_open', $asset['asset_number']));
    }
    $closed = $isOpen ? null : ($wasOpen ? $today : ($dmg['closed_date'] ?: $today));

    $db->beginTransaction();
    try {
        $db->prepare("UPDATE asset_damages SET damage_date = ?, issue = ?, storage_location = ?, state = ?, note = ?, closed_date = ? WHERE id = ?")
           ->execute([$date, $issue, $storage, $state, $note ?: null, $closed, $id]);
        $msg = t('dmg_updated', $dmg['asset_number']);
        if ($asset) {
            if ($isOpen) {
                // Masih rusak / dalam perbaikan: aset Tidak Digunakan & lokasinya = lokasi penyimpanan.
                $db->prepare("UPDATE assets SET status = 'Tidak Digunakan', location = ? WHERE id = ?")->execute([$storage, (int)$asset['id']]);
            } elseif ($state === 'fixed' && $wasOpen) {
                // Selesai diperbaiki: kembali ke Stok (atau Digunakan bila pengguna tidak dilepas saat rusak).
                $owners = assetOwnersTableExists($db) ? getOwnersForAsset($db, (int)$asset['id']) : [];
                $newStatus = $owners ? 'Digunakan' : 'Stok';
                $db->prepare("UPDATE assets SET status = ? WHERE id = ?")->execute([$newStatus, (int)$asset['id']]);
                $msg .= ' ' . t('dmg_fixed_status', $newStatus === 'Stok' ? t('status_stock') : t('status_used'));
            } elseif ($state === 'disposed') {
                $db->prepare("UPDATE assets SET status = 'Tidak Digunakan' WHERE id = ?")->execute([(int)$asset['id']]);
                if ($wasOpen) $msg .= ' ' . t('dmg_disposed_note');
            }
        }
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $done(false, t('dmg_err_save', $e->getMessage()));
    }
    $done(true, $msg);
}

if ($action === 'delete') {
    // Hapus catatan (mis. salah input). Bila catatan masih terbuka, status aset dikembalikan seperti sebelum ditandai rusak.
    $db->beginTransaction();
    try {
        $db->prepare("DELETE FROM asset_damages WHERE id = ?")->execute([$id]);
        if ($asset && damageStateOpen($dmg['state'])) {
            $owners = assetOwnersTableExists($db) ? getOwnersForAsset($db, (int)$asset['id']) : [];
            $prev = in_array($dmg['prev_status'], ['Digunakan', 'Stok', 'Tidak Digunakan'], true) ? $dmg['prev_status'] : 'Stok';
            if ($prev === 'Digunakan' && !$owners) $prev = 'Stok';
            $db->prepare("UPDATE assets SET status = ? WHERE id = ?")->execute([$prev, (int)$asset['id']]);
        }
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $done(false, t('dmg_err_save', $e->getMessage()));
    }
    $done(true, t('dmg_deleted', $dmg['asset_number']));
}

$done(false, t('dmg_err_not_found'));
