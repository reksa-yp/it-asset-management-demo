<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$importMsg = $_SESSION['import_msg'] ?? null;
unset($_SESSION['import_msg']);

$pageTitle = t('page_title_import_export');
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-5">

    <div class="bg-white rounded-xl shadow-sm p-5">
        <h2 class="font-semibold text-slate-700 mb-2"><?= t('step1_title') ?></h2>
        <p class="text-sm text-slate-500 mb-4">
            <?= t('step1_desc') ?>
        </p>
        <a href="download_template.php"
           class="inline-flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('download') ?> <?= t('btn_download_template_excel') ?>
        </a>
    </div>

    <div class="bg-white rounded-xl shadow-sm p-5">
        <h2 class="font-semibold text-slate-700 mb-2"><?= t('step2_title') ?></h2>
        <p class="text-sm text-slate-500 mb-4">
            <?= t('step2_desc') ?>
        </p>
        <a href="export_excel.php"
           class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            <?= icon('sheet') ?> <?= t('btn_export_excel') ?>
        </a>
    </div>

    <div class="bg-white rounded-xl shadow-sm p-5 lg:col-span-2">
        <h2 class="font-semibold text-slate-700 mb-2"><?= t('step3_title') ?></h2>

        <?php if ($importMsg): ?>
            <div class="mb-3 text-sm rounded-lg px-3 py-2 <?= $importMsg['ok'] ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700' ?>">
                <?= htmlspecialchars($importMsg['text']) ?>
            </div>
        <?php endif; ?>

        <form method="post" action="import_process.php" enctype="multipart/form-data" class="flex flex-wrap items-center gap-3 text-sm">
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
            <input type="file" name="excel_file" accept=".xlsx,.xls" required style="max-width:100%"
                   class="border rounded-lg px-3 py-2 text-sm">
            <button class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 font-medium"><?= t('btn_upload_import') ?></button>
        </form>
        <p class="text-xs text-slate-400 mt-2">
            <?= t('import_instructions') ?>
        </p>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
