<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/vendor/autoload.php'; // composer require phpoffice/phpspreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

$db = getDB();

// ===== Filter export (dari modal Export di menu Management User) =====
//   dept[]  : satu atau beberapa departement ('__none__' = user tanpa departement). Kosong = semua.
//   active  : '1' aktif saja, '0' nonaktif saja, '' semua.
$deptFilter = array_values(array_unique(array_filter(array_map(
    fn($d) => trim((string)$d),
    (array)($_GET['dept'] ?? [])
), fn($d) => $d !== '')));
$activeFilter = (string)($_GET['active'] ?? '');

$conditions = [];
$params = [];
if ($deptFilter) {
    $parts = [];
    $named = array_values(array_filter($deptFilter, fn($d) => $d !== '__none__'));
    if ($named) {
        $parts[] = 'department IN (' . implode(',', array_fill(0, count($named), '?')) . ')';
        array_push($params, ...$named);
    }
    if (in_array('__none__', $deptFilter, true)) {
        $parts[] = "(department IS NULL OR department = '')";
    }
    $conditions[] = '(' . implode(' OR ', $parts) . ')';
}
if ($activeFilter === '1' || $activeFilter === '0') {
    $conditions[] = 'is_active = ?';
    $params[] = (int)$activeFilter;
}

$stmt = $db->prepare("
    SELECT id, full_name, username, email, department, pc_username, pc_password, role, is_active, created_at
    FROM users" . ($conditions ? ' WHERE ' . implode(' AND ', $conditions) : '') . "
    ORDER BY department, full_name
");
$stmt->execute($params);
$users = $stmt->fetchAll();

// Catatan: kolom Password (login sistem) sengaja TIDAK diexport (hash tidak berguna & tidak aman untuk dibagikan).
// Saat diimport kembali, kosongkan kolom Password agar password lama tetap dipakai.
// Username PC / Password PC ikut diexport apa adanya karena hanya data referensi IT, disimpan plain (bukan hash).
$headers = ['Nama Lengkap', 'Username', 'Email', 'Departement', 'Jabatan', 'Password', 'Username PC', 'Password PC', 'Role', 'Status', 'Tanggal Dibuat'];

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Users');

$sheet->fromArray($headers, null, 'A1');

$userPositionMap = getUserPositionMap($db);
$dataRows = [];
foreach ($users as $u) {
    $dataRows[] = [
        $u['full_name'],
        $u['username'],
        $u['email'],
        $u['department'],
        $userPositionMap[(int)$u['id']] ?? '',
        '', // password login sistem tidak diexport
        $u['pc_username'],
        $u['pc_password'],
        $u['role'],
        $u['is_active'] ? 'Aktif' : 'Nonaktif',
        date('Y-m-d', strtotime($u['created_at'])),
    ];
}

if ($dataRows) {
    $sheet->fromArray($dataRows, null, 'A2');
}

$lastCol = count($headers);
$lastRow = 1 + count($dataRows);

// ===== Styling: header bold + background, border seluruh tabel, auto-fit kolom =====
$headerRange = 'A1:' . \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($lastCol) . '1';
$sheet->getStyle($headerRange)->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
$sheet->getStyle($headerRange)->getFill()
      ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('1F3DD1');
$sheet->getStyle($headerRange)->getAlignment()->setHorizontal('center');

if ($lastRow >= 1) {
    $fullRange = 'A1:' . \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($lastCol) . $lastRow;
    $sheet->getStyle($fullRange)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
}

// Auto-fit lebar kolom
for ($c = 1; $c <= $lastCol; $c++) {
    $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($c);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}
$sheet->freezePane('A2');

// Kolom No di paling kiri (dipanggil terakhir supaya gaya & huruf kolom di atas tidak perlu diubah).
require_once __DIR__ . '/includes/xls_number.php';
xlsAddNumberColumn($sheet, 1, $lastRow);
require_once __DIR__ . '/includes/letterhead.php';
xlsAddTitleBlock($sheet, 1, xlsL('Data User ', 'User Data ') . xlsCompanyName(),
    [documentCreatedAt(), xlsCountLine('Jumlah user', 'Total users', count($dataRows))]);

// ===== Output =====
// Nama file ikut menyebut departement yang dipilih, mis. users_EXIM_Finance_20260930_101500.xlsx
$fileTag = '';
if ($deptFilter && count($deptFilter) <= 4) {
    $fileTag = implode('_', array_map(
        fn($d) => $d === '__none__' ? 'TanpaDept' : preg_replace('/[^A-Za-z0-9-]+/', '-', $d),
        $deptFilter
    )) . '_';
} elseif ($deptFilter) {
    $fileTag = count($deptFilter) . 'dept_';
}
$filename = 'users_' . ($fileTag !== '' ? $fileTag : 'export_') . date('Ymd_His') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
