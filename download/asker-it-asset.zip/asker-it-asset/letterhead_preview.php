<?php
/**
 * Contoh dokumen berkop (khusus admin): untuk memeriksa tampilan kop surat sebelum dipakai.
 * Isinya teks contoh, tidak membaca data apa pun.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/letterhead.php';
$h = fn($v) => htmlspecialchars((string)$v);
?>
<!DOCTYPE html>
<html lang="<?= $h(currentLang()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $h(t('lh_sample_title')) ?></title>
<style>
    @page { size: A4; margin: 14mm 14mm; }
    body { font-family: Arial, sans-serif; color: #1e293b; margin: 24px; font-size: 12px; }
    .head { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 1.5px solid #173A68; padding-bottom: 6px; margin-bottom: 14px; }
    .head .name { font-size: 13px; font-weight: bold; }
    .muted { color: #64748b; }
    h1 { text-align: center; font-size: 15px; margin: 6px 0 14px; letter-spacing: .5px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #cbd5e1; padding: 5px 7px; text-align: left; vertical-align: top; }
    th { background: #eef2ff; }
    .no-print { margin-top: 20px; text-align: center; }
    .no-print button { background: #1F3DD1; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 13px; cursor: pointer; }
    @media print { body { margin: 0; } .no-print { display: none; } tr { page-break-inside: avoid; } }
<?= letterheadCss() ?></style>
</head>
<body>
    <?= letterheadOpen() ?>
    <div class="head"><div class="name"><?= $h(t('lh_sample_title')) ?></div><div class="muted"><?= $h(documentCreatedAt()) ?></div></div>
    <h1><?= $h(mb_strtoupper(t('lh_sample_title'))) ?></h1>
    <p><?= $h(t('lh_sample_text')) ?></p>
    <table>
        <thead><tr><th style="width:32px">No</th><th><?= $h(t('lh_sample_col1')) ?></th><th><?= $h(t('lh_sample_col2')) ?></th><th><?= $h(t('lh_sample_col3')) ?></th></tr></thead>
        <tbody>
        <?php for ($i = 1; $i <= 6; $i++): ?>
            <tr><td><?= $i ?></td><td><?= $h(t('lh_sample_col1')) ?> <?= $i ?></td><td>—</td><td>—</td></tr>
        <?php endfor; ?>
        </tbody>
    </table>
    <?= letterheadClose() ?>
    <div class="no-print"><button onclick="window.print()"><?= t('btn_print') ?></button></div>
</body>
</html>
