<?php
/**
 * API untuk Agen Kantor (tanpa login; diamankan dengan kunci agen).
 * Agen memanggil alamat ini berulang-ulang (POST JSON):
 *   { "key": "...", "info": {...}, "results": { "probes": {id: {code, body(base64)}}, "jobs": {id: {...}} } }
 * Jawaban: { "ok": true, "probes": [...], "jobs": [...], "next": detik }
 * Setelah menyimpan hasil, server menjalankan cek CCTV (sesuai interval) sehingga Cron Job tidak wajib.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
ini_set('display_errors', '0');
date_default_timezone_set('Asia/Jakarta');
define('CCTV_AGENT_CONTEXT', true);   // jangan menunggu agen di dalam permintaan agen sendiri

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/cctv.php';

$out = function (int $status, array $data) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
};

if ($_SERVER['REQUEST_METHOD'] !== 'POST') $out(405, ['ok' => false, 'error' => 'POST only']);
$raw = (string)file_get_contents('php://input', false, null, 0, 30 * 1024 * 1024);
$in = json_decode($raw, true);
if (!is_array($in)) $out(400, ['ok' => false, 'error' => 'JSON?']);

$set = agentSettings(true);
$key = (string)($in['key'] ?? ($_SERVER['HTTP_X_AGENT_KEY'] ?? ''));
if (!$set['enabled'] || $set['key'] === '' || !hash_equals($set['key'], $key)) {
    usleep(500000);   // perlambat tebakan kunci
    $out(403, ['ok' => false, 'error' => 'Kunci agen salah atau Agen Kantor belum diaktifkan di menu Agen Kantor.']);
}

// Info PC agen (ditampilkan di menu Agen Kantor).
$info = [];
foreach (['host', 'php', 'version', 'os', 'ip'] as $k) if (isset($in['info'][$k])) $info[$k] = mb_substr((string)$in['info'][$k], 0, 80);
saveAgentSettings(['last_seen' => time(), 'info' => $info ?: $set['info']]);

$res = (array)($in['results'] ?? []);
$nProbe = agentStoreProbeResults((array)($res['probes'] ?? []));
$nJob = agentStoreJobResults((array)($res['jobs'] ?? []));

// Cek CCTV terjadwal: dijalankan dari sini sesuai interval (lock yang sama dengan cctv_check.php).
$cctv = '';
$interval = max(55, (int)cctvSettings()['interval_min'] * 60 - 5);
if (time() - (int)$set['last_cctv'] >= $interval) {
    $lock = @fopen(__DIR__ . '/includes/data/cctv_check.lock', 'c');
    if ($lock && flock($lock, LOCK_EX | LOCK_NB)) {
        saveAgentSettings(['last_cctv' => time()]);
        @set_time_limit(300);
        try {
            $db = getDB();
            $hasCams = (int)$db->query("SELECT COUNT(*) FROM cctv_nvr")->fetchColumn() > 0 || cctvCameras($db);
            if ($hasCams) {
                runCctvCheck($db);
                require_once __DIR__ . '/includes/cctv_snapshot.php';
                cctvAutoSnapshotDaily($db);
                $cctv = (string)cctvSettings(true)['last_run_info'];
            }
        } catch (Throwable $e) {
            $cctv = 'ERROR: ' . $e->getMessage();
        }
        flock($lock, LOCK_UN);
    }
    if ($lock) fclose($lock);
}

// Pekerjaan berikutnya untuk agen.
$probes = agentPendingProbes();
$jobs = agentPendingJobs();
$hot = agentIsHot();
$out(200, [
    'ok'      => true,
    'time'    => date('Y-m-d H:i:s'),
    'stored'  => ['probes' => $nProbe, 'jobs' => $nJob],
    'cctv'    => $cctv,
    'probes'  => $probes,
    'jobs'    => $jobs,
    'next'    => ($probes || $jobs) ? 0 : ($hot ? 2 : 10),
    'version' => AGENT_VERSION,
]);
