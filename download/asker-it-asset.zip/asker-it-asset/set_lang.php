<?php
/**
 * Ganti bahasa aktif (EN/ID) lalu redirect kembali ke halaman asal.
 * Dipakai oleh tombol bahasa di halaman login maupun di topbar dashboard.
 */
require_once __DIR__ . '/includes/auth.php';

$lang = $_GET['lang'] ?? 'id';
setLang($lang);

$redirect = $_GET['redirect'] ?? '';
// Hanya izinkan redirect ke halaman lokal (bukan URL luar) demi keamanan.
if ($redirect === '' || preg_match('#^https?://#i', $redirect) || strpos($redirect, '//') === 0) {
    $redirect = 'login.php';
}

header('Location: ' . $redirect);
exit;
