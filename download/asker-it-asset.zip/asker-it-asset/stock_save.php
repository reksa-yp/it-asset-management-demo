<?php
/**
 * Simpan (tambah / edit) transaksi stok masuk atau keluar.
 *
 * Tambahan fitur Stok ber-ID Aset:
 *  - Barang Masuk + centang "Daftarkan sebagai aset": tiap unit dibuatkan aset baru
 *    (status Stok, nomor <Awalan>/STOK/<jenis>/<urut>) dan dihubungkan lewat tabel stock_asset_links.
 *  - Barang Keluar untuk barang ber-ID: admin memilih ID aset yang diberikan. Aset otomatis
 *    diserahkan ke user (status Digunakan, pengguna terisi) + tercatat di Mutasi Aset.
 *  - Transaksi yang sudah terhubung dengan aset hanya boleh diubah tanggal & keterangannya.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/stock.php';
require_once __DIR__ . '/includes/mutation.php';

$back = 'stock.php?' . preg_replace('/[^A-Za-z0-9_=&%.\-]/', '', (string)($_POST['back'] ?? 'tab=history'));
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . $back); exit; }
csrfCheck();

$db = getDB();
ensureStockTables($db);

$id     = (int)($_POST['id'] ?? 0);
$type   = ($_POST['type'] ?? '') === 'out' ? 'out' : 'in';
$catId  = (int)($_POST['category_id'] ?? 0);
$date   = trim($_POST['trx_date'] ?? '');
$qty    = (int)($_POST['qty'] ?? 0);
$item   = mb_substr(trim($_POST['item_name'] ?? ''), 0, 100);
$note   = mb_substr(trim($_POST['note'] ?? ''), 0, 255);
$userId = (int)($_POST['user_id'] ?? 0);
$registerAsset = !$id && $type === 'in' && !empty($_POST['register_asset']);
$assetCatName  = trim((string)($_POST['asset_category'] ?? ''));
$pickedAssets  = ($type === 'out' && !$id)
    ? array_values(array_unique(array_filter(array_map('intval', (array)($_POST['asset_ids'] ?? [])))))
    : [];

$fail = function (string $key, ...$args) use ($back) {
    $_SESSION['stock_msg'] = ['ok' => false, 'text' => t($key, ...$args)];
    header('Location: ' . $back);
    exit;
};

$old = null;
$oldLinked = [];
if ($id) {
    $s = $db->prepare("SELECT * FROM stock_transactions WHERE id = ?");
    $s->execute([$id]);
    $old = $s->fetch();
    if (!$old) $fail('stock_err_not_found');
    $oldLinked = getStockTrxAssets($db, [$id])[$id] ?? [];
    if ($oldLinked) {
        // Terhubung dengan ID aset: kategori, barang, jumlah, jenis & penerima dikunci (pakai data lama).
        $type   = $old['type'];
        $catId  = (int)$old['category_id'];
        $qty    = (int)$old['qty'];
        $item   = (string)$old['item_name'];
        $userId = (int)$old['user_id'];
    }
}

$cat = $db->prepare("SELECT * FROM stock_categories WHERE id = ?");
$cat->execute([$catId]);
$cat = $cat->fetch();
if (!$cat) $fail('stock_err_category');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !strtotime($date)) $fail('stock_err_date');
if ($pickedAssets) $qty = count($pickedAssets);   // Barang Keluar ber-ID: jumlah = banyaknya ID dipilih
if ($qty < 1) $fail('stock_err_qty');

// ===== Edit transaksi ber-ID: hanya tanggal & keterangan =====
if ($oldLinked) {
    $db->beginTransaction();
    try {
        $db->prepare("UPDATE stock_transactions SET trx_date = ?, note = ? WHERE id = ?")->execute([$date, $note ?: null, $id]);
        // Barang Masuk: tanggal pembelian aset ikut disesuaikan (hanya yang masih sama dengan tanggal lama).
        if ($old['type'] === 'in' && $date !== $old['trx_date'] && assetsHasColumn($db, 'purchase_date')) {
            $ids = array_column($oldLinked, 'id');
            $ph  = implode(',', array_fill(0, count($ids), '?'));
            $db->prepare("UPDATE assets SET purchase_date = ? WHERE purchase_date = ? AND id IN ($ph)")
               ->execute([$date, $old['trx_date'], ...$ids]);
        }
        $db->commit();
    } catch (Throwable $e) {
        $db->rollBack();
        $fail('stock_err_save_generic', $e->getMessage());
    }
    $_SESSION['stock_msg'] = ['ok' => true, 'text' => t('stock_updated_linked')];
    header('Location: ' . $back);
    exit;
}

$recipientName = null; $recipientDept = null;
if ($type === 'out') {
    $u = $db->prepare("SELECT id, full_name, department FROM users WHERE id = ?");
    $u->execute([$userId]);
    $u = $u->fetch();
    if (!$u) $fail('stock_err_user');
    $recipientName = $u['full_name'];
    $recipientDept = $u['department'];
} else {
    $userId = 0;
}

// Validasi stok: setelah transaksi ini disimpan, stok kategori tidak boleh minus.
$after = stockAvailable($db, $catId, $id) + ($type === 'in' ? $qty : -$qty);
if ($after < 0) {
    $fail('stock_err_over', stockAvailable($db, $catId, $id));
}
// Barang Keluar wajib memilih barang yang sudah pernah dicatat di Barang Masuk (per kategori),
// dan jumlahnya tidak boleh melebihi stok barang tersebut.
if ($type === 'out') {
    // Pakai penulisan nama barang persis seperti saat Barang Masuk (supaya rekap per barang rapi).
    $canon = $db->prepare("SELECT item_name FROM stock_transactions WHERE type = 'in' AND category_id = ?
                           AND LOWER(TRIM(COALESCE(item_name,''))) = LOWER(TRIM(?)) ORDER BY id LIMIT 1");
    $canon->execute([$catId, $item]);
    $canonName = $canon->fetchColumn();
    if ($canonName !== false) $item = trim((string)$canonName);
    $itemAvail = stockItemAvailable($db, $catId, $item, $id);
    if ($itemAvail < $qty) {
        $fail('stock_err_item_over', $item !== '' ? $item : t('stock_item_noname'), max(0, $itemAvail));
    }

    // Unit ber-ID (hasil Barang Masuk yang didaftarkan sebagai aset) yang masih berstatus Stok.
    $itemKey = mb_strtolower(trim($item));
    $units = array_values(array_filter(getStockItemUnits($db), fn($u) => $u['cat'] === $catId && $u['key'] === $itemKey));
    $unitIds = array_column($units, 'id');
    if ($pickedAssets) {
        foreach ($pickedAssets as $aid) {
            if (!in_array($aid, $unitIds, true)) $fail('stock_err_unit_invalid');
        }
    } elseif ($units && !$id && ($itemAvail - count($units)) < $qty) {
        // Semua sisa stok barang ini ber-ID -> wajib pilih ID aset yang diberikan.
        $fail('stock_err_pick_units');
    }
}

// Mengubah Barang Masuk tidak boleh membuat stok barang itu minus (mis. jumlah dikurangi padahal sudah keluar).
if ($old && $old['type'] === 'in') {
    $oldItem = trim((string)$old['item_name']);
    $beforeOld = stockItemAvailable($db, (int)$old['category_id'], $oldItem, 0);
    $sameItem  = (int)$old['category_id'] === $catId && mb_strtolower($oldItem) === mb_strtolower($item);
    $afterOld  = stockItemAvailable($db, (int)$old['category_id'], $oldItem, $id) + ($sameItem ? ($type === 'in' ? $qty : -$qty) : 0);
    if ($afterOld < 0 && $beforeOld >= 0) {
        $fail('stock_err_item_negative', $oldItem !== '' ? $oldItem : t('stock_item_noname'));
    }
}
// Jika kategori transaksi lama diganti, stok kategori lama juga tidak boleh jadi minus.
if ($old && (int)$old['category_id'] !== $catId && stockAvailable($db, (int)$old['category_id'], $id) < 0) {
    $fail('stock_err_old_category');
}

// ===== Validasi "Daftarkan sebagai aset" =====
$assetAbbr = null;
if ($registerAsset) {
    if ($item === '') $fail('stock_err_asset_item');
    if ($qty > STOCK_ASSET_MAX_UNITS) $fail('stock_err_asset_max', STOCK_ASSET_MAX_UNITS);
    require_once __DIR__ . '/includes/categories.php';
    $assetAbbr = $assetCatName !== '' ? getCategoryAbbr($db, $assetCatName) : null;
    if (!$assetAbbr) $fail('stock_err_asset_category');
}

// Tabel tambahan dibuat SEBELUM transaksi DB (CREATE TABLE membuat MySQL auto-commit).
if ($registerAsset || $pickedAssets) ensureStockAssetLinkTable($db);
if ($pickedAssets) {
    if (!assetOwnersTableExists($db)) $fail('asset_stock_err_migration');
    ensureMutationTable($db);
}

$params = [$catId, $type, $date, $qty, $item ?: null, $userId ?: null, $recipientName, $recipientDept, $note ?: null];
if ($id) {
    $db->prepare("UPDATE stock_transactions SET category_id=?, type=?, trx_date=?, qty=?, item_name=?, user_id=?,
                  recipient_name=?, recipient_department=?, note=? WHERE id=?")
       ->execute([...$params, $id]);
    $_SESSION['stock_msg'] = ['ok' => true, 'text' => t('stock_updated')];
    header('Location: ' . $back);
    exit;
}

$db->beginTransaction();
try {
    $db->prepare("INSERT INTO stock_transactions (category_id, type, trx_date, qty, item_name, user_id,
                  recipient_name, recipient_department, note, created_by) VALUES (?,?,?,?,?,?,?,?,?,?)")
       ->execute([...$params, (int)$_SESSION['user_id']]);
    $trxId = (int)$db->lastInsertId();

    if ($registerAsset) {
        $numbers = createAssetsFromStockIn($db, $trxId, $assetCatName, $assetAbbr, $item, $date, $qty);
        $msg = t('stock_saved_in_assets', $qty, $cat['unit'], $item,
                 count($numbers) > 1 ? $numbers[0] . ' – ' . end($numbers) : $numbers[0]);
    } elseif ($pickedAssets) {
        $handed = [];
        foreach ($pickedAssets as $aid) {
            $before = mutationSnapshot($db, $aid);
            setAssetOwners($db, $aid, [$userId]);
            $db->prepare("UPDATE assets SET status = 'Digunakan' WHERE id = ?")->execute([$aid]);
            syncAssetUserData($db, $aid);
            recordAssetMutation($db, $before, mutationSnapshot($db, $aid), [
                'date' => $date, 'reason' => 'handover', 'source' => 'stock',
                'note' => trim(t('stock_mut_note', $trxId) . ($note !== '' ? ' — ' . $note : '')),
            ]);
            $handed[] = $before['asset_number'];
        }
        stockLinkAssets($db, $trxId, $pickedAssets);
        $msg = t('stock_saved_out_assets', count($handed), $recipientName, implode(', ', $handed));
    } else {
        $msg = $type === 'in'
            ? t('stock_saved_in', $qty, $cat['unit'], $cat['name'])
            : t('stock_saved_out', $qty, $cat['unit'], $cat['name'], $recipientName);
    }
    $db->commit();
    $_SESSION['stock_msg'] = ['ok' => true, 'text' => $msg];
} catch (Throwable $e) {
    if ($db->inTransaction()) $db->rollBack();
    $fail('stock_err_save_generic', $e->getMessage());
}
header('Location: ' . $back);
