<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/mutation.php';
require_once __DIR__ . '/includes/asset_accessories.php';
require_once __DIR__ . '/includes/asset_number.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: assets.php');
    exit;
}
csrfCheck();

$id           = $_POST['id'] ?: null;
$assetNumber  = trim($_POST['asset_number'] ?? '');
$category     = $_POST['category'] ?? '';
$deviceName   = trim($_POST['device_name'] ?? '');
// 1 aset sekarang bisa dipakai beberapa pengguna sekaligus (semua setara,
// tanpa "pengguna utama"). Departement & Email Pengguna jadi field manual,
// tidak lagi otomatis ikut dari 1 user tertentu. Lihat includes/asset_owners.php.
$ownerIds     = array_map('intval', (array)($_POST['owner_user_id'] ?? []));
$department   = trim($_POST['department'] ?? '');
$ownerEmail   = trim($_POST['owner_email'] ?? '');
$ip           = trim($_POST['ip_address'] ?? '');
$hostname     = trim($_POST['hostname'] ?? '');
$location     = trim($_POST['location'] ?? '');
$processor    = trim($_POST['processor'] ?? '');
$ram          = trim($_POST['ram'] ?? '');
$storage      = trim($_POST['storage'] ?? '');
$printerInfo  = trim($_POST['printer_info'] ?? '');
$monitorInfo  = trim($_POST['monitor_info'] ?? '');
$accessories  = trim($_POST['accessories'] ?? '');
// Daftar Aksesoris (bisa lebih dari satu lewat tombol + di form): Nama + Brand/Type.
// Ringkasannya tetap disimpan di kolom lama assets.accessories. Lihat includes/asset_accessories.php.
$accessoryItems = null;
if (isset($_POST['accessory'])) {
    $accessoryItems = [];
    foreach ((array)$_POST['accessory'] as $row) {
        $accessoryItems[] = ['name' => (string)($row['name'] ?? ''), 'brand' => (string)($row['brand'] ?? '')];
    }
    $accessoryItems = cleanAccessoryItems($accessoryItems);
    $accessories    = accessoriesColumnText($accessoryItems);
}
$osName       = trim($_POST['os_name'] ?? '');
// Status OS sekarang berupa checkbox (dicentang = Original).
$osStatus     = !empty($_POST['os_status_original']) ? 'Original' : 'Belum Original';
$serial       = trim($_POST['serial_number'] ?? '');
$purchaseDate = trim($_POST['purchase_date'] ?? '');
$purchaseDate = ($purchaseDate !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $purchaseDate)) ? $purchaseDate : null;
// Daftar Software aset ini (bisa lebih dari satu lewat tombol + di form).
// Tiap baris: nama, serial number, dan checkbox Original sendiri-sendiri.
// Lihat includes/asset_software.php. Kolom lama assets.software/
// software_serial_number/software_status TIDAK dipakai lagi.
$softwareItems = [];
foreach ((array)($_POST['software'] ?? []) as $row) {
    $softwareItems[] = [
        'name'     => trim((string)($row['name'] ?? '')),
        'serial'   => trim((string)($row['serial'] ?? '')),
        'original' => !empty($row['original']),
    ];
}
$motherboardBrand = trim($_POST['motherboard_brand'] ?? '');
$status       = $_POST['status'] ?? 'Stok';
$pcUsername   = trim($_POST['pc_username'] ?? '');
$pcPassword   = trim($_POST['pc_password'] ?? '');
$pcUsername   = $pcUsername !== '' ? $pcUsername : null;
$pcPassword   = $pcPassword !== '' ? $pcPassword : null;

// Pesan gagal ditampilkan di halaman Aset (bukan halaman kosong), lalu kembali ke daftar.
$failSave = function (string $text) use ($category): void {
    $_SESSION['asset_bulk_msg'] = ['ok' => false, 'text' => $text];
    header('Location: assets.php' . (isTabletCategory($category) ? '?category=' . urlencode($category) : ''));
    exit;
};
if ($category === '') { $failSave(t('gen_number_select_category_first')); }

$db = getDB();

// Nomor Aset:
// - Aset BARU -> selalu dibuat otomatis di sini (format: Awalan/Departement/Jenis/Urutan); isian form diabaikan.
// - EDIT aset -> boleh diubah manual di form. Kalau dikosongkan, nomor yang lama dipertahankan
//   (tidak diam-diam berganti); untuk nomor baru pakai tombol "Buatkan Otomatis" di form.
$autoNumbered = false;
if ($id) {
    $cur = $db->prepare("SELECT asset_number FROM assets WHERE id = ?");
    $cur->execute([(int)$id]);
    $current = $cur->fetchColumn();
    if ($current === false) { $failSave(t('asset_save_failed')); }
    if ($assetNumber === '') { $assetNumber = (string)$current; }
}
if ($assetNumber === '' || !$id) {
    $suggest = suggestAssetNumber($db, $category, assetNumberDepartment($db, $ownerIds, $department), $location, $id ? (int)$id : null);
    if (!$suggest['ok']) { $failSave(t('asset_save_failed') . ' ' . $suggest['message']); }
    $assetNumber  = $suggest['asset_number'];
    $autoNumbered = true;
}
if (mb_strlen($assetNumber) > ASSET_NUMBER_MAX_LEN) { $failSave(t('asset_save_number_too_long', $assetNumber, ASSET_NUMBER_MAX_LEN)); }
// Nomor Aset harus unik: beri pesan yang jelas, bukan error database.
$dup = $db->prepare("SELECT id FROM assets WHERE asset_number = ? AND id <> ? LIMIT 1");
$dup->execute([$assetNumber, $id ? (int)$id : 0]);
if ($dup->fetchColumn()) { $failSave(t('asset_save_number_taken', $assetNumber)); }
ensureAssetAccessoriesTable($db); // tabel BARU asset_accessories, dibuat jika belum ada (di luar transaksi)

// ===== Isian khusus Tablet (lihat includes/tablet.php) =====
// ID Tablet & Status Condition disimpan di tabel baru asset_tablet_details.
// Status pemakaian tablet diisi otomatis: Digunakan jika ada user, Stok jika belum.
$isTablet        = isTabletCategory($category);
$tabletId        = trim($_POST['tablet_id'] ?? '');
$tabletCondition = $_POST['tablet_condition'] ?? 'Bagus';
if ($isTablet) {
    $status = array_filter($ownerIds) ? 'Digunakan' : 'Stok';
    ensureTabletTable($db);
    // ID Tablet = akun login tablet, jadi boleh sama di beberapa tablet (tidak dicek unik lagi).
}

// Kolom purchase_date hanya ada setelah migrasi "Tanggal Pembelian" (menu Upgrade
// Sistem) dijalankan. Dicek dulu supaya tidak error di server yang belum di-upgrade.
$hasPurchaseDateCol = (bool)$db->query("
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'assets' AND COLUMN_NAME = 'purchase_date'
")->fetchColumn();

// Mutasi Aset: simpan kondisi kepemilikan SEBELUM diedit, supaya penggantian pengguna
// lewat form ini juga tercatat otomatis di menu Mutasi Aset.
$mutBefore = null;
if ($id) {
    ensureMutationTable($db);
    $mutBefore = mutationSnapshot($db, (int)$id);
}

if ($id) {
    $sql = "UPDATE assets SET
        asset_number=?, category=?, device_name=?, department=?, owner_email=?, ip_address=?, hostname=?,
        location=?, processor=?, ram=?, storage=?, printer_info=?, monitor_info=?, accessories=?,
        os_name=?, os_status=?, serial_number=?, motherboard_brand=?, status=?,
        pc_username=?, pc_password=?" . ($hasPurchaseDateCol ? ", purchase_date=?" : "") . "
        WHERE id=?";
    $params = [$assetNumber,$category,$deviceName,$department,$ownerEmail,$ip,$hostname,$location,
               $processor,$ram,$storage,$printerInfo,$monitorInfo,$accessories,
               $osName,$osStatus,$serial,$motherboardBrand,$status,$pcUsername,$pcPassword];
    if ($hasPurchaseDateCol) { $params[] = $purchaseDate; }
    $params[] = $id;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $assetId = (int)$id;
} else {
    $sql = "INSERT INTO assets
        (asset_number, category, device_name, department, owner_email, ip_address, hostname, location,
         processor, ram, storage, printer_info, monitor_info, accessories,
         os_name, os_status, serial_number, motherboard_brand, status, pc_username, pc_password" .
         ($hasPurchaseDateCol ? ", purchase_date" : "") . ")
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?" . ($hasPurchaseDateCol ? ",?" : "") . ")";
    $params = [$assetNumber,$category,$deviceName,$department,$ownerEmail,$ip,$hostname,$location,
               $processor,$ram,$storage,$printerInfo,$monitorInfo,$accessories,
               $osName,$osStatus,$serial,$motherboardBrand,$status,$pcUsername,$pcPassword];
    if ($hasPurchaseDateCol) { $params[] = $purchaseDate; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $assetId = (int)$db->lastInsertId();
}

// Simpan daftar pengguna aset ini (bisa lebih dari satu, atau kosong).
setAssetOwners($db, $assetId, $ownerIds);
// Departement, Email Pengguna, Username & Password PC diambil dari data User (user pertama),
// tidak lagi diisi di form Asset. Lihat includes/asset_user_sync.php.
syncAssetUserData($db, $assetId);
// Pengguna berubah (edit aset) -> catat di riwayat Mutasi Aset.
if ($mutBefore) {
    $mutAfter = mutationSnapshot($db, $assetId);
    $b = $mutBefore['owner_ids']; sort($b);
    $a = $mutAfter['owner_ids'];  sort($a);
    if ($b !== $a) {
        recordAssetMutation($db, $mutBefore, $mutAfter, [
            'reason' => $a ? 'other' : 'return', 'source' => 'asset_form', 'note' => t('mut_note_from_asset_form'),
        ]);
    }
}
// Simpan daftar software aset ini (bisa lebih dari satu, atau kosong).
setAssetSoftware($db, $assetId, $softwareItems);
// Simpan daftar aksesoris aset ini (Nama + Brand/Type).
if ($accessoryItems !== null) { setAssetAccessories($db, (int)$assetId, $accessoryItems); }
// Simpan ID Tablet & Status Condition (hanya untuk kategori Tablet).
if ($isTablet) {
    saveTabletDetails($db, $assetId, $tabletId, $tabletCondition);
}

$_SESSION['asset_bulk_msg'] = ['ok' => true, 'text' => $autoNumbered ? t('asset_saved_auto_number', $assetNumber) : t('asset_saved', $assetNumber)];
header('Location: assets.php' . ($isTablet ? '?category=' . urlencode($category) : ''));
exit;
