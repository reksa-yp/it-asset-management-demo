<?php
/**
 * Simpan Mutasi Aset (dari menu Mutasi Aset).
 *
 * Yang dilakukan (semua dalam 1 transaksi):
 *   1. Foto kondisi SEBELUM (pengguna, departement, lokasi) -> disimpan di asset_mutations.
 *   2. Pengguna aset diganti ke user tujuan (asset_owners), atau dikosongkan jika dikembalikan ke Stok IT.
 *   3. Status aset: Digunakan (ada user) / Stok (dikembalikan). Lokasi baru diisi jika diubah.
 *   4. Departement, email, login PC disalin dari user tujuan (sama seperti saat aset disimpan di menu Aset).
 * Struktur tabel lama TIDAK diubah.
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/mutation.php';

$back = 'mutations.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . $back); exit; }
csrfCheck();

$db = getDB();
ensureMutationTable($db); // di luar transaksi (CREATE TABLE otomatis commit di MySQL)

$assetId   = (int)($_POST['asset_id'] ?? 0);
$target    = ($_POST['target'] ?? 'user') === 'stock' ? 'stock' : 'user';
$userIds   = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['to_user_ids'] ?? [])))));
$date      = trim((string)($_POST['mutation_date'] ?? ''));
$location  = trim((string)($_POST['to_location'] ?? ''));
$reason    = (string)($_POST['reason'] ?? 'other');
$condition = (string)($_POST['asset_condition'] ?? 'good');
$note      = trim((string)($_POST['note'] ?? ''));
if ($target === 'stock') { $userIds = []; }

$fail = function (string $msg) use ($back) {
    $_SESSION['mutation_msg'] = ['ok' => false, 'text' => $msg];
    header('Location: ' . $back);
    exit;
};

$before = mutationSnapshot($db, $assetId);
if (!$before) $fail(t('mut_err_asset'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !strtotime($date)) $fail(t('mut_err_date'));
if (!assetOwnersTableExists($db)) $fail(t('asset_stock_err_migration'));

if ($target === 'user') {
    if (!$userIds) $fail(t('mut_err_no_user'));
    $ph = implode(',', array_fill(0, count($userIds), '?'));
    $st = $db->prepare("SELECT id FROM users WHERE is_active = 1 AND id IN ($ph)");
    $st->execute($userIds);
    if (count($st->fetchAll()) !== count($userIds)) $fail(t('mut_err_user_invalid'));
    $same = $before['owner_ids'];
    sort($same); $cmp = $userIds; sort($cmp);
    if ($same === $cmp && ($location === '' || $location === (string)$before['location'])) $fail(t('mut_err_same_user'));
} elseif (!$before['owner_ids'] && $before['status'] === 'Stok') {
    $fail(t('mut_err_already_stock', $before['asset_number']));
}

$db->beginTransaction();
try {
    setAssetOwners($db, $assetId, $userIds);
    $db->prepare("UPDATE assets SET status = ?" . ($location !== '' ? ", location = ?" : "") . " WHERE id = ?")
       ->execute($location !== ''
           ? [$userIds ? 'Digunakan' : 'Stok', mb_substr($location, 0, 100), $assetId]
           : [$userIds ? 'Digunakan' : 'Stok', $assetId]);
    syncAssetUserData($db, $assetId); // departement, email, login PC ikut user tujuan (kosong jika ke Stok)

    $after  = mutationSnapshot($db, $assetId);
    $number = recordAssetMutation($db, $before, $after, [
        'date' => $date, 'reason' => $reason, 'condition' => $condition, 'note' => $note, 'source' => 'menu',
    ]);
    $db->commit();

    $newId = (int)$db->query("SELECT id FROM asset_mutations WHERE mutation_number = " . $db->quote($number))->fetchColumn();
    $_SESSION['mutation_msg'] = [
        'ok'    => true,
        'text'  => t('mut_saved', $number, $before['asset_number'], mutationPartyLabel($before['user_names']), mutationPartyLabel($after['user_names'])),
        'print' => $newId,
    ];
} catch (Throwable $e) {
    if ($db->inTransaction()) $db->rollBack();
    $fail(t('mut_err_save') . ' ' . $e->getMessage());
}

header('Location: ' . $back);
exit;
