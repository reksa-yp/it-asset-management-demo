<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$id = $_GET['id'] ?? null;
if ($id && $id != $_SESSION['user_id']) {
    $db = getDB();
    $affected = assetIdsOfUsers($db, [(int)$id]); // aset yang dipakai user ini
    $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);
    deleteUserPositions($db, [(int)$id]);
    syncAssetsUserData($db, $affected); // ambil data dari user lain di aset itu, atau kosongkan
}
header('Location: users.php');
exit;
