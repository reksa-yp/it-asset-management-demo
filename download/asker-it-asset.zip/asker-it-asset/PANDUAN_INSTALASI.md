# Panduan Instalasi — IT Asset Management

Aplikasi inventaris aset IT + ticketing helpdesk (PHP + MySQL, cocok untuk XAMPP).

## Kebutuhan

- PHP 8.0 atau lebih baru, dengan ekstensi `pdo_mysql`, `mbstring`, `gd`, `zip`
- MySQL / MariaDB
- Folder `vendor/` sudah disertakan (PhpSpreadsheet & Dompdf), tidak perlu `composer install`

## Langkah instalasi

1. Ekstrak folder `asker-it-asset` ke `htdocs` (contoh: `C:\xampp\htdocs\asker-it-asset`).
2. Jalankan Apache dan MySQL dari XAMPP Control Panel.
3. Buka `http://localhost/asker-it-asset/` — otomatis diarahkan ke `install.php`.
4. Isi formulir:
   - **Database**: host, nama database, user, password (XAMPP bawaan: `localhost`, `root`, password kosong). Database dibuat otomatis kalau belum ada.
   - **Identitas sistem** (opsional): nama sistem dan awalan Nomor Aset (contoh `ABC` menghasilkan `ABC/FIN/PC/001`).
   - **Akun admin pertama**.
5. Klik **Instal sekarang**, lalu login.
6. Setelah berhasil, hapus file `install.php` dari server.

Installer otomatis terkunci setelah berhasil (file `includes/data/installed.lock`).
Untuk instal ulang, hapus file itu.

## Instalasi di hosting (Hostinger, cPanel, dan sejenisnya)

Aplikasi bisa dipasang langsung di shared hosting tanpa SSH dan tanpa Composer.

1. **Atur PHP.** Di panel hosting (Hostinger: hPanel → Advanced → PHP Configuration; cPanel: *Select PHP Version*
   atau *MultiPHP Manager*), pilih **PHP 8.1 atau lebih baru**. Pastikan ekstensi `pdo_mysql`, `mbstring`, `gd`,
   `zip`, dan `curl` aktif. Disarankan `upload_max_filesize` dan `post_max_size` = `64M`, serta
   `date.timezone` = `Asia/Jakarta`.
2. **Buat database dulu.** Di hosting, installer tidak bisa membuat database sendiri karena tidak ada user `root`.
   Hostinger: hPanel → Databases → Management. cPanel: *MySQL Database Wizard* (centang **ALL PRIVILEGES**).
   Catat nama database, user, dan password. Nama dan user biasanya diberi awalan otomatis,
   misalnya `u123456789_aset` atau `namaakun_aset`.
3. **Upload dan ekstrak.** Buka File Manager → `public_html` → upload `asker-it-asset.zip` → klik kanan →
   **Extract**. Hasilnya `public_html/asker-it-asset/`, sehingga aplikasi dibuka di `https://domainanda.com/asker-it-asset/`.
   Jika ingin langsung di `https://domainanda.com/` (atau subdomain), pindahkan **isi** folder `asker-it-asset`
   ke folder root domain tersebut. Hapus file ZIP setelah diekstrak.
4. **Jalankan installer.** Buka alamat aplikasi, lalu `install.php` terbuka otomatis. Semua cek kebutuhan harus
   hijau. Jika ada folder yang belum bisa ditulis, ubah permission `config/`, `includes/data/`, dan
   `assets/uploads/` menjadi `755` lewat File Manager.
5. **Isi database dengan data dari langkah 2**: host `localhost` (cPanel/Hostinger), nama database dan user
   **lengkap dengan awalannya**, serta password database. Lalu isi identitas sistem dan akun admin pertama, klik
   **Instal sekarang**, dan login.
6. **Amankan.** Hapus `install.php`. Aktifkan SSL/HTTPS di panel hosting.
   HTTPS juga diperlukan agar fitur scan QR bisa memakai kamera HP dan agar data Agen Kantor terenkripsi.
   Folder `scripts/` dan file panduan `.md` tidak dipakai di hosting dan boleh dihapus.

Pindah dari server lokal yang sudah berisi data: sebelum langkah 4, ekspor database lama dari phpMyAdmin
lokal, lalu impor file `.sql`-nya lewat phpMyAdmin hosting ke database baru. Installer akan mendeteksi akun
admin yang sudah ada, jadi Anda cukup login dengan akun lama. Salin juga isi `assets/uploads/` dan
`includes/data/` dari server lama jika ingin logo, kop surat, dan foto ikut pindah.

**CCTV dan menu Jaringan di hosting.** Server hosting berada di internet sehingga tidak bisa langsung
menjangkau perangkat di jaringan lokal kantor (alamat seperti `192.168.x.x`). Aplikasi mendeteksinya otomatis
(menu **Agen Kantor** → Lokasi server) lalu menyesuaikan diri:

- **Menu Jaringan**: tab Topologi & Data koneksi tetap jalan. Tab Cek jaringan & Scan disembunyikan, dan muncul
  lagi bila **Agen Kantor** diaktifkan.
- **CCTV**: di CCTV → Pengaturan → 1, setiap NVR punya pilihan **Cara terhubung**:
  - **IP publik / DDNS**: isi IP publik dari ISP (atau nama DDNS) serta port HTTP/RTSP yang diteruskan router
    (port forwarding) ke NVR. Alamat RTSP & snapshot bisa diisi manual untuk merek apa pun.
  - **Cloudflare Tunnel**: tanpa IP publik. Web NVR dibuka lewat hostname HTTPS Cloudflare.
  - **Agen Kantor**: tanpa IP publik, port forwarding, maupun VPN (lihat di bawah).
- **Live preview**: shared hosting umumnya tidak punya ffmpeg, jadi "Lihat live" otomatis memakai **snapshot**
  dari NVR yang diperbarui ±1-2 detik sekali. Video RTSP hanya di server yang punya ffmpeg (server kantor / VPS).
- **Cek otomatis**: ganti Task Scheduler dengan **Cron Job** di panel hosting (perintahnya ada di
  CCTV → Pengaturan → 7). Bila Agen Kantor aktif, cek berjalan setiap agen melapor sehingga Cron Job tidak wajib.
- Script `.bat` di folder `scripts/` khusus server Windows dan boleh dihapus di hosting.

**Agen Kantor** adalah script kecil (folder `tools/agen_kantor/`) yang dijalankan di 1 PC Windows di kantor yang
selalu menyala. Agen membaca NVR, mengambil snapshot, menjalankan ping & scan, lalu mengirim hasilnya ke hosting
lewat HTTPS. Cara pakai: menu **Agen Kantor** → centang **Aktifkan** → **Unduh paket agen** → ekstrak di PC kantor
→ klik 2x `jalankan_agen.bat` untuk uji coba → klik kanan `pasang_agen.bat` → Run as administrator agar
berjalan otomatis. PC agen butuh PHP (XAMPP, atau PHP for Windows yang diekstrak ke folder `php` di dalam folder agen).

## Setelah instalasi

- Nama sistem, logo, dan awalan Nomor Aset: menu **Pengaturan Sistem**.
- Jenis aset (Desktop PC, Laptop, Printer, Monitor, Aksesoris, Tablet) bisa diubah di menu **Kategori Aset**.
- Kredensial database tersimpan di `config/database.php` dan bisa diubah manual.
- Folder yang harus bisa ditulis web server: `config/`, `includes/data/`, `assets/uploads/` (logo dan logo signature).

## Instal manual (jika install.php tidak bisa dipakai)

`sql/install.sql` berisi seluruh struktur tabel dan bisa diimpor lewat phpMyAdmin ke database kosong.
Akun admin tetap dibuat lewat `install.php` (password harus di-hash oleh PHP).

## Panduan penggunaan

Fungsi setiap menu dan cara menggunakannya ada di file `PANDUAN_PENGGUNAAN.pdf`.

## Kop Surat (menu Kop Surat)

Admin bisa mengatur kop yang dicetak di semua dokumen (Print dan PDF) dan di bagian atas file Excel:
logo kiri atas, ornamen kanan atas, logo kecil kiri bawah, nama perusahaan, nama singkat, alamat, dan
zona waktu untuk tulisan "Dibuat pada". Selama belum diatur, dokumen memakai logo dari Pengaturan
Sistem (kalau ada) dan kop bawah kosong. Pengaturan disimpan di `includes/data/letterhead.json` dan
gambarnya di `assets/uploads/letterhead/`, jadi kedua folder itu harus bisa ditulis oleh web server.

Semua file Excel (export dan template import) memakai susunan yang sama: logo di baris 1-3, judul di
baris 5, keterangan di baris 6-7, judul kolom di baris 8, dan data mulai baris 9.

## Menu CCTV (opsional)

1. Kategori Aset → tambahkan kategori **CCTV** dan **NVR**.
2. Daftarkan NVR dan kamera di menu Asset (atau sekaligus lewat **Import CCTV / NVR** dari Excel).
3. Klik kanan `scripts\pasang_jadwal_cctv.bat` → **Run as administrator** untuk membuat jadwal cek otomatis tiap 1 menit.
   Jika XAMPP tidak di `C:\xampp`, ubah `PHP_EXE` di `scripts\cctv_check.bat`.
4. Atur email notifikasi di CCTV → Pengaturan → 3.
5. (Opsional) Live preview: unduh *ffmpeg-release-essentials* dari gyan.dev, ekstrak sehingga ada
   `C:\xampp\ffmpeg\bin\ffmpeg.exe`, lalu di CCTV → Pengaturan → 1 isi Port RTSP tiap NVR (bawaan 554) dan klik **Tes RTSP**.

Panduan lengkap: `PANDUAN_CCTV.md`.
