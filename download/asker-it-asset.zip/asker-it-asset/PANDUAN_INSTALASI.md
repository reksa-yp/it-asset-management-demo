# Panduan Instalasi — IT Asset Management

Aplikasi inventaris aset IT + ticketing helpdesk (PHP + MySQL, cocok untuk XAMPP).

## Kebutuhan

- PHP 8.0 atau lebih baru, dengan ekstensi `pdo_mysql`, `mbstring`, `gd`, `zip`
- MySQL / MariaDB
- Folder `vendor/` sudah disertakan (PhpSpreadsheet & Dompdf), tidak perlu `composer install`

## Langkah instalasi

1. Ekstrak folder `asker-it-asset` ke `htdocs` (contoh: `C:\xampp\htdocs\asker-it-asset`).
2. Jalankan Apache dan MySQL dari XAMPP Control Panel.
3. Buka `http://localhost/asker-it-asset/` — otomatis diarahkan ke `install.php`.
4. Isi formulir:
   - **Database**: host, nama database, user, password (XAMPP bawaan: `localhost`, `root`, password kosong). Database dibuat otomatis kalau belum ada.
   - **Identitas sistem** (opsional): nama sistem dan awalan Nomor Aset (contoh `ABC` menghasilkan `ABC/FIN/PC/001`).
   - **Akun admin pertama**.
5. Klik **Instal sekarang**, lalu login.
6. Setelah berhasil, hapus file `install.php` dari server.

Installer otomatis terkunci setelah berhasil (file `includes/data/installed.lock`).
Untuk instal ulang, hapus file itu.

## Setelah instalasi

- Nama sistem, logo, dan awalan Nomor Aset: menu **Pengaturan Sistem**.
- Jenis aset (Desktop PC, Laptop, Printer, Monitor, Aksesoris, Tablet) bisa diubah di menu **Kategori Aset**.
- Kredensial database tersimpan di `config/database.php` dan bisa diubah manual.
- Folder yang harus bisa ditulis web server: `config/`, `includes/data/`, `assets/uploads/` (logo dan logo signature).

## Instal manual (jika install.php tidak bisa dipakai)

`sql/install.sql` berisi seluruh struktur tabel dan bisa diimpor lewat phpMyAdmin ke database kosong.
Akun admin tetap dibuat lewat `install.php` (password harus di-hash oleh PHP).
