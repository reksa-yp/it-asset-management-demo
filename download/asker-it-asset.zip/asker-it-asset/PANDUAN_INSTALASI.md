# Panduan Instalasi — IT Asset Management

Aplikasi inventaris aset IT + ticketing helpdesk (PHP + MySQL, cocok untuk XAMPP).

## Kebutuhan

- PHP 8.0 atau lebih baru, dengan ekstensi `pdo_mysql`, `mbstring`, `gd`, `zip`
- MySQL / MariaDB
- Folder `vendor/` sudah disertakan (PhpSpreadsheet & Dompdf), tidak perlu `composer install`

## Langkah instalasi

1. Ekstrak folder `asker-it-asset` ke `htdocs` (contoh: `C:\xampp\htdocs\asker-it-asset`).
2. Jalankan Apache dan MySQL dari XAMPP Control Panel.
3. Buka `http://localhost/asker-it-asset/` — otomatis diarahkan ke `install.php`.
4. Isi formulir:
   - **Database**: host, nama database, user, password (XAMPP bawaan: `localhost`, `root`, password kosong). Database dibuat otomatis kalau belum ada.
   - **Identitas sistem** (opsional): nama sistem dan awalan Nomor Aset (contoh `ABC` menghasilkan `ABC/FIN/PC/001`).
   - **Akun admin pertama**.
5. Klik **Instal sekarang**, lalu login.
6. Setelah berhasil, hapus file `install.php` dari server.

Installer otomatis terkunci setelah berhasil (file `includes/data/installed.lock`).
Untuk instal ulang, hapus file itu.

## Setelah instalasi

- Nama sistem, logo, dan awalan Nomor Aset: menu **Pengaturan Sistem**.
- Jenis aset (Desktop PC, Laptop, Printer, Monitor, Aksesoris, Tablet) bisa diubah di menu **Kategori Aset**.
- Kredensial database tersimpan di `config/database.php` dan bisa diubah manual.
- Folder yang harus bisa ditulis web server: `config/`, `includes/data/`, `assets/uploads/` (logo dan logo signature).

## Instal manual (jika install.php tidak bisa dipakai)

`sql/install.sql` berisi seluruh struktur tabel dan bisa diimpor lewat phpMyAdmin ke database kosong.
Akun admin tetap dibuat lewat `install.php` (password harus di-hash oleh PHP).

## Panduan penggunaan

Fungsi setiap menu dan cara menggunakannya ada di file `PANDUAN_PENGGUNAAN.pdf`.

## Kop Surat (menu Kop Surat)

Admin bisa mengatur kop yang dicetak di semua dokumen (Print dan PDF) dan di bagian atas file Excel:
logo kiri atas, ornamen kanan atas, logo kecil kiri bawah, nama perusahaan, nama singkat, alamat, dan
zona waktu untuk tulisan "Dibuat pada". Selama belum diatur, dokumen memakai logo dari Pengaturan
Sistem (kalau ada) dan kop bawah kosong. Pengaturan disimpan di `includes/data/letterhead.json` dan
gambarnya di `assets/uploads/letterhead/`, jadi kedua folder itu harus bisa ditulis oleh web server.

Semua file Excel (export dan template import) memakai susunan yang sama: logo di baris 1-3, judul di
baris 5, keterangan di baris 6-7, judul kolom di baris 8, dan data mulai baris 9.

## Menu CCTV (opsional)

1. Kategori Aset → tambahkan kategori **CCTV** dan **NVR**.
2. Daftarkan NVR dan kamera di menu Asset (atau sekaligus lewat **Import CCTV / NVR** dari Excel).
3. Klik kanan `scripts\pasang_jadwal_cctv.bat` → **Run as administrator** untuk membuat jadwal cek otomatis tiap 1 menit.
   Jika XAMPP tidak di `C:\xampp`, ubah `PHP_EXE` di `scripts\cctv_check.bat`.
4. Atur email notifikasi di CCTV → Pengaturan → 3.

Panduan lengkap: `PANDUAN_CCTV.md`.
