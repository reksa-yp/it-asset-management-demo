<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
require_once __DIR__ . '/includes/request_feature.php';
require_once __DIR__ . '/includes/letterhead.php';
function requestUi(string $id, string $en): string { return currentLang() === 'en' ? $en : $id; }

$db = getDB(); ensureRequestTable($db);
$admin = isAdmin();
$id = isset($_GET['id']) ? filter_var($_GET['id'], FILTER_VALIDATE_INT) : null;
$sql = "SELECT r.*, COALESCE(r.target_manual_name, u.full_name) AS full_name, COALESCE(r.target_manual_department, u.department) AS department, u.email, su.full_name AS submitter_name, h.full_name AS handler_name FROM user_requests r LEFT JOIN users u ON u.id=r.user_id LEFT JOIN users su ON su.id=r.submitted_by_user_id LEFT JOIN users h ON h.id=r.handled_by";
$params = [];
if ($id) { $sql .= ' WHERE r.id=?'; $params[] = $id; }
elseif (!$admin) { $sql .= ' WHERE (r.user_id=? OR r.submitted_by_user_id=?)'; $params[] = (int)$_SESSION['user_id']; $params[] = (int)$_SESSION['user_id']; }
$sql .= ' ORDER BY r.created_at DESC';
$stmt = $db->prepare($sql); $stmt->execute($params); $rows = $stmt->fetchAll();
if (function_exists("requestEnsureEnglish")) requestEnsureEnglish($db, $rows);
if ($id && $rows && !$admin && (int)$rows[0]['user_id'] !== (int)$_SESSION['user_id'] && (int)($rows[0]['submitted_by_user_id'] ?? 0) !== (int)$_SESSION['user_id']) { http_response_code(403); exit('Akses ditolak.'); }
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html><html lang="<?= htmlspecialchars(currentLang()) ?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= requestUi('Laporan Pengajuan Khusus','Special Request Report') ?></title><style>
*{box-sizing:border-box}body{font-family:Arial,Helvetica,sans-serif;color:#1e293b;margin:20px;background:#fff;font-size:11px}.toolbar{padding:12px;text-align:right;background:#fff;border-bottom:1px solid #d7deea;margin-bottom:12px}.btn{border:0;background:#1f3dd1;color:#fff;padding:9px 16px;border-radius:5px;font-weight:700;cursor:pointer}.document-title{width:100%;border-collapse:collapse;margin:0 0 12px}.document-title td{border:0;padding:4px 0;background:#fff}.document-title h1{font-size:18px;margin:0 0 5px;color:#172554}.muted{color:#64748b}.item{margin:0 0 18px;page-break-inside:avoid;break-inside:avoid}.itemhead{width:100%;border-collapse:collapse;margin:0}.itemhead td{border:1px solid #9aa8bd;padding:8px 10px;background:#eaf0f8;color:#172554}.itembody{width:100%;border-collapse:collapse;margin:0 0 14px}.itembody th,.itembody td{border:1px solid #aeb9c9;padding:7px 9px;vertical-align:top;text-align:left}.itembody th{width:20%;background:#f1f4f8;font-size:10px;font-weight:bold;color:#334155}.itembody td{width:30%;line-height:1.45;white-space:pre-wrap;overflow-wrap:anywhere}.section-title{font-size:11px;font-weight:bold;background:#dce5f2!important;color:#172554!important;letter-spacing:.02em}.photo{max-width:100%;max-height:85mm;object-fit:contain;display:block;margin:5px 0;border:1px solid #cbd5e1}.foot{margin-top:12px;padding-top:8px;border-top:1px solid #aeb9c9;color:#64748b;font-size:9px;text-align:center}@media print{body{margin:0}.toolbar{display:none}.item{page-break-inside:avoid;break-inside:avoid}a{color:inherit;text-decoration:none}.itemhead td,.itembody th,.section-title{-webkit-print-color-adjust:exact;print-color-adjust:exact}}@media(max-width:600px){body{margin:10px}.itembody th{width:28%}.itembody td{width:22%}}
<?= letterheadCss() ?>
</style></head><body>
<?= letterheadOpen() ?>
<div class="toolbar"><?php if (currentLang() !== 'en'): ?><button class="btn" type="button" id="translatePrintBtn" style="background:#0f766e;margin-right:8px"><?= requestUi('Translate text to English','Translate text to English') ?></button><?php endif; ?><button class="btn" id="printDocumentBtn" onclick="window.print()"><?= requestUi('Cetak / Simpan PDF','Print / Save PDF') ?></button></div>
<table class="document-title"><tr><td><h1><?= requestUi('Laporan Pengajuan Khusus','Special Request Report') ?></h1><div class="muted"><?= h(function_exists('customAppName') && customAppName() !== '' ? customAppName() : t('app_name')) ?> · <?= $id ? requestUi('Detail pengajuan','Request details') : ($admin ? requestUi('Riwayat seluruh pengguna','All users history') : requestUi('Riwayat pengajuan saya','My request history')) ?></div></td><td style="text-align:right;vertical-align:top"><strong><?= h(documentCreatedAt()) ?></strong><div class="muted"><?= requestUi('Tanggal cetak','Print date') ?></div></td></tr></table>
<?php if (!$rows): ?><p class="muted"><?= requestUi('Tidak ada data pengajuan untuk dicetak.','No request data to print.') ?></p><?php endif; ?>
<?php foreach ($rows as $r): ?>
<article class="item">
<table class="itemhead"><tr><td><strong><?= h($r['request_number']) ?></strong><br><span class="muted"><?= h(date('d M Y H:i', strtotime($r['created_at']))) ?></span></td><td style="text-align:right"><strong><?= requestUi('Status: ','Status: ') ?><?= h(requestUi($r['status'], ['Menunggu'=>'Pending','Disetujui'=>'Approved','Ditolak'=>'Rejected','Selesai'=>'Completed','Dibatalkan'=>'Cancelled'][$r['status']] ?? $r['status'])) ?></strong></td></tr></table>
<table class="itembody">
<tr><th><?= requestUi('Pemohon / Untuk','Requested by / For') ?></th><td><?= h($r['full_name']) ?><?php if(!empty($r['submitter_name']) && $r['submitter_name'] !== $r['full_name']): ?><br><small><?= requestUi('Diajukan oleh:','Submitted by:') ?> <?= h($r['submitter_name']) ?></small><?php endif; ?></td><th><?= requestUi('Departemen','Department') ?></th><td><?= h($r['department'] ?? '-') ?></td></tr>
<tr><th><?= requestUi('Jenis Pengajuan','Request Type') ?></th><td><?= h(requestUi($r['request_type'], ['Baru'=>'New','Penggantian'=>'Replacement'][$r['request_type']] ?? $r['request_type'])) ?></td><th><?= requestUi('Kategori','Category') ?></th><td><?= h(requestUi($r['category'], ['Aksesoris'=>'Accessories','Lainnya'=>'Other'][$r['category']] ?? $r['category'])) ?></td></tr>
<tr><th colspan="4" class="section-title"><?= requestUi('Detail Pengajuan','Request Details') ?></th></tr><tr><td colspan="4" class="translatable-text" data-original="<?= h($r['item_description']) ?>"><?= h(currentLang()==='en' && !empty($r['item_description_en']) ? $r['item_description_en'] : $r['item_description']) ?></td></tr>
<tr><th colspan="4" class="section-title"><?= requestUi('Alasan Pengajuan','Request Reason') ?></th></tr><tr><td colspan="4" class="translatable-text" data-original="<?= h($r['reason']) ?>"><?= h(currentLang()==='en' && !empty($r['reason_en']) ? $r['reason_en'] : $r['reason']) ?></td></tr>
<?php if (!empty($r['image_path'])): ?><tr><th colspan="4" class="section-title"><?= requestUi('Foto Barang / Lampiran','Item Photo / Attachment') ?></th></tr><tr><td colspan="4"><img class="photo" src="<?= h($r['image_path']) ?>" alt="Foto lampiran"></td></tr><?php endif; ?>
<?php if (!empty($r['admin_note'])): ?><tr><th colspan="4" class="section-title"><?= requestUi('Catatan Admin','Admin Notes') ?></th></tr><tr><td colspan="4" class="translatable-text" data-original="<?= h($r['admin_note']) ?>"><?= h(currentLang()==='en' && !empty($r['admin_note_en']) ? $r['admin_note_en'] : $r['admin_note']) ?></td></tr><?php endif; ?>
<?php if (!empty($r['handler_name'])): ?><tr><th><?= requestUi('Diproses oleh','Processed by') ?></th><td colspan="3"><?= h($r['handler_name']) ?></td></tr><?php endif; ?>
</table></article>
<?php endforeach; ?>
<div class="foot"><?= h(t('footer_note')) ?></div>
<?= letterheadClose() ?>
<script>
(() => {
 const csrf = <?= json_encode(csrfToken()) ?>;
 const isEnglish = document.documentElement.lang === 'en';
 const printBtn = document.getElementById('printDocumentBtn');
 const translateBtn = document.getElementById('translatePrintBtn');
 const fields = [...document.querySelectorAll('.translatable-text')];
 let translationPromise = null;
 let translationError = null;
 let translatedCount = 0;

 function setStatus(message) {
   let status = document.getElementById('translationPrintStatus');
   if (!status) {
     status = document.createElement('span');
     status.id = 'translationPrintStatus';
     status.style.cssText = 'display:inline-block;margin-right:10px;color:#475569;font-size:12px';
     document.querySelector('.toolbar')?.prepend(status);
   }
   status.textContent = message;
 }

 async function translateFields() {
   translationError = null;
   translatedCount = 0;
   const todo = fields.filter(el => !(el.dataset.translated === '1') && ((el.dataset.original || el.textContent).trim() !== ''));
   if (!todo.length) return;
   if (printBtn) printBtn.disabled = true;
   if (translateBtn) translateBtn.disabled = true;
   setStatus('Translating request details…');
   try {
     for (const el of todo) {
       const original = el.dataset.original || el.textContent;
       const res = await fetch('request_translate.php', {
         method: 'POST',
         credentials: 'same-origin',
         headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Accept': 'application/json'},
         body: new URLSearchParams({csrf_token: csrf, text: original})
       });
       let data;
       try { data = await res.json(); } catch (_) { throw new Error('Translation service returned an invalid response.'); }
       if (!res.ok || !data.ok || typeof data.translatedText !== 'string' || !data.translatedText.trim()) {
         throw new Error(data.error || 'Translation failed.');
       }
       el.textContent = data.translatedText;
       el.dataset.translated = '1';
       translatedCount++;
     }
     setStatus('Request details translated to English.');
   } catch (e) {
     translationError = e;
     setStatus('Translation failed; some original text may remain.');
   } finally {
     if (printBtn) printBtn.disabled = false;
     if (translateBtn) translateBtn.disabled = false;
   }
 }

 function ensureTranslation() {
   if (!translationPromise) {
     translationPromise = translateFields().finally(() => { translationPromise = null; });
   }
   return translationPromise;
 }

 if (isEnglish && fields.length) {
   // Translate as soon as the document loads, before the user prints or saves PDF.
   ensureTranslation();
 }
 if (translateBtn) {
   translateBtn.addEventListener('click', async () => {
     await ensureTranslation();
     if (translationError) alert(translationError.message + '\nOriginal text has been preserved. You can retry before printing.');
   });
 }
 if (printBtn) {
   printBtn.addEventListener('click', async (event) => {
     if (!isEnglish || !fields.length) return;
     event.preventDefault();
     await ensureTranslation();
     if (translationError) {
       const proceed = confirm('Some text could not be translated. Print with the original text for those fields?');
       if (!proceed) return;
     }
     window.print();
   });
 }
})();
</script></body></html>
