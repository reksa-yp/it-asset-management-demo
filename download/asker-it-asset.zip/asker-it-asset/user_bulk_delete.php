<?php
/**
 * Hapus beberapa user sekaligus, dipanggil dari form checkbox di users.php.
 * Akun yang sedang login tidak akan pernah ikut terhapus, walaupun id-nya
 * entah bagaimana terselip di daftar yang dikirim (checkbox untuk baris
 * akun sendiri memang tidak ditampilkan di users.php).
 */
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: users.php');
    exit;
}
csrfCheck();

$rawIds = $_POST['ids'] ?? [];
$ids = array_values(array_unique(array_filter(
    array_map('intval', (array)$rawIds),
    fn($v) => $v > 0 && $v != $_SESSION['user_id']
)));

if ($ids) {
    $db = getDB();
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $affected = assetIdsOfUsers($db, $ids); // aset yang dipakai user-user ini
    $stmt = $db->prepare("DELETE FROM users WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    deleteUserPositions($db, $ids);
    syncAssetsUserData($db, $affected); // ambil data dari user lain di aset itu, atau kosongkan
    $_SESSION['user_import_msg'] = ['ok' => true, 'text' => count($ids) . ' user berhasil dihapus.'];
} else {
    $_SESSION['user_import_msg'] = ['ok' => false, 'text' => 'Tidak ada user yang dipilih untuk dihapus.'];
}

header('Location: users.php');
exit;
