<?php
/**
 * Aksi admin untuk pengajuan khusus: hapus (satu / banyak) dan ubah status banyak sekaligus.
 *   POST action=delete  ids[]=1&ids[]=2
 *   POST action=status  ids[]=...  status=Disetujui|Ditolak|Menunggu|Selesai
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin();
if (!isAdmin()) { http_response_code(403); exit('Akses ditolak.'); }
require_once __DIR__ . '/includes/request_feature.php';

$views = ['all', 'pending', 'approved', 'rejected'];
$view = in_array((string)($_POST['return_view'] ?? ''), $views, true) ? (string)$_POST['return_view'] : 'all';
$back = 'request.php?view=' . urlencode($view);
$rq = trim((string)($_POST['return_q'] ?? ''));
if ($rq !== '') $back .= '&q=' . urlencode($rq);
$rc = trim((string)($_POST['return_cat'] ?? ''));
if ($rc !== '') $back .= '&cat=' . urlencode($rc);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . $back); exit; }
csrfCheck();

$ids = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['ids'] ?? [])), fn($n) => $n > 0)));
$action = (string)($_POST['action'] ?? '');
if (!$ids) { $_SESSION['request_flash'] = ['type' => 'error', 'message' => 'Pilih minimal satu pengajuan.']; header('Location: ' . $back); exit; }

$db = getDB(); ensureRequestTable($db);
$in = implode(',', array_fill(0, count($ids), '?'));

if ($action === 'delete') {
    $st = $db->prepare("SELECT id, image_path FROM user_requests WHERE id IN ($in)");
    $st->execute($ids);
    $found = $st->fetchAll(PDO::FETCH_ASSOC);
    $del = $db->prepare("DELETE FROM user_requests WHERE id IN ($in)");
    $del->execute($ids);
    $n = $del->rowCount();
    foreach ($found as $f) {                       // hapus juga foto lampirannya
        $p = (string)($f['image_path'] ?? '');
        if ($p !== '' && strpos($p, 'assets/uploads/requests/') === 0 && strpos($p, '..') === false) {
            $file = __DIR__ . '/' . $p;
            if (is_file($file)) @unlink($file);
        }
    }
    $_SESSION['request_flash'] = ['type' => 'success', 'message' => $n . ' pengajuan berhasil dihapus.'];
} elseif ($action === 'status') {
    $status = trim((string)($_POST['status'] ?? ''));
    if (!in_array($status, ['Menunggu', 'Disetujui', 'Ditolak', 'Selesai'], true)) {
        $_SESSION['request_flash'] = ['type' => 'error', 'message' => 'Status tidak valid.']; header('Location: ' . $back); exit;
    }
    $up = $db->prepare("UPDATE user_requests SET status = ?, handled_by = ? WHERE id IN ($in)");
    $up->execute(array_merge([$status, (int)$_SESSION['user_id']], $ids));
    $_SESSION['request_flash'] = ['type' => 'success', 'message' => 'Status ' . count($ids) . ' pengajuan diubah menjadi ' . $status . '.'];
} else {
    $_SESSION['request_flash'] = ['type' => 'error', 'message' => 'Aksi tidak dikenal.'];
}
header('Location: ' . $back); exit;
